﻿app.constant('WRSU_MASTER', {
    SAVELOG: 'imcc-api/v1/log',
    SECURITYLOG: 'imcc-api/v1/securelog'
});