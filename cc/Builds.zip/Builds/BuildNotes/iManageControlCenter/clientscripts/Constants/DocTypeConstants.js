﻿app.constant('WRSU_DOCTYPE', {
    SEARCH_TYPES: 'admin-api/v1/types/search',
    POST_TYPE: 'admin-api/v1/types',
    PUT_TYPE: 'admin-api/v1/types/{ALIAS}',
    GETDOCTYPESEXIST: 'admin-api/v1/types/search',
}
);


app.constant('CONST_TYPE_FILEDS', {
    AppExtension: 'app_extension',
    Description: 'description',
    DmsExtension: 'dms_extension',
    TAlias: 'id',
    HIPAAComplaint: 'hipaa',
    Database: 'database'
});

app.constant('CONST_TYPE_FILTER', {
    Alias: 'alias',
    Description: 'description',
    DmsExtension: 'dms_extension',
    AppExtension: 'app_extension',
    HIPAAComplaint: 'hipaa'
});