﻿app.constant('WRSU_APPSETUP', {
    GETAPPS: 'admin-api/v1/appsetup/search',
    POSTAPI: 'admin-api/v1/appsetup',
    PUTAPI: 'admin-api/v1/appsetup/{ALIAS}'
}
);

app.constant('CONST_APPSETUP', {
    Name: 'name',
    NameFilter: 'name',
    Type: 'id',
    TypeFilter: 'alias',
    Primary: 'primary',
    PrimaryFilter: 'primary',
    Location: 'location',
    DDE: 'dde',
    DDEFilter: 'dde',
    IntegrationMode: 'integration_mode',
    IntegrationModeFilter: 'integration_mode',
    DDEAppName: 'dde_app_name',
    DDEAppNameFilter: 'dde_app_name',
    DDETopic: 'dde_topic',
    DDETopicFilter: 'dde_topic',
    DDEOpen: 'dde_open',
    DDEReadOpen: 'dde_read_open',
    DDEPrintandExitApp: 'dde_print_1',
    DDEPRint: 'dde_print',
    DataBase: 'database'
}
);