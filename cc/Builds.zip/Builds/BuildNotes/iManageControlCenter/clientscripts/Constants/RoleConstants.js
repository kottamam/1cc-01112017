app.constant('WRSU_ROLES',{
	SEARCH_ROLES:	'admin-api/v1/roles/search',
	POST_ROLE:	'admin-api/v1/roles',
	PUT_ROLE:	'admin-api/v1/roles/{ALIAS}',
	GET_ROLE:	'admin-api/v1/roles/search',
	GET_USERSINROLE:'admin-api/v1/roles'
}
);


app.constant('CONST_ROLES_FILEDS',{	
	RoleName : 'id',
	Description : 'description',
	Privileges : '',
	IsExternal : '',
	m1: 'm1',
	m2: 'm2',
	m3: 'm3',
	nvps : 'nvps',
	profiles : 'profiles'

		/* public List<int> ContentAndFolderOperationList { get; set; }
    public List<int> AdministrativeOperationList { get; set; }
    public List<int> WebOperationsList { get; set; }

    public List<RoleProfileModel> RoleProfileModelList { get; set; }*/
}
);

app.constant('CONST_ROLES_SEARCH_FILEDS',{	
	RoleName : 'alias',
	Description : 'description'
}
);


app.constant('CONST_ROLES_POST_FILEDS',{
	Database : 'database',
	RoleName : 'id',
	Description : 'description',
	m1 : 'm1',
	m2 : 'm2',
	m3 : 'm3',
	profiles : 'profiles',
	nvps : 'nvps'
}
);

//This is from m1
app.constant('CONTENT_FOLDER_OPERATIONS',{
	IMPORTCREATECONTENT : 1,
	CHECKOUTDOCUMENTS : 2,
	UNLOCKDOCUMENTS : 4,
	DELETE : 8,
	ALLOWFULLTEXTSEARCH : 2048,
	READONLY : 16,
	CREATEPUBLICFOLDER : 32,
	CREATEPUBLICSEARCHES : 64
}
);

//This is from m2
app.constant('ADMINISTRATIVE_OPERATIONS',{
	WORKSITEIMPORT : 1,
	WORKSITEMONITOR : 2,
	WORKSITEADMINISTRATOR : 4,
	VIEWDOCUMENTS : 8,
	ISEXTERNAL : 16
}
);

//This is from m3
app.constant('WEB_OPERATIONS',{
	SEARCHWEB : 2,
	CREATEWORKSPACE : 4,
	CREATEPUBLICWORKSPACE : 8,
	CREATESYSTEMWORKSPACE : 64,
	DELETEWORKSPACE : 128
}
);
