﻿var app = angular.module('iManage', ['ngMaterial', 'common.directives', 'ngAnimate', 'ui.router', 'ngAria', 'md.data.table', 'material.svgAssetsCache', 'ngMessages', 'ngCookies', 'iManageExteralApp', 'ngSanitize', 'fixed.table.header', 'angular-nicescroll']);
var extApp = angular.module('iManageExteralApp', []);
angular.module('common.services', []);
angular.module('common.directives', ['common.services']);

(function () {
    app.config(function ($mdThemingProvider) {
        $mdThemingProvider.theme('default')
          .primaryPalette('light-blue', {
              'default': '300'
          })
          .accentPalette('deep-orange', {
              'default': '500'
          });
    })
})();

app.config([
  '$httpProvider', function ($httpProvider) {
      return $httpProvider.interceptors.push('sessionTimeoutInterceptor');
  }
]);

//app.config(["$locationProvider", function ($locationProvider) {
//    $locationProvider.html5Mode(true);
//}]);

(function () {
    app.run(['$rootScope', '$log', '$timeout', '$cookies', '$mdMedia', function ($rootScope, $log, $timeout, $cookies, $mdMedia) {
        $rootScope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState, fromParams) {

            $timeout(function () {

                $rootScope.$broadcast('InitializeTabContents');
                //$log.info("State changed from : " + fromState.name + ", to:" + toState.name);
            });

        })
        $rootScope.$mdMedia = $mdMedia;
    }]);
})();

(function () {
    app.run(['$rootScope', '$log', '$timeout', '$cookies', '$mdMedia', '$state', function ($rootScope, $log, $timeout, $cookies, $mdMedia, $state) {
        $rootScope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {

            if ($rootScope.checkReadyToChangeState) {
                event.preventDefault();
                var promise = $rootScope.checkReadyToChangeState();
                promise.then(function (response) {
                    if (response && response.Status === 0) {
                        $rootScope.checkReadyToChangeState = null;
                        $state.go(toState, toParams);
                    }
                }, function (response) {
                });
            }
        });
        //$rootScope.$mdMedia = $mdMedia;
    }]);
})();

(function () {
    app.run(['$rootScope', '$log', '$timeout', '$cookies', '$mdMedia', '$urlRouter', function ($rootScope, $log, $timeout, $cookies, $mdMedia, $urlRouter) {
        $rootScope.$on('$stateChangeCancel', function (event, toState, toParams, fromState, fromParams) {

            if (event.noUpdate !== true) {
                $urlRouter.update();
            }
            //return TransitionPrevented;
        })
    }]);
})();