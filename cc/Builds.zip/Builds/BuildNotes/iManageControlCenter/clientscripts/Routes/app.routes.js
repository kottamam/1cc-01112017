	  extApp.provider('$externalState', function($stateProvider){
        this.$get = function($state){
            return {
                /**
                 * @function app.dashboard.dashboardStateProvider.addState
                 * @memberof app.dashboard
                 * @param {string} title - the title used to build state, url & find template
                 * @param {string} controllerAs - the controller to be used, if false, we don't add a controller (ie. 'UserController as user')
                 * @param {string} templatePrefix - either 'content', 'presentation' or null
                 * @author Alex Boisselle
                 * @description adds states to the dashboards state provider dynamically
                 * @returns {object} user - token and id of user
                 */
                addState: function(title, controllerAs, templatePrefix,pageName) {
                    $stateProvider.state('home.' + templatePrefix, {
                        url: title,
                        views: {
                            'content@home': {
                                templateUrl: pageName,
                                controller: controllerAs ? controllerAs : null
                            }
                        }
                    });
                }
            }
        }
    });
    

