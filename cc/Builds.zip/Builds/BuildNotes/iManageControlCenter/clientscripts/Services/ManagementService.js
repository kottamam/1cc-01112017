﻿//app.service("ManagementService", managementService);
angular.module('common.services').service("ManagementService", managementService);
managementService.$inject = ['$http'];
function managementService($http) {

    /* this.getUserPermission = function (libName,userId,key) {
         var response = $http({
             url: baseUrl + "Mobility2/MobilityService.svc/dms/v1/groups?dbName="+libName+"&userId="+userId+"&groupID=NRTADMIN",
             method: "GET",
             headers: {
                   'cookie': 'X-Auth-Token='+key  	         
             }
         });
         return response;
     };*/




    this.getCaptions = function (libName, key) {
        var response = $http({
            url: baseUrl + "admin-api/v1/captions?database=" + libName + "&offset=0&limit=200&total=true",
            method: "GET",
            headers: {
                'cookie': 'X-Auth-Token=' + key
            }
        });
        return response;
    }
}