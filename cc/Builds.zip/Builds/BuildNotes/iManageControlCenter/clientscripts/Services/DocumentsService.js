﻿app.service("DocumentsService", DocumentsService);
DocumentsService.$inject = ['$http'];
function DocumentsService($http) {

    this.getDocuments = function (apiUrl, authKey) {
        var response = $http({
            url: apiUrl,
            method: "GET",
            headers: {
                'X-Auth-Token': authKey,
                'X-Auth-Type': 'unified'
            }
        });
        return response;
    };

    this.checkinDocument = function (apiUrl, authKey, formdata) {
        var response = $http({
            url: apiUrl,
            method: "POST",
            headers: {
                'X-Auth-Token': authKey,
                'X-Auth-Type': 'unified',
                'Content-Type': undefined

            },
            data: formdata
        });
        return response;
    };

    this.getHistoryDocumentsList = function (URL, key) {//requestModel, MetaType
        var response = $http({
            url: URL,
            method: "GET",
            headers: {
                'X-Auth-Token': key,
                'X-Auth-Type': 'unified'
            }
        });
        return response;
    }

    this.getVersionDocumentsList = function (URL, key) {
        var response = $http({
            url: URL,
            method: "GET",
            headers: {
                'X-Auth-Token': key,
                'X-Auth-Type': 'unified'
            }
        });
        return response;
    }

    this.getSecurityDocumentsList = function (URL, key) {
        var promise = $http({
            url: URL,
            method: "GET",
            headers: {
                'X-Auth-Token': key,
                'X-Auth-Type': 'unified'
            }
        });
        return promise;
    };

    this.getCheckedOutInformation = function (Url, loginmodel) {
        var promise = $http({
            url: Url,
            method: "GET",
            headers: {
                'X-Auth-Token': loginmodel.AuthKey,
                'X-Auth-Type': 'unified'
            }
        });
        return promise;
    };

    this.UnlockDocument = function (apiUrl, authKey) {
        var response = $http({
            url: apiUrl,
            method: "PATCH",
            headers: {
                'X-Auth-Token': authKey,
                'X-Auth-Type': 'unified'
            },
            data: JSON.stringify({ "action": "unlock" })

        });
        return response;
    };
}