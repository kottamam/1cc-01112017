﻿
app.service("HomeService", homeService);
homeService.$inject = ['$http'];
function homeService($http) {
    this.getDBLibraries = function (loginmodel) {
        var promise = $http({

            url: baseUrl + "api/v1/session/databases/operations",
            method: "GET",
            headers: {
                'X-Auth-Token': loginmodel.AuthKey,
                'X-Auth-Type': 'unified'
            }
        });
        return promise;
    };

    this.getUserPhoto = function (loginmodel) {
        var promise = $http({

            url: baseUrl + "api/v1/users/" + loginmodel.UserName + "/photo",
            method: "GET",
           /* headers: {
                'X-Auth-Token': loginmodel.AuthKey,
                'X-Auth-Type': 'unified'
            }*/
        });
        return promise;
    };

    this.getServerVersion = function (authKey) {
        var promise = $http({

            url: baseUrl + "api/v1/system/config ",
            method: "GET",
            headers: {
                'X-Auth-Token': authKey,
                'X-Auth-Type': 'unified'
            }
        });
        return promise;
    };
}