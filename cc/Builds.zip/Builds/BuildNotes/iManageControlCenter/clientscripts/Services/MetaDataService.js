﻿app.service("MetaDataService", MetaDataService);
MetaDataService.$inject = ['$http'];

function MetaDataService($http) {

    this.getMetaDataList = function (URL, key) {
        var response = $http({
            url: URL,
            method: "GET",
            headers: {
                'X-Auth-Token': key,
                'X-Auth-Type': 'unified'
            }
        });
        return response;
    };

    this.getExstMetaDataList = function (URL, key) {
        var response = $http({
            url: URL,
            method: "GET",
            headers: {
                'X-Auth-Token': key,
                'X-Auth-Type': 'unified'
            }
        });
        return response;
    };

    this.addMetaData = function (URL, key, metaDataDetails) {
        var promise = $http({
            url: URL,
            method: "POST",
            data: JSON.stringify(metaDataDetails),
            headers: {
                'X-Auth-Token': key,
                'X-Auth-Type': 'unified'
            }
        });
        return promise;
    };

    this.EditMetaData = function (URL, key, metaDataDetails) {
        var promise = $http({
            url: URL,
            method: "PUT",
            data: JSON.stringify(metaDataDetails),
            headers: {
                'X-Auth-Token': key,
                'X-Auth-Type': 'unified'
            }
        });
        return promise;
    };

    this.deleteMetaData = function (URL, key) {
        var promise = $http({
            url: URL,
            method: "DELETE",
            headers: {
                'X-Auth-Token': key,
                'X-Auth-Type': 'unified'
            }
        });
        return promise;
    };
}