app.service("FileService", FileService);
FileService.$inject = ['$http'];

function FileService($http) {
	this.getFile = function (apiUrl, authKey) {
		var response = $http({
			url: apiUrl,
			method: "GET",
			headers: {
				'cookie': 'X-Auth-Token=' + authKey  	         
			},
			 responseType: "arraybuffer"
			
		
		});
		return response;
	}

	
}