app.service("loginService", loginService);
loginService.$inject = ['$http'];
function loginService($http) {
    this.validateUser = function (loginmodel) {
        var promise = $http({
            url: baseUrl + (loginmodel.networklogin ? "api/v1/session/network-login" : "api/v1/session/login"),
            method: "PUT",
            data: { 'user_id': loginmodel.UserName, 'password': loginmodel.Password, 'application_name': loginmodel.ApplicationName  },
            dataType: "json"
        	 
        });
        return promise;
    };

    this.logOutUser = function (authToken) {
        var apiUrl = baseUrl + 'api/v1/session/logout?X-Auth-Token=' + authToken;
        var promise = $http({
            url: apiUrl,
            method: "GET",
            headers: {
                'X-Auth-Token': authToken,
                'X-Auth-Type': 'unified'
            }
        });
        return promise;
    };
}