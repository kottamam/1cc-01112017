app.service('CaptionService', CaptionService)
CaptionService.$inject = [ '$http' ];
function CaptionService($http) {

	 this.getCaptions = function (URL,key) {//requestModel, MetaType
	        var response = $http({
	            url: URL,
	            method: "GET",
	            headers: {
	            	 'X-Auth-Token': key,
	              	 'X-Auth-Type': 'unified'    
	            }
	        });
	        return response;
	    }
	 this.editCaptions = function(CaptionModel,URL,key) {
		var response = $http({
			url:URL,
			method:"PUT",
			heders:{
				 'X-Auth-Token': key,
              	 'X-Auth-Type': 'unified'	
			},
		data: JSON.stringify(CaptionModel)
			
		});
		return response;
		
	}

}
