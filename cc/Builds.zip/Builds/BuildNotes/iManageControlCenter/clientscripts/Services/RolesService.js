﻿app.service("RolesService", RolesService);
RolesService.$inject = ['$http'];

function RolesService($http) {
    this.getRoles = function (apiUrl, authKey) {
        var response = $http({
            url: apiUrl,
            method: "GET",
            headers: {
                //'cookie': 'X-Auth-Token=' + authKey  	  
                'X-Auth-Token': authKey,
                'X-Auth-Type': 'unified'
            }
        });
        return response;
    }

    //this.DeleteRole = function (libName, roleModel) {
    //	var response = $http({
    //		method: "POST",
    //		url: "Roles/DeleteRoles",
    //		params: {
    //			libraryName: libName,
    //			roleModelJSON: JSON.stringify(roleModel)
    //		}
    //	});
    //	return response;
    //}

    //this.getCaptions = function (libName) {
    //	var response = $http({
    //		url: "Roles/Captions",
    //		method: "GET",
    //		params: { libraryName: libName }
    //	});
    //	return response;

    //}



    this.addRoles = function (roleModel, apiUrl, authKey) {
        var response = $http({
            url: apiUrl,
            method: "POST",
            data: JSON.stringify(roleModel),
            headers: {
                //'cookie': 'X-Auth-Token=' + authKey  	  
                'X-Auth-Token': authKey,
                'X-Auth-Type': 'unified'
            }
        });
        return response;
    };

    this.editRole = function (roleModel, apiUrl, authKey) {
        var response = $http({
            url: apiUrl,
            method: "PUT",
            data: JSON.stringify(roleModel),
            headers: {
                //'cookie': 'X-Auth-Token=' + authKey  	  
                'X-Auth-Token': authKey,
                'X-Auth-Type': 'unified'
            }
        });
        return response;
    }

    this.getRole = function (apiUrl, authKey) {
        var response = $http({
            url: apiUrl,
            method: "GET",
            headers: {
                //'cookie': 'X-Auth-Token=' + authKey  	  
                'X-Auth-Token': authKey,
                'X-Auth-Type': 'unified'
            }
        });
        return response;
    };

    this.AddUsersToRole = function (apiUrl, authKey) {
        var promise = $http({
            url: apiUrl,
            method: 'PUT',
            headers: {
                'X-Auth-Token': authKey,
                'X-Auth-Type': 'unified'
            }
        });
        return promise;
    };

    this.RemoveUsersToRole = function (apiUrl, authKey) {
        var promise = $http({
            url: apiUrl,
            method: 'DELETE',
            headers: {
                'X-Auth-Token': authKey,
                'X-Auth-Type': 'unified'
            }
        });
        return promise;
    };
}