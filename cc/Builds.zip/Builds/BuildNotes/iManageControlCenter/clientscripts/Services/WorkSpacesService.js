app.service("WorkSpaceService", WorkSpaceService);
WorkSpaceService.$inject = ['$http'];

function WorkSpaceService($http) {

    this.getWorkSpaces = function (URL, key) {
        var promise = $http({
            url: URL,
            method: "GET",
            headers: {
                'X-Auth-Token': key,
                'X-Auth-Type': 'unified'
            }
        });
        return promise;
    };

    this.getWorkSpaceSecurity = function (URL, key) {
        var promise = $http({
            url: URL,
            method: "GET",
            headers: {
                'X-Auth-Token': key,
                'X-Auth-Type': 'unified'
            }
        });
        return promise;
    };
}