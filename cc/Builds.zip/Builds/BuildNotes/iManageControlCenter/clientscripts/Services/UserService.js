﻿app.service("UserService", UserService);
UserService.$inject = ['$http'];

function UserService($http) {
  
    this.getUsers = function (URL, key) {  
       var promise = $http({
            url: URL,
            method: "GET",
            headers: {
                'X-Auth-Token': key,
                'X-Auth-Type': 'unified'
            }
        });
        return promise;
    }
    
    this.getSingleUser = function (URL, key) {  
        var promise = $http({
             url: URL,
             method: "GET",
             headers: {
                 'X-Auth-Token': key,
                 'X-Auth-Type': 'unified' 	         
             }
         });
         return promise;
     }
    
    this.addUser = function (userDetails,URL, key) {//groupDetails,
    	var promise = $http({
            url: URL,
            method: "POST",
            headers: {
                'X-Auth-Token': key,
                'X-Auth-Type': 'unified'
          },
          data:JSON.stringify(userDetails)
        });
        return promise; 
    }
    
    this.editUser = function (userDetails,URL, key) {
    	var requetdata=JSON.stringify(userDetails);
        var promise = $http({
            method: "PUT",
            url: URL,
            headers: {
                'X-Auth-Token': key,
                'X-Auth-Type': 'unified'
            },
            data:requetdata
        });
        return promise;
    }
       
    this.getAllUsersInRole = function (apiUrl, authKey) {
    	var promise = $http({
            url: apiUrl,
            method: "GET",
            headers: {
                'X-Auth-Token': authKey,
                'X-Auth-Type': 'unified'
            }
        });
        return promise;
    };
    
    this.getRoleLessUsers = function (apiUrl, authKey) {
    	var promise = $http({
            url: apiUrl,
            method: "GET",
            headers: {
                'X-Auth-Token': authKey,
                'X-Auth-Type': 'unified'
            }
        });
        return promise;
    };
  
    this.getAllUsersInGroup = function (URL, key) {
        var promise = $http({
            url: URL,
            method: "GET",
            headers: {
                'X-Auth-Token': key,
                'X-Auth-Type': 'unified'
          },
          
        });
        return promise;
    }
 

    this.GetAllSelectedUsersFromTheList = function (Url, key) {
        var promise = $http({
            url: Url,
            method: "GET",
            headers: {
                'X-Auth-Token': key,
                'X-Auth-Type': 'unified'
          }
            
        });
        return promise;
    }

  
    this.AddUserToGroup = function (URL,key) {
        var promise = $http({
            url: URL,
            method: "PUT",
            headers: {
                'X-Auth-Token': key,
                'X-Auth-Type': 'unified'
            }
        });
        return promise;
    }
    
    this.RemoveUserFromGroup = function (URL, key) {
        var promise = $http({
            url: URL,
            method: "PUT",
            headers: {
                'X-Auth-Token': key,
                'X-Auth-Type': 'unified'
            }
        });
        return promise;
    };

    this.getUserOutOfGroups = function (apiUrl, authKey) {
        var promise = $http({
            url: apiUrl,
            method: "GET",
            headers: {
                'X-Auth-Token': authKey,
                'X-Auth-Type': 'unified'
            }
        });
        return promise;
    };
}