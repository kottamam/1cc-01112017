﻿app.service("GroupService", GroupService);
GroupService.$inject = ['$http'];
function GroupService($http) {

    this.getGroupDetails = function (URL, key) {
        var response = $http({
            url: URL,
            method: "GET",
            headers: {
                'X-Auth-Token': key,
                'X-Auth-Type': 'unified'
            }
        });
        return response;
    };

    this.getGroups = function (URL, key) {
        var response = $http({
            url: URL,
            method: "GET",
            headers: {
                'X-Auth-Token': key,
                'X-Auth-Type': 'unified'
            }
        });
        return response;
    };

    this.addGroups = function (groupDetails, Url, key) {
        var response = $http({
            url: Url,
            method: "POST",
            headers: {
                'X-Auth-Token': key,
                'X-Auth-Type': 'unified'
            },
            data: JSON.stringify(groupDetails)
        });
        return response;
    };

    this.EditGroup = function (groupDetails, Url, key) {
        var promise = $http({
            url: Url,
            method: "PUT",
            headers: {
                'X-Auth-Token': key,
                'X-Auth-Type': 'unified'
            },
            data: JSON.stringify(groupDetails)
        });
        return promise;
    };

    this.EnableDisableGroup = function (Url, key) {
        var response = $http({
            url: Url,
            method: "PUT",
            headers: {
                'X-Auth-Token': key,
                'X-Auth-Type': 'unified'
            }

        });
        return response;
    };

    this.copyGroup = function (groupDetails, Url, key) {
        var response = $http({
            url: Url,
            method: "POST",
            headers: {
                'X-Auth-Token': key,
                'X-Auth-Type': 'unified'
            },
            data: JSON.stringify(groupDetails)
        });
        return response;
    };

    this.GetGroupsOfUserFromGroups = function (URL, key) {
        var promise = $http({
            url: URL,
            method: "GET",
            headers: {
                'X-Auth-Token': key,
                'X-Auth-Type': 'unified'
            }
        });
        return promise;
    };

    this.GetUsersInGroup = function (URL, key) {
        var promise = $http({
            url: URL,
            method: "GET",
            headers: {
                'X-Auth-Token': key,
                'X-Auth-Type': 'unified'
            }
        });
        return promise;
    };

    this.GetGroupNonMembers = function (URL, key) {
        var promise = $http({
            url: URL,
            method: "GET",
            headers: {
                'X-Auth-Token': key,
                'X-Auth-Type': 'unified'
            }
        });
        return promise;
    };

    this.AddUserToGroup = function (apiUrl, userModel, authKey) {
        var promise = $http({
            url: apiUrl,
            method: "PUT",
            headers: {
                'X-Auth-Token': authKey,
                'X-Auth-Type': 'unified'
            },
            data: JSON.stringify(userModel)
        });
        return promise;
    };

    this.RemoveUserFromGroup = function (apiUrl, userModel, authKey) {
        var promise = $http({
            url: apiUrl,
            method: "PUT",
            headers: {
                'X-Auth-Token': authKey,
                'X-Auth-Type': 'unified'
            },
            data: JSON.stringify(userModel)
        });
        return promise;
    };
}