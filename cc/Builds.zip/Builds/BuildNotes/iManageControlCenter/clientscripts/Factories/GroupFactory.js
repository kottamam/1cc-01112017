﻿app.factory('groupFactory', groupFactory);
groupFactory.$inject = ['WRSU_GROUPS', 'CONST_GROUPS', 'CONST_GROUPS_VIEW_DETAILS'];

function groupFactory(WRSU_GROUPS, CONST_GROUPS, CONST_GROUPS_VIEW_DETAILS) {

    var groupUIModel = {
        GroupName: '',
        GroupFullName: '',
        GroupIsExternal: false,
        GroupEnabled: true,
        GroupNOS: 'NOSVirtual',
        GroupNum: 0,
        Domain: ''
    };

    var groupApiModel = {
        groupid: '',
        full_name: '',
        enabled: false,
        is_external: true,
        group_nos: 'NOSVirtual',
        groupnum: 0
    };

    var groupViewUIModel = {
        GroupName: '',
        GroupFullName: '',
        GroupEnabled: true,
        GroupIsExternal: false,
        GroupNOS: 'NOSVirtual',
        GroupNum: 0,
        Domain: ''
    };

    var groupViewApiModel = {
        GroupName: '',
        GroupFullName: '',
        GroupEnabled: false,
        GroupIsExternal: true,
        GroupNOS: 'NOSVirtual',
        GroupNum: 0
    };

    var validationSettings = {
        showMessage: false,
        confirmationPassword: ''
    };

    var returnGroupInitialValueSettings = function () {
        return angular.copy(groupUIModel);
    };

    var returnGroupViewUIInitialValueSettings = function () {
        return angular.copy(groupViewUIModel);
    };

    // return {
    // groupInitialValues : returnGroupInitialValueSettings
    // }
    var returnGroupValidationSettings = function () {
        return angular.copy(validationSettings);
    };

    function getGroupNosDisplay(nos) {
        return 'NOSVirtual';
    }

    function getGroupUIModel(groupApiModel) {
        var groupModel = angular.copy(groupUIModel);
        groupModel.GroupName = groupApiModel[CONST_GROUPS.GroupName];
        groupModel.GroupFullName = groupApiModel[CONST_GROUPS.GroupFullName];
        groupModel.GroupIsExternal = groupApiModel[CONST_GROUPS.GroupIsExternal];
        groupModel.GroupEnabled = groupApiModel[CONST_GROUPS.GroupEnabled];
        groupModel.GroupNOS = getGroupNosDisplay(groupApiModel[CONST_GROUPS.GroupNOS]);
        groupModel.GroupNum = groupApiModel[CONST_GROUPS.GroupNum];
        groupModel.Domain = groupApiModel[CONST_GROUPS.Domain];
        return groupModel;
    }

    function getGroupViewUIModel(groupViewApiModel) {
        var groupViewModel = angular.copy(groupViewUIModel);
        groupViewModel.GroupName = groupViewApiModel[CONST_GROUPS_VIEW_DETAILS.GroupName];
        groupViewModel.GroupFullName = groupViewApiModel[CONST_GROUPS_VIEW_DETAILS.GroupFullName];
        groupViewModel.GroupEnabled = groupViewApiModel[CONST_GROUPS_VIEW_DETAILS.GroupEnabled];
        groupViewModel.GroupIsExternal = groupViewApiModel[CONST_GROUPS_VIEW_DETAILS.GroupIsExternal];
        groupViewModel.GroupNOS = getGroupNosDisplay(groupViewApiModel[CONST_GROUPS_VIEW_DETAILS.GroupNOS]);
        groupViewModel.GroupNum = groupViewApiModel[CONST_GROUPS_VIEW_DETAILS.GroupNum];
        groupViewModel.Domain = groupViewApiModel[CONST_GROUPS_VIEW_DETAILS.Domain];
        return groupViewModel;

    }
    function getGroupApiPostModel(groupUIModel, dbName) {
        var groupModelApi = {}; // = angular.copy(groupUIModel)
        groupModelApi[CONST_GROUPS.DataBase] = dbName
        groupModelApi[CONST_GROUPS.GroupName] = groupUIModel.GroupName;
        groupModelApi[CONST_GROUPS.GroupFullName] = groupUIModel.GroupFullName;
        groupModelApi[CONST_GROUPS.GroupIsExternal] = groupUIModel.GroupIsExternal;
        groupModelApi[CONST_GROUPS.GroupEnabled] = groupUIModel.GroupEnabled;
        groupModelApi[CONST_GROUPS.Domain] = groupUIModel.Domain;
        groupModelApi[CONST_GROUPS.Domain] = groupUIModel.Domain;
        groupModelApi[CONST_GROUPS.SyncId] = '';
        groupModelApi[CONST_GROUPS.DistinguishedName] = '';
        if (groupUIModel.GroupNOS == 'NOSVirtual') {
            groupModelApi[CONST_GROUPS.GroupNOS] = 2;
        }
        else {
            groupModelApi[CONST_GROUPS.GroupNOS] = 0;
        }
        groupModelApi.group_domain = '';
        return groupModelApi;

    }
    function getGroupApiPutModel(groupUIModel, dbName) {
        var groupModelApi = {}; // = angular.copy(groupUIModel)
        groupModelApi[CONST_GROUPS.DataBase] = dbName
        groupModelApi[CONST_GROUPS.GroupName] = groupUIModel.GroupName;
        groupModelApi[CONST_GROUPS.GroupFullName] = groupUIModel.GroupFullName;
        groupModelApi[CONST_GROUPS.GroupIsExternal] = groupUIModel.GroupIsExternal;
        groupModelApi[CONST_GROUPS.GroupEnabled] = groupUIModel.GroupEnabled;
        // groupModelApi[CONST_GROUPS.GroupNOS] = groupUIModel.GroupNOS;
        if (groupUIModel.GroupNOS == 'NOSVirtual') {
            groupModelApi[CONST_GROUPS.GroupNOS] = 2;
        }
        else {
            groupModelApi[CONST_GROUPS.GroupNOS] = 0;
        }
        groupModelApi[CONST_GROUPS.GroupNum] = groupUIModel.GroupNum;
        return groupModelApi;

    }
    var returnGroupUIModel = function (groupApiModel) {
        return getGroupUIModel(groupApiModel);

    }
    var returnGroupViewUIModel = function (groupViewApiModel) {
        return getGroupViewUIModel(groupViewApiModel);

    }

    var returnGroupApiPostModel = function (group, dbName) {
        return getGroupApiPostModel(group, dbName);

    }
    var returnGroupApiPutModel = function (group, dbName) {
        return getGroupApiPutModel(group, dbName);

    }

    var returnGroupUsersAPI = function (requestModel, GroupName) {
        var apiUrl = baseUrl + WRSU_GROUPS['GETGROUPUSERS'];
        apiUrl = apiUrl.replace("<group_alias>", GroupName);

        apiUrl += "?database=" + requestModel.libraryName + '&offset=' + (requestModel.pagenumber - 1) * requestModel.pageLength +
                    '&limit=' + requestModel.pageLength + '&total=' + requestModel.isTotal;

        if (requestModel.searchText.trim().length > 0)
            apiUrl += '&alias=*' + requestModel.searchText.trim() + '*';

        return apiUrl;
    };

    var returnGroupNonMembersAPI = function (requestModel, GroupName) {
        var apiUrl = baseUrl + WRSU_GROUPS['GETNONGROUPMEMBERS'];
        apiUrl = apiUrl.replace("<group_alias>", GroupName);

        apiUrl += "?database=" + requestModel.libraryName + '&offset=' + (requestModel.pagenumber - 1) * requestModel.pageLength +
                    '&limit=' + requestModel.pageLength + '&total=' + requestModel.isTotal;

        if (requestModel.searchText.trim().length > 0)
            apiUrl += '&alias=*' + requestModel.searchText.trim() + '*';

        return apiUrl;
    };

    var returnAPIUrl = function (APIFOR, requestModel, userId, dbName, action) {
        var ApiUrl = '';
        if (APIFOR !== 'GETGROUPLISTONOFFSET') {
            ApiUrl = baseUrl + WRSU_GROUPS[APIFOR];
        }
        else {
            ApiUrl = baseUrl + WRSU_GROUPS['SEARCHGROUPS'];
        }

        if (APIFOR == 'GETGROUPSOFUSERFROMGROUPS') {
            ApiUrl = prepareUrlGroupsOfUser(ApiUrl, requestModel, userId, dbName);

         }
        else if (APIFOR == 'REMOVEUSERFROMGROUP' || APIFOR == 'ADDUSERINGROUP') {
            ApiUrl = baseUrl + WRSU_GROUPS[APIFOR];
            ApiUrl = ApiUrl.replace("<group_alias>", requestModel.GroupName);
        }
        else if (APIFOR == 'VIEWGROUPDETAILS') {
            //return ApiUrl + "?dbName=" + dbName + '&groupID=' + requestModel.GroupName;
            return ApiUrl + requestModel.GroupName;
        }
       /* else if (APIFOR == 'GETUSERSINGROUP') {
            return ApiUrl + "?dbName=" + requestModel.libraryName + '&pageLength=' + requestModel.pageLength + '&groupName=' + userId;
        }*/
        else if (APIFOR == 'COPYGROUPS') {
            return ApiUrl + userId + '/members'
        }       
        else if (APIFOR == 'GETGROUPLISTONOFFSET') {
            ApiUrl = prepareGroupListUrlOnOffset(ApiUrl, requestModel, userId);
        }
        else if (APIFOR == 'POSTGROUPS') {
            ApiUrl = baseUrl + WRSU_GROUPS['POSTGROUPS'];
        }
        else if (APIFOR == 'PUTGROUPS') {
            ApiUrl = baseUrl + WRSU_GROUPS['PUTGROUPS'] + requestModel.GroupName;
        }
        else if (requestModel != null) {
            ApiUrl = prepareUrl(ApiUrl, requestModel);
        }
        return ApiUrl;
    };

    function prepareAssignGroupUri(URL, group, User, dbName, action) {
        var ApiUrl = URL;
        if (action == "add")
            return URL + "?dbName=" + dbName + '&user=' + User + '&groupName=' + group + '&action=addUser';
        else if (action == "remove")
            return URL + "?dbName=" + dbName + '&user=' + User + '&groupName=' + group + '&action=deleteUser';
        else if (action == "enable")
            return URL + "?dbName=" + dbName + '&groupName=' + group + '&action=enableGroup';
        else if (action == "disable")
            return URL + "?dbName=" + dbName + '&groupName=' + group + '&action=disableGroup';
    }

    function prepareUrlGroupsOfUser(URL, groups, User, dbName) {
        var apiUrl = URL.replace("<userId>", User);
        apiUrl = apiUrl.replace("<dbName>", dbName);

        var aliasString = '';
        if (groups.length > 0) {
            angular.forEach(groups, function (grp) {
                if (aliasString.trim().length > 0) {
                    aliasString += ',';
                }
                aliasString += grp;
            });
        }
        apiUrl = apiUrl.replace("<alias>", aliasString);
        return apiUrl;

        //var ApiUrl = URL + "?dbName=" + dbName + '&userId=' + User + '&groupID=';
        //if (groups.length > 0) {
        //    angular.forEach(groups, function (grp) {
        //        if (ApiUrl.indexOf('=', ApiUrl.length - 1) !== -1) {
        //            ApiUrl += grp;
        //        } else {
        //            ApiUrl += ',' + grp;
        //        }
        //    });
        //}
        //return ApiUrl;
    }

    function prepareUrl(URL, requestModel) {
        var ApiUrl = URL + "?database=" + requestModel.libraryName + '&offset=' + ((requestModel.pagenumber - 1) * requestModel.pageLength) + '&limit=' + requestModel.pageLength + '&total=' + requestModel.isTotal;
        if (requestModel.searchText != null && requestModel.searchText != '')
            ApiUrl += '&query=*' + requestModel.searchText + '*'
        if (requestModel.filters.length > 0) {
            angular.forEach(requestModel.filters, function (filterItem) {
                if (filterItem.FilterValues[0] != null && filterItem.FilterValues[0] != '') {
                    if (filterItem.FilterKey == 'GroupEnabled' || filterItem.FilterKey == 'GroupIsExternal') {
                        ApiUrl += '&' + CONST_GROUPS[filterItem.FilterKey + 'Filter'] + '=' + (filterItem.FilterValues[0] == "Y" ? 'true' : 'false');


                    } else {
                        ApiUrl += '&' + CONST_GROUPS[filterItem.FilterKey + 'Filter'] + '=*' + filterItem.FilterValues[0] + '*'

                    }
                }
            });
        }
        return ApiUrl;
    }


    function prepareGroupListUrlOnOffset(URL, requestModel) {
        var ApiUrl = URL + "?database=" + requestModel.libraryName + '&offset=' + requestModel.pagenumber + '&limit=' + requestModel.pageLength +
            '&total=' + requestModel.isTotal;
        if (requestModel.searchText != null && requestModel.searchText != '')
            ApiUrl += '&query=*' + requestModel.searchText + '*';
        if (requestModel.filters.length > 0) {
            angular.forEach(requestModel.filters, function (filterItem) {
                if (filterItem.FilterValues[0] != null && filterItem.FilterValues[0] != '') {
                    if (filterItem.FilterKey == 'GroupEnabled' || filterItem.FilterKey == 'GroupIsExternal') {
                        ApiUrl += '&' + CONST_GROUPS[filterItem.FilterKey + 'Filter'] + '=' + (filterItem.FilterValues[0] == "Y" ? 'true' : 'false');
                    } else {
                        ApiUrl += '&' + CONST_GROUPS[filterItem.FilterKey + 'Filter'] + '=*' + filterItem.FilterValues[0] + '*'

                    }
                }
            });
        }
        return ApiUrl;
    }

    function prepareGroupFromUser(URL, requestModel, userId) {
        var ApiUrl = URL + "?dbName=" + requestModel.libraryName + '&pageLength=' + requestModel.pageLength.toString() + '&userId=' + userId;
        return ApiUrl;
    }

    return {
        groupInitialValues: returnGroupInitialValueSettings,
        validations: returnGroupValidationSettings,
        getGroupUI: returnGroupUIModel,
        getGroupViewUI: returnGroupViewUIModel,
        getGroupPostModel: returnGroupApiPostModel,
        getGroupPutModel: returnGroupApiPutModel,
        getAPIUrl: returnAPIUrl,
        groupViewUIInitialValueSettings: returnGroupViewUIInitialValueSettings,
        getGroupUsersAPI: returnGroupUsersAPI,
        getGroupNonMemberAPI: returnGroupNonMembersAPI
    }
}