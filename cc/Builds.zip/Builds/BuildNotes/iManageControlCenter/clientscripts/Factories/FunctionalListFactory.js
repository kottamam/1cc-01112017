﻿app.factory('functionalListFactory', functionalListFactory);

function functionalListFactory() {

    //var userEvents = [
    //  {
    //      'Add': 'Add_Virtual_User',
    //      'Edit':'Add_Virtual_User',
    //      'AddClick': 'Add_Virtual_User',
    //      'EditClick':'OnEditing("Add_Virtual_User")',
    //      'URL': '#/user',
    //      'DisplayText': 'Virtual user'
    //  }
    //];
  

    //var userMenus = [
    //    {
    //        'relation': 'Add_Virtual_User1',
    //        'referance': '#/user',
    //        'labelText': 'Virtual user'
    //    }
    //];

    var appSetUpMenus = [
     {
         'relation': 'Add_virtual_appSetup',
         'referance': '#/appSetup',
         'labelText': 'App Setup'
     }
    ];

    var MetaDataMenus = [
   {
       'relation': 'Add_Edit_MetaData',
       'referance': '#/metaData',
       'labelText': 'MetaData'
   }
    ];
    
    var groupMenus = [
     {
         'relation': 'virtual_group',
         'referance': '#/group',
         'labelText': 'Virtual Group'
     }
    ];

    var docMenus = [
   {
       'relation': 'virtual_docs',
       'referance': '#/types',
       'labelText': 'Add types'
   }
    ];

    var SecurityTemplatesMenu = [
 {
     'relation': 'Add_Edit_Security_Templates',
     'referance': '',
     'labelText': 'Add Security Template'
 }
    ];

    // var databasesMenus = [
    //{
    //    'relation': 'Add_Databases',
    //    'referance': '#/tab_database',
    //    'labelText': 'Add Databases'
    //}
    // ];


    var moreUserMenus = [
      {
          'relation': 'javascript:void(0);',
          'referance': '',
          'labelText': 'Add/Remove Groups'
      },
    {
        'relation': 'javascript:void(0);',
        'referance': '',
        'labelText': 'Add/Remove Roles'
    },
      {
          'relation': 'javascript:void(0);',
          'referance': '',
          'labelText': 'Add/Remove Preferred Database'
      }
    ];


    var moreGroupMenus = [
       {
           'relation': 'javascript:void(0);',
           'referance': '',
           'labelText': 'Add/Remove Users'
       }
    ];

    var moreRolesMenus = [
    {
        'relation': 'javascript:void(0);',
        'referance': '',
        'labelText': 'Add/Remove Users'
    },
  {
      'relation': 'javascript:void(0);',
      'referance': '',
      'labelText': 'Create/Edit Profile'
  },
    {
        'relation': 'javascript:void(0);',
        'referance': '',
        'labelText': 'Search Profile'
    }
    ];

    var moreTypesMenus = [
    {
        'relation': 'javascript:void(0);',
        'referance': '',
        'labelText': 'Add/Remove File Types'
    },
  {
      'relation': 'javascript:void(0);',
      'referance': '',
      'labelText': 'Create File Type'
  },
    {
        'relation': 'javascript:void(0);',
        'referance': '',
        'labelText': 'File Types'
    }
    ];

    return {
        getMenu: function (currentTab) {
            return GetAddMenus(currentTab);
        },
        getMoreMenu: function (currentTab) {
            return GetMoreMenus(currentTab);
        }
    }

    function GetAddMenus(currentTab) {

        switch (currentTab) {
            case 'User':
                return userMenus;
                break;

            case 'Group':
                return groupMenus;
                break;

            case 'Types':
                return docMenus;
                break;

            case 'App Setup':
                return appSetUpMenus;
                break;

            case 'Roles':
                break;
            case 'MetaData':
                return MetaDataMenus;
                break;

            case 'Security Templates':
                return SecurityTemplatesMenu;
                break;

        }
    }

    function GetMoreMenus(currentTab) {

        switch (currentTab) {
            case 'User':
                return moreUserMenus;
                break;

            case 'Group':
                return moreGroupMenus;
                break;

            case 'Types':
                return moreTypesMenus;
                break;

            case 'AppSetup':
                break;

            case 'Roles': return moreRolesMenus;
                break;

        }
    }
}