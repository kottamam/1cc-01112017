﻿app.factory('loginFactory', loginFactory);
loginFactory.$inject = ['$http', '$q', 'HomeService', 'groupFactory', 'GroupService'];

function loginFactory($http, $q, homeService, groupFactory, GroupService) {
    
    function loadsettings() {
        var deferred = $q.defer();
        var x2js = new X2JS();
        var todayDate = (new Date()).toJSON();
        var promise = $http.get("content/settings.xml?v=" + todayDate)

        promise.then(function (response) {
            var navXml = x2js.xml_str2json(response.data);
            var sectionsObj = navXml.root.groupprefix;
            deferred.resolve(sectionsObj);
        });
        return deferred.promise;
    }

    var premittedUser = function (loginmodel) {
        var deferred = $q.defer();
        var x2js = new X2JS();
        var pdbrequestModel = {};
        pdbrequestModel.libraryName = '*';
        var settings = loadsettings();
        settings.then(function (response) {
            var promise = homeService.getDBLibraries(loginmodel);
            promise.then(function (responsedb) {
                if (responsedb && responsedb.data && responsedb.data.data) {
                    angular.forEach(responsedb["data"]["data"], function (db) {
                        var dbname = db.database;

                        var apiUrl = groupFactory.getAPIUrl('GETGROUPSOFUSERFROMGROUPS', [response], loginmodel.UserName, dbname);
                        var promiseOne = GroupService.GetGroupsOfUserFromGroups(apiUrl, loginmodel.AuthKey);
                        promiseOne.then(function (responsegroups) {
                            deferred.resolve(responsegroups.data.data);
                        });
                    });
                } else {

                    deferred.resolve(responsedb);
                }
            });
        });
        return deferred.promise;
    }

    var returnrequestModelDef = function (loginmodel) {
        return premittedUser(loginmodel);
    };

    return {
        getpremittedUser: premittedUser
    };
};