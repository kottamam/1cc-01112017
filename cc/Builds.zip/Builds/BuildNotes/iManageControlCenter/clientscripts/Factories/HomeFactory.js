﻿app.factory('homeFactory', homeFactory);
app.factory('sessionTimeoutInterceptor', sessionTimeoutInterceptor);

homeFactory.$inject = ['$http', '$q', '$externalState', '$state', '$filter'];
function homeFactory($http, $q, $externalState, $state, $filter) {
    //Management
    var selectedAppSettings = {
        appType: '',
        CurrentTab: '',
        CurrentSubTab: '',
        NoAppsPermission: 'Error',
        TotalRowCount: 0,
        CurrentPageIndex: 1,
        ResponseCount: 50,
        MetaDataItem: ''
    }

    var appsVar = {
        initialLoading: true,
        selectedRecordId: '',
        SearchText: '',
        CaptionsList: [],
        selectedMetaData: 'CUSTOM1',
        sortField: '',
        rightClickMenuID: '',
        tooltipValue: ''
    }

    var requestModelDef = {
        libraryName: '',
        pagenumber: 1,
        pageLength: 50,
        isTotal: true,
        IsMoreRowsFound: false,
        Cursor: '',
        searchText: '',
        sortKey: '',
        sortValue: '',//,DESC
        filters: []//[{'Key1',[{'Value1', 'Value2',etc}] },{'Key1',[{'Value1', 'Value2',etc}] }]        
    }

    var requestModelDe = {
        libraryName: '',
        pagenumber: 1,
        pageLength: 50,
        isTotal: true,
        IsMoreRowsFound: false,
        Cursor: '',
        searchText: '',
        sortKey: '',
        sortValue: '',//,DESC
        filters: [],
        DocumentNumber: '',
        Version: '',
        UserID: '',
        UserType: '',
        Custom1: '',
        Custom2: '',
        Id: ''
    }

    var NavigationMenu = function (captionsList) {
        var deferred = $q.defer();
        var x2js = new X2JS();
        var promise = $http.get("content/navigation.xml")

        promise.then(function (response) {
            var NavigationMenuJson = [];

            var navXml = x2js.xml_str2json(response.data);
            var sectionsObj = navXml.root.sections;
            angular.forEach(sectionsObj, function (section) {
                NavigationMenuJson.push(getJsonObject(section, '','',captionsList));
            });
            deferred.resolve(NavigationMenuJson);


        });



        return deferred.promise;
    }
    function getJsonObject(sectionobj, parentname, targetName,captionsList) {
        var obj = {};
        obj.AppsID = sectionobj._id;
        obj.AppsName = sectionobj._name;
        var url = '';
        var target = '';
        if (parentname != '') {
            url = parentname + '/' + obj.AppsName;
            target = targetName + '_' + obj.AppsID;
        } else {
            url = obj.AppsName;
            target = obj.AppsID;
        }

        obj.AppsIcon = sectionobj._iconclass;
        if (sectionobj._pageName != '' && sectionobj._pageName) {
            obj.AppsType = 'link';
        } else if (sectionobj.subsections && sectionobj.apps) {
            obj.AppsType = 'toggle-menu';

        }
        else if (sectionobj.subsections && !sectionobj.apps) {
            obj.AppsType = 'toggle';
        }
        else if (!sectionobj.subsections && sectionobj.apps) {
            obj.AppsType = 'menu';
        }
        obj.AppsTarget = target;

        if (sectionobj._pageName != '' && sectionobj._pageName) {
            if ($filter('filter')($state.get(), { name: 'home.' + target }).length == 0) {
                $externalState.addState(url, sectionobj._controller == "" ? null : sectionobj._controller, target, sectionobj._pageName);
            }
        }
        obj.childMenus = [];

        if (sectionobj.subsections) {
            if (sectionobj.subsections.length) {
                angular.forEach(sectionobj.subsections, function (subsection) {

                    obj.childMenus.push(getJsonObject(subsection, url, target,captionsList));
                });
            } else {
                obj.childMenus.push(getJsonObject(sectionobj.subsections, url, target,captionsList));
            }
        }
        if (sectionobj.apps) {
            if (sectionobj.apps.length) {
                angular.forEach(sectionobj.apps, function (apps) {
                	if(obj.AppsName=='Metadata' && apps.name=='Custom'){
                		 angular.forEach(captionsList, function (caps) {
                			 if(!caps.ParentMetaItem && caps.MetaDataItem!='CLASS')
                			 obj.childMenus.push(createCustomAppsObject(apps, url, target,caps));  });
                	}else
                	{ obj.childMenus.push(getAppsJsonObject(apps, url, target));}
                });
            } else {
            	if(obj.AppsName=='Metadata' && sectionobj.apps.name=='Custom'){
           		 angular.forEach(captionsList, function (caps) {
           			 if(!caps.ParentMetaItem && caps.MetaDataItem!='CLASS')
           			    obj.childMenus.push(createCustomAppsObject(sectionobj.apps, url, target,caps)); });
           	}else
           	{ obj.childMenus.push(getAppsJsonObject(sectionobj.apps, url, target));}
            }
        }

        if (obj.childMenus.length == 0) {
            obj.childMenus = "";
        }
        return obj;
    }
    function createCustomAppsObject(apps, parentname, targetname,caption)
    {
    	 var obj = {};
         obj.AppsID = caption.MetaDataItem;
         obj.AppsName = caption.MetaDataItem;
         obj.AppsTitle = caption.DisplayText;
         var url = '';
         var target = '';
         if (parentname != '') {
             url = parentname + '/' + obj.AppsID;
             target = targetname + '_' + obj.AppsID;
         } else {
             url = obj.AppsID;
             target = obj.AppsID;
         }

         obj.AppsIcon = apps.iconclass;
         obj.AppsType = 'tab';
         obj.AppsTarget = target;

         if (apps.pageName != '' && apps.pageName) {
             if ($filter('filter')($state.get(), { name: 'home.' + target }).length == 0) {
                 $externalState.addState(url, apps.controller == "" ? null : apps.controller, target, apps.pageName);
             }
         }
         return obj;
    }
    function getAppsJsonObject(apps, parentname, targetname) {
        var obj = {};
        obj.AppsID = apps.id;
        obj.AppsName = apps.name;
        obj.AppsTitle = apps.title;
        var url = '';
        var target = '';
        if (parentname != '') {
            url = parentname + '/' + obj.AppsName;
            target = targetname + '_' + obj.AppsID;
        } else {
            url = obj.AppsName;
            target = obj.AppsID;
        }

        obj.AppsIcon = apps.iconclass;
        obj.AppsType = 'tab';
        obj.AppsTarget = target;

        if (apps.pageName != '' && apps.pageName) {
            if ($filter('filter')($state.get(), { name: 'home.' + target }).length == 0) {
                $externalState.addState(url, apps.controller == "" ? null : apps.controller, target, apps.pageName);
            }
        }
        return obj;

    }

    var returnrequestModelDef = function () {
        return angular.copy(requestModelDe);
    }

    var userAreaDef = [{ AppTypeName: "Management", visibility: true }, { AppTypeName: "Content", visibility: true }, { AppTypeName: "System", visibility: true }]

    return {
        selectedApp: selectedAppSettings,
        applicationVariables: appsVar,
        userArea: userAreaDef,
        requestModel: requestModelDef,
        getSections: NavigationMenu,
        requestModelInstance: returnrequestModelDef
    }
};


sessionTimeoutInterceptor.$inject = ['$window', '$timeout', '$cookies'];
function sessionTimeoutInterceptor($window, $timeout, $cookies) {

    return {
        request: function (config) {
            $cookies.sessiontimeout = null;
            if ($cookies.get('UserAuthKey')) {
                var AuthKey = $cookies.get('UserAuthKey');
                $cookies.put('UserAuthKey', AuthKey, { 'expires': updateCookieExpiary() });
                var LoginUserId = $cookies.get('LoginUserId');
                $cookies.put('LoginUserId', LoginUserId, { 'expires': updateCookieExpiary() });
                var toState = $cookies.get('toState');
                $cookies.put('toState', toState, { 'expires': updateCookieExpiary() });
            } else {
                $cookies.sessiontimeout = 401;
            }
            return config;
        },
        response: function (response) {

            if (UserSessionTimer) {
                $timeout.cancel(UserSessionTimer);
                UserSessionTimer = null;
            }

            return response;
        },

        responseError: function (response) {
            $cookies.sessiontimeout = response.status;
            return response;
        }
    };
}