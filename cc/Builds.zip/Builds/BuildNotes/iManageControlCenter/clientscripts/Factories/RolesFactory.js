﻿app.factory('rolesFactory', rolesFactory);
rolesFactory.$inject = ['WRSU_ROLES', 'CONST_ROLES_FILEDS', 'CONST_ROLES_SEARCH_FILEDS', 'CONST_ROLES_POST_FILEDS',
						'CONTENT_FOLDER_OPERATIONS', 'ADMINISTRATIVE_OPERATIONS', 'WEB_OPERATIONS'];

function rolesFactory(WRSU_ROLES, CONST_ROLES_FILEDS, CONST_ROLES_SEARCH_FILEDS, CONST_ROLES_POST_FILEDS,
		CONTENT_FOLDER_OPERATIONS, ADMINISTRATIVE_OPERATIONS, WEB_OPERATIONS) {

	var rolesInitialValueSettings = {
		RoleName: '',
		Description: '',
		Privileges: '',
		RoleIsExternal: false,
		SelectedPrivileges: [],
		RemovedPrivileges: [],
		SelectedMembers: [],
		RemovedMembers: [],
		ProfileInfo: []
	};

	var rolesDBModelInitialValueSettings = {
		RoleName: '',
		Description: '',
		Privileges: '',
		IsExternal: false,
		ContentAndFolderOperationList: [],
		AdministrativeOperationList: [],
		WebOperationsList: [],
		RoleProfileModelList: []
	};

	var roleProfileModel = {
		RoleName: '',
		ProfileId: '',
		SearchValue: '',
		SetValue: '',
		SearchAccess: '',
		SetAccess: '',
		Profile: []
	};

	var returnRolesInitialValueSettings = function () {
		return angular.copy(rolesInitialValueSettings);
	}

	var returnrolesDBModelInitialValueSettings = function () {
		return angular.copy(rolesDBModelInitialValueSettings);
	}

	var returnRoleProfileModel = function () {
		return angular.copy(roleProfileModel);
	}

	var returnSearchAPIUrl = function (requestModel) {
		var apiURL = baseUrl + WRSU_ROLES['SEARCH_ROLES'];
		var offset = ((requestModel.pagenumber - 1) * requestModel.pageLength);

		apiURL += "?database=" + requestModel.libraryName +
		'&offset=' + offset + '&limit=' + requestModel.pageLength + '&total=' + requestModel.isTotal;

		if (requestModel.searchText != null && requestModel.searchText.trim().length > 0)
			apiURL += '&query=*' + requestModel.searchText + '*';

		if (requestModel.filters && requestModel.filters.length > 0) {
			angular.forEach(requestModel.filters, function (filterItem) {
				if (filterItem.FilterValues[0] != null && filterItem.FilterValues[0].trim().length > 0) {
					apiURL += '&' + CONST_ROLES_SEARCH_FILEDS[filterItem.FilterKey] + '=*' + filterItem.FilterValues[0] + '*';
				}
			});
		}
		return apiURL;
	}

	function getRoleUIModel(roleAPIModel) {
		var roleTempModel = angular.copy(rolesInitialValueSettings);

		roleTempModel.RoleName = roleAPIModel[CONST_ROLES_FILEDS.RoleName];
		roleTempModel.Description = roleAPIModel[CONST_ROLES_FILEDS.Description];
		roleTempModel.RoleIsExternal = roleAPIModel[CONST_ROLES_FILEDS.IsExternal];
		roleTempModel.Privileges = '';

		if (!isNaN(roleAPIModel[CONST_ROLES_FILEDS.m1]) && !isNaN(roleAPIModel[CONST_ROLES_FILEDS.m2]))
			roleTempModel.Privileges = roleAPIModel[CONST_ROLES_FILEDS.m1] + roleAPIModel[CONST_ROLES_FILEDS.m2];
		else if (!isNaN(roleAPIModel[CONST_ROLES_FILEDS.m1]))
			roleTempModel.Privileges = roleAPIModel[CONST_ROLES_FILEDS.m1];
		else if (!isNaN(roleAPIModel[CONST_ROLES_FILEDS.m2]))
			roleTempModel.Privileges = roleAPIModel[CONST_ROLES_FILEDS.m2];

		return roleTempModel;
	}

	var returnRoleUIModel = function (roleAPIModel) {
		return getRoleUIModel(roleAPIModel);
	}

	function getRoleUIModelWithAllInfo(roleAPIModel) {
		var roleTempModel = angular.copy(rolesDBModelInitialValueSettings);

		roleTempModel.RoleName = roleAPIModel[CONST_ROLES_FILEDS.RoleName];
		roleTempModel.Description = roleAPIModel[CONST_ROLES_FILEDS.Description];
		roleTempModel.IsExternal = roleAPIModel[CONST_ROLES_FILEDS.IsExternal];
		roleTempModel.Privileges = '';

		if (!isNaN(roleAPIModel[CONST_ROLES_FILEDS.m1]) && !isNaN(roleAPIModel[CONST_ROLES_FILEDS.m2]))
			roleTempModel.Privileges = roleAPIModel[CONST_ROLES_FILEDS.m1] + roleAPIModel[CONST_ROLES_FILEDS.m2];
		else if (!isNaN(roleAPIModel[CONST_ROLES_FILEDS.m1]))
			roleTempModel.Privileges = roleAPIModel[CONST_ROLES_FILEDS.m1];
		else if (!isNaN(roleAPIModel[CONST_ROLES_FILEDS.m2]))
			roleTempModel.Privileges = roleAPIModel[CONST_ROLES_FILEDS.m2];

		fillContentFolderOperations(roleTempModel, roleAPIModel);
		fillAdministrativeOperations(roleTempModel, roleAPIModel);
		fillWebOperations(roleTempModel, roleAPIModel);
		return roleTempModel;
	}

	var returnRoleUIModelWithAllInfo = function (roleAPIModel) {
		return getRoleUIModelWithAllInfo(roleAPIModel);
	}

	function fillContentFolderOperations(roleUIModel, roleAPIModel) {
		var bitValue = roleAPIModel.m1;

		if ((bitValue & CONTENT_FOLDER_OPERATIONS.ALLOWFULLTEXTSEARCH) == CONTENT_FOLDER_OPERATIONS.ALLOWFULLTEXTSEARCH)
			roleUIModel.ContentAndFolderOperationList.push(CONTENT_FOLDER_OPERATIONS.ALLOWFULLTEXTSEARCH);

		if ((bitValue & CONTENT_FOLDER_OPERATIONS.CHECKOUTDOCUMENTS) == CONTENT_FOLDER_OPERATIONS.CHECKOUTDOCUMENTS)
			roleUIModel.ContentAndFolderOperationList.push(CONTENT_FOLDER_OPERATIONS.CHECKOUTDOCUMENTS);

		if ((bitValue & CONTENT_FOLDER_OPERATIONS.CREATEPUBLICFOLDER) == CONTENT_FOLDER_OPERATIONS.CREATEPUBLICFOLDER)
			roleUIModel.ContentAndFolderOperationList.push(CONTENT_FOLDER_OPERATIONS.CREATEPUBLICFOLDER);

		if ((bitValue & CONTENT_FOLDER_OPERATIONS.CREATEPUBLICSEARCHES) == CONTENT_FOLDER_OPERATIONS.CREATEPUBLICSEARCHES)
			roleUIModel.ContentAndFolderOperationList.push(CONTENT_FOLDER_OPERATIONS.CREATEPUBLICSEARCHES);

		if ((bitValue & CONTENT_FOLDER_OPERATIONS.DELETE) == CONTENT_FOLDER_OPERATIONS.DELETE)
			roleUIModel.ContentAndFolderOperationList.push(CONTENT_FOLDER_OPERATIONS.DELETE);

		if ((bitValue & CONTENT_FOLDER_OPERATIONS.IMPORTCREATECONTENT) == CONTENT_FOLDER_OPERATIONS.IMPORTCREATECONTENT)
			roleUIModel.ContentAndFolderOperationList.push(CONTENT_FOLDER_OPERATIONS.IMPORTCREATECONTENT);

		if ((bitValue & CONTENT_FOLDER_OPERATIONS.READONLY) == CONTENT_FOLDER_OPERATIONS.READONLY)
			roleUIModel.ContentAndFolderOperationList.push(CONTENT_FOLDER_OPERATIONS.READONLY);

		if ((bitValue & CONTENT_FOLDER_OPERATIONS.UNLOCKDOCUMENTS) == CONTENT_FOLDER_OPERATIONS.UNLOCKDOCUMENTS)
			roleUIModel.ContentAndFolderOperationList.push(CONTENT_FOLDER_OPERATIONS.UNLOCKDOCUMENTS);
	}

	function fillAdministrativeOperations(roleUIModel, roleAPIModel) {
		var bitValue = roleAPIModel.m2;

		if ((bitValue & ADMINISTRATIVE_OPERATIONS.VIEWDOCUMENTS) == ADMINISTRATIVE_OPERATIONS.VIEWDOCUMENTS)
			roleUIModel.AdministrativeOperationList.push(ADMINISTRATIVE_OPERATIONS.VIEWDOCUMENTS);

		if ((bitValue & ADMINISTRATIVE_OPERATIONS.WORKSITEADMINISTRATOR) == ADMINISTRATIVE_OPERATIONS.WORKSITEADMINISTRATOR)
			roleUIModel.AdministrativeOperationList.push(ADMINISTRATIVE_OPERATIONS.WORKSITEADMINISTRATOR);

		if ((bitValue & ADMINISTRATIVE_OPERATIONS.WORKSITEIMPORT) == ADMINISTRATIVE_OPERATIONS.WORKSITEIMPORT)
			roleUIModel.AdministrativeOperationList.push(ADMINISTRATIVE_OPERATIONS.WORKSITEIMPORT);

		if ((bitValue & ADMINISTRATIVE_OPERATIONS.WORKSITEMONITOR) == ADMINISTRATIVE_OPERATIONS.WORKSITEMONITOR)
			roleUIModel.AdministrativeOperationList.push(ADMINISTRATIVE_OPERATIONS.WORKSITEMONITOR);

		if ((bitValue & ADMINISTRATIVE_OPERATIONS.ISEXTERNAL) == ADMINISTRATIVE_OPERATIONS.ISEXTERNAL) {
			roleUIModel.AdministrativeOperationList.push(ADMINISTRATIVE_OPERATIONS.ISEXTERNAL);
			roleUIModel.IsExternal = true;
		}
	}

	function fillWebOperations(roleUIModel, roleAPIModel) {
		var bitValue = roleAPIModel.m3;

		if ((bitValue & WEB_OPERATIONS.CREATEPUBLICWORKSPACE) == WEB_OPERATIONS.CREATEPUBLICWORKSPACE)
			roleUIModel.WebOperationsList.push(WEB_OPERATIONS.CREATEPUBLICWORKSPACE);

		if ((bitValue & WEB_OPERATIONS.CREATESYSTEMWORKSPACE) == WEB_OPERATIONS.CREATESYSTEMWORKSPACE)
			roleUIModel.WebOperationsList.push(WEB_OPERATIONS.CREATESYSTEMWORKSPACE);

		if ((bitValue & WEB_OPERATIONS.CREATEWORKSPACE) == WEB_OPERATIONS.CREATEWORKSPACE)
			roleUIModel.WebOperationsList.push(WEB_OPERATIONS.CREATEWORKSPACE);

		if ((bitValue & WEB_OPERATIONS.DELETEWORKSPACE) == WEB_OPERATIONS.DELETEWORKSPACE)
			roleUIModel.WebOperationsList.push(WEB_OPERATIONS.DELETEWORKSPACE);

		if ((bitValue & WEB_OPERATIONS.SEARCHWEB) == WEB_OPERATIONS.SEARCHWEB)
			roleUIModel.WebOperationsList.push(WEB_OPERATIONS.SEARCHWEB);
	}

	function getAPIRoleModel(roleUIViewModel, dbName) {
		var roleTempAPIModel = {};

		roleTempAPIModel[CONST_ROLES_POST_FILEDS.Database] = dbName;
		roleTempAPIModel[CONST_ROLES_POST_FILEDS.RoleName] = roleUIViewModel.RoleName;
		roleTempAPIModel[CONST_ROLES_POST_FILEDS.Description] = roleUIViewModel.Description;

		roleTempAPIModel[CONST_ROLES_POST_FILEDS.nvps] = [];
		roleTempAPIModel[CONST_ROLES_POST_FILEDS.profiles] = [{
			"profile_id": "AUTHOR", 	//required
			"search_access": "W", 	//default W
			"search_value": "", 	//default Empty String
			"set_access": "W", 	//default W
			"set_value": ""		//default Empty String
		},
			{
				"profile_id": "CLASS",
				"search_access": "W",
				"search_value": "",
				"set_access": "W",
				"set_value": "DOC"
			},
			{
				"profile_id": "CUSTOM1",
				"search_access": "W",
				"search_value": "",
				"set_access": "W",
				"set_value": ""
			},
			{
				"profile_id": "CUSTOM10",
				"search_access": "W",
				"search_value": "",
				"set_access": "W",
				"set_value": ""
			},
			{
				"profile_id": "CUSTOM11",
				"search_access": "W",
				"search_value": "",
				"set_access": "W",
				"set_value": ""
			},
			{
				"profile_id": "CUSTOM12",
				"search_access": "W",
				"search_value": "",
				"set_access": "W",
				"set_value": ""
			},
			{
				"profile_id": "CUSTOM13",
				"search_access": "W",
				"search_value": "",
				"set_access": "W",
				"set_value": ""
			},
			{
				"profile_id": "CUSTOM14",
				"search_access": "W",
				"search_value": "",
				"set_access": "W",
				"set_value": ""
			},
			{
				"profile_id": "CUSTOM15",
				"search_access": "W",
				"search_value": "",
				"set_access": "W",
				"set_value": ""
			},
			{
				"profile_id": "CUSTOM16",
				"search_access": "W",
				"search_value": "",
				"set_access": "W",
				"set_value": ""
			},
			{
				"profile_id": "CUSTOM17",
				"search_access": "W",
				"search_value": "",
				"set_access": "W",
				"set_value": ""
			},
			{
				"profile_id": "CUSTOM18",
				"search_access": "W",
				"search_value": "",
				"set_access": "W",
				"set_value": ""
			},
			{
				"profile_id": "CUSTOM19",
				"search_access": "W",
				"search_value": "",
				"set_access": "W",
				"set_value": ""
			},
			{
				"profile_id": "CUSTOM2",
				"search_access": "W",
				"search_value": "",
				"set_access": "W",
				"set_value": ""
			},
			{
				"profile_id": "CUSTOM20",
				"search_access": "W",
				"search_value": "",
				"set_access": "W",
				"set_value": ""
			},
			{
				"profile_id": "CUSTOM21",
				"search_access": "W",
				"search_value": "",
				"set_access": "W",
				"set_value": ""
			},
			{
				"profile_id": "CUSTOM22",
				"search_access": "W",
				"search_value": "",
				"set_access": "W",
				"set_value": ""
			},
			{
				"profile_id": "CUSTOM23",
				"search_access": "W",
				"search_value": "",
				"set_access": "W",
				"set_value": ""
			},
			{
				"profile_id": "CUSTOM24",
				"search_access": "W",
				"search_value": "",
				"set_access": "W",
				"set_value": ""
			},
			{
				"profile_id": "CUSTOM25",
				"search_access": "W",
				"search_value": "",
				"set_access": "W",
				"set_value": ""
			},
			{
				"profile_id": "CUSTOM26",
				"search_access": "W",
				"search_value": "",
				"set_access": "W",
				"set_value": ""
			},
			{
				"profile_id": "CUSTOM27",
				"search_access": "W",
				"search_value": "",
				"set_access": "W",
				"set_value": ""
			},
			{
				"profile_id": "CUSTOM28",
				"search_access": "W",
				"search_value": "",
				"set_access": "W",
				"set_value": ""
			},
			{
				"profile_id": "CUSTOM29",
				"search_access": "W",
				"search_value": "",
				"set_access": "W",
				"set_value": ""
			},
			{
				"profile_id": "CUSTOM3",
				"search_access": "W",
				"search_value": "",
				"set_access": "W",
				"set_value": ""
			},
			{
				"profile_id": "CUSTOM30",
				"search_access": "W",
				"search_value": "",
				"set_access": "W",
				"set_value": ""
			},
			{
				"profile_id": "CUSTOM4",
				"search_access": "W",
				"search_value": "",
				"set_access": "W",
				"set_value": ""
			},
			{
				"profile_id": "CUSTOM5",
				"search_access": "W",
				"search_value": "",
				"set_access": "W",
				"set_value": ""
			},
			{
				"profile_id": "CUSTOM6",
				"search_access": "W",
				"search_value": "",
				"set_access": "W",
				"set_value": ""
			},
			{
				"profile_id": "CUSTOM7",
				"search_access": "W",
				"search_value": "",
				"set_access": "W",
				"set_value": ""
			},
			{
				"profile_id": "CUSTOM8",
				"search_access": "W",
				"search_value": "",
				"set_access": "W",
				"set_value": ""
			},
			{
				"profile_id": "CUSTOM9",
				"search_access": "W",
				"search_value": "",
				"set_access": "W",
				"set_value": ""
			},
			{
				"profile_id": "Document Number",
				"search_access": "W",
				"search_value": "",
				"set_access": "W",
				"set_value": ""
			},
			{
				"profile_id": "OPERATOR",
				"search_access": "W",
				"search_value": "",
				"set_access": "W",
				"set_value": ""
			},
			{
				"profile_id": "SUBCLASS",
				"search_access": "W",
				"search_value": "",
				"set_access": "W",
				"set_value": ""
			},
			{
				"profile_id": "TYPE",
				"search_access": "W",
				"search_value": "",
				"set_access": "W",
				"set_value": ""
			},
			{
				"profile_id": "VERSION",
				"search_access": "W",
				"search_value": "",
				"set_access": "W",
				"set_value": ""
			}
		];

		var m1Value = 0, m2Value = 0, m3Value = 0;

		angular.forEach(roleUIViewModel.ContentAndFolderOperationList, function (itemTagValue) {
			if (!isNaN(itemTagValue)) {
				m1Value = m1Value | itemTagValue;
			}
		});
		if (!roleUIViewModel.IsExternal) {
			angular.forEach(roleUIViewModel.AdministrativeOperationList, function (itemTagValue) {
				if (!isNaN(itemTagValue)) {
					m2Value = m2Value | itemTagValue;
				}
			});
		} else {
			m2Value = m2Value | 16;
		}

		angular.forEach(roleUIViewModel.WebOperationsList, function (itemTagValue) {
			if (!isNaN(itemTagValue)) {
				m3Value = m3Value | itemTagValue;
			}
		});

		roleTempAPIModel[CONST_ROLES_POST_FILEDS.m1] = m1Value;
		roleTempAPIModel[CONST_ROLES_POST_FILEDS.m2] = m2Value;
		roleTempAPIModel[CONST_ROLES_POST_FILEDS.m3] = m3Value;

		return roleTempAPIModel;
	}

	var returnRoleAPIModel = function (roleUIViewModel, dbName) {
		return getAPIRoleModel(roleUIViewModel, dbName);
	}

	var returnPOSTAPIUrl = function () {
		var apiURL = baseUrl + WRSU_ROLES['POST_ROLE'];
		return apiURL;
	}

	var returnPUTAPIUrl = function (alias) {
		var apiURL = baseUrl + WRSU_ROLES['PUT_ROLE'];
		apiURL = apiURL.replace("{ALIAS}", alias);
		return apiURL;
	}

	var returnGetSingleRoleUrl = function (dbName, roleName) {
		var apiURL = baseUrl + WRSU_ROLES['GET_ROLE'];
		apiURL += '?database=' + dbName + '&alias=' + roleName;
		return apiURL;
	}

	var returnGetUsersInRoleUrl = function (requestModel, roleName) {
		var apiURL = baseUrl + WRSU_ROLES['GET_USERSINROLE'];
		apiURL += '/' + roleName + '/users?database=' + requestModel.libraryName;
		apiURL += '&offset=' + (requestModel.pagenumber - 1) * requestModel.pageLength;
		apiURL += '&limit=' + requestModel.pageLength;
		apiURL += '&total=' + requestModel.isTotal;

		if (requestModel.searchText != null && requestModel.searchText != '')
			apiURL += '&alias=*' + requestModel.searchText + '*'

		return apiURL;
	}

	var prepareAddRoleUserUrl = function (roleName, userId, dbName) {
		var apiURL = baseUrl + WRSU_ROLES['POST_ROLE'];
		apiURL += '/' + roleName + '/users/' + userId + '?database=' + dbName;
		return apiURL;
	}

	var prepareRemoveRoleUserUrl = function (roleName, userId, dbName) {
		var apiURL = baseUrl + WRSU_ROLES['POST_ROLE'];
		apiURL += '/' + roleName + '/users/' + userId + '?database=' + dbName;
		return apiURL;
	}

	return {
		rolesInitialValues: returnRolesInitialValueSettings,
		dbRoleModelInitialValues: returnrolesDBModelInitialValueSettings,
		roleProfileModelInitialValues: returnRoleProfileModel,
		searchAPIUrl: returnSearchAPIUrl,
		getUIModel: returnRoleUIModel,
		getUIModelWithAllInfo: returnRoleUIModelWithAllInfo,
		getAPIModel: returnRoleAPIModel,
		postAPIUrl: returnPOSTAPIUrl,
		putAPIUrl: returnPUTAPIUrl,
		getSingleRoleAPIUrl: returnGetSingleRoleUrl,
		getUsersInRoleUrl: returnGetUsersInRoleUrl,
		getAddRoleUserUrl: prepareAddRoleUserUrl,
		getRemoveRoleUserUrl: prepareRemoveRoleUserUrl
	}
}