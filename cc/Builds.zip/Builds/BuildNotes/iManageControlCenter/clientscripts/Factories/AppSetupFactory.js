﻿app.factory('appSetupFactory', appSetupFactory);
appSetupFactory.$inject = ['WRSU_APPSETUP', 'CONST_APPSETUP'];
function appSetupFactory(WRSU_APPSETUP, CONST_APPSETUP) {

    var appSetupUIModel = {
        Name: '',
        Type: '',
        Primary: '',
        Location: '',
        DDE: false,
        IntegrationMode: '',
        DDEAppName: '',
        DDETopic: '',
        DDEOpen: '',
        DDEReadOpen: '',
        DDEPrintandExitApp: '',
        DDEPRint: '',
        IntegrationModeText:''
    };

    var returnAppSetupUIModel = function getAppSetupUIModel(appSetupApiModel) {
        var appSetupModel = angular.copy(appSetupUIModel);
        appSetupModel.Name = appSetupApiModel[CONST_APPSETUP.Name];
        appSetupModel.Type = appSetupApiModel[CONST_APPSETUP.Type];
        appSetupModel.Primary = appSetupApiModel[CONST_APPSETUP.Primary];
        appSetupModel.Location = appSetupApiModel[CONST_APPSETUP.Location];
        appSetupModel.DDE = appSetupApiModel[CONST_APPSETUP.DDE];
        appSetupModel.IntegrationMode = appSetupApiModel[CONST_APPSETUP.IntegrationMode];
        appSetupModel.DDEAppName = appSetupApiModel[CONST_APPSETUP.DDEAppName];
        appSetupModel.DDETopic = appSetupApiModel[CONST_APPSETUP.DDETopic];
        appSetupModel.DDEOpen = appSetupApiModel[CONST_APPSETUP.DDEOpen];
        appSetupModel.DDEReadOpen = appSetupApiModel[CONST_APPSETUP.DDEReadOpen];
        appSetupModel.DDEPrintandExitApp = appSetupApiModel[CONST_APPSETUP.DDEPrintandExitApp];
        appSetupModel.DDEPRint = appSetupApiModel[CONST_APPSETUP.DDEPRint];
        
        if (appSetupApiModel[CONST_APPSETUP.IntegrationMode]=='N')        	{
        	 appSetupModel.IntegrationModeText='COM-Integrated' 
        	}
        else if (appSetupApiModel[CONST_APPSETUP.IntegrationMode]=='T')        	{
       	 appSetupModel.IntegrationModeText='Non-Integrated' 
       	}
        else if (appSetupApiModel[CONST_APPSETUP.IntegrationMode]=='Y')        	{
          	 appSetupModel.IntegrationModeText='ODMA' 
          	}        	 
        return appSetupModel;
    };

    var returnAppSetupAPIModel = function (appSetupUIModel, dbName) {
        var appSetupApiModel = {};

        appSetupApiModel[CONST_APPSETUP.Name] = appSetupUIModel.Name;
        appSetupApiModel[CONST_APPSETUP.Type] = appSetupUIModel.Type;
        appSetupApiModel[CONST_APPSETUP.Primary] = appSetupUIModel.Primary;
        appSetupApiModel[CONST_APPSETUP.Location] = appSetupUIModel.Location;
        appSetupApiModel[CONST_APPSETUP.DDE] = appSetupUIModel.DDE;
        appSetupApiModel[CONST_APPSETUP.IntegrationMode] = appSetupUIModel.IntegrationMode;
        appSetupApiModel[CONST_APPSETUP.DDEAppName] = appSetupUIModel.DDEAppName;
        appSetupApiModel[CONST_APPSETUP.DDETopic] = appSetupUIModel.DDETopic;
        appSetupApiModel[CONST_APPSETUP.DDEOpen] = appSetupUIModel.DDEOpen;
        appSetupApiModel[CONST_APPSETUP.DDEReadOpen] = appSetupUIModel.DDEReadOpen;
        appSetupApiModel[CONST_APPSETUP.DDEPrintandExitApp] = appSetupUIModel.DDEPrintandExitApp;
        appSetupApiModel[CONST_APPSETUP.DDEPRint] = appSetupUIModel.DDEPRint;
        appSetupApiModel[CONST_APPSETUP.DataBase] = dbName;

        return appSetupApiModel;
    };

    var returnAPIUrl = function (APIFOR, requestModel) {
        var apiUrl = baseUrl + WRSU_APPSETUP[APIFOR];

        if (APIFOR === 'GETAPPS') {
            apiUrl = apiUrl + '?database=' + requestModel.libraryName + '&offset=' + ((requestModel.pagenumber-1)*requestModel.pageLength) + '&limit=' + requestModel.pageLength
                + '&total=' + requestModel.isTotal;
            if(requestModel.searchText!=null && requestModel.searchText!='')
            		apiUrl+='&query=*'+requestModel.searchText+'*'         
            if (requestModel.filters.length > 0) {
         	   angular.forEach(requestModel.filters, function (filterItem) {
     				if(filterItem.FilterValues[0]!=null && filterItem.FilterValues[0]!=''){
     					if(filterItem.FilterKey=='Primary' || filterItem.FilterKey=='DDE')//|| filterItem.FilterKey=='IntegrationMode'
     					{
     						apiUrl+='&'+CONST_APPSETUP[filterItem.FilterKey+'Filter']+'='+(filterItem.FilterValues[0]=="Y"?'true':'false');
     	  					
     						
     					}else
     					{
     						apiUrl+='&'+CONST_APPSETUP[filterItem.FilterKey+'Filter']+'=*'+filterItem.FilterValues[0]+'*'
     		  						
     					} 
     				}
     	          });			 
     		}
        }else  if (APIFOR === 'PUTAPI') {
            apiUrl =  apiUrl.replace('{ALIAS}',requestModel.Type)
         		 
 		}
    

        return apiUrl;
    };

    var returnAppSetUpInitialValueSettings = function () {
        return angular.copy(appSetupUIModel);
    };

    return {
        getAPIUrl: returnAPIUrl,
        getAppSetupUIModel: returnAppSetupUIModel,
        AppSetupInitialValues: returnAppSetUpInitialValueSettings,
        getAppSetupAPIPostModel: returnAppSetupAPIModel
    }
}