﻿app.factory('metaDataFactory', metaDataFactory);
metaDataFactory.$inject = ['WRSU_METADATA','CONST_METADATA'];
function metaDataFactory(WRSU_METADATA,CONST_METADATA) {

    var metaDataUIModel = {
        Alias :'',
        Description:'',
        HIPAAComplaint :false,
        EnableFlag :true,
        ParentAlias:'',
        GrandParentAlias: '',
        ShowEditButton:false
    }

    function getMetaDataUIModel(metaDataApiModel)
    {
    	var metaModel=angular.copy(metaDataUIModel);   
    	metaModel.Alias= metaDataApiModel[CONST_METADATA.Alias];//.user_id_ex;
    	metaModel.Description=metaDataApiModel[CONST_METADATA.Description];
    	metaModel.HIPAAComplaint= metaDataApiModel[CONST_METADATA.HIPAAComplaint];
    	metaModel.EnableFlag= metaDataApiModel[CONST_METADATA.EnableFlag];
    	//metaModel.ParentAlias= metaDataApiModel[CONST_METADATA.ParentAlias];
    	//metaModel.GrandParentAlias= metaDataApiModel[CONST_METADATA.GrandParentAlias];
    	//metaModel.ShowEditButton= userApiModel[CONST_USERS.Email];
    	 
    	return metaModel;   
    	
    }
  
    var returnAPIUrl=function(APIFOR,modelObject)
    {
        var ApiUrl = baseUrl + WRSU_METADATA[APIFOR]
    	if(modelObject!=null)
    	{
    		ApiUrl=prepareUrl(ApiUrl,modelObject,APIFOR);
    		
    	}
    	return ApiUrl;
    	
    }
    
    function prepareUrl(URL,requestmodel,APIFOR)
    {
    	var ApiUrl=URL;
    	switch(APIFOR)
    	{
    	case 'POSTMETADATA':
    		ApiUrl=	ApiUrl.replace("{CUSTOMTYPE}", requestmodel.MetaType.toLowerCase());
    		break;
    	case 'PUTMETADATA': 
    		ApiUrl=	ApiUrl.replace("{CUSTOMTYPE}", requestmodel.MetaType.toLowerCase());
    		break;
    	case 'DELETEMETADATA': 
    		ApiUrl=	ApiUrl.replace("{CUSTOMTYPE}", requestmodel.MetaType.toLowerCase());
    		ApiUrl+="?"+CONST_METADATA.DataBase+"="+requestmodel.libraryName+'&'+CONST_METADATA.AliasQuery+'='+requestmodel.Alias;
    		if(requestmodel.parentAlias!='' && requestmodel.parentAlias)
        	{
    			ApiUrl+='&'+CONST_METADATA.ParentAliasQuery+'='+requestmodel.parentAlias;
        	}
    		break;
    	case 'SEARCHMETADATA':
    		ApiUrl=	ApiUrl.replace("{CUSTOMTYPE}", requestmodel.MetaType.toLowerCase()); 
    		ApiUrl+="?"+CONST_METADATA.DataBase+"="+requestmodel.libraryName+'&offset='+((requestmodel.pagenumber-1)*requestmodel.pageLength)+'&limit='+requestmodel.pageLength+'&total='+requestmodel.isTotal;
             if(requestmodel.searchText!=null && requestmodel.searchText!='')
             ApiUrl+='&query=*'+requestmodel.searchText+'*'         
             if (requestmodel.filters.length > 0) {
          	   angular.forEach(requestmodel.filters, function (filterItem) {
      				if(filterItem.FilterValues[0]!=null && filterItem.FilterValues[0]!=''){
      					if(filterItem.FilterKey=='HIPAAComplaint' || filterItem.FilterKey=='EnableFlag')
      					{
      						ApiUrl+='&'+CONST_METADATA[filterItem.FilterKey+'Filter']+'='+(filterItem.FilterValues[0]=="Y"?'true':'false');
     	  							
      					}else
      					{
      						ApiUrl+='&'+CONST_METADATA[filterItem.FilterKey+'Filter']+'=*'+filterItem.FilterValues[0]+'*'
      		  			} 
      				}
      	          });			 
      		}
             break;
    	case 'SEARCHCHILDMETADATA':      
    		ApiUrl=	ApiUrl.replace("{CUSTOMTYPE}", requestmodel.MetaType.toLowerCase()); 
    		ApiUrl=	ApiUrl.replace("{PALIAS}", requestmodel.parentAlias); 
    		ApiUrl=	ApiUrl.replace("{CHILDCUSTOM}", requestmodel.subType.toLowerCase()); 
    		ApiUrl+="?"+CONST_METADATA.DataBase+"="+requestmodel.libraryName+'&offset='+((requestmodel.pagenumber-1)*requestmodel.pageLength)+'&limit='+requestmodel.pageLength+'&total='+requestmodel.isTotal;
             if(requestmodel.searchText!=null && requestmodel.searchText!='')
             ApiUrl+='&query=*'+requestmodel.searchText+'*'         
             if (requestmodel.filters.length > 0) {
          	   angular.forEach(requestmodel.filters, function (filterItem) {
      				if(filterItem.FilterValues[0]!=null && filterItem.FilterValues[0]!=''){
      					if(filterItem.FilterKey=='HIPAAComplaint' || filterItem.FilterKey=='EnableFlag')
      					{
      						ApiUrl+='&'+CONST_METADATA[filterItem.FilterKey+'Filter']+'='+(filterItem.FilterValues[0]=="Y"?'true':'false');
     	  							
      					}else
      					{
      						ApiUrl+='&'+CONST_METADATA[filterItem.FilterKey+'Filter']+'=*'+filterItem.FilterValues[0]+'*'
      		  			} 
      				}
      	          });			 
      		}
             break;
    	    case 'GETMETADATAEXIST':
    	        ApiUrl = ApiUrl.replace("{CUSTOMTYPE}", requestmodel.MetaType.toLowerCase());
    	        ApiUrl += "?" + CONST_METADATA.AliasQuery + '=' + requestmodel.Alias + "&database=" + requestmodel.libraryName;
    	        break;
    		
    	}
    	
         return ApiUrl;
    }

    var returnMetaUIModel=function(metaApiModel)
    {
    	return getMetaDataUIModel(metaApiModel);
    	
    }
    
    var returnMetaAPIPOSTModel=function(metaUIModel,dbName)
    {
    	return getMetaAPIPOSTModel(metaUIModel,dbName);
    	
    }
    
    var returnMetaAPIPUTModel=function(metaUIModel,dbName)
    {
    	return getMetaAPIPUTModel(metaUIModel,dbName);
    	
    }
    
    function getMetaAPIPOSTModel(metaUIModel,dbName)
    {
    	var metaDataApiModel={};
    	metaDataApiModel[CONST_METADATA.Alias]=metaUIModel.Alias;
    	metaDataApiModel[CONST_METADATA.Description]=metaUIModel.Description;
    	metaDataApiModel[CONST_METADATA.HIPAAComplaint]=metaUIModel.HIPAAComplaint;
    	metaDataApiModel[CONST_METADATA.EnableFlag]=metaUIModel.EnableFlag;
      	metaDataApiModel[CONST_METADATA.MetaType]=metaUIModel.MetaType.toLowerCase();
    	metaDataApiModel[CONST_METADATA.DataBase]=dbName;
    	if(metaUIModel.ParentAlias)
    	{
    		if(metaUIModel.ParentAlias!='')
        	{
    			metaDataApiModel[CONST_METADATA.ParentAlias]={};
    			metaDataApiModel[CONST_METADATA.ParentAlias][CONST_METADATA.Alias]=metaUIModel.ParentAlias;
        	}
    	}
    	return metaDataApiModel;   
    	
    }
  
    
    function getMetaAPIPUTModel(metaUIModel,dbName)
    {
    	var metaDataApiModel={};
    	metaDataApiModel[CONST_METADATA.Alias]=metaUIModel.Alias;
    	metaDataApiModel[CONST_METADATA.Description]=metaUIModel.Description;
    	metaDataApiModel[CONST_METADATA.HIPAAComplaint]=metaUIModel.HIPAAComplaint;
    	metaDataApiModel[CONST_METADATA.EnableFlag]=metaUIModel.EnableFlag;
      	metaDataApiModel[CONST_METADATA.MetaType]=metaUIModel.MetaType.toLowerCase();
    	metaDataApiModel[CONST_METADATA.DataBase]=dbName;
    	if(metaUIModel.ParentAlias)
    	{
    		if(metaUIModel.ParentAlias!='')
        	{
    			metaDataApiModel[CONST_METADATA.ParentAlias]={};
    			metaDataApiModel[CONST_METADATA.ParentAlias][CONST_METADATA.Alias]=metaUIModel.ParentAlias;
        	}
    	}
    	return metaDataApiModel;   
    	
    }
  
    var returnMetaDataInitialValueSettings = function () {
        return angular.copy(metaDataUIModel);
    }

    var validationSettings = {
        showMessage: false,
        showInformationMessage: false,
        serverResponse: false
    };

    var returnMetaDataValidationSettings = function () {
        return angular.copy(validationSettings);
    }

    return {
        meatDataInitialValues: returnMetaDataInitialValueSettings,
        getAPIUrl: returnAPIUrl,
        getMetaDataUI: returnMetaUIModel,
        getMetaAPIModel: returnMetaAPIPOSTModel,
        getMetaAPIPUTModel: returnMetaAPIPUTModel,
       // getSubItemDeleteApiUrl: returnSubDeleteAPIUrl,
        validations: returnMetaDataValidationSettings
    }
}