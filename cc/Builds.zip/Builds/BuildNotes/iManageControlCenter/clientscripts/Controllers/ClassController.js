﻿app.controller("ClassController", ClassController);
ClassController.$inject = ['$scope', '$rootScope', '$timeout', 'ClassService', 'classFactory', '$filter', '$mdDialog', '$mdMedia', 'homeFactory', 'CONST_CLASS', '$q'];

function ClassController($scope, $rootScope, $timeout, ClassService, classFactory, $filter, $mdDialog, $mdMedia, homeFactory, CONST_CLASS, $q) {

    var requestModel = homeFactory.requestModelInstance();
    var FilterSearchTimeout;
    var selectedRowIndex = -1;
    var SelectedClassListForFilter = [];
    var LastAddedSelectedItemClass = [];
    var lastAppendClassItemCount = 0;
    var noDataExist = false;

    $scope.ClassList = [];
    $scope.selected = [];
    $scope.ClassModel = classFactory.classInitailValues();
    $scope.generalSettings = classFactory.generalSettings;
    $scope.validation = classFactory.validations();
    $scope.IsSubClassVisible = false;
    $scope.posting = false;

    $scope.query = {
        order: 'name',
        limit: requestModel.pageLength,
        page: requestModel.pagenumber,
        totalCount: 0
    };

    $scope.ClassListPagination = {
        limit: requestModel.pageLength,
        page: requestModel.pagenumber,
        totalCount: 0
    };

    var metadataModel = {
        ValueText: '',
        DisplayText: '',
        IsSelected: false,
        ShowInPopup: true,
        DependantItemId: '',
        oneDisable: true,
        TagValue: 0
    }
    //angular.forEach($scope.metaDataListForPopup, function (metadata) {
    //    metadata.IsSelected = false;
    //});
    $scope.metaDataListForPopup = [];
    $scope.SubClassMetaDataList = [];
    $scope.IsShowRequiredField = false;

    var metaDataListFor = $filter('filter')($scope.appsVar.CaptionsList, { isMetaItem: true });
    angular.forEach(metaDataListFor, function (metadata) {
        metadataModel.TagValue = getCustomTagValue(metadata);
        metadataModel.ValueText = metadata.MetaDataItem;
        metadataModel.DisplayText = metadata.DisplayText;
        metadataModel.IsSelected = false;
        metadataModel.ShowInPopup = metadata.MetaDataItem != 'CLASS' && metadata.MetaDataItem != 'SUBCLASS';
        if (metadata.MetaDataItem === 'CUSTOM2') {
            metadataModel.DependantItemId = 'CUSTOM1';
            metadataModel.oneDisable = true;
        } else if (metadata.MetaDataItem === 'CUSTOM30') {
            metadataModel.DependantItemId = 'CUSTOM29';
            metadataModel.oneDisable = true;
        } else {
            metadataModel.DependantItemId = '';
            metadataModel.oneDisable = false;
        }
        $scope.metaDataListForPopup.push(angular.copy(metadataModel));
        $scope.SubClassMetaDataList.push(angular.copy(metadataModel));
    });

    function getCustomTagValue(customData) {
        var tagValue = 0;
        switch (customData.MetaDataItem) {
            case "CUSTOM1":
                tagValue = 2;
                break;

            case "CUSTOM2":
                tagValue = 1;
                break;

            case "CUSTOM3":
                tagValue = 4;
                break;

            case "CUSTOM4":
                tagValue = 8;
                break;

            case "CUSTOM5":
                tagValue = 16;
                break;

            case "CUSTOM6":
                tagValue = 32;
                break;

            case "CUSTOM7":
                tagValue = 64;
                break;

            case "CUSTOM8":
                tagValue = 128;
                break;

            case "CUSTOM9":
                tagValue = 256;
                break;

            case "CUSTOM10":
                tagValue = 512;
                break;

            case "CUSTOM11":
                tagValue = 1024;
                break;

            case "CUSTOM12":
                tagValue = 2048;
                break;

            case "CUSTOM29":
                tagValue = 4096;
                break;

            case "CUSTOM30":
                tagValue = 8192;
                break;
            default:
                tagValue = 0;
        }
        return tagValue;
    }

    $scope.EnableCheckbox = function (metaData) {
        if (metaData.ValueText == 'CUSTOM1') {
            var selectedMetaDataItem = $filter('filter')($scope.metaDataListForPopup, { ValueText: 'CUSTOM2' });
            selectedMetaDataItem[0].DependantItemId = 'CUSTOM1';
            selectedMetaDataItem[0].oneDisable = !metaData.IsSelected;
            if (metaData.IsSelected == false) {
                selectedMetaDataItem[0].IsSelected = false;
            }
        }
        else if (metaData.ValueText == 'CUSTOM29') {
            var selectedMetaDataItem = $filter('filter')($scope.metaDataListForPopup, { ValueText: 'CUSTOM30' });
            selectedMetaDataItem[0].DependantItemId = 'CUSTOM29';
            selectedMetaDataItem[0].oneDisable = !metaData.IsSelected;
            if (metaData.IsSelected == false) {
                selectedMetaDataItem[0].IsSelected = false;
            }
        }
    }


    $scope.ContextMenuFunctions = {
        Edit: function () { $scope.PageEvents.Edit(); },
        Delete: function () { $scope.PageEvents.Delete(); },
        DisplaySubClassList: function () { $scope.PageEvents.ShowSubclassList(); }
    };

    $scope.FilterOptions = {
        Security: [{ 'DisplayText': 'Private', 'ValueText': 'Private' }, { 'DisplayText': 'Public', 'ValueText': 'Public' }, { 'DisplayText': 'View', 'ValueText': 'View' }]
    }

    $scope.$on('Window_Scrolled', function () {
        if (!$scope.showSelectedClassDetails) {
            if ($scope.query.totalCount > $scope.ClassList.length) {
                requestModel.pagenumber += 1;
                fillClassList();
            }
        }
        else {
            if ($scope.ClassView.totalCount > $scope.ClassView.SubClassList.length) {
                subClassRequestModel.pagenumber += 1;
                fillSubClassInView();
            }
        }
    });

    $timeout(function () {
        $(window).scrollTop(0);
    });

    function setContextMenuObject() {
        $scope.menuList = [

		//{
		//	Label: 'Delete',
		//	Icon: 'icon-delete',
		//	onClick: $scope.ContextMenuFunctions.Delete,
		//	Enable: $scope.selected.length > 0,
		//	IconType: 'font-icon'
		//}

        ];
    };

    $scope.applyFilter = function (key, ctrlId) {
        var filterValue = $('#' + ctrlId).val().trim();

        if (requestModel.filters.length > 0) {
            requestModel.filters = jQuery.grep(requestModel.filters, function (filterItem) {
                return filterItem.FilterKey !== key;
            });
        }
        if (filterValue.length == 0) return;

        var filterValueList = [];
        filterValueList[0] = filterValue;

        var filterItem = { 'FilterKey': key, 'FilterValues': filterValueList };
        requestModel.filters.push(filterItem);

        Initalize();
    };

    function fillClassList() {
        requestModel.libraryName = $scope.vm.selectedLibrary;
        requestModel.searchText = $scope.appsVar.SearchText;
        $scope.ClassListPagination.totalCount = 0;
        $scope.query.totalCount = 0;

        if (isSearch) {
            //$scope.showSearchProgress = true;
            showProgressDialog();
        }

        var apiUrl = classFactory.getAPIUrl('SEARCHCLASS', requestModel);
        $scope.mc.getlogDetails("Debug", 'Method:GET;URL' + JSON.stringify(apiUrl));
        var promiseClass = ClassService.getClasses(apiUrl, $scope.mc.loginModel.AuthKey);
        promiseClass.then(function (response) {
            $scope.appsVar.initialLoading = false;
            if (response.data && response.status === 200) {
                $scope.mc.getlogDetails("Debug", "Class list fetched");
                $scope.ClassListPagination.totalCount = response.data[CONST_CLASS.TotalCount];

                if (lastAppendClassItemCount > 0) {
                    $scope.ClassList.splice($scope.ClassList.length - lastAppendClassItemCount, lastAppendClassItemCount);
                    $scope.selected.splice($scope.selected.length - lastAppendClassItemCount, lastAppendClassItemCount);
                    lastAppendClassItemCount = 0;
                }
                $scope.query.totalCount = response.data[CONST_CLASS.TotalCount];

                var classUIModel;
                var filterTempModel;
                var tempListFilter = [];

                angular.forEach(response.data[CONST_CLASS.ClassList], function (classApiModel) {
                    classUIModel = classFactory.getClassUI(classApiModel)
                    if (SelectedClassListForFilter.length === 0) {
                        $scope.ClassList.push(classUIModel);
                    }
                    else {
                        tempListFilter = $filter('filter')(SelectedClassListForFilter, {
                            Alias: classUIModel.Alias
                        }, true);
                        if (tempListFilter.length === 0) {
                            $scope.ClassList.push(classUIModel);
                        }
                        else {
                            LastAddedSelectedItemClass = $.grep(LastAddedSelectedItemClass,
							   function (item, index) {
							       return item.Alias != classUIModel.Alias;
							   });

                            tempListFilter[0].Description = classUIModel.Description;
                            tempListFilter[0].Echo = classUIModel.Echo;
                            tempListFilter[0].RetainDays = classUIModel.RetainDays;
                            tempListFilter[0].FieldRequired = classUIModel.FieldRequired;
                            tempListFilter[0].Security = classUIModel.Security;
                            tempListFilter[0].SubclassRequired = classUIModel.SubclassRequired;
                            tempListFilter[0].HIPAACompliant = classUIModel.HIPAACompliant;

                            filterTempModel = angular.copy(tempListFilter[0]);
                            $scope.ClassList.push(filterTempModel);
                            $scope.selected.push(filterTempModel);
                            filterTempModel = null;
                        }
                        tempListFilter = [];
                    }
                    classUIModel = null;
                });
                lastAppendClassItemCount = 0;
                if ($scope.appsVar.SearchText.length === 0 && !isValidFilterFind()) {
                    angular.forEach(LastAddedSelectedItemClass, function (classModel) {
                        filterTempModel = angular.copy(classModel);
                        $scope.ClassList.push(filterTempModel);
                        $scope.selected.push(filterTempModel);
                        filterTempModel = null;
                        lastAppendClassItemCount += 1;
                    });
                }
                if ($scope.selected.length > 0) {
                    setContextMenuObject();
                }
            } else {
                $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
            }
            var subClassDisplayText = $filter('filter')($scope.appsVar.CaptionsList, { MetaDataItem: 'SUBCLASS' });
            if (typeof subClassDisplayText !== 'undefined' && subClassDisplayText.length > 0) {
                $scope.appsVar.tooltipValue = subClassDisplayText[0].DisplayText;
            } else {
                var waitTillGetAppsVar = $scope.$watch(function () { return $scope.appsVar.CaptionsList }, function () {
                    var subClassDisplayText = $filter('filter')($scope.appsVar.CaptionsList, { MetaDataItem: 'SUBCLASS' });
                    if (typeof subClassDisplayText !== 'undefined' && subClassDisplayText.length > 0) {
                        $scope.appsVar.tooltipValue = subClassDisplayText[0].DisplayText;
                        waitTillGetAppsVar();
                    }
                });
            }
            if (isSearch) $mdDialog.hide();
            $scope.showSearchProgress = false;
        }, function (response) {
            $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
            $mdDialog.show(
					$mdDialog.alert()
					.parent(angular.element(document.body))
					.clickOutsideToClose(true)
					.title('Warning!')
					.textContent('Failed to retrive Classes.')
					.ariaLabel('Warning!')
					.ok('OK')
			);
            if (isSearch) $mdDialog.hide();
            $scope.showSearchProgress = false;
        });
    }


    var isSearch = false;

    $scope.$on('Search_Click', function () {
        search_Click();
    });

    function search_Click() {
        lastAppendClassItemCount = 0;
        LastAddedSelectedItemClass = angular.copy(SelectedClassListForFilter);
        $scope.selected = [];
        $scope.ClassList = [];
        isSearch = true;
        requestModel.pagenumber = 1;
        Initalize();
    }

    $scope.$on('onTableSorting', function (object, sortFiled) {
        requestModel.pagenumber = 1;
        Initalize();
    });

    $scope.SelectCurrentRow = function (classModel, $event) {
        if ($event.ctrlKey) {
            classModel.selected ? classModel.selected = false : classModel.selected = true;
            $scope.PageEvents.Delete = ClassDeleteFunction;
            $scope.PageEvents.Edit = undefined;
        }
        else {
            this.getAllSelectedRows($scope.ClassList, classModel);
            $scope.PageEvents.Delete = ClassDeleteFunction;
            $scope.PageEvents.Edit = ClassEditFunction;
        }
        var selectedUserList = $scope.selected;
        if (selectedUserList.length == 0) {
            $('#card-more-button').attr('disabled', 'disabled')
        } else {
            $('#card-more-button').removeAttr('disabled')
        }
    };

    function Initalize() {
        $scope.ClassListPagination.page = 1;
        requestModel.pagenumber = 1;
        $scope.query.totalCount = 0;
        $scope.query.page = 1;
        fillClassList();
    }
    var destroybroadCast;
    RegisterInitializeTabContents();
    $scope.$on('RegisterInitializeTabContents', function () {
        if (angular.isFunction(destroybroadCast))
            destroybroadCast();

        RegisterInitializeTabContents();
    });

    function RegisterInitializeTabContents() {
        var destroybroadCast = $scope.$on('InitializeTabContents', function () {

            if ($scope.vm.selectedApp.NoAppsPermission.trim().length > 0)
                return;
            if (!$scope.vm.selectedLibrary || $scope.vm.selectedLibrary.trim().length == 0)
                return;

            requestModel = homeFactory.requestModelInstance();
            FilterSearchTimeout = null;
            selectedRowIndex = -1;
            lastAppendClassItemCount = 0;
            noDataExist = false;

            $scope.ClassList = [];
            $scope.selected = [];
            SelectedClassListForFilter = [];
            LastAddedSelectedItemClass = [];

            $scope.ClassModel = classFactory.classInitailValues();
            $scope.generalSettings = classFactory.generalSettings;
            $scope.validation = classFactory.validations();
            $scope.IsSubClassVisible = false;
            $scope.posting = false;
            $scope.showSelectedClassDetails = false;

            Initalize();
            destroybroadCast();
        });
    }

    $scope.$on('$destroy', function () {
        $scope.PageEvents.Add = 'undefined';
        $scope.PageEvents.Edit = 'undefined';
        $scope.PageEvents.Save = 'undefined';
        $scope.PageEvents.Delete = 'undefined';
        $scope.PageEvents.CancelDialog = 'undefined';
        $scope.PageEvents.ShowSubclassList = 'undefined';
        $scope.PageEvents.AddRole = 'undefined';
        $scope.PageEvents.ResetPasswordclicked = 'undefined';
        $scope.PageEvents.ViewAssignUser = 'undefined';
        $scope.PageEvents.AssignUser = 'undefined';
        $scope.PageEvents.AssignGroup = 'undefined';
        $scope.PageEvents.ViewSelected = 'undefined';
        $scope.PageEvents.ShowOnlySelected = 'undefined';
    });


    $scope.onSelectClassRow = function (classModel) {
        setContextMenuObject();

        var tempListFilter = $filter('filter')(SelectedClassListForFilter, {
            Alias: classModel.Alias
        }, true);
        if (tempListFilter.length === 0) {
            SelectedClassListForFilter.push(angular.copy(classModel));
        }
        tempListFilter = [];

    };

    $scope.onDeselectClassRow = function (classModel) {
        setContextMenuObject();

        if (SelectedClassListForFilter.length > 0) {
            SelectedClassListForFilter = $.grep(SelectedClassListForFilter,
								function (item, index) {
								    return item.Alias != classModel.Alias;
								});
        }
        if (SelectedClassListForFilter.length > 0) {
            LastAddedSelectedItemClass = $.grep(LastAddedSelectedItemClass,
								   function (item, index) {
								       return item.Alias != classModel.Alias;
								   });
        }
    };

    $scope.onTableFilter = function (value, key, isInstantFilter, disablePerformFilter) {
        if (requestModel.filters.length > 0) {
            requestModel.filters = jQuery.grep(requestModel.filters, function (filterItem) {
                return filterItem.FilterKey !== key;
            });
        }
        var filterValueList = [];
        filterValueList[0] = value;

        var filterItem = { 'FilterKey': key, 'FilterValues': filterValueList };
        requestModel.filters.push(filterItem);

        if (FilterSearchTimeout) $timeout.cancel(FilterSearchTimeout);

        if (!disablePerformFilter) {
            if (isInstantFilter) {
                search_Click();
            } else {
                FilterSearchTimeout = $timeout(function () {
                    search_Click();
                }, 2000);
            }
        };
    };
    function showProgressDialog() {
        $mdDialog.show({
            parent: angular.element(document.body),
            template: '<md-dialog ng-cloak height="100%" style="min-width: 1px !important;"><md-dialog-content><div class="md-dialog-content-clearpadding">' +
			  '<md-progress-circular md-mode="indeterminate"></md-progress-circular>' +
			  '</div></md-dialog-content></md-dialog>',
            controller: DialogController
        });
    }

    function isValidFilterFind() {
        var filterKeyItem = null;
        var blnResult = false;

        for (var iCount = 0; iCount < requestModel.filters.length; iCount++) {
            filterKeyItem = requestModel.filters[iCount];
            if (filterKeyItem.FilterValues && filterKeyItem.FilterValues[0] && filterKeyItem.FilterValues[0].trim().length > 0) {
                blnResult = true;
                break;
            }
            filterKeyItem = null;
        }
        return blnResult;
    }

    $scope.PageEvents.ShowOnlySelected = function () {
        $scope.vm.viewSelectedOnlyLabel = $scope.vm.viewSelectedOnlyLabel == 'View selected' ? 'Show all' : 'View selected';
    };

    function DialogController($scope, $mdDialog) {

        $scope.dialogPopup = {
            Header: '',
            Message: '',
            CallbackFunction: null,
            Show: function () {
                $('#popup-alert-dialog-bg').slideToggle();
            },
            OK: function () {
                $('#popup-alert-dialog-bg').slideToggle();
                $scope.dialogPopup.Header = '';
                $scope.dialogPopup.Message = '';

                if ($scope.dialogPopup.CallbackFunction) {
                    $scope.dialogPopup.CallbackFunction();
                    $scope.dialogPopup.CallbackFunction = null;
                }
            }
        };

        $scope.hide = function () {
            $mdDialog.hide();
        };
        $scope.cancel = function () {
            $mdDialog.cancel();
        };
        $scope.answer = function () {
            $mdDialog.hide();
        };

        $scope.ClassTextChange = CustomClassTextChange;

        function CustomClassTextChange($event) {
            if ($event.keyCode === 13) {
                $event.preventDefault();
            }
        }
        $scope.ClassButtonChange = function ($event, type) {
            if ($event.keyCode === 9) {
                $event.preventDefault();
                if (type == "Add")
                    $("#classAddEditForm input[id=classAlias]").focus();
                else if (type == "Edit") {
                    $("#classAddEditForm input[id=classDescription]").focus();
                    $("#classAddEditForm input[id=classDescription]").select();
                }
            }
        }
    }

    $scope.PageEvents.CancelDialog = function () {
        $mdDialog.cancel();
    }

    ///Class Add and Edit

    $scope.PageEvents.Add = function () {

        var subClassDisplayText = $filter('filter')($scope.appsVar.CaptionsList, { MetaDataItem: $scope.vm.selectedApp.CurrentTab });
        if (typeof subClassDisplayText !== 'undefined' && subClassDisplayText.length > 0) {
            $scope.appsVar.tooltipValue = subClassDisplayText[0].DisplayText;
            $scope.generalSettings.PopupTitle = 'Add ' + subClassDisplayText[0].DisplayText;
        } else {
            var waitTillGetAppsVar = $scope.$watch(function () { return $scope.appsVar.CaptionsList }, function () {
                var subClassDisplayText = $filter('filter')($scope.appsVar.CaptionsList, { MetaDataItem: $scope.vm.selectedApp.CurrentTab });
                if (typeof subClassDisplayText !== 'undefined' && subClassDisplayText.length > 0) {
                    $scope.generalSettings.PopupTitle = 'Add ' + subClassDisplayText[0].DisplayText;
                    waitTillGetAppsVar();
                }
            });
        }

        $scope.validation.showMessage = false;
        $scope.validation.showInformationMessage = false;
        $scope.ShowWarning = false;
        $scope.posting = false;
        $scope.PageEvents.UserAction = 'Add';
        $scope.ClassModel = classFactory.classInitailValues();

        $scope.IsSubClassVisible = true;

        var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
        $mdDialog.show({
            controller: DialogController,
            scope: $scope,
            preserveScope: true,
            templateUrl: 'Views/AddClass.html',
            parent: angular.element(document.body),
            clickOutsideToClose: true,
            fullscreen: useFullScreen,
            onComplete: function () {
                $("#classAddEditForm input[id=classAlias]").focus();
                $("#classAddEditForm input[id=classAlias]").select();
            }
        })
		.then(function (answer) {

		}, function () {

		});
        $scope.$watch(function () {
            return $mdMedia('xs') || $mdMedia('sm');
        }, function (wantsFullScreen) {
            $scope.customFullscreen = (wantsFullScreen === true);
        });
    };

    $scope.PageEvents.Save = function () {
        $scope.validation.showMessage = true;
        $scope.posting = false;
        $scope.ShowWarning = false;

        if ($scope.ClassModel.Description == '' || $scope.ClassModel.Description == undefined || $scope.ClassModel.Alias == '') {
            return;
        }
        $scope.posting = true;
        var requiredFieldsList = [];
        var serverModel = classFactory.getClassAPIPostModel($scope.ClassModel, $scope.vm.selectedLibrary);
        if ($scope.PageEvents.UserAction == 'Add') {
            var apiUrl = classFactory.getAPIUrl('POSTCLASS', $scope.ClassModel);
            $scope.mc.getlogDetails("Debug", 'Method:POST;URL:' + JSON.stringify(apiUrl) + ';Body:' + JSON.stringify(serverModel));
            var promiseAdd = ClassService.addClass(apiUrl, $scope.mc.loginModel.AuthKey, serverModel);
            promiseAdd.then(function (response) {
                $scope.validation.showMessage = false;
                $scope.posting = false;
                $scope.validation.showInformationMessage = false;
                $scope.ShowWarning = false;

                if (!response.data.error) {
                    $scope.dialogPopup.CallbackFunction = function () {
                        $mdDialog.hide();
                    }
                    $scope.dialogPopup.Header = 'Success';
                    $scope.dialogPopup.Message = 'Class added succesfully.';
                    $scope.mc.setSecurityLogDetails("Info", 'Success', $scope.ClassModel.Alias, ' Class Add', JSON.stringify(serverModel))
                    $scope.dialogPopup.Show();
                    $timeout(function () {
                        $scope.dialogPopup.OK();
                        $scope.ClassModel = classFactory.classInitailValues();
                        $scope.selected = [];
                        $scope.ClassList = [];
                        requestModel.pagenumber = 1;
                        Initalize();
                    }, 2000);
                }
                else {
                    $scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.ClassModel.Alias, ' Class Add', JSON.stringify(serverModel))
                    $scope.ShowWarning = true;
                    $scope.ErrorMessage = response.data.Message;
                    if (response && response.data && response.data.details && response.data.details.message) {
                        $scope.ErrorMessage = response.data.details.message;
                    }
                    else {
                        $scope.ErrorMessage = "Posting user failed due to unknown errors.";
                    }
                }
            }, function (response) {
                $scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.ClassModel.Alias, ' Class Add', JSON.stringify(serverModel))
                $scope.posting = false;
                $scope.ShowWarning = true;
                $scope.ErrorMessage = "Posting user failed due to unknown errors.";
            });
        } else {
            var apiUrl = classFactory.getAPIUrl('PUTCLASS', $scope.ClassModel);
            $scope.mc.getlogDetails("Debug", 'Method:PUT;URL:' + JSON.stringify(apiUrl) + ';Body:' + JSON.stringify(serverModel));
            //$scope.mc.setSecurityLogDetails("Info", 'Method:PUT;URL:' + JSON.stringify(apiUrl) + ';Body:' + JSON.stringify(serverModel));
            var promiseAdd = ClassService.editClass(apiUrl, $scope.mc.loginModel.AuthKey, serverModel);
            promiseAdd.then(function (response) {
                $scope.validation.showMessage = false;
                $scope.validation.showInformationMessage = false;
                $scope.ShowWarning = false;
                $scope.posting = false;

                if (!response.data.error) {
                    $scope.dialogPopup.CallbackFunction = function () {
                        $mdDialog.hide();
                    }
                    $scope.dialogPopup.Header = 'Success';
                    $scope.dialogPopup.Message = 'Class edited succesfully.';
                    $scope.result = angular.equals($scope.ClassModel, $scope.originalclass);
                    $scope.mc.setSecurityLogDetails("Info", 'Success', $scope.ClassModel.Alias, ' Class Add', JSON.stringify(serverModel))
                    $scope.dialogPopup.Show();
                    $timeout(function () {
                        $scope.dialogPopup.OK();
                        $scope.ClassModel = classFactory.classInitailValues();
                        //fillClassList();
                    }, 2000);

                    $scope.ClassList[selectedRowIndex].Description = $scope.ClassModel.Description;
                    $scope.ClassList[selectedRowIndex].Echo = $scope.ClassModel.Echo;
                    $scope.ClassList[selectedRowIndex].RetainDays = $scope.ClassModel.RetainDays;
                    $scope.ClassList[selectedRowIndex].FieldRequired = $scope.ClassModel.FieldRequired;
                    $scope.ClassList[selectedRowIndex].Security = $scope.ClassModel.Security;
                    $scope.ClassList[selectedRowIndex].SubclassRequired = $scope.ClassModel.SubclassRequired;
                    $scope.ClassList[selectedRowIndex].HIPAACompliant = $scope.ClassModel.HIPAACompliant;

                    var tmpList = [];
                    tmpList = angular.copy($scope.ClassList);
                    $scope.selected = [];
                    $scope.ClassList = [];
                    $scope.ClassList = angular.copy(tmpList);
                    $scope.ClassModel = classFactory.classInitailValues();
                    tmpList = [];
                }
                else {
                    $scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.ClassModel.Alias, ' Class Add', JSON.stringify(serverModel))
                    $scope.ShowWarning = true;
                    $scope.ErrorMessage = response.data.Message;
                }
            }, function (response) {
                $scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.ClassModel.Alias, ' Class Add', JSON.stringify(serverModel))
                $scope.posting = false;
                $scope.ShowWarning = true;
                $scope.ErrorMessage = "Posting user failed due to unknown errors.";
            });
        }
    };

    $scope.PageEvents.Delete = function (event) {

        if (!$scope.selected || $scope.selected.length == 0) {
            $mdDialog.show(
					   $mdDialog.alert()
						   .parent(angular.element(document.body))
						   .clickOutsideToClose(true)
						   .title('Warning!')
						   .textContent('Please select Class(es) to delete.')
						   .ariaLabel('Warning!')
						   .ok('OK')
				   );
            return;
        }

        var confirm = $mdDialog.confirm()
					.title('Warning!')
					.theme('confirm-dialog')
				   .textContent('Are you sure you want to delete the selected Class(es)?')
				   .ariaLabel('')
				   .targetEvent(event)
				   .ok('Yes')
				   .cancel('No');
        $mdDialog.show(confirm).then(function () {
            $mdDialog.show(
				$mdDialog.alert()
			   .parent(angular.element(document.body))
			   .clickOutsideToClose(true)
			   .title('Warning!')
			   .textContent('Are you sure you want to delete the selected Class(es)?')
			   .ariaLabel('')
			   .ok('OK')
			   ).then(function () {

			       $mdDialog.show(
							$mdDialog.alert()
							.parent(angular.element(document.body))
							.clickOutsideToClose(true)
							.title('Warning!')
							.textContent('Failed to delete selected Class(es).')
							.ariaLabel('')
							.ok('OK')
					);
			   });
        });
    };

    $scope.SubClassTextChange = CustomSubClassTextChange;

    function CustomSubClassTextChange($event) {
        if ($event.keyCode === 13) {
            $event.preventDefault();
        }
    }

    var subClassRequestModel = homeFactory.requestModelInstance();
    var subClassListSearchTimeout;
    var isInstantSearch = false;
    var isSubClassListSearchTextDirty = false;
    var totalSubClassCountWithoutFilter = 0;

    var SelectedSubClassListForFilter = [];
    var LastAddedSelectedItemSubClass = [];
    var lastAppendSubClassItemCount = 0;

    $scope.ClassView = {
        SearchText: '',
        ViewSelectedText: '',
        IsViewSubClassListErrorMsg: false,
        SubClassListErrorMsg: '',
        SubClassList: [],
        SelectedSubclassList: [],
        SubClassMenuList: [],
        NewAddClassList: [],
        EditClassList: [],
        totalCount: 0,
        IsSetTitleMsg: false,
        SubClassListTitle: ''
    };

    $scope.PageEvents.ViewSelected = function (selectedRow, $event) {
        if (!$event.ctrlKey) {
            $scope.ViewClassModel = angular.copy(selectedRow);
            setFieldRequired();

            $scope.ClassView.ViewSelectedText = 'View selected';
            selectedRowIndex = -1;
            SelectedSubClassListForFilter = [];
            LastAddedSelectedItemSubClass = [];
            lastAppendSubClassItemCount = 0;
            $scope.IsSubClassVisible = false;
            totalSubClassCountWithoutFilter = 0;

            $rootScope.checkReadyToChangeState = function () {
                return $q(function (resolve, reject) {
                    if (!isClassEdited()) {
                        resolve({ Status: 0 });
                        return;
                    }
                    var confirm = $mdDialog.confirm()
							.title('Warning!')
							.theme('confirm-dialog')
							.textContent('Do you want to save the changes?')
							.ariaLabel('Warning!').ok('Yes').cancel('No');

                    $mdDialog.show(confirm).then(function () {
                        var classPromise = saveClass();
                        classPromise.then(function (response) {
                            if (response && response.Status === 0 && response.ErrorMessage.length === 0) {
                                resolve({ Status: 0 });
                            }
                            else if (response && response.ErrorMessage) {
                                $mdDialog.show($mdDialog.alert()
											.parent(angular.element(document.body))
											.clickOutsideToClose(true)
											.title('Warning!')
											.textContent(response.ErrorMessage)
											.ariaLabel('Warning!')
											.ok('OK')
										);
                                resolve({ Status: -1 });
                            }

                        });
                    }, function () {
                        resolve({ Status: 0 });
                    });
                });
            };

            var tempListFilter = $filter('filter')($scope.ClassList, {
                Alias: $scope.ViewClassModel.Alias
            }, true);
            if (tempListFilter.length > 0) {
                selectedRowIndex = $scope.ClassList.indexOf(tempListFilter[0]);
            }
            tempListFilter = [];

            $scope.ClassView.NewAddClassList = [];
            $scope.ClassView.EditClassList = [];
            $scope.InitailizeClassView();
            $scope.posting = false;
            $scope.showSelectedClassDetails = true;
        }
    }

    function setFieldRequired() {
        var fieldRequired = $scope.ViewClassModel.FieldRequired;

        angular.forEach($scope.metaDataListForPopup, function (metadata) {
            metadata.IsSelected = false;
            if (metadata.ShowInPopup) {
                if ((fieldRequired & metadata.TagValue) === metadata.TagValue) {
                    metadata.IsSelected = true;
                    $scope.EnableCheckbox(metadata);
                }
            }
        });
    }

    $scope.HideViewSelected = function () {
        if (!isClassEdited()) {
            closeViewWindow();
            return;
        }
        if (noDataExist) {
            closeViewWindow();
            return;
        }
        var confirm = $mdDialog.confirm()
				.title('Warning!')
				.theme('confirm-dialog')
				.textContent('Do you want to save the changes?')
				.ariaLabel('Warning!').ok('Yes').cancel('No');

        $mdDialog.show(confirm).then(function () {
            var classPromise = saveClass();
            classPromise.then(function (response) {
                if (response && response.Status === 0 && response.ErrorMessage.length === 0) {
                    closeViewWindow();
                }
                else if (response && response.ErrorMessage) {
                    $mdDialog.show($mdDialog.alert()
								.parent(angular.element(document.body))
								.clickOutsideToClose(true)
								.title('Warning!')
								.textContent(response.ErrorMessage)
								.ariaLabel('Warning!')
								.ok('OK')
							);
                }
            });
        }, function () {
            closeViewWindow();
        });
    };

    function isClassEdited() {
        if ($scope.ClassList[selectedRowIndex].Description !== $scope.ViewClassModel.Description
		   || $scope.ClassList[selectedRowIndex].RetainDays !== $scope.ViewClassModel.RetainDays
		   || $scope.ClassList[selectedRowIndex].Security !== $scope.ViewClassModel.Security
		   || $scope.ClassList[selectedRowIndex].SubclassRequired !== $scope.ViewClassModel.SubclassRequired
		   || $scope.ClassList[selectedRowIndex].HIPAACompliant !== $scope.ViewClassModel.HIPAACompliant
		   || $scope.ClassList[selectedRowIndex].Echo !== $scope.ViewClassModel.Echo) {
            return true;
        }

        if ($scope.ClassView.NewAddClassList.length > 0 || $scope.ClassView.EditClassList.length > 0) {
            return true;
        }
        return false;
    }

    function closeViewWindow() {
        $scope.showSelectedClassDetails = false;
        $scope.ClassView.ViewSelectedText = 'View selected';
        $scope.ClassView.NewAddClassList = [];
        $scope.ClassView.EditClassList = [];
        isInstantSearch = false;
        isSubClassListSearchTextDirty = false;
        $scope.ClassView.SearchText = '';
        $scope.ClassView.SubClassList = [];
        $scope.ClassView.SelectedSubclassList = [];
        $scope.ClassView.SubClassMenuList = [];
        $scope.ClassView.totalCount = 0;
        $scope.ClassView.IsSetTitleMsg = true;
        $scope.ClassView.SubClassListTitle = '';
        SelectedSubClassListForFilter = [];
        LastAddedSelectedItemSubClass = [];
        lastAppendSubClassItemCount = 0;
        $scope.posting = false;

        angular.forEach($scope.metaDataListForPopup, function (metadata) {
            metadata.IsSelected = false;
        });

        $timeout(function () {
            $(window).scrollTop($scope.scrollTop);
        });
    }

    $scope.InitailizeClassView = function () {
        isInstantSearch = false;
        isSubClassListSearchTextDirty = false;
        $scope.ClassView.SearchText = '';
        $scope.ClassView.SubClassList = [];
        $scope.ClassView.SelectedSubclassList = [];
        $scope.ClassView.SubClassMenuList = [];
        $scope.ClassView.totalCount = 0;
        $scope.ClassView.IsSetTitleMsg = true;
        $scope.ClassView.SubClassListTitle = '';
        SelectedSubClassListForFilter = [];
        LastAddedSelectedItemSubClass = [];
        lastAppendSubClassItemCount = 0;
        totalSubClassCountWithoutFilter = 0;

        fillNewClassList();
        fillSubClassInView();
    }

    function fillNewClassList() {
        angular.forEach($scope.ClassView.NewAddClassList, function (subClassModel) {
            if ($scope.ClassView.SearchText.length === 0) {
                $scope.ClassView.SubClassList.push(subClassModel);
            }
            else {
                if (subClassModel.Alias.indexOf($scope.ClassView.SearchText) >= 0 || subClassModel.Description.indexOf($scope.ClassView.SearchText) >= 0) {
                    $scope.ClassView.SubClassList.push(subClassModel);
                }
            }
        });
    }

    function fillSubClassInView() {

        if (!$scope.vm.selectedLibrary || $scope.vm.selectedLibrary.trim().length == 0)
            return;

        subClassRequestModel.libraryName = $scope.vm.selectedLibrary;
        subClassRequestModel.searchText = $scope.ClassView.SearchText;
        subClassRequestModel.Alias = $scope.ViewClassModel.Alias;

        var apiUrl = classFactory.getAPIUrl('SEARCHSUBCLASS', subClassRequestModel);
        $scope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(apiUrl));
        var promise = ClassService.getClasses(apiUrl, $scope.mc.loginModel.AuthKey);
        promise.then(function (response) {
            if (response.data && response.status === 200) {
                $scope.mc.getlogDetails("Debug", "Received searched sub class details.");
                $scope.ClassView.totalCount = response.data[CONST_CLASS.TotalCount];

                if ($scope.ClassView.IsSetTitleMsg) {
                    totalSubClassCountWithoutFilter = $scope.ClassView.totalCount;
                    $scope.ClassView.IsSetTitleMsg = false;
                    if ($scope.ClassView.totalCount > 0 || $scope.ClassView.NewAddClassList.length > 0) {
                        $scope.ClassView.SubClassListTitle = $scope.ViewClassModel.Alias + ' has ' +
							($scope.ClassView.totalCount + $scope.ClassView.NewAddClassList.length).toString() + ' ' + $scope.appsVar.tooltipValue;
                    }
                    else {
                        $scope.ClassView.SubClassListTitle = $scope.ViewClassModel.Alias + ' has no ' + $scope.appsVar.tooltipValue;
                    }
                }

                if (lastAppendSubClassItemCount > 0) {
                    $scope.ClassView.SubClassList.splice($scope.ClassView.SubClassList.length - lastAppendSubClassItemCount, lastAppendSubClassItemCount);
                    $scope.ClassView.SelectedSubclassList.splice($scope.ClassView.SelectedSubclassList.length - lastAppendSubClassItemCount, lastAppendSubClassItemCount);
                    lastAppendSubClassItemCount = 0;
                }

                var subClassUIModel;
                var filterTempModel;
                var tempListFilter = [];

                angular.forEach(response.data[CONST_CLASS.ClassList], function (subClassApiModel) {
                    subClassUIModel = classFactory.getClassUI(subClassApiModel)
                    if (SelectedSubClassListForFilter.length === 0) {
                        $scope.ClassView.SubClassList.push(subClassUIModel);
                    }
                    else {
                        tempListFilter = $filter('filter')(SelectedSubClassListForFilter, {
                            Alias: subClassUIModel.Alias
                        }, true);
                        if (tempListFilter.length === 0) {
                            $scope.ClassView.SubClassList.push(subClassUIModel);
                        }
                        else {
                            LastAddedSelectedItemSubClass = $.grep(LastAddedSelectedItemSubClass,
							   function (item, index) {
							       return item.Alias != subClassUIModel.Alias;
							   });

                            tempListFilter[0].Description = subClassUIModel.Description;
                            tempListFilter[0].Echo = subClassUIModel.Echo;
                            tempListFilter[0].RetainDays = subClassUIModel.RetainDays;
                            tempListFilter[0].FieldRequired = subClassUIModel.FieldRequired;
                            tempListFilter[0].Security = subClassUIModel.Security;
                            tempListFilter[0].HIPAACompliant = subClassUIModel.HIPAACompliant;

                            filterTempModel = angular.copy(tempListFilter[0]);
                            $scope.ClassView.SubClassList.push(filterTempModel);
                            $scope.ClassView.SelectedSubclassList.push(filterTempModel);
                            filterTempModel = null;
                        }
                        tempListFilter = [];
                    }
                    subClassUIModel = null;
                });
                lastAppendSubClassItemCount = 0;
                if ($scope.ClassView.SearchText.length === 0) {
                    angular.forEach(LastAddedSelectedItemSubClass, function (subClassModel) {
                        filterTempModel = angular.copy(subClassModel);
                        $scope.ClassView.SubClassList.push(filterTempModel);
                        $scope.ClassView.SelectedSubclassList.push(filterTempModel);
                        filterTempModel = null;
                        lastAppendSubClassItemCount += 1;
                    });
                }
                if ($scope.ClassView.SelectedSubclassList.length > 0) {
                    setSubClassListContextMenuObject();
                }
                if ($scope.ClassView.SearchText.length > 0 && $scope.ClassView.SubClassList.length === 0) {
                    $scope.ClassView.IsViewSubClassListErrorMsg = true;
                    $scope.ClassView.SubClassListErrorMsg = $scope.appsVar.tooltipValue + ' not found, based on this search.';
                }
            } else {
                $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
            }
        }, function (response) {
            $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
            $mdDialog.show(
				$mdDialog.alert()
				.parent(angular.element(document.body))
				.clickOutsideToClose(true)
				.title('Warning!')
				.textContent('Failed to retrive SubClasses.')
				.ariaLabel('Warning!')
				.ok('OK')
		);
        });
    };

    $scope.$watch(function () { return $scope.ClassView.SearchText; }, function (val) {
        if ($scope.ClassView.SearchText.length > 0) {
            isSubClassListSearchTextDirty = true;
        }
        if (subClassListSearchTimeout) $timeout.cancel(subClassListSearchTimeout);

        if (isInstantSearch) {
            isInstantSearch = false;
            $scope.SubClassList_SearchClick();
        }
        else {
            subClassListSearchTimeout = $timeout(function () {
                if (isSubClassListSearchTextDirty) {
                    $scope.SubClassList_SearchClick();
                }
            }, 2000);
        }
    }, true);

    $scope.SubClassList_SearchClick = function () {
        if (subClassListSearchTimeout) $timeout.cancel(subClassListSearchTimeout);
        lastAppendSubClassItemCount = 0;
        LastAddedSelectedItemSubClass = angular.copy(SelectedSubClassListForFilter);
        $scope.ClassView.IsViewSubClassListErrorMsg = false;
        $scope.ClassView.SubClassListErrorMsg = '';
        subClassRequestModel.pagenumber = 1;
        $scope.ClassView.SubClassList = [];
        $scope.ClassView.SelectedSubclassList = [];
        fillNewClassList();
        fillSubClassInView();
    };

    $scope.ClearSubClassListSearch = function () {
        isInstantSearch = true;
        $scope.ClassView.SearchText = '';
    };

    $scope.onSubClassDeselect = function (subClassModel) {
        setSubClassListContextMenuObject();
        if (SelectedSubClassListForFilter.length > 0) {
            SelectedSubClassListForFilter = $.grep(SelectedSubClassListForFilter,
								function (item, index) {
								    return item.Alias != subClassModel.Alias;
								});
        }
        if (SelectedSubClassListForFilter.length > 0) {
            LastAddedSelectedItemSubClass = $.grep(LastAddedSelectedItemSubClass,
								   function (item, index) {
								       return item.Alias != subClassModel.Alias;
								   });
        }
    };

    $scope.onSubClassSelect = function (subClassModel) {
        setSubClassListContextMenuObject();
        var tempListFilter = $filter('filter')(SelectedSubClassListForFilter, {
            Alias: subClassModel.Alias
        }, true);
        if (tempListFilter.length === 0) {
            SelectedSubClassListForFilter.push(angular.copy(subClassModel));
        }
    };

    $scope.ContextMenuFunctions = {
        Edit: function () { $scope.OpenEditSubClass(); }
    };

    function setSubClassListContextMenuObject() {
        $scope.ClassView.SubClassMenuList = [
			{
			    Label: 'Edit',
			    Icon: 'icon-edit',
			    onClick: $scope.ContextMenuFunctions.Edit,
			    Enable: $scope.ClassView.SelectedSubclassList.length === 1,
			    IconType: 'font-icon'
			}
        ];
    };

    $scope.SelectedOnlyFilterOnGrid = function (selectedList) {
        return function (subClassModel) {
            if ($scope.ClassView.ViewSelectedText === 'View selected') {
                return true;
            }
            if ($scope.ClassView.ViewSelectedText === 'Show all') {
                if (selectedList.length === 0) {
                    $scope.ClassView.ViewSelectedText = 'View selected';
                }
                var tempListFilter = $filter('filter')(selectedList, {
                    Alias: subClassModel.Alias
                }, true);
                if (tempListFilter.length > 0) {
                    return true;
                }
                return false;
            }
            return false;
        }
    };

    $scope.ViewSelected_Click = function () {
        $scope.ClassView.ViewSelectedText = $scope.ClassView.ViewSelectedText == 'View selected' ? 'Show all' : 'View selected';
    };

    $scope.OpenAddSubClass = function () {
        $scope.IsShowRequiredField = false;
        var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
        $mdDialog.show({
            controller: SubClassAddDialogController,
            preserveScope: false,
            templateUrl: 'Views/AddClass.html',
            parent: angular.element(document.body),
            clickOutsideToClose: true,
            fullscreen: useFullScreen,
            onComplete: function () {
                $("#classAddEditForm input[id=classAlias]").focus();
            },
            bindToController: true,
            locals: {
                parentScope: $scope
            }
        })
		.then(function (answer) {

		}, function () {

		});
        $scope.$watch(function () {
            return $mdMedia('xs') || $mdMedia('sm');
        }, function (wantsFullScreen) {
            $scope.customFullscreen = (wantsFullScreen === true);
        });
    };

    function SubClassAddDialogController($scope, $mdDialog, parentScope) {

        $scope.hide = function () {
            $mdDialog.hide();
        };
        $scope.cancel = function () {
            $mdDialog.cancel();
        };
        $scope.answer = function () {
            $mdDialog.hide();
        };

        $scope.ClassTextChange = CustomClassTextChange;

        function CustomClassTextChange($event) {
            if ($event.keyCode === 13) {
                $event.preventDefault();
            }
        }
        $scope.ClassButtonChange = function ($event, type) {
            if ($event.keyCode === 9) {
                $event.preventDefault();
                if (type == "Add")
                    $("#classAddEditForm input[id=classAlias]").focus();
                else if (type == "Edit") {
                    $("#classAddEditForm input[id=classDescription]").focus();
                    $("#classAddEditForm input[id=classDescription]").select();
                }
            }
        }

        $scope.IsShowRequiredField = false;
        $scope.ShowWarning = false;
        $scope.posting = false;
        $scope.IsSubClassVisible = false;
        $scope.ClassModel = classFactory.classInitailValues();
        $scope.ClassModel.ParentClass = parentScope.appsVar.tooltipValue;
        $scope.generalSettings = classFactory.generalSettings;
        $scope.generalSettings.PopupTitle = 'Add ' + parentScope.appsVar.tooltipValue + ' for ' + parentScope.ViewClassModel.Alias;

        $scope.PageEvents = {
            UserAction: 'Add',
            CancelDialog: function () { $mdDialog.cancel(); },
            Save: null
        };

        $scope.PageEvents.Save = function () {
            if ($scope.ClassModel.Description == '' || $scope.ClassModel.Description == undefined || $scope.ClassModel.Alias == '') {
                return;
            }

            parentScope.ClassView.NewAddClassList.push($scope.ClassModel);
            parentScope.ClassView.SubClassListTitle = parentScope.ViewClassModel.Alias + ' has ' +
				(totalSubClassCountWithoutFilter + parentScope.ClassView.NewAddClassList.length).toString() + ' ' + parentScope.appsVar.tooltipValue;

            if (parentScope.ClassView.SearchText.length === 0) {
                parentScope.ClassView.SubClassList.splice(parentScope.ClassView.NewAddClassList.length - 1, 0, $scope.ClassModel);
            }
            else {
                if ($scope.ClassModel.Alias.indexOf(parentScope.ClassView.SearchText) >= 0 || $scope.ClassModel.Description.indexOf(parentScope.ClassView.SearchText) >= 0) {
                    parentScope.ClassView.SubClassList.splice(parentScope.ClassView.NewAddClassList.length - 1, 0, $scope.ClassModel);
                }
            }
            $scope.ClassModel = classFactory.classInitailValues();
            $mdDialog.cancel();
        };
    }

    $scope.OpenEditSubClass = function () {
        $scope.IsShowRequiredField = false;
        if ($scope.ClassView.SelectedSubclassList.length === 0) return;

        var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
        $mdDialog.show({
            controller: SubClassEditDialogController,
            preserveScope: false,
            templateUrl: 'Views/AddClass.html',
            parent: angular.element(document.body),
            clickOutsideToClose: true,
            fullscreen: useFullScreen,
            onComplete: function () {
                $("#classAddEditForm input[id=classDescription]").focus();
                $("#classAddEditForm input[id=classDescription]").select();
            },
            bindToController: true,
            locals: {
                parentScope: $scope
            }
        })
		.then(function (answer) {

		}, function () {

		});
        $scope.$watch(function () {
            return $mdMedia('xs') || $mdMedia('sm');
        }, function (wantsFullScreen) {
            $scope.customFullscreen = (wantsFullScreen === true);
        });
    };

    function SubClassEditDialogController($scope, $mdDialog, parentScope) {

        $scope.hide = function () {
            $scope.IsShowRequiredField = false;
            $mdDialog.hide();
        };
        $scope.cancel = function () {
            $scope.IsShowRequiredField = false;
            $mdDialog.cancel();
        };
        $scope.answer = function () {
            $scope.IsShowRequiredField = false;
            $mdDialog.hide();
        };

        $scope.ClassTextChange = CustomClassTextChange;

        function CustomClassTextChange($event) {
            if ($event.keyCode === 13) {
                $event.preventDefault();
            }
        }
        $scope.ClassButtonChange = function ($event, type) {
            if ($event.keyCode === 9) {
                $event.preventDefault();
                if (type == "Add")
                    $("#classAddEditForm input[id=classAlias]").focus();
                else if (type == "Edit") {
                    $("#classAddEditForm input[id=classDescription]").focus();
                    $("#classAddEditForm input[id=classDescription]").select();
                }
            }
        }

        $scope.SubClassMetaDataList = angular.copy(parentScope.SubClassMetaDataList);
        $scope.IsShowRequiredField = true;
        $scope.ShowWarning = false;
        $scope.posting = false;
        $scope.IsSubClassVisible = false;
        $scope.ClassModel = angular.copy(parentScope.ClassView.SelectedSubclassList[0]);
        $scope.generalSettings = classFactory.generalSettings;
        $scope.generalSettings.PopupTitle = 'Edit ' + parentScope.ViewClassModel.Alias;

        $scope.PageEvents = {
            UserAction: 'Edit',
            CancelDialog: function () { $mdDialog.cancel(); },
            Save: null
        };

        function setFieldRequired() {
            var fieldRequired = $scope.ClassModel.FieldRequired;

            angular.forEach($scope.SubClassMetaDataList, function (metadata) {
                metadata.IsSelected = false;
                if (metadata.ShowInPopup) {
                    if ((fieldRequired & metadata.TagValue) === metadata.TagValue) {
                        metadata.IsSelected = true;
                        $scope.EnableCheckbox(metadata);
                    }
                }
            });
        }

        $scope.EnableCheckbox = function (metaData) {
            if (metaData.ValueText == 'CUSTOM1') {
                var selectedMetaDataItem = $filter('filter')($scope.SubClassMetaDataList, { ValueText: 'CUSTOM2' });
                selectedMetaDataItem[0].DependantItemId = 'CUSTOM1';
                selectedMetaDataItem[0].oneDisable = !metaData.IsSelected;
                if (metaData.IsSelected == false) {
                    selectedMetaDataItem[0].IsSelected = false;
                }
            }
            else if (metaData.ValueText == 'CUSTOM29') {
                var selectedMetaDataItem = $filter('filter')($scope.SubClassMetaDataList, { ValueText: 'CUSTOM30' });
                selectedMetaDataItem[0].DependantItemId = 'CUSTOM29';
                selectedMetaDataItem[0].oneDisable = !metaData.IsSelected;
                if (metaData.IsSelected == false) {
                    selectedMetaDataItem[0].IsSelected = false;
                }
            }
        }
        setFieldRequired();

        $scope.PageEvents.Save = function () {
            var blnIsNewItem = false;
            var fieldRequired = 0;

            if ($scope.ClassModel.Description == '' || $scope.ClassModel.Description == undefined || $scope.ClassModel.Alias == '') {
                return;
            }

            for (iCount = 0; iCount < $scope.SubClassMetaDataList.length; iCount++) {
                if ($scope.SubClassMetaDataList[iCount].IsSelected && $scope.SubClassMetaDataList[iCount].ShowInPopup) {
                    fieldRequired = fieldRequired | $scope.SubClassMetaDataList[iCount].TagValue;
                }
            }
            $scope.ClassModel.FieldRequired = fieldRequired;

            var tempListFilter = $filter('filter')(parentScope.ClassView.NewAddClassList, {
                Alias: $scope.ClassModel.Alias
            }, true);
            if (tempListFilter.length > 0) {
                tempListFilter[0].Description = $scope.ClassModel.Description;
                tempListFilter[0].RetainDays = $scope.ClassModel.RetainDays;
                tempListFilter[0].Security = $scope.ClassModel.Security;
                tempListFilter[0].HIPAACompliant = $scope.ClassModel.HIPAACompliant;
                tempListFilter[0].Echo = $scope.ClassModel.Echo;
                tempListFilter[0].ParentClass = $scope.ClassModel.ParentClass;
                tempListFilter[0].FieldRequired = $scope.ClassModel.FieldRequired;
                blnIsNewItem = true;
            }
            tempListFilter = [];

            if (!blnIsNewItem) {
                parentScope.ClassView.EditClassList = $.grep(parentScope.ClassView.EditClassList,
							   function (item, index) {
							       return item.Alias != $scope.ClassModel.Alias;
							   });
            }
            tempListFilter = $filter('filter')(parentScope.ClassView.SubClassList, {
                Alias: $scope.ClassModel.Alias
            }, true);
            if (tempListFilter.length > 0) {
                tempListFilter[0].Description = $scope.ClassModel.Description;
                tempListFilter[0].RetainDays = $scope.ClassModel.RetainDays;
                tempListFilter[0].Security = $scope.ClassModel.Security;
                tempListFilter[0].HIPAACompliant = $scope.ClassModel.HIPAACompliant;
                tempListFilter[0].Echo = $scope.ClassModel.Echo;
                tempListFilter[0].ParentClass = $scope.ClassModel.ParentClass;
                tempListFilter[0].FieldRequired = $scope.ClassModel.FieldRequired;

                if (!blnIsNewItem) {
                    parentScope.ClassView.EditClassList.push(angular.copy(tempListFilter[0]));
                }
            }
            $scope.ClassModel = classFactory.classInitailValues();
            $mdDialog.cancel();
        };
    }

    $scope.SaveClassContent = function () {
        $scope.posting = false;
        if ($scope.ViewClassModel.Description === '' || $scope.ViewClassModel.Description === undefined || $scope.ViewClassModel.Alias === '') {
            return;
        }
        $scope.posting = true;
        var classPromise = saveClass();
        classPromise.then(function (response) {
            if (response && response.Status === 0 && response.ErrorMessage.length === 0) {
                $mdDialog.show($mdDialog.alert()
						   .parent(angular.element(document.body))
						   .clickOutsideToClose(true)
						   .title('Success')
						   .textContent('Class details succesfully updated.')
						   .ariaLabel('Success')
						   .ok('OK')
					   );
                $scope.ClassView.SubClassList = [];
                $scope.ClassView.NewAddClassList = [];
                $scope.ClassView.EditClassList = [];
                $scope.InitailizeClassView();
            }
            else if (response && response.ErrorMessage) {
                $mdDialog.show($mdDialog.alert()
							.parent(angular.element(document.body))
							.clickOutsideToClose(true)
							.title('Warning!')
							.textContent(response.ErrorMessage)
							.ariaLabel('Warning!')
							.ok('OK')
						);
            }
            $scope.posting = false;
        }, function (response) {
            $scope.posting = false;
            if (response && response.ErrorMessage) {
                $mdDialog.show($mdDialog.alert()
							.parent(angular.element(document.body))
							.clickOutsideToClose(true)
							.title('Warning!')
							.textContent(response.ErrorMessage)
							.ariaLabel('Warning!')
							.ok('OK')
						);
            }
        });
    };

    function saveClass() {

        return $q(function (resolve, reject) {

            var deferredarray = [];
            var errorMesssage = '';
            var errorMsg = '';
            var requiredFieldsList = [];
            var fieldRequired = 0;

            //angular.forEach($scope.metaDataListForPopup, function (metadata) {
            //	if (metadata.IsSelected) {
            //	    fieldRequired = fieldRequired | metadata.TagValue;
            //	}
            //});

            for (iCount = 0; iCount < $scope.metaDataListForPopup.length; iCount++) {
                if ($scope.metaDataListForPopup[iCount].IsSelected && $scope.metaDataListForPopup[iCount].ShowInPopup) {
                    fieldRequired = fieldRequired | $scope.metaDataListForPopup[iCount].TagValue;
                }
            }

            $scope.ViewClassModel.Echo = $scope.ViewClassModel.Echo === true || $scope.ViewClassModel.Echo === "true";
            $scope.ViewClassModel.SubclassRequired = $scope.ViewClassModel.SubclassRequired === true || $scope.ViewClassModel.SubclassRequired === "true";
            $scope.ViewClassModel.HIPAACompliant = $scope.ViewClassModel.HIPAACompliant === true || $scope.ViewClassModel.HIPAACompliant === "true";
            $scope.ViewClassModel.libraryName = $scope.vm.selectedLibrary;
            $scope.ViewClassModel.FieldRequired = fieldRequired;

            var apiUrlExist = classFactory.getAPIUrl('GETCLASSEXIST', $scope.ViewClassModel);
            exstMetadata = ClassService.getClasses(apiUrlExist, $scope.mc.loginModel.AuthKey);
            var deferredexstClass = $q.defer();
            exstMetadata.then(function (aresponse) {
                deferredexstClass.resolve(aresponse);
                deferredarray.push(deferredexstClass.promise);
                if (aresponse && aresponse.data && aresponse.data.data) {
                    if (aresponse.data.data.length == 0) {
                        noDataExist = true;
                        $scope.ClassList = $.grep($scope.ClassList,
							  function (item, index) {
							      return item.Alias != $scope.ViewClassModel.Alias;
							  });
                        errorMesssage = $scope.vm.selectedApp.CurrentTab + " does not contain " + $scope.ViewClassModel.Alias;
                        $q.all(deferredarray).then(function () {
                            resolve({ Status: -1, ErrorMessage: errorMesssage });
                        }, function () {
                            resolve({ Status: -1, ErrorMessage: errorMesssage });
                        });
                    }
                    else {
                        noDataExist = false;
                        var deferredClass = $q.defer();
                        var apiUrl = classFactory.getAPIUrl('PUTCLASS', $scope.ViewClassModel);
                        var serverModel = classFactory.getClassAPIPostModel($scope.ViewClassModel, $scope.vm.selectedLibrary);
                        $scope.mc.getlogDetails("Debug", 'Method:PUT;URL:' + JSON.stringify(apiUrl) + ';Body:' + JSON.stringify(serverModel));
                        var promise = ClassService.editClass(apiUrl, $scope.mc.loginModel.AuthKey, serverModel);
                        promise.then(function (response) {
                            deferredClass.resolve(response);
                            if (response && response.data && !response.data.error) {
                                $scope.mc.setSecurityLogDetails("Info", 'Success', $scope.ViewClassModel.Alias, ' Class Update' + JSON.stringify(serverModel))

                                $scope.ClassList[selectedRowIndex].Description = $scope.ViewClassModel.Description;
                                $scope.ClassList[selectedRowIndex].Echo = $scope.ViewClassModel.Echo;
                                $scope.ClassList[selectedRowIndex].RetainDays = $scope.ViewClassModel.RetainDays;
                                $scope.ClassList[selectedRowIndex].FieldRequired = $scope.ViewClassModel.FieldRequired;
                                $scope.ClassList[selectedRowIndex].Security = $scope.ViewClassModel.Security;
                                $scope.ClassList[selectedRowIndex].SubclassRequired = $scope.ViewClassModel.SubclassRequired;
                                $scope.ClassList[selectedRowIndex].HIPAACompliant = $scope.ViewClassModel.HIPAACompliant;

                                var tmpList = [];
                                tmpList = angular.copy($scope.ClassList);
                                $scope.selected = [];
                                $scope.ClassList = [];
                                $scope.ClassList = angular.copy(tmpList);
                                tmpList = [];
                                status = 0;
                                errorMsg = '';
                            }
                            else {
                                $scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.ViewClassModel.Alias, ' Class Update' + JSON.stringify(serverModel))
                                status = -1;
                                if (response && response.data && response.data.details && response.data.details.message) {
                                    errorMsg = response.data.details.message;
                                }
                                else {
                                    errorMsg = 'Posting class failed due to unknown errors.';
                                }
                            }
                        }, function (response) {
                            deferredClass.resolve(response);
                            $scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.ViewClassModel.Alias, ' Class Update' + JSON.stringify(serverModel))
                            status = -1;
                            if (response && response.data && response.data.details && response.data.details.message) {
                                errorMsg = response.data.details.message;
                            } else {
                                errorMsg = 'Posting class failed due to unknown errors.';
                            }
                        });
                        deferredarray.push(deferredClass.promise);

                        var deferredAddSubClass = $q.defer();
                        var subClassAddPromise = addNewSubClass();
                        subClassAddPromise.then(function (responseAddSubClass) {
                            deferredAddSubClass.resolve(responseAddSubClass);
                            if (errorMsg.length === 0 && responseAddSubClass && responseAddSubClass.ErrorMessage.length > 0) {
                                errorMsg = responseAddSubClass.ErrorMessage;
                            }
                        });
                        deferredarray.push(deferredAddSubClass.promise);

                        var deferredEditSubClass = $q.defer();
                        var subClassEditPromise = editSubClass();
                        subClassEditPromise.then(function (responseEditSubClass) {
                            deferredEditSubClass.resolve(responseEditSubClass);
                            if (errorMsg.length === 0 && responseEditSubClass && responseEditSubClass.ErrorMessage.length > 0) {
                                errorMsg = responseEditSubClass.ErrorMessage;
                            }
                        });
                        deferredarray.push(deferredEditSubClass.promise);

                        $q.all(deferredarray).then(function () {
                            resolve({ Status: 0, ErrorMessage: errorMsg });
                        }, function () {
                            resolve({ Status: -1, ErrorMessage: errorMsg });
                        });
                    }
                }
                else {
                    errorMesssage = $scope.vm.selectedApp.CurrentTab + " does not contain " + $scope.ViewClassModel.Alias;
                    $q.all(deferredarray).then(function () {
                        resolve({ Status: -1, ErrorMessage: errorMesssage });
                    }, function () {
                        resolve({ Status: -1, ErrorMessage: errorMesssage });
                    });
                }


            }, function (aresponse) {
                errorMesssage = $scope.vm.selectedApp.CurrentTab + " does not contain " + $scope.ViewClassModel.Alias;
                $q.all(deferredarray).then(function () {
                    resolve({ Status: -1, ErrorMessage: errorMesssage });
                }, function () {
                    resolve({ Status: -1, ErrorMessage: errorMesssage });
                });
            });

        });
    }

    function addNewSubClass() {
        var apiUrl;
        var deferredarray = [];
        var errorMsg = '';

        return $q(function (resolve, reject) {
            angular.forEach($scope.ClassView.NewAddClassList, function (subClassModel) {
                var deferredUser = $q.defer();
                subClassModel.ParentClass = $scope.ViewClassModel.Alias;
                apiUrl = classFactory.getAPIUrl('POSTSUBCLASS', subClassModel);
                var serverModel = classFactory.getClassAPIPostModel(subClassModel, $scope.vm.selectedLibrary);
                $scope.mc.getlogDetails("Debug", 'Method:PUT;URL:' + JSON.stringify(apiUrl) + ';Body:' + JSON.stringify(serverModel));
                var promiseAdd = ClassService.addSubClass(apiUrl, $scope.mc.loginModel.AuthKey, serverModel);
                promiseAdd.then(function (response) {
                    deferredUser.resolve(response);
                    if (response.status === 200) {
                        $scope.mc.setSecurityLogDetails("Info", 'Success', $scope.ViewClassModel.Alias, 'Sub Class Add' + JSON.stringify(serverModel))
                    }
                    else {
                        $scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.ViewClassModel.Alias, 'Sub Class Add' + JSON.stringify(serverModel))
                    }
                }, function (response) {
                    deferredUser.resolve(response);
                    $scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.ViewClassModel.Alias, ' Sub Class Add', JSON.stringify(serverModel));
                    if (response && response.data && response.data.details && response.data.details.message) {
                        if (errorMsg.length === 0) errorMsg = response.data.details.message;
                    } else {
                        if (errorMsg.length === 0) errorMsg = 'Posting class failed due to unknown errors.';
                    }
                });
                deferredarray.push(deferredUser.promise);
            });

            $q.all(deferredarray).then(function () {
                resolve({ Status: 0, ErrorMessage: errorMsg });
            }, function () {
                resolve({ Status: -1, ErrorMessage: errorMsg });
            });
        });
    }

    function editSubClass() {
        var apiUrl;
        var deferredarray = [];
        var errorMsg = '';

        return $q(function (resolve, reject) {
            angular.forEach($scope.ClassView.EditClassList, function (subClassModel) {
                var deferredUser = $q.defer();
                subClassModel.ParentClass = $scope.ViewClassModel.Alias;
                apiUrl = classFactory.getAPIUrl('PUTSUBCLASS', subClassModel);
                var serverModel = classFactory.getClassAPIPostModel(subClassModel, $scope.vm.selectedLibrary);
                $scope.mc.getlogDetails("Debug", 'Method:PUT;URL:' + JSON.stringify(apiUrl) + ';Body:' + JSON.stringify(serverModel));
                var promiseAdd = ClassService.editSubClass(apiUrl, $scope.mc.loginModel.AuthKey, serverModel);
                promiseAdd.then(function (response) {
                    deferredUser.resolve(response);
                    if (response.status === 200) {
                        $scope.mc.setSecurityLogDetails("Info", 'Success', $scope.ViewClassModel.Alias, 'Sub Class Update', JSON.stringify(serverModel));
                    } else {
                        $scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.ViewClassModel.Alias, 'Sub Class Update', JSON.stringify(serverModel));
                    }
                }, function (response) {
                    deferredUser.resolve(response);
                    $scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.ViewClassModel.Alias, 'Sub Class Update', JSON.stringify(serverModel));
                    if (response && response.data && response.data.details && response.data.details.message) {
                        if (errorMsg.length === 0) errorMsg = response.data.details.message;
                    } else {
                        if (errorMsg.length === 0) errorMsg = 'Posting ' + $scope.appsVar.tooltipValue + ' failed due to unknown errors.';
                    }
                });
                deferredarray.push(deferredUser.promise);
            });

            $q.all(deferredarray).then(function () {
                resolve({ Status: 0, ErrorMessage: errorMsg });
            }, function () {
                resolve({ Status: -1, ErrorMessage: errorMsg });
            });
        });
    }

    var view_scroll_fix_top = 524;
    $(window).on('scroll', function () {
        if ($scope.showSelectedClassDetails) {
            view_scroll_fix_top = $('.view-details-tab-container md-tabs-content-wrapper').offset().top;
            if ($(window).scrollTop() >= view_scroll_fix_top - 64) {
                $('.view-details-tab-container md-tabs-content-wrapper').addClass('fix-title');
            } else {
                $('.view-details-tab-container md-tabs-content-wrapper').removeClass('fix-title');
            }
        }
    });
}