app.controller("WorkSpaceController", WorkSpaceController);

WorkSpaceController.$inject = ['$scope', '$rootScope', '$filter', '$timeout', '$log', '$mdDialog', '$mdMedia', 'WorkSpaceService', 'workSpaceFactory', 'homeFactory',
		 'CONST_WORKSPACE', '$q', 'userFactory', 'CONST_USERS', 'GroupService', 'groupFactory', 'CONST_GROUPS_VIEW_DETAILS', 'UserService',
         'MetaDataService', 'metaDataFactory', 'CONST_METADATA'];

function WorkSpaceController($scope, $rootScope, $filter, $timeout, $log, $mdDialog, $mdMedia, WorkSpaceService, workSpaceFactory, homeFactory, CONST_WORKSPACE, $q,
	userFactory, CONST_USERS, GroupService, groupFactory, CONST_GROUPS_VIEW_DETAILS, UserService, MetaDataService, metaDataFactory, CONST_METADATA) {

    $scope.PageEvents.Add = undefined;
    $scope.selected = [];
    $scope.workSpaceList = [];
    $scope.appsVar.SearchText = '';
    $scope.IsShowWorkspaceList = false;
    $scope.showWorkspaceSearchFileds = false;

    var FilterSearchTimeout;
    var requestModel = homeFactory.requestModelInstance();

    $scope.$on('Window_Scrolled', function () {
        if ($scope.query.totalCount > $scope.workSpaceList.length) {
            requestModel.pagenumber++;
            getworkSpaces();
        }
    });
    var SelectedworkSpaceIdListForFilter = [];
    var LastAddedSelectedItemWorkSpaceId = [];
    var lastAppendItemCount = 0;
    $timeout(function () {
        $(window).scrollTop(0);
    });

    function getworkSpaces() {
        if ($scope.vm.selectedApp.NoAppsPermission.trim().length > 0)
            return;
        if (!$scope.vm.selectedLibrary || $scope.vm.selectedLibrary.trim().length == 0)
            return;

        $scope.IsShowWorkspaceList = false;
        if ($scope.WorkspaceSearch.Custom1Text.trim().length === 0 && $scope.WorkspaceSearch.Custom2Text.trim().length === 0 &&
            $scope.WorkspaceSearch.DescriptionText.trim().length === 0) return;

        showProgressDialog();
        $scope.lastSelectedLibrary = $scope.vm.selectedLibrary;
        requestModel.libraryName = $scope.vm.selectedLibrary;
        requestModel.searchText = $scope.appsVar.SearchText;
        requestModel.Custom1SearchText = $scope.WorkspaceSearch.Custom1Text.trim();
        requestModel.Custom2SearchText = $scope.WorkspaceSearch.Custom2Text.trim();
        requestModel.DescriptionSearchText = $scope.WorkspaceSearch.DescriptionText.trim();

        $scope.SearchCount = 0;

        if (requestModel.Custom1SearchText.length > 0) {
            $scope.SearchCount += 1;
        }
        if (requestModel.Custom2SearchText.length > 0) {
            $scope.SearchCount += 1;
        }
        if (requestModel.DescriptionSearchText.length > 0) {
            $scope.SearchCount += 1;
        }
        var apiUrl = workSpaceFactory.getAPIUrl('SEARCHWORKSPACE', requestModel);
        $scope.mc.getlogDetails("Debug", 'Method:GET;URL' + JSON.stringify(apiUrl));
        var promise = WorkSpaceService.getWorkSpaces(apiUrl, $scope.mc.loginModel.AuthKey)
        promise.then(function (response) {
            if (response["status"] == 200) {
                $scope.mc.getlogDetails("Info", "Received workspace details.");
                $scope.query.totalCount = response["data"]["total_count"];
                var tempListFilter = [];
                var workSpaceUIModel;
                var filterTempModel;
                //if (lastAppendItemCount > 0) {
                //    $scope.workSpaceList.splice($scope.workSpaceList.length - lastAppendItemCount, lastAppendItemCount);
                //    $scope.selected.splice($scope.selected.length - lastAppendItemCount, lastAppendItemCount);
                //}
                angular.forEach(response["data"]["data"], function (workSpace) {
                    workSpaceUIModel = workSpaceFactory.getworkSpaceUI(workSpace);
                    //$scope.workSpaceList.push(workSpaceUIModel);

                    if (SelectedworkSpaceIdListForFilter.length === 0) {
                        $scope.workSpaceList.push(workSpaceUIModel);
                    }
                    else {
                        tempListFilter = $filter('filter')(SelectedworkSpaceIdListForFilter, {
                            Id: workSpaceUIModel.Id
                        }, true);
                        if (tempListFilter.length === 0) {
                            $scope.workSpaceList.push(workSpaceUIModel);
                        }
                        else {
                            LastAddedSelectedItemWorkSpaceId = $.grep(LastAddedSelectedItemWorkSpaceId,
							   function (item, index) {
							       return item.Id != workSpaceUIModel.Id;
							   });

                            tempListFilter[0].Author = workSpaceUIModel.Author//.user_id_ex;
                            tempListFilter[0].Class = workSpaceUIModel.Class;
                            tempListFilter[0].CreateDate = workSpaceUIModel.CreateDate;
                            tempListFilter[0].Custom1 = workSpaceUIModel.Custom1;
                            tempListFilter[0].Custom2 = workSpaceUIModel.Custom2;
                            tempListFilter[0].Custom3 = workSpaceUIModel.Custom3;
                            tempListFilter[0].Database = workSpaceUIModel.Database;
                            tempListFilter[0].DefaultSecurity = workSpaceUIModel.DefaultSecurity;
                            tempListFilter[0].DocumentNumber = workSpaceUIModel.DocumentNumber;
                            tempListFilter[0].EditDate = workSpaceUIModel.EditDate;
                            tempListFilter[0].EditProfileDate = workSpaceUIModel.EditProfileDate;
                            tempListFilter[0].FileCreateDate = workSpaceUIModel.FileCreateDate;
                            tempListFilter[0].FileEditDate = workSpaceUIModel.FileEditDate;
                            tempListFilter[0].HasAttachment = workSpaceUIModel.HasAttachment;
                            tempListFilter.HasSubfolders = workSpaceUIModel.HasSubfolders;
                            tempListFilter.Id = workSpaceUIModel.Id;

                            tempListFilter[0].Owner = workSpaceUIModel.Owner;
                            tempListFilter[0].RetainDays = workSpaceUIModel.RetainDays;
                            tempListFilter[0].Size = workSpaceUIModel.Size;
                            tempListFilter[0].Subtype = workSpaceUIModel.Subtype;
                            tempListFilter[0].Type = workSpaceUIModel.Type;
                            tempListFilter[0].Version = workSpaceUIModel.Version;
                            tempListFilter[0].Wstype = workSpaceUIModel.Wstype;

                            tempListFilter[0].InUse = workSpaceUIModel.InUse;
                            tempListFilter[0].Operator = workSpaceUIModel.Operator;
                            tempListFilter[0].Name = workSpaceUIModel.Name;
                            tempListFilter[0].Location = workSpaceUIModel.Location;
                            tempListFilter[0].LastUser = workSpaceUIModel.LastUser;
                            tempListFilter[0].Iwl = workSpaceUIModel.Iwl;
                            tempListFilter[0].IsHipaa = workSpaceUIModel.IsHipaa;
                            tempListFilter[0].IsHidden = workSpaceUIModel.IsHidden;
                            tempListFilter[0].IsExternalAsNormal = workSpaceUIModel.IsExternalAsNormal;
                            tempListFilter[0].IsExternal = workSpaceUIModel.IsExternal;
                            tempListFilter[0].IsContentSavedSearch = workSpaceUIModel.IsContentSavedSearch;

                            tempListFilter[0].Indexable = workSpaceUIModel.Indexable;
                            tempListFilter[0].IsCheckedOut = workSpaceUIModel.IsCheckedOut;
                            tempListFilter[0].IsContainerSavedSearch = workSpaceUIModel.IsContainerSavedSearch;

                            filterTempModel = angular.copy(tempListFilter[0]);
                            $scope.workSpaceList.push(filterTempModel);
                            $scope.selected.push(filterTempModel);
                            filterTempModel = null;
                        }
                        tempListFilter = [];
                    }
                    workSpaceUIModel = null;
                });
                //lastAppendItemCount = 0;
                //if ($scope.appsVar.SearchText.length === 0 && !isValidFilterFind()) {
                //    angular.forEach(LastAddedSelectedItemWorkSpaceId, function (worksSpace) {
                //        filterTempModel = angular.copy(worksSpace);
                //        $scope.workSpaceList.push(filterTempModel);
                //        $scope.selected.push(filterTempModel);
                //        filterTempModel = null;
                //        lastAppendItemCount += 1;
                //    });
                //}

                if ($scope.selected.length > 0) {
                    setContextMenuObject();
                }
                $scope.IsShowWorkspaceList = true;
                $mdDialog.hide();

            } else {
                $mdDialog.hide();
                $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                if (response.data && response.data.details && response.data.details.message) {
                    $mdDialog.show($mdDialog.alert()
						.parent(angular.element(document.body))
						.clickOutsideToClose(true)
						.title('Warning!')
						.textContent(response.data.details.message)
						.ariaLabel('')
						.ok('OK'));
                }
                else {
                    $mdDialog.show($mdDialog.alert()
					   .parent(angular.element(document.body))
					   .clickOutsideToClose(true)
					   .title('Warning!')
					   .textContent(response.data.error.message)
					   .ariaLabel('')
					   .ok('OK'));
                }
            }
            $timeout(function () {
                $('td').filter(function () {
                    if (!$(this).hasClass("md-checkbox-cell")) {
                        if ($(this).text().trim().length === 0) {
                            $(this).html('&nbsp;');
                        }
                    }
                });
                $('md-checkbox').click(function (event) {
                    $('.context-menu-container').remove();
                });
            });

        }, function (response) {
            $mdDialog.hide();
            $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
            if (response && response.data && response.data.details && response.data.details.message) {
                $mdDialog.show($mdDialog.alert()
					.parent(angular.element(document.body))
					.clickOutsideToClose(true)
					.title('Warning!')
					.textContent(response.data.details.message)
					.ariaLabel('')
					.ok('OK'));
                $scope.showSearchProgress = false;
                if (isSearch) $mdDialog.hide();
            }
            else {
                $mdDialog.show($mdDialog.alert()
				   .parent(angular.element(document.body))
				   .clickOutsideToClose(true)
				   .title('Warning!')
				   .textContent(response.data.error.message)
				   .ariaLabel('')
				   .ok('OK'));
                $scope.showSearchProgress = false;
                if (isSearch) $mdDialog.hide();
            }
        });
    }

    function showProgressDialog() {
        $mdDialog.show({
            parent: angular.element(document.body),
            template: '<md-dialog ng-cloak height="100%" style="min-width: 1px !important;"><md-dialog-content><div class="md-dialog-content-clearpadding">' +
              '<md-progress-circular md-mode="indeterminate"></md-progress-circular>' +
              '</div></md-dialog-content></md-dialog>',
            controller: DialogController
        });
    }

    $scope.PageEvents.ShowOnlySelected = function () {
        $scope.vm.viewSelectedOnlyLabel = $scope.vm.viewSelectedOnlyLabel == 'View selected' ? 'Show all' : 'View selected';
    }

    $scope.viewSelectedOnlyLabel = 'View selected';
    $scope.filterSelected = function (selected, field) {
        return function (WorSpace) {
            if ($scope.viewSelectedOnlyLabel == 'Show all') {
                if (selected.length == 0) {
                    $scope.viewSelectedOnlyLabel = 'View selected';
                }
                var items = $filter('filter')(selected, WorSpace, true);
                if (items.length > 0)
                    return true;

                return false;
            } else {
                return true;
            }
        }
    };

    $scope.onTableFilter = function (value, key, isInstantFilter, disablePerformFilter) {

        if (requestModel.filters.length > 0) {
            requestModel.filters = jQuery.grep(requestModel.filters, function (filterItem) {
                return filterItem.FilterKey !== key;
            });
        }
        var filterValueList = [];
        filterValueList[0] = value;

        var filterItem = { 'FilterKey': key, 'FilterValues': filterValueList };
        requestModel.filters.push(filterItem);

        requestModel.pagenumber = 1;
        $scope.query.page = 1;

        if (FilterSearchTimeout) $timeout.cancel(FilterSearchTimeout);

        if (!disablePerformFilter) {
            if (isInstantFilter) {
                getworkSpaces();
            } else {
                FilterSearchTimeout = $timeout(function () {
                    getworkSpaces();
                }, 2000);
            }
        };
    };

    var isSearch = false;

    $scope.$on('Search_Click', function () {
        $scope.Search_Click();
    });

    $scope.Search_Click = function () {
        if ($scope.WorkspaceSearch.Custom1Text.trim().length === 0 && $scope.WorkspaceSearch.Custom2Text.trim().length === 0 &&
           $scope.WorkspaceSearch.DescriptionText.trim().length === 0) {
            SelectedworkSpaceIdListForFilter = [];
        }
        $scope.showWorkspaceSearchFileds = false;
        lastAppendItemCount = 0;
        LastAddedSelectedItemWorkSpaceId = angular.copy(SelectedworkSpaceIdListForFilter);
        $scope.selected = [];
        $scope.workSpaceList = [];
        isSearch = true;
        $scope.SearchCount = 0;
        workSpaceInitalize();
    };

    $scope.SearchCount = 0;

    $scope.SearchIconClicked = function () {
        $scope.showWorkspaceSearchFileds = !$scope.showWorkspaceSearchFileds;
    }

    function workSpaceInitalize() {
        $scope.lastSelectedLibrary = '';
        requestModel.pagenumber = 1;
        $scope.query.page = 1;
        $scope.query.totalCount = 0;

        getworkSpaces();
        //if ($scope.SearchCount > 0 && $scope.showWorkspaceSearchFileds) {
        //$scope.showWorkspaceSearchFileds = false;
        //}
    }

    $scope.query = {
        limit: requestModel.pageLength,
        page: requestModel.pagenumber,
        totalCount: 0
    };

    $scope.onPaginate = function (page, limit) {
        isSearch = false;
        requestModel.pagenumber = page;
        requestModel.pageLength = limit;
        getworkSpaces();
        $scope.promise = $timeout(function () {

        }, 2000);
    };

    $scope.deSelect = function (workSpaceModel) {
        setContextMenuObject();
        if (SelectedworkSpaceIdListForFilter.length > 0) {
            SelectedworkSpaceIdListForFilter = $.grep(SelectedworkSpaceIdListForFilter,
								function (item, index) {
								    return item.Id != workSpaceModel.Id;
								});
        }
        if (SelectedworkSpaceIdListForFilter.length > 0) {
            LastAddedSelectedItemWorkSpaceId = $.grep(LastAddedSelectedItemWorkSpaceId,
								   function (item, index) {
								       return item.Id != workSpaceModel.Id;
								   });
        }
    };

    $scope.onSelect = function (workSpaceModel) {
        setContextMenuObject();
        var tempListFilter = $filter('filter')(SelectedworkSpaceIdListForFilter, {
            Id: workSpaceModel.Id
        }, true);
        if (tempListFilter.length === 0) {
            SelectedworkSpaceIdListForFilter.push(angular.copy(workSpaceModel));
        }
    };

    $scope.loadStuff = function () {
        $scope.promise = $timeout(function () {

        }, 2000);
    };
    var destroybroadCast;
    RegisterInitializeTabContents();

    $scope.$on('RegisterInitializeTabContents', function () {
        if (angular.isFunction(destroybroadCast))
            destroybroadCast();

        RegisterInitializeTabContents();
    });
    function RegisterInitializeTabContents() {
        var destroybroadCast = $scope.$on('InitializeTabContents', function () {
            $scope.selected = [];
            $scope.workSpaceList = [];
            $scope.lastSelectedLibrary = '';
            requestModel.pagenumber = 1;
            $scope.query.page = 1;
            $scope.query.totalCount = 0;
            //workSpaceInitalize();
            $scope.IsShowWorkspaceList = false;
            setCustom1Caption();
            setCustom2Caption();
            $scope.WorkspaceSearch.Custom1Text = '';
            $scope.WorkspaceSearch.Custom2Text = '';
            t = $scope.WorkspaceSearch.DescriptionText = '';
            if ($scope.vm.selectedApp.NoAppsPermission.trim().length > 0)
                return;
            if (!$scope.vm.selectedLibrary || $scope.vm.selectedLibrary.trim().length == 0)
                return;
            destroybroadCast();
        });
    }

    $scope.ContextMenuFunctions = {
        CheckUserAccess: function () {
            openWorkspaceAccess();
        }
    };

    function setContextMenuObject() {
        if ($scope.selected !== undefined && $scope.selected.length > 0) {
            if ($scope.selected.length == 1) {

            } else {

            }

            $scope.menuList = [
					{
					    Label: 'Check Effective Access',
					    Icon: 'icon-workspace-security',
					    onClick: $scope.ContextMenuFunctions.CheckUserAccess,
					    Enable: $scope.selected.length == 1,
					    IconType: 'font-icon'
					}];
        }
    }

    $scope.WorkspaceSearch = {
        Custom1Caption: '',
        Custom2Caption: '',
        Custom1Text: '',
        Custom2Text: '',
        DescriptionText: ''
    };

    function setCustom1Caption() {
        var selectedNextDisplayText = $filter('filter')($scope.metaDataList, { MetaDataItem: 'CUSTOM1' }, true);
        $scope.WorkspaceSearch.Custom1Caption = selectedNextDisplayText[0].DisplayText;
    }

    function setCustom2Caption() {
        var selectedNextDisplayText = $filter('filter')($scope.metaDataList, { MetaDataItem: 'CUSTOM2' }, true);
        $scope.WorkspaceSearch.Custom2Caption = selectedNextDisplayText[0].DisplayText;
    }
    setCustom1Caption();
    setCustom2Caption();

    $scope.$on('$destroy', function () {
        $scope.PageEvents.Add = 'undefined';
        $scope.PageEvents.Edit = 'undefined';
        $scope.PageEvents.Save = 'undefined';
        $scope.PageEvents.Delete = 'undefined';
        $scope.PageEvents.CancelDialog = 'undefined';
        $scope.PageEvents.ShowSubclassList = 'undefined';
        $scope.PageEvents.AddRole = 'undefined';
        $scope.PageEvents.ResetPasswordclicked = 'undefined';
        $scope.PageEvents.ViewAssignUser = 'undefined';
        $scope.PageEvents.AssignUser = 'undefined';
        $scope.PageEvents.AssignGroup = 'undefined';
        $scope.PageEvents.ShowOnlySelected = 'undefined';
    });

    function openWorkspaceAccess() {
        $scope.PageEvents.UserAction = 'Check Workspace Access';

        var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
        $mdDialog.show({
            controller: WorkspaceAccessDialogController,
            preserveScope: false,
            templateUrl: 'Views/WorkspaceAccess.html',
            parent: angular.element(document.body),
            clickOutsideToClose: true,
            fullscreen: useFullScreen,
            bindToController: true,
            locals: {
                parentScope: $scope
            }
        })
		.then(function (answer) {
		}, function () {
		});
        $scope.$watch(function () {
            return $mdMedia('xs') || $mdMedia('sm');
        }, function (wantsFullScreen) {
            $scope.customFullscreen = (wantsFullScreen === true);
        });
    };

    function DialogController($scope, $mdDialog) {
        $scope.hide = function () {
            $mdDialog.hide();
        };
        $scope.cancel = function () {
            $mdDialog.cancel();
        };
        $scope.answer = function () {
            $mdDialog.hide();
        };
    }

    $scope.PageEvents.CancelDialog = function () {
        $mdDialog.cancel();
    };

    function WorkspaceAccessDialogController($scope, $mdDialog, parentScope) {
        $scope.hide = function () {
            $mdDialog.hide();
        };
        $scope.cancel = function () {
            $mdDialog.cancel();
        };
        $scope.answer = function () {
            $mdDialog.hide();
        };

        $scope.IsLoading = false;
        $scope.IsShowErrorMsg = false;
        $scope.SelectedUserId = '';
        $scope.SearchText = '';

        $scope.workspace = angular.copy(parentScope.selected[0]);
        $scope.WorkspaceAccessList = [];
        var accessRequestModel = homeFactory.requestModelInstance();

        $scope.userQuerySearch = function (query) {
            $scope.IsShowErrorMsg = false;
            $scope.IsLoading = false;
            var userList = [];
            var deferred = $q.defer();

            if (parentScope.vm.selectedApp.NoAppsPermission.trim().length > 0)
                return;
            if (!parentScope.vm.selectedLibrary || parentScope.vm.selectedLibrary.trim().length == 0)
                return;

            var userRequestModel = homeFactory.requestModelInstance();
            userRequestModel.libraryName = parentScope.vm.selectedLibrary;
            userRequestModel.searchText = query;
            var apiUrl = userFactory.getAPIUrl('SEARCHUSERS', userRequestModel);
            parentScope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(apiUrl));
            var promise = UserService.getUsers(apiUrl, parentScope.mc.loginModel.AuthKey)
            promise.then(function (response) {
                if (response["status"] == 200) {
                    parentScope.mc.getlogDetails("Info", "Received users details.");
                    deferred.resolve(userList);
                    angular.forEach(response["data"]["data"], function (user) {
                        userList.push(user[CONST_USERS.UserId]);
                    });
                } else {
                    parentScope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                }
            }, function (response) {
                parentScope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
            });
            return deferred.promise;
        };

        $scope.UserSelected = function () {
            $scope.WorkspaceAccessList = [];
            $scope.IsShowErrorMsg = false;
            $scope.IsLoading = false;

            if (!$scope.SelectedUserId || $scope.SelectedUserId.trim().length == 0) {
                //$scope.ErrorMessage = 'Please select user.';
                //$scope.IsShowErrorMsg = true;
                return;
            }
            getWorkspaceAccessList();
        };
        $scope.WorkspaceCheckAccessButtonChange = function ($event) {
            if ($event.keyCode === 9) {
                $event.preventDefault();
                $("#UserId").focus();

            }
            return false;
        }

        function getWorkspaceAccessList() {
            var WorkspaceAccess = workSpaceFactory.workSpaceSecurityInitailValues();

            if (parentScope.vm.selectedApp.NoAppsPermission.trim().length > 0)
                return;
            if (!parentScope.vm.selectedLibrary || parentScope.vm.selectedLibrary.trim().length == 0)
                return;

            accessRequestModel.libraryName = parentScope.vm.selectedLibrary;
            accessRequestModel.WorkspaceId = $scope.workspace.Id;
            accessRequestModel.UserId = $scope.SelectedUserId;

            $scope.IsLoading = true;
            $scope.IsShowErrorMsg = true;
            var accessApiUrl = workSpaceFactory.getAPIUrl('CHECKUSERACCESS', accessRequestModel);
            parentScope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(accessApiUrl));
            var promise = WorkSpaceService.getWorkSpaceSecurity(accessApiUrl, parentScope.mc.loginModel.AuthKey)
            promise.then(function (response) {
                if (response.status === 200 && response.data && response.data.data) {
                    parentScope.mc.getlogDetails("Debug", "Received workspace security details.");

                    var access = '';
                    switch (response.data.data.access) {
                        case 'no_access':
                            access = 'No Access';
                            break;

                        case 'read':
                            access = 'Read';
                            break;

                        case 'read_write':
                            access = 'Read Write';
                            break;

                        case 'full_access':
                            access = 'Full Access';
                            break;

                        default:
                            access = '';
                            break;
                    }
                    var userPromise = userFactory.getSingleUser('GETUSER', parentScope.vm.selectedLibrary, $scope.SelectedUserId, parentScope.mc.loginModel.AuthKey);
                    parentScope.mc.getlogDetails("Debug", 'Method:GET;URL:' + 'GETUSER');
                    userPromise.then(function (userResponse) {
                        if (userResponse && userResponse.data && userResponse.data.length > 0) {
                            parentScope.mc.getlogDetails("Debug", "User details fetched.");

                            WorkspaceAccess = workSpaceFactory.workSpaceSecurityInitailValues();
                            WorkspaceAccess.Id = $scope.SelectedUserId;
                            WorkspaceAccess.Name = userResponse.data[0][CONST_USERS.FullName];
                            WorkspaceAccess.AllowLogin = userResponse.data[0][CONST_USERS.IsAllowLogon];
                            WorkspaceAccess.AccessRight = access;
                            $scope.WorkspaceAccessList.push(WorkspaceAccess);
                            $scope.IsShowErrorMsg = false;
                            $scope.IsLoading = false;
                        } else {
                            parentScope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(userResponse));
                            //checkUserAccessInGroup(checkUserAccessResponse);
                            $scope.IsLoading = false;
                        }
                    });
                }
                else {
                    parentScope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                }
            }, function (response) {
                $scope.IsLoading = false;
                parentScope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                $mdDialog.show($mdDialog.alert()
					.parent(angular.element(document.body))
					.clickOutsideToClose(true)
					.title('Warning!')
					.textContent('Failed to retrive workSpaces.')
					.ariaLabel('')
					.ok('OK')
				);
            });
        }

        //function checkUserAccessInGroup(response) {
        //    var groupTempList = $filter('filter')(response["data"]["data"], { type: 'group' }, true);
        //    if (typeof groupTempList != 'undefined' && groupTempList.length > 0) {

        //        var groupIdList = [];
        //        for (iCount = 0; iCount < groupTempList.length; iCount++) {
        //            groupIdList.push(groupTempList[iCount].id);
        //        }

        //        var userGroupListApiUrl = groupFactory.getAPIUrl('GETGROUPSOFUSERFROMGROUPS', groupIdList, $scope.SelectedUserId, parentScope.vm.selectedLibrary);
        //        parentScope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(userGroupListApiUrl));
        //        var promise = GroupService.GetGroupsOfUserFromGroups(userGroupListApiUrl, parentScope.mc.loginModel.AuthKey)
        //        promise.then(function (response) {
        //            if (response && response.status === 200 && response.data && response.data.data && response.data.data.length > 0) {
        //                parentScope.mc.getlogDetails("Info", "Groups list of user fetched.");

        //                var selectedGroup = $filter('filter')(groupTempList, { id: response.data.data[0].group_id }, true);
        //                if (typeof selectedGroup != 'undefined' && selectedGroup.length > 0) {
        //                    parentScope.mc.getlogDetails("Debug", 'Method:GET;URL:' + 'GETUSER');
        //                    var userPromise = userFactory.getSingleUser('GETUSER', parentScope.vm.selectedLibrary, $scope.SelectedUserId, parentScope.mc.loginModel.AuthKey);
        //                    userPromise.then(function (response) {
        //                        if (response && response.data && response.data.length > 0) {
        //                            parentScope.mc.getlogDetails("Info", "User details fetched.");
        //                            WorkspaceAccess = workSpaceFactory.getWorkspaceSecurityUIModel(selectedGroup[0]);
        //                            WorkspaceAccess.Id = response.data[0][CONST_USERS.UserId];
        //                            WorkspaceAccess.Name = response.data[0][CONST_USERS.FullName];
        //                            WorkspaceAccess.AllowLogin = response.data[0][CONST_USERS.IsAllowLogon];
        //                            $scope.WorkspaceAccessList.push(WorkspaceAccess);
        //                            $scope.IsShowErrorMsg = false;
        //                        } else {
        //                            parentScope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
        //                        }
        //                    }, function (response) {
        //                        parentScope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
        //                    });
        //                }
        //            }
        //            else {
        //                parentScope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
        //            }
        //        }, function (response) {
        //            parentScope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
        //        });
        //    }
        //}
    }
}