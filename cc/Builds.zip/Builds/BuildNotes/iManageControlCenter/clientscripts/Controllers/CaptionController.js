﻿app.controller("CaptionController", CaptionController);
CaptionController.$inject = ['$scope', '$rootScope', 'CaptionService',
		'captionsFactory', '$filter', '$mdDialog', '$mdMedia', '$timeout',
		'homeFactory', 'CONST_CAPTIONS', 'userFactory', '$q'];

function CaptionController($scope, $rootScope, CaptionService, captionsFactory,
		$filter, $mdDialog, $mdMedia, $timeout, homeFactory, CONST_CAPTIONS, userFactory, $q) {


    $scope.loading = true;
    $scope.showValidation = false;
    $scope.ShowWarning = false;
    $scope.ErrorMessage = '';
    $scope.SearchValue = null;
    $scope.appsVar.SearchText = '';
    $scope.lastSelectedLibrary = '';

    $scope.CaptionModel = captionsFactory.captionInitialValues();

    var requestModel = homeFactory.requestModelInstance();
    var FilterSearchTimeout;
    var selectedRowIndex = -1;

    $scope.CaptionDetails = [];
    $scope.PageEvents.Add = undefined;
    $scope.PageEvents.Edit = 'undefined';
    $scope.PageEvents.Delete = 'undefined';
    RegisterInitializeTabContents();
    var destroybroadCast;
    $scope.$on('RegisterInitializeTabContents', function () {
        if (angular.isFunction(destroybroadCast))
            destroybroadCast();

        RegisterInitializeTabContents();
    });
    function RegisterInitializeTabContents() {
        var destroybroadCast = $scope.$on('InitializeTabContents', function () {
            Initalize();
            $scope.selected = [];
            $scope.CaptionDetails = [];

            if ($scope.vm.selectedApp.NoAppsPermission.trim().length > 0)
                return;
            if (!$scope.vm.selectedLibrary || $scope.vm.selectedLibrary.trim().length == 0)
                return;
            destroybroadCast();
        });
    }

    $scope.ContextMenuFunctions = {
        Edit: function () {
            CaptionEditFunction();
        }
    }

    function setContextMenuObject() {

        $scope.menuList = [
				{
				    Label: 'Edit',
				    Icon: 'icon-edit',
				    onClick: $scope.ContextMenuFunctions.Edit,
				    Enable: $scope.selected.length == 1,
				    IconType: 'font-icon'
				}
        ];
    }
    function Initalize() {
        requestModel.pagenumber = 1;
        $scope.query.totalCount = 0;
        $scope.query.page = 1;
        lastAppendItemCount = 0;
        getCaptions();
    }

    $timeout(function () {
        $(window).scrollTop(0);
    });

    $scope.$on('Window_Scrolled', function () {
        if ($scope.query.totalCount > $scope.CaptionDetails.length) {
            requestModel.pagenumber++;
            getCaptions();
        }
    });



    function getCaptions() {

        if (!$scope.vm.selectedLibrary || $scope.vm.selectedLibrary.trim().length == 0)
            return;
        requestModel.libraryName = $scope.vm.selectedLibrary;
        requestModel.isTotal = true;
        requestModel.searchText = $scope.appsVar.SearchText;
        requestModel.locale = 1033;

        if (isSearch) {
            //  $scope.showSearchProgress = true;
            showProgressDialog();
        }
        var apiUrl = captionsFactory.getAPIUrl('SEARCHCAPTIONS', requestModel)
        $scope.mc.getlogDetails("Debug", 'Requested Api Url:' + JSON.stringify(apiUrl));
        var Caption = CaptionService.getCaptions(apiUrl, $scope.mc.loginModel.AuthKey);
        Caption.then(function (response) {
            $scope.appsVar.initialLoading = false;
            if (response) {

                if (response["status"] == 200) {
                    $scope.mc.getlogDetails("Info", 'GET Url:' + JSON.stringify(apiUrl));

                    $scope.query.totalCount = response["data"]["total_count"];
                    var tempListFilter = [];
                    var captionUIModel;
                    var filterTempModel;
                    if (lastAppendItemCount > 0) {
                        $scope.CaptionDetails.splice($scope.CaptionDetails.length - lastAppendItemCount, lastAppendItemCount);
                        $scope.selected.splice($scope.selected.length - lastAppendItemCount, lastAppendItemCount);
                    }
                    angular.forEach(response["data"]["data"], function (caption) {
                        captionUIModel = captionsFactory.getCaptionUI(caption)
                        if (SelectedCaptionListForFilter.length === 0) {
                            $scope.CaptionDetails.push(captionUIModel);
                        }
                        else {
                            tempListFilter = $filter('filter')(SelectedCaptionListForFilter, {
                                MetaDataItem: captionUIModel.MetaDataItem
                            }, true);
                            if (tempListFilter.length === 0) {
                                $scope.CaptionDetails.push(captionUIModel);
                            }
                            else {
                                LastAddedSelectedItemCaptionId = $.grep(LastAddedSelectedItemCaptionId,
                                   function (item, index) {
                                       return item.MetaDataItem != captionUIModel.MetaDataItem;
                                   });
                                tempListFilter[0].DisplayText = captionUIModel.DisplayText;
                                tempListFilter[0].MetaDataItem = captionUIModel.MetaDataItem;
                                tempListFilter[0].isMetaItem = captionUIModel.isMetaItem;
                                tempListFilter[0].ParentMetaItem = captionUIModel.ParentMetaItem;
                                tempListFilter[0].Locale = captionUIModel.Locale;
                                filterTempModel = angular.copy(tempListFilter[0]);
                                $scope.CaptionDetails.push(filterTempModel);
                                $scope.selected.push(filterTempModel);
                                filterTempModel = null;
                            }
                            tempListFilter = [];

                        }
                        captionUIModel = null;
                    });
                    lastAppendItemCount = 0;
                    if ($scope.appsVar.SearchText.length === 0 && !isValidFilterFind()) {
                        angular.forEach(LastAddedSelectedItemCaptionId, function (caption) {
                            filterTempModel = angular.copy(caption);
                            $scope.CaptionDetails.push(filterTempModel);
                            $scope.selected.push(filterTempModel);
                            filterTempModel = null;
                            lastAppendItemCount += 1;
                        });
                    }
                }
                $scope.showSearchProgress = false;
                if (isSearch) $mdDialog.hide();

            }
            $scope.vm.selectedApp.ResponseCount = $scope.CaptionDetails.length;

        }, function (response) {

            //$scope.mc.setSecurityLogDetails("Error", 'Method:GET;URL:' + JSON.stringify(apiUrl)+",Response:"+JSON.stringify(response));
            $scope.mc.getlogDetails("Error", 'Method:GET;URL:' + JSON.stringify(apiUrl) + ",Response:" + JSON.stringify(response));

            $mdDialog.show(
					$mdDialog.alert()
					.parent(angular.element(document.body))
					.clickOutsideToClose(true)
					.title('Warning!')
					.textContent('Failed to retrive Captions.')
					.ariaLabel('Warning!')
					.ok('OK')
			);
            $scope.showSearchProgress = false;
            if (isSearch) $mdDialog.hide();
        });
        $scope.showSearchProgress = false;
        if (isSearch) $mdDialog.hide();
    }

    $scope.select = function (item, $event) {
        if ($event.ctrlKey) {
            item.selected ? item.selected = false : item.selected = true;
            $scope.PageEvents.Edit = 'undefined';
        } else {
            this.getAllSelectedRows(item);
            $scope.PageEvents.Edit = CaptionEditFunction;

        }
        setContextMenuObject();
    };

    var isSearch = false;

    $scope.$on('Search_Click', function (event, args) {
        search_Click();
    });
    function search_Click() {

        LastAddedSelectedItemCaptionId = angular.copy(SelectedCaptionListForFilter);
        $scope.selected = [];
        $scope.CaptionDetails = [];
        isSearch = true;
        Initalize();
        lastAppendItemCount = 0;
    }


    $scope.validation = {
        showMessage: false
    };

    $scope.EditCaption = function () {
        $scope.posting = true;
        $scope.validation.showMessage = true;
        $scope.ShowWarning = false;

        if ($scope.CaptionModel.DisplayText == '' || !$scope.CaptionModel.DisplayText) {
            return;
        }
        var apiUrl = captionsFactory
				.getAPIUrl('POSTCAPTIONS', $scope.CaptionModel)
        var requestBody = captionsFactory.getCaptionPostModel($scope.CaptionModel, $scope.vm.selectedLibrary);
        $scope.mc.getlogDetails("Debug", 'Requested Api Url:' + JSON.stringify(apiUrl) + 'Requested Body:' + JSON.stringify(requestBody));

        var UpdateData = CaptionService.editCaptions(requestBody, apiUrl, $scope.mc.loginModel.AuthKey);
        UpdateData.then(function (response) {
            if (response.statusText = 'OK') {
                $scope.mc.setSecurityLogDetails("Info", 'Success', $scope.CaptionModel.MetaDataItem, 'Caption Edit', JSON.stringify(requestBody));

                var filteredCaptionList = $filter('filter')($scope.appsVar.CaptionsList,
						{ MetaDataItem: $scope.CaptionModel.MetaDataItem }, true);
                if (filteredCaptionList && filteredCaptionList.length > 0) {
                    filteredCaptionList[0].DisplayText = $scope.CaptionModel.DisplayText;
                }
                $scope.dialogPopup.CallbackFunction = function () {
                    $mdDialog.hide();
                }
                $scope.dialogPopup.Header = 'Success';
                $scope.dialogPopup.Message = 'Caption edited succesfully.';
                $scope.dialogPopup.Show();
                $scope.showValidation = false;
                $scope.ShowWarning = false;

                $timeout(function () {
                    $scope.dialogPopup.OK();

                }, 2000);

                if (selectedRowIndex >= 0) {
                    $scope.CaptionDetails[selectedRowIndex].DisplayText = $scope.CaptionModel.DisplayText
                }
                var tmpList = [];
                tmpList = angular.copy($scope.CaptionDetails);
                $scope.selected = [];
                $scope.CaptionDetails = [];
                $scope.CaptionDetails = angular.copy(tmpList);
                tmpList = [];
                $scope.CaptionModel = captionsFactory.captionInitialValues();
            } else {
                $scope.ShowWarning = true;
                $scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.CaptionModel.MetaDataItem, 'Caption Edit', JSON.stringify(requestBody));
                if (response && response.data && response.data.details && response.data.details.message) {

                    $scope.ErrorMessage = response.data.details.message;
                }
                else
                    $scope.ErrorMessage = "Caption Updation  failed due to unknown errors";

            }
            $scope.posting = false;
        }, function (response) {
            $scope.ShowWarning = true;
            $scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.CaptionModel.MetaDataItem, 'Caption Edit', JSON.stringify(requestBody));
            if (response && response.data && response.data.details && response.data.details.message) {
                $scope.ErrorMessage = response.data.details.message;
            }
            else
                $scope.ErrorMessage = "Caption Updation  failed due to unknown errors";

        });
    }

    var CaptionEditFunction = function (row) {
        $scope.ShowWarning = false;
        $scope.PageEvents.UserAction = 'Edit';
        $scope.ValidateCaptions = $scope.selected;
        selectedRowIndex = -1;

        var captionID = $scope.appsVar.selectedRecordId;
        $scope.ValidateCaptions = $scope.selected;


        selectedRowIndex = $scope.CaptionDetails.indexOf($scope.selected[0]);
        angular.copy($scope.ValidateCaptions[0], $scope.CaptionModel);
        var useFullScreen = ($mdMedia('sm') || $mdMedia('xs'))
                && $scope.customFullscreen;
        $mdDialog.show({
            controller: DialogController,
            scope: $scope,
            preserveScope: true,
            templateUrl: 'Views/EditCaptions.html',
            parent: angular.element(document.body),
            clickOutsideToClose: true,
            fullscreen: useFullScreen,
            onComplete: function () {
                $("#CaptionForm input[id=caption]").focus();
                $("#CaptionForm input[id=caption]").select();
            }
        }).then(
                function (answer) {
                    $scope.status = '';
                }, function () {
                    $scope.status = '';
                });
        $scope.$watch(function () {
            return $mdMedia('xs') || $mdMedia('sm');
        }, function (wantsFullScreen) {
            $scope.customFullscreen = (wantsFullScreen === true);
        });
        return true;

    }

    $scope.PageEvents.BindLabel = function (data) {

        return 'Save';

    };

    $scope.PageEvents.Save = function () {
        return $scope.EditCaption();
    };

    $scope.PageEvents.CancelDialog = function () {
        $scope.CaptionModel = captionFactory.captionInitialValues();
        $scope.showValidation = false;
        $scope.ShowWarning = false;
    }

    function DialogController($scope, $mdDialog) {
        $scope.hide = function () {
            $mdDialog.hide();
        };
        $scope.cancel = function () {
            $mdDialog.cancel();
        };
        $scope.answer = function () {
            $mdDialog.hide();
        };

        $scope.CaptionsTextChange = CustomCaptionsTextChange;

        function CustomCaptionsTextChange($event) {
            if ($event.keyCode === 13) {
                $event.preventDefault();
            }
        }
    }

    $scope.CaptionButtonChange = function ($event, type) {
        if ($event.keyCode === 9) {
            $event.preventDefault();
            if (type == "Edit") {
                $("#CaptionForm input[id=caption]").focus();
                $("#CaptionForm input[id=caption]").select();
            }
        }
        return false;
    }



    $scope.$on('$destroy', function () {
        $scope.PageEvents.Edit = 'undefined';
        $scope.PageEvents.Save = 'undefined';
        $scope.PageEvents.CancelDialog = 'undefined';
        $scope.PageEvents.ShowOnlySelected = 'undefined';
    });

    $scope.selected = [];

    $scope.query = {
        order: 'name',
        limit: requestModel.pageLength,
        page: requestModel.pagenumber,
        totalCount: 0
    };

    $scope.deSelect = function (captionModel) {
        setContextMenuObject();
        if (SelectedCaptionListForFilter.length > 0) {
            SelectedCaptionListForFilter = $.grep(SelectedCaptionListForFilter,
								function (item, index) {
								    return item.MetaDataItem != captionModel.MetaDataItem;
								});
        }
        if (SelectedCaptionListForFilter.length > 0) {
            LastAddedSelectedItemCaptionId = $.grep(LastAddedSelectedItemCaptionId,
								   function (item, index) {
								       return item.MetaDataItem != captionModel.MetaDataItem;
								   });
        }
    };

    $scope.onSelect = function (captionModel) {
        var tempListFilter = $filter('filter')(SelectedCaptionListForFilter, {
            MetaDataItem: captionModel.MetaDataItem
        }, true);
        if (tempListFilter.length === 0) {
            SelectedCaptionListForFilter.push(angular.copy(captionModel));
        }
        setContextMenuObject();
    };
    $scope.viewSelectedOnlyLabel = 'View selected';
    $scope.filterSelected = function (selected, field) {
        return function (group) {
            if ($scope.viewSelectedOnlyLabel == 'Show all') {
                if (selected.length == 0) {
                    $scope.viewSelectedOnlyLabel = 'View selected';
                }
                var items = $filter('filter')(selected, group, true);
                if (items.length > 0)
                    return true;

                return false;
            } else {
                return true;
            }
        }
    };
    $scope.PageEvents.ShowOnlySelected = function () {
        $scope.vm.viewSelectedOnlyLabel = $scope.vm.viewSelectedOnlyLabel == 'View selected' ? 'Show all' : 'View selected';
    }

    $scope.dialogPopup = {
        Header: '',
        Message: '',
        CallbackFunction: null,
        Show: function () {
            $('#popup-alert-dialog-bg').slideToggle();
        },
        OK: function () {
            $('#popup-alert-dialog-bg').slideToggle();
            $scope.dialogPopup.Header = '';
            $scope.dialogPopup.Message = '';

            if ($scope.dialogPopup.CallbackFunction) {
                $scope.dialogPopup.CallbackFunction();
                $scope.dialogPopup.CallbackFunction = null;
            }
        }
    }
    var SelectedCaptionListForFilter = [];
    var LastAddedSelectedItemCaptionId = [];
    var lastAppendItemCount = 0;
    function showProgressDialog() {
        $mdDialog.show({
            parent: angular.element(document.body),
            template: '<md-dialog ng-cloak height="100%" style="min-width: 1px !important;"><md-dialog-content><div class="md-dialog-content-clearpadding">' +
              '<md-progress-circular md-mode="indeterminate"></md-progress-circular>' +
              '</div></md-dialog-content></md-dialog>',
            controller: DialogController
        });
    }
    function isValidFilterFind() {
        var filterKeyItem = null;
        var blnResult = false;

        for (var iCount = 0; iCount < requestModel.filters.length; iCount++) {
            filterKeyItem = requestModel.filters[iCount];
            if (filterKeyItem.FilterValues && filterKeyItem.FilterValues[0] && filterKeyItem.FilterValues[0].trim().length > 0) {
                blnResult = true;
                break;
            }
            filterKeyItem = null;
        }
        return blnResult;
    }

    $scope.onTableFilter = function (value, key, isInstantFilter, disablePerformFilter) {

        if (requestModel.filters.length > 0) {
            requestModel.filters = jQuery.grep(requestModel.filters, function (filterItem) {
                return filterItem.FilterKey !== key;
            });
        }

        var filterValueList = [];
        filterValueList[0] = value;

        var filterItem = { 'FilterKey': key, 'FilterValues': filterValueList };
        requestModel.filters.push(filterItem);

        requestModel.pagenumber = 1;
        $scope.query.page = 1;
        $scope.query.totalCount = 0;

        if (FilterSearchTimeout) $timeout.cancel(FilterSearchTimeout);

        if (!disablePerformFilter) {
            if (isInstantFilter) {
                search_Click();
            } else {
                FilterSearchTimeout = $timeout(function () {
                    search_Click();
                }, 2000);
            }
        }
    };


}