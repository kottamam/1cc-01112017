﻿app.controller("TemplateController", TemplateController);

TemplateController.$inject = ['$scope', '$rootScope', '$filter', '$timeout', '$log', '$mdDialog', '$mdMedia', 'TemplateService', 'TemplateFactory', 'homeFactory', '$q'];

function TemplateController($scope, $rootScope, $filter, $timeout, $log, $mdDialog, $mdMedia, TemplateService, TemplateFactory, homeFactory, $q) {

    $scope.PageEvents.Add = undefined;
    $scope.selected = [];
    $scope.workSpaceList = [];
    $scope.appsVar.SearchText = '';
    $scope.SelectedTemplateModel = TemplateFactory.workSpaceInitailValues();
    var selectedRowIndex = -1;

    var FilterSearchTimeout;
    var requestModel = homeFactory.requestModelInstance();

    $scope.$on('Window_Scrolled', function () {
        if ($scope.query.totalCount > $scope.workSpaceList.length) {
            requestModel.pagenumber++;
            getworkSpaces();
        }
    });
    var SelectedworkSpaceIdListForFilter = [];
    var LastAddedSelectedItemWorkSpaceId = [];
    var lastAppendItemCount = 0;
    var FolderListSearchTimeOut = null;
    var isFolderListSearchTextDirty = false;
    var isFolderListInstantSearch = false;
    $timeout(function () {
        $(window).scrollTop(0);
    });

    function getworkSpaces() {
        if ($scope.vm.selectedApp.NoAppsPermission.trim().length > 0)
            return;
        if (!$scope.vm.selectedLibrary || $scope.vm.selectedLibrary.trim().length == 0)
            return;

        $scope.IsShowWorkspaceList = false;

        showProgressDialog();
        $scope.lastSelectedLibrary = $scope.vm.selectedLibrary;
        requestModel.libraryName = $scope.vm.selectedLibrary;
        requestModel.searchText = $scope.appsVar.SearchText;

        var apiUrl = TemplateFactory.getAPIUrl('SEARCHWORKSPACE', requestModel);
        $scope.mc.getlogDetails("Debug", 'Method:GET;URL' + JSON.stringify(apiUrl));
        var promise = TemplateService.getWorkSpaces(apiUrl, $scope.mc.loginModel.AuthKey)
        promise.then(function (response) {
            if (response["status"] == 200) {
                $scope.mc.getlogDetails("Info", "Received workspace details.");
                $scope.query.totalCount = response["data"]["total_count"];
                var tempListFilter = [];
                var workSpaceUIModel;
                var filterTempModel;
                //if (lastAppendItemCount > 0) {
                //    $scope.workSpaceList.splice($scope.workSpaceList.length - lastAppendItemCount, lastAppendItemCount);
                //    $scope.selected.splice($scope.selected.length - lastAppendItemCount, lastAppendItemCount);
                //}
                angular.forEach(response["data"]["data"], function (workSpace) {
                    workSpaceUIModel = TemplateFactory.getworkSpaceUI(workSpace);
                    //$scope.workSpaceList.push(workSpaceUIModel);

                    if (SelectedworkSpaceIdListForFilter.length === 0) {
                        $scope.workSpaceList.push(workSpaceUIModel);
                    }
                    else {
                        tempListFilter = $filter('filter')(SelectedworkSpaceIdListForFilter, {
                            Id: workSpaceUIModel.Id
                        }, true);
                        if (tempListFilter.length === 0) {
                            $scope.workSpaceList.push(workSpaceUIModel);
                        }
                        else {
                            LastAddedSelectedItemWorkSpaceId = $.grep(LastAddedSelectedItemWorkSpaceId,
							   function (item, index) {
							       return item.Id != workSpaceUIModel.Id;
							   });

                            tempListFilter[0].Author = workSpaceUIModel.Author//.user_id_ex;
                            tempListFilter[0].Class = workSpaceUIModel.Class;
                            tempListFilter[0].CreateDate = workSpaceUIModel.CreateDate;
                            tempListFilter[0].Custom1 = workSpaceUIModel.Custom1;
                            tempListFilter[0].Custom2 = workSpaceUIModel.Custom2;
                            tempListFilter[0].Custom3 = workSpaceUIModel.Custom3;
                            tempListFilter[0].Database = workSpaceUIModel.Database;
                            tempListFilter[0].DefaultSecurity = workSpaceUIModel.DefaultSecurity;
                            tempListFilter[0].DocumentNumber = workSpaceUIModel.DocumentNumber;
                            tempListFilter[0].EditDate = workSpaceUIModel.EditDate;
                            tempListFilter[0].EditProfileDate = workSpaceUIModel.EditProfileDate;
                            tempListFilter[0].FileCreateDate = workSpaceUIModel.FileCreateDate;
                            tempListFilter[0].FileEditDate = workSpaceUIModel.FileEditDate;
                            tempListFilter[0].HasAttachment = workSpaceUIModel.HasAttachment;
                            tempListFilter.HasSubfolders = workSpaceUIModel.HasSubfolders;
                            tempListFilter.Id = workSpaceUIModel.Id;

                            tempListFilter[0].Owner = workSpaceUIModel.Owner;
                            tempListFilter[0].RetainDays = workSpaceUIModel.RetainDays;
                            tempListFilter[0].Size = workSpaceUIModel.Size;
                            tempListFilter[0].Subtype = workSpaceUIModel.Subtype;
                            tempListFilter[0].Type = workSpaceUIModel.Type;
                            tempListFilter[0].Version = workSpaceUIModel.Version;
                            tempListFilter[0].Wstype = workSpaceUIModel.Wstype;

                            tempListFilter[0].InUse = workSpaceUIModel.InUse;
                            tempListFilter[0].Operator = workSpaceUIModel.Operator;
                            tempListFilter[0].Name = workSpaceUIModel.Name;
                            tempListFilter[0].Location = workSpaceUIModel.Location;
                            tempListFilter[0].LastUser = workSpaceUIModel.LastUser;
                            tempListFilter[0].Iwl = workSpaceUIModel.Iwl;
                            tempListFilter[0].IsHipaa = workSpaceUIModel.IsHipaa;
                            tempListFilter[0].IsHidden = workSpaceUIModel.IsHidden;
                            tempListFilter[0].IsExternalAsNormal = workSpaceUIModel.IsExternalAsNormal;
                            tempListFilter[0].IsExternal = workSpaceUIModel.IsExternal;
                            tempListFilter[0].IsContentSavedSearch = workSpaceUIModel.IsContentSavedSearch;

                            tempListFilter[0].Indexable = workSpaceUIModel.Indexable;
                            tempListFilter[0].IsCheckedOut = workSpaceUIModel.IsCheckedOut;
                            tempListFilter[0].IsContainerSavedSearch = workSpaceUIModel.IsContainerSavedSearch;

                            filterTempModel = angular.copy(tempListFilter[0]);
                            $scope.workSpaceList.push(filterTempModel);
                            $scope.selected.push(filterTempModel);
                            filterTempModel = null;
                        }
                        tempListFilter = [];
                    }
                    workSpaceUIModel = null;
                });
                //lastAppendItemCount = 0;
                //if ($scope.appsVar.SearchText.length === 0 && !isValidFilterFind()) {
                //    angular.forEach(LastAddedSelectedItemWorkSpaceId, function (worksSpace) {
                //        filterTempModel = angular.copy(worksSpace);
                //        $scope.workSpaceList.push(filterTempModel);
                //        $scope.selected.push(filterTempModel);
                //        filterTempModel = null;
                //        lastAppendItemCount += 1;
                //    });
                //}

                if ($scope.selected.length > 0) {
                    setContextMenuObject();
                }
                $scope.IsShowWorkspaceList = true;
                $mdDialog.hide();

            } else {
                $mdDialog.hide();
                $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                if (response.data && response.data.details && response.data.details.message) {
                    $mdDialog.show($mdDialog.alert()
						.parent(angular.element(document.body))
						.clickOutsideToClose(true)
						.title('Warning!')
						.textContent(response.data.details.message)
						.ariaLabel('')
						.ok('OK'));
                }
                else {
                    $mdDialog.show($mdDialog.alert()
					   .parent(angular.element(document.body))
					   .clickOutsideToClose(true)
					   .title('Warning!')
					   .textContent(response.data.error.message)
					   .ariaLabel('')
					   .ok('OK'));
                }
            }
            $timeout(function () {
                $('td').filter(function () {
                    if (!$(this).hasClass("md-checkbox-cell")) {
                        if ($(this).text().trim().length === 0) {
                            $(this).html('&nbsp;');
                        }
                    }
                });
                $('md-checkbox').click(function (event) {
                    $('.context-menu-container').remove();
                });
            });

        }, function (response) {
            $mdDialog.hide();
            $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
            if (response && response.data && response.data.details && response.data.details.message) {
                $mdDialog.show($mdDialog.alert()
					.parent(angular.element(document.body))
					.clickOutsideToClose(true)
					.title('Warning!')
					.textContent(response.data.details.message)
					.ariaLabel('')
					.ok('OK'));
                $scope.showSearchProgress = false;
                if (isSearch) $mdDialog.hide();
            }
            else {
                $mdDialog.show($mdDialog.alert()
				   .parent(angular.element(document.body))
				   .clickOutsideToClose(true)
				   .title('Warning!')
				   .textContent(response.data.error.message)
				   .ariaLabel('')
				   .ok('OK'));
                $scope.showSearchProgress = false;
                if (isSearch) $mdDialog.hide();
            }
        });
    }

    function showProgressDialog() {
        $mdDialog.show({
            parent: angular.element(document.body),
            template: '<md-dialog ng-cloak height="100%" style="min-width: 1px !important;"><md-dialog-content><div class="md-dialog-content-clearpadding">' +
              '<md-progress-circular md-mode="indeterminate"></md-progress-circular>' +
              '</div></md-dialog-content></md-dialog>',
            controller: DialogController
        });
    }

    $scope.PageEvents.ShowOnlySelected = function () {
        $scope.vm.viewSelectedOnlyLabel = $scope.vm.viewSelectedOnlyLabel == 'View selected' ? 'Show all' : 'View selected';
    }

    $scope.viewSelectedOnlyLabel = 'View selected';
    $scope.filterSelected = function (selected, field) {
        return function (WorSpace) {
            if ($scope.viewSelectedOnlyLabel == 'Show all') {
                if (selected.length == 0) {
                    $scope.viewSelectedOnlyLabel = 'View selected';
                }
                var items = $filter('filter')(selected, WorSpace, true);
                if (items.length > 0)
                    return true;

                return false;
            } else {
                return true;
            }
        }
    };

    $scope.onTableFilter = function (value, key, isInstantFilter, disablePerformFilter) {

        if (requestModel.filters.length > 0) {
            requestModel.filters = jQuery.grep(requestModel.filters, function (filterItem) {
                return filterItem.FilterKey !== key;
            });
        }
        var filterValueList = [];
        filterValueList[0] = value;

        var filterItem = { 'FilterKey': key, 'FilterValues': filterValueList };
        requestModel.filters.push(filterItem);

        requestModel.pagenumber = 1;
        $scope.query.page = 1;

        if (FilterSearchTimeout) $timeout.cancel(FilterSearchTimeout);

        if (!disablePerformFilter) {
            if (isInstantFilter) {
                getworkSpaces();
            } else {
                FilterSearchTimeout = $timeout(function () {
                    getworkSpaces();
                }, 2000);
            }
        };
    };

    var isSearch = false;

    $scope.$on('Search_Click', function () {
        $scope.Search_Click();
    });

    $scope.Search_Click = function () {
        $scope.showWorkspaceSearchFileds = false;
        lastAppendItemCount = 0;
        LastAddedSelectedItemWorkSpaceId = angular.copy(SelectedworkSpaceIdListForFilter);
        $scope.selected = [];
        $scope.workSpaceList = [];
        isSearch = true;
        workSpaceInitalize();
    };

    $scope.SearchIconClicked = function () {
        $scope.showWorkspaceSearchFileds = !$scope.showWorkspaceSearchFileds;
    }

    $scope.query = {
        limit: requestModel.pageLength,
        page: requestModel.pagenumber,
        totalCount: 0
    };

    workSpaceInitalize();

    function workSpaceInitalize() {
        $scope.lastSelectedLibrary = '';
        requestModel.pagenumber = 1;
        $scope.query.page = 1;
        $scope.query.totalCount = 0;

        getworkSpaces();
    }

    $scope.onPaginate = function (page, limit) {
        isSearch = false;
        requestModel.pagenumber = page;
        requestModel.pageLength = limit;
        getworkSpaces();
        $scope.promise = $timeout(function () {

        }, 2000);
    };

    $scope.deSelect = function (workSpaceModel) {
        setContextMenuObject();
        if (SelectedworkSpaceIdListForFilter.length > 0) {
            SelectedworkSpaceIdListForFilter = $.grep(SelectedworkSpaceIdListForFilter,
								function (item, index) {
								    return item.Id != workSpaceModel.Id;
								});
        }
        if (SelectedworkSpaceIdListForFilter.length > 0) {
            LastAddedSelectedItemWorkSpaceId = $.grep(LastAddedSelectedItemWorkSpaceId,
								   function (item, index) {
								       return item.Id != workSpaceModel.Id;
								   });
        }
    };

    $scope.onSelect = function (workSpaceModel) {
        setContextMenuObject();
        var tempListFilter = $filter('filter')(SelectedworkSpaceIdListForFilter, {
            Id: workSpaceModel.Id
        }, true);
        if (tempListFilter.length === 0) {
            SelectedworkSpaceIdListForFilter.push(angular.copy(workSpaceModel));
        }
    };

    $scope.loadStuff = function () {
        $scope.promise = $timeout(function () {

        }, 2000);
    };
    var destroybroadCast;
    RegisterInitializeTabContents();

    $scope.$on('RegisterInitializeTabContents', function () {
        if (angular.isFunction(destroybroadCast))
            destroybroadCast();

        RegisterInitializeTabContents();
    });
    function RegisterInitializeTabContents() {
        var destroybroadCast = $scope.$on('InitializeTabContents', function () {
            $scope.selected = [];
            $scope.workSpaceList = [];
            $scope.lastSelectedLibrary = '';
            requestModel.pagenumber = 1;
            $scope.query.page = 1;
            $scope.query.totalCount = 0;
            $scope.showSelectedTemplateDetails = false;
            if ($scope.vm.selectedApp.NoAppsPermission.trim().length > 0)
                return;
            if (!$scope.vm.selectedLibrary || $scope.vm.selectedLibrary.trim().length == 0)
                return;
            destroybroadCast();
        });
    }

    $scope.ContextMenuFunctions = {
        Edit: function () {
            TemplateEditFunction();
        },
        Delete: function () {
            $scope.PageEvents.Delete();
        },
        AddFolder: function () {
            //AssignUserFunction();
        },
        Tab: function () {
            //AssignUserFunction();
        },
        Export: function () {
            //AssignUserFunction();
        }
    };

    function setContextMenuObject() {
        if ($scope.selected !== undefined && $scope.selected.length > 0) {
            $scope.menuList = [
                 {
                     Label: 'Export',
                     Icon: 'icon-export',
                     onClick: $scope.ContextMenuFunctions.Export,
                     Enable: $scope.selected.length == 1,
                     IconType: 'font-icon'
                 },
                {
                    Label: 'Delete',
                    Icon: 'icon-delete',
                    onClick: $scope.ContextMenuFunctions.Delete,
                    Enable: $scope.selected.length == 1,
                    IconType: 'font-icon'
                },
                {
                    Label: 'Edit',
                    Icon: 'icon-edit',
                    onClick: $scope.ContextMenuFunctions.Edit,
                    Enable: $scope.selected.length == 1,
                    IconType: 'font-icon'

                },
                 {
                     Label: 'Tab',
                     Icon: 'icon-add-tab',
                     onClick: $scope.ContextMenuFunctions.Tab,
                     Enable: $scope.selected.length == 1,
                     IconType: 'font-icon'
                 }

            ];
        }
    }

    var TemplateEditFunction = function (row) {
        $scope.ShowWarning = false;
        $scope.PageEvents.UserAction = 'Edit';
        selectedRowIndex = -1;

        var captionID = $scope.appsVar.selectedRecordId;
        $scope.ValidateTemplate = $scope.selected;


        selectedRowIndex = $scope.workSpaceList.indexOf($scope.selected[0]);
        angular.copy($scope.ValidateTemplate[0], $scope.TemplateModel);
        var useFullScreen = ($mdMedia('sm') || $mdMedia('xs'))
                && $scope.customFullscreen;
        $mdDialog.show({
            controller: DialogController,
            scope: $scope,
            preserveScope: true,
            templateUrl: 'Views/AddTemplate.html',
            parent: angular.element(document.body),
            clickOutsideToClose: true,
            fullscreen: useFullScreen,
            onComplete: function () {
                $("#CaptionForm input[id=caption]").focus();
                $("#CaptionForm input[id=caption]").select();
            }
        }).then(
                function (answer) {
                    $scope.status = '';
                }, function () {
                    $scope.status = '';
                });
        $scope.$watch(function () {
            return $mdMedia('xs') || $mdMedia('sm');
        }, function (wantsFullScreen) {
            $scope.customFullscreen = (wantsFullScreen === true);
        });
        return true;

    }

    $scope.PageEvents.Delete = function (event) {

        var selectedTemplateList = $scope.selected;

        if (typeof selectedTemplateList !== 'undefined' && selectedTemplateList.length > 0) {
            var confirm = $mdDialog.confirm()
					.title('Warning!')
					.theme('confirm-dialog')
			.textContent('Are you sure you want to delete the selected Template(s)?')
			.ariaLabel('')
			.ok('Yes')
			.cancel('No');
            $mdDialog.show(confirm).then(function () {
                $mdDialog.show(
						$mdDialog.alert()
						.parent(angular.element(document.body))
						.clickOutsideToClose(true)
						.title('Warning!')
						.textContent('Are you sure you want to delete the selected Template(s)?')
						.ariaLabel('Warning!')
						.ok('OK')
				).then(function () {
				    $mdDialog.show(
							$mdDialog.alert()
							.parent(angular.element(document.body))
							.clickOutsideToClose(true)
							.title('Warning!')
							.textContent('Failed to delete selected Template(s).')
							.ariaLabel('Warning!')
							.ok('OK')
					);
				});
            });
        }
        else {
            $mdDialog.show(
					$mdDialog.alert()
					.parent(angular.element(document.body))
					.clickOutsideToClose(true)
					.title('Warning!')
					.textContent('Please select Template(s) to delete.')
					.ariaLabel('Warning!')
					.ok('OK')
			);
        }


    };

    $scope.$on('$destroy', function () {
        $scope.PageEvents.Add = 'undefined';
        $scope.PageEvents.Edit = 'undefined';
        $scope.PageEvents.Save = 'undefined';
        $scope.PageEvents.Delete = 'undefined';
        $scope.PageEvents.CancelDialog = 'undefined';
        $scope.PageEvents.ShowSubclassList = 'undefined';
        $scope.PageEvents.AddRole = 'undefined';
        $scope.PageEvents.ResetPasswordclicked = 'undefined';
        $scope.PageEvents.ViewAssignUser = 'undefined';
        $scope.PageEvents.AssignUser = 'undefined';
        $scope.PageEvents.AssignGroup = 'undefined';
        $scope.PageEvents.ShowOnlySelected = 'undefined';
        $scope.PageEvents.ViewSelected = 'undefined';
    });


    function DialogController($scope, $mdDialog) {
        $scope.hide = function () {
            $mdDialog.hide();
        };
        $scope.cancel = function () {
            $mdDialog.cancel();
        };
        $scope.answer = function () {
            $mdDialog.hide();
        };
    }

    $scope.PageEvents.CancelDialog = function () {
        $mdDialog.cancel();
    };


    $scope.validation = {
        showMessage: false
    }

    $scope.PageEvents.Add = function (event) {
        $scope.PageEvents.UserAction = 'Add';
        $scope.TemplateModel = TemplateFactory.workSpaceInitailValues();
        $scope.ShowWarning = false;
        $scope.validation.showMessage = false;
        var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
        $mdDialog.show({
            // controller: UserController,
            controller: DialogController,
            scope: $scope, // use parent scope in template
            preserveScope: true, // do not forget this if use parent scope
            templateUrl: 'Views/AddTemplate.html',
            parent: angular.element(document.body),
            targetEvent: event,
            clickOutsideToClose: true,
            fullscreen: useFullScreen,
            onComplete: function () {
                $("#GroupForm input[id=GroupName]").focus();
            }

        }).then(function (answer) {
            $scope.status = '';
        }, function () {
            $scope.status = '';
        });
        $scope.$watch(function () {
            return $mdMedia('xs') || $mdMedia('sm');
        }, function (wantsFullScreen) {
            $scope.customFullscreen = (wantsFullScreen === true);
        });
    };


    var TemplateIndex = -1;
    $scope.selectedFolder = [];
    $scope.folders = [];
    $scope.selectedTabs = [];
    $scope.Tabs = [];
    var templateFolderReqModel = homeFactory.requestModelInstance();

    $scope.TabList = {
        SearchText: '',
        SearchClick: TabSearchClick,
        ClearSearchClick: TabClearSearchClick
    };

    function TabSearchClick() {

    }

    function TabClearSearchClick() {
        $scope.TabList.SearchText = '';
    }

    $scope.FolderList = {
        SearchText: '',
        SearchClick: FolderSearchClick,
        ClearSearchClick: FolderClearSearchClick
    };

    function FolderSearchClick() {
        $scope.folders = [];
        if (FolderListSearchTimeOut) $timeout.cancel(FolderListSearchTimeOut);
        var isFolderListSearchTextDirty = false;
        var isFolderListInstantSearch = false;
        templateFolderReqModel = homeFactory.requestModelInstance();
        templateFolderReqModel.Id = SelectedTemplateModel.Id;
        getFoldersFromWorkspace(SelectedTemplateModel, 'GETFOLDERSFROMWORKSPCE');
    }

    function FolderClearSearchClick() {
        isFolderListInstantSearch = true;
        $scope.FolderList.SearchText = '';
    }


    $scope.$watch(function () { return $scope.FolderList.SearchText; }, function (val) {
        if ($scope.FolderList.SearchText.length > 0) {
            isFolderListSearchTextDirty = true;
        }
        if (FolderListSearchTimeOut) $timeout.cancel(FolderListSearchTimeOut);

        if (isFolderListInstantSearch) {
            isFolderListInstantSearch = false;
            FolderSearchClick();
        }
        else {
            FolderListSearchTimeOut = $timeout(function () {
                if (isFolderListSearchTextDirty) {
                    FolderSearchClick();
                }
            }, 2000);
        }
    }, true);



    function getFoldersFromWorkspace(selectedRow) {
        var deferredarray = [];
        var deferred = $q.defer();
        templateFolderReqModel.libraryName = $scope.vm.selectedLibrary;
        templateFolderReqModel.searchText = $scope.FolderList.SearchText;
        templateFolderReqModel.Id = selectedRow.Id;

        var apiUrl = TemplateFactory.getAPIUrl('GETFOLDERSFROMWORKSPCE', templateFolderReqModel);
        $scope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(apiUrl));

        var promise = TemplateService.getFoldersFromWorkspace(apiUrl, $scope.mc.loginModel.AuthKey);
        promise.then(function (response) {
            if (response.status === 200) {
                $scope.folders = [];
                $scope.Tabs = [];
                angular.forEach(response.data.data, function (folder) {
                    if (!folder.subtype) {
                        var folderUIModel = TemplateFactory.getFolderUI(folder);
                        $scope.folders.push(folderUIModel);
                    }
                    //else {
                    //    var folderUIModel = TemplateFactory.getFolderUI(folder);
                    //    $scope.Tabs.push(folderUIModel);
                    //}
                });
                if ($scope.folders.length > 0) {
                    $scope.TemplateFolderHeaderText = $scope.childHeading.heading + " have " + $scope.folders.length + " Folders";
                } else {
                    $scope.TemplateFolderHeaderText = selectedRow.Name + " do not have Folders";
                }
                deferred.resolve(response);
            } else {
                $scope.mc.getlogDetails("Error", 'Method:GET;URL:' + JSON.stringify(apiUrl) + ",Response:" + JSON.stringify(response));

            }
            deferredarray.push(deferred.promise);
        }, function (response) {
            $scope.mc.getlogDetails("Error", 'Method:GET;URL:' + JSON.stringify(apiUrl) + ",Response:" + JSON.stringify(response));
        });
        $q.all(deferredarray).then(function () {
        });
    }

    $scope.parentWorkspaceId = '';
    $scope.parentWorkspaceName = '';
    $scope.childHeading = {
        icon: '',
        heading:''
    };

    $scope.PageEvents.ViewSelected = function (selectedRow, $event) {
        if (!$event.ctrlKey) {
            $scope.parentWorkspaceId = '';
            $scope.selectedFolder = [];
            $scope.folders = [];
            $scope.selectedTabs = [];
            $scope.Tabs = [];
            $scope.navFolderList = [];
            $scope.TabList.SearchText = '';
            $scope.FolderList.SearchText = '';
            $scope.parentWorkspaceId = selectedRow.Id;
            $scope.parentWorkspaceName = selectedRow.Name;
            $scope.childHeading.icon = selectedRow.Wstype;
            $scope.childHeading.heading = selectedRow.Name;
            SelectedTemplateModel = angular.copy(selectedRow);

            getFoldersFromWorkspace(selectedRow);

            $scope.scrollTop = $(window).scrollTop();
            $('.view-details-tab-container md-tabs-content-wrapper').removeClass('fix-title');
            $scope.showSelectedTemplateDetails = true;
            $timeout(function () {
                $(window).scrollTop(0);
            });
        }
    };

    $scope.HideFolderViewSelected = function (sub) {
        if (true) {
            if (sub.HasSubfolders) {
                if ($scope.parentWorkspaceId == sub.ParentId) {
                    $timeout(function () {
                        sub.Id = $scope.parentWorkspaceId;
                        getFoldersFromWorkspace(sub);
                        $scope.navFolderList = [];
                        $scope.childHeading.icon = 'workspace';
                        $scope.childHeading.heading = $scope.parentWorkspaceName;
                        $scope.scrollTop = $(window).scrollTop();
                        $('.view-details-tab-container md-tabs-content-wrapper').removeClass('fix-title');
                        $scope.showSelectedTemplateDetails = true;
                        $timeout(function () {                            
                            $(window).scrollTop(0);
                        });
                    });
                   
                }
                else {
                    $timeout(function () {
                        sub.Id = sub.ParentId;
                        getSubFoldersFromWorkspace(sub);
                        $scope.navFolderList = $.grep($scope.navFolderList,
							   function (item, index) {
							       return item.ParentId != sub.ParentId;
							   });
                        $scope.childHeading.icon = $scope.navFolderList[$scope.navFolderList.length - 1].Wstype;
                        $scope.childHeading.heading = $scope.navFolderList[$scope.navFolderList.length-1].Name;
                        $scope.scrollTop = $(window).scrollTop();
                        $('.view-details-tab-container md-tabs-content-wrapper').removeClass('fix-title');
                        $scope.showSelectedTemplateDetails = true;
                        $timeout(function () {
                            $(window).scrollTop(0);
                        });
                    });
                   
                }
            }
            closeFolderView();
            return;
        }
    };

    function closeFolderView() {
        $scope.selectedFolder = [];
        //$scope.folders = [];
        $scope.selectedTabs = [];
        $scope.Tabs = [];
        $scope.showSelectedTemplateDetails = false;
        if (FolderListSearchTimeOut) $timeout.cancel(FolderListSearchTimeOut);
        isFolderListSearchTextDirty = false;
        isFolderListInstantSearch = false;
        $scope.SelectedTemplateModel = TemplateFactory.workSpaceInitailValues();
        $timeout(function () {
            $(window).scrollTop($scope.scrollTop);
        });

    }

    $scope.HideViewSelected = function () {
        if (!isTemplateEdited()) {
            closeView();
            return;
        }
        //var confirm = $mdDialog.confirm().title('Warning!').theme('confirm-dialog').textContent('Do you want to save the changes?').ariaLabel('Warning!').ok('Yes').cancel('No');

        //$mdDialog.show(confirm).then(function () {
        //    var Promise = $scope.SaveGroupDetails();
        //    Promise.then(function (response) {
        //        if (response.statusText == "OK") {
        //            closeView();
        //        }

        //    });
        //}, function () {
        //    closeView();
        //});
    };

    function isTemplateEdited() {
        //var result = angular.equals($scope.GroupModel, $scope.ViewGroupModel);
        //if (!result) {
        //    return true;
        //}

        //if ($scope.newMembers.length > 0 || $scope.removedMembers.length > 0) {
        //    return true;
        //}
        return false;
    }

    function closeView() {
        $scope.selectedFolder = [];
        $scope.folders = [];
        $scope.selectedTabs = [];
        $scope.Tabs = [];
        $scope.showSelectedTemplateDetails = false;
        if (FolderListSearchTimeOut) $timeout.cancel(FolderListSearchTimeOut);
        isFolderListSearchTextDirty = false;
        isFolderListInstantSearch = false;
        $scope.SelectedTemplateModel = TemplateFactory.workSpaceInitailValues();
        $timeout(function () {
            $(window).scrollTop($scope.scrollTop);
        });

    }

    $scope.viewSelectedFoldersOnlyLabel = 'View selected';

    $scope.ShowOnlySelectedFolders = function () {
        $scope.viewSelectedFoldersOnlyLabel = $scope.viewSelectedFoldersOnlyLabel == 'View selected' ? 'Show all' : 'View selected';

    }

    $scope.filterSelectedFolders = function (selected, field) {
        return function (selectedFolder) {
            if ($scope.viewSelectedFoldersOnlyLabel == 'Show all') {
                if (selected.length == 0) {
                    $scope.viewSelectedFoldersOnlyLabel = 'View selected';
                }
                var items = $filter('filter')(selected, selectedFolder, true);
                if (items.length > 0)
                    return true;

                return false;
            } else {
                return true;
            }
        }
    };

    $scope.viewSelectedTabsOnlyLabel = 'View selected';

    $scope.ShowOnlySelectedTabs = function () {
        $scope.viewSelectedTabsOnlyLabel = $scope.viewSelectedTabsOnlyLabel == 'View selected' ? 'Show all' : 'View selected';

    }

    $scope.filterSelectedTabs = function (selected, field) {
        return function (selectedTabs) {
            if ($scope.viewSelectedTabsOnlyLabel == 'Show all') {
                if (selected.length == 0) {
                    $scope.viewSelectedTabsOnlyLabel = 'View selected';
                }
                var items = $filter('filter')(selected, selectedTabs, true);
                if (items.length > 0)
                    return true;

                return false;
            } else {
                return true;
            }
        }
    };

    $scope.navFolderList = [];
    var templateSubFolderReqModel = homeFactory.requestModelInstance();

    $scope.PageEvents.ViewSubFolder = function (selectedsubRow, $event) {
        if (!selectedsubRow.HasSubfolders) {
            return;
        }
        $scope.childHeading.icon = selectedsubRow.Wstype;
        $scope.childHeading.heading = selectedsubRow.Name;
        $scope.navFolderList.push(selectedsubRow);
        templateFolderReqModel.searchText = $scope.FolderList.SearchText;
        templateFolderReqModel.Id = selectedsubRow.Id;
        getSubFoldersFromWorkspace(selectedsubRow);
    };

    function getSubFoldersFromWorkspace(selectedRow) {
        var deferredarray = [];
        var deferred = $q.defer();
        templateSubFolderReqModel.libraryName = $scope.vm.selectedLibrary;
        templateSubFolderReqModel.searchText = $scope.FolderList.SearchText;
        templateSubFolderReqModel.Id = selectedRow.Id;

        var apiUrl = TemplateFactory.getAPIUrl('GETSUBFOLDERFROMFOLDER', templateSubFolderReqModel);
        $scope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(apiUrl));

        var promise = TemplateService.getFoldersFromWorkspace(apiUrl, $scope.mc.loginModel.AuthKey);
        promise.then(function (response) {
            if (response.status === 200) {
                $scope.folders = [];
                $scope.Tabs = [];
                angular.forEach(response.data.data, function (folder) {
                    if (!selectedRow.SubType) {
                        var folderUIModel = TemplateFactory.getFolderUI(folder);
                        $scope.folders.push(folderUIModel);
                    }
                    //else {
                    //    var folderUIModel = TemplateFactory.getFolderUI(folder);
                    //    $scope.Tabs.push(folderUIModel);
                    //}
                });
                if ($scope.folders.length > 0) {
                    $scope.TemplateFolderHeaderText = $scope.childHeading.heading + " have " + $scope.folders.length + " Folders";
                } else {
                    $scope.TemplateFolderHeaderText = selectedRow.Name + " do not have Folders";
                }
                deferred.resolve(response);
            } else {
                $scope.mc.getlogDetails("Error", 'Method:GET;URL:' + JSON.stringify(apiUrl) + ",Response:" + JSON.stringify(response));

            }
            deferredarray.push(deferred.promise);
        }, function (response) {
            $scope.mc.getlogDetails("Error", 'Method:GET;URL:' + JSON.stringify(apiUrl) + ",Response:" + JSON.stringify(response));
        });
        $q.all(deferredarray).then(function () {
        });
    }


}