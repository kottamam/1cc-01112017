﻿app.controller("AppSetupController", AppSetupController);
AppSetupController.$inject = ['$scope', '$rootScope', 'AppSetupService', '$filter', '$timeout', 'homeFactory', 'appSetupFactory',
'$mdDialog', '$mdMedia'];

function AppSetupController($scope, $rootScope, AppSetupService, $filter, $timeout, homeFactory, appSetupFactory, $mdDialog, $mdMedia) {

    var requestModel = homeFactory.requestModelInstance();

    $scope.AppSetupList = [];
    $scope.selected = [];

    $scope.query = {
        limit: requestModel.pageLength,
        page: requestModel.pagenumber,
        totalCount: 0
    };

    $scope.FilterOptions = {
        IntegrationMode: [{ 'DisplayText': 'COM-Integrated', 'ValueText': 'N' },
				   { 'DisplayText': 'Non-Integrated', 'ValueText': 'T' },
				   { 'DisplayText': 'ODMA', 'ValueText': 'Y' }]
    };

    
    $scope.$on('Window_Scrolled', function () {
        if ($scope.query.totalCount > $scope.AppSetupList.length) {
            requestModel.pagenumber++;
            getAppSetupList();
        }
    });
    var SelectedAppIdListForFilter = [];
    var LastAddedSelectedItemAppId = [];
    var lastAppendItemCount = 0;
    function getAppSetupList() {
        if ($scope.vm.selectedApp.NoAppsPermission.trim().length > 0) return;
        if (!$scope.vm.selectedLibrary || $scope.vm.selectedLibrary.trim().length == 0) return;

        $scope.loading = true;
        requestModel.libraryName = $scope.vm.selectedLibrary;
        requestModel.searchText = $scope.appsVar.SearchText;
        $scope.lastSelectedLibrary = $scope.vm.selectedLibrary;
        if (isSearch) {
            //  $scope.showSearchProgress = true;
            showProgressDialog();
        }
        var apiUrl = appSetupFactory.getAPIUrl('GETAPPS', requestModel);
        $scope.mc.getlogDetails("Debug", 'Method:GET:URL:' + JSON.stringify(apiUrl));
        var promise = AppSetupService.getAppSetupList(apiUrl, $scope.mc.loginModel.AuthKey);
        promise.then(function (response) {
            if (response["status"] === 200) {
                $scope.query.totalCount = response["data"]["total_count"];
                $scope.mc.getlogDetails("Debug", 'Success:Requested Api URL:' + JSON.stringify(apiUrl));
                var tempListFilter = [];
                var appUIModel;
                var filterTempModel;
                if (lastAppendItemCount > 0) {
                    $scope.AppSetupList.splice($scope.AppSetupList.length - lastAppendItemCount, lastAppendItemCount);
                    $scope.selected.splice($scope.selected.length - lastAppendItemCount, lastAppendItemCount);
                }
                angular.forEach(response["data"]["data"], function (appsetup) {
                    appUIModel = appSetupFactory.getAppSetupUIModel(appsetup);
                    if (SelectedAppIdListForFilter.length === 0) {
                        $scope.AppSetupList.push(appUIModel);
                    }
                    else {
                        tempListFilter = $filter('filter')(SelectedAppIdListForFilter, {
                            Name: appUIModel.Name
                        }, true);
                        if (tempListFilter.length === 0) {
                            $scope.AppSetupList.push(appUIModel);
                        }
                        else {
                            LastAddedSelectedItemAppId = $.grep(LastAddedSelectedItemAppId,
							   function (item, index) {
							       return item.Name != appUIModel.Name;
							   });

                            tempListFilter[0].Name = appUIModel.Name;
                            tempListFilter[0].Type = appUIModel.Type;
                            tempListFilter[0].Primary = appUIModel.Primary;
                            tempListFilter[0].IsAllowLogon = appUIModel.IsAllowLogon;
                            tempListFilter[0].Location = appUIModel.Location;
                            tempListFilter[0].DDE = appUIModel.DDE;
                            tempListFilter[0].IntegrationMode = appUIModel.IntegrationMode;
                            tempListFilter[0].DDEAppName = appUIModel.DDEAppName;
                            tempListFilter[0].DDETopic = appUIModel.DDETopic;
                            tempListFilter[0].DDEOpen = appUIModel.DDEOpen;
                            tempListFilter[0].DDEReadOpen = appUIModel.DDEReadOpen;
                            tempListFilter[0].DDEPrintandExitApp = appUIModel.DDEPrintandExitApp;
                            tempListFilter[0].DDEPRint = appUIModel.DDEPRint;

                            filterTempModel = angular.copy(tempListFilter[0]);
                            $scope.AppSetupList.push(filterTempModel);
                            $scope.selected.push(filterTempModel);
                            filterTempModel = null;
                        }
                        tempListFilter = [];
                    }
                    appUIModel = null;
                });
                lastAppendItemCount = 0;
                if ($scope.appsVar.SearchText.length === 0 && !isValidFilterFind()) {
                    angular.forEach(LastAddedSelectedItemAppId, function (app) {
                        filterTempModel = angular.copy(app);
                        $scope.AppSetupList.push(filterTempModel);
                        $scope.selected.push(filterTempModel);
                        filterTempModel = null;
                        lastAppendItemCount += 1;
                    });
                }

                if ($scope.selected.length > 0) {
                    setContextMenuObject();
                }
            }
            else {
            	 $scope.mc.getlogDetails("Error", 'Method:GET;URL:' + JSON.stringify(apiUrl)+",Response:"+JSON.stringify(response));
             	
            	  }
 
            $scope.loading = false;
            $scope.showSearchProgress = false;
            if (isSearch) $mdDialog.hide();
        }, function (response) {
            $scope.loading = false;
          //  $scope.mc.getlogDetails("Error", 'Method:GET;URL:' + JSON.stringify(apiUrl) + ",Response:" + JSON.stringify(response));
       	 $scope.mc.getlogDetails("Error", 'Method:GET;URL:' + JSON.stringify(apiUrl)+",Response:"+JSON.stringify(response));
         
            
            $mdDialog.show(
					   $mdDialog.alert()
						   .parent(angular.element(document.body))
						   .clickOutsideToClose(true)
						   .title('Warning!')
						   .textContent('Failed to retrive App Setup.')
						   .ariaLabel('Warning!')
						   .ok('OK')
						   .targetEvent(event)
				   );
            if (isSearch) $mdDialog.hide();
            $scope.showSearchProgress = false;
        });
    }

    function Initalize() {
        $scope.query.page = 1;
        $scope.query.totalCount = 0;
        requestModel.pagenumber = 1;
        getAppSetupList();
    }

	$timeout(function() {
		$(window).scrollTop(0);
	});
    
    $scope.deSelect = function (appSetupModel) {
        setContextMenuObject();
        if (SelectedAppIdListForFilter.length > 0) {
            SelectedAppIdListForFilter = $.grep(SelectedAppIdListForFilter,
								function (item, index) {
								    return item.Name != appSetupModel.Name;
								});
        }
        if (SelectedAppIdListForFilter.length > 0) {
            LastAddedSelectedItemAppId = $.grep(LastAddedSelectedItemAppId,
								   function (item, index) {
								       return item.Name != appSetupModel.Name;
								   });
        }
    };

    $scope.onSelect = function (appSetupModel) {
        setContextMenuObject();
        var tempListFilter = $filter('filter')(SelectedAppIdListForFilter, {
            Name: appSetupModel.Name
        }, true);
        if (tempListFilter.length === 0) {
            SelectedAppIdListForFilter.push(angular.copy(appSetupModel));
        }
    };

    function setContextMenuObject() {
        $scope.menuList = [
				{
				    Label: 'Edit',
				    Icon: 'icon-edit',
				    onClick: $scope.ContextMenuFunctions.Edit,
				    Enable: $scope.selected.length == 1,
				    IconType: 'font-icon'
				}];
    }

    $scope.ContextMenuFunctions = {
        Edit: function () { $scope.PageEvents.Edit(); }
    };
    RegisterInitializeTabContents();
    var destroybroadCast;
    $scope.$on('RegisterInitializeTabContents', function () {
        if (angular.isFunction(destroybroadCast))
            destroybroadCast();

        RegisterInitializeTabContents();
    });
    function RegisterInitializeTabContents() {
	 var destroybroadCast = $scope.$on('InitializeTabContents', function () {
            $scope.AppSetupList = [];
            $scope.selected = [];
        Initalize();

        if ($scope.vm.selectedApp.NoAppsPermission.trim().length > 0)
            return;
        if (!$scope.vm.selectedLibrary || $scope.vm.selectedLibrary.trim().length == 0)
            return;
        destroybroadCast();
    });
    }

    var isSearch = false;

    $scope.$on('Search_Click', function (event, args) {
        LastAddedSelectedItemAppId = angular.copy(SelectedAppIdListForFilter);
        $scope.AppSetupList = [];
        $scope.selected = [];
        isSearch = true;
        Initalize();
        lastAppendItemCount = 0;
    });
    $scope.PageEvents.ShowOnlySelected = function () {
        $scope.vm.viewSelectedOnlyLabel = $scope.vm.viewSelectedOnlyLabel == 'View selected' ? 'Show all' : 'View selected';

    }
    $scope.viewSelectedOnlyLabel = 'View selected';
    $scope.filterSelected = function (selected, field) {
        return function (group) {
            if ($scope.viewSelectedOnlyLabel == 'Show all') {
                if (selected.length == 0) {
                    $scope.viewSelectedOnlyLabel = 'View selected';
                }
                var items = $filter('filter')(selected, group, true);
                if (items.length > 0)
                    return true;

                return false;
            } else {
                return true;
            }
        }
    };
 
    $scope.$on('$destroy', function () {
        $scope.PageEvents.Add = 'undefined';
        $scope.PageEvents.Edit = 'undefined';
        $scope.PageEvents.Save = 'undefined';
        $scope.PageEvents.Delete = 'undefined';
        $scope.PageEvents.CancelDialog = 'undefined';
        $scope.PageEvents.ShowSubclassList = 'undefined';
        $scope.PageEvents.AddRole = 'undefined';
        $scope.PageEvents.ResetPasswordclicked = 'undefined';
        $scope.PageEvents.ViewAssignUser = 'undefined';
        $scope.PageEvents.AssignUser = 'undefined';
        $scope.PageEvents.AssignGroup = 'undefined';
        $scope.PageEvents.ViewSelected = 'undefined';
    });
 
    $scope.PageEvents.Add = function () {
        $scope.PageEvents.UserAction = 'Add';
        $scope.appsetup = appSetupFactory.AppSetupInitialValues();

        var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
        $mdDialog.show({
            controller: AppSetAddEditController,
            preserveScope: false,
            templateUrl: 'Views/AddAppSetup.html',
            parent: angular.element(document.body),
            clickOutsideToClose: true,
            fullscreen: useFullScreen,
            locals: {
                parentScope: $scope
            },
            onComplete: function () {
                $("#AppSetUpForm input[id=Name]").focus();
                $("#AppSetUpForm input[id=Name]").select();
            }
        }).then(function (answer) {
            $scope.status = '';
        }, function () {
            $scope.status = '';
        });
        $scope.$watch(function () {
            return $mdMedia('xs') || $mdMedia('sm');
        }, function (wantsFullScreen) {
            $scope.customFullscreen = (wantsFullScreen === true);
        });
    };

    $scope.PageEvents.Edit = function () {
        $scope.PageEvents.UserAction = 'Edit';
        $scope.appsetup = $scope.selected[0];

        $scope.selectedTypeItem = $scope.selected[0].TAlias;
        var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
        $mdDialog.show({
            controller: AppSetAddEditController,
            preserveScope: false,
            templateUrl: 'Views/AddAppSetup.html',
            parent: angular.element(document.body),
            clickOutsideToClose: true,
            fullscreen: useFullScreen,
            locals: {
                parentScope: $scope
            },
            onComplete: function () {
                $("#AppSetUpForm input[id=Location]").focus();
                $("#AppSetUpForm input[id=Location]").select();
            }
        })
		.then(function (answer) {
		    $scope.status = '';
		}, function () {
		    $scope.status = '';
		});
        $scope.$watch(function () {
            return $mdMedia('xs') || $mdMedia('sm');
        }, function (wantsFullScreen) {
            $scope.customFullscreen = (wantsFullScreen === true);
        });
    };

    $scope.PageEvents.CancelDialog = function () {
        $mdDialog.cancel();
    }
    function showProgressDialog() {
        $mdDialog.show({
            parent: angular.element(document.body),
            template: '<md-dialog ng-cloak height="100%" style="min-width: 1px !important;"><md-dialog-content><div class="md-dialog-content-clearpadding">' +
              '<md-progress-circular md-mode="indeterminate"></md-progress-circular>' +
              '</div></md-dialog-content></md-dialog>',
            controller: DialogController
        });
    }

    var FilterSearchTimeout;
    function isValidFilterFind() {
        var filterKeyItem = null;
        var blnResult = false;

        for (var iCount = 0; iCount < requestModel.filters.length; iCount++) {
            filterKeyItem = requestModel.filters[iCount];
            if (filterKeyItem.FilterValues && filterKeyItem.FilterValues[0] && filterKeyItem.FilterValues[0].trim().length > 0) {
                blnResult = true;
                break;
            }
            filterKeyItem = null;
        }
        return blnResult;
    }


    $scope.onTableFilter = function (value, key, isInstantFilter, disablePerformFilter) {


        if (requestModel.filters.length > 0) {
            requestModel.filters = jQuery.grep(requestModel.filters, function (filterItem) {
                return filterItem.FilterKey !== key;
            });
        }


        var filterValueList = [];
        filterValueList[0] = value;

        var filterItem = { 'FilterKey': key, 'FilterValues': filterValueList };
        requestModel.filters.push(filterItem);

        requestModel.pagenumber = 1;
        $scope.query.page = 1;
        $scope.query.totalCount = 0;

        if (FilterSearchTimeout) $timeout.cancel(FilterSearchTimeout);

        if (!disablePerformFilter) {
            if (isInstantFilter) {
                $scope.AppSetupList = [];
                $scope.selected = [];
                getAppSetupList();
            } else {
                FilterSearchTimeout = $timeout(function () {
                    $scope.AppSetupList = [];
                    $scope.selected = [];
                    getAppSetupList();
                }, 2000);
            }
        };
    };
    function DialogController($scope, $mdDialog) {
        $scope.hide = function () {
            $mdDialog.hide();
        };
        $scope.cancel = function () {
            $mdDialog.cancel();
        };
        $scope.answer = function () {
            $mdDialog.hide();
        };
    }

    function AppSetAddEditController($scope, $mdDialog, parentScope, docTypeFactory, DocTypeService, homeFactory, $log, $q) {

        $scope.hide = function () {
            $mdDialog.hide();
        };

        $scope.cancel = function () {
            $mdDialog.cancel();
        };

        $scope.answer = function () {
            $mdDialog.hide();
        };

        $scope.AppSetupTextChange = CustomAppSetupTextChange;

        function CustomAppSetupTextChange($event) {
            if ($event.keyCode === 13) {
                $event.preventDefault();
            }
        }
        var selectedRowIndex = -1;
        $scope.appsetup = angular.copy(parentScope.appsetup);
        $scope.ShowWarning = false;
        $scope.PageEvents = parentScope.PageEvents;

        $scope.PageEvents.BindLabel = function (data) {
            if (parentScope.PageEvents.UserAction == 'Add') {
                return 'Add'
            } else {
                return 'Save';
            }
        }

        $scope.PageEvents.Save = function () {
            $scope.posting = false;
            $scope.ShowWarning = false;

            if ($scope.selectedTypeItem) {
                $scope.appsetup.Type = $scope.selectedTypeItem.TAlias;
            }
            if ($scope.appsetup.Name === '' || !$scope.appsetup.Location || $scope.appsetup.Location === '') {
                return;
            }
            else if ($scope.appsetup.DDE) {
                if (!$scope.appsetup.DDEAppName || $scope.appsetup.DDEAppName === '' || !$scope.appsetup.DDETopic || $scope.appsetup.DDETopic === ''
					|| !$scope.appsetup.DDEOpen || $scope.appsetup.DDEOpen === '') {
                    return;
                }
            }
            if (!$scope.appsetup.Type || $scope.appsetup.Type.trim().length == 0) {
                $scope.ShowWarning = true;
                $scope.ErrorMessage = 'Please select Type.';
                $('md-dialog div').animate({ scrollTop: 9999 }, 'slow');
                return
            }
            $scope.posting = true;
            if ($scope.PageEvents.UserAction == 'Add') {
                var apiUrl = appSetupFactory.getAPIUrl('POSTAPI', null);
               
                var apiModel = appSetupFactory.getAppSetupAPIPostModel($scope.appsetup, parentScope.vm.selectedLibrary);
              //  parentScope.mc.setSecurityLogDetails("Info", 'Method:POST;Body:' + JSON.stringify(apiModel) + 'URL:' + JSON.stringify(apiUrl));
                var promiseAdd = AppSetupService.addAppSetup(apiUrl, parentScope.mc.loginModel.AuthKey, apiModel);
                promiseAdd.then(function (response) {
                    if (response.statusText = 'OK') {
                        $scope.dialogPopup.CallbackFunction = function () {
                            $mdDialog.hide();
                        }
                        $scope.posting = false;
                        $scope.ShowWarning = false;
                        $scope.dialogPopup.Header = 'Success';
                        $scope.dialogPopup.Message = 'App added succesfully.';
                        parentScope.mc.setSecurityLogDetails("Info", 'Success', $scope.appsetup.Name, 'App Add', JSON.stringify(apiModel))
                        $scope.dialogPopup.Show();

                        $timeout(function () {
                            $scope.appsetup = appSetupFactory.AppSetupInitialValues();

                            parentScope.AppSetupList = [];
                            parentScope.selected = [];
                            Initalize();
                            $scope.dialogPopup.OK();

                        }, 2000);
                    }
                    else {
                        $scope.ShowWarning = true;
                        parentScope.mc.setSecurityLogDetails("Info", 'Failure', $scope.appsetup.Name, 'App Add', JSON.stringify(apiModel))
                        if (response && response.data && response.data.details && response.data.details.message) {
                            $scope.ErrorMessage = response.data.details.message;
                        }
                        else {
                            $scope.ErrorMessage = 'Posting App failed due to unknown errors.';
                            
                        }
                        $('md-dialog div').animate({ scrollTop: 9999 }, 'slow');
                    }


                }, function (response) {
                    $scope.posting = false;
                    $scope.ShowWarning = true;
                    $scope.ErrorMessage = 'Posting App failed due to unknown errors.';
                    parentScope.mc.setSecurityLogDetails("Info", 'Failure', $scope.appsetup.Name, 'App Add', JSON.stringify(apiModel))
                    $('md-dialog div').animate({ scrollTop: 9999 }, 'slow');
                });
            }
            else {
                selectedRowIndex = -1;
                if (parentScope.selected && parentScope.selected.length > 0)
                    selectedRowIndex = parentScope.AppSetupList.indexOf(parentScope.selected[0]);

                var apiUrl = appSetupFactory.getAPIUrl('PUTAPI', $scope.appsetup);
                 
                var apiModel = appSetupFactory.getAppSetupAPIPostModel($scope.appsetup, parentScope.vm.selectedLibrary);
                parentScope.mc.getlogDetails("Debug", 'Method:POST;Body:' + JSON.stringify(apiModel) + 'URL:' + JSON.stringify(apiUrl));
                
                var promiseAdd = AppSetupService.EditAppSetup(apiUrl, parentScope.mc.loginModel.AuthKey, apiModel);
                promiseAdd.then(function (response) {
                    if (response.statusText = 'OK') {
                        $scope.dialogPopup.CallbackFunction = function () {
                            $mdDialog.hide();
                        }
                        $scope.ShowWarning = false;
                        $scope.posting = false;
                        $scope.dialogPopup.Header = 'Success';
                        $scope.dialogPopup.Message = 'App updated succesfully.';
                        parentScope.mc.setSecurityLogDetails("Info", 'Success', $scope.appsetup.Name, ' App Update', JSON.stringify(apiModel))
                        $timeout(function () {
                            $scope.dialogPopup.OK();

                        }, 2000);
                        if (selectedRowIndex >= 0) {
                            parentScope.AppSetupList[selectedRowIndex].Location = $scope.appsetup.Location;
                            parentScope.AppSetupList[selectedRowIndex].Type = $scope.appsetup.Type;
                            parentScope.AppSetupList[selectedRowIndex].IntegrationMode = $scope.appsetup.IntegrationMode;
                            parentScope.AppSetupList[selectedRowIndex].DDE = $scope.appsetup.DDE;
                            parentScope.AppSetupList[selectedRowIndex].Primary = $scope.appsetup.Primary;
                            parentScope.AppSetupList[selectedRowIndex].DDEAppName = $scope.appsetup.DDEAppName;
                            parentScope.AppSetupList[selectedRowIndex].DDETopic = $scope.appsetup.DDETopic;
                            parentScope.AppSetupList[selectedRowIndex].DDEOpen = $scope.appsetup.DDEOpen;
                            parentScope.AppSetupList[selectedRowIndex].DDEReadOpen = $scope.appsetup.DDEReadOpen;
                            parentScope.AppSetupList[selectedRowIndex].DDEPRint = $scope.appsetup.DDEPRint;
                            parentScope.AppSetupList[selectedRowIndex].DDEPrintandExitApp = $scope.appsetup.DDEPrintandExitApp;
                        }
                        var tmpList = [];
                        tmpList = angular.copy(parentScope.AppSetupList);
                        parentScope.selected = [];
                        parentScope.AppSetupList = [];
                        parentScope.AppSetupList = angular.copy(tmpList);
                        $scope.appsetup = appSetupFactory.AppSetupInitialValues();
                        tmpList = [];
                    }
                    else {
                        $scope.posting = false;
                        $scope.ShowWarning = true;
                        parentScope.mc.setSecurityLogDetails("Info", 'Failure', $scope.appsetup.Name, ' App Update', JSON.stringify(apiModel))
                        if (response && response.data && response.data.details && response.data.details.message) {
                            $scope.ErrorMessage = response.data.details.message;
                             }                        
                        else {
                            $scope.ErrorMessage = "App updation failed due to unknown errors.";
                           
                        }
                        $('md-dialog div').animate({ scrollTop: 9999 }, 'slow');

                    }
                }, function (response) {
                    $scope.ShowWarning = true;
                    parentScope.mc.setSecurityLogDetails("Info", 'Failure', $scope.appsetup.Name, ' App Update', JSON.stringify(apiModel))
                    if (response && response.data && response.data.details && response.data.details.message) {
                        $scope.ErrorMessage = response.data.details.message;                       
                      }
                    else {
                        $scope.ErrorMessage ="App updation failed due to unknown errors."
                       
                    }
                    $('md-dialog div').animate({ scrollTop: 9999 }, 'slow');
                });
            }
        };
        $scope.AppSetupChange = function ($event, type) {
            if ($event.keyCode === 9) {
                $event.preventDefault();
                if (type == "Add")
                    $("#AppSetUpForm input[id=Name]").focus();
                else if (type == "Edit") {
                    $("#AppSetUpForm input[id=Location]").focus();
                    $("#AppSetUpForm input[id=Location]").select();
                }

            }
            return false;
        }
        $scope.dialogPopup = {
            Header: '',
            Message: '',
            CallbackFunction: null,
            Show: function () {
                $('#popup-alert-dialog-bg').slideToggle();
            },
            OK: function () {
                $('#popup-alert-dialog-bg').slideToggle();
                $scope.dialogPopup.Header = '';
                $scope.dialogPopup.Message = '';

                if ($scope.dialogPopup.CallbackFunction) {
                    $scope.dialogPopup.CallbackFunction();
                    $scope.dialogPopup.CallbackFunction = null;
                }
            }
        }

        $scope.autocompleteTypeMatch = true;
        $scope.selectedTypeItem = null;
        $scope.searchTypeText = null;
        $scope.queryTypeSearch = queryTypeSearch;
        $scope.DocTypeListofApp = [];


        function queryTypeSearch(query) {
            var deffered = $q.defer();
            var FilterSearchTimeout;
            var typeListRequestModel = homeFactory.requestModelInstance();


            var filterValueList = [];
            filterValueList[0] = query;

            var filterItem = { 'FilterKey': 'Alias', 'FilterValues': filterValueList };
            typeListRequestModel.filters.push(filterItem);

            typeListRequestModel.pagenumber = 1;

            if (FilterSearchTimeout) $timeout.cancel(FilterSearchTimeout);
            var obj = [];
            var searchAPIUrl = docTypeFactory.searchAPIUrl(typeListRequestModel);
            parentScope.mc.getlogDetails("Debug", 'Requested Api Url:' + JSON.stringify(searchAPIUrl));
            var typeDbRequest = DocTypeService.getDocTypes(searchAPIUrl, parentScope.mc.loginModel.AuthKey);

            typeDbRequest.then(function (response) {
                if (response.status === 200) {
                    angular.forEach(response.data.data, function (typeItem) {
                        obj.push(docTypeFactory.getUIModel(typeItem));
                    });
                    deffered.resolve(obj);
                }
            }, function () { });

            return deffered.promise;
        }

        $scope.searchTextChange = searchTextChange;
        $scope.selectedItemChange = selectedItemChange;

        function searchTextChange(text) {
            return queryTypeSearch(text);
        }

        function selectedItemChange(item) {
        }
    }
}