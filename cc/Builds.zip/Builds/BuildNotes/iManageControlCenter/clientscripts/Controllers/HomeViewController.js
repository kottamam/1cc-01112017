app.controller("HomeViewController", HomeViewController);
HomeViewController.$inject = ['$scope', '$state', '$filter'];

function HomeViewController($scope, $state, $filter) {
	var hvc = this;

	hvc.tileClicked=function(AppsName,title,target)
	{
	    var tostate = 'home.' + target;
	    var statetarget = tostate.split(".")[1];
	    if (statetarget) {
	        statetargetTabs = statetarget.split("_");
	        if (statetargetTabs.length == 2)
	            activesection = $filter('filter')($scope.$parent.vm.menu.sections, { AppsTarget: statetargetTabs[0] }, true);
	        else {
	            var object = $filter('filter')($scope.$parent.vm.menu.sections, { AppsTarget: statetargetTabs[0] }, true);
	            activesection = $filter('filter')(object[0].childMenus, { AppsTarget: statetargetTabs[0] + '_' + statetargetTabs[1] }, true);
	        }
	        object = $filter('filter')(activesection[0].childMenus, { AppsTarget: statetarget }, true);
	    }
	    $scope.$parent.vm.headerNavigationMenu = activesection[0].childMenus;
	    $scope.$parent.vm.headerNavigationSelectedMenu = object;
	    $scope.$parent.vm.setActiveSection(activesection[0]);		
	    $scope.$parent.vm.menu.onTabLinkSelected(AppsName, title, target);
	}
	
}