﻿var baseUrl = '';
var baseIMCCApiUrl = '';
var UserSessionTimer = null;
var sessionTime = 1000 * 60 * 60 * 4;
var cookieExpiary = new Date();

function updateCookieExpiary() {
    cookieExpiary = new Date();
    var time = cookieExpiary.getTime();
    time += sessionTime;
    cookieExpiary.setTime(time);
    return cookieExpiary;
}