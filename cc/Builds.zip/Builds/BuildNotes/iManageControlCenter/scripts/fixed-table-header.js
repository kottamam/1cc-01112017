/*
 * Angular Fixed Table Header
 * https://github.com/daniel-nagy/fixed-table-header
 * @license MIT
 * v0.2.1
 */
(function (window, angular, undefined) {
'use strict';

angular.module('fixed.table.header', []).directive('fixHead', fixHead);

function fixHead($compile, $window) {
  
  function compile(tElement) {
    var table = {
      clone: tElement.parent().clone().empty(),
      original: tElement.parent()
    };
    
    var header = {
      clone: tElement.clone(),
      original: tElement
    };
    
  /*  var firstItem = {
    	      clone:  tElement.parent().children("tbody").clone(),
    	      original:  tElement.parent().children("tbody") 
    	    };*/
  
    // prevent recursive compilation
    header.clone.removeAttr('fix-head').removeAttr('ng-if');
    
    table.clone.css({display: 'block', overflow: 'hidden'}).addClass('clone');
   
    header.clone.css('display', 'block');
   /* firstItem.clone.css('display', 'block');
    firstItem.clone.find("tr:first").removeClass('ng-hide');
    firstItem.clone.find("tr:first").removeAttr('ng-show');
    firstItem.clone.find("tr:gt(0)").remove();*/
    //header.original.css('visibility', 'hidden');
    
    return function postLink(scope) {
        var scrollContainer = $(table.original.parent()[0]);
      
      // insert the element so when it is compiled it will link
      // with the correct scope and controllers
      header.original.after(header.clone);
    //  firstItem.original.after(firstItem.clone);
     
      $compile(table.clone)(scope);
      $compile(header.clone)(scope);
      // $compile(firstItem.clone)(scope);
      var cloneItem=table.clone.append(header.clone);//.append(firstItem.clone);
     
      scrollContainer.parent()[0].insertBefore(cloneItem[0], scrollContainer[0]);
      
 
        
           
      scrollContainer.on('scroll', function () {
        // use CSS transforms to move the cloned header when the table is scrolled horizontally
        header.clone.css('transform', 'translate3d(' + -(scrollContainer.prop('scrollLeft')) + 'px, 0, 0)');
      });
      
      function cells() {
        return header.clone.find('th').length;
      }
      
      function getCells(node) {
        return Array.prototype.map.call(node.find('th'), function (cell) {
          return jQLite(cell);
        });
      }
      
      function height() {
        return header.original.prop('clientHeight');
      }
      
      function jQLite(node) {
        return angular.element(node);
      }
      
      function marginTop(height) {
        table.original.css('marginTop', '-' + height + 'px');
      }
      
      function updateCells() {
        var cells = {
          clone: getCells(header.clone),
          original: getCells(header.original)
        };
        
        cells.clone.forEach(function (clone, index) {
          if(clone.data('isClone')) {
            return;
          }
          
          // prevent duplicating watch listeners
          clone.data('isClone', true);
          
          var cell = cells.original[index];
          var style = $window.getComputedStyle(cell[0]);
          
          var getWidth = function () {
            return style.width;
          };
          
          var setWidth = function () {
              marginTop(height());
              var ua = window.navigator.userAgent;
              var msie = ua.indexOf("MSIE ");

              if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) {
                  clone.css({ minWidth: (parseFloat(style.width.replace(/px/, "")) + parseFloat(style.paddingLeft.replace(/px/, "")) + parseFloat(style.paddingRight.replace(/px/, ""))) + "px", maxWidth: (parseFloat(style.width.replace(/px/, "")) + parseFloat(style.paddingLeft.replace(/px/, "")) + parseFloat(style.paddingRight.replace(/px/, ""))) + "px" });
              } else {
                  clone.css({ minWidth: style.width, maxWidth: style.width });
              }
              
            /*  header.clone.children().find("th").each(function(item,index) {
            	  firstItem.clone.children().find("td:nth-child("+(item+1)+")").css({ minWidth:index.style.minWidth  , maxWidth: index.style.maxWidth });
                  
                  
           });*/
          }; 
          
          var listener = scope.$watch(getWidth, setWidth);
          
          $window.addEventListener('resize', setWidth);
          
          clone.on('$destroy', function () {
            listener();
            $window.removeEventListener('resize', setWidth);
          });
          
          cell.on('$destroy', function () {
            clone.remove();
          });
        });
        
      
      }
      
      scope.$watch(cells, updateCells);
      
      header.original.on('$destroy', function () {
        header.clone.remove();
      });
    };
  }
  
  return {
    compile: compile
  };
}

fixHead.$inject = ['$compile', '$window'];

})(window, angular);