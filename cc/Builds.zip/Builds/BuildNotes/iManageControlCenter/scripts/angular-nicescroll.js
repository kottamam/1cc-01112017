(function () {
    'use strict';

    angular
        .module('angular-nicescroll', [])
        .directive('ngNicescroll', ngNicescroll);

    ngNicescroll.$inject = ['$rootScope','$parse'];

    /* @ngInject */
    function ngNicescroll($rootScope,$parse) {
        // Usage:
        //
        // Creates:
        //
        var directive = {
            link: link
        };
        return directive;

        function link(scope, element, attrs, controller) {

            var niceOption = scope.$eval(attrs.niceOption)

            var niceScroll = $(element).niceScroll(niceOption);
            var nice = $(element).getNiceScroll();
            
         	scope.$watch(function () { return $('#'+nice[0].id+ '-hr').width() }, function () {
           if( $('#'+nice[0].id+ '-hr').width() > $('#'+nice[0].id+ '-hr >div').width())
           {
        	   $('#'+nice[0].id+ '-hr').addClass('alwaysvisible');
           }else
           {
        	   $('#'+nice[0].id+ '-hr').removeClass('alwaysvisible');
           }
        	});
           
       
           
       	scope.$watch(function () { return $(element).find('table tr').length }, function () {
       	   if($(element).find('table tr').length>8)
           {
        	   $('#'+nice[0].id).addClass('alwaysvisible');
           }else
           {
        	   $('#'+nice[0].id).removeClass('alwaysvisible');
           }
		});
 
           	
          
            if (attrs.niceScrollObject)  $parse(attrs.niceScrollObject).assign(scope, nice);
       
            // on scroll end
            niceScroll.onscrollend = function (data) {
                var fetchMargin = 0;
                if (attrs.fetchMargin) {
                    fetchMargin = scope.$eval(attrs.fetchMargin)
                }
                if (this.newscrolly >= this.page.maxh - fetchMargin) {
                    if (attrs.niceScrollEnd) scope.$evalAsync(attrs.niceScrollEnd);

                }
                if (data.end.y <= 0) {
                    // at top
                    if (attrs.niceScrollTopEnd) scope.$evalAsync(attrs.niceScrollTopEnd);
                }
            };


            scope.$on('$destroy', function () {
                if (angular.isDefined(niceScroll.version)) {
                    niceScroll.remove();
                }
            })


        }
    }


})();
