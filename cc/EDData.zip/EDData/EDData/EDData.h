// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the EDDATA_EXPORTS
// symbol defined on the command line. This symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// EDDATA_API functions as being imported from a DLL, whereas this DLL sees symbols
// defined with this macro as being exported.
#ifdef EDDATA_EXPORTS
#define EDDATA_API __declspec(dllexport)
#else
#define EDDATA_API __declspec(dllimport)
#endif



extern "C" EDDATA_API  int EDF(const char* szInFile, const char* szOutFile);
extern "C" EDDATA_API  int DFCF(const char* szInFile, const char* szAppSettingsJson);
extern "C" EDDATA_API  int ChkPK(const char* szInFile, const char* szAppSettingsJson, const char* inproductKey);
