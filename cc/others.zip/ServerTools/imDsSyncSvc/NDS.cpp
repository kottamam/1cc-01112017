//=============================================================================
// File: NDS.cpp
//-----------------------------------------------------------------------------
// Date      Who  Modification
// --------  ---  -------------------------------------------------------------
// 04/5/02  MDL  Initial coding
//-----------------------------------------------------------------------------
// Copyright (C) 2002, iManage, Inc.
// PROPRIETARY AND CONFIDENTIAL
//=============================================================================

#include "StdAfx.h"
#include "NDS.h"
#include <Report/Report.h>


extern void LogMsg(const char *szPath_, const int line_, const long lLevel_, const char *szFormat_, ...);

namespace NDSOM
{


/////////////////////////////////////////////////////
// CNdsWrapper

CNdsWrapper::CNdsWrapper( void )
{
	m_NWLibHandle = LoadLibrary( _T("netwin32.dll" ) );
	m_NWLocalHandle = LoadLibrary( _T("locwin32.dll" ) );

	ptrNWCallsInit = NULL;
	ptrNWDSCreateContext = NULL;
	ptrNWDSCreateContextHandle = NULL;
	ptrNWIsDSAuthenticated = NULL;
	ptrNWDSSetContext = NULL;
	ptrNWDSGetContext = NULL;
	ptrNWDSAllocBuf = NULL;
	ptrNWDSList = NULL;
	ptrNWDSGetObjectCount = NULL;
	ptrNWDSGetObjectName = NULL;
	ptrNWDSFreeBuf = NULL;
	ptrNWDSFreeContext = NULL;

	ptrNWDSInitBuf = NULL;
	ptrNWDSPutAttrName = NULL;
	ptrNWDSRead = NULL;
	ptrNWDSGetAttrName =NULL;
	ptrNWDSGetAttrVal =NULL;
	ptrNWDSGetAttrCount =NULL;
	ptrNWDSGetEffectiveRights = NULL;

	ptrNWLlocaleconv = NULL;
	ptrNWInitUnicodeTables = NULL;
	ptrNWFreeUnicodeTables = NULL;

	ptrNWDSAuthenticate = NULL;
	ptrNWDSAuthenticateConn = NULL;
	ptrNWDSChangeObjectPassword = NULL;
	ptrNWDSGenerateObjectKeyPair = NULL;
	ptrNWDSLogin = NULL;
	ptrNWDSLogout = NULL;
	ptrNWDSVerifyObjectPassword = NULL;
	ptrNWDSOpenConnToNDSServer = NULL;
	ptrNWDSGetDefNameContext = NULL;
	ptrNWDSSetDefNameContext = NULL;
	ptrNWDSGetMonitoredConnRef = NULL;
	ptrNWDSOpenMonitoredConn = NULL;
	ptrNWDSScanConnsForTrees = NULL;
	ptrNWDSScanForAvailableTrees = NULL;
	ptrNWDSReturnBlockOfAvailableTrees = NULL;
	ptrNWDSSCanDSAuthenticate = NULL;
	ptrNWDSPutAttrVal = NULL;
	ptrNWDSAddObject = NULL;
	ptrNWDSAddFilterToken = NULL;
	ptrNWDSAllocFilter = NULL;
	ptrNWDSPutFilter = NULL;
	ptrNWDSSearch = NULL;
	ptrNWDSComputeAttrValSize = NULL;

    if( m_NWLibHandle == NULL )
    {
		LogMsg( LOG_ERROR, _T( "Unable to load Novell NDS 'netwin32.dll' library." ) );
    }

    if( m_NWLocalHandle == NULL )
    {
		LogMsg( LOG_ERROR, _T( "Unable to load Novell NDS 'locwin32.dll' library." ) );
    }

	if( ( m_NWLibHandle != NULL ) && ( m_NWLocalHandle != NULL ) )
		InitDllFunctionPointers( );
}

CNdsWrapper::~CNdsWrapper()
{
 	if( m_NWLibHandle!= NULL) 
       	FreeLibrary( m_NWLibHandle );

	if( m_NWLocalHandle!= NULL )
       	FreeLibrary( m_NWLocalHandle );
}

void CNdsWrapper::InitDllFunctionPointers()
{
	//netwin32.dll functions
	ptrNWCallsInit = (NWDSCALLSINIT)GetProcAddress(m_NWLibHandle,_T("NWNetInit"));
	ptrNWDSCreateContext = (NWDSCREATECONTEXT)GetProcAddress(m_NWLibHandle,_T("NWDSCreateContext"));
	ptrNWDSCreateContextHandle = (NWDSCREATECONTEXTHANDLE)GetProcAddress(m_NWLibHandle, _T("NWDSCreateContextHandle"));
	ptrNWIsDSAuthenticated = (NWISDSAUTHENTICATED)GetProcAddress(m_NWLibHandle, _T("NWIsDSAuthenticated"));
	ptrNWDSSetContext = (NWDSSETCONTEXT)GetProcAddress(m_NWLibHandle, _T("NWDSSetContext"));
	ptrNWDSGetContext = (NWDSGETCONTEXT)GetProcAddress(m_NWLibHandle, _T("NWDSGetContext"));
	ptrNWDSAllocBuf = (NWDSALLOCBUF)GetProcAddress(m_NWLibHandle, _T("NWDSAllocBuf"));
	ptrNWDSList = (NWDSLIST)GetProcAddress(m_NWLibHandle, _T("NWDSList"));
	ptrNWDSGetObjectCount = (NWDSGETOBJECTCOUNT)GetProcAddress(m_NWLibHandle, _T("NWDSGetObjectCount"));
	ptrNWDSGetObjectName = (NWDSGETOBJECTNAME)GetProcAddress(m_NWLibHandle, _T("NWDSGetObjectName"));
	ptrNWDSFreeBuf = (NWDSFREEBUF)GetProcAddress(m_NWLibHandle, _T("NWDSFreeBuf"));
	ptrNWDSFreeContext = (NWDSFREECONTEXT)GetProcAddress(m_NWLibHandle, _T("NWDSFreeContext"));

	ptrNWDSInitBuf = (NWDSINITBUF)GetProcAddress(m_NWLibHandle, _T("NWDSInitBuf"));
	ptrNWDSPutAttrName = (NWDSPUTATTRNAME)GetProcAddress(m_NWLibHandle, _T("NWDSPutAttrName"));
	ptrNWDSRead = (NWDSREAD)GetProcAddress(m_NWLibHandle, _T("NWDSRead"));
	ptrNWDSGetAttrName = (NWDSGETATTRNAME)GetProcAddress(m_NWLibHandle, _T("NWDSGetAttrName"));
	ptrNWDSGetAttrVal = (NWDSGETATTRVAL)GetProcAddress(m_NWLibHandle, _T("NWDSGetAttrVal"));
	ptrNWDSGetAttrCount = (NWDSGETATTRCOUNT)GetProcAddress(m_NWLibHandle, _T("NWDSGetAttrCount"));
	ptrNWDSGetEffectiveRights = (NWDSGETEFFECTIVERIGHTS)GetProcAddress(m_NWLibHandle, _T("NWDSGetEffectiveRights"));

	ptrNWDSAuthenticate = (NWDSAUTHENTICATE)GetProcAddress(m_NWLibHandle, _T("NWDSAuthenticate"));
	ptrNWDSAuthenticateConn = (NWDSAUTHENTICATECONN)GetProcAddress(m_NWLibHandle, _T("NWDSAuthenticateConn"));
	ptrNWDSChangeObjectPassword = (NWDSCHANGEOBJECTPASSWORD)GetProcAddress(m_NWLibHandle, _T("NWDSChangeObjectPassword"));
	ptrNWDSGenerateObjectKeyPair = (NWDSGENERATEOBJECTKEYPAIR)GetProcAddress(m_NWLibHandle, _T("NWDSGenerateObjectKeyPair"));
	ptrNWDSLogin = (NWDSLOGIN)GetProcAddress(m_NWLibHandle, _T("NWDSLogin"));
	ptrNWDSLogout = (NWDSLOGOUT)GetProcAddress(m_NWLibHandle, _T("NWDSLogout"));
	ptrNWDSVerifyObjectPassword = (NWDSVERIFYOBJECTPASSWORD)GetProcAddress(m_NWLibHandle, _T("NWDSVerifyObjectPassword"));
	ptrNWDSOpenConnToNDSServer = (NWDSOPENCONNTONDSSERVER)GetProcAddress(m_NWLibHandle, _T("NWDSOpenConnToNDSServer"));
	ptrNWDSGetDefNameContext = (NWDSGETDEFNAMECONTEXT)GetProcAddress(m_NWLibHandle, _T("NWDSGetDefNameContext"));
	ptrNWDSSetDefNameContext = (NWDSSETDEFNAMECONTEXT)GetProcAddress(m_NWLibHandle, _T("NWDSSetDefNameContext"));
	ptrNWDSGetMonitoredConnRef = (NWDSGETMONITOREDCONNREF)GetProcAddress(m_NWLibHandle, _T("NWDSGetMonitoredConnRef"));
	ptrNWDSOpenMonitoredConn = (NWDSOPENMONITOREDCONN)GetProcAddress(m_NWLibHandle, _T("NWDSOpenMonitoredConn"));
	ptrNWDSScanConnsForTrees = (NWDSSCANCONNSFORTREES)GetProcAddress(m_NWLibHandle, _T("NWDSScanConnsForTrees"));
	ptrNWDSScanForAvailableTrees = (NWDSSCANFORAVAILABLETREES)GetProcAddress(m_NWLibHandle, _T("NWDSScanForAvailableTrees"));
	ptrNWDSReturnBlockOfAvailableTrees = (NWDSRETURNBLOCKOFAVAILABLETREES)GetProcAddress(m_NWLibHandle, _T("NWDSReturnBlockOfAvailableTrees"));
	ptrNWDSSCanDSAuthenticate = (NWDSCANDSAUTHENTICATE)GetProcAddress(m_NWLibHandle, _T("NWDSSCanDSAuthenticate"));
	ptrNWDSPutAttrVal = (NWDSPUTATTRVAL)GetProcAddress(m_NWLibHandle, _T( "NWDSPutAttrVal" ) );
	ptrNWDSAddObject = (NWDSADDOBJECT)GetProcAddress(m_NWLibHandle, _T( "NWDSAddObject" ) );
	ptrNWDSAddFilterToken = (NWDSADDFILTERTOKEN)GetProcAddress(m_NWLibHandle, _T( "NWDSAddFilterToken" ) );
	ptrNWDSAllocFilter = (NWDSALLOCFILTER)GetProcAddress(m_NWLibHandle, _T( "NWDSAllocFilter" ) );
	ptrNWDSPutFilter = (NWDSPUTFILTER)GetProcAddress(m_NWLibHandle, _T( "NWDSPutFilter" ) );
	ptrNWDSSearch = (NWDSSEARCH)GetProcAddress(m_NWLibHandle, _T( "NWDSSearch" ) );
	ptrNWDSComputeAttrValSize = (NWDSCOMPUTEATTRVALSIZE)GetProcAddress(m_NWLibHandle, _T( "NWDSComputeAttrValSize" ) );

	//locwin32.dll functions
	ptrNWLlocaleconv = (NWLLOCALECONV)GetProcAddress(m_NWLocalHandle, _T("NWLlocaleconv"));
	ptrNWInitUnicodeTables = (NWINITUNICODETABLES)GetProcAddress(m_NWLocalHandle, _T("NWInitUnicodeTables"));
	ptrNWFreeUnicodeTables = (NWFREEUNICODETABLES)GetProcAddress(m_NWLocalHandle, _T("NWFreeUnicodeTables"));
}


bool CNdsWrapper::CheckDllFunctionPointers( void )
{
	if(m_NWLibHandle == NULL)
		return false;

	if(m_NWLocalHandle == NULL)
		return false;

	bool bRetval = true;

	if (!ptrNWCallsInit)
	{
		LogMsg(LOG_INFO, "Could Not Find NWNetInit in NetWin32.dll");
		bRetval =  false;
	}
	if (!ptrNWDSCreateContext)
	{
		LogMsg(LOG_INFO, "Could Not Find NWDSCreateContext in NetWin32.dll");
		bRetval =  false;
	}
    if (!ptrNWDSCreateContextHandle)
	{
		LogMsg(LOG_INFO, "Could Not Find NWDSCreateContextHandle in NetWin32.dll");
		bRetval =  false;
	}
    if (!ptrNWIsDSAuthenticated)
	{
		LogMsg(LOG_INFO, "Could Not Find NWIsDSAuthenticated in NetWin32.dll");
		bRetval =  false;
	}
	if (!ptrNWDSSetContext)
	{
		LogMsg(LOG_INFO, "Could Not Find NWDSSetContext in NetWin32.dll");
		bRetval =  false;
	}
    if (!ptrNWDSGetContext)
	{
		LogMsg(LOG_INFO, "Could Not Find NWDSGetContext in NetWin32.dll");
		bRetval =  false;
	}
	if (!ptrNWDSAllocBuf)
	{
		LogMsg(LOG_INFO, "Could Not Find NWDSAllocBuf in NetWin32.dll");
		bRetval =  false;
	}
	if (!ptrNWDSList) 
	{
		LogMsg(LOG_INFO, "Could Not Find NWDSList in NetWin32.dll");
		bRetval =  false;
	}
	if (!ptrNWDSGetObjectCount)
	{
		LogMsg(LOG_INFO, "Could Not Find NWDSGetObjectCount in NetWin32.dll");
		bRetval =  false;
	}
	if (!ptrNWDSGetObjectName) 
	{
		LogMsg(LOG_INFO, "Could Not Find NWDSGetObjectName in NetWin32.dll");
		bRetval =  false;
	}
	if (!ptrNWDSFreeBuf)
	{
		LogMsg(LOG_INFO, "Could Not Find NWDSFreeBuf in NetWin32.dll");
		bRetval =  false;
	}
	if (!ptrNWDSFreeContext)
	{
		LogMsg(LOG_INFO, "Could Not Find NWDSFreeContext in NetWin32.dll");
		bRetval =  false;
	}
	if (!ptrNWDSInitBuf)
	{
		LogMsg(LOG_INFO, "Could Not Find NWDSInitBuf in NetWin32.dll");
		bRetval =  false;
	}
	if (!ptrNWDSPutAttrName)
	{
		LogMsg(LOG_INFO, "Could Not Find NWDSPutAttrName in NetWin32.dll");
		bRetval =  false;
	}
	if (!ptrNWDSRead) 
	{
		LogMsg(LOG_INFO, "Could Not Find NWDSRead in NetWin32.dll");
		bRetval =  false;
	}
	if (!ptrNWDSGetAttrName)
	{
		LogMsg(LOG_INFO, "Could Not Find NWDSGetAttrName in NetWin32.dll");
		bRetval =  false;
	}
	if (!ptrNWDSGetAttrVal)
	{
		LogMsg(LOG_INFO, "Could Not Find NWDSGetAttrVal in NetWin32.dll");
		bRetval =  false;
	}
	if (!ptrNWDSGetAttrCount)
	{
		LogMsg(LOG_INFO, "Could Not Find NWDSGetAttrCount in NetWin32.dll");
		bRetval =  false;
	}
	if (!ptrNWDSPutAttrVal)
	{
		LogMsg(LOG_INFO, "Could Not Find NWDSPutAttrVal in NetWin32.dll");
		bRetval =  false;
	}
	if (!ptrNWDSAddObject)
	{
		LogMsg(LOG_INFO, "Could Not Find NWDSAddObject in NetWin32.dll");
		bRetval =  false;
	}
	if (!ptrNWDSAddFilterToken)
	{
		LogMsg(LOG_INFO, "Could Not Find NWDSAddFilterToken in NetWin32.dll");
		bRetval =  false;
	}
	if (!ptrNWDSAllocFilter)
	{
		LogMsg(LOG_INFO, "Could Not Find NWDSAllocFilter in NetWin32.dll");
		bRetval =  false;
	}
	if (!ptrNWDSPutFilter)
	{
		LogMsg(LOG_INFO, "Could Not Find NWDSPutFilter in NetWin32.dll");
		bRetval =  false;
	}
	if (!ptrNWDSSearch)
	{
		LogMsg(LOG_INFO, "Could Not Find NWDSSearch in NetWin32.dll");
		bRetval =  false;
	}
	if (!ptrNWDSComputeAttrValSize)
	{
		LogMsg(LOG_INFO, "Could Not Find NWDSComputeAttrValSize in NetWin32.dll");
		bRetval =  false;
	}

	//locwin32.dll functions
	if (!ptrNWLlocaleconv)
	{
		LogMsg(LOG_INFO, "Could Not Find NWLlocaleconv in LocWin32.dll");
		bRetval =  false;
	}
	if (!ptrNWInitUnicodeTables)
	{
		LogMsg(LOG_INFO, "Could Not Find NWInitUnicodeTables in LocWin.dll");
		bRetval =  false;
	}
	if (!ptrNWFreeUnicodeTables)
	{
		LogMsg(LOG_INFO, "Could Not Find NWFreeUnicodeTables in LocWin.dll");
		bRetval =  false;
	}

	return bRetval;
}





/////////////////////////////////////////////////////
// CNDS

CNDS::CNDS( void )
: m_NdsWrapper( ), m_strContext( _T( "" ) ), m_context( 0 ), m_ccode( 0 ), m_nwccode( 0 ), m_lConvInfo( )
{
}

CNDS::~CNDS( void )
{
	Logout( );
}

bool CNDS::Login( LPCTSTR szContext, LPCTSTR szUid, LPCTSTR szPwd )
{
	if( m_NdsWrapper.CheckDllFunctionPointers( ) )
	{
		m_ccode = m_NdsWrapper.ptrNWCallsInit( NULL,NULL );
		if( m_ccode )
			return false;

		m_NdsWrapper.ptrNWLlocaleconv( &m_lConvInfo );
		m_ccode = m_NdsWrapper.ptrNWInitUnicodeTables( m_lConvInfo.country_id, m_lConvInfo.code_page );
		if( m_ccode )
			return false;

		m_ccode = m_NdsWrapper.ptrNWDSCreateContextHandle( &m_context );
		if( m_ccode )
		{
			m_NdsWrapper.ptrNWFreeUnicodeTables( );
			return false;
		}

		// set m_context values here
		//m_ccode = m_NdsWrapper.ptrNWDSSetContext( m_context, DCK_TREE_NAME, _T( "ERNIE" ) );
		m_ccode = m_NdsWrapper.ptrNWDSSetContext( m_context, DCK_NAME_CONTEXT, ( LPVOID ) szContext );

		m_ccode = m_NdsWrapper.ptrNWDSLogin( m_context, 0, ( LPTSTR ) szUid, ( LPTSTR ) szPwd, 0 );
		if( m_ccode )
		{
			m_NdsWrapper.ptrNWDSFreeContext( m_context );
			m_NdsWrapper.ptrNWFreeUnicodeTables( );
			return false;
		}
	}
	else
		return false;

	return true;
}

bool CNDS::Logout( void )
{
	try
	{
		m_ccode = m_NdsWrapper.ptrNWDSLogout( m_context );
		if( m_ccode )
			return false;

		m_ccode = m_NdsWrapper.ptrNWDSFreeContext( m_context );
		if( m_ccode )
			return false;

		m_ccode = m_NdsWrapper.ptrNWFreeUnicodeTables( );
		if( m_ccode )
			return false;
	}

	catch( ... )
	{
		return false;
	}

	return true;
}

void CNDS::CanonicalizeDN( CString& strDN )
{
	strDN.Replace( _T( "OU=" ), _T( "" ) );
}

void CNDS::GetFirstValue( CString& strDN )
{
	// gets the first value
	// e.g. "CN=Matthew.OU=Container"
	// becomes "Matthew"

	int iEqual = strDN.Find( _T( '=' ), 0 );
	int iPeriod = strDN.Find( _T( '.' ), 0 );
	if( iPeriod == -1 )
		iPeriod = strDN.GetLength( ) + 1;

	int iLength = iPeriod - iEqual - 1;
	strDN = strDN.Mid( iEqual + 1, iLength );
}

bool CNDS::GetOrgUnits( LPCTSTR szContext, CDSORGUNITLIST& lstOU )
{
	if( !m_NdsWrapper.ptrNWIsDSAuthenticated( ) )
		return false;

	lstOU.RemoveAll( );

	// verify szContext is a valid context
	if( _tcslen( szContext ) > 0 )
	{
		m_ccode = m_NdsWrapper.ptrNWDSSetContext( m_context, DCK_NAME_CONTEXT, ( nptr ) szContext );
		if( m_ccode )
			return false;
	}

	// get context
	nstr8 strContext[ MAX_DN_CHARS + 1 ];
	m_ccode = m_NdsWrapper.ptrNWDSGetContext( m_context, DCK_NAME_CONTEXT, strContext );
	if( m_ccode )
		return false;

	m_strContext = strContext;
	CanonicalizeDN( m_strContext );

	// allocate space for the buffers
	pBuf_T pBuf;
	m_ccode = m_NdsWrapper.ptrNWDSAllocBuf( ( size_t ) DEFAULT_MESSAGE_LEN, &pBuf );
	if( m_ccode )
		return false;

	// DO loop to get all the objects names
	nint32	lIterationHandle = NO_MORE_ITERATIONS;
	nuint32	luObjectCount, luAttrCount;
	nstr8 strObjectName[MAX_DN_CHARS+1];
	Object_Info_T objectInfo;
	nuint32 i;

	do 
	{
		m_ccode = m_NdsWrapper.ptrNWDSList( m_context, "", &lIterationHandle, pBuf );
		if( m_ccode )
			break;

		m_ccode = m_NdsWrapper.ptrNWDSGetObjectCount( m_context, pBuf, &luObjectCount );
		if( m_ccode )
			break;

		for( i=0; i<luObjectCount; i++ )
		{
			m_ccode = m_NdsWrapper.ptrNWDSGetObjectName( m_context, pBuf, strObjectName, &luAttrCount, &objectInfo );
			if( m_ccode )
				break;

			if( ( toupper( strObjectName[ 0 ] ) == _T( 'O' ) ) && ( toupper( strObjectName[ 1 ] ) == _T( 'U' ) ) )
			{
				CDSOrgUnit* pOrgUnit = new CDSOrgUnit( &strObjectName[ 3 ], &strObjectName[ 3 ], ( LPCTSTR ) m_strContext, _T( "" ) );
				lstOU.AddBack( pOrgUnit );
			}
			else if( toupper( strObjectName[ 0 ] ) == _T( 'O' ) )
			{
				CDSOrgUnit* pOrgUnit = new CDSOrgUnit( &strObjectName[ 2 ], &strObjectName[ 2 ], ( LPCTSTR ) m_strContext, _T( "" ) );
				lstOU.AddBack( pOrgUnit );
			}
		}
	} while( lIterationHandle!=NO_MORE_ITERATIONS );

	// cleanup buffer
	m_NdsWrapper.ptrNWDSFreeBuf( pBuf );

	return true;
}



bool CNDS::GetUsers( LPCTSTR szContext, CDSUSERLIST& lstUser )
{
	if( !m_NdsWrapper.ptrNWIsDSAuthenticated( ) )
		return false;

	lstUser.RemoveAll( );

	// verify szContext is a valid context
	if( _tcslen( szContext ) > 0 )
	{
		m_ccode = m_NdsWrapper.ptrNWDSSetContext( m_context, DCK_NAME_CONTEXT, ( nptr ) szContext );
		if( m_ccode )
			return false;
	}

	// get context
	nstr8 strContext[ MAX_DN_CHARS + 1 ];
	m_ccode = m_NdsWrapper.ptrNWDSGetContext( m_context, DCK_NAME_CONTEXT, strContext );
	if( m_ccode )
		return false;

	m_strContext = strContext;
	CanonicalizeDN( m_strContext );

	// allocate space for the buffers
	pBuf_T pBuf, pInBuf, pOutBuf;
	m_ccode = m_NdsWrapper.ptrNWDSAllocBuf( ( size_t ) DEFAULT_MESSAGE_LEN, &pBuf );
	if( m_ccode )
		return false;
	m_ccode = m_NdsWrapper.ptrNWDSAllocBuf( ( size_t) DEFAULT_MESSAGE_LEN, &pInBuf );
	if( m_ccode )
		return false;
	m_ccode = m_NdsWrapper.ptrNWDSAllocBuf( ( size_t) DEFAULT_MESSAGE_LEN, &pOutBuf );
	if( m_ccode )
		return false;

	// DO loop to get all the objects names
	nint32	lIterationHandle = NO_MORE_ITERATIONS, lIter = NO_MORE_ITERATIONS;;
	nuint32	luObjectCount, luAttrCount;
	nstr8 strObjectName[MAX_DN_CHARS+1];
	Object_Info_T objectInfo;
	nuint32 i;

	do 
	{
		m_ccode = m_NdsWrapper.ptrNWDSList( m_context, "", &lIterationHandle, pBuf );
		if( m_ccode )
			break;

		m_ccode = m_NdsWrapper.ptrNWDSGetObjectCount( m_context, pBuf, &luObjectCount );
		if( m_ccode )
			break;

		for( i=0; i<luObjectCount; i++ )
		{
			m_ccode = m_NdsWrapper.ptrNWDSGetObjectName( m_context, pBuf, strObjectName, &luAttrCount, &objectInfo );
			if( m_ccode )
				break;

			// skip objects that are not users
			if( _tcsicmp( objectInfo.baseClass, _T( "User" ) ) != 0 )
				continue;
				
			NWSYNTAX_ID	syntax;
			NWCOUNT attrCount;
			NWCOUNT	valCount;
			char attrName[ MAX_DN_CHARS + 1 ];
			char attrVal[ MAX_DN_CHARS + 1 ];
			uint8 bDisableLogin;

			// get ID attribute
			m_ccode = m_NdsWrapper.ptrNWDSInitBuf( m_context, DSV_READ, pInBuf );
			m_ccode = m_NdsWrapper.ptrNWDSPutAttrName( m_context, pInBuf, ( char NWFAR* ) A_FULL_NAME );
			m_ccode = m_NdsWrapper.ptrNWDSRead( m_context, strObjectName, DS_ATTRIBUTE_VALUES, FALSE, pInBuf, &lIter, pOutBuf );
			CString strId = &strObjectName[ 3 ];
	
			// get full name attribute
			CString strFullName = _T( "" );
			if( m_ccode == 0 )
			{
				m_ccode = m_NdsWrapper.ptrNWDSGetAttrCount( m_context, pOutBuf, &attrCount );
				m_ccode = m_NdsWrapper.ptrNWDSGetAttrName( m_context, pOutBuf, attrName, &valCount, &syntax );
				m_ccode = m_NdsWrapper.ptrNWDSGetAttrVal( m_context, pOutBuf, syntax, attrVal );
	
				strFullName = attrVal;
			}

			// get login disabled attribute
			bool bAllowLogin = false;
			lIter = NO_MORE_ITERATIONS;
			m_ccode = m_NdsWrapper.ptrNWDSFreeBuf( pInBuf );
			m_ccode = m_NdsWrapper.ptrNWDSAllocBuf( ( size_t ) DEFAULT_MESSAGE_LEN, &pInBuf );
			m_ccode = m_NdsWrapper.ptrNWDSInitBuf( m_context, DSV_READ, pInBuf );
			m_ccode = m_NdsWrapper.ptrNWDSFreeBuf( pOutBuf );
			m_ccode = m_NdsWrapper.ptrNWDSAllocBuf( ( size_t ) DEFAULT_MESSAGE_LEN, &pOutBuf );
			m_ccode = m_NdsWrapper.ptrNWDSPutAttrName( m_context, pInBuf, ( char NWFAR* ) A_LOGIN_DISABLED );
			//if the login flag is set, syntax==7,  type SYN_BOOLEAN
			m_ccode = m_NdsWrapper.ptrNWDSRead( m_context, ( pnstr8 ) ( LPCTSTR ) strId, DS_ATTRIBUTE_VALUES, FALSE, pInBuf, &lIter, pOutBuf);
			if( m_ccode == ERR_NO_SUCH_ENTRY )
			{
				//Object does not exist
				continue;
			}
			else if( m_ccode == ERR_NO_SUCH_ATTRIBUTE )
			{
				//assume the property is not set
				bAllowLogin = true;
			}
			else if( m_ccode )
			{
				//generic error
				continue;
			}
			else
			{
				m_ccode = m_NdsWrapper.ptrNWDSGetAttrCount( m_context, pOutBuf, &attrCount);
				m_ccode = m_NdsWrapper.ptrNWDSGetAttrName( m_context, pOutBuf, attrName, &valCount, &syntax );
				m_ccode = m_NdsWrapper.ptrNWDSGetAttrVal( m_context, pOutBuf, syntax, &bDisableLogin );
				if( bDisableLogin )
					bAllowLogin = false;
				else
					bAllowLogin = true;
			}

			// get telephone attribute
			CString strTelephone = _T( "" );
			lIter = NO_MORE_ITERATIONS;
			m_ccode = m_NdsWrapper.ptrNWDSFreeBuf( pInBuf );
			m_ccode = m_NdsWrapper.ptrNWDSAllocBuf( ( size_t ) DEFAULT_MESSAGE_LEN, &pInBuf );
			m_ccode = m_NdsWrapper.ptrNWDSInitBuf( m_context, DSV_READ, pInBuf );
			m_ccode = m_NdsWrapper.ptrNWDSFreeBuf( pOutBuf );
			m_ccode = m_NdsWrapper.ptrNWDSAllocBuf( ( size_t ) DEFAULT_MESSAGE_LEN, &pOutBuf );
			m_ccode = m_NdsWrapper.ptrNWDSPutAttrName( m_context, pInBuf, ( char NWFAR* ) A_TELEPHONE_NUMBER );
			m_ccode = m_NdsWrapper.ptrNWDSRead( m_context, ( pnstr8 ) ( LPCTSTR ) strId, DS_ATTRIBUTE_VALUES, FALSE, pInBuf, &lIter, pOutBuf);
			if( m_ccode == ERR_NO_SUCH_ENTRY )
			{
				//Object does not exist
				continue;
			}
			else if( m_ccode == ERR_NO_SUCH_ATTRIBUTE )
			{
				//assume the property is not set
				strTelephone = _T( "" );
			}
			else if( m_ccode )
			{
				//generic error
				continue;
			}
			else
			{
				m_ccode = m_NdsWrapper.ptrNWDSGetAttrCount( m_context, pOutBuf, &attrCount);
				m_ccode = m_NdsWrapper.ptrNWDSGetAttrName( m_context, pOutBuf, attrName, &valCount, &syntax );
				m_ccode = m_NdsWrapper.ptrNWDSGetAttrVal( m_context, pOutBuf, syntax, attrVal );

				strTelephone = attrVal;
			}


			// get fax attribute
			CString strFax = _T( "" );
			lIter = NO_MORE_ITERATIONS;
			m_ccode = m_NdsWrapper.ptrNWDSFreeBuf( pInBuf );
			m_ccode = m_NdsWrapper.ptrNWDSAllocBuf( ( size_t ) DEFAULT_MESSAGE_LEN, &pInBuf );
			m_ccode = m_NdsWrapper.ptrNWDSInitBuf( m_context, DSV_READ, pInBuf );
			m_ccode = m_NdsWrapper.ptrNWDSFreeBuf( pOutBuf );
			m_ccode = m_NdsWrapper.ptrNWDSAllocBuf( ( size_t ) DEFAULT_MESSAGE_LEN, &pOutBuf );
			m_ccode = m_NdsWrapper.ptrNWDSPutAttrName( m_context, pInBuf, ( char NWFAR* ) A_FACSIMILE_TELEPHONE_NUMBER );
			m_ccode = m_NdsWrapper.ptrNWDSRead( m_context, ( pnstr8 ) ( LPCTSTR ) strId, DS_ATTRIBUTE_VALUES, FALSE, pInBuf, &lIter, pOutBuf);
			if( m_ccode == ERR_NO_SUCH_ENTRY )
			{
				//Object does not exist
				continue;
			}
			else if( m_ccode == ERR_NO_SUCH_ATTRIBUTE )
			{
				//assume the property is not set
				strFax = _T( "" );
			}
			else if( m_ccode )
			{
				//generic error
				continue;
			}
			else
			{
				m_ccode = m_NdsWrapper.ptrNWDSGetAttrCount( m_context, pOutBuf, &attrCount);
				m_ccode = m_NdsWrapper.ptrNWDSGetAttrName( m_context, pOutBuf, attrName, &valCount, &syntax );

				
				// fax is a multiply-valued attribute so just get first value
				for( NWCOUNT n = 0; n<valCount; n++ )
				{
					nuint32 ulAttrValSize;
					m_ccode = m_NdsWrapper.ptrNWDSComputeAttrValSize( m_context, pOutBuf, syntax, &ulAttrValSize );

					BYTE* pfax = new BYTE[ ulAttrValSize ];

					m_ccode = m_NdsWrapper.ptrNWDSGetAttrVal( m_context, pOutBuf, syntax, ( LPVOID ) pfax );

					if( n == 0 )
					{
						Fax_Number_T *pTemp = ( Fax_Number_T * ) pfax;
						strFax = pTemp->telephoneNumber;
					}

					delete [] pfax;
				}
			}


			// get location attribute
			CString strLocation = _T( "" );
			lIter = NO_MORE_ITERATIONS;
			m_ccode = m_NdsWrapper.ptrNWDSFreeBuf( pInBuf );
			m_ccode = m_NdsWrapper.ptrNWDSAllocBuf( ( size_t ) DEFAULT_MESSAGE_LEN, &pInBuf );
			m_ccode = m_NdsWrapper.ptrNWDSInitBuf( m_context, DSV_READ, pInBuf );
			m_ccode = m_NdsWrapper.ptrNWDSFreeBuf( pOutBuf );
			m_ccode = m_NdsWrapper.ptrNWDSAllocBuf( ( size_t ) DEFAULT_MESSAGE_LEN, &pOutBuf );
			m_ccode = m_NdsWrapper.ptrNWDSPutAttrName( m_context, pInBuf, ( char NWFAR* ) A_LOCALITY_NAME );
			m_ccode = m_NdsWrapper.ptrNWDSRead( m_context, ( pnstr8 ) ( LPCTSTR ) strId, DS_ATTRIBUTE_VALUES, FALSE, pInBuf, &lIter, pOutBuf);
			if( m_ccode == ERR_NO_SUCH_ENTRY )
			{
				//Object does not exist
				continue;
			}
			else if( m_ccode == ERR_NO_SUCH_ATTRIBUTE )
			{
				//assume the property is not set
				strLocation = _T( "" );
			}
			else if( m_ccode )
			{
				//generic error
				continue;
			}
			else
			{
				m_ccode = m_NdsWrapper.ptrNWDSGetAttrCount( m_context, pOutBuf, &attrCount);
				m_ccode = m_NdsWrapper.ptrNWDSGetAttrName( m_context, pOutBuf, attrName, &valCount, &syntax );
				m_ccode = m_NdsWrapper.ptrNWDSGetAttrVal( m_context, pOutBuf, syntax, attrVal );

				strLocation = attrVal;
			}


			// get email attribute
			CString strEmail = _T( "" );
			lIter = NO_MORE_ITERATIONS;
			m_ccode = m_NdsWrapper.ptrNWDSFreeBuf( pInBuf );
			m_ccode = m_NdsWrapper.ptrNWDSAllocBuf( ( size_t ) DEFAULT_MESSAGE_LEN, &pInBuf );
			m_ccode = m_NdsWrapper.ptrNWDSInitBuf( m_context, DSV_READ, pInBuf );
			m_ccode = m_NdsWrapper.ptrNWDSFreeBuf( pOutBuf );
			m_ccode = m_NdsWrapper.ptrNWDSAllocBuf( ( size_t ) DEFAULT_MESSAGE_LEN, &pOutBuf );
			m_ccode = m_NdsWrapper.ptrNWDSPutAttrName( m_context, pInBuf, ( char NWFAR* ) _T( "Internet EMail Address" ) );
			m_ccode = m_NdsWrapper.ptrNWDSRead( m_context, ( pnstr8 ) ( LPCTSTR ) strId, DS_ATTRIBUTE_VALUES, FALSE, pInBuf, &lIter, pOutBuf);
			if( m_ccode == ERR_NO_SUCH_ENTRY )
			{
				//Object does not exist
				continue;
			}
			else if( m_ccode == ERR_NO_SUCH_ATTRIBUTE )
			{
				//assume the property is not set
				strEmail = _T( "" );
			}
			else if( m_ccode )
			{
				//generic error
				continue;
			}
			else
			{
				m_ccode = m_NdsWrapper.ptrNWDSGetAttrCount( m_context, pOutBuf, &attrCount);
				m_ccode = m_NdsWrapper.ptrNWDSGetAttrName( m_context, pOutBuf, attrName, &valCount, &syntax );

				// email is a multiply-valued attribute so just get first value
				for( NWCOUNT n = 0; n<valCount; n++ )
				{
					m_ccode = m_NdsWrapper.ptrNWDSGetAttrVal( m_context, pOutBuf, syntax, attrVal );

					if( n == 0 )
						strEmail = attrVal;
				}
			}


			// create user object and add to end of list
			CDSUser* pUser = new CDSUser( 
				_T( "" ),					// Full DN
				( LPCTSTR ) strFullName, 
				_T( "" ),					// k1syncId
				( LPCTSTR ) strId, 
				( LPCTSTR ) m_strContext, 
				( LPCTSTR ) strTelephone,
				( LPCTSTR ) strFax,
				( LPCTSTR ) strLocation,
				( LPCTSTR ) strEmail,
				bAllowLogin 
				);
			lstUser.AddBack( pUser );
		}
	} while( lIterationHandle!=NO_MORE_ITERATIONS );

	// cleanup buffers
	m_NdsWrapper.ptrNWDSFreeBuf( pOutBuf );
	m_NdsWrapper.ptrNWDSFreeBuf( pInBuf) ;
	m_NdsWrapper.ptrNWDSFreeBuf( pBuf );

	return true;
}

bool CNDS::GetGroups( LPCTSTR szContext, CDSGROUPLIST& lstGroup )
{
	if( !m_NdsWrapper.ptrNWIsDSAuthenticated( ) )
		return false;

	lstGroup.RemoveAll( );

	// verify szContext is a valid context
	if( _tcslen( szContext ) > 0 )
	{
		m_ccode = m_NdsWrapper.ptrNWDSSetContext( m_context, DCK_NAME_CONTEXT, ( nptr ) szContext );
		if( m_ccode )
			return false;
	}

	// get context
	nstr8 strContext[ MAX_DN_CHARS + 1 ];
	m_ccode = m_NdsWrapper.ptrNWDSGetContext( m_context, DCK_NAME_CONTEXT, strContext );
	if( m_ccode )
		return false;

	m_strContext = strContext;
	CanonicalizeDN( m_strContext );

	// allocate space for the buffers
	pBuf_T pBuf, pInBuf, pOutBuf;
	m_ccode = m_NdsWrapper.ptrNWDSAllocBuf( ( size_t ) DEFAULT_MESSAGE_LEN, &pBuf );
	if( m_ccode )
		return false;
	m_ccode = m_NdsWrapper.ptrNWDSAllocBuf( ( size_t) DEFAULT_MESSAGE_LEN, &pInBuf );
	if( m_ccode )
		return false;
	m_ccode = m_NdsWrapper.ptrNWDSAllocBuf( ( size_t) DEFAULT_MESSAGE_LEN, &pOutBuf );
	if( m_ccode )
		return false;

	// DO loop to get all the objects names
	nint32	lIterationHandle = NO_MORE_ITERATIONS, lIter = NO_MORE_ITERATIONS;;
	nuint32	luObjectCount, luAttrCount;
	nstr8 strObjectName[MAX_DN_CHARS+1];
	Object_Info_T objectInfo;
	nuint32 i;

	do 
	{
		m_ccode = m_NdsWrapper.ptrNWDSList( m_context, "", &lIterationHandle, pBuf );
		if( m_ccode )
			break;

		m_ccode = m_NdsWrapper.ptrNWDSGetObjectCount( m_context, pBuf, &luObjectCount );
		if( m_ccode )
			break;

		for( i=0; i<luObjectCount; i++ )
		{
			m_ccode = m_NdsWrapper.ptrNWDSGetObjectName( m_context, pBuf, strObjectName, &luAttrCount, &objectInfo );
			if( m_ccode )
				break;

			// skip objects that are not users
			if( _tcsicmp( objectInfo.baseClass, _T( "Group" ) ) != 0 )
				continue;
			
			NWSYNTAX_ID	syntax;
			NWCOUNT attrCount;
			NWCOUNT	valCount;
			char attrName[ MAX_DN_CHARS + 1 ];
			char attrVal[ MAX_DN_CHARS + 1 ];
			uint8 bDisableLogin;

			// get ID attribute
			CString strId = &strObjectName[ 3 ];

			// get full name attribute
			CString strFullName = _T( "" );
			m_ccode = m_NdsWrapper.ptrNWDSInitBuf( m_context, DSV_READ, pInBuf );
			m_ccode = m_NdsWrapper.ptrNWDSPutAttrName( m_context, pInBuf, ( char NWFAR* ) A_FULL_NAME );
			m_ccode = m_NdsWrapper.ptrNWDSRead( m_context, strObjectName, DS_ATTRIBUTE_VALUES, FALSE, pInBuf, &lIter, pOutBuf );
			if( m_ccode == 0 )
			{
				m_ccode = m_NdsWrapper.ptrNWDSGetAttrCount( m_context, pOutBuf, &attrCount );
				m_ccode = m_NdsWrapper.ptrNWDSGetAttrName( m_context, pOutBuf, attrName, &valCount, &syntax );
				m_ccode = m_NdsWrapper.ptrNWDSGetAttrVal( m_context, pOutBuf, syntax, attrVal );
	
				strFullName = attrVal;
			}

			// get login disabled attribute
			bool bAllowLogin = false;
			lIter = NO_MORE_ITERATIONS;
			m_ccode = m_NdsWrapper.ptrNWDSFreeBuf( pInBuf );
			m_ccode = m_NdsWrapper.ptrNWDSAllocBuf( ( size_t ) DEFAULT_MESSAGE_LEN, &pInBuf );
			m_ccode = m_NdsWrapper.ptrNWDSInitBuf( m_context, DSV_READ, pInBuf );
			m_ccode = m_NdsWrapper.ptrNWDSFreeBuf( pOutBuf );
			m_ccode = m_NdsWrapper.ptrNWDSAllocBuf( ( size_t ) DEFAULT_MESSAGE_LEN, &pOutBuf );
			m_ccode = m_NdsWrapper.ptrNWDSPutAttrName( m_context, pInBuf, ( char NWFAR* ) A_LOGIN_DISABLED );
			//if the login flag is set, syntax==7,  type SYN_BOOLEAN
			m_ccode = m_NdsWrapper.ptrNWDSRead( m_context, ( pnstr8 ) ( LPCTSTR ) strId, DS_ATTRIBUTE_VALUES, FALSE, pInBuf, &lIter, pOutBuf);
			if( m_ccode == ERR_NO_SUCH_ENTRY )
			{
				//Object does not exist
				continue;
			}
			else if( m_ccode == ERR_NO_SUCH_ATTRIBUTE )
			{
				//assume the property is not set
				bAllowLogin = true;
			}
			else if( m_ccode )
			{
				//generic error
				continue;
			}
			else
			{
				m_ccode = m_NdsWrapper.ptrNWDSGetAttrCount( m_context, pOutBuf, &attrCount);
				m_ccode = m_NdsWrapper.ptrNWDSGetAttrName( m_context, pOutBuf, attrName, &valCount, &syntax );
				m_ccode = m_NdsWrapper.ptrNWDSGetAttrVal( m_context, pOutBuf, syntax, &bDisableLogin );
				if( bDisableLogin )
					bAllowLogin = false;
				else
					bAllowLogin = true;
			}

			// get description attribute
			CString strDescription = _T( "" );
			lIter = NO_MORE_ITERATIONS;
			m_ccode = m_NdsWrapper.ptrNWDSFreeBuf( pInBuf );
			m_ccode = m_NdsWrapper.ptrNWDSAllocBuf( ( size_t ) DEFAULT_MESSAGE_LEN, &pInBuf );
			m_ccode = m_NdsWrapper.ptrNWDSInitBuf( m_context, DSV_READ, pInBuf );
			m_ccode = m_NdsWrapper.ptrNWDSFreeBuf( pOutBuf );
			m_ccode = m_NdsWrapper.ptrNWDSAllocBuf( ( size_t ) DEFAULT_MESSAGE_LEN, &pOutBuf );
			m_ccode = m_NdsWrapper.ptrNWDSPutAttrName( m_context, pInBuf, ( char NWFAR* ) A_DESCRIPTION );
			m_ccode = m_NdsWrapper.ptrNWDSRead( m_context, ( pnstr8 ) ( LPCTSTR ) strId, DS_ATTRIBUTE_VALUES, FALSE, pInBuf, &lIter, pOutBuf);
			if( m_ccode == ERR_NO_SUCH_ENTRY )
			{
				//Object does not exist
				continue;
			}
			else if( m_ccode == ERR_NO_SUCH_ATTRIBUTE )
			{
				//assume the property is not set
				strDescription = _T( "" );
			}
			else if( m_ccode )
			{
				//generic error
				continue;
			}
			else
			{
				m_ccode = m_NdsWrapper.ptrNWDSGetAttrCount( m_context, pOutBuf, &attrCount);
				m_ccode = m_NdsWrapper.ptrNWDSGetAttrName( m_context, pOutBuf, attrName, &valCount, &syntax );
				m_ccode = m_NdsWrapper.ptrNWDSGetAttrVal( m_context, pOutBuf, syntax, attrVal );

				strDescription = attrVal;
			}

			// create user object and add to end of list
			// use the DESCRIPTION field first and then the FULLNAME field
			ObjectContainers::CUniqueBstrVector vtMembers;

			CDSGroup* pGroup = new CDSGroup( 
				_T( "" ),			// DN
				( ( strFullName.GetLength( ) > 0 ) ? ( LPCTSTR ) strFullName : ( LPCTSTR ) strDescription ), 
				( LPCTSTR ) m_strContext, 
				_T( "" ),			// k1syncid
				( LPCTSTR ) strId, 
				vtMembers,
				bAllowLogin );
			lstGroup.AddBack( pGroup );
		}
	} while( lIterationHandle!=NO_MORE_ITERATIONS );

	// cleanup buffers
	m_NdsWrapper.ptrNWDSFreeBuf( pOutBuf );
	m_NdsWrapper.ptrNWDSFreeBuf( pInBuf) ;
	m_NdsWrapper.ptrNWDSFreeBuf( pBuf );

	return true;
}

bool CNDS::GetGroupMembers( LPCTSTR szContext, CDSGroup& NDSGroup )
{
	if( !m_NdsWrapper.ptrNWIsDSAuthenticated( ) )
		return false;

	// verify szContext is a valid context
	if( _tcslen( szContext ) > 0 )
	{
		m_ccode = m_NdsWrapper.ptrNWDSSetContext( m_context, DCK_NAME_CONTEXT, ( nptr ) szContext );
		if( m_ccode )
			return false;
	}
	else
	{
		m_ccode = m_NdsWrapper.ptrNWDSSetContext( m_context, DCK_NAME_CONTEXT, ( nptr ) ( LPCTSTR ) m_strContext );
		if( m_ccode )
			return false;
	}

	// get context
	nstr8 strContext[ MAX_DN_CHARS + 1 ];
	m_ccode = m_NdsWrapper.ptrNWDSGetContext( m_context, DCK_NAME_CONTEXT, strContext );
	if( m_ccode )
		return false;

	m_strContext = strContext;
	CanonicalizeDN( m_strContext );

	// allocate space for the buffers
	pBuf_T pInBuf, pOutBuf;
	m_ccode = m_NdsWrapper.ptrNWDSAllocBuf( ( size_t) DEFAULT_MESSAGE_LEN, &pInBuf );
	if( m_ccode )
		return false;
	m_ccode = m_NdsWrapper.ptrNWDSAllocBuf( ( size_t) DEFAULT_MESSAGE_LEN, &pOutBuf );
	if( m_ccode )
		return false;

	// DO loop to get all the objects names
	nint32	lIterationHandle = NO_MORE_ITERATIONS;
	nuint32 i, j;

	NWSYNTAX_ID	syntax;
	NWCOUNT attrCount;
	NWCOUNT	valCount;
	char attrName[MAX_DN_CHARS+1];
	char attrVal[MAX_DN_CHARS+1];

	m_ccode = m_NdsWrapper.ptrNWDSInitBuf( m_context, DSV_READ, pInBuf );
	m_ccode = m_NdsWrapper.ptrNWDSPutAttrName( m_context, pInBuf, ( char NWFAR* ) A_MEMBER );

	do
	{
		m_ccode = m_NdsWrapper.ptrNWDSRead( m_context, ( pnstr8 ) ( LPCTSTR ) NDSGroup.GetGroupId( ), DS_ATTRIBUTE_VALUES, FALSE, pInBuf, &lIterationHandle, pOutBuf );
							
		if( m_ccode == 0 )
		{
			m_ccode = m_NdsWrapper.ptrNWDSGetAttrCount( m_context, pOutBuf, &attrCount );
			for( i=0; i<attrCount; i++ )
			{
				m_ccode = m_NdsWrapper.ptrNWDSGetAttrName( m_context, pOutBuf, attrName, &valCount, &syntax );
				for( j=0; j<valCount; j++ )
				{
					m_ccode = m_NdsWrapper.ptrNWDSGetAttrVal( m_context, pOutBuf, syntax, attrVal );

					CString strId = &attrVal[ 0 ];
					GetFirstValue( strId );
					NDSGroup.AddMember( ( LPCTSTR ) strId );
				}
			}
		}
	} while(lIterationHandle!=NO_MORE_ITERATIONS);

	// cleanup
	m_NdsWrapper.ptrNWDSFreeBuf(pInBuf);
	m_NdsWrapper.ptrNWDSFreeBuf(pOutBuf);

	return true;
}

bool CNDS::UserOrGroupExists( LPCTSTR szContext, LPCTSTR szObject )
{
	if( !m_NdsWrapper.ptrNWIsDSAuthenticated( ) )
		return false;

	// verify szContext is a valid context
	if( _tcslen( szContext ) > 0 )
	{
		m_ccode = m_NdsWrapper.ptrNWDSSetContext( m_context, DCK_NAME_CONTEXT, ( nptr ) szContext );
		if( m_ccode )
			return false;
	}
	else
	{
		m_ccode = m_NdsWrapper.ptrNWDSSetContext( m_context, DCK_NAME_CONTEXT, ( nptr ) ( LPCTSTR ) m_strContext );
		if( m_ccode )
			return false;
	}

	// get context
	nstr8 strContext[ MAX_DN_CHARS + 1 ];
	m_ccode = m_NdsWrapper.ptrNWDSGetContext( m_context, DCK_NAME_CONTEXT, strContext );
	if( m_ccode )
		return false;

	m_strContext = strContext;
	CanonicalizeDN( m_strContext );

	// check effective rights to the attributes
	nuint32 effrights;
	m_ccode = m_NdsWrapper.ptrNWDSGetEffectiveRights( m_context, NULL, ( pnstr8 ) szObject, ( char NWFAR* ) A_COMMON_NAME, &effrights );
	if( m_ccode == ERR_NO_SUCH_ENTRY )
		return false;
	else 
	{
		if( m_ccode )
			return false;
		 else
			return true;
	}
}

CString CNDS::GetFirstName( const CString& strFullName )
{
	CString strRetval = _T( "" );

	int iSpace = strFullName.Find( _T( ' ' ), 0 );
	if( iSpace == -1 )
		strRetval = strFullName;
	else
	{
		strRetval = strFullName.Mid( 0, iSpace );
	}

	return strRetval;
}

CString CNDS::GetLastName( const CString& strFullName )
{
	CString strRetval = _T( "" );

	int iSpace = strFullName.Find( _T( ' ' ), 0 );
	if( iSpace == -1 )
		strRetval = strFullName;
	else
	{
		strRetval = strFullName.Mid( iSpace + 1 );
	}

	return strRetval;
}

bool CNDS::SetAttribute( pBuf_T& pBuf, LPCTSTR szAttributeName, nuint32 syntaxID, LPCTSTR szValue )
{
	// add attribute
	m_ccode = m_NdsWrapper.ptrNWDSPutAttrName( m_context, pBuf, ( LPTSTR ) szAttributeName );
	if( m_ccode )
	{
		m_NdsWrapper.ptrNWDSFreeBuf( pBuf );
		return false;
	}

	// set value
	m_ccode = m_NdsWrapper.ptrNWDSPutAttrVal( m_context, pBuf, syntaxID, ( LPVOID ) szValue );
	if( m_ccode )
	{
		m_NdsWrapper.ptrNWDSFreeBuf( pBuf );
		return false;
	}

	return true;
}

bool CNDS::AddUser( const CDSUser& NDSUser )
{
	if( !m_NdsWrapper.ptrNWIsDSAuthenticated( ) )
		return false;

	// verify szContext is a valid context
	if( _tcslen( NDSUser.GetParentDn( ) ) > 0 )
	{
		m_ccode = m_NdsWrapper.ptrNWDSSetContext( m_context, DCK_NAME_CONTEXT, ( nptr ) ( LPCTSTR ) NDSUser.GetParentDn( ) );
		if( m_ccode )
			return false;
	}
	else
	{
		m_ccode = m_NdsWrapper.ptrNWDSSetContext( m_context, DCK_NAME_CONTEXT, ( nptr ) ( LPCTSTR ) m_strContext );
		if( m_ccode )
			return false;
	}

	// get context
	nstr8 strContext[ MAX_DN_CHARS + 1 ];
	m_ccode = m_NdsWrapper.ptrNWDSGetContext( m_context, DCK_NAME_CONTEXT, strContext );
	if( m_ccode )
		return false;

	m_strContext = strContext;
	CanonicalizeDN( m_strContext );

	// allocate space for the buffer
	pBuf_T pBuf;
	m_ccode = m_NdsWrapper.ptrNWDSAllocBuf( ( size_t) DEFAULT_MESSAGE_LEN, &pBuf );
	if( m_ccode )
		return false;

	// initialize buffer for Directory Services ADD operation
	m_ccode = m_NdsWrapper.ptrNWDSInitBuf( m_context, DSV_ADD_ENTRY, pBuf );
	if( m_ccode )
	{
		m_NdsWrapper.ptrNWDSFreeBuf( pBuf );
		return false;
	}

	// add attributes
	if( !SetAttribute( pBuf, A_OBJECT_CLASS, SYN_CLASS_NAME, _T( "User" ) ) ) return false;
	if( !SetAttribute( pBuf, A_FULL_NAME, SYN_CI_STRING, ( LPCTSTR ) NDSUser.GetName( ) ) ) return false;
	if( !SetAttribute( pBuf, A_GIVEN_NAME, SYN_CI_STRING, ( LPCTSTR ) GetFirstName( ( LPCTSTR ) NDSUser.GetName( ) ) ) ) return false;
	if( !SetAttribute( pBuf, A_SURNAME, SYN_CI_STRING, ( LPCTSTR ) GetLastName( ( LPCTSTR ) NDSUser.GetName( ) ) ) ) return false;
	if( !SetAttribute( pBuf, A_TELEPHONE_NUMBER, SYN_TEL_NUMBER, ( LPCTSTR ) NDSUser.GetTelephoneNumber( ) ) ) return false;
	if( !SetAttribute( pBuf, _T( "Internet EMail Address" ), SYN_CI_STRING, ( LPCTSTR ) NDSUser.GetMail( ) ) ) return false;
	if( !SetAttribute( pBuf, A_LOCALITY_NAME, SYN_CI_STRING, ( LPCTSTR ) NDSUser.GetLocation( ) ) ) return false;

	// add login disabled attribute
	m_ccode = m_NdsWrapper.ptrNWDSPutAttrName( m_context, pBuf, A_LOGIN_DISABLED );
	if( m_ccode )
	{
		m_NdsWrapper.ptrNWDSFreeBuf( pBuf );
		return false;
	}

	// set value
	nuint8 bLoginDisabled = NDSUser.GetEnabled( );
	m_ccode = m_NdsWrapper.ptrNWDSPutAttrVal( m_context, pBuf, SYN_BOOLEAN, ( LPVOID ) &bLoginDisabled );
	if( m_ccode )
	{
		m_NdsWrapper.ptrNWDSFreeBuf( pBuf );
		return false;
	}

	// add fax attribute
	m_ccode = m_NdsWrapper.ptrNWDSPutAttrName( m_context, pBuf, A_FACSIMILE_TELEPHONE_NUMBER );
	if( m_ccode )
	{
		m_NdsWrapper.ptrNWDSFreeBuf( pBuf );
		return false;
	}

	// set value
	Fax_Number_T fax;
	fax.telephoneNumber = NDSUser.GetFax( );
	m_ccode = m_NdsWrapper.ptrNWDSPutAttrVal( m_context, pBuf, SYN_FAX_NUMBER, ( LPVOID ) &fax );
	if( m_ccode )
	{
		m_NdsWrapper.ptrNWDSFreeBuf( pBuf );
		return false;
	}

	CString strObjectName;
	strObjectName.Format( _T( "CN=%s" ), ( LPCTSTR ) NDSUser.GetUserId( ) );

	nint32 lIterationHandle = NO_MORE_ITERATIONS;
	nstr8 szObjectName[ MAX_DN_CHARS + 1 ];
	_tcscpy( szObjectName, ( LPCTSTR ) strObjectName );

	// NWDSAddObject creates the object pointed to by strObjectName. The 3rd and 4th args are reserved (NULL and 0 here).
	m_ccode = m_NdsWrapper.ptrNWDSAddObject( m_context, szObjectName, NULL, 0, pBuf );
	if( m_ccode )
	{
		m_NdsWrapper.ptrNWDSFreeBuf( pBuf );
		return false;
	}
	else
		return true;
}

bool CNDS::AddGroup( const CDSGroup& NDSGroup )
{
	if( !m_NdsWrapper.ptrNWIsDSAuthenticated( ) )
		return false;

	// verify szContext is a valid context
	if( _tcslen( NDSGroup.GetParentDn( ) ) > 0 )
	{
		m_ccode = m_NdsWrapper.ptrNWDSSetContext( m_context, DCK_NAME_CONTEXT, ( nptr ) ( LPCTSTR ) NDSGroup.GetParentDn( ) );
		if( m_ccode )
			return false;
	}
	else
	{
		m_ccode = m_NdsWrapper.ptrNWDSSetContext( m_context, DCK_NAME_CONTEXT, ( nptr ) ( LPCTSTR ) m_strContext );
		if( m_ccode )
			return false;
	}

	// get context
	nstr8 strContext[ MAX_DN_CHARS + 1 ];
	m_ccode = m_NdsWrapper.ptrNWDSGetContext( m_context, DCK_NAME_CONTEXT, strContext );
	if( m_ccode )
		return false;

	m_strContext = strContext;
	CanonicalizeDN( m_strContext );

	// allocate space for the buffer
	pBuf_T pBuf;
	m_ccode = m_NdsWrapper.ptrNWDSAllocBuf( ( size_t) DEFAULT_MESSAGE_LEN, &pBuf );
	if( m_ccode )
		return false;

	// initialize buffer for Directory Services ADD operation
	m_ccode = m_NdsWrapper.ptrNWDSInitBuf( m_context, DSV_ADD_ENTRY, pBuf );
	if( m_ccode )
	{
		m_NdsWrapper.ptrNWDSFreeBuf( pBuf );
		return false;
	}

	// add attributes
	if( !SetAttribute( pBuf, A_OBJECT_CLASS, SYN_CLASS_NAME, _T( "Group" ) ) ) return false;
	if( !SetAttribute( pBuf, A_FULL_NAME, SYN_CI_STRING, ( LPCTSTR ) NDSGroup.GetName( ) ) ) return false;
	if( !SetAttribute( pBuf, A_DESCRIPTION, SYN_CI_STRING, ( LPCTSTR ) NDSGroup.GetName( ) ) ) return false;

	// add group members -- the membership list should be the DNs of the users
	for( ObjectContainers::CUniqueBstrVector::Const_Iterator iterG = NDSGroup.GetMemberDNs( ).Begin( ); iterG != NDSGroup.GetMemberDNs( ).End( ); iterG++ )
	{
		_bstr_t strDN = *iterG;
		if( !SetAttribute( pBuf, _T( "Member" ), SYN_DIST_NAME, strDN ) ) return false;
	}

	CString strObjectName;
	strObjectName.Format( _T( "CN=%s" ), ( LPCTSTR ) NDSGroup.GetGroupId( ) );

	nint32 lIterationHandle = NO_MORE_ITERATIONS;
	nstr8 szObjectName[ MAX_DN_CHARS + 1 ];
	_tcscpy( szObjectName, ( LPCTSTR ) strObjectName );

	// NWDSAddObject creates the object pointed to by strObjectName. The 3rd and 4th args are reserved (NULL and 0 here).
	m_ccode = m_NdsWrapper.ptrNWDSAddObject( m_context, szObjectName, NULL, 0, pBuf );
	if( m_ccode )
	{
		m_NdsWrapper.ptrNWDSFreeBuf( pBuf );
		return false;
	}
	else
		return true;
}


bool CNDS::Search( LPCTSTR szContext, LPCTSTR szObject )
{
	if( !m_NdsWrapper.ptrNWIsDSAuthenticated( ) )
		return false;

	// verify szContext is a valid context
	if( _tcslen( szContext ) > 0 )
	{
		m_ccode = m_NdsWrapper.ptrNWDSSetContext( m_context, DCK_NAME_CONTEXT, ( nptr ) szContext );
		if( m_ccode )
			return false;
	}
	else
	{
		m_ccode = m_NdsWrapper.ptrNWDSSetContext( m_context, DCK_NAME_CONTEXT, ( nptr ) ( LPCTSTR ) m_strContext );
		if( m_ccode )
			return false;
	}

	// get context
	nstr8 strContext[ MAX_DN_CHARS + 1 ];
	m_ccode = m_NdsWrapper.ptrNWDSGetContext( m_context, DCK_NAME_CONTEXT, strContext );
	if( m_ccode )
		return false;

	m_strContext = strContext;
	CanonicalizeDN( m_strContext );

	// declare variables
	Object_Info_T pObjectInfo;
	pBuf_T pBuf, pFilter;
	pFilter_Cursor_T pCur;
	nuint32 luObjectCount;
	nint32 lIterationHandle = NO_MORE_ITERATIONS;
	nstr8 strObjectName[ MAX_DN_CHARS + 1 ];
	nuint32 luAttrCount;

	// allocate space for the buffers
	m_ccode = m_NdsWrapper.ptrNWDSAllocBuf( ( size_t) DEFAULT_MESSAGE_LEN, &pBuf );
	if( m_ccode )
		return false;
	m_ccode = m_NdsWrapper.ptrNWDSAllocBuf( ( size_t) DEFAULT_MESSAGE_LEN, &pFilter );
	if( m_ccode )
	{
		m_NdsWrapper.ptrNWDSFreeBuf( pBuf );
		return false;
	}

	// init the search filter
	m_ccode = m_NdsWrapper.ptrNWDSInitBuf( m_context, DSV_SEARCH_FILTER, pFilter );
	if( m_ccode )
	{
		m_NdsWrapper.ptrNWDSFreeBuf( pBuf );
		m_NdsWrapper.ptrNWDSFreeBuf( pFilter );
		return false;
	}

	// Allocate space for the search filter - pCur holds the filter cursor data
	m_ccode = m_NdsWrapper.ptrNWDSAllocFilter( &pCur );
	if( m_ccode )
	{
		m_NdsWrapper.ptrNWDSFreeBuf( pBuf );
		m_NdsWrapper.ptrNWDSFreeBuf( pFilter );
		return false;
	}

	// Add a node to the search filter expression tree. pCur is the filter cursor, FTOK_ANAME indicates that an 
	// attribute name is being added, the attribute name "Object Class" is next, and the syntax for the attribute, 
	// SYN_CLASS_NAME is last
	m_ccode = m_NdsWrapper.ptrNWDSAddFilterToken( pCur, FTOK_ANAME, _T( "Object Class" ), SYN_CLASS_NAME );
	if( m_ccode )
	{
		m_NdsWrapper.ptrNWDSFreeBuf( pBuf );
		m_NdsWrapper.ptrNWDSFreeBuf( pFilter );
		return false;
	}

	// Add the equal relational operator next
	m_ccode = m_NdsWrapper.ptrNWDSAddFilterToken( pCur, FTOK_EQ, NULL, ( nuint32 ) NULL );
	if( m_ccode )
	{
		m_NdsWrapper.ptrNWDSFreeBuf( pBuf );
		m_NdsWrapper.ptrNWDSFreeBuf( pFilter );
		return false;
	}

	// USE FTOK_AVAL to indicate that a value token is being placed and pass attribute value
	m_ccode = m_NdsWrapper.ptrNWDSAddFilterToken( pCur, FTOK_AVAL, _T( "Group" ), SYN_CLASS_NAME );
	if( m_ccode )
	{
		m_NdsWrapper.ptrNWDSFreeBuf( pBuf );
		m_NdsWrapper.ptrNWDSFreeBuf( pFilter );
		return false;
	}

	// USE FTOK_END to indicate the end of the expression 
	m_ccode = m_NdsWrapper.ptrNWDSAddFilterToken( pCur, FTOK_END, NULL, ( nuint32 ) NULL );
	if( m_ccode )
	{
		m_NdsWrapper.ptrNWDSFreeBuf( pBuf );
		m_NdsWrapper.ptrNWDSFreeBuf( pFilter );
		return false;
	}

	// Place finished search filter into the search input buffer
	m_ccode = m_NdsWrapper.ptrNWDSPutFilter( m_context, pFilter, pCur, NULL );
	if( m_ccode )
	{
		m_NdsWrapper.ptrNWDSFreeBuf( pBuf );
		m_NdsWrapper.ptrNWDSFreeBuf( pFilter );
		return false;
	}

	// Do the search
	do
	{
		m_ccode = m_NdsWrapper.ptrNWDSSearch( 
						m_context,
						( LPTSTR ) szObject,	// subtree to search
						DS_SEARCH_SUBTREE,		// scope is subtree
						FALSE,					// deref alias false
						pFilter,				// search filter
						DS_ATTRIBUTE_VALUES,	// info type to return
						TRUE,					// return all attributes
						NULL,					// attribute list
						&lIterationHandle,		// iteration information
						0,						// reserved
						0,						// reserved
						pBuf					// buf for search result
						); 
	  
		if( m_ccode )
		{
			m_NdsWrapper.ptrNWDSFreeBuf( pBuf );
			m_NdsWrapper.ptrNWDSFreeBuf( pFilter );
			return false;
		}

		m_ccode = m_NdsWrapper.ptrNWDSGetObjectCount( m_context, pBuf, &luObjectCount );
		if( m_ccode )
		{
			m_NdsWrapper.ptrNWDSFreeBuf( pBuf );
			m_NdsWrapper.ptrNWDSFreeBuf( pFilter );
			return false;
		}

		if( 0 == luObjectCount )
		{
			m_NdsWrapper.ptrNWDSFreeBuf( pBuf );
			m_NdsWrapper.ptrNWDSFreeBuf( pFilter );
			return false;
		}

		// For each object found, extract the name from the buffer
		for( nuint i = 0; i < luObjectCount; i++ )
		{
			m_ccode = m_NdsWrapper.ptrNWDSGetObjectName( m_context, pBuf, strObjectName, &luAttrCount, &pObjectInfo );
			if( m_ccode )
			{
				m_NdsWrapper.ptrNWDSFreeBuf( pBuf );
				m_NdsWrapper.ptrNWDSFreeBuf( pFilter );
				break;
			}

			//std::cout << _T( "Object: " ) << ( LPCTSTR ) strObjectName << _T( ", " ) << luAttrCount << _T( " attributes" ) << std::endl;

			NWSYNTAX_ID	luSyntax;
			nstr8 strAttrName[ MAX_DN_CHARS + 1 ];
			nstr8 strAttrVal[ MAX_DN_CHARS + 1 ];
			nint32 lIterationHandle2 = NO_MORE_ITERATIONS;
			NWCOUNT luValues;

			// iterate over all attributes
			for( nuint j = 0; j < luAttrCount; j++ )
			{
				// get attribute name
				m_ccode = m_NdsWrapper.ptrNWDSGetAttrName( m_context, pBuf, strAttrName, &luValues, &luSyntax );
				//std::cout << _T( "\t" ) << ( LPCTSTR ) strAttrName << _T( ": " );

				if( luValues > 1 )
				{
					//std::cout << std::endl;

					// get each attribute value
					for( NWCOUNT z = 0; z < luValues; z++ )
					{
						m_ccode = m_NdsWrapper.ptrNWDSGetAttrVal( m_context, pBuf, luSyntax, strAttrVal );
						//std::cout << _T( "\t\t" ) << ( LPCTSTR ) strAttrVal << std::endl;
					}
				}
				else
				{
					if( luSyntax == SYN_FAX_NUMBER )
					{
						Fax_Number_T fax;
						m_ccode = m_NdsWrapper.ptrNWDSGetAttrVal( m_context, pBuf, luSyntax, &fax );
						//std::cout << ( LPCTSTR ) fax.telephoneNumber << std::endl;
					}
					else
					{
						m_ccode = m_NdsWrapper.ptrNWDSGetAttrVal( m_context, pBuf, luSyntax, strAttrVal );
						//std::cout << ( LPCTSTR ) strAttrVal << std::endl;
					}
				}
			}
		}

	// loop back if more data
	} while( lIterationHandle != NO_MORE_ITERATIONS );

	// cleanup
	m_NdsWrapper.ptrNWDSFreeBuf( pBuf );
	m_NdsWrapper.ptrNWDSFreeBuf( pFilter );

	return true;
}

bool CNDS::ContextExists( LPCTSTR szContext )
{
	if( !m_NdsWrapper.ptrNWIsDSAuthenticated( ) )
		return false;

	// verify szContext is a valid context
	if( _tcslen( szContext ) > 0 )
	{
		m_ccode = m_NdsWrapper.ptrNWDSSetContext( m_context, DCK_NAME_CONTEXT, ( nptr ) szContext );
		if( m_ccode )
			return false;
	}
	else
	{
		m_ccode = m_NdsWrapper.ptrNWDSSetContext( m_context, DCK_NAME_CONTEXT, ( nptr ) ( LPCTSTR ) m_strContext );
		if( m_ccode )
			return false;
	}

	// get context
	nstr8 strContext[ MAX_DN_CHARS + 1 ];
	m_ccode = m_NdsWrapper.ptrNWDSGetContext( m_context, DCK_NAME_CONTEXT, strContext );
	if( m_ccode )
		return false;

	m_strContext = strContext;

	pBuf_T pBuf;
    m_ccode = m_NdsWrapper.ptrNWDSAllocBuf( ( size_t ) DEFAULT_MESSAGE_LEN, &pBuf );
    if( m_ccode )
		return false;

	nint32 lIterationHandle = NO_MORE_ITERATIONS;

	// search container, if it exists
	m_ccode = m_NdsWrapper.ptrNWDSList( m_context, "", &lIterationHandle, pBuf );
	bool bRetval = ( m_ccode == 0 );	// -601 (ERR_NO_SUCH_ENTRY) means that the container was not found

	// clean up
	m_NdsWrapper.ptrNWDSFreeBuf(pBuf);

   return bRetval;
}

bool CNDS::IsConnected( void )
{
	return ( m_NdsWrapper.ptrNWIsDSAuthenticated( ) == TRUE );
}

}

