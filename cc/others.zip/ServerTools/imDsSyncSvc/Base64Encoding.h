#ifndef _BASE64ENCODING_H_
#define _BASE64ENCODING_H_

#include <string>

class Base64Encoding
{
public:

	Base64Encoding();

	stlport::string base64_chars;


	bool is_base64(unsigned char c);
	/* base64_encode
	*  bytes_to_encode - input bytes array
	*  in_len - input length
	*  Returns - base64 encoded string
	*/
	stlport::string base64_encode(unsigned char const* bytes_to_encode, unsigned int in_len);

	/* base64_decode
	*  encoded_string - [input]base64 encoded string
	*  decoded_bytes - [output]Upon success contains decoded output
	*  buf_len - [input]Length of "decoded_bytes"
	*  Returns - length of the decoded string. 0 otherwise.
	*/
	int base64_decode(stlport::string const& encoded_string, unsigned char*& decoded_bytes, unsigned int buf_len);
};

#endif //_BASE64ENCODING_H_