////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// File:	imDsSyncSvc.h
//
// Project: Directory Service Synchronization Service
//
// Contents:	
//
//   Date    Who  Modification
// 03/07/02  MDL  Initial coding
//
// Copyright (C) 2002, iManage Technologies, Inc. ALL RIGHTS RESERVED
//                     PROPRIETARY AND CONFIDENTIAL
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma once


#if !defined(__IM_IMDSSYNCSVC_H__)
#define __IM_IMDSSYNCSVC_H__

#include "StdAfx.h"
#include "DSSyncService.h"

#include <stl\NrString.h>
#include <Verification\StackWalk.h>
#include <Report\Report.h>
#include <Registry\Registry.h>
#include <db\db.h>
#include <fileServer\fileServer.h>


namespace IM
{

class ImDsSyncSvc : public NtSystemService
{

public:
	ImDsSyncSvc(CDSSyncSvc *pServiceConfiguration_);
	virtual	~ImDsSyncSvc();
	void	Halt();
	void	CommandLineStartup();
	void	SetShutdownThread(Thread* pThread_);
//--------------------------------------------------------------------------------------------------------------
// System Agent methods.
//
protected:
	void					Init();
	void					OnStopCleanup();

//--------------------------------------------------------------------------------------------------------------
// Members
//
public:

private:
	bool												m_bClean;
	Thread												*m_pShutdownThread;
	DsSyncService										*m_pDsSyncService;
	DsSyncDatabaseList									*m_pDatabaseList;
	DBPoolMgr											*m_pPoolMgr;
};

}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Halt
//
inline void 
IM::ImDsSyncSvc::CommandLineStartup()
{
	m_bIsDebug = true;
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Halt
//
inline void 
IM::ImDsSyncSvc::Halt()
{
	::SetEvent(m_hStopEvent);
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// SetShutdownThread
//
inline void
IM::ImDsSyncSvc::SetShutdownThread(IM::Thread* pThread_)
{
	m_pShutdownThread = pThread_;
}

#endif

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////