////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// File:	RestClientDefs.h
//
// Project: This file defines all the enums, datastructures and typedefs used in ReSTClient
//
// Contents:	
//
//   Date    Who  Modification
// 07/25/13  Bala  Initial coding
//
// Copyright (C) 2001, iManage Technologies, Inc. ALL RIGHTS RESERVED
//                     PROPRIETARY AND CONFIDENTIAL
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef RESTCLIENT_DEFS_H
#define RESTCLIENT_DEFS_H

#include "RestClientOptions.h"

//typedefs
typedef stlport::map<stlport::string, stlport::string> FieldMap;
typedef stlport::list<FieldMap> FieldMapList;
typedef stlport::list<stlport::string> StringList;

enum WS_XACTION{
	XACTION_IDLE					=0,
	XACTION_LOGINWEB				=1,
	XACTION_UPLOADDOC				= 2,
	XACTION_OTHER					=3,
	
};




struct WSUserInfo
{
	long m_error_code;
	stlport::string m_strDatabase;
	stlport::string  m_strId;
	stlport::string m_strUserNum;
};

struct UploadDocResp
{
	long m_error_code;
	
};



#endif //RESTCLIENT_DEFS_H