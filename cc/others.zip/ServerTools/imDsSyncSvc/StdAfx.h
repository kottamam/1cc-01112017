//=============================================================================
// File: StdAfx.h
//-----------------------------------------------------------------------------
// Date      Who  Modification
// --------  ---  -------------------------------------------------------------
// 03/07/02  MDL  Initial coding
//-----------------------------------------------------------------------------
// Copyright (C) 2002, iManage, Inc.
// PROPRIETARY AND CONFIDENTIAL
//=============================================================================

#pragma once

// For building with VS2008 and stlPort51
#ifdef WSNT_VS2008	//	********************* VS2008 ******************************************************************************
#include <WSNT_VS2008.h>
#endif	// WSNT_VS2008	********************* VS2008 ******************************************************************************



// disable annoying warning messages
#pragma warning ( disable : 4786 )	// 'identifier' : identifier was truncated to 'number' characters in the debug information
#pragma warning ( disable : 4231 )	// nonstandard extension used : 'identifier' before template explicit instantiation
#pragma warning ( disable : 4290 )	// C++ Exception Specification ignored
#pragma warning ( disable : 4005 )	// macro redefinition
#pragma warning ( disable : 4101 )	// unreferenced local variable

#include <boost/asio.hpp>

#include <winsock2.h>


// for _bstr_t and TCHAR
#include <comdef.h>
#include <comutil.h>
#include <tchar.h>

// STL includes
#include <vector>
#include <map>
#include <list>
#include <queue>
#include <deque>
#include <stack>
#include <set>
#include <algorithm>
#include <functional>
#include <fstream>

#include <iostream>
#ifdef UNICODE
#define COUT wcout
#define CERR werr
#else
#define COUT cout
#define CERR cerr
#endif
#define endl _T( "\n" )

// for IM::Exception
#include <Verification\Exception.h>


typedef imstd::basic_ofstream<_TCHAR, imstd::char_traits<_TCHAR> > imofstream;
typedef imstd::basic_ifstream<_TCHAR, imstd::char_traits<_TCHAR> > imifstream;


// Rogue Wave CString class
#include <rw\cstring.h>

// include output from compilation of Messages.mc
#include "Messages.h"

#include <FileServer/FileServer.h>

/*
#include <nwnet.h>
//
// Locale.h MUST be includeded before nwlocale.h to avoid collisions with conflicting definitions.
//
#include <Locale.h>
#include <nwlocale.h>
*/


#define minimum(a,b)            (((a) < (b)) ? (a) : (b))

