//=============================================================================
// File: BstrStringFunctions.h
//-----------------------------------------------------------------------------
// Date      Who  Modification
// --------  ---  -------------------------------------------------------------
// 10/19/01  MDL  Initial coding
//-----------------------------------------------------------------------------
// Copyright (C) 2001, iManage, Inc.
// PROPRIETARY AND CONFIDENTIAL
//=============================================================================


// This file defines some useful string functions for the _bstr_t class.
// They are placed in a separate namespace to avoid confusion with 
// the plethora of other string functions with similar names.


#ifdef _INC_COMUTIL

#ifndef _BSTRSTRINGS_STRINGFUNCTIONS_H_
#define _BSTRSTRINGS_STRINGFUNCTIONS_H_

namespace BstrStrings
{
	int CountWordsInString( const _bstr_t& strWords, const TCHAR chWordSeparator );
	_bstr_t GetNextWordFromString( const _bstr_t& strWords, const TCHAR chWordSeparator, DWORD& dwIndex );
	int FindLeft( const _bstr_t& strToSearch, const _bstr_t& strSub );
	int FindRight( const _bstr_t& strSearch, const _bstr_t& strSub );
	_bstr_t Mid( const _bstr_t& str, const int iStartPos, const int iCount );
	_bstr_t RemoveLeadingBackslashes( const _bstr_t& strInput );
	_bstr_t TrimLeft( const _bstr_t& strInput );
	_bstr_t TrimRight( const _bstr_t& strInput );
}

#endif // _BSTRSTRINGS_STRINGFUNCTIONS_H_

#endif // _INC_COMUTIL