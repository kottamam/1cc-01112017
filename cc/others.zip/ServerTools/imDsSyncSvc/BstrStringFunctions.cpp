//=============================================================================
// File: BstrStringFunctions.cpp
//-----------------------------------------------------------------------------
// Date      Who  Modification
// --------  ---  -------------------------------------------------------------
// 10/19/01  MDL  Initial coding
//-----------------------------------------------------------------------------
// Copyright (C) 2001, iManage, Inc.
// PROPRIETARY AND CONFIDENTIAL
//=============================================================================

#include "StdAfx.h"
#include "BstrStringFunctions.h"

#ifdef _INC_COMUTIL

namespace BstrStrings
{

// A word is a string like "word"
// and a string of words is a string like "word1;word2;word3"
//
// Given a string of words and a word separator (e.g. ';')
// this method counts the number of words
// e.g. "word1;word2;word3" has three words
int CountWordsInString( const _bstr_t& strWords, const TCHAR chWordSeparator )
{
	int iRetval = 0;

	// string of words
	const TCHAR* szTemp = ( LPCTSTR ) strWords;
	const DWORD dwLength = strWords.length( );

	// word separator
	const TCHAR szWordSeparator[] = { chWordSeparator, NULL };
	const _bstr_t strWordSeparator( szWordSeparator );

	// a single string with no word separators
	// must count as one word
	if( dwLength > 0 )
		++iRetval;

	// read until end of string is reached
	DWORD dwIndex = 0;
	while( dwIndex < dwLength )
	{
		// get current character
		const TCHAR szCurCh[] = { szTemp[ dwIndex ], NULL };
		const _bstr_t strCurCh( szCurCh );

		// increment index
		++dwIndex;

		// if it is the word separator
		// and if this isn't the end of the string
		// (don't count trailing word separators)
		if( ( strCurCh == strWordSeparator ) && ( dwIndex < dwLength ) )
			++iRetval;			// increment count
	}

	return iRetval;
}

// A word is a string like "word"
// and a string of words is a string like "word1;word2;word3"
//
// Given a string of words and a word separator (e.g. ';')
// and given an index into the string
// this method returns the next word in the string
// until either the end of string or the word separator
_bstr_t GetNextWordFromString( const _bstr_t& strWords, const TCHAR chWordSeparator, DWORD& dwIndex )
{
	_bstr_t strRetval = _T( "" );

	// string of words
	const TCHAR* szTemp = ( LPCTSTR ) strWords;
	const DWORD dwLength = strWords.length( );
	
	// word separator
	const TCHAR szWordSeparator[] = { chWordSeparator, NULL };
	const _bstr_t strWordSeparator( szWordSeparator );

	// read until word separator is reached
	while( dwIndex < dwLength )
	{
		// get current character
		const TCHAR szCurCh[] = { szTemp[ dwIndex ], NULL };
		const _bstr_t strCurCh( szCurCh );

		// always advance index even when character is word separator
		// so when this method terminates, index will be at
		// start of next value
		++dwIndex;

		// if it is word separator
		if( strCurCh == strWordSeparator )
			break;				// terminate
		else
			strRetval += strCurCh;	// append character to string
	}
	
	return strRetval;
}

// Given a search string and a substring value to search for
// this method returns the zero-based index of the starting position
// of the substring, searching from left to right,
// and returns -1 if the substring is not found
int FindLeft( const _bstr_t& strSearch, const _bstr_t& strSub )
{
	const int iSearchLen = strSearch.length( );
	const int iSubLen = strSub.length( );

	// check string lengths
	if( ( iSearchLen == 0 ) || ( iSubLen == 0 ) )
		return -1;

	const TCHAR* szSearch = ( LPCTSTR ) strSearch;
	const TCHAR* szSub = ( LPCTSTR ) strSub;

	for( int i=0; i<iSearchLen; i++ )
	{
		// is there a match on first character of the substring?
		if( szSearch[ i ] == szSub[ 0 ] )
		{
			
			// if the substring size > 1 
			// make sure all the characters match
			// and make sure we don't exceed iSearchLen in length

			for( int j=1, iTemp = i+1; j<iSubLen && iTemp<iSearchLen; j++, iTemp++ )
			{
				if( szSearch[ iTemp ] != szSub[ j ] )
					break;
			}

			// match found, return index of starting position
			if( j == iSubLen )
				return i;
		}
	}

	return -1;
}

// Given a search string and a substring value to search for
// this method returns the zero-based index of the starting position
// of the substring, searching from right to left,
// and returns -1 if the substring is not found
int FindRight( const _bstr_t& strSearch, const _bstr_t& strSub )
{
	const int iSearchLen = strSearch.length( );
	const int iSubLen = strSub.length( );

	// check string lengths
	if( ( iSearchLen == 0 ) || ( iSubLen == 0 ) )
		return -1;

	const TCHAR* szSearch = ( LPCTSTR ) strSearch;
	const TCHAR* szSub = ( LPCTSTR ) strSub;

	for( int i=iSearchLen-1; i>=0; i-- )
	{
		// is there a match on first character of the substring?
		if( szSearch[ i ] == szSub[ 0 ] )
		{
			
			// if the substring size > 1 
			// make sure all the characters match
			// and make sure we don't exceed iSearchLen in length

			for( int j=1, iTemp = i+1; j<iSubLen && iTemp<iSearchLen; j++, iTemp++ )
			{
				if( szSearch[ iTemp ] != szSub[ j ] )
					break;
			}

			// match found, return index of starting position
			if( j == iSubLen )
				return i;
		}
	}

	return -1;
}

// Given a string and a starting and ending position
// this method returns the inclusive substring
_bstr_t Mid( const _bstr_t& str, const int iStartPos, const int iCount )
{
	_bstr_t strRetval = _T( "" );

	const int iLen = str.length( );

	// check string length
	if( iLen == 0 )
		return strRetval;

	// check the bounds
	const int iEndPos = iStartPos + iCount - 1;
	if( ( iStartPos < 0 ) || ( iStartPos >= iLen ) || ( iEndPos < 0 ) || ( iEndPos >= iLen ) || ( iEndPos < iStartPos ) )
		return strRetval;

	const TCHAR* sz = ( LPCTSTR ) str;

	for( int i=iStartPos; i<=iEndPos; i++ )
	{
		// create a string of one character
		const TCHAR szChar[ 2 ] = { sz[ i ], NULL };

		// append the character string
		strRetval += szChar;
	}

	return strRetval;
}

// Given an input string, this method removes the two leading backslashes
// e.g. "\\server" becomes "server"
// and if no blackslashes are there, the original string is returned
_bstr_t RemoveLeadingBackslashes( const _bstr_t& strInput )
{
	const DWORD dwLength = strInput.length( );
	if( dwLength < 2 )
		return strInput;

	_bstr_t strRetval = _T( "" );

	// strip off the prefixed "\\" characters
	TCHAR *szTemp = ( LPTSTR ) strInput;

	TCHAR sz1[] = { szTemp[ 0 ], NULL };
	TCHAR sz2[] = { szTemp[ 1 ], NULL };
	_bstr_t str1( sz1 ), str2( sz2 );
	const _bstr_t strBackslash( _T( "\\" ) );

	if( ( str1 == strBackslash ) && ( str2 == strBackslash ) )
		strRetval = BstrStrings::Mid( strInput, 2, dwLength - 2 );
	else
		strRetval = strInput;

	return strRetval;
}

// This method trims whitespace (tabs and spaces)
// from the left of a given string
_bstr_t TrimLeft( const _bstr_t& strInput )
{	
	const TCHAR szSpace[] = _T( " " );
	const TCHAR szTab[] = _T( "\t" );

	_bstr_t strRetval = _T( "" );

	const TCHAR* szInput = ( LPCTSTR ) strInput;
	const int iLength = strInput.length( );
	int iIndex = 0;

	// skip leading whitespace
	while( iIndex < iLength )
	{
		// get current character
		TCHAR szTemp[] = { szInput[ iIndex ], NULL };

		// if whitespace, skip over it
		if( ( _tcsicmp( szTemp, szSpace ) == 0 ) || ( _tcsicmp( szTemp, szTab ) == 0 ) )
			++iIndex;
		else
			break;
	}

	// copy the rest of the string
	while( iIndex < iLength )
	{
		TCHAR szTemp[] = { szInput[ iIndex ], NULL };
		strRetval += _bstr_t( szTemp );
		++iIndex;
	}

	return strRetval;
}

// This method trims whitespace (tabs and spaces)
// from the right of a given string
_bstr_t TrimRight( const _bstr_t& strInput )
{	
	const TCHAR szSpace[] = _T( " " );
	const TCHAR szTab[] = _T( "\t" );

	_bstr_t strRetval = _T( "" );

	const TCHAR* szInput = ( LPCTSTR ) strInput;
	const int iLength = strInput.length( );
	int iIndex = iLength;

	// skip trailing whitespace
	while( iIndex > 0 )
	{
		// get current character
		TCHAR szTemp[] = { szInput[ iIndex - 1 ], NULL };

		// if whitespace, skip over it
		if( ( _tcsicmp( szTemp, szSpace ) == 0 ) || ( _tcsicmp( szTemp, szTab ) == 0 ) )
			--iIndex;
		else
			break;
	}

	// copy the rest of the string
	int iIndex2 = 0;
	while( iIndex2 < iIndex )
	{
		TCHAR szTemp[] = { szInput[ iIndex2 ], NULL };
		strRetval += _bstr_t( szTemp );
		++iIndex2;
	}

	return strRetval;
}
}

#endif