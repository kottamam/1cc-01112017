////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// File:	Main.cpp
//
// Project: Directory Service Synchronization Service
//
// Contents:	Implements the main entry points for the Directory Service Synchronization Service.
//
//   Date    Who  Modification
// 03/07/02  MDL  Initial coding
//
// Copyright (C) 2002, iManage Technologies, Inc. ALL RIGHTS RESERVED
//                     PROPRIETARY AND CONFIDENTIAL
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma hdrstop

#include "StdAfx.h"
#include "imDsSyncSvc.h"

#include <stl\NrString.h>
#include <Verification\StackWalk.h>
#include <Report\Report.h>
#include <Registry\Registry.h>
#include <Registry\RegistryLib.h>
#include <verification\CRTDebug.h>
#include <collect\collect.h>

#include <iManagePerfMon\ClientPerfMon.h>

#include "resource.h"
#include <atlstr.h>

const unsigned long g_ulServiceExitSleepTime = 300000; // 5 minutes

// forward
void LogMsg(const char *szPath_, const int line_, const long lLevel_, const char *szFormat_, ...);


void StartService(int nArgC_, char *szArgV_[]);

void main(int nArgC_, char *szArgV_[])
{
	__try 
	{
		StartService(nArgC_,szArgV_);
	}
	__except (IM::NrtExceptionFilterForStackDump(GetExceptionInformation()))
	{
		LogMsg(LOG_INFO, "+++ Main Process exception %0x +++", GetExceptionCode());
	}
}


void
StartService(int nArgC_, char *szArgV_[])
{
	DWORD								dwExitCode = NULL;
	IM::ImDsSyncSvc						*pImDsSyncSvc = NULL;
	IM::CDSSyncSvc						*pServiceConfiguration = NULL;
	IMUtil::ShutdownWatchDogThread		*pWatchDogThread = NULL;
	RWLocale							*p_locale = NULL;

	try
	{
		IM::CRTDebug dbg;

		// initialize with local instance of RWLocale
		p_locale = (class RWLocale *) RWLocale::defaultLocale();
		RWLocale::global(p_locale);

		// 2008-08-04 MH
		//  Characters in the DN strings, such as �, fail with case-insensitive string comparisons unless the codepage is set
		// we only support 1252
		setlocale( LC_ALL, "English" );

		check_pointer(*szArgV_);		

		// load configuration data from registry
		pServiceConfiguration = im_new IM::CDSSyncSvc(NULL);
		pServiceConfiguration->LoadFromRegistry();

		// Set the new version if different.
		CString strBuildVersionId;
		strBuildVersionId.LoadString(BUILD_VERSION_ID);

		IM::NrString strBuildId = strBuildVersionId;
		if(pServiceConfiguration->m_strVersion.Get() != strBuildId)
		{
			pServiceConfiguration->m_strVersion.Set(strBuildId.c_str());
			pServiceConfiguration->StoreInRegistry();
		}

		// initialize logging
		IM::LogMessageInitialize(pServiceConfiguration->m_strLogPath.Get().c_str(), pServiceConfiguration->m_lLogMask.Get());

		// Initialize the log message module.
		LogMsg(LOG_INFO, "**********************************  STARTUP  **********************************");
		LogMsg(LOG_INFO, "Computer Name: %s     Build ID: %s", pServiceConfiguration->m_strComputerName.c_str(), pServiceConfiguration->m_strVersion.Get().c_str());

		// Write Temporary path to log
		wchar_t	szTempPath[MAX_PATH];
		memset(szTempPath, 0, sizeof(szTempPath));
		GetTempPathW(MAX_PATH, szTempPath);
		LogMsg(LOG_INFO, "Temporary Path: %s", UnicodeToUTF8(szTempPath).c_str());

		// Write Service configuration to log.
		pServiceConfiguration->LogRegistry();

		pWatchDogThread = im_new IMUtil::ShutdownWatchDogThread(pImDsSyncSvc, g_ulServiceExitSleepTime);
		check_object(pWatchDogThread);

		// Create ImKMIdxSvc object
		pImDsSyncSvc = im_new IM::ImDsSyncSvc(pServiceConfiguration);
		check_object(pImDsSyncSvc);

		pImDsSyncSvc->SetShutdownThread(pWatchDogThread);

		if ((nArgC_ > 1) && ((*szArgV_[1] == '-') || (*szArgV_[1] == '/')))
		{
			pImDsSyncSvc->CommandLineStartup();

			if (_stricmp(szArgV_[1] + 1, "debug") == 0)
			{
				pImDsSyncSvc->DebugStartup(nArgC_, szArgV_);
			}
			else
			{
				IM::NrString strVersion;
				IM::NrString strDisplayName;

				printf("Version %s - built on %s at %s\n", pImDsSyncSvc->GetVersion(strVersion).c_str(), __DATE__, __TIME__);
				printf("Usage: %s [-debug]\n", pImDsSyncSvc->GetName(strDisplayName).c_str());

				exit(0);
			}
		}
		else
		{
			pImDsSyncSvc->Startup(szArgV_[0]);
		}
	}
	catch(imstd::exception &e)
	{
		if (NULL != pImDsSyncSvc)
		{
			pImDsSyncSvc->Halt();
		}

		LogMsg(LOG_INFO, "Unhandled service exception %s", e.what());
	}
	catch(long)
	{
		if (NULL != pImDsSyncSvc)
		{
			pImDsSyncSvc->Halt();
		}
	}

	if (NULL != pImDsSyncSvc)
	{
		dwExitCode = pImDsSyncSvc->GetExitCode();
		pImDsSyncSvc->Destroy();
		pImDsSyncSvc = NULL;
	}

	if (NULL != pServiceConfiguration)
	{
		// This causes problems if the registy is modified by Service Manager
		// while the service is running. Commenting this out
		// makes the connections editable while the service is running
		
		//pServiceConfiguration->StoreInRegistry();


		delete pServiceConfiguration;
		pServiceConfiguration=NULL;
	}

	if(NULL != pWatchDogThread)
	{
		pWatchDogThread->Done();
		::Sleep(20);

		delete pWatchDogThread;
		pWatchDogThread = NULL;
	}

	// Delete RogueWave static member so it isn't reported as memory leak.
	RWCollectable *pNilCollectable = getRWNilCollectable();
	if (pNilCollectable != NULL)
	{
		delete pNilCollectable;
		pNilCollectable = NULL;
	}

	if (p_locale != NULL)
	{
		delete p_locale;
		p_locale = NULL;
	}

	RWZone*	p_zone = (class RWZone*)RWZone::local(NULL);
	if (p_zone != NULL)
	{
		delete p_zone;
		p_zone = NULL;
	}

	LogMsg(LOG_INFO, "**********************************  SHUTDOWN  *********************************");
	IM::LogMessageClose();
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//  ReMapMessageLevel (report.lib -> verification.lib)
//
//
//		static _TCHAR *szLevel[] = { report
//				_T("Error "), 0
//				_T("Warn  "), 1
//				_T("Debug "), 2
//				_T("Header"), 3
//				_T("Info  "), 4
//				_T("Info2 "), 5
//				_T("Info3 "), 6
//				_T("Info4 "), 7
//		};
//
//		static _TCHAR *szLevel[] = { verification
//				_T("Assert"), 0
//				_T("Debug "), 1
//				_T("Error "), 2
//				_T("Warn  "), 3
//				_T("Header"), 4
//				_T("Info  "), 5
//				_T("Info2 "), 6
//				_T("Info3 "), 7
//				_T("Info4 "), 8
//		};
//
void 
	ReMapMessageLevel(long* lLevel_)
{
	switch (*lLevel_)
	{
		case 0:
			*lLevel_ = 2;
			break;

		case 1:
			*lLevel_ = 3;
			break;

		case 2:
			*lLevel_ = 1;
			break;

		case 3:
			*lLevel_ = 4;
			break;

		case 4:
			*lLevel_ = 5;
			break;

		case 5:
			*lLevel_ = 6;
			break;

		case 6:
			*lLevel_ = 7;
			break;

		case 7:
			*lLevel_ = 8;
			break;

		default:
			break;
	}
}

BOOL
isUnicodeLogFile()
{
	return FALSE;
}

void
LogMsgW(const wchar_t *szPath_, const int line_, const long lLevel_, const wchar_t *szFormat_, ...)
{
	::LogMsg(UnicodeToAnsi(szPath_, CP_UTF8).c_str(), line_, lLevel_, UnicodeToAnsi(szFormat_, CP_UTF8).c_str());
}

void
LogMsg(const char *szPath_, const int line_, const long lLevel_, const char *szFormat_, ...)
{
	try
	{
		va_list arglist;
		va_start(arglist, szFormat_);

		//
		// Normalize levels between implementations.
		//
		long lLevel = lLevel_;

		ReMapMessageLevel(&lLevel);

		IM::LogMessage(szPath_, line_, LM_FILE_OUTPUT, lLevel, szFormat_, arglist);

		va_end(arglist);
	}
	catch (IM::Exception &)
	{
		//
		// Don re-throw here!!!
		//
	}
}
