////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// File:	CJSONPayload.cpp
//
// Project: Implementation JSON payload interfaces
//
// Contents:	
//
//   Date    Who  Modification
// 04/28/13  Bala  Initial coding
//
// Copyright (C) 2001, iManage Technologies, Inc. ALL RIGHTS RESERVED
//                     PROPRIETARY AND CONFIDENTIAL
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "CJSONPayload.h"
#include <iostream>
#include <sstream>
#include <crtdbg.h>

#ifdef _DEBUG
	#define new			new(_NORMAL_BLOCK, __FILE__, __LINE__)
#endif // _DEBUG


/************** START CJSONPayload ***************/
void CJSONPayload::generateLoginPayload(const char* strUserName, const char* strPassword, stlport::string& outputPayload)
{
	JSONNODE *p = json_new(JSON_NODE);
	json_push_back(p, json_new_a("user_id", strUserName));
	json_push_back(p, json_new_a("password", strPassword));
	json_push_back(p, json_new_a("persona", "admin"));
	//json_push_back(p, json_new_a("lib", "l"));
	//json_push_back(p, json_new_b("subdomain", false));
	//json_push_back(p, json_new_b("allLibraries", false));
	json_char *jc = json_write_formatted(p);
	outputPayload = jc;

	//cleanup memory
	json_free(jc);
	json_delete(p);
	return;
}

void CJSONPayload::generatePayloadForAddRemoveUsers(const char* szDatabase, const char* szUserId, const char* action, stlport::string& outputPayload)
{
	JSONNODE *p = json_new(JSON_NODE);
	json_push_back(p, json_new_a("database", szDatabase));
	json_push_back(p, json_new_a("action", action));
	json_push_back(p, json_new_a("data_type", "users"));

	JSONNODE *n = json_new(JSON_ARRAY);
	json_set_name(n, "data");

	json_push_back(n, json_new_a(NULL, szUserId));
	json_push_back(p, n);
	//json_push_back(p, json_new_a("lib", "l"));
	//json_push_back(p, json_new_b("subdomain", false));
	//json_push_back(p, json_new_b("allLibraries", false));
	json_char *jc = json_write_formatted(p);
	outputPayload = jc;

	//cleanup memory
	json_free(jc);
	json_delete(p);
	return;
}












int CJSONPayload::getValue(stlport::string strKey, stlport::string & strOutValue)
{
	if(m_fieldMap.size() > 0)
	{
		stlport::map<stlport::string, stlport::string>::iterator it;
		it = m_fieldMap.find(strKey);

		if(it != m_fieldMap.end())
		{
			strOutValue = it->second;
			return 0;
		}

	}

	return 1;
}

int CJSONPayload::getFieldMap(FieldMap& fieldMap)
{
	if(m_fieldMap.size() > 0)
	{
		fieldMap = m_fieldMap;
		return 0;
	}

	return 1;
}




int CJSONPayload::ParseResponse(const char* respPayload)
{
	m_fieldMap.clear();

	/*JSONNODE *n = json_parse(respPayload);
	if(n == NULL)
		return 1;

	JSONNODE_ITERATOR i = json_begin(n);
	bool bContinue = true;

	do
	{
		i = ParseJSON(i, json_end(n));

		if (i == json_end(n) || *i == NULL)
		{
			stlport::cout << "Reached the END OR Invalid JSON" << stlport::endl;
			bContinue = false;
		}
		else
		{
			// get the node name and value as a string
			json_char *node_name = json_name(*i);
			stlport::stringstream ss;
			if(json_type(*i) == JSON_NUMBER)
			{
				ss << json_as_string(*i);
			}
			else if(json_type(*i) == JSON_STRING)
			{
				json_char *node_value = json_as_string(*i);
				ss << node_value;
				json_free(node_value);
			}
			else if(json_type(*i) == JSON_ARRAY)
			{
				JSONNODE *dataArr = json_as_array(*i);

				JSONNODE_ITERATOR j = json_begin(dataArr);
							
				while(j == json_end(n) || *j == NULL)
				{
					j = ParseJSON(j, json_end(dataArr));
				};
			}

			//Insert into map;
			m_fieldMap[node_name] = ss.str();
				
			// cleanup and increment the iterator
			json_free(node_name);
			++i;
		}
	}while(bContinue);

	json_delete(n);*/
	return GenerateFieldMap(respPayload);
}

int CJSONPayload::GenerateFieldMap(const char* respPayload)
{
	JSONNODE *n = json_parse(respPayload);
	if(n == NULL)
		return 1;

	JSONNODE_ITERATOR i = json_begin(n);
	bool bContinue = true;

	long lRtnCode = 0;
	do
	{
		if(i == NULL)
		{
			bContinue = false;
			break;
		}
		//i = ParseJSON(i, json_end(n));

		if (i == json_end(n) || *i == NULL)
		{
			//stlport::cout << "Reached the END OR Invalid JSON" << stlport::endl;
			bContinue = false;
			break;
		}
		else
		{
			// get the node name and value as a string
			json_char *node_name = json_name(*i);
			//stlport::stringstream ss;
			stlport::string strNodeValue;
			/*if(json_type(*i) == JSON_NUMBER)
			{
				ss << json_as_string(*i);
			}
			else if(json_type(*i) == JSON_STRING)
			{
				json_char *node_value = json_as_string(*i);
				ss << node_value;
				json_free(node_value);
			}*/
			/*if(!strcmp(node_name, "error"))
			{
				JSONNODE *node_code = json_get(*i, "code");
				if(node_code != NULL)
				{
					json_char *node_value = json_as_string(node_code);
					m_fieldMap[node_name] = node_value;
					json_free(node_value);
					//json_free(node_code);
				}
				else
				{
					lRtnCode = 1;
				}

				JSONNODE *node_msg = json_get(*i, "message");
				if(node_code != NULL)
				{
					json_char *node_value = json_as_string(node_msg);
					stlport::stringstream ss;
					ss << m_fieldMap[node_name] << "-" << node_value;
					m_fieldMap[node_name] = ss.str();
					json_free(node_value);
					//json_free(node_msg);
				}
				else
				{
					lRtnCode = 1;
				}

				json_free(node_name);
				break;
			}*/

			if(json_type(*i) == JSON_ARRAY || json_type(*i) == JSON_NODE)
			{
				json_char *node_value = json_write(*i);
				GenerateFieldMap(node_value);
				json_free(node_value);
			}
			else
			{
				json_char *node_value = json_as_string(*i);
				strNodeValue = node_value;
				json_free(node_value);
			}

			//Insert into map;
			m_fieldMap[node_name] = strNodeValue;
				
			// cleanup and increment the iterator
			json_free(node_name);
			++i;
		}
	}while(bContinue);

	json_delete(n);
	return lRtnCode;
}
/*
int CJSONPayload::ReadNodeData(void*& node, stlport::string& strNodeName, stlport::string& strNodeValue)
{
	// get the node name and value as a string
	json_char *node_name = json_name(node);
	stlport::stringstream ss;
	if(json_type(node) == JSON_NUMBER)
	{
		ss << json_as_string(node);
	}
	else if(json_type(node) == JSON_STRING)
	{
		json_char *node_value = json_as_string(node);
		ss << node_value;
		json_free(node_value);
	}

	strNodeName = node_name;
	strNodeValue = ss.str();

	json_free(node_name);
	return 0;
}*/




FieldMapList CJSONPayload::GetChildrenList(const char* respPayload, bool& bOverFlow)
{
	FieldMapList childrenList;
	bOverFlow = false;
	
	ParseJSONArray(respPayload, "data", bOverFlow, childrenList);

	return childrenList;
}

FieldMapList CJSONPayload::GetChildrenList(const char* respPayload, bool& bOverFlow, stlport::string& nextUrl)
{
	FieldMapList childrenList;
	bOverFlow = false;

	ParseJSONArray(respPayload, "data", bOverFlow, childrenList, nextUrl);

	return childrenList;
}

int CJSONPayload::ParseJSONArray(const char* respPayload, const char* arrayName, bool& bOverflow, FieldMapList& fieldList, stlport::string& nextUrl )
{
	long lRtnCode = 0;
	JSONNODE *n = json_parse(respPayload);
	if (n != NULL)
	{


		
		JSONNODE_ITERATOR i = json_begin(n);
		bool bContinue = true;
		bool bFound = false;

		do
		{
			if (i == NULL)
			{
				bContinue = false;
				break;
			}

			if (i == json_end(n) || *i == NULL)
			{
				bContinue = false;
			}
			else
			{
				json_char *node_name = json_name(*i);
				if ((json_type(*i) == JSON_ARRAY) && (strcmp(node_name, arrayName) == 0))
					bFound = true;
				else
					++i;

				json_free(node_name);
			}
		} while (bContinue && (bFound == false));

		if (bFound)
		{
			JSONNODE *dataArr = json_as_array(*i);

			int json_index_t = json_size(dataArr);
			for (int idx = 0; idx < json_index_t; ++idx)
			{
				JSONNODE *node = json_at(dataArr, idx);
				json_char *jc = json_write_formatted(node);

				ParseResponse(jc);
				fieldList.push_back(m_fieldMap);

				json_free(jc);
				//json_free(node);
			}
			json_delete(dataArr);
		}
		else
		{
			lRtnCode = 1;
		}

		json_delete(n);
	}
	else
		lRtnCode = 1;

	return lRtnCode;
}

int CJSONPayload::ParseJSONArray(const char* respPayload, const char* arrayName, bool& bOverflow, FieldMapList& fieldList)
{
	long lRtnCode = 0;
	JSONNODE *n = json_parse(respPayload);
	if(n != NULL)
	{
		
		JSONNODE_ITERATOR i = json_begin(n);
		bool bContinue = true;
		bool bFound = false;

		do
		{
			if(i == NULL)
			{
				bContinue = false;
				break;
			}

			if (i == json_end(n) || *i == NULL)
			{
				bContinue = false;
			}
			else
			{
				json_char *node_name = json_name(*i);
				if ((json_type(*i) == JSON_ARRAY) && (strcmp(node_name, arrayName) == 0))
					bFound = true;
				else
					++i;

				json_free(node_name);
			}
		}while(bContinue &&( bFound == false));

		if (bFound)
		{
			JSONNODE *dataArr = json_as_array(*i);

			int json_index_t = json_size(dataArr);
			for(int idx = 0; idx < json_index_t; ++idx)
			{
				JSONNODE *node = json_at(dataArr, idx);
				json_char *jc = json_write_formatted(node);

				ParseResponse(jc);
				fieldList.push_back(m_fieldMap);

				json_free(jc);
				//json_free(node);
			}
			json_delete(dataArr);
		}
		else
		{
			lRtnCode = 1;
		}

		json_delete(n);
	}
	else 
		lRtnCode = 1;

	return lRtnCode;
}

JSONNODE_ITERATOR CJSONPayload::ParseJSON(JSONNODE_ITERATOR& iterator, JSONNODE_ITERATOR end_iterator)
{
	JSONNODE_ITERATOR i = iterator;

	if (*i == NULL || i == end_iterator)
	{
		//stlport::cout << "Reached the END OR Invalid JSON" << stlport::endl;
		return i;
	}

	if (/*json_type(*i) == JSON_ARRAY || */json_type(*i) == JSON_NODE)
	{
		ParseJSON(++i, end_iterator);
	}

	return i;
}






/************** END CJSONPayload ***************/
