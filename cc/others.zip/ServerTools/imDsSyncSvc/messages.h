//	Header Section

// Note: We use HRESULT values which differ in that there is only
//	1 bit of severity (1=Error), 2 reserved bits of 0, and 13 bits
//	of Facility code.  By the rules of COM all facility codes in an
//	interface MUST be FACILITY_ITF.

//
//	Communication level codes; RPC codes must be mapped to these
//
//
//  Values are 32 bit values laid out as follows:
//
//   3 3 2 2 2 2 2 2 2 2 2 2 1 1 1 1 1 1 1 1 1 1
//   1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0
//  +---+-+-+-----------------------+-------------------------------+
//  |Sev|C|R|     Facility          |               Code            |
//  +---+-+-+-----------------------+-------------------------------+
//
//  where
//
//      Sev - is the severity code
//
//          00 - Success
//          01 - Informational
//          10 - Warning
//          11 - Error
//
//      C - is the Customer code flag
//
//      R - is a reserved bit
//
//      Facility - is the facility code
//
//      Code - is the facility's status code
//
//
// Define the facility codes
//


//
// Define the severity codes
//


//
// MessageId: INVALID_PARAMETER
//
// MessageText:
//
// Invalid paremeter
//
#define INVALID_PARAMETER                ((HRESULT)0x00000064L)

//
// MessageId: INVALID_INDEXFILENAME
//
// MessageText:
//
// Bad index file name
//
#define INVALID_INDEXFILENAME            ((HRESULT)0x00000065L)

//
// MessageId: FILE_OPEN_FAILED
//
// MessageText:
//
// File open failed
//
#define FILE_OPEN_FAILED                 ((HRESULT)0x00000066L)

//
// MessageId: DRE_INIT_FAILED
//
// MessageText:
//
// DRE initialization failed
//
#define DRE_INIT_FAILED                  ((HRESULT)0x00000067L)

//
// MessageId: DRE_DATABASE_CREATE_FAILED
//
// MessageText:
//
// DRE Database creation failed
//
#define DRE_DATABASE_CREATE_FAILED       ((HRESULT)0x00000068L)

//
// MessageId: DRE_GET_INFO_FAILED
//
// MessageText:
//
// DRE Get info failed
//
#define DRE_GET_INFO_FAILED              ((HRESULT)0x00000069L)

//
// MessageId: NRTDMS_CREATE_FAILED
//
// MessageText:
//
// Not able to create NRTDMS
//
#define NRTDMS_CREATE_FAILED             ((HRESULT)0x0000006AL)

//
// MessageId: ODBC_UNABLE_TO_EXECUTE_SQL
//
// MessageText:
//
// Unable to execute SQL statement
//
#define ODBC_UNABLE_TO_EXECUTE_SQL       ((HRESULT)0x0000006BL)

