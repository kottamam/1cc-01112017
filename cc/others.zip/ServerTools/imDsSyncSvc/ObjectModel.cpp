//=============================================================================
// File: ObjectModel.cpp
//-----------------------------------------------------------------------------
// Date      Who  Modification
// --------  ---  -------------------------------------------------------------
// 04/5/02  MDL  Initial coding
//-----------------------------------------------------------------------------
// Copyright (C) 2002, iManage, Inc.
// PROPRIETARY AND CONFIDENTIAL
//=============================================================================

#pragma once

#include "StdAfx.h"
#include "ObjectModel.h"

#include <iostream>
#include <Report\Report.h>
#include <db\db.h>
#include <registry/registry.h>
#include <crypt/crypt.h>

#include <ctime>
#include <iomanip>
#include <ShlObj.h>
extern void CheckIdForInvalidCharacters(RWCString &strId_, RWCString &strInvalidChar_);

DSOM::CSidMap g_SidMap;




namespace DSOM
{


_bstr_t TruncateString(const _bstr_t& strValue, UINT iMaxLen)
{
	_bstr_t retval = _T("");

	if (strValue.length() > iMaxLen)
	{
		retval = BstrStrings::Mid(strValue, 0, iMaxLen);
	}
	else
	{
		retval = strValue;
	}

	return retval;
}


CSidMap::CSidMap()
: m_mapSid2List( true )
{
}

CSidMap::~CSidMap()
{
	m_mapSid2List.RemoveAll();
}


void CSidMap::AddOrUpdate( const _bstr_t& strGroupObjectSID, const _bstr_t& strUserObjectGUID )
{
	if( strUserObjectGUID.length() == 0 )
		return;

	ObjectContainers::CUniqueBstrVector* pVec = get( strGroupObjectSID );

	if( pVec->IsMember( strUserObjectGUID ) )
	{
		// update value: remove and add it back
		pVec->Remove( strUserObjectGUID );
	}

	// add value
	pVec->AddBack( strUserObjectGUID );
}

void CSidMap::RemoveIfPresent( const _bstr_t& strUserObjectGUID )
{
	for( SID2LISTMAP::Const_Iterator iter = m_mapSid2List.Begin(); iter != m_mapSid2List.End(); iter++ )
	{
		ObjectContainers::CUniqueBstrVector *pVec = iter->second;
		if( pVec->IsMember( strUserObjectGUID ) )
			pVec->Remove( strUserObjectGUID );
	}
}

ObjectContainers::CUniqueBstrVector* CSidMap::get( const _bstr_t& strGroupObjectSID )
{
	ObjectContainers::CUniqueBstrVector *pVec = m_mapSid2List[ strGroupObjectSID ];
	if( pVec == NULL )
	{
		pVec = im_new ObjectContainers::CUniqueBstrVector();
		m_mapSid2List.Set( strGroupObjectSID, pVec );		// the map owns the vector pointer, will delete it automatically on destruction
	}

	return pVec;
}

const ObjectContainers::CUniqueBstrVector& CSidMap::Get( const _bstr_t& strGroupObjectSID )
{
	ObjectContainers::CUniqueBstrVector* pVec = get( strGroupObjectSID );
	return *pVec;
}

void CSidMap::Reset()
{
	m_mapSid2List.RemoveAll();
}


///////////////////////////////////////////////////////////////////////
// CDMSUser

CDMSUser::CDMSUser(
	const _bstr_t& bstrDn, 
	const _bstr_t& bstrName,
	const _bstr_t& bstrParentDn,
	const _bstr_t& bstrK1SyncId,
	const _bstr_t& bstrObjectSID,
	bool		   bExternal,
	const _bstr_t& bstrUserId,
	const _bstr_t& bstrTelephoneNumber,
	const _bstr_t& bstrMail,
	const _bstr_t& bstrFax,
	const _bstr_t& bstrLocation,
	const bool bEnabled,
	const _bstr_t& bstrPrimaryGroupID,
	IM::CDSSyncSvc_DSParameters::LDAPTYPE lNOS
	)
	:
	CDSUser( 
		bstrDn, 
		bstrName, 
		bstrParentDn, 
		bstrK1SyncId,
		bstrObjectSID,
		bExternal,
		bstrUserId,
		bstrTelephoneNumber,
		bstrMail,
		bstrFax,
		bstrLocation,
		bEnabled,
		bstrPrimaryGroupID
		),
		m_lNOS(lNOS)
{
}

CDMSUser::CDMSUser( const CDMSUser& DMSUser ) 
	: CDSUser( DMSUser ),	// call base copy constructor
	m_lNOS( DMSUser.m_lNOS )
{
	*this = DMSUser;
}

CDMSUser::~CDMSUser( void )
{
}

CDMSUser& CDMSUser::operator=( const CDMSUser& DMSUser )
{
	// call base class assignment operator
	CDSUser::operator=( DMSUser );

	m_lNOS = DMSUser.m_lNOS;

	bPasswordNeverExpires = DMSUser.bPasswordNeverExpires;
	bForcePasswordChange = DMSUser.bForcePasswordChange;
	strPassword = DMSUser.strPassword;

	return *this;
}

bool CDMSUser::operator==( const CDMSUser& DMSUser ) const
{
	return (
		CDSUser::operator==( DMSUser ) && 
		m_lNOS == DMSUser.m_lNOS
		);
}

const IM::CDSSyncSvc_DSParameters::LDAPTYPE& CDMSUser::GetNOS( void ) const
{
	return m_lNOS;
}

void CDMSUser::SetNOS( const IM::CDSSyncSvc_DSParameters::LDAPTYPE& lNOS )
{
	m_lNOS = lNOS;
}

const bool CDMSUser::getForcePasswordChange() const
{
	return bForcePasswordChange;
}

void CDMSUser::setForcePasswordChange(bool bForcePasswordChange)
{
	this->bForcePasswordChange = bForcePasswordChange;
}
const bool CDMSUser::getPasswordNeverExpires() const
{
	return bPasswordNeverExpires;
}

void CDMSUser::setPasswordNeverExpires(bool bPasswordNeverExpires)
{
	this->bPasswordNeverExpires = bPasswordNeverExpires;
}
const std::string CDMSUser::getUserNum() const
{
	return bstrUserNum;
}

void CDMSUser::setUserNum(std::string userNum)
{
	bstrUserNum = userNum;
}
void CDMSUser::setUserPassword(std::string userPassword)
{
	strPassword = userPassword;
}
const std::string CDMSUser::getUserPassword() const
{
	return strPassword;
}

///////////////////////////////////////////////////////////////////////
// CDMSGroup

CDMSGroup::CDMSGroup(
	const _bstr_t& bstrDn, 
	const _bstr_t& bstrName,
	const _bstr_t& bstrParentDn,
	const _bstr_t& bstrK1SyncId,
	const _bstr_t& bstrObjectSID,
	bool		   bExternal,
	const _bstr_t& bstrGroupId,
	const ObjectContainers::CUniqueBstrVector& vMembers,
	const bool bEnabled,
	IM::CDSSyncSvc_DSParameters::LDAPTYPE lNOS
	)
	:
	CDSGroup( 
		bstrDn, 
		bstrName, 
		bstrParentDn, 
		bstrK1SyncId,
		bstrObjectSID,
		bExternal,
		bstrGroupId,
		vMembers,
		bEnabled
		),
	m_lNOS( lNOS )
{
}

CDMSGroup::CDMSGroup( const CDMSGroup& DMSGroup ) 
	: CDSGroup( DMSGroup ),				// call base copy constructor
	m_lNOS( DMSGroup.m_lNOS )
{
	*this = DMSGroup;
}

CDMSGroup::~CDMSGroup( void )
{
}

CDMSGroup& CDMSGroup::operator=( const CDMSGroup& DMSGroup )
{
	// call base class assignment operator
	CDSGroup::operator=( DMSGroup );

	m_lNOS = DMSGroup.m_lNOS;

	return *this;
}

bool CDMSGroup::operator==( const CDMSGroup& DMSGroup ) const
{
	return (
		CDSGroup::operator==( DMSGroup ) && 
		m_lNOS == DMSGroup.m_lNOS
		);
}

const IM::CDSSyncSvc_DSParameters::LDAPTYPE& CDMSGroup::GetNOS( void ) const
{
	return m_lNOS;
}

void CDMSGroup::SetNOS( const IM::CDSSyncSvc_DSParameters::LDAPTYPE& lNOS )
{
	m_lNOS = lNOS;
}






// from ..\..\..\itools\mlib\dbIfc\dbGuiIfc.h
const _bstr_t STR_OSTYPE_NT	= _T( "3" );
const _bstr_t STR_OSTYPE_NOVELL_NDS	= _T( "4" );
const _bstr_t STR_OSTYPE_NT_ADS	= _T( "6" );
const _bstr_t STR_OSTYPE_NETSCAPE_DS = _T( "7" );

// from ..\..\..\itools\mlib\toolService\serviceMain.h
#define ENCRYPT_KEY _T( "iManage Service" )

#define DEFAULT_PASSWORD _T( "mhdocs" )


//
//	waitHookCallback
//
//	Hook function for processing events while waiting for
//	Document Server to reply
//
//	Returning a FALSE during the CLIENT_WAIT_PROGRESS mode will
//	cancel the call to the Document Server.  A TRUE will continue
//	the operation
//

BOOL waitHookCallback(long mode, long mSecs, long byteCount, void *v)
{
	switch (mode)
	{
	case CLIENT_WAIT_INIT:
		break;

	case CLIENT_WAIT_PROGRESS:
#ifdef LATER
		Report("RPC call in progress: %d msecs, bytes = %d, data rate %5.2fKbs\n",
				mSecs, byteCount, (float) byteCount / mSecs);
		return TRUE;
#endif
		break;

	case CLIENT_WAIT_DONE:
#ifdef LATER
		if (debug)
		{
			if (mSecs == 0)
				printf("--- < 1ms, data received = %d bytes\n",
						byteCount);
			else
				printf("--- %d msecs, bytes = %d, data rate %6.3fKbs\n",
						mSecs, byteCount, (float) byteCount / mSecs);
		}
		return TRUE;
#endif
		break;
	}

	return TRUE;
}




_bstr_t MakeErrorString( const _bstr_t& strLabel, const _bstr_t& strValue )
{
	wchar_t szBuf[ 1024 ];
	memset( szBuf, 0, 1024 * sizeof( wchar_t ) );

	_bstr_t szFmt = L"%s: %s";
	wsprintfW( szBuf, szFmt, ( LPCWSTR ) strLabel, ( LPCWSTR ) strValue );

	_bstr_t szUTF8 = UnicodeToUTF8(szBuf).c_str();
	return szUTF8;
}

_bstr_t MakeErrorString( const _bstr_t& strLabel1, const _bstr_t& strValue1, const _bstr_t& strLabel2, const _bstr_t& strValue2 )
{
	wchar_t szBuf[ 1024 ];
	memset( szBuf, 0, 1024 * sizeof( wchar_t ) );

	_bstr_t szFmt = L"%s: %s, %s: %s";
	wsprintfW( szBuf, szFmt, ( LPCWSTR ) strLabel1, ( LPCWSTR ) strValue1, ( LPCWSTR ) strLabel2, ( LPCWSTR ) strValue2 );

	_bstr_t szUTF8 = UnicodeToUTF8(szBuf).c_str();
	return szUTF8;
}

_bstr_t MakeErrorString( const _bstr_t& strLabel1, const _bstr_t& strValue1, const _bstr_t& strLabel2, const _bstr_t& strValue2, const _bstr_t& strLabel3, const _bstr_t& strValue3 )
{
	wchar_t szBuf[ 1024 ];
	memset( szBuf, 0, 1024 * sizeof( wchar_t ) );

	_bstr_t szFmt = L"%s: %s, %s: %s, %s: %s";
	wsprintfW( szBuf, szFmt, ( LPCWSTR ) strLabel1, ( LPCWSTR ) strValue1, ( LPCWSTR ) strLabel2, ( LPCWSTR ) strValue2, ( LPCWSTR ) strLabel3, ( LPCWSTR ) strValue3 );

	_bstr_t szUTF8 = UnicodeToUTF8(szBuf).c_str();
	return szUTF8;
}

_bstr_t MakeErrorString( const _bstr_t& strLabel1, const _bstr_t& strValue1, const _bstr_t& strLabel2, const _bstr_t& strValue2, const _bstr_t& strLabel3, const _bstr_t& strValue3, const _bstr_t& strLabel4, const _bstr_t& strValue4 )
{
	wchar_t szBuf[ 1024 ];
	memset( szBuf, 0, 1024 * sizeof( wchar_t ) );

	_bstr_t szFmt = L"%s: %s, %s: %s, %s: %s, %s: %s";
	wsprintfW( szBuf, szFmt, ( LPCWSTR ) strLabel1, ( LPCWSTR ) strValue1, ( LPCWSTR ) strLabel2, ( LPCWSTR ) strValue2, ( LPCWSTR ) strLabel3, ( LPCWSTR ) strValue3, ( LPCWSTR ) strLabel4, ( LPCWSTR ) strValue4 );

	_bstr_t szUTF8 = UnicodeToUTF8(szBuf).c_str();
	return szUTF8;
}

_bstr_t IntToBstr( int i )
{
	wchar_t buf[ 16 ];
	memset( buf, 0, 16 * sizeof( wchar_t ) );
	_itow( i, buf, 10 );
	return buf;
}



/////////////////////////////////////////////////////
// CMlibCommunication

CMlibCommunication::CMlibCommunication(CDSSyncContextGeneric* pDSSyncContext)
	: m_pdb(NULL), m_pDSSyncContext(pDSSyncContext), m_bLoggedOn(false)
{
	CJediContext jc("CMlibCommunication", "CMlibCommunication");
	try
	{
		if (m_pDSSyncContext != NULL)
		{
			if (m_pDSSyncContext->GetConnection()->m_DMSParameters.m_lTcpipPort.Get() != 0)
				m_pdb = im_new NRDsSyncSvcClient(NULL, _T("imDsSyncSvc"), m_pDSSyncContext->GetConnection()->m_DMSParameters.m_lTcpipPort.Get());
			else
				m_pdb = im_new NRDsSyncSvcClient(NULL, _T("imDsSyncSvc"));

			// logon
			LPCTSTR szServer = m_pDSSyncContext->GetConnection()->m_DMSParameters.m_strDms.Get().c_str();
			if (szServer != NULL)
			{
				m_pdb->setServer(szServer);
				m_pdb->setTimeout(10 * 60);	// 10 minute timeout to DMS

				long lLoginType = m_pDSSyncContext->GetConnection()->m_DMSParameters.m_lLoginType.Get();
				if (lLoginType == 0)
				{

					long lRetval = m_pdb->Logon(m_pDSSyncContext->GetConnection()->m_DMSParameters.m_strUserId.Get().c_str(), m_pDSSyncContext->GetConnection()->m_DMSParameters.m_strPassword.Get().c_str());
					if (lRetval != NRC_SUCCESS)
					{
						RWCString rwErrorMsg;
						NRGetCodeString(lRetval, rwErrorMsg);
						LogMsg(LOG_ERROR, _T("NRDsSyncSvcClient::Logon() failure on server '%s', user '%s', Error Message '%s'"), m_pDSSyncContext->GetConnection()->m_DMSParameters.m_strDms.Get().c_str(), m_pDSSyncContext->GetConnection()->m_DMSParameters.m_strUserId.Get().c_str(), rwErrorMsg);

					}
					else
					{
						m_bLoggedOn = true;
						LogMsg(LOG_INFO, _T("NRDsSyncSvcClient::Logon() success on server '%s', user '%s'"), m_pDSSyncContext->GetConnection()->m_DMSParameters.m_strDms.Get().c_str(), m_pDSSyncContext->GetConnection()->m_DMSParameters.m_strUserId.Get().c_str());
					}
				}
				else if (lLoginType == 1)
				{
					if (m_pDSSyncContext->GetConnection()->strToken.length() ==0)
						m_bLoggedOn = FALSE;
					else
					{
						NRList pKVPList;
						ProfileColumnSelection selectFlag;
						NRList* pDatabaseList = new NRList();
						IM::NrString szDefaultLibrary, userId;
						NRList* pEffectiveDbList = new NRList();
						DWORD bufferSize = 32767;
						TCHAR  infoBuf[32767];
						GetComputerName(infoBuf, &bufferSize);
						LCID lcId = GetThreadLocale();
						
						
						long lResult = m_pdb->SSOLogon(m_pDSSyncContext->GetConnection()->strToken.c_str(), SSOAuthType::AUTH_WORKSITE_TOKEN, &pKVPList, infoBuf, TRUE, 0, (int)lcId, selectFlag, 0, pDatabaseList, (char*)szDefaultLibrary.c_str(), pEffectiveDbList, (char *)userId.c_str());
						//call SSO login
						if (lResult == NRC_SUCCESS)
							m_bLoggedOn = TRUE;
						else
							m_bLoggedOn = FALSE;
					}

				}
			}
			else
				jc.ThrowGenericError("m_pDSSyncContext->GetConnection( )", "CMlibCommunication::CMlibCommunication() unable to get DMS parameters");
		}
	}

	catch (CBaseException& e)
	{
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		jc.LogMessage((imstd::exception)e.what());
	}
	catch (long lErrorCode)
	{
		jc.LogMessage(lErrorCode);
	}
}

CMlibCommunication::~CMlibCommunication(void)
{
	CJediContext jc("CMlibCommunication", "~CMlibCommunication");
	try
	{
		if (m_pdb != NULL)
		{
			// logoff
			m_pdb->logoff();

			delete m_pdb;
		}
		m_mapUserIdToUserNum.clear();
		m_mapSyncIdToUserNum.clear();
		m_mapDistNameToUserNum.clear();
		m_mapUserIdToSyncId.clear();
		m_mapUserIdToDn.clear();
		m_mapDnToSyncId.clear();
		m_mapDnToUserId.clear();
		m_SyncIdToUserId.clear();
		m_SyncIdToDn.clear();
	}

	catch (CBaseException& e)
	{
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		jc.LogMessage((imstd::exception)e.what());
	}
	catch (long lErrorCode)
	{
		jc.LogMessage(lErrorCode);
	}
}


_bstr_t CMlibCommunication::GetBeginningDosTime(void)
{
	DateTime dtBeginningOfTime(DateTime::BeginningOfTime());
	DateTime dtOneSecond(1, 0);
	dtBeginningOfTime += dtOneSecond;

	RWCString strDateTime;
	return dtBeginningOfTime.GetDosDateTime(strDateTime);
}

DWORD CMlibCommunication::GetDSUserFromNRUser(NRUserEx* pNRUserEx, CDSUser*& pDSUser)
{
	CJediContext jc("CMlibCommunication", "GetDSUserFromNRUser");
	DWORD dwRetval = DSOM_SUCCESS;
	pDSUser = NULL;

	try
	{
		if (pNRUserEx != NULL)
		{
			// get user attributes
			const char *szUserDistName = pNRUserEx->getValue(NRUserEx::NRUSEREX_DIST_NAME);
			const char *szUserFullName = pNRUserEx->getValue(NRUserEx::NRUSEREX_FULLNAME);
			const char *szUserDomain = pNRUserEx->getValue(NRUserEx::NRUSEREX_USER_DOMAIN);
			const char *szUserSyncId = pNRUserEx->getValue(NRUserEx::NRUSEREX_SYNC_ID);
			const char *szUserId = pNRUserEx->getValue(NRUserEx::NRUSEREX_USERID);
			const char *szUserPhone = pNRUserEx->getValue(NRUserEx::NRUSEREX_PHONE);
			const char *szUserEmail = pNRUserEx->getValue(NRUserEx::NRUSEREX_EMAIL);
			const char *szUserFax = pNRUserEx->getValue(NRUserEx::NRUSEREX_FAX);
			const char *szUserLocation = pNRUserEx->getValue(NRUserEx::NRUSEREX_USERLOC);
			const char *szUserLogin = pNRUserEx->getValue(NRUserEx::NRUSEREX_LOGIN);

			bool bIsExternal = false;
#ifdef WS85_EXTERNAL
			const char *szIsExternal = pNRUserEx->getValue(NRUserEx::NRUSEREX_IS_EXTERNAL);
			bIsExternal = _tcsicmp(szIsExternal, _T("Y")) == 0;
#endif

			bool bEnabled = _tcsicmp(szUserLogin, _T("Y")) == 0;

			// create user
			pDSUser = im_new CDSUser(
				UTF8ToUnicode(szUserDistName).c_str(),
				UTF8ToUnicode(szUserFullName).c_str(),
				UTF8ToUnicode(szUserDomain).c_str(),
				UTF8ToUnicode(szUserSyncId).c_str(),
				L"",	// objectSID
				bIsExternal,
				UTF8ToUnicode(szUserId).c_str(),
				UTF8ToUnicode(szUserPhone).c_str(),
				UTF8ToUnicode(szUserEmail).c_str(),
				UTF8ToUnicode(szUserFax).c_str(),
				UTF8ToUnicode(szUserLocation).c_str(),
				bEnabled,
				L""	// primaryGroupID
				);
		}
	}

	catch (CBaseException& e)
	{
		if (pDSUser){ delete pDSUser; pDSUser = NULL; }
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		if (pDSUser){ delete pDSUser; pDSUser = NULL; }
		dwRetval = DSOM_FAILURE;
		jc.LogMessage((imstd::exception)e.what());
	}
	catch (long lErrorCode)
	{
		if (pDSUser){ delete pDSUser; pDSUser = NULL; }
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(lErrorCode);
	}

	// caller must delete pointer
	return dwRetval;
}

IM::CDSSyncSvc_DSParameters::LDAPTYPE CMlibCommunication::ConvertDmsNosToDsNos(long lDmsNos)
{
	CJediContext jc("CMlibCommunication", "ConvertDmsNosToDsNos");

	try
	{
		switch (lDmsNos)
		{
		case 3:
			return IM::CDSSyncSvc_DSParameters::NT;
			break;
		case 4:
			return IM::CDSSyncSvc_DSParameters::Novell;
			break;
		case 6:
			return IM::CDSSyncSvc_DSParameters::Microsoft;
			break;
		case 7:
			return IM::CDSSyncSvc_DSParameters::Sun;
			break;
		default:
			jc.ThrowGenericError("Converting DMS NOS to DS NOS", MakeErrorString("Unsupported DMS NOS type: ", IntToBstr(lDmsNos)));
			break;
		}
	}

	catch (CGenericException& e)
	{
		jc.LogMessage(e);
		throw;	// caller expects this exception for invalid conversion type
	}
	catch (CBaseException& e)
	{
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		jc.LogMessage((imstd::exception)e.what());
	}
	catch (long lErrorCode)
	{
		jc.LogMessage(lErrorCode);
	}

	// exceptional condition
	return IM::CDSSyncSvc_DSParameters::Microsoft;
}

_bstr_t CMlibCommunication::ConvertDsNosToDmsNos(IM::CDSSyncSvc_DSParameters::LDAPTYPE DsNos)
{
	CJediContext jc("CMlibCommunication", "ConvertDsNosToDmsNos");

	try
	{
		switch (DsNos)
		{
		case IM::CDSSyncSvc_DSParameters::Microsoft:
			return STR_OSTYPE_NT_ADS;
			break;
		case IM::CDSSyncSvc_DSParameters::Sun:
			return STR_OSTYPE_NETSCAPE_DS;
			break;
		case IM::CDSSyncSvc_DSParameters::Novell:
			return STR_OSTYPE_NOVELL_NDS;
			break;
		case IM::CDSSyncSvc_DSParameters::NT:
			return STR_OSTYPE_NT;
			break;
		default:
			jc.ThrowGenericError("Converting DS NOS to DMS NOS", MakeErrorString("Unsupported DS NOS type: ", IntToBstr((int)DsNos)));
			break;
		}
	}

	catch (CGenericException& e)
	{
		jc.LogMessage(e);
		throw;	// caller expects this exception for invalid conversion type
	}
	catch (CBaseException& e)
	{
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		jc.LogMessage((imstd::exception)e.what());
	}
	catch (long lErrorCode)
	{
		jc.LogMessage(lErrorCode);
	}

	// exceptional condition
	return STR_OSTYPE_NT_ADS;
}


DWORD CMlibCommunication::GetDMSUserFromNRUser(NRUserEx* pNRUserEx, CDMSUser*& pDMSUser)
{
	CJediContext jc("CMlibCommunication", "GetDMSUserFromNRUser");
	DWORD dwRetval = DSOM_SUCCESS;
	pDMSUser = NULL;

	try
	{
		if (pNRUserEx != NULL)
		{
			// get user attributes
			const char *szUserDistName = pNRUserEx->getValue(NRUserEx::NRUSEREX_DIST_NAME);
			const char *szUserFullName = pNRUserEx->getValue(NRUserEx::NRUSEREX_FULLNAME);
			const char *szUserDomain = pNRUserEx->getValue(NRUserEx::NRUSEREX_USER_DOMAIN);
			const char *szUserSyncId = pNRUserEx->getValue(NRUserEx::NRUSEREX_SYNC_ID);
			const char *szUserId = pNRUserEx->getValue(NRUserEx::NRUSEREX_USERID);
			const char *szUserPhone = pNRUserEx->getValue(NRUserEx::NRUSEREX_PHONE);
			const char *szUserEmail = pNRUserEx->getValue(NRUserEx::NRUSEREX_EMAIL);
			const char *szUserFax = pNRUserEx->getValue(NRUserEx::NRUSEREX_FAX);
			const char *szUserLocation = pNRUserEx->getValue(NRUserEx::NRUSEREX_USERLOC);
			const char *szUserLogin = pNRUserEx->getValue(NRUserEx::NRUSEREX_LOGIN);
			const char *szUserNOS = pNRUserEx->getValue(NRUserEx::NRUSEREX_USER_NOS);

			bool bIsExternal = false;
#ifdef WS85_EXTERNAL
			const char *szIsExternal = pNRUserEx->getValue(NRUserEx::NRUSEREX_IS_EXTERNAL);
			bIsExternal = _tcsicmp(szIsExternal, _T("Y")) == 0;
#endif

			bool bEnabled = _tcsicmp(szUserLogin, _T("Y")) == 0;
			IM::CDSSyncSvc_DSParameters::LDAPTYPE lNOS = (IM::CDSSyncSvc_DSParameters::LDAPTYPE) atoi(szUserNOS);


			// create user
			pDMSUser = im_new CDMSUser(
				UTF8ToUnicode(szUserDistName).c_str(),
				UTF8ToUnicode(szUserFullName).c_str(),
				UTF8ToUnicode(szUserDomain).c_str(),
				UTF8ToUnicode(szUserSyncId).c_str(),
				L"",	// objectSID
				bIsExternal,
				UTF8ToUnicode(szUserId).c_str(),
				UTF8ToUnicode(szUserPhone).c_str(),
				UTF8ToUnicode(szUserEmail).c_str(),
				UTF8ToUnicode(szUserFax).c_str(),
				UTF8ToUnicode(szUserLocation).c_str(),
				bEnabled,
				L"",	// primaryGroupID
				lNOS
				);
		}
	}

	catch (CBaseException& e)
	{
		if (pDMSUser) { delete pDMSUser; pDMSUser = NULL; }
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		if (pDMSUser) { delete pDMSUser; pDMSUser = NULL; }
		dwRetval = DSOM_FAILURE;
		jc.LogMessage((imstd::exception)e.what());
	}
	catch (long lErrorCode)
	{
		if (pDMSUser) { delete pDMSUser; pDMSUser = NULL; }
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(lErrorCode);
	}

	// caller must delete pointer
	return dwRetval;
}


DWORD CMlibCommunication::GetDSGroupFromNRGroup(NRGroupEx* pNRGroupEx, CDSGroup*& pDSGroup)
{
	CJediContext jc("CMlibCommunication", "GetDSGroupFromNRGroup");
	DWORD dwRetval = DSOM_SUCCESS;
	pDSGroup = NULL;

	try
	{
		if (pNRGroupEx != NULL)
		{
			// get group attributes
			const char *szGroupDistName = pNRGroupEx->getValue(NRGroupEx::NRGROUPEX_DIST_NAME);
			const char *szGroupFullName = pNRGroupEx->getValue(NRGroupEx::NRGROUPEX_FULLNAME);
			const char *szGroupDomain = pNRGroupEx->getValue(NRGroupEx::NRGROUPEX_GROUP_DOMAIN);
			const char *szGroupSyncId = pNRGroupEx->getValue(NRGroupEx::NRGROUPEX_SYNC_ID);
			const char *szGroupId = pNRGroupEx->getValue(NRGroupEx::NRGROUPEX_GROUPID);
			const char *szGroupEnabled = pNRGroupEx->getValue(NRGroupEx::NRGROUPEX_ENABLED);

			bool bIsExternal = false;
#ifdef WS85_EXTERNAL
			const char *szIsExternal = pNRGroupEx->getValue(NRGroupEx::NRGROUPEX_IS_EXTERNAL);
			bIsExternal = _tcsicmp(szIsExternal, _T("Y")) == 0;
#endif

			bool bEnabled = _tcsicmp(szGroupEnabled, _T("Y")) == 0;

			ObjectContainers::CUniqueBstrVector vMembers;

			// create  group
			pDSGroup = im_new CDSGroup(
				UTF8ToUnicode(szGroupDistName).c_str(),
				UTF8ToUnicode(szGroupFullName).c_str(),
				UTF8ToUnicode(szGroupDomain).c_str(),
				UTF8ToUnicode(szGroupSyncId).c_str(),
				_T(""),	// objectSID
				bIsExternal,
				UTF8ToUnicode(szGroupId).c_str(),
				vMembers,
				bEnabled
				);
		}
	}

	catch (CBaseException& e)
	{
		if (pDSGroup) { delete pDSGroup; pDSGroup = NULL; }
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		if (pDSGroup) { delete pDSGroup; pDSGroup = NULL; }
		dwRetval = DSOM_FAILURE;
		jc.LogMessage((imstd::exception)e.what());
	}
	catch (long lErrorCode)
	{
		if (pDSGroup) { delete pDSGroup; pDSGroup = NULL; }
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(lErrorCode);
	}

	// caller must delete pointer
	return dwRetval;
}

DWORD CMlibCommunication::GetDMSGroupFromNRGroup(NRGroupEx* pNRGroupEx, CDMSGroup*& pDMSGroup)
{
	CJediContext jc("CMlibCommunication", "GetDMSGroupFromNRGroup");
	DWORD dwRetval = DSOM_SUCCESS;
	pDMSGroup = NULL;

	try
	{
		if (pNRGroupEx != NULL)
		{
			// get group attributes
			const char *szGroupDistName = pNRGroupEx->getValue(NRGroupEx::NRGROUPEX_DIST_NAME);
			const char *szGroupFullName = pNRGroupEx->getValue(NRGroupEx::NRGROUPEX_FULLNAME);
			const char *szGroupDomain = pNRGroupEx->getValue(NRGroupEx::NRGROUPEX_GROUP_DOMAIN);
			const char *szGroupSyncId = pNRGroupEx->getValue(NRGroupEx::NRGROUPEX_SYNC_ID);
			const char *szGroupId = pNRGroupEx->getValue(NRGroupEx::NRGROUPEX_GROUPID);
			const char *szGroupEnabled = pNRGroupEx->getValue(NRGroupEx::NRGROUPEX_ENABLED);
			const char *szGroupNOS = pNRGroupEx->getValue(NRGroupEx::NRGROUPEX_GROUP_NOS);

			bool bIsExternal = false;
#ifdef WS85_EXTERNAL
			const char *szIsExternal = pNRGroupEx->getValue(NRGroupEx::NRGROUPEX_IS_EXTERNAL);
			bIsExternal = _tcsicmp(szIsExternal, _T("Y")) == 0;
#endif

			bool bEnabled = _tcsicmp(szGroupEnabled, _T("Y")) == 0;
			IM::CDSSyncSvc_DSParameters::LDAPTYPE lNOS = (IM::CDSSyncSvc_DSParameters::LDAPTYPE) atoi(szGroupNOS);

			ObjectContainers::CUniqueBstrVector vMembers;

			// create  group
			pDMSGroup = im_new CDMSGroup(
				UTF8ToUnicode(szGroupDistName).c_str(),
				UTF8ToUnicode(szGroupFullName).c_str(),
				UTF8ToUnicode(szGroupDomain).c_str(),
				UTF8ToUnicode(szGroupSyncId).c_str(),
				_T(""),	// objectSID
				bIsExternal,
				UTF8ToUnicode(szGroupId).c_str(),
				vMembers,
				bEnabled,
				lNOS
				);
		}
	}

	catch (CBaseException& e)
	{
		if (pDMSGroup) { delete pDMSGroup; pDMSGroup = NULL; }
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		if (pDMSGroup) { delete pDMSGroup; pDMSGroup = NULL; }
		dwRetval = DSOM_FAILURE;
		jc.LogMessage((imstd::exception)e.what());
	}
	catch (long lErrorCode)
	{
		if (pDMSGroup) { delete pDMSGroup; pDMSGroup = NULL; }
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(lErrorCode);
	}

	// caller must delete pointer
	return dwRetval;
}


DWORD CMlibCommunication::SetNRUserFromDSUser(NRUserEx& NRUser, const CDSUser& DSUser, const bool bSetPassword, const bool bSetEnabled)
{
	CJediContext jc("CMlibCommunication", "SetNRUserFromDSUser");
	DWORD dwRetval = DSOM_SUCCESS;

	try
	{
		NRUser.setValue(NRUserEx::NRUSEREX_DIST_NAME, ((DSUser.GetDn().length() > 0) ? UnicodeToUTF8(DSUser.GetDn()).c_str() : NULL));
		NRUser.setValue(NRUserEx::NRUSEREX_SYNC_ID, ((DSUser.GetK1SyncId().length() > 0) ? UnicodeToUTF8(DSUser.GetK1SyncId()).c_str() : NULL));
		NRUser.setValue(NRUserEx::NRUSEREX_USERID, ((DSUser.GetUserId().length() > 0) ? UnicodeToUTF8(DSUser.GetUserId()).c_str() : NULL));
		NRUser.setValue(NRUserEx::NRUSEREX_USERIDEX, ((DSUser.GetUserId().length() > 0) ? UnicodeToUTF8(DSUser.GetUserId()).c_str() : NULL));
		NRUser.setValue(NRUserEx::NRUSEREX_FULLNAME, ((DSUser.GetName().length() > 0) ? UnicodeToUTF8(DSUser.GetName()).c_str() : NULL));

		NRUser.setValue(NRUserEx::NRUSEREX_PHONE, ((DSUser.GetTelephoneNumber().length() > 0) ? UnicodeToUTF8(TruncateString(DSUser.GetTelephoneNumber(), 32)).c_str() : NULL));
		NRUser.setValue(NRUserEx::NRUSEREX_FAX, ((DSUser.GetFax().length()) ? UnicodeToUTF8(TruncateString(DSUser.GetFax(), 32)).c_str() : NULL));
		NRUser.setValue(NRUserEx::NRUSEREX_USERLOC, ((DSUser.GetLocation().length() > 0) ? UnicodeToUTF8(TruncateString(DSUser.GetLocation(), 254)).c_str() : NULL));

		NRUser.setValue(NRUserEx::NRUSEREX_EMAIL, ((DSUser.GetMail().length() > 0) ? UnicodeToUTF8(DSUser.GetMail()).c_str() : NULL));
		NRUser.setValue(NRUserEx::NRUSEREX_USER_DOMAIN, ((DSUser.GetParentDn().length()) ? UnicodeToUTF8(DSUser.GetParentDn()).c_str() : NULL));

		// Defect #41488 -- Sync Svc will now follow ADS enabled flag 9/18/2006 MH
		NRUser.setValue(NRUserEx::NRUSEREX_LOGIN, DSUser.GetEnabled() ? _T("Y") : _T("N"));

#ifdef WS85_EXTERNAL
		NRUser.setValue(NRUserEx::NRUSEREX_IS_EXTERNAL, DSUser.GetExternal() ? _T("Y") : _T("N"));
#endif

		NRUser.setValue(NRUserEx::NRUSEREX_LAST_SYNC_TS, m_pDSSyncContext->GetTimestamp());

		_bstr_t DmsNos = ConvertDsNosToDmsNos((IM::CDSSyncSvc_DSParameters::LDAPTYPE) m_pDSSyncContext->GetConnection()->m_DSParameters.m_lServiceType.Get());
		NRUser.setValue(NRUserEx::NRUSEREX_USER_NOS, DmsNos);

		if (bSetPassword)
		{
			NRUser.setValue(NRUserEx::NRUSEREX_USER_PASSWD, m_pDSSyncContext->GetConnection()->m_DMSParameters.m_strDefaultPassword.Get().c_str());
			NRUser.setValue(NRUserEx::NRUSEREX_PWD_NEVER_EXPIRE_F, m_pDSSyncContext->GetConnection()->m_DMSParameters.m_bDefaultPasswordNeverExpires.Get() ? _T("Y") : _T("N"));
			NRUser.setValue(NRUserEx::NRUSEREX_FORCE_PASSWORD_CHANGE_F, m_pDSSyncContext->GetConnection()->m_DMSParameters.m_bDefaultPasswordMustBeChanged.Get() ? _T("Y") : _T("N"));
		}

		if (bSetEnabled)
			NRUser.setValue(NRUserEx::NRUSEREX_LOGIN, DSUser.GetEnabled() ? _T("Y") : _T("N"));
		else
		{
			if (!DSUser.GetEnabled())
				NRUser.setValue(NRUserEx::NRUSEREX_LOGIN, _T("N"));
		}
	}

	catch (CBaseException& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage((imstd::exception)e.what());
	}
	catch (long lErrorCode)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(lErrorCode);
	}
	return dwRetval;
}

DWORD CMlibCommunication::SetNRUserFromDMSUser(NRUserEx& NRUser, const CDMSUser& DMSUser, const bool bSetPassword, const bool bSetEnabled)
{
	CJediContext jc("CMlibCommunication", "SetNRUserFromDMSUser");
	DWORD dwRetval = DSOM_SUCCESS;
	try
	{
		NRUser.setValue(NRUserEx::NRUSEREX_DIST_NAME, ((DMSUser.GetDn().length() > 0) ? UnicodeToUTF8(DMSUser.GetDn()).c_str() : NULL));
		NRUser.setValue(NRUserEx::NRUSEREX_SYNC_ID, ((DMSUser.GetK1SyncId().length() > 0) ? UnicodeToUTF8(DMSUser.GetK1SyncId()).c_str() : NULL));
		NRUser.setValue(NRUserEx::NRUSEREX_USERID, ((DMSUser.GetUserId().length() > 0) ? UnicodeToUTF8(DMSUser.GetUserId()).c_str() : NULL));
		NRUser.setValue(NRUserEx::NRUSEREX_USERIDEX, ((DMSUser.GetUserId().length() > 0) ? UnicodeToUTF8(DMSUser.GetUserId()).c_str() : NULL));
		NRUser.setValue(NRUserEx::NRUSEREX_FULLNAME, ((DMSUser.GetName().length() > 0) ? UnicodeToUTF8(DMSUser.GetName()).c_str() : NULL));
		NRUser.setValue(NRUserEx::NRUSEREX_PHONE, ((DMSUser.GetTelephoneNumber().length() > 0) ? UnicodeToUTF8(DMSUser.GetTelephoneNumber()).c_str() : NULL));
		NRUser.setValue(NRUserEx::NRUSEREX_FAX, ((DMSUser.GetFax().length()) ? UnicodeToUTF8(DMSUser.GetFax()).c_str() : NULL));
		NRUser.setValue(NRUserEx::NRUSEREX_USERLOC, ((DMSUser.GetLocation().length() > 0) ? UnicodeToUTF8(DMSUser.GetLocation()).c_str() : NULL));
		NRUser.setValue(NRUserEx::NRUSEREX_EMAIL, ((DMSUser.GetMail().length() > 0) ? UnicodeToUTF8(DMSUser.GetMail()).c_str() : NULL));
		NRUser.setValue(NRUserEx::NRUSEREX_USER_DOMAIN, ((DMSUser.GetParentDn().length()) ? UnicodeToUTF8(DMSUser.GetParentDn()).c_str() : NULL));
		//NRUser.setValue( NRUserEx::NRUSEREX_LOGIN, DMSUser.GetEnabled( ) ? _T( "Y" ) : _T( "N" ) );
		NRUser.setValue(NRUserEx::NRUSEREX_LAST_SYNC_TS, m_pDSSyncContext->GetTimestamp());

#ifdef WS85_EXTERNAL
		NRUser.setValue(NRUserEx::NRUSEREX_IS_EXTERNAL, DMSUser.GetExternal() ? _T("Y") : _T("N"));
#endif

		_bstr_t DmsNos = ConvertDsNosToDmsNos(DMSUser.GetNOS());
		NRUser.setValue(NRUserEx::NRUSEREX_USER_NOS, DmsNos);

		if (bSetPassword)
		{
			NRUser.setValue(NRUserEx::NRUSEREX_USER_PASSWD, m_pDSSyncContext->GetConnection()->m_DMSParameters.m_strDefaultPassword.Get().c_str());
			NRUser.setValue(NRUserEx::NRUSEREX_PWD_NEVER_EXPIRE_F, m_pDSSyncContext->GetConnection()->m_DMSParameters.m_bDefaultPasswordNeverExpires.Get() ? _T("Y") : _T("N"));
			NRUser.setValue(NRUserEx::NRUSEREX_FORCE_PASSWORD_CHANGE_F, m_pDSSyncContext->GetConnection()->m_DMSParameters.m_bDefaultPasswordMustBeChanged.Get() ? _T("Y") : _T("N"));
		}

		if (bSetEnabled)
			NRUser.setValue(NRUserEx::NRUSEREX_LOGIN, DMSUser.GetEnabled() ? _T("Y") : _T("N"));
		else
		{
			if (!DMSUser.GetEnabled())
				NRUser.setValue(NRUserEx::NRUSEREX_LOGIN, _T("N"));
		}
	}

	catch (CBaseException& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage((imstd::exception)e.what());
	}
	catch (long lErrorCode)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(lErrorCode);
	}
	return dwRetval;
}

DWORD CMlibCommunication::SetNRGroupFromDSGroup(NRGroupEx& NRGroup, const CDSGroup& DSGroup, const bool bSetEnabled)
{
	CJediContext jc("CMlibCommunication", "SetNRGroupFromDSGroup");
	DWORD dwRetval = DSOM_SUCCESS;

	try
	{
		NRGroup.setValue(NRGroupEx::NRGROUPEX_DIST_NAME, ((DSGroup.GetDn().length() > 0) ? UnicodeToUTF8(DSGroup.GetDn()).c_str() : NULL));
		NRGroup.setValue(NRGroupEx::NRGROUPEX_SYNC_ID, ((DSGroup.GetK1SyncId().length() > 0) ? UnicodeToUTF8(DSGroup.GetK1SyncId()).c_str() : NULL));
		NRGroup.setValue(NRGroupEx::NRGROUPEX_GROUPID, ((DSGroup.GetGroupId().length() > 0) ? UnicodeToUTF8(DSGroup.GetGroupId()).c_str() : NULL));
		NRGroup.setValue(NRGroupEx::NRGROUPEX_FULLNAME, ((DSGroup.GetName().length() > 0) ? UnicodeToUTF8(DSGroup.GetName()).c_str() : NULL));
		NRGroup.setValue(NRGroupEx::NRGROUPEX_GROUP_DOMAIN, ((DSGroup.GetParentDn().length() > 0) ? UnicodeToUTF8(DSGroup.GetParentDn()).c_str() : NULL));
		//NRGroup.setValue( NRGroupEx::NRGROUPEX_ENABLED, DSGroup.GetEnabled( ) ? _T( "Y" ) : _T( "N" ) );
		NRGroup.setValue(NRGroupEx::NRGROUPEX_LAST_SYNC_TS, m_pDSSyncContext->GetTimestamp());

#ifdef WS85_EXTERNAL
		NRGroup.setValue(NRGroupEx::NRGROUPEX_IS_EXTERNAL, DSGroup.GetExternal() ? _T("Y") : _T("N"));
#endif

		_bstr_t DmsNos = ConvertDsNosToDmsNos((IM::CDSSyncSvc_DSParameters::LDAPTYPE) m_pDSSyncContext->GetConnection()->m_DSParameters.m_lServiceType.Get());
		NRGroup.setValue(NRGroupEx::NRGROUPEX_GROUP_NOS, DmsNos);

		if (bSetEnabled)
			NRGroup.setValue(NRGroupEx::NRGROUPEX_ENABLED, DSGroup.GetEnabled() ? _T("Y") : _T("N"));
		else
		{
			if (!DSGroup.GetEnabled())
				NRGroup.setValue(NRGroupEx::NRGROUPEX_ENABLED, _T("N"));
		}
	}
	catch (CBaseException& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage((imstd::exception)e.what());
	}
	catch (long lErrorCode)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(lErrorCode);
	}
	return dwRetval;
}

DWORD CMlibCommunication::SetNRGroupFromDMSGroup(NRGroupEx& NRGroup, const CDMSGroup& DMSGroup, const bool bSetEnabled)
{
	CJediContext jc("CMlibCommunication", "SetNRGroupFromDMSGroup");
	DWORD dwRetval = DSOM_SUCCESS;

	try
	{
		NRGroup.setValue(NRGroupEx::NRGROUPEX_DIST_NAME, ((DMSGroup.GetDn().length() > 0) ? UnicodeToUTF8(DMSGroup.GetDn()).c_str() : NULL));
		NRGroup.setValue(NRGroupEx::NRGROUPEX_SYNC_ID, ((DMSGroup.GetK1SyncId().length() > 0) ? UnicodeToUTF8(DMSGroup.GetK1SyncId()).c_str() : NULL));
		NRGroup.setValue(NRGroupEx::NRGROUPEX_GROUPID, ((DMSGroup.GetGroupId().length() > 0) ? UnicodeToUTF8(DMSGroup.GetGroupId()).c_str() : NULL));
		NRGroup.setValue(NRGroupEx::NRGROUPEX_FULLNAME, ((DMSGroup.GetName().length() > 0) ? UnicodeToUTF8(DMSGroup.GetName()).c_str() : NULL));
		NRGroup.setValue(NRGroupEx::NRGROUPEX_GROUP_DOMAIN, ((DMSGroup.GetParentDn().length() > 0) ? UnicodeToUTF8(DMSGroup.GetParentDn()).c_str() : NULL));

#ifdef WS85_EXTERNAL
		NRGroup.setValue(NRGroupEx::NRGROUPEX_IS_EXTERNAL, DMSGroup.GetExternal() ? _T("Y") : _T("N"));
#endif

		// Defect #41488 -- Sync Svc will now follow ADS enabled flag 9/18/2006 MH
		NRGroup.setValue(NRGroupEx::NRGROUPEX_ENABLED, DMSGroup.GetEnabled() ? _T("Y") : _T("N"));

		NRGroup.setValue(NRGroupEx::NRGROUPEX_LAST_SYNC_TS, m_pDSSyncContext->GetTimestamp());

		_bstr_t DmsNos = ConvertDsNosToDmsNos(DMSGroup.GetNOS());
		NRGroup.setValue(NRGroupEx::NRGROUPEX_GROUP_NOS, DmsNos);

		if (bSetEnabled)
			NRGroup.setValue(NRGroupEx::NRGROUPEX_ENABLED, DMSGroup.GetEnabled() ? _T("Y") : _T("N"));
		else
		{
			if (!DMSGroup.GetEnabled())
				NRGroup.setValue(NRGroupEx::NRGROUPEX_ENABLED, _T("N"));
		}
	}

	catch (CBaseException& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage((imstd::exception)e.what());
	}
	catch (long lErrorCode)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(lErrorCode);
	}
	return dwRetval;
}

void CleanupNRList(NRList* list)
{
	CJediContext jc("CMlibCommunication", "CleanupNRList");
	try
	{
		if (list != NULL)
		{
			list->clearAndDestroy();
			delete list;
		}
	}
	catch (CBaseException& e)
	{
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		jc.LogMessage((imstd::exception)e.what());
	}
	catch (long lErrorCode)
	{
		jc.LogMessage(lErrorCode);
	}
}

void CleanupNRLists(NRList* list1, NRList* list2)
{
	CleanupNRList(list1);
	CleanupNRList(list2);
}

DWORD CMlibCommunication::GetUsers(CDSUSERLIST& UserList)
{
	CJediContext jc("CMlibCommunication", "GetUsers");
	DWORD dwRetval = DSOM_SUCCESS;
	NRList* pSearchItemList = NULL;
	NRList* pResultList = NULL;

	try
	{
		long lErrorField = 0;
		long lSearchStatus = 0;
		pSearchItemList = im_new NRList;
		NRSearchItem* pSearchItem = im_new NRSearchItem(SEARCH_USERSYNCSTARTDATE, GetBeginningDosTime());
		pSearchItemList->insert((RWCollectable *)pSearchItem);
		pSearchItem = im_new NRSearchItem(SEARCH_USERSYNCENDDATE, m_pDSSyncContext->GetTimestamp());
		pSearchItemList->insert((RWCollectable *)pSearchItem);
		pSearchItem = im_new NRSearchItem(SEARCH_USERNOS, m_pDSSyncContext->GetConnection()->m_DSParameters.GetNOSType().c_str());
		pSearchItemList->insert((RWCollectable *)pSearchItem);
		pSearchItem = NULL;

		long lDbRetcode = m_pdb->SelectUserList(m_pDSSyncContext->GetConnection()->m_DMSParameters.m_strLibrary.Get().c_str(), pSearchItemList, NR_SEARCH_ALL_NOS, 99999, lErrorField, lSearchStatus, pResultList);
		if (lDbRetcode == NRC_SUCCESS)
		{
			NRUserEx* pUserEx = NULL;
			NRListIterator iter(*pResultList);
			while ((pUserEx = (NRUserEx *)iter()) != NULL)
			{
				CDSUser* pTempUser = NULL;
				if (GetDSUserFromNRUser(pUserEx, pTempUser) == DSOM_SUCCESS)
				{
					if (pTempUser != NULL)
						UserList.AddBack(pTempUser);	// UserList owns the pointer
				}
				else
				{
					// error is logged in GetDSUserFromNRUser, not much we can do but ignore it and move on
				}
			}
		}
		else
			jc.ThrowDatabaseError("SelectUserList", lDbRetcode, "Can't select users; can't proceed");

		// cleanup search item list and results list
		CleanupNRLists(pSearchItemList, pResultList);
	}

	catch (CBaseException& e)
	{
		dwRetval = DSOM_FAILURE;
		CleanupNRLists(pSearchItemList, pResultList);
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		dwRetval = DSOM_FAILURE;
		CleanupNRLists(pSearchItemList, pResultList);
		jc.LogMessage((imstd::exception)e.what());
	}
	catch (long lErrorCode)
	{
		dwRetval = DSOM_FAILURE;
		CleanupNRLists(pSearchItemList, pResultList);
		jc.LogMessage(lErrorCode);
	}

	return dwRetval;
}

DWORD CMlibCommunication::GetGroups(CDSGROUPLIST& GroupList)
{
	CJediContext jc("CMlibCommunication", "GetGroups");
	DWORD dwRetval = DSOM_SUCCESS;
	NRList* pSearchItemList = NULL;
	NRList* pResultList = NULL;

	try
	{
		long lErrorField = 0;
		long lSearchStatus = 0;
		pSearchItemList = im_new NRList;
		NRSearchItem* pSearchItem = im_new NRSearchItem(SEARCH_GROUPSYNCSTARTDATE, GetBeginningDosTime());
		pSearchItemList->insert((RWCollectable *)pSearchItem);
		pSearchItem = im_new NRSearchItem(SEARCH_GROUPSYNCENDDATE, m_pDSSyncContext->GetTimestamp());
		pSearchItemList->insert((RWCollectable *)pSearchItem);
		pSearchItem = im_new NRSearchItem(SEARCH_GROUPNOS, m_pDSSyncContext->GetConnection()->m_DSParameters.GetNOSType().c_str());
		pSearchItemList->insert((RWCollectable *)pSearchItem);
		pSearchItem = NULL;

		if (m_pdb->SelectGroupList(m_pDSSyncContext->GetConnection()->m_DMSParameters.m_strLibrary.Get().c_str(), pSearchItemList, NR_SEARCH_ALL_NOS, 99999, lErrorField, lSearchStatus, pResultList) == NRC_SUCCESS)
		{
			NRGroupEx* pGroupEx = NULL;
			NRListIterator iter(*pResultList);
			while ((pGroupEx = (NRGroupEx *)iter()) != NULL)
			{
				CDSGroup* pTempGroup = NULL;
				if (GetDSGroupFromNRGroup(pGroupEx, pTempGroup) == DSOM_SUCCESS)
				{
					if (pTempGroup != NULL)
						GroupList.AddBack(pTempGroup);	// GroupList owns the pointer
				}
				else
				{
					// error is logged in GetDSGroupFromNRGroup, ignore and move on
				}
			}
		}
		else
			jc.ThrowDatabaseError("SelectGroupList", 0, "Can't select groups; can't proceed");

		// cleanup search item list and results list
		CleanupNRLists(pSearchItemList, pResultList);
	}

	catch (CBaseException& e)
	{
		dwRetval = DSOM_FAILURE;
		CleanupNRLists(pSearchItemList, pResultList);
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		dwRetval = DSOM_FAILURE;
		CleanupNRLists(pSearchItemList, pResultList);
		jc.LogMessage((imstd::exception)e.what());
	}
	catch (long lErrorCode)
	{
		dwRetval = DSOM_FAILURE;
		CleanupNRLists(pSearchItemList, pResultList);
		jc.LogMessage(lErrorCode);
	}

	return dwRetval;
}

DWORD CMlibCommunication::GetUserBySyncId(const _bstr_t& strId, CDMSUser& DMSUser)
{
	CJediContext jc("CMlibCommunication", "GetUserBySyncId");
	DWORD dwRetval = DSOM_USERNOTFOUND;
	NRList* pSearchItemList = NULL;
	NRList* pResultList = NULL;

	try
	{
		long lErrorField = 0;
		long lSearchStatus = 0;
		pSearchItemList = im_new NRList;
		NRSearchItem* pSearchItem = im_new NRSearchItem(SEARCH_USERSYNCID, UnicodeToUTF8(strId).c_str());
		pSearchItemList->insert((RWCollectable *)pSearchItem);
		pSearchItem = NULL;

		long lDbRetcode = m_pdb->SelectUserList(m_pDSSyncContext->GetConnection()->m_DMSParameters.m_strLibrary.Get().c_str(), pSearchItemList, NR_SEARCH_ALL_NOS, 99999, lErrorField, lSearchStatus, pResultList);
		if (lDbRetcode == NRC_SUCCESS)
		{
			NRUserEx* pUserEx = NULL;
			NRListIterator iter(*pResultList);
			while ((pUserEx = (NRUserEx *)iter()) != NULL)
			{
				CDMSUser* pTempUser = NULL;
				if (GetDMSUserFromNRUser(pUserEx, pTempUser) != DSOM_SUCCESS)
				{
					// error is logged in GetDMSUserFromNRUser, ignore it here and move on
				}

				if (pTempUser != NULL)
				{
					dwRetval = DSOM_SUCCESS;

					// assign outgoing user object
					DMSUser = *pTempUser;

					// add userid/usernum to map for faster group membership processing
					_bstr_t userid = pTempUser->GetUserId();
					_bstr_t dn = pTempUser->GetDn();
					_bstr_t syncid = pTempUser->GetK1SyncId();
					int userNum = atoi(pUserEx->getValue(NRUserEx::NRUSEREX_USERNUM));
					bool addUserToMaps;
					if (AddUserToMaps(userid, syncid, dn, userNum, addUserToMaps) != DSOM_SUCCESS)
					{
						// error is logged in AddUserToMaps, ignore here and move on
					}

					// cleanup
					delete pTempUser;
				}
				else
					dwRetval = DSOM_USERNOTFOUND;
			}
		}
		else
			jc.ThrowDatabaseError("SelectUserList", lDbRetcode, MakeErrorString("Select Value (syncid)", strId));

		// cleanup search item list and results list
		CleanupNRLists(pSearchItemList, pResultList);
	}

	catch (CBaseException& e)
	{
		dwRetval = DSOM_FAILURE;
		CleanupNRLists(pSearchItemList, pResultList);
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		dwRetval = DSOM_FAILURE;
		CleanupNRLists(pSearchItemList, pResultList);
		jc.LogMessage((imstd::exception)e.what());
	}
	catch (long lErrorCode)
	{
		dwRetval = DSOM_FAILURE;
		CleanupNRLists(pSearchItemList, pResultList);
		jc.LogMessage(lErrorCode);
	}

	return dwRetval;
}

DWORD CMlibCommunication::GetUserByUserId(const _bstr_t& strId, CDMSUser& DMSUser)
{
	CJediContext jc("CMlibCommunication", "GetUserByUserId");
	DWORD dwRetval = DSOM_USERNOTFOUND;
	NRList* pSearchItemList = NULL;
	NRList* pResultList = NULL;

	try
	{
		long lErrorField = 0;
		long lSearchStatus = 0;
		pSearchItemList = new NRList;
		NRSearchItem* pSearchItem = new NRSearchItem(SEARCH_USERID, UnicodeToUTF8(strId).c_str());
		pSearchItemList->insert((RWCollectable *)pSearchItem);
		pSearchItem = NULL;

		long lDbRetcode = m_pdb->SelectUserList(m_pDSSyncContext->GetConnection()->m_DMSParameters.m_strLibrary.Get().c_str(), pSearchItemList, NR_SEARCH_ALL_NOS, 99999, lErrorField, lSearchStatus, pResultList);
		if (lDbRetcode == NRC_SUCCESS)
		{
			NRUserEx* pUserEx = NULL;
			NRListIterator iter(*pResultList);
			while ((pUserEx = (NRUserEx *)iter()) != NULL)
			{
				CDMSUser* pTempUser = NULL;
				if (GetDMSUserFromNRUser(pUserEx, pTempUser) != DSOM_SUCCESS)
				{
					// error is logged in GetDMSUserFromNRUser, ignore here and move on
				}

				if (pTempUser != NULL)
				{
					dwRetval = DSOM_SUCCESS;

					// assign outgoing user object
					DMSUser = *pTempUser;

					// add userid/usernum to map for faster group membership processing
					_bstr_t userid = pTempUser->GetUserId();
					_bstr_t syncid = pTempUser->GetK1SyncId();
					_bstr_t dn = pTempUser->GetDn();
					int userNum = atoi(pUserEx->getValue(NRUserEx::NRUSEREX_USERNUM));
					bool addUserToMaps;
					if (AddUserToMaps(userid, syncid, dn, userNum, addUserToMaps) != DSOM_SUCCESS)
					{
						// error is logged in AddUserToMaps, ignore here and move on
					}

					// cleanup
					delete pTempUser;
				}
				else
					dwRetval = DSOM_USERNOTFOUND;
			}
		}
		else
			jc.ThrowDatabaseError("SelectUserList", lDbRetcode, MakeErrorString("Select value (userid)", strId));

		// cleanup search item list and results list
		CleanupNRLists(pSearchItemList, pResultList);
	}

	catch (CBaseException& e)
	{
		dwRetval = DSOM_FAILURE;
		CleanupNRLists(pSearchItemList, pResultList);
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		dwRetval = DSOM_FAILURE;
		CleanupNRLists(pSearchItemList, pResultList);
		jc.LogMessage((imstd::exception)e.what());
	}
	catch (long lErrorCode)
	{
		dwRetval = DSOM_FAILURE;
		CleanupNRLists(pSearchItemList, pResultList);
		jc.LogMessage(lErrorCode);
	}

	return dwRetval;
}

DWORD CMlibCommunication::GetGroupBySyncId(const _bstr_t& strId, CDMSGroup& DMSGroup)
{
	CJediContext jc("CMlibCommunication", "GetGroupBySyncId");
	DWORD dwRetval = DSOM_GROUPNOTFOUND;
	NRList* pSearchItemList = NULL;
	NRList* pResultList = NULL;
	CDMSGroup* pTempGroup = NULL;

	try
	{
		long lErrorField = 0;
		long lSearchStatus = 0;
		pSearchItemList = im_new NRList;
		NRSearchItem* pSearchItem = im_new NRSearchItem(SEARCH_GROUPSYNCID, UnicodeToUTF8(strId).c_str());
		pSearchItemList->insert((RWCollectable *)pSearchItem);
		pSearchItem = NULL;

		long lDbRetcode = m_pdb->SelectGroupList(m_pDSSyncContext->GetConnection()->m_DMSParameters.m_strLibrary.Get().c_str(), pSearchItemList, NR_SEARCH_ALL_NOS, 99999, lErrorField, lSearchStatus, pResultList);
		if (lDbRetcode == NRC_SUCCESS)
		{
			NRGroupEx* pGroupEx = NULL;
			NRListIterator iter(*pResultList);
			while ((pGroupEx = (NRGroupEx *)iter()) != NULL)
			{
				pTempGroup = NULL;
				if (GetDMSGroupFromNRGroup(pGroupEx, pTempGroup) != DSOM_SUCCESS)
				{
					// error is logged in GetDMSGroupFromNRGroup, ignore and move on
				}

				if (pTempGroup != NULL)
				{
					dwRetval = DSOM_SUCCESS;

					if (AssignGroupMembershipToDSGroup(*pTempGroup) == DSOM_SUCCESS)
					{
						// assign outgoing user object
						DMSGroup = *pTempGroup;

					}
					else
						dwRetval = DSOM_FAILURE;

					// cleanup
					if (pTempGroup != NULL)
					{
						delete pTempGroup;
						pTempGroup = NULL;
					}
				}
				else
					dwRetval = DSOM_GROUPNOTFOUND;
			}
		}
		else
			jc.ThrowDatabaseError("SelectGroupList", lDbRetcode, MakeErrorString("Select value (syncid)", strId));

		// cleanup
		if (pTempGroup != NULL)
		{
			delete pTempGroup;
			pTempGroup = NULL;
		}

		// cleanup search item list and results list
		CleanupNRLists(pSearchItemList, pResultList);
	}

	catch (CBaseException& e)
	{
		dwRetval = DSOM_FAILURE;
		if (pTempGroup) { delete pTempGroup; pTempGroup = NULL; }
		CleanupNRLists(pSearchItemList, pResultList);
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		dwRetval = DSOM_FAILURE;
		if (pTempGroup) { delete pTempGroup; pTempGroup = NULL; }
		CleanupNRLists(pSearchItemList, pResultList);
		jc.LogMessage((imstd::exception)e.what());
	}
	catch (long lErrorCode)
	{
		dwRetval = DSOM_FAILURE;
		if (pTempGroup) { delete pTempGroup; pTempGroup = NULL; }
		CleanupNRLists(pSearchItemList, pResultList);
		jc.LogMessage(lErrorCode);
	}

	return dwRetval;
}

DWORD CMlibCommunication::GetGroupByGroupId(const _bstr_t& strId, CDMSGroup& DMSGroup)
{
	CJediContext jc("CMlibCommunication", "GetGroupByGroupId");
	DWORD dwRetval = DSOM_GROUPNOTFOUND;
	NRList* pSearchItemList = NULL;
	NRList* pResultList = NULL;
	CDMSGroup* pTempGroup = NULL;

	try
	{
		long lErrorField = 0;
		long lSearchStatus = 0;
		pSearchItemList = new NRList;
		NRSearchItem* pSearchItem = new NRSearchItem(SEARCH_GROUPID, UnicodeToUTF8(strId).c_str());
		pSearchItemList->insert((RWCollectable *)pSearchItem);
		pSearchItem = NULL;

		long lDbRetcode = m_pdb->SelectGroupList(m_pDSSyncContext->GetConnection()->m_DMSParameters.m_strLibrary.Get().c_str(), pSearchItemList, NR_SEARCH_ALL_NOS, 99999, lErrorField, lSearchStatus, pResultList);
		if (lDbRetcode == NRC_SUCCESS)
		{
			NRGroupEx* pGroupEx = NULL;
			NRListIterator iter(*pResultList);
			while ((pGroupEx = (NRGroupEx *)iter()) != NULL)
			{
				pTempGroup = NULL;
				if (GetDMSGroupFromNRGroup(pGroupEx, pTempGroup) != DSOM_SUCCESS)
				{
					// error is logged in GetDMSGroupFromNRGroup, ignore and move on
				}

				if (pTempGroup != NULL)
				{
					dwRetval = DSOM_SUCCESS;

					if (AssignGroupMembershipToDSGroup(*pTempGroup) == DSOM_SUCCESS)
					{
						// assign outgoing user object
						DMSGroup = *pTempGroup;
					}

					// cleanup
					if (pTempGroup != NULL)
					{
						delete pTempGroup;
						pTempGroup = NULL;
					}
				}
				else
					dwRetval = DSOM_GROUPNOTFOUND;
			}
		}
		else
			jc.ThrowDatabaseError("SelectGroupList", lDbRetcode, MakeErrorString("Select value (groupid)", strId));

		// cleanup
		if (pTempGroup != NULL)
		{
			delete pTempGroup;
			pTempGroup = NULL;
		}

		// cleanup search item list and results list
		CleanupNRLists(pSearchItemList, pResultList);
	}

	catch (CBaseException& e)
	{
		dwRetval = DSOM_FAILURE;
		if (pTempGroup) { delete pTempGroup; pTempGroup = NULL; }
		CleanupNRLists(pSearchItemList, pResultList);
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		dwRetval = DSOM_FAILURE;
		if (pTempGroup) { delete pTempGroup; pTempGroup = NULL; }
		CleanupNRLists(pSearchItemList, pResultList);
		jc.LogMessage((imstd::exception)e.what());
	}
	catch (long lErrorCode)
	{
		dwRetval = DSOM_FAILURE;
		if (pTempGroup) { delete pTempGroup; pTempGroup = NULL; }
		CleanupNRLists(pSearchItemList, pResultList);
		jc.LogMessage(lErrorCode);
	}

	return dwRetval;
}

DWORD CMlibCommunication::AssignGroupMembershipToDSGroup(CDMSGroup& DMSGroup)
{
	CJediContext jc("CMlibCommunication", "AssignGroupMembershipToDSGroup");
	DWORD dwRetval = DSOM_SUCCESS;
	CDSUser* pTempUser = NULL;
	NRList* pResultList = NULL;

	try
	{
		bool bConversion = false;
		IM::CDSSyncSvc_DSParameters::LDAPTYPE lDmsNos;
		try
		{
			lDmsNos = ConvertDmsNosToDsNos(DMSGroup.GetNOS());
			bConversion = true;
		}
		catch (CGenericException& e)
		{
			bConversion = false;
			//e.GetErrorString();
			//LogMsg( LOG_ERROR, _T( "Skipping group membership '%s' because the group NOS type %i is unsupported" ), (LPCTSTR) DMSGroup.GetGroupId(), (int)DMSGroup.GetNOS() );
		}

		// we can't process the group b/c its NOS type (virtual or external, etc) is not supported for Sync
		// but return DSOM_SUCCESS since this error condition will be handled later (in DS_To_Db_Groups)
		if (!bConversion)
			return DSOM_SUCCESS;

		long lDbRetcode = m_pdb->GetUsersInGroup(m_pDSSyncContext->GetConnection()->m_DMSParameters.m_strLibrary.Get().c_str(), UnicodeToUTF8(DMSGroup.GetGroupId()), pResultList);
		if (lDbRetcode == NRC_SUCCESS)
		{
			NRUserEx* pUserEx = NULL;
			NRListIterator iter(*pResultList);
			while ((pUserEx = (NRUserEx *)iter()) != NULL)
			{
				pTempUser = NULL;
				if (GetDSUserFromNRUser(pUserEx, pTempUser) != DSOM_SUCCESS)
				{
					// error is logged in GetDSUserFromNRUser, not much we can do but ignore the error and move on
				}

				int userNum = atoi(pUserEx->getValue(NRUserEx::NRUSEREX_USERNUM));

				if (pTempUser != NULL)
				{
					if (bConversion)
					{
						if (lDmsNos == IM::CDSSyncSvc_DSParameters::Novell)
						{
							DMSGroup.AddMember(_wcsupr(pTempUser->GetUserId()));
						}
						else
						{
							_bstr_t dn = pTempUser->GetDn();
							_bstr_t userid = pTempUser->GetUserId();
							_bstr_t syncid = pTempUser->GetK1SyncId();
							bool addUserToMaps;
							if (AddUserToMaps(userid, syncid, dn, userNum, addUserToMaps) != DSOM_SUCCESS) // this only adds to map if value hasn't yet been added
							{
								// error is logged in AddUserToMaps, ignore it here and move on
							}

							if (dn.length() > 0)
								DMSGroup.AddMember(dn);
							else if (userid.length() > 0)
								DMSGroup.AddMember(userid);
							else if (syncid.length() > 0)
								DMSGroup.AddMember(syncid);
						}
					}

					// cleanup
					delete pTempUser;
					pTempUser = NULL;
				}
			}
		}
		else
			jc.ThrowDatabaseError("GetUsersInGroup", lDbRetcode, MakeErrorString("Select value (groupid)", DMSGroup.GetGroupId()));

		// cleanup results list
		CleanupNRList(pResultList);
	}

	catch (CBaseException& e)
	{
		dwRetval = DSOM_FAILURE;
		if (pTempUser) { delete pTempUser; pTempUser = NULL; }
		CleanupNRList(pResultList);
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		dwRetval = DSOM_FAILURE;
		if (pTempUser) { delete pTempUser; pTempUser = NULL; }
		CleanupNRList(pResultList);
		jc.LogMessage((imstd::exception)e.what());
	}
	catch (long lErrorCode)
	{
		dwRetval = DSOM_FAILURE;
		if (pTempUser) { delete pTempUser; pTempUser = NULL; }
		CleanupNRList(pResultList);
		jc.LogMessage(lErrorCode);
	}
	return dwRetval;
}

DWORD CMlibCommunication::UserExistsInMap(USERNUMMAP& map, const _bstr_t& id, bool& result)
{
	CJediContext jc("CMlibCommunication", "UserExistsInMap");
	DWORD dwRetval = DSOM_SUCCESS;
	result = true;
	try
	{
		USERNUMMAP::const_iterator iter = map.find(_wcsupr(id));
		result = iter != map.end();
	}
	catch (CBaseException& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch (long lErrorCode)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(lErrorCode);
	}
	return dwRetval;
}

DWORD CMlibCommunication::GetUserInMap(USERNUMMAP& map, const _bstr_t& id, long& userNum, bool& result)
{
	CJediContext jc("CMlibCommunication", "GetUserInMap");
	DWORD dwRetval = DSOM_SUCCESS;
	result = true;

	try
	{
		userNum = 0;
		USERNUMMAP::const_iterator iter = map.find(_wcsupr(id));

		if (iter == map.end())
			result = false;
		else
			userNum = (int)iter->second;
	}
	catch (CBaseException& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch (long lErrorCode)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(lErrorCode);
	}
	return dwRetval;

}

DWORD CMlibCommunication::AddUserToMap(USERNUMMAP& map, const _bstr_t& id, long userNum, bool& result)
{
	CJediContext jc("CMlibCommunication", "AddUserToMap");
	DWORD dwRetval = DSOM_SUCCESS;
	result = true;

	try
	{
		if (userNum == 0)
			result = false;
		else
		{
			bool userExistsInMap;
			if (UserExistsInMap(map, id, userExistsInMap) == DSOM_SUCCESS)
			{
				if (!userExistsInMap)
				{
					map.insert(USERNUMMAP::value_type(_wcsupr(id), userNum));
					result = true;
				}
				else
					result = false;
			}
			else
				dwRetval = DSOM_FAILURE;
		}
	}
	catch (CBaseException& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch (long lErrorCode)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(lErrorCode);
	}
	return dwRetval;
}

DWORD CMlibCommunication::UserExistsInMap(USERUSERMAP& map, const _bstr_t& id, bool& result)
{
	CJediContext jc("CMlibCommunication", "UserExistsInMap");
	DWORD dwRetval = DSOM_SUCCESS;
	result = true;

	try
	{
		USERUSERMAP::const_iterator iter = map.find(_wcsupr(id));
		result = iter != map.end();
	}
	catch (CBaseException& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch (long lErrorCode)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(lErrorCode);
	}
	return dwRetval;
}

DWORD CMlibCommunication::GetUserInMap(USERUSERMAP& map, const _bstr_t& id, _bstr_t& id2, bool& result)
{
	CJediContext jc("CMlibCommunication", "GetUserInMap");
	DWORD dwRetval = DSOM_SUCCESS;
	result = true;

	try
	{
		id2 = _T("");

		USERUSERMAP::const_iterator iter = map.find(_wcsupr(id));

		if (iter == map.end())
			result = false;
		else
		{
			id2 = (_bstr_t)iter->second;
			result = true;
		}
	}
	catch (CBaseException& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch (long lErrorCode)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(lErrorCode);
	}
	return dwRetval;
}

DWORD CMlibCommunication::AddUserToMap(USERUSERMAP& map, const _bstr_t& id, const _bstr_t& id2, bool& result)
{
	CJediContext jc("CMlibCommunication", "AddUserToMap");
	DWORD dwRetval = DSOM_SUCCESS;
	result = true;

	try
	{
		if (id.length() == 0 || id2.length() == 0)
			result = false;
		else
		{
			bool userExistsInMap;
			if (UserExistsInMap(map, id, userExistsInMap) == DSOM_SUCCESS)
			{
				if (!userExistsInMap)
				{
					map.insert(USERUSERMAP::value_type(_wcsupr(id), _wcsupr(id2)));
					result = true;
				}
				else
					result = false;
			}
			else
				dwRetval = DSOM_FAILURE;
		}
	}
	catch (CBaseException& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch (long lErrorCode)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(lErrorCode);
	}
	return dwRetval;
}

DWORD CMlibCommunication::AddUserToMaps(const _bstr_t& userId, const _bstr_t& syncId, const _bstr_t& distName, long userNum, bool& result)
{
	CJediContext jc("CMlibCommunication", "AddUserToMaps");
	DWORD dwRetval = DSOM_SUCCESS;
	result = false;	// indicates if user was added to any of the 3 usernum maps

	try
	{
		int useridlen = userId.length();
		int syncidlen = syncId.length();
		int dnlen = distName.length();

		bool addUserToMap;
		if (userNum != 0)
		{
			if (useridlen > 0)
			{
				if (AddUserToMap(m_mapUserIdToUserNum, userId, userNum, addUserToMap) == DSOM_SUCCESS)
					result |= addUserToMap;
				else
					dwRetval = DSOM_FAILURE;
			}

			if (syncidlen > 0)
			{
				if (AddUserToMap(m_mapSyncIdToUserNum, syncId, userNum, addUserToMap) == DSOM_SUCCESS)
					result |= addUserToMap;
				else
					dwRetval = DSOM_FAILURE;
			}

			if (dnlen > 0)
			{
				if (AddUserToMap(m_mapDistNameToUserNum, distName, userNum, addUserToMap) == DSOM_SUCCESS)
					result |= addUserToMap;
				else
					dwRetval = DSOM_FAILURE;
			}
		}
		else
			result = false;

		if (useridlen > 0 && syncidlen > 0)
		{
			if (AddUserToMap(m_mapUserIdToSyncId, userId, syncId, addUserToMap) != DSOM_SUCCESS)
				dwRetval = DSOM_FAILURE;
			if (AddUserToMap(m_SyncIdToUserId, syncId, userId, addUserToMap) != DSOM_SUCCESS)
				dwRetval = DSOM_FAILURE;
		}

		if (useridlen > 0 && dnlen > 0)
		{
			if (AddUserToMap(m_mapUserIdToDn, userId, distName, addUserToMap) != DSOM_SUCCESS)
				dwRetval = DSOM_FAILURE;
			if (AddUserToMap(m_mapDnToUserId, distName, userId, addUserToMap) != DSOM_SUCCESS)
				dwRetval = DSOM_FAILURE;
		}

		if (dnlen > 0 && syncidlen > 0)
		{
			if (AddUserToMap(m_mapDnToSyncId, distName, syncId, addUserToMap) != DSOM_SUCCESS)
				dwRetval = DSOM_FAILURE;
			if (AddUserToMap(m_SyncIdToDn, syncId, distName, addUserToMap) != DSOM_SUCCESS)
				dwRetval = DSOM_FAILURE;
		}
	}
	catch (CBaseException& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch (long lErrorCode)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(lErrorCode);
	}
	return dwRetval;
}

DWORD CMlibCommunication::GetUserFromMaps(const _bstr_t& anyId, long& userNum, bool& result)
{
	CJediContext jc("CMlibCommunication", "GetUserFromMaps");
	DWORD dwRetval = DSOM_SUCCESS;
	result = false;

	try
	{
		userNum = 0;

		if (GetUserInMap(m_mapUserIdToUserNum, anyId, userNum, result) != DSOM_SUCCESS)
			dwRetval = DSOM_FAILURE;
		if (result) return dwRetval;	// if found, return immediately

		if (GetUserInMap(m_mapUserIdToUserNum, anyId, userNum, result) != DSOM_SUCCESS)
			dwRetval = DSOM_FAILURE;
		if (result) return dwRetval;	// if found, return immediately

		if (GetUserInMap(m_mapSyncIdToUserNum, anyId, userNum, result) != DSOM_SUCCESS)
			dwRetval = DSOM_FAILURE;
		if (result) return dwRetval;	// if found, return immediately

		if (GetUserInMap(m_mapDistNameToUserNum, anyId, userNum, result) != DSOM_SUCCESS)
			dwRetval = DSOM_FAILURE;
		if (result) return dwRetval;	// if found, return immediately

		_bstr_t id2 = _T("");
		bool temp;
		if (GetUserInMap(m_mapUserIdToSyncId, anyId, id2, temp) == DSOM_SUCCESS)
		{
			if (temp)	// if found above, then id2 is populated and we can look in second map
			{
				if (GetUserInMap(m_mapSyncIdToUserNum, id2, userNum, result) != DSOM_SUCCESS)
					dwRetval = DSOM_FAILURE;
			}
		}
		else
			dwRetval = DSOM_FAILURE;
		if (result) return dwRetval;	// if found, return immediately

		id2 = _T("");
		if (GetUserInMap(m_mapUserIdToDn, anyId, id2, temp) == DSOM_SUCCESS)
		{
			if (temp)	// if found above, then id2 is populated and we can look in second map
			{
				if (GetUserInMap(m_mapDistNameToUserNum, id2, userNum, result) != DSOM_SUCCESS)
					dwRetval = DSOM_FAILURE;
			}
		}
		else
			dwRetval = DSOM_FAILURE;
		if (result) return dwRetval;	// if found, return immediately

		id2 = _T("");
		if (GetUserInMap(m_mapDnToSyncId, anyId, id2, temp) == DSOM_SUCCESS)
		{
			if (temp)	// if found above, then id2 is populated and we can look in second map
			{
				if (GetUserInMap(m_mapSyncIdToUserNum, id2, userNum, result) != DSOM_SUCCESS)
					dwRetval = DSOM_FAILURE;
			}
		}
		else
			dwRetval = DSOM_FAILURE;
		if (result) return dwRetval;	// if found, return immediately

		id2 = _T("");
		if (GetUserInMap(m_mapDnToUserId, anyId, id2, temp) == DSOM_SUCCESS)
		{
			if (temp)	// if found above, then id2 is populated and we can look in second map
			{
				if (GetUserInMap(m_mapUserIdToUserNum, id2, userNum, result) != DSOM_SUCCESS)
					dwRetval = DSOM_FAILURE;
			}
		}
		else
			dwRetval = DSOM_FAILURE;
		if (result) return dwRetval;	// if found, return immediately

		id2 = _T("");
		if (GetUserInMap(m_SyncIdToUserId, anyId, id2, temp) == DSOM_SUCCESS)
		{
			if (temp)	// if found above, then id2 is populated and we can look in second map
			{
				if (GetUserInMap(m_mapUserIdToUserNum, id2, userNum, result) != DSOM_SUCCESS)
					dwRetval = DSOM_FAILURE;
			}
		}
		else
			dwRetval = DSOM_FAILURE;
		if (result) return dwRetval;	// if found, return immediately

		id2 = _T("");
		if (GetUserInMap(m_SyncIdToDn, anyId, id2, temp) == DSOM_SUCCESS)
		{
			if (temp)	// if found above, then id2 is populated and we can look in second map
			{
				if (GetUserInMap(m_mapDistNameToUserNum, id2, userNum, result) != DSOM_SUCCESS)
					dwRetval = DSOM_FAILURE;
			}
		}
		else
			dwRetval = DSOM_FAILURE;
		if (result) return dwRetval;	// if found, return immediately
	}
	catch (CBaseException& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch (long lErrorCode)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(lErrorCode);
	}
	return dwRetval;
}

DWORD CMlibCommunication::InAButNotB(ObjectContainers::CUniqueIntVector& vA, ObjectContainers::CUniqueIntVector& vB, ObjectContainers::CUniqueIntVector& vRes, bool& result)
{
	CJediContext jc("CMlibCommunication", "InAButNotB");
	DWORD dwRetval = DSOM_SUCCESS;
	result = true;

	try
	{
		vRes.RemoveAll();

		for (ObjectContainers::CUniqueIntVector::Const_Iterator iterA = vA.Begin(); iterA != vA.End(); iterA++)
		{
			if (!vB.IsMember(*iterA))
			{
				result = false;
				vRes.AddBack(*iterA);
			}
		}
	}
	catch (CBaseException& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch (long lErrorCode)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(lErrorCode);
	}
	return dwRetval;
}

DWORD CMlibCommunication::GetGroupMembershipForDSGroup(CDSGroup& DSGroup, ObjectContainers::CUniqueIntVector& vMems, bool& result)
{
	CJediContext jc("CMlibCommunication", "GetGroupMembershipForDSGroup");
	DWORD dwRetval = DSOM_SUCCESS;
	result = true;	// result of false means 1 or more group members weren't added b/c we couldn't obtain userNum

	try
	{
		vMems.RemoveAll();

		ObjectContainers::CUniqueBstrVector vecDNs = DSGroup.GetMemberDNs();
		for (ObjectContainers::CUniqueBstrVector::Const_Iterator iter = vecDNs.Begin(); iter != vecDNs.End(); iter++)
		{
			//format: userid#$#syncid#$#dn#$#
			_bstr_t compositedId = *iter;

			if (compositedId.length() == 0)
				continue;

			_bstr_t strUserId(L""), strSyncId(L""), strDn(L"");

			// if compositedId isn't of the format above,
			// then strUserId will be set to the entire string
			// and strSyncId and strDn will be blank
			CDSInterface::DecodeCompositedIdentifier(compositedId, strUserId, strSyncId, strDn);

			LogMsg(LOG_INFO, _T("User ID '%s' Group ID '%s'"), UnicodeToUTF8(strUserId).c_str(), UnicodeToUTF8(DSGroup.GetGroupId()).c_str());

			long userNum = 0;

			bool found1 = false;
			if (strUserId.length() > 0)
			{
				if (GetUserFromMaps(strUserId, userNum, found1) != DSOM_SUCCESS)
				{
					// error is logged in GetUserFromMaps, not much we can do but ignore this error
				}
			}

			bool found2 = false;
			if (userNum == 0 && strSyncId.length() > 0)
			{
				if (GetUserFromMaps(strSyncId, userNum, found2) != DSOM_SUCCESS)
				{
					// error is logged in GetUserFromMaps, not much we can do but ignore this error
				}
			}

			bool found3 = false;
			if (userNum == 0 && strDn.length() > 0)
			{
				if (GetUserFromMaps(strDn, userNum, found3) != DSOM_SUCCESS)
				{
					// error is logged in GetUserFromMaps, not much we can do but ignore this error
				}
			}

			// can't find it in maps, get it from database
			if (userNum == 0)	// or: !found1 && !found2 && !found3
			{
				if (strUserId.length() > 0)
				{
					if (GetUserNum(strUserId, userNum) != DSOM_SUCCESS)
					{
						// error is logged in GetUserNum, not much we can do but ignore this error
					}
				}

				if (userNum == 0 && strSyncId.length() > 0)
				{
					if (GetUserNumBySyncId(strSyncId, userNum) != DSOM_SUCCESS)
					{
						// error is logged in GetUserNumBySyncId, not much we can do but ignore this error
					}
				}

				if (userNum == 0)
				{
					// all attempts to get userNum have failed
					LogMsg(LOG_ERROR, _T("Unable to get usernum for user '%s' to add to group '%s'"), UnicodeToUTF8(strUserId).c_str(), UnicodeToUTF8(DSGroup.GetGroupId()).c_str());
					result = false;
				}
				else
				{
					bool addUserToMaps;
					if (AddUserToMaps(strUserId, strSyncId, strDn, userNum, addUserToMaps) != DSOM_SUCCESS)
					{
						// error is logged in AddUserToMaps, not much we can do but ignore this error
					}
				}
			}

			// if we've finally found userNum, add it
			if (userNum != 0)	// or: found1 || found2 || found3
				vMems.AddBack(userNum);
		}
	}
	catch (CBaseException& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch (long lErrorCode)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(lErrorCode);
	}
	return dwRetval;
}

// DS is group1
// DMS is group2
DWORD CMlibCommunication::CompareGroupMems(CDSGroup& dsGroup, CDSGroup& dmsGroup, bool& result)
{
	CJediContext jc("CMlibCommunication", "CompareGroupMems");
	DWORD dwRetval = DSOM_SUCCESS;
	result = true;

	try
	{
		bool getGroupMembership = true;	// false indicates 1 or more group members weren't added b/c their userNum's couldn't be obtained
		if (GetGroupMembershipForDSGroup(dsGroup, dsGroup.dsMems, getGroupMembership) != DSOM_SUCCESS)
		{
			return DSOM_FAILURE;	// can't continue
		}

		getGroupMembership = true;
		if (GetGroupMembershipForDSGroup(dmsGroup, dsGroup.dmsMems, getGroupMembership) != DSOM_SUCCESS)
		{
			return DSOM_FAILURE;	// can't continue
		}

		bool inAButNotB = true;
		if (InAButNotB(dsGroup.dsMems, dsGroup.dmsMems, dsGroup.InDsNotDms, inAButNotB) == DSOM_SUCCESS)
		{
			if (!inAButNotB)
			{
				result = false;
				_bstr_t desc;
				if (MemErrorMsg(dsGroup.InDsNotDms, desc) == DSOM_SUCCESS)
					LogMsg(LOG_DEBUG, _T("DS Group '%s' has members '%s' not in DMS Group '%s'"), UnicodeToUTF8(dsGroup.GetGroupId()).c_str(), UnicodeToUTF8(desc).c_str(), UnicodeToUTF8(dmsGroup.GetGroupId()).c_str());
				else
					LogMsg(LOG_DEBUG, _T("DS Group '%s' has members not in DMS Group '%s'"), UnicodeToUTF8(dsGroup.GetGroupId()).c_str(), UnicodeToUTF8(dmsGroup.GetGroupId()).c_str());
			}
		}
		else
		{
			return DSOM_FAILURE;	// can't continue
		}

		inAButNotB = true;
		if (InAButNotB(dsGroup.dmsMems, dsGroup.dsMems, dsGroup.InDmsNotDs, inAButNotB) == DSOM_SUCCESS)
		{
			if (!inAButNotB)
			{
				result = false;
				_bstr_t desc;
				if (MemErrorMsg(dsGroup.InDmsNotDs, desc) == DSOM_SUCCESS)
					LogMsg(LOG_DEBUG, _T("DMS Group '%s' has members '%s' not in DS Group '%s'"), UnicodeToUTF8(dmsGroup.GetGroupId()).c_str(), UnicodeToUTF8(desc).c_str(), UnicodeToUTF8(dsGroup.GetGroupId()).c_str());
				else
					LogMsg(LOG_DEBUG, _T("DMS Group '%s' has members not in DS Group '%s'"), UnicodeToUTF8(dmsGroup.GetGroupId()).c_str(), UnicodeToUTF8(dsGroup.GetGroupId()).c_str());
			}
		}
		else
		{
			return DSOM_FAILURE;	// can't continue
		}

		dsGroup.bMemberVectorsSet = true;
	}
	catch (CBaseException& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch (long lErrorCode)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(lErrorCode);
	}
	return dwRetval;
}

DWORD CMlibCommunication::ResolvePrimaryGroupIDMembership(CDSGroup* pDSGroup)
{
	CJediContext jc("CMlibCommunication", "ResolvePrimaryGroupIDMembership");
	DWORD dwRetval = DSOM_SUCCESS;

	try
	{
		_bstr_t groupObjectSID = pDSGroup->GetObjectSID();
		if (groupObjectSID.length() > 0)
		{
			// Iterate all users (objectGUID/syncid values) that have this group as the primaryGroupID
			for (ObjectContainers::CUniqueBstrVector::Const_Iterator iter = g_SidMap.Get(groupObjectSID).Begin(); iter != g_SidMap.Get(groupObjectSID).End(); iter++)
			{
				// The string in *iter is a composited value:
				//format: userid#$#syncid#$#dn#$#
				pDSGroup->AddMember(*iter);

				// this will be parsed later when CompareGroupMems() calls GetGroupMembershipForDSGroup() during group processing
			}
		}
	}
	catch (CBaseException& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch (long lErrorCode)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(lErrorCode);
	}
	return dwRetval;
}


DWORD CMlibCommunication::MemErrorMsg(ObjectContainers::CUniqueIntVector& v, _bstr_t& output)
{
	CJediContext jc("CMlibCommunication", "ResolvePrimaryGroupIDMembership");
	DWORD dwRetval = DSOM_SUCCESS;
	output = _T("");

	try
	{
		for (ObjectContainers::CUniqueIntVector::Const_Iterator iter = v.Begin(); iter != v.End(); iter++)
		{
			wchar_t szVal[16];
			memset(szVal, 0, 16 * sizeof(wchar_t));

			long lUserNum = *iter;

			_itow(lUserNum, szVal, 10);

			if (output.length() != 0)
				output += L",";
			output += szVal;
		}
	}
	catch (CBaseException& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch (long lErrorCode)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(lErrorCode);
	}
	return dwRetval;
}

DWORD CMlibCommunication::InsertUser(const CDSUser& DSUser)
{
	CJediContext jc("CMlibCommunication", "InsertUser");
	DWORD dwRetval = DSOM_SUCCESS;

	try
	{
		RWCString id = UnicodeToUTF8(DSUser.GetUserId()).c_str();
		RWCString invalidChars = "";
		CheckIdForInvalidCharacters(id, invalidChars);
		if (invalidChars.length() > 0)
		{
			LogMsg(LOG_ERROR, _T("CMlibCommunication::InsertUser() User ID '%s' has invalid character(s): '%s'"), UnicodeToUTF8(DSUser.GetUserId()).c_str(), (LPCTSTR)invalidChars);
			return DSOM_FAILURE;
		}

		NRUserEx NRUser;
		if (SetNRUserFromDSUser(NRUser, DSUser, true, true) == DSOM_SUCCESS)
		{
			long lUserNum = 0;
			long lDbRetcode = m_pdb->InsertUser(m_pDSSyncContext->GetConnection()->m_DMSParameters.m_strLibrary.Get().c_str(), &NRUser, lUserNum);
			if (lDbRetcode != NRC_SUCCESS)
				jc.ThrowDatabaseError("InsertUser", lDbRetcode, MakeErrorString("User Dn", DSUser.GetDn(), "UserID", DSUser.GetUserId(), "User Name", DSUser.GetName()));
		}
		else
		{
			dwRetval = DSOM_FAILURE;
		}
	}

	catch (CBaseException& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch (long lErrorCode)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(lErrorCode);
	}
	return dwRetval;
}

DWORD CMlibCommunication::InsertGroup(const CDSGroup& DSGroup)
{
	CJediContext jc("CMlibCommunication", "InsertGroup");
	DWORD dwRetval = DSOM_SUCCESS;

	try
	{
		/*
		RWCString id = UnicodeToUTF8(DSGroup.GetGroupId()).c_str();
		RWCString invalidChars = _T( "" );
		CheckIdForInvalidCharacters( id, invalidChars );
		if( invalidChars.length() > 0 )
		{
		// for groups, spaces are allowed (but not for users)
		if( strcmpi( invalidChars, "White Space" ) != 0 )
		{
		LogMsg( LOG_ERROR, _T( "CMlibCommunication::InsertGroup() Group ID '%s' has invalid character(s): '%s'" ), ( LPCTSTR ) DSGroup.GetGroupId(), ( LPCTSTR ) invalidChars );
		return DSOM_FAILURE;
		}
		}
		*/

		NRGroupEx NRGroup;
		if (SetNRGroupFromDSGroup(NRGroup, DSGroup, true) == DSOM_SUCCESS)
		{
			unsigned long ulGroupNum = 0;
			long lDbRetcode = m_pdb->InsertGroup(m_pDSSyncContext->GetConnection()->m_DMSParameters.m_strLibrary.Get().c_str(), &NRGroup, ulGroupNum);
			if (lDbRetcode != NRC_SUCCESS)
				jc.ThrowDatabaseError("InsertGroup", lDbRetcode, DSGroup.GetDn());
			else
			{
				lDbRetcode = SetGroupMembership((long)ulGroupNum, DSGroup);
				if (lDbRetcode != DSOM_SUCCESS)
					jc.ThrowGenericError("SetGroupMembership", MakeErrorString("Group DN", DSGroup.GetDn(), "GroupID", DSGroup.GetGroupId(), "Group Name", DSGroup.GetName()));
			}
		}
		else
		{
			dwRetval = DSOM_FAILURE;
		}
	}

	catch (CBaseException& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch (long lErrorCode)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(lErrorCode);
	}
	return dwRetval;
}

DWORD CMlibCommunication::UpdateUser(const CDSUser& DSUser)
{
	CJediContext jc("CMlibCommunication", "UpdateUser");
	DWORD dwRetval = DSOM_SUCCESS;
	NRList* pSearchItemList = NULL;
	NRList* pResultList = NULL;

	try
	{
		long lErrorField = 0;
		long lSearchStatus = 0;
		pSearchItemList = im_new NRList;
		NRSearchItem* pSearchItem = im_new NRSearchItem(SEARCH_USERSYNCID, UnicodeToUTF8(DSUser.GetK1SyncId()));
		pSearchItemList->insert((RWCollectable *)pSearchItem);
		pSearchItem = NULL;

		_bstr_t strErr = MakeErrorString("Select value (syncid)", DSUser.GetK1SyncId(), "User ID", DSUser.GetUserId(), "User Name", DSUser.GetName());

		long lDbRetcode = m_pdb->SelectUserList(m_pDSSyncContext->GetConnection()->m_DMSParameters.m_strLibrary.Get().c_str(), pSearchItemList, NR_SEARCH_ALL_NOS, 5000, lErrorField, lSearchStatus, pResultList);
		if (lDbRetcode == NRC_SUCCESS)
		{
			NRUserEx* pUserEx = NULL;
			NRListIterator iter(*pResultList);
			while ((pUserEx = (NRUserEx *)iter()) != NULL)
			{
				// update NRUserEx fields with new values
				if (SetNRUserFromDSUser(*pUserEx, DSUser, false, false) == DSOM_SUCCESS)
				{
					lDbRetcode = m_pdb->UpdateUser(m_pDSSyncContext->GetConnection()->m_DMSParameters.m_strLibrary.Get().c_str(), pUserEx);
					if (lDbRetcode != NRC_SUCCESS)
						jc.ThrowDatabaseError("UpdateUser", lDbRetcode, strErr);
				}
				else
				{
					dwRetval = DSOM_FAILURE;
				}
			}
		}
		else
			jc.ThrowDatabaseError("SelectUserList", lDbRetcode, strErr);

		// cleanup search item list and results list
		CleanupNRLists(pSearchItemList, pResultList);
	}
	catch (CBaseException& e)
	{
		dwRetval = DSOM_FAILURE;
		CleanupNRLists(pSearchItemList, pResultList);
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		dwRetval = DSOM_FAILURE;
		CleanupNRLists(pSearchItemList, pResultList);
		jc.LogMessage(e);
	}
	catch (long lErrorCode)
	{
		dwRetval = DSOM_FAILURE;
		CleanupNRLists(pSearchItemList, pResultList);
		jc.LogMessage(lErrorCode);
	}
	return dwRetval;
}

DWORD CMlibCommunication::MigrateUser(const CDSUser& DSUser, CDMSUser& dmsUser)
{
	CJediContext jc("CMlibCommunication", "MigrateUser");
	DWORD dwRetval = DSOM_SUCCESS;
	NRList* pSearchItemList = NULL;
	NRList* pResultList = NULL;

	try
	{
		long lErrorField = 0;
		long lSearchStatus = 0;
		pSearchItemList = im_new NRList;
		NRSearchItem* pSearchItem = im_new NRSearchItem(SEARCH_USERID, UnicodeToUTF8(DSUser.GetUserId()).c_str());
		pSearchItemList->insert((RWCollectable *)pSearchItem);
		pSearchItem = NULL;

		_bstr_t strErr = MakeErrorString("Select value (userid)", DSUser.GetUserId(), "User Name", DSUser.GetName());

		long lDbRetcode = m_pdb->SelectUserList(m_pDSSyncContext->GetConnection()->m_DMSParameters.m_strLibrary.Get().c_str(), pSearchItemList, NR_SEARCH_ALL_NOS, 5000, lErrorField, lSearchStatus, pResultList);
		if (lDbRetcode == NRC_SUCCESS)
		{
			NRUserEx* pUserEx = NULL;
			NRListIterator iter(*pResultList);
			while ((pUserEx = (NRUserEx *)iter()) != NULL)
			{
				// update NRUserEx fields with new values
				if (SetNRUserFromDSUser(*pUserEx, DSUser, false, false) == DSOM_SUCCESS)
				{
					lDbRetcode = m_pdb->UpdateUser(m_pDSSyncContext->GetConnection()->m_DMSParameters.m_strLibrary.Get().c_str(), pUserEx);
					if (lDbRetcode != NRC_SUCCESS)
						jc.ThrowDatabaseError("UpdateUser", lDbRetcode, strErr);
				}
				else
				{
					dwRetval = DSOM_FAILURE;
				}
			}
		}
		else
			jc.ThrowDatabaseError("SelectUserList", lDbRetcode, strErr);

		// cleanup search item list and results list
		CleanupNRLists(pSearchItemList, pResultList);
	}
	catch (CBaseException& e)
	{
		dwRetval = DSOM_FAILURE;
		CleanupNRLists(pSearchItemList, pResultList);
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		dwRetval = DSOM_FAILURE;
		CleanupNRLists(pSearchItemList, pResultList);
		jc.LogMessage(e);
	}
	catch (long lErrorCode)
	{
		dwRetval = DSOM_FAILURE;
		CleanupNRLists(pSearchItemList, pResultList);
		jc.LogMessage(lErrorCode);
	}
	return dwRetval;
}

// note that this function searches on userid and not sync_id
DWORD CMlibCommunication::GetUserNum(const _bstr_t& strUserId, long& lUserNum)
{
	CJediContext jc("CMlibCommunication", "GetUserNum");
	DWORD dwRetval = DSOM_SUCCESS;
	lUserNum = 0;
	NRList* pSearchItemList = NULL;
	NRList* pResultList = NULL;

	try
	{
		long lErrorField = 0;
		long lSearchStatus = 0;
		pSearchItemList = im_new NRList;
		NRSearchItem* pSearchItem = im_new NRSearchItem(SEARCH_USERID, UnicodeToUTF8(strUserId).c_str());
		pSearchItemList->insert((RWCollectable *)pSearchItem);
		pSearchItem = NULL;

		_bstr_t strErr = MakeErrorString("Select value (userid)", strUserId);

		long lDbRetcode = m_pdb->SelectUserList(m_pDSSyncContext->GetConnection()->m_DMSParameters.m_strLibrary.Get().c_str(), pSearchItemList, NR_SEARCH_ALL_NOS, 5000, lErrorField, lSearchStatus, pResultList);
		if (lDbRetcode == NRC_SUCCESS)
		{
			NRUserEx* pUserEx = NULL;
			NRListIterator iter(*pResultList);
			while ((pUserEx = (NRUserEx *)iter()) != NULL)
			{
				const char *szUserNum = pUserEx->getValue(NRUserEx::NRUSEREX_USERNUM);
				lUserNum = _ttoi(szUserNum);
			}
		}
		else
			jc.ThrowDatabaseError("SelectUserList", lDbRetcode, strErr);

		// cleanup search item list and results list
		CleanupNRLists(pSearchItemList, pResultList);
	}
	catch (CBaseException& e)
	{
		dwRetval = DSOM_FAILURE;
		CleanupNRLists(pSearchItemList, pResultList);
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		dwRetval = DSOM_FAILURE;
		CleanupNRLists(pSearchItemList, pResultList);
		jc.LogMessage(e);
	}
	catch (long lErrorCode)
	{
		dwRetval = DSOM_FAILURE;
		CleanupNRLists(pSearchItemList, pResultList);
		jc.LogMessage(lErrorCode);
	}
	return dwRetval;

}

// note that this function searches on sync_id
DWORD CMlibCommunication::GetUserNumBySyncId(const _bstr_t& strSyncId, long& lUserNum)
{
	CJediContext jc("CMlibCommunication", "GetUserNumBySyncId");
	DWORD dwRetval = DSOM_SUCCESS;
	lUserNum = 0;
	NRList* pSearchItemList = NULL;
	NRList* pResultList = NULL;

	try
	{
		long lErrorField = 0;
		long lSearchStatus = 0;
		pSearchItemList = im_new NRList;
		NRSearchItem* pSearchItem = im_new NRSearchItem(SEARCH_USERSYNCID, UnicodeToUTF8(strSyncId).c_str());
		pSearchItemList->insert((RWCollectable *)pSearchItem);
		pSearchItem = NULL;

		_bstr_t strErr = MakeErrorString("Select value (syncid)", strSyncId);

		long lDbRetcode = m_pdb->SelectUserList(m_pDSSyncContext->GetConnection()->m_DMSParameters.m_strLibrary.Get().c_str(), pSearchItemList, NR_SEARCH_ALL_NOS, 5000, lErrorField, lSearchStatus, pResultList);
		if (lDbRetcode == NRC_SUCCESS)
		{
			NRUserEx* pUserEx = NULL;
			NRListIterator iter(*pResultList);
			while ((pUserEx = (NRUserEx *)iter()) != NULL)
			{
				const char *szUserNum = pUserEx->getValue(NRUserEx::NRUSEREX_USERNUM);
				lUserNum = _ttoi(szUserNum);
			}
		}
		else
			jc.ThrowDatabaseError("SelectUserList", lDbRetcode, strErr);

		// cleanup search item list and results list
		CleanupNRLists(pSearchItemList, pResultList);
	}
	catch (CBaseException& e)
	{
		dwRetval = DSOM_FAILURE;
		CleanupNRLists(pSearchItemList, pResultList);
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		dwRetval = DSOM_FAILURE;
		CleanupNRLists(pSearchItemList, pResultList);
		jc.LogMessage(e);
	}
	catch (long lErrorCode)
	{
		dwRetval = DSOM_FAILURE;
		CleanupNRLists(pSearchItemList, pResultList);
		jc.LogMessage(lErrorCode);
	}
	return dwRetval;

}

// note that this function searches on sync_id
DWORD CMlibCommunication::GetDNBySyncId(const _bstr_t& strSyncId, _bstr_t& strDn)
{
	CJediContext jc("CMlibCommunication", "GetDNBySyncId");
	DWORD dwRetval = DSOM_SUCCESS;
	strDn = _T("");
	NRList* pSearchItemList = NULL;
	NRList* pResultList = NULL;

	try
	{
		long lErrorField = 0;
		long lSearchStatus = 0;
		pSearchItemList = im_new NRList;
		NRSearchItem* pSearchItem = im_new NRSearchItem(SEARCH_USERSYNCID, UnicodeToUTF8(strSyncId).c_str());
		pSearchItemList->insert((RWCollectable *)pSearchItem);
		pSearchItem = NULL;

		_bstr_t strErr = MakeErrorString("Select value (syncid)", strSyncId);

		long lDbRetcode = m_pdb->SelectUserList(m_pDSSyncContext->GetConnection()->m_DMSParameters.m_strLibrary.Get().c_str(), pSearchItemList, NR_SEARCH_ALL_NOS, 5000, lErrorField, lSearchStatus, pResultList);
		if (lDbRetcode == NRC_SUCCESS)
		{
			NRUserEx* pUserEx = NULL;
			NRListIterator iter(*pResultList);
			while ((pUserEx = (NRUserEx *)iter()) != NULL)
			{
				strDn = UTF8ToUnicode(pUserEx->getValue(NRUserEx::NRUSEREX_DIST_NAME)).c_str();
			}
		}
		else
			jc.ThrowDatabaseError("SelectUserList", lDbRetcode, strErr);

		// cleanup search item list and results list
		CleanupNRLists(pSearchItemList, pResultList);
	}
	catch (CBaseException& e)
	{
		dwRetval = DSOM_FAILURE;
		CleanupNRLists(pSearchItemList, pResultList);
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		dwRetval = DSOM_FAILURE;
		CleanupNRLists(pSearchItemList, pResultList);
		jc.LogMessage(e);
	}
	catch (long lErrorCode)
	{
		dwRetval = DSOM_FAILURE;
		CleanupNRLists(pSearchItemList, pResultList);
		jc.LogMessage(lErrorCode);
	}
	return dwRetval;

}

DWORD CMlibCommunication::SetGroupMembership_AllAtOnce(const long& lGroupNum, const CDSGroup& DSGroup)
{
	CJediContext jc("CMlibCommunication", "SetGroupMembership_AllAtOnce");
	DWORD dwRetval = DSOM_SUCCESS;
	NRList* pUserNumList = NULL;

	try
	{
		// get list of user nums

		CDSGroup temp = DSGroup;
		pUserNumList = im_new NRList;

		for (CDSUSERMAP::Const_Iterator iter = temp.GetMembers().Begin(); iter != temp.GetMembers().End(); iter++)
		{
			CDSUser* pUser = iter->second;
			if (pUser != NULL)
			{
				long lUserNum = 0;
				if (GetUserNum(pUser->GetUserId(), lUserNum) == DSOM_SUCCESS)
				{
					if (lUserNum != 0)
					{
						NRLong* pNRLong = im_new NRLong(lUserNum);
						pUserNumList->insert((RWCollectable *)pNRLong);
					}
					else
					{
						LogMsg(LOG_ERROR, _T("CMlibCommunication::SetGroupMembership_AllAtOnce(), GetUserNum() for User ID '%s' returned 0; user is not in database, can't add user to group."), UnicodeToUTF8(pUser->GetUserId()).c_str());
					}
				}
			}
		}


		long lDbRetcode = m_pdb->SetGroupMembershipList(m_pDSSyncContext->GetConnection()->m_DMSParameters.m_strLibrary.Get().c_str(), lGroupNum, pUserNumList);
		if (lDbRetcode != NRC_SUCCESS)
		{
			//jc.ThrowDatabaseError( "SetGroupMembershipList", lDbRetcode, MakeErrorString( "Group ID", DSGroup.GetGroupId(), "Group Num", IntToBstr( lGroupNum ) ) );
			LogMsg(LOG_ERROR, _T("Database call SetGroupMembershipList failed, Return Code %i, %s"), lDbRetcode, (LPCTSTR)MakeErrorString("Group ID", DSGroup.GetGroupId(), "Group Num", IntToBstr(lGroupNum)));
		}

		// cleanup
		CleanupNRList(pUserNumList);
	}
	catch (CBaseException& e)
	{
		dwRetval = DSOM_FAILURE;
		CleanupNRList(pUserNumList);
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		dwRetval = DSOM_FAILURE;
		CleanupNRList(pUserNumList);
		jc.LogMessage(e);
	}
	catch (long lErrorCode)
	{
		dwRetval = DSOM_FAILURE;
		CleanupNRList(pUserNumList);
		jc.LogMessage(lErrorCode);
	}
	return dwRetval;
}

DWORD CMlibCommunication::SetGroupMembership(const long& lGroupNum, const CDSGroup& DSGroup)
{
	CJediContext jc("CMlibCommunication", "SetGroupMembership");
	DWORD dwRetval = DSOM_SUCCESS;
	NRList* pUserList = NULL;

	try
	{
		if (DSGroup.bMemberVectorsSet)
		{
			for (ObjectContainers::CUniqueIntVector::Const_Iterator iter = DSGroup.InDsNotDms.Begin(); iter != DSGroup.InDsNotDms.End(); iter++)
			{
				long lUserNum = *iter;
				long lDbRetcode = m_pdb->AddUserToGroup(m_pDSSyncContext->GetConnection()->m_DMSParameters.m_strLibrary.Get().c_str(), lGroupNum, lUserNum);
				if (lDbRetcode != NRC_SUCCESS)
				{
					//jc.ThrowDatabaseError( "AddUserToGroup", lDbRetcode, MakeErrorString( "Select value (groupnum)", IntToBstr( lGroupNum ), "Select value (usernum)", IntToBstr( lUserNum ), "Group ID", DSGroup.GetGroupId() ) );
					LogMsg(LOG_ERROR, _T("Database call AddUserToGroup failed, Return Code %i, %s"), lDbRetcode, (LPCTSTR)MakeErrorString("Select value (groupnum)", IntToBstr(lGroupNum), "Select value (usernum)", IntToBstr(lUserNum), "Group ID", DSGroup.GetGroupId()));
				}
			}

			for (ObjectContainers::CUniqueIntVector::Const_Iterator iter2 = DSGroup.InDmsNotDs.Begin(); iter2 != DSGroup.InDmsNotDs.End(); iter2++)
			{
				long lUserNum = *iter2;
				long lDbRetcode = m_pdb->RemoveUserFromGroup(m_pDSSyncContext->GetConnection()->m_DMSParameters.m_strLibrary.Get().c_str(), lGroupNum, lUserNum);
				if (lDbRetcode != NRC_SUCCESS)
				{
					//jc.ThrowDatabaseError( "RemoveUserFromGroup", lDbRetcode, MakeErrorString( "Select value (groupnum)", IntToBstr( lGroupNum ), "Select value (usernum)", IntToBstr( lUserNum ), "Group ID", DSGroup.GetGroupId() ) );
					LogMsg(LOG_ERROR, _T("Database call RemoveUserFromGroup failed, Return Code %i, %s"), lDbRetcode, (LPCTSTR)MakeErrorString("Select value (groupnum)", IntToBstr(lGroupNum), "Select value (usernum)", IntToBstr(lUserNum), "Group ID", DSGroup.GetGroupId()));
				}
			}
		}
		else
		{
			CDSGroup DSGroupTemp = DSGroup;

			if (DSGroupTemp.GetMembers().Count() == 0)
				m_pDSSyncContext->GetDSInterface()->GetGroupMembers(DSGroupTemp);

			long lDbRetcode = m_pdb->GetUsersInGroup(m_pDSSyncContext->GetConnection()->m_DMSParameters.m_strLibrary.Get().c_str(), UnicodeToUTF8(DSGroup.GetGroupId()).c_str(), pUserList);
			if (lDbRetcode != NRC_SUCCESS)
				jc.ThrowDatabaseError("GetUsersInGroup", lDbRetcode, MakeErrorString("Select value (groupid)", DSGroup.GetGroupId(), "Group Num", IntToBstr(lGroupNum)));
			else
			{
				CUSERIDNUMMAP idNumMap;

				// create a map of userid to usernum for the DMS
				NRUserEx* pUserEx = NULL;
				NRListIterator iter(*pUserList);
				while ((pUserEx = (NRUserEx *)iter()) != NULL)
				{
					const char *szUserNum = pUserEx->getValue(NRUserEx::NRUSEREX_USERNUM);
					int lUserNum = _ttoi(szUserNum);

					const char *szUserId = pUserEx->getValue(NRUserEx::NRUSEREX_USERID);
					_bstr_t strUserId = UTF8ToUnicode(szUserId).c_str();

					idNumMap.insert(CUSERIDNUMMAP::value_type(strUserId, lUserNum));
				}

				// create a map of userid for the DS
				CUSERIDNUMMAP dsIdMap;
				for (CDSUSERMAP::Const_Iterator iter3 = DSGroupTemp.GetMembers().Begin(); iter3 != DSGroupTemp.GetMembers().End(); iter3++)
				{
					CDSUser* pUser = iter3->second;
					if (pUser != NULL)
					{
						dsIdMap.insert(CUSERIDNUMMAP::value_type(pUser->GetUserId(), 0));
					}
				}

				// Remove all members that are in the DMS but not in the DS
				for (CUSERIDNUMMAP::iterator iter1 = idNumMap.begin(); iter1 != idNumMap.end(); iter1++)
				{
					_bstr_t strUserId = iter1->first;

					CUSERIDNUMMAP::iterator found = dsIdMap.find(strUserId);
					if (found == dsIdMap.end())
					{
						long lUserNum = iter1->second;
						lDbRetcode = m_pdb->RemoveUserFromGroup(m_pDSSyncContext->GetConnection()->m_DMSParameters.m_strLibrary.Get().c_str(), lGroupNum, lUserNum);
						if (lDbRetcode != NRC_SUCCESS)
						{
							//jc.ThrowDatabaseError( "RemoveUserFromGroup", lDbRetcode, MakeErrorString( "Select value (groupnum)", IntToBstr( lGroupNum ), "Select value (usernum)", IntToBstr( lUserNum ), "Group ID", DSGroup.GetGroupId(), "User ID", strUserId ) );
							LogMsg(LOG_ERROR, _T("Database call RemoveUserFromGroup failed, Return Code %i, %s"), lDbRetcode, (LPCTSTR)MakeErrorString("Select value (groupnum)", IntToBstr(lGroupNum), "Select value (usernum)", IntToBstr(lUserNum), "Group ID", DSGroup.GetGroupId(), "User ID", strUserId));
						}
					}
				}

				// Add members that are in the DS but not in the DMS
				for (CUSERIDNUMMAP::iterator iter2 = dsIdMap.begin(); iter2 != dsIdMap.end(); iter2++)
				{
					_bstr_t strUserId = iter2->first;
					CUSERIDNUMMAP::const_iterator found = idNumMap.find(strUserId);
					if (found == idNumMap.end())
					{
						long lUserNum = 0;
						if (GetUserNum(strUserId, lUserNum) == DSOM_SUCCESS)
						{
							if (lUserNum == 0)
							{
								LogMsg(LOG_ERROR, _T("CMlibCommunication::SetGroupMembership(), GetUserNum() for User ID '%s' returned 0; user is not in database, can't add user to group."), UnicodeToUTF8(strUserId).c_str());
							}
							else
							{
								lDbRetcode = m_pdb->AddUserToGroup(m_pDSSyncContext->GetConnection()->m_DMSParameters.m_strLibrary.Get().c_str(), lGroupNum, lUserNum);
								if (lDbRetcode != NRC_SUCCESS)
								{
									//jc.ThrowDatabaseError( "AddUserToGroup", lDbRetcode, MakeErrorString( "Select value (groupnum)", IntToBstr( lGroupNum ), "Select value (usernum)", IntToBstr( lUserNum ), "Group ID", DSGroup.GetGroupId(), "User ID", strUserId ) );
									LogMsg(LOG_ERROR, _T("Database call AddUserToGroup failed, Return Code %i, %s"), lDbRetcode, (LPCTSTR)MakeErrorString("Select value (groupnum)", IntToBstr(lGroupNum), "Select value (usernum)", IntToBstr(lUserNum), "Group ID", DSGroup.GetGroupId(), "User ID", strUserId));
								}
							}
						}
					}
				}
			}

			// cleanup results list
			CleanupNRList(pUserList);
		}
	}
	catch (CBaseException& e)
	{
		dwRetval = DSOM_FAILURE;
		CleanupNRList(pUserList);
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		dwRetval = DSOM_FAILURE;
		CleanupNRList(pUserList);
		jc.LogMessage(e);
	}
	catch (long lErrorCode)
	{
		dwRetval = DSOM_FAILURE;
		CleanupNRList(pUserList);
		jc.LogMessage(lErrorCode);
	}
	return dwRetval;
}

DWORD CMlibCommunication::UpdateGroup(const CDSGroup& DSGroup)
{
	CJediContext jc("CMlibCommunication", "UpdateGroup");
	DWORD dwRetval = DSOM_SUCCESS;
	NRList* pSearchItemList = NULL;
	NRList* pResultList = NULL;

	try
	{
		long lErrorField = 0;
		long lSearchStatus = 0;
		pSearchItemList = im_new NRList;
		NRSearchItem* pSearchItem = im_new NRSearchItem(SEARCH_GROUPSYNCID, UnicodeToUTF8(DSGroup.GetK1SyncId()).c_str());
		pSearchItemList->insert((RWCollectable *)pSearchItem);
		pSearchItem = NULL;

		long lDbRetcode = m_pdb->SelectGroupList(m_pDSSyncContext->GetConnection()->m_DMSParameters.m_strLibrary.Get().c_str(), pSearchItemList, NR_SEARCH_ALL_NOS, 5000, lErrorField, lSearchStatus, pResultList);
		if (lDbRetcode == NRC_SUCCESS)
		{
			NRGroupEx* pGroupEx = NULL;
			NRListIterator iter(*pResultList);
			while ((pGroupEx = (NRGroupEx *)iter()) != NULL)
			{
				const char *szGroupNum = pGroupEx->getValue(NRGroupEx::NRGROUPEX_GROUPNUM);
				long lGroupNum = _ttoi(szGroupNum);

				// update NRGroupEx fields with new values
				if (SetNRGroupFromDSGroup(*pGroupEx, DSGroup, DSGroup.GetEnabled()) == DSOM_SUCCESS)
				{
					lDbRetcode = m_pdb->UpdateGroup(m_pDSSyncContext->GetConnection()->m_DMSParameters.m_strLibrary.Get().c_str(), pGroupEx);
					if (lDbRetcode != NRC_SUCCESS)
						jc.ThrowDatabaseError("UpdateGroup", lDbRetcode, MakeErrorString("Select value (groupid)", DSGroup.GetGroupId(), "Group Name", DSGroup.GetName()));
					else
					{
						if (SetGroupMembership(lGroupNum, DSGroup) != DSOM_SUCCESS)
							jc.ThrowGenericError("SetGroupMembership", MakeErrorString("Group ID", DSGroup.GetGroupId(), "Group Name", DSGroup.GetName(), "Group Num", IntToBstr(lGroupNum)));
					}
				}
				else
				{
					dwRetval = DSOM_FAILURE;
				}
			}
		}
		else
			jc.ThrowDatabaseError("SelectGroupList", lDbRetcode, MakeErrorString("Select value (groupid)", DSGroup.GetGroupId(), "Group Name", DSGroup.GetName()));

		CleanupNRLists(pSearchItemList, pResultList);
	}
	catch (CBaseException& e)
	{
		dwRetval = DSOM_FAILURE;
		CleanupNRLists(pSearchItemList, pResultList);
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		dwRetval = DSOM_FAILURE;
		CleanupNRLists(pSearchItemList, pResultList);
		jc.LogMessage(e);
	}
	catch (long lErrorCode)
	{
		dwRetval = DSOM_FAILURE;
		CleanupNRLists(pSearchItemList, pResultList);
		jc.LogMessage(lErrorCode);
	}
	return dwRetval;
}

DWORD CMlibCommunication::MigrateGroup(const CDSGroup& DSGroup)
{
	CJediContext jc("CMlibCommunication", "MigrateGroup");
	DWORD dwRetval = DSOM_SUCCESS;
	NRList* pSearchItemList = NULL;
	NRList* pResultList = NULL;

	try
	{
		long lErrorField = 0;
		long lSearchStatus = 0;
		pSearchItemList = im_new NRList;
		NRSearchItem* pSearchItem = im_new NRSearchItem(SEARCH_GROUPID, UnicodeToUTF8(DSGroup.GetGroupId()).c_str());
		pSearchItemList->insert((RWCollectable *)pSearchItem);
		pSearchItem = NULL;

		long lDbRetcode = m_pdb->SelectGroupList(m_pDSSyncContext->GetConnection()->m_DMSParameters.m_strLibrary.Get().c_str(), pSearchItemList, NR_SEARCH_ALL_NOS, 5000, lErrorField, lSearchStatus, pResultList);
		if (lDbRetcode == NRC_SUCCESS)
		{
			NRGroupEx* pGroupEx = NULL;
			NRListIterator iter(*pResultList);
			while ((pGroupEx = (NRGroupEx *)iter()) != NULL)
			{
				const char *szGroupNum = pGroupEx->getValue(NRGroupEx::NRGROUPEX_GROUPNUM);
				long lGroupNum = _ttoi(szGroupNum);

				// update NRGroupEx fields with new values
				if (SetNRGroupFromDSGroup(*pGroupEx, DSGroup, DSGroup.GetEnabled()) == DSOM_SUCCESS)
				{
					lDbRetcode = m_pdb->UpdateGroup(m_pDSSyncContext->GetConnection()->m_DMSParameters.m_strLibrary.Get().c_str(), pGroupEx);
					if (lDbRetcode != NRC_SUCCESS)
						jc.ThrowDatabaseError("UpdateGroup", lDbRetcode, MakeErrorString("Select value (groupid)", DSGroup.GetGroupId(), "Group Name", DSGroup.GetName()));
					else
					{
						if (SetGroupMembership(lGroupNum, DSGroup) != DSOM_SUCCESS)
							jc.ThrowGenericError("SetGroupMembership", MakeErrorString("Group ID", DSGroup.GetGroupId(), "Group Name", DSGroup.GetName(), "Group Num", IntToBstr(lGroupNum)));
					}
				}
				else
				{
					dwRetval = DSOM_FAILURE;
				}
			}
		}
		else
			jc.ThrowDatabaseError("SelectGroupList", lDbRetcode, MakeErrorString("Select value (groupid)", DSGroup.GetGroupId(), "Group Name", DSGroup.GetName()));

		CleanupNRLists(pSearchItemList, pResultList);
	}
	catch (CBaseException& e)
	{
		dwRetval = DSOM_FAILURE;
		CleanupNRLists(pSearchItemList, pResultList);
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		dwRetval = DSOM_FAILURE;
		CleanupNRLists(pSearchItemList, pResultList);
		jc.LogMessage(e);
	}
	catch (long lErrorCode)
	{
		dwRetval = DSOM_FAILURE;
		CleanupNRLists(pSearchItemList, pResultList);
		jc.LogMessage(lErrorCode);
	}
	return dwRetval;
}





DWORD CMlibCommunication::UpdateUserPhoto(const CDSUser& DSUser, _bstr_t& strPhotoPath_, bool& bUserPhotoSupported)
{
	CJediContext jc("CMlibCommunication", "UpdateUserPhoto");
	DWORD dwRetval = DSOM_SUCCESS;
	bUserPhotoSupported = true;
	try
	{
		RWCString id = UnicodeToUTF8(DSUser.GetUserId()).c_str();

		long lDbRetcode = m_pdb->UpdateUserPhoto(m_pDSSyncContext->GetConnection()->m_DMSParameters.m_strLibrary.Get().c_str(), id, strPhotoPath_);
		if (lDbRetcode != NRC_SUCCESS)
		{
			bUserPhotoSupported = false;
			jc.ThrowDatabaseError("UpdateUserPhoto", lDbRetcode, MakeErrorString("User Dn", DSUser.GetDn(), "UserID", DSUser.GetUserId(), "User Name", DSUser.GetName()));
		}
		else
			bUserPhotoSupported = true;
	}

	catch (CBaseException& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch (long lErrorCode)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(lErrorCode);
	}
	return dwRetval;
}


DWORD CMlibCommunication::DisableUser(const CDSUser& DSUser)
{
	CJediContext jc("CMlibCommunication", "DisableUser");
	DWORD dwRetval = DSOM_SUCCESS;

	try
	{
		long lDbRetcode = m_pdb->SetUserEnabledFlag(m_pDSSyncContext->GetConnection()->m_DMSParameters.m_strLibrary.Get().c_str(), UnicodeToUTF8(DSUser.GetUserId()).c_str(), false);
		if (lDbRetcode != NRC_SUCCESS)
			jc.ThrowDatabaseError("SetUserEnabledFlag", lDbRetcode, MakeErrorString("User ID", DSUser.GetUserId(), "User Name", DSUser.GetName()));
	}
	catch (CBaseException& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch (long lErrorCode)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(lErrorCode);
	}
	return dwRetval;
}

DWORD CMlibCommunication::DisableGroup(const CDSGroup& DSGroup)
{
	CJediContext jc("CMlibCommunication", "DisableGroup");
	DWORD dwRetval = DSOM_SUCCESS;

	try
	{
		long lDbRetcode = m_pdb->SetGroupEnabledFlag(m_pDSSyncContext->GetConnection()->m_DMSParameters.m_strLibrary.Get().c_str(), UnicodeToUTF8(DSGroup.GetGroupId()).c_str(), false);
		if (lDbRetcode != NRC_SUCCESS)
			jc.ThrowDatabaseError("SetGroupEnabledFlag", lDbRetcode, MakeErrorString("Group ID", DSGroup.GetGroupId(), "Group Name", DSGroup.GetName()));
	}
	catch (CBaseException& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch (imstd::exception& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch (long lErrorCode)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(lErrorCode);
	}
	return dwRetval;
}




/////////////////////////////////////////////////////
// CSynchronizer

CSynchronizer::CSynchronizer( HANDLE hStopEvent )
{
	m_hStopEvent = hStopEvent;
}

CSynchronizer::~CSynchronizer( void )
{
}

bool CSynchronizer::ServiceIsStopping()
{
	if( WaitForSingleObject(m_hStopEvent, 0) == WAIT_OBJECT_0 )
		return true;
	else
		return false;
}











DWORD CSynchronizer::Synchronize( CDSSyncContextGeneric* pSyncContext, ICommunication* pDatabase )
{
	CJediContext jc( "CSynchronizer", "Synchronize" );

	// check pointers
	if( ( pSyncContext == NULL ) || ( pDatabase == NULL ) )
		return DSOM_FAILURE;

	DWORD dwRetval = DSOM_SUCCESS;

#ifdef _DEBUG
	//TestMemoryLeak( pSyncContext, pDatabase );
	//return dwRetval;
#endif

	try
	{
		ObjectContainers::CUniqueBstrVector vecExternalDNList;

#ifdef WS85_EXTERNAL
		DWORD dwRet = pSyncContext->GetDSInterface( )->ResolveExternalDNList( pSyncContext->GetConnection()->m_strExternalDNList.Get().c_str(), vecExternalDNList );
		if( dwRet != DSOM_SUCCESS )
			jc.ThrowGenericError( _T( "ResolveExternalDNList" ), _T( "returned failure" ) );
		LogMsg( LOG_DEBUG, _T( "External DN count: %i" ), vecExternalDNList.Count() );
#ifdef _DEBUG
		int externalCount = 0;
		for( ObjectContainers::CUniqueBstrVector::Const_Iterator iter = vecExternalDNList.Begin(); iter != vecExternalDNList.End(); iter++ )
		{
			_bstr_t dn = *iter;
			LogMsg( LOG_DEBUG, _T( "External object #%d: %s" ), ++externalCount, UnicodeToUTF8(dn).c_str() );
		}
		//return DSOM_SUCCESS;
#endif	// _DEBUG

#endif	// WS85_EXTERNAL
		

		

		while( pSyncContext->GetSyncState( ).GetState( ) != CDSSyncState::PassComplete )
		{
			// check if the service is stopping
			if( ServiceIsStopping() )
				break;

			switch( pSyncContext->GetSyncState( ).GetState( ) )
			{
			case CDSSyncState::DSUsers:
				dwRetval = DS_To_Db_Users( pSyncContext, pDatabase, vecExternalDNList );
				break;
			case CDSSyncState::DSGroups:
				dwRetval = DS_To_Db_Groups( pSyncContext, pDatabase, vecExternalDNList );
				break;
			case CDSSyncState::DmsUsers:
				dwRetval = Db_To_DS_Users( pSyncContext, pDatabase );
				pSyncContext->GetSyncState( ).AdvanceState( );
				break;
			case CDSSyncState::DmsGroups:
				dwRetval = Db_To_DS_Groups( pSyncContext, pDatabase );
				pSyncContext->GetSyncState( ).AdvanceState( );
				break;
			}

			if( dwRetval != DSOM_SUCCESS )
				break;
		}

		if( dwRetval == DSOM_SUCCESS )
			LogMsg( LOG_INFO, "Synchronization Pass Complete." );
		else
			LogMsg( LOG_ERROR, "Synchronization Pass Had Errors; Incomplete." );

		// reset the state back to DSUsers
		pSyncContext->GetSyncState( ).AdvanceState( );
		pSyncContext->ResetTimestamp( );

		g_SidMap.Reset();
	}
	catch( CBaseException& e )
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch(imstd::exception& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch(long lErrorCode)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage( lErrorCode );
	}
	return dwRetval;
}


DWORD CSynchronizer::DS_To_Db_Users( CDSSyncContextGeneric* pSyncContext, ICommunication* pDatabase, ObjectContainers::CUniqueBstrVector& vecExternalDNList )
{
	CJediContext jc( "CSynchronizer", "DS_To_Db_Users" );
	DWORD dwRetval = DSOM_SUCCESS;

	try
	{
		LogMsg( LOG_INFO, _T( "Phase 1 of 4: Synchronizing DS to WorkSite USERS for connection '%s'" ), ( LPCTSTR ) pSyncContext->GetConnection( )->m_strName.Get( ).c_str( ) );
		LogMsg( LOG_INFO, _T( "Registry Filter Entry: %s" ), ( LPCTSTR ) pSyncContext->GetConnection( )->m_strFilter.Get( ).c_str( ) );
		CDSUSERLIST DSUserList( true );
		DWORD dwTemp = pSyncContext->GetDSInterface( )->GetNextUsers( pSyncContext->GetUsersContext( ), DSUserList );
		if( dwTemp == DSOM_NOMOREUSERS )
			pSyncContext->GetSyncState( ).AdvanceState( );

		if( dwTemp == DSOM_FAILURE )
		{
			dwRetval = DSOM_FAILURE;
			LogMsg( LOG_ERROR, _T( "Failure on CDSGeneric::GetNextUsers()" ) );
		}
		else
		{
			//NT-64214 to find out if photo is supported, API not present.As of now true
			//bool bUserPhotoIsSupported = pDatabase->UserPhotoIsSupported();
			bool bUserPhotoIsSupported = true;
			for( CDSUSERLIST::Const_Iterator iter = DSUserList.Begin( ); iter != DSUserList.End( ); iter++ )
			{
				// check if the service is stopping
				if( ServiceIsStopping() )
					break;

				CDSUser* pDSUser = *iter;
				if( pDSUser != NULL )
				{
					try
					{
						if( pDSUser->GetK1SyncId().length() == 0 )
						{
							LogMsg( LOG_ERROR, _T( "User has no sync id -- cannot proceed: %s" ), UnicodeToUTF8(pDSUser->GetUserId()).c_str() );
						}
						else
						{
							// if user is on External list, mark as External
							bool bIsExternal = vecExternalDNList.IsMember( _wcsupr( pDSUser->GetDn() ) );
							pDSUser->SetExternal( bIsExternal );

							// if user has primaryGroupID set, set/update it in global map
							if( pDSUser->GetPrimaryGroupID().length() > 0 )
							{
								// Background:
								//
								// primaryGroupID is an RSID, a relative SID
								// Format of objectSID:
								//		domainSID-RSID
								//
								// Example
								// Domain SID
								// S-1-5-21-2563103455-3616774778-3265173650
								// Group RSID
								// 12297
								// Group objectSID
								// S-1-5-21-2563103455-3616774778-3265173650-12297
								//
								// A user's primaryGroupID value would be 12297, the RSID of the group
								// since the user and group must belong to the same domain (thus the same domainSID)

								// Thus we compose the group's objectSID by getting the domainSID from the user's objectSID
								// and appending the RSID of the group, which is the user's primaryGroupID value

								// get domainSID plus trailing "-"

								int lastDash = BstrStrings::FindRight( pDSUser->GetObjectSID(), _T( "-" ) );
								_bstr_t domainSID = BstrStrings::Mid( pDSUser->GetObjectSID(), 0, lastDash + 1 );
								_bstr_t groupObjectSID = domainSID + pDSUser->GetPrimaryGroupID();

								_bstr_t compositedId = _T( "" );
								if( CDSInterface::EncodeCompositedIdentifier( pDSUser->GetUserId(), pDSUser->GetK1SyncId(), pDSUser->GetDn(), compositedId ) == DSOM_SUCCESS )
								{
									g_SidMap.AddOrUpdate( groupObjectSID, compositedId );
								}
								else
									LogMsg( LOG_ERROR, _T( "CDSInterface::EncodeCompositedIdentifier failed for user DN '%s'" ), UnicodeToUTF8(pDSUser->GetDn()).c_str() );
							}
							else
							{
								// if user has no primaryGroupID set, make sure it is removed from global map if it exists in any
								g_SidMap.RemoveIfPresent( pDSUser->GetK1SyncId() );
							}

							// add association of IDs to maps for help with group membership comparison

							bool addUserToMaps;
							if( pDatabase->AddUserToMaps( pDSUser->GetUserId(), pDSUser->GetK1SyncId(), pDSUser->GetDn(), 0, addUserToMaps ) != DSOM_SUCCESS )
							{
								// error is logged in AddUserToMaps, ignore here and continue
							}

							// get corresponding user from DMS
							CDMSUser DmsUser( L"", L"", L"", L"", L"", false, L"", L"", L"", L"", L"", true, L"", IM::CDSSyncSvc_DSParameters::Microsoft );

							DWORD dw = pDatabase->GetUserBySyncId(pDSUser->GetK1SyncId(), DmsUser);

							// compare users
							if( dw == DSOM_USERNOTFOUND )
							{
								dw = pDatabase->GetUserByUserId(pDSUser->GetUserId(), DmsUser);
								if( dw == DSOM_SUCCESS )
								{
									IM::CDSSyncSvc_DSParameters::LDAPTYPE lDsNos = ( IM::CDSSyncSvc_DSParameters::LDAPTYPE ) pSyncContext->GetConnection( )->m_DSParameters.m_lServiceType.Get( );

									bool bConversion = false;
									IM::CDSSyncSvc_DSParameters::LDAPTYPE lDmsNos;
									try
									{
										lDmsNos = pDatabase->ConvertDmsNosToDsNos( DmsUser.GetNOS() );
										bConversion = true;
									}
									catch( CGenericException& e )
									{
										//e.GetErrorString();
										LogMsg( LOG_ERROR, _T( "User '%s' DMS NOS type is %i, and will not by synced with directory user of the same name since virtual (2) and external (5) NOS types are not synchronizable, %s" ), 
											UnicodeToUTF8(pDSUser->GetUserId( )).c_str(),
											(int)DmsUser.GetNOS(),
											UnicodeToUTF8(pDSUser->GetDn()).c_str());
									}

									if( bConversion )
									{
										if( DmsUser.GetK1SyncId().length() == 0 )
										{

											if( 
												( lDmsNos == lDsNos )

												||
													( 
														( lDmsNos == IM::CDSSyncSvc_DSParameters::NT )
														&&
														( lDsNos == IM::CDSSyncSvc_DSParameters::Microsoft )
													)
												)
											{
												// migrate user
												dw = pDatabase->MigrateUser(*pDSUser, DmsUser);
												switch( dw )
												{
												case DSOM_SUCCESS:
													LogMsg( LOG_INFO, _T( "User '%s' migrated, %s" ), UnicodeToUTF8(pDSUser->GetUserId( )).c_str(), UnicodeToUTF8(pDSUser->GetDn()).c_str() );
													break;
												case DSOM_FAILURE:
													LogMsg( LOG_ERROR, _T( "Failure on CRESTCommunication::MigrateUser() for '%s'" ), UnicodeToUTF8(pDSUser->GetUserId( )).c_str() );
													break;
												}
											}
											else
											{
												LogMsg( LOG_ERROR, _T( "Cannot migrate user '%s' (NOS=%i) because the NOS types do not match, %s" ), UnicodeToUTF8(pDSUser->GetUserId( )).c_str(), (int) DmsUser.GetNOS(), UnicodeToUTF8(pDSUser->GetDn( )).c_str()  );
											}
										}
										else
										{
											LogMsg( LOG_ERROR, _T( "Cannot migrate user '%s' because the sync_id is already set DOCUSERS.sync_id field must be cleared before this user can be migrated, %s" ), UnicodeToUTF8(pDSUser->GetUserId( )).c_str(), UnicodeToUTF8(pDSUser->GetDn( )).c_str()  );
										}
									}
								}
								else if( dw == DSOM_USERNOTFOUND )
								{
									if (pDatabase->InsertUser(*pDSUser) == DSOM_SUCCESS)
										LogMsg( LOG_INFO, _T( "User '%s' inserted, %s" ), UnicodeToUTF8(pDSUser->GetUserId( )).c_str(), UnicodeToUTF8(pDSUser->GetDn()).c_str()  );
									else
										LogMsg( LOG_ERROR, _T( "Failure on CRESTCommunication::InsertUser() for '%s'" ), UnicodeToUTF8(pDSUser->GetUserId( )).c_str() );
								}
								else //if( dw == DSOM_FAILURE )
								{
									LogMsg( LOG_ERROR, _T( "Failure on CRESTCommunication::GetUserByUserId() for '%s'" ), UnicodeToUTF8(pDSUser->GetUserId( )).c_str() );
								}
							}
							else if( dw == DSOM_FAILURE )
							{
								LogMsg( LOG_ERROR, _T( "Failure on CRESTCommunication::GetUserBySyncId() for '%s'" ), UnicodeToUTF8(pDSUser->GetUserId( )).c_str() );
							}
							else // dw == DSOM_SUCCESS
							{
								if( !( *pDSUser == DmsUser ) )
								{
									_bstr_t delta = DmsUser.GetDeltaDescription( *pDSUser );

									// if ID's are the same but containers are not then warn of possible ID contention
									if( ( _wcsicmp( pDSUser->GetUserId( ), DmsUser.GetUserId( ) ) == 0 ) && ( _wcsicmp( pDSUser->GetParentDn( ), DmsUser.GetParentDn( ) ) != 0 ) )
									{
										LogMsg( LOG_WARN, _T( "User '%s' exists in two containers: '%s' and '%s', Changed attributes=%s; DN is %s" ), 
											UnicodeToUTF8(pDSUser->GetUserId( )).c_str(),
											UnicodeToUTF8(pDSUser->GetParentDn( )).c_str(),
											UnicodeToUTF8(DmsUser.GetParentDn( )).c_str(),
											UnicodeToUTF8(delta).c_str(),
											UnicodeToUTF8(pDSUser->GetDn()).c_str()  );
									}
									
									// update user
									dw = pDatabase->UpdateUser(*pDSUser);
									switch( dw )
									{
									case DSOM_SUCCESS:
										{
											if( DmsUser.GetEnabled() && !pDSUser->GetEnabled() )
												LogMsg( LOG_INFO, _T( "User '%s' updated and disabled, Changed attributes=%s; DN is %s" ), UnicodeToUTF8(pDSUser->GetUserId( )).c_str(), UnicodeToUTF8(delta).c_str(), UnicodeToUTF8(pDSUser->GetDn()).c_str() );
											else if( !DmsUser.GetEnabled() && pDSUser->GetEnabled() )
												LogMsg( LOG_INFO, _T( "User '%s' updated and re-enabled, Changed attributes=%s; DN is %s" ), UnicodeToUTF8(pDSUser->GetUserId( )).c_str(), UnicodeToUTF8(delta).c_str(), UnicodeToUTF8(pDSUser->GetDn()).c_str() );
											else if( !DmsUser.GetEnabled() && !pDSUser->GetEnabled() )
												LogMsg( LOG_INFO, _T( "User '%s' updated and remains disabled, Changed attributes=%s; DN is %s" ), UnicodeToUTF8(pDSUser->GetUserId( )).c_str(), UnicodeToUTF8(delta).c_str(), UnicodeToUTF8(pDSUser->GetDn()).c_str() );
											else
												LogMsg( LOG_INFO, _T( "User '%s' updated and remains enabled, Changed attributes=%s; DN is %s" ), UnicodeToUTF8(pDSUser->GetUserId( )).c_str(), UnicodeToUTF8(delta).c_str(), UnicodeToUTF8(pDSUser->GetDn()).c_str() );
										}
										break;
									case DSOM_FAILURE:
										LogMsg( LOG_ERROR, _T( "Failure on CRESTCommunication::UpdateUser() for '%s', Changed attributes=%s; DN is %s" ), UnicodeToUTF8(pDSUser->GetUserId( )).c_str(), UnicodeToUTF8(delta).c_str(), UnicodeToUTF8(pDSUser->GetDn()).c_str() );
										break;
									}
								}
								else
									LogMsg( LOG_DEBUG, _T( "User is current: %s, DN is %s " ), UnicodeToUTF8(pDSUser->GetUserId( )).c_str(), UnicodeToUTF8(pDSUser->GetDn()).c_str() );
							}

							// update user photo
							if (bUserPhotoIsSupported == true)
							{
								_bstr_t strPhotoPath;
								dw = pSyncContext->GetDSInterface()->GetUserPhoto(*pDSUser, strPhotoPath);
								if ((dw == DSOM_SUCCESS) && (strPhotoPath.length() > 0))
								{
									dw = pDatabase->UpdateUserPhoto(*pDSUser, strPhotoPath,bUserPhotoIsSupported);
									::DeleteFile(strPhotoPath);
								}
							}

						}
					}
					catch( CBaseException& e )
					{
						LogMsg( LOG_ERROR, _T( "Error processing user %s" ), UnicodeToUTF8(pDSUser->GetDn()).c_str() );
						jc.LogMessage(e);
					}
					catch(imstd::exception& e)
					{
						LogMsg( LOG_ERROR, _T( "Error processing user %s" ), UnicodeToUTF8(pDSUser->GetDn()).c_str() );
						jc.LogMessage(e);
					}
					catch(long lErrorCode)
					{
						LogMsg( LOG_ERROR, _T( "Error processing user %s" ), UnicodeToUTF8(pDSUser->GetDn()).c_str() );
						jc.LogMessage( lErrorCode );
					}
					catch( ... )
					{
						LogMsg( LOG_ERROR, _T( "Error processing user %s" ), UnicodeToUTF8(pDSUser->GetDn()).c_str() );
						jc.LogMessage();
					}
				}
				else
				{
					// unable to get user from list
					dwRetval = DSOM_FAILURE;
					break;
				}
			}
		}
	}

	catch( CBaseException& e )
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch(imstd::exception& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch(long lErrorCode)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage( lErrorCode );
	}
	return dwRetval;
}


DWORD CSynchronizer::DS_To_Db_Groups( CDSSyncContextGeneric* pSyncContext, ICommunication* pDatabase, ObjectContainers::CUniqueBstrVector& vecExternalDNList )
{
	CJediContext jc( "CSynchronizer", "DS_To_Db_Groups" );
	DWORD dwRetval = DSOM_SUCCESS;

	try
	{
		LogMsg( LOG_INFO, _T( "Phase 2 of 4: Synchronizing DS to WorkSite GROUPS for connection '%s'" ), ( LPCTSTR ) pSyncContext->GetConnection( )->m_strName.Get( ).c_str( ) );
		CDSGROUPLIST DSGroupList( true );
		DWORD dwTemp = pSyncContext->GetDSInterface( )->GetNextGroups( pSyncContext->GetGroupsContext( ), DSGroupList );
		if( dwTemp == DSOM_NOMOREGROUPS )
			pSyncContext->GetSyncState( ).AdvanceState( );

		if( dwTemp == DSOM_FAILURE )
		{
			dwRetval = DSOM_FAILURE;
			LogMsg( LOG_ERROR, _T( "Failure on CDSGeneric::GetNextGroups()" ) );
		}
		else
		{
			for( CDSGROUPLIST::Const_Iterator iter = DSGroupList.Begin( ); iter != DSGroupList.End( ); iter++ )
			{
				// check if the service is stopping
				if( ServiceIsStopping() )
					break;

				CDSGroup* pDSGroup = *iter;
				if( pDSGroup != NULL )
				{
					try
					{
						if( pDSGroup->GetK1SyncId().length() == 0 )
						{
							LogMsg( LOG_ERROR, _T( "Group has no sync id -- cannot proceed: %s" ), UnicodeToUTF8(pDSGroup->GetGroupId()).c_str() );
						}
						else
						{
							// get LDAP type
							IM::CDSSyncSvc_DSParameters::LDAPTYPE lDsNos = ( IM::CDSSyncSvc_DSParameters::LDAPTYPE ) pSyncContext->GetConnection( )->m_DSParameters.m_lServiceType.Get( );

							// if user is on External list, mark as External
							bool bIsExternal = vecExternalDNList.IsMember( _wcsupr( pDSGroup->GetDn() ) );
							pDSGroup->SetExternal( bIsExternal );

							// ENFORCE group membership rules:
							// 1. External groups can only contain External users
							// 2. Internal (i.e. non-external) groups can only contain Internal users
							// Such violating memberships will be removed from this group's membership, and will be logged as such but will not cause exceptions
							ObjectContainers::CUniqueBstrVector memberDNs = pDSGroup->GetMemberDNs();
							ObjectContainers::CUniqueBstrVector memberDNsToRemove;
							for( ObjectContainers::CUniqueBstrVector::Const_Iterator iter = memberDNs.Begin(); iter != memberDNs.End(); iter++ )
							{
								_bstr_t memberCompositeDN = *iter;
								_bstr_t strUserId = L"";
								_bstr_t strSyncId = L"";
								_bstr_t strDn = L"";
								if( CDSInterface::DecodeCompositedIdentifier( memberCompositeDN, strUserId, strSyncId, strDn ) == DSOM_SUCCESS )
								{
									// if group is External, each member must be in External list
									if( pDSGroup->GetExternal() )
									{
										if( !vecExternalDNList.IsMember( _wcsupr( strDn ) ) )
										{
											// add member to removal list to be removed after this list has been iterated
											memberDNsToRemove.AddBack( memberCompositeDN );
										}
									}
									else
									// if group is Internal, each member must not be in External list
									{
										if( vecExternalDNList.IsMember( _wcsupr( strDn ) ) )
										{
											// add member to removal list to be removed after this list has been iterated
											memberDNsToRemove.AddBack( memberCompositeDN );
										}
									}
								}
								else
									LogMsg( LOG_ERROR, _T( "CDSInterface::DecodeCompositedIdentifier failed for group member '%s'" ), UnicodeToUTF8(memberCompositeDN).c_str() );
							}

							// now remove any membership violations
							for( ObjectContainers::CUniqueBstrVector::Const_Iterator iter2 = memberDNsToRemove.Begin(); iter2 != memberDNsToRemove.End(); iter2++ )
							{
								_bstr_t memberCompositeDN = *iter2;
								pDSGroup->GetMemberDNs().Remove( memberCompositeDN );
							}

							if( pDatabase->ResolvePrimaryGroupIDMembership( pDSGroup ) != DSOM_SUCCESS )
							{
								_bstr_t err = _T( "returned failure for group " );
								err += pDSGroup->GetGroupId();
								jc.ThrowGenericError( _T( "ResolvePrimaryGroupIDMembership" ), err );
							}

							// get corresponding group from DMS
							ObjectContainers::CUniqueBstrVector vMembers;
							DSOM::CDMSGroup *DmsGroupPtr = NULL;

							if ( lDsNos == IM::CDSSyncSvc_DSParameters::Novell )
							{
								DmsGroupPtr = im_new CDMSGroup( L"", L"", L"", L"", ( LPCWSTR ) pDSGroup->GetGroupId(), false, ( LPCWSTR ) pDSGroup->GetGroupId(),
														vMembers, true, IM::CDSSyncSvc_DSParameters::Novell);
							}
							else
							{
								DmsGroupPtr = im_new CDMSGroup( L"", L"", L"", L"", L"", false, L"", vMembers, true, IM::CDSSyncSvc_DSParameters::Microsoft );
							}
							imstd::auto_ptr<CDMSGroup> autoDelete(DmsGroupPtr);
							DSOM::CDMSGroup& DmsGroup = *DmsGroupPtr;

							DWORD dw = pDatabase->GetGroupBySyncId(pDSGroup->GetK1SyncId(), DmsGroup);

							// compare groups
							if( dw == DSOM_GROUPNOTFOUND )
							{
								dw = pDatabase->GetGroupByGroupId(pDSGroup->GetGroupId(), DmsGroup);
								if( dw == DSOM_SUCCESS )
								{
//									IM::CDSSyncSvc_DSParameters::LDAPTYPE lDsNos = ( IM::CDSSyncSvc_DSParameters::LDAPTYPE ) pSyncContext->GetConnection( )->m_DSParameters.m_lServiceType.Get( );

									bool bConversion = false;
									IM::CDSSyncSvc_DSParameters::LDAPTYPE lDmsNos;
									try
									{
										lDmsNos = pDatabase->ConvertDmsNosToDsNos( DmsGroup.GetNOS() );
										bConversion = true;
									}
									catch( CGenericException& e )
									{
										//e.GetErrorString();
										LogMsg( LOG_ERROR, _T( "Group '%s' DMS NOS type is %i, and will not by synced with directory group of the same name since virtual (2) and external (5) NOS types are not synchronizable, %s" ),
											UnicodeToUTF8(pDSGroup->GetGroupId( )).c_str(),
											(int)DmsGroup.GetNOS(),
											UnicodeToUTF8(pDSGroup->GetDn()).c_str());
									}

									if( bConversion )
									{
										if( DmsGroup.GetK1SyncId().length( ) == 0 )
										{
											if( 
												( lDmsNos == lDsNos )

												||
													( 
														( lDmsNos == IM::CDSSyncSvc_DSParameters::NT )
														&&
														( lDsNos == IM::CDSSyncSvc_DSParameters::Microsoft )
													)
												)
											{
												// migrate group
												dw = pDatabase->MigrateGroup(*pDSGroup);
												switch( dw )
												{
												case DSOM_SUCCESS:
													LogMsg( LOG_INFO, 
														_T( "Group '%s' migrated, %s" ),
														UnicodeToUTF8(pDSGroup->GetGroupId( )).c_str(),
														UnicodeToUTF8(pDSGroup->GetDn()).c_str() );
													break;
												case DSOM_FAILURE:
													LogMsg( LOG_ERROR, 
														_T( "Failure on CRESTCommunication::MigrateGroup() for '%s'" ),
														UnicodeToUTF8(pDSGroup->GetGroupId( )).c_str() );
													break;
												}
											}
											else
											{
												LogMsg( LOG_ERROR,
													_T( "Cannot migrate group '%s' (NOS=%i) because the NOS types do not match, %s" ),
													UnicodeToUTF8(pDSGroup->GetGroupId( )).c_str(),
													(int)DmsGroup.GetNOS(),
													UnicodeToUTF8(pDSGroup->GetDn()).c_str() );
											}
										}
										else
										{
											LogMsg( LOG_ERROR, 
												_T( "Cannot migrate group '%s' because the sync_id is already set. GROUPS.sync_id field must be cleared before this user can be migrated, %s" ),
												UnicodeToUTF8(pDSGroup->GetGroupId( )).c_str(),
												UnicodeToUTF8(pDSGroup->GetDn()).c_str() );
										}
									}
								}
								else if( dw == DSOM_GROUPNOTFOUND )
								{
									if( pDatabase->InsertGroup( *pDSGroup ) == DSOM_SUCCESS )
										LogMsg( LOG_INFO, _T( "Group '%s' inserted, %s" ), UnicodeToUTF8(pDSGroup->GetGroupId( )).c_str(), UnicodeToUTF8(pDSGroup->GetDn()).c_str());
									else
										LogMsg( LOG_ERROR, _T( "Failure on CRESTCommunication::InsertGroup() for '%s'" ), UnicodeToUTF8(pDSGroup->GetGroupId( )).c_str() );
								}
								else //if( dw == DSOM_FAILURE )
								{
									LogMsg( LOG_ERROR, _T( "Failure on CRESTCommunication::GetGroupByGroupId() for '%s'" ), UnicodeToUTF8(pDSGroup->GetGroupId( )).c_str() );
								}
							}
							else if( dw == DSOM_FAILURE )
							{
								LogMsg( LOG_ERROR, _T( "Failure on CRESTCommunication::GetGroupBySyncId() for '%s'" ), UnicodeToUTF8(pDSGroup->GetGroupId( )).c_str() );
							}
							else // dw == DSOM_SUCCESS
							{
								// this compare function caches usernum membership vectors so it must be done outside of IF statement
								bool bCompareGroupMems = false;
								if (pDatabase->CompareGroupMems(*pDSGroup, DmsGroup, bCompareGroupMems) == DSOM_SUCCESS)
								{
									long memberCount = 0;
									if( pDSGroup->bMemberVectorsSet )
										memberCount = pDSGroup->dsMems.Count();
									else
										memberCount = pDSGroup->GetMembers().Count();

									if( !( *pDSGroup == DmsGroup && bCompareGroupMems ) )
									{

										_bstr_t delta = DmsGroup.GetDeltaDescription( *pDSGroup );

										// if ID's are the same but containers are not then warn of possible ID contention
										if( ( _wcsicmp( pDSGroup->GetGroupId( ), DmsGroup.GetGroupId( ) ) == 0 ) && ( _wcsicmp( pDSGroup->GetParentDn( ), DmsGroup.GetParentDn( ) ) != 0 ) )
										{
											LogMsg( LOG_WARN, 
												_T( "Group '%s' exists in two containers: '%s' and '%s', Changed attributes=%s; DN is %s, Member count %i" ),
												UnicodeToUTF8(pDSGroup->GetGroupId( )).c_str(),
												UnicodeToUTF8(pDSGroup->GetParentDn( )).c_str(),
												UnicodeToUTF8(DmsGroup.GetParentDn( )).c_str(),
												UnicodeToUTF8(delta).c_str(),
												UnicodeToUTF8(pDSGroup->GetDn()).c_str(),
												memberCount );
										}
										
										// update group
										dw = pDatabase->UpdateGroup(*pDSGroup);
										switch( dw )
										{
										case DSOM_SUCCESS:
											{
												if( DmsGroup.GetEnabled() && !pDSGroup->GetEnabled() )
													LogMsg( LOG_INFO, "Group '%s' updated and disabled, Changed attributes=%s; DN is %s, Member count %i", UnicodeToUTF8(pDSGroup->GetGroupId( )).c_str(), UnicodeToUTF8(delta).c_str(), UnicodeToUTF8(pDSGroup->GetDn()).c_str(), memberCount );
												else if( !DmsGroup.GetEnabled() && pDSGroup->GetEnabled() )
													LogMsg( LOG_INFO, "Group '%s' updated and re-enabled, Changed attributes=%s; DN is %s, Member count %i", UnicodeToUTF8(pDSGroup->GetGroupId( )).c_str(), UnicodeToUTF8(delta).c_str(), UnicodeToUTF8(pDSGroup->GetDn()).c_str(), memberCount );
												else if( !DmsGroup.GetEnabled() && !pDSGroup->GetEnabled() )
													LogMsg( LOG_INFO, "Group '%s' updated and remains disabled, Changed attributes=%s; DN is %, Member count %is", UnicodeToUTF8(pDSGroup->GetGroupId( )).c_str(), UnicodeToUTF8(delta).c_str(), UnicodeToUTF8(pDSGroup->GetDn()).c_str(), memberCount );
												else
													LogMsg( LOG_INFO, "Group '%s' updated and remains enabled, Changed attributes=%s; DN is %s, Member count %i", UnicodeToUTF8(pDSGroup->GetGroupId( )).c_str(), UnicodeToUTF8(delta).c_str(), UnicodeToUTF8(pDSGroup->GetDn()).c_str(), memberCount );
											}
											break;
										case DSOM_FAILURE:
											LogMsg( LOG_ERROR, "Failure on CRESTCommunication::UpdateGroup() for '%s', Changed attributes=%s; DN is %s, Member count %i", UnicodeToUTF8(pDSGroup->GetGroupId( )).c_str(), UnicodeToUTF8(delta).c_str(), UnicodeToUTF8(pDSGroup->GetDn()).c_str(), memberCount );
											break;
										}
									}
									else
										LogMsg( LOG_DEBUG, "Group '%s' current, DN is %s, Member count %i", UnicodeToUTF8(pDSGroup->GetGroupId( )).c_str(), UnicodeToUTF8(pDSGroup->GetDn()).c_str(), memberCount );
								}
								else
								{
									LogMsg( LOG_ERROR, "Failure on CRESTCommunication::CompareGroupMems() for '%s', can't synchronize group", UnicodeToUTF8(pDSGroup->GetGroupId( )).c_str() );
								}
							}
						}
					}

					catch( CBaseException& e )
					{
						LogMsg( LOG_ERROR, _T( "Error processing group %s" ), UnicodeToUTF8(pDSGroup->GetDn()).c_str() );
						jc.LogMessage(e);
					}
					catch(imstd::exception& e)
					{
						LogMsg( LOG_ERROR, _T( "Error processing group %s" ), UnicodeToUTF8(pDSGroup->GetDn()).c_str() );
						jc.LogMessage(e);
					}
					catch(long lErrorCode)
					{
						LogMsg( LOG_ERROR, _T( "Error processing group %s" ), UnicodeToUTF8(pDSGroup->GetDn()).c_str() );
						jc.LogMessage( lErrorCode );
					}
					catch( ... )
					{
						LogMsg( LOG_ERROR, _T( "Error processing group %s" ), UnicodeToUTF8(pDSGroup->GetDn()).c_str() );
						jc.LogMessage();
					}
				}
				else
				{
					// unable to get group from list
					dwRetval = DSOM_FAILURE;
					break;
				}
			}
		}
	}
	catch( CBaseException& e )
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch(imstd::exception& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch(long lErrorCode)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage( lErrorCode );
	}
	return dwRetval;
}

DWORD CSynchronizer::Db_To_DS_Users( CDSSyncContextGeneric* pSyncContext, ICommunication* pDatabase )
{
	CJediContext jc( "CSynchronizer", "Db_To_DS_Users" );
	DWORD dwRetval = DSOM_SUCCESS;

	try
	{
		LogMsg( LOG_INFO, _T( "Phase 3 of 4: Synchronizing WorkSite to DS USERS for connection '%s'" ), ( LPCTSTR ) pSyncContext->GetConnection( )->m_strName.Get( ).c_str( ) );

		// check for registry filter setting
		_bstr_t strDSFilter = pSyncContext->GetConnection()->m_strFilter.Get().c_str();
		LogMsg( LOG_DEBUG, _T("DS User Filter: %s" ), UnicodeToUTF8(strDSFilter).c_str() );

		CDSUSERLIST DbUserList( true );
		
		if (pDatabase->GetUsers(DbUserList) == DSOM_SUCCESS)
		{
			for( CDSUSERLIST::Const_Iterator iter = DbUserList.Begin( ); iter != DbUserList.End( ); iter++ )
			{
				// check if the service is stopping
				if( ServiceIsStopping() )
					break;

				CDSUser* pDSUser = *iter;
				if( pDSUser != NULL )
				{
					// verify that this user belongs to the correct branch of the tree
					if( ( pDSUser->GetParentDn( ).length( ) > 0 ) && ( pDSUser->GetDn( ).length( ) > 0 ) )
					{
						_bstr_t strUpperParentDn = _wcsupr( pDSUser->GetParentDn( ) );
						_bstr_t strUpperRootContainer = _wcsupr( pSyncContext->GetUsersContext( )->GetRootContainer( ) );
						if( wcsstr( (LPCWSTR)strUpperParentDn, (LPCWSTR)strUpperRootContainer ) != NULL )
						{
							bool exists;
							if( pSyncContext->GetDSInterface( )->UserExists( *pDSUser, exists, strDSFilter ) == DSOM_SUCCESS )
							{
								if( !exists )
								{
									// disable the user only if it is currently enabled
									if( pDSUser->GetEnabled() )
									{
										if (pDatabase->DisableUser(*pDSUser) == DSOM_SUCCESS)
											LogMsg( LOG_INFO, _T( "User '%s' disabled %s on directory-lookup" ), UnicodeToUTF8(pDSUser->GetUserId( )).c_str(), UnicodeToUTF8(pDSUser->GetDn()).c_str() );
										else
											LogMsg( LOG_ERROR, _T( "Failure on CRESTCommunication::DisableUser() for '%s'" ), UnicodeToUTF8(pDSUser->GetUserId( )).c_str() );
									}
										LogMsg( LOG_INFO, _T( "User '%s' remains disabled %s on directory-lookup" ), UnicodeToUTF8(pDSUser->GetUserId( )).c_str(), UnicodeToUTF8(pDSUser->GetDn()).c_str() );
								}
								else
									if( pDSUser->GetEnabled() )
										LogMsg( LOG_INFO, _T( "User '%s' remains enabled and synchronized %s on directory-lookup" ), UnicodeToUTF8(pDSUser->GetUserId( )).c_str(), UnicodeToUTF8(pDSUser->GetDn()).c_str() );
									else
										LogMsg( LOG_INFO, _T( "User '%s' remains disabled and synchronized %s on directory-lookup" ), UnicodeToUTF8(pDSUser->GetUserId( )).c_str(), UnicodeToUTF8(pDSUser->GetDn()).c_str() );
							}
							else
							{
								LogMsg( LOG_ERROR, "Unable to determine if user '%s' exists on directory, skipping enable/disable", UnicodeToUTF8(pDSUser->GetUserId( )).c_str() );
							}

						}
					}
				}
			}
		}
		else
		{
			dwRetval = DSOM_FAILURE;
			LogMsg( LOG_ERROR, _T( "Failure on CRESTCommunication::GetUsers()" ) );
		}
	}
	catch( CBaseException& e )
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch(imstd::exception& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch(long lErrorCode)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage( lErrorCode );
	}
	return dwRetval;
}

DWORD CSynchronizer::Db_To_DS_Groups( CDSSyncContextGeneric* pSyncContext, ICommunication* pDatabase )
{
	CJediContext jc( "CSynchronizer", "Db_To_DS_Groups" );
	DWORD dwRetval = DSOM_SUCCESS;

	try
	{
		LogMsg( LOG_INFO, _T( "Phase 4 of 4: Synchronizing WorkSite to DS GROUPS for connection '%s'" ), ( LPCTSTR ) pSyncContext->GetConnection( )->m_strName.Get( ).c_str( ) );

		// check for registry filter setting
		_bstr_t strDSFilter = pSyncContext->GetConnection()->m_strFilter.Get().c_str();
		LogMsg( LOG_DEBUG, _T("DS Group Filter: %s" ), UnicodeToUTF8(strDSFilter).c_str() );

		CDSGROUPLIST DbGroupList( true );
		
		if (pDatabase->GetGroups(DbGroupList) == DSOM_SUCCESS)
		{
			for( CDSGROUPLIST::Const_Iterator iter = DbGroupList.Begin( ); iter != DbGroupList.End( ); iter++ )
			{
				// check if the service is stopping
				if( ServiceIsStopping() )
					break;

				CDSGroup* pDSGroup = *iter;
				if( pDSGroup != NULL )
				{
					// verify that this group belongs to the correct branch of the tree
					if( ( pDSGroup->GetParentDn( ).length( ) > 0 ) && ( pDSGroup->GetDn( ).length( ) > 0 ) )
					{
						_bstr_t strUpperParentDn = _wcsupr( pDSGroup->GetParentDn( ) );
						_bstr_t strUpperRootContainer = _wcsupr( pSyncContext->GetUsersContext( )->GetRootContainer( ) );
						if( wcsstr( (LPCWSTR)strUpperParentDn, (LPCWSTR)strUpperRootContainer ) != NULL )
						{
							bool exists;
							if( pSyncContext->GetDSInterface( )->GroupExists( *pDSGroup, exists, strDSFilter ) == DSOM_SUCCESS )
							{
								if( !exists )
								{
									// disable the group only if it is currently enabled
									if( pDSGroup->GetEnabled() )
									{
										if (pDatabase->DisableGroup(*pDSGroup) == DSOM_SUCCESS)
											LogMsg( LOG_INFO, _T( "Group '%s' disabled %s on directory-lookup" ), UnicodeToUTF8(pDSGroup->GetGroupId( )).c_str(), UnicodeToUTF8(pDSGroup->GetDn()).c_str()  );
										else
											LogMsg( LOG_ERROR, _T( "Failure on CRESTCommunication::DisableGroup() for '%s'" ), UnicodeToUTF8(pDSGroup->GetGroupId( )).c_str() );
									}
									LogMsg( LOG_INFO, _T( "Group '%s' remains disabled %s on directory-lookup" ), UnicodeToUTF8(pDSGroup->GetGroupId( )).c_str(), UnicodeToUTF8(pDSGroup->GetDn()).c_str() );
								}
								else
									if( pDSGroup->GetEnabled() )
										LogMsg( LOG_INFO, _T( "Group '%s' remains enabled and synchronized %s on directory-lookup" ), UnicodeToUTF8(pDSGroup->GetGroupId( )).c_str(), UnicodeToUTF8(pDSGroup->GetDn()).c_str() );
									else
										LogMsg( LOG_INFO, _T( "Group '%s' remains disabled and synchronized %s on directory-lookup" ), UnicodeToUTF8(pDSGroup->GetGroupId( )).c_str(), UnicodeToUTF8(pDSGroup->GetDn()).c_str() );
							}
							else
							{
								LogMsg( LOG_ERROR, "Unable to determine if user '%s' exists on directory, skipping enable/disable", UnicodeToUTF8(pDSGroup->GetGroupId( )).c_str() );
							}

						}
					}
				}
			}
		}
		else
		{
			dwRetval = DSOM_FAILURE;
			LogMsg( LOG_ERROR, _T( "Failure on CRESTCommunication::GetGroups()" ) );
		}
	}
	catch( CBaseException& e )
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch(imstd::exception& e)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage(e);
	}
	catch(long lErrorCode)
	{
		dwRetval = DSOM_FAILURE;
		jc.LogMessage( lErrorCode );
	}
	return dwRetval;
}





}	// namespace DSOM











