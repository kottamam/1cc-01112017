////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// File:	RestClientConsts.h
//
// Project: This file defines all the contants
//
// Contents:	
//
//   Date    Who  Modification
// 07/25/13  Bala  Initial coding
//
// Copyright (C) 2001, iManage Technologies, Inc. ALL RIGHTS RESERVED
//                     PROPRIETARY AND CONFIDENTIAL
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef RESTCLIENT_CONSTS_H
#define RESTCLIENT_CONSTS_H

#include <list>
#include <map>
#include <string>


#define	WS_PRP_ERROR_CODE		"code"
#define	WS_PRP_ERROR_MESSAGE	"message"
#define	WS_PRP_ERROR_EXCEPTION_ID	"exceptionId"

//Publish properties



//Endpoint constants
#define APIENDPOINT "/api/v1"
#define APIENDPOINTV2 "/api/v2"
#define CUSTOMERID "imanage"
#define	LOGIN		"/session/login"
#define	LOGOUT		"/session/logout"
#define USERS			"/users"
#define USERSSEARCH			"/users/search"
#define	GROUPS			"/groups"
#define	GROUPSSEARCH			"/groups/search"
#define SEARCH_GLOBAL_FOLDERS	"/folders/global/search"
#define MEMBERS					"/members"


//worksite keys
#define WS_USER_DISTINGUISHED_NAME "distinguished_name"
#define WS_USER_FULL_NAME			"full_name"
#define WS_USER_ID					"id"
#define WS_USER_ID_EX				"user_id_ex"
#define WS_USER_USER_ID				"user_id"
#define WS_USER_PASSWORD			"user_password"
#define WS_USER_PWD_NEVER_EXPIRE			"pwd_never_expire"
#define WS_USER_FORCE_PWD_CHANGE			"force_password_change"
#define WS_USER_PASSWORD			"user_password"
#define WS_USER_IS_EXTERNAL			"is_external"
#define WS_USER_LAST_SYNC_TS		"last_sync_ts"
#define WS_USER_LOGIN				"login"
#define WS_USER_SYNC_ID				"sync_id"
#define WS_USER_DOMAIN				"user_domain"
#define WS_USER_NOS					"user_nos"
#define WS_USER_NUM					"user_num"
#define WS_USER_PHONE					"phone"
#define WS_USER_EMAIL					"email"
#define WS_USER_FAX					"fax"
#define WS_USER_LOCATION				"location"
#define WS_DATABASE					"database"
#define WS_GROUP_DOMAIN				"group_domain"
#define WS_GROUP_ID					"groupid"
#define WS_GROUP_ID_ID					"group_id"
#define WS_GROUP_ENABLED			"enabled"
#define WS_GROUP_NOS				"group_nos"
#define WS_GROUP_NUMBER				"group_number"
#endif //RESTCLIENT_CONSTS_H