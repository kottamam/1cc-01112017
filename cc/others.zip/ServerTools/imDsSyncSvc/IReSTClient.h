////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// File:	IReSTClient.h
//
// Project: Interface to invoke ReST APIs
//
// Contents:	
//
//   Date    Who  Modification
// 02/28/01  CJO  Initial coding
//
// Copyright (C) 2001, iManage Technologies, Inc. ALL RIGHTS RESERVED
//                     PROPRIETARY AND CONFIDENTIAL
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef _REST_CLIENT_H
#define _REST_CLIENT_H

#include "RestClientOptions.h"
#include "RestClientConsts.h"
#include "RestClientDefs.h"

namespace DSOM
{
	class IRestClient
	{
	public:
		IRestClient(){}
		virtual ~IRestClient(){}



		//Callback implementation
		virtual size_t HandleWrite(void *ptr, size_t size, size_t nmemb) = 0;
		virtual size_t HandleHeader(void *ptr, size_t size, size_t nmemb) = 0;
		virtual size_t HandleRead(void *ptr, size_t size, size_t nmemb) = 0;


		//CURL callbacks
		static size_t WriteFunction(void *ptr, size_t size, size_t nmemb, void *userdata);
		static size_t HeaderFunction(void *ptr, size_t size, size_t nmemb, void *userdata);
		static size_t ReadFunction(void *ptr, size_t size, size_t nmemb, void *userdata);



	};
}

#endif //_REST_CLIENT_H