////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// File:	IPayload.h
//
// Project: Payload related interfaces declaration
//
// Contents:	
//
//   Date    Who  Modification
// 07/25/13  Bala  Initial coding
//
// Copyright (C) 2001, iManage Technologies, Inc. ALL RIGHTS RESERVED
//                     PROPRIETARY AND CONFIDENTIAL
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef RESTCLIENT_PAYLOAD_H
#define RESTCLIENT_PAYLOAD_H

#include "RestClientConsts.h"
#include "RestClientDefs.h"

class IPayload
{
public:
	IPayload(){}
	virtual ~IPayload(){}

	//Payload generators
	
	virtual FieldMapList GetChildrenList(const char* respPayload, bool& bOverFlow)=0;
	virtual FieldMapList GetChildrenList(const char* respPayload, bool& bOverFlow, stlport::string& nextUrl) = 0;
	
	virtual int ParseResponse(const char* respPayload)=0;
	
	virtual int getValue(stlport::string strKey, stlport::string & strOutValue)=0;
	virtual int getFieldMap(FieldMap& fieldMap)=0;
	virtual void generateLoginPayload(const char* strUserName, const char* strPassword, stlport::string& outputPayload)=0;
	
	virtual void generatePayloadForAddRemoveUsers(const char* szDatabase, const char* szUserId, const char* action, stlport::string& outputPayload) = 0;
	
	//Response payload parsers
	

};

#endif //RESTCLIENT_PAYLOAD_H