////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// File:	CJSONPayload.h
//
// Project: Interfaces for flow payload generators/parsers
//
// Contents:	
//
//   Date    Who  Modification
// 04/28/13  Bala  Initial coding
//
// Copyright (C) 2001, iManage Technologies, Inc. ALL RIGHTS RESERVED
//                     PROPRIETARY AND CONFIDENTIAL
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef _JSON_PAYLOAD_H
#define _JSON_PAYLOAD_H

#include "IPayload.h"
#include <libjson.h>

class CJSONPayload : public IPayload
{
public:
	CJSONPayload() {}
	virtual ~CJSONPayload() {}

	int ParseResponse(const char* respPayload);
	int getValue(stlport::string strKey, stlport::string & strOutValue);
	virtual int getFieldMap(FieldMap& fieldMap);
	

	
	FieldMapList GetChildrenList(const char* respPayload, bool& bOverFlow);
	FieldMapList GetChildrenList(const char* respPayload, bool& bOverFlow, stlport::string& nextUrl);

	void generateLoginPayload(const char* strUserName, const char* strPassword, stlport::string& outputPayload);
	void generatePayloadForAddRemoveUsers(const char* szDatabase, const char* szUserId, const char* action, stlport::string& outputPayload);
	
	

	
	

private:
	
	void** ParseJSON(void** &iterator, void** end_iterator);
	
	int GenerateFieldMap(const char* respPayload);
	int ParseJSONArray(const char* respPayload, const char* arrayName, bool& bOverflow, FieldMapList& fieldList);
	int ParseJSONArray(const char* respPayload, const char* arrayName, bool& bOverflow, FieldMapList& fieldList, stlport::string& nextUrl);
	
	
	

private:
	FieldMap m_fieldMap;
	//FieldMapList m_fieldMapList;
};

#endif //_JSON_PAYLOAD_H