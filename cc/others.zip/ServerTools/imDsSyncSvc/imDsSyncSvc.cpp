////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// File:	ImDsSyncSvc.cpp
//
// Project: Directory Service Synchronization Service
//
// Contents:	
//
//   Date    Who  Modification
// 03/07/02  MDL  Initial coding
//
// Copyright (C) 2002, iManage Technologies, Inc. ALL RIGHTS RESERVED
//                     PROPRIETARY AND CONFIDENTIAL
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include "StdAfx.h"
#include "imDsSyncSvc.h"
#include <oncRpc\OncRpc.h>

#pragma hdrstop

using namespace IM;

//======================================================================================================================
// ImDsSyncSvc
//======================================================================================================================

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// ImDsSyncSvc - Overloaded constructor.
//
ImDsSyncSvc::ImDsSyncSvc(CDSSyncSvc *pServiceConfiguration_)
	:	NtSystemService(pServiceConfiguration_),
		m_pDatabaseList(NULL),
		m_pDsSyncService(NULL),
		m_pPoolMgr(NULL),
		m_pShutdownThread(NULL)
{
	NtSystemService::m_pService = this;

	try
	{
		CDSSyncSvc* myConfiguration = (CDSSyncSvc*) m_pServiceConfiguration;
		throw_syserr_iffails(NULL != myConfiguration);

		//
		// Database List
		//
		m_pDatabaseList = im_new DsSyncDatabaseList(NULL);
		m_pDatabaseList->LoadAll();


		//
		// Database connection pool manager.
		//
		m_pPoolMgr = im_new ::DBPoolMgr(m_hStopEvent, m_pDatabaseList, NULL, 1);
		check_object(m_pPoolMgr);
	}
	catch(imstd::exception &e)
	{
		LogMsg(LOG_DEBUG, "Failed to create an ImDsSyncSvc class;  e.what %s", e.what());

		Event(ECAT_CONFIG, EVE_GENERIC| EVT_SYSERR, "At least one critical run time error has occurred. Stopping service.");
		::SetEvent(m_hStopEvent);
	}
	catch(long)
	{
		Event(ECAT_CONFIG, EVE_GENERIC| EVT_SYSERR, "At least one critical run time error has occurred. Stopping service.");
		::SetEvent(m_hStopEvent);
	}
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// ~ImDsSyncSvc - Destructor.
//
ImDsSyncSvc::~ImDsSyncSvc()
{	
	try
	{
		if(!m_bClean)
		{			
			m_bIsDebug = true; //suppress SCM notification;
			OnStopCleanup();
		}

		if (m_pDsSyncService != NULL)
		{
			delete m_pDsSyncService;
			m_pDsSyncService = NULL;
		}

		if (m_pDatabaseList != NULL)
		{
			m_pDatabaseList->ClearList();
			delete m_pDatabaseList;
			m_pDatabaseList = NULL;
		}

		if (m_pPoolMgr != NULL)
		{
			check_pointer(m_pPoolMgr);
			delete m_pPoolMgr;
			m_pPoolMgr = NULL;
		}
	}
	catch(imstd::exception &)
	{
	}
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Init
//
void
ImDsSyncSvc::Init()
{
	NtSystemService::Init();
	try
	{
		throw_if_signaled(m_hStopEvent);

		ChangeStatus(SERVICE_START_PENDING,10000);

		// Sync Svc should treat all scheduled times in local time
		// UTC In Use is NOT what we want
		// Defect #43163 and #42867
		//gbDatabaseTimeInUtc = m_pServiceConfiguration->m_bUtcInUse.Get();
		gbDatabaseTimeInUtc = false;

		ChangeStatus(SERVICE_START_PENDING,10000);

		// Database connection pool manager.
		m_pPoolMgr->initializePools();

		throw_iffails(m_pPoolMgr->startThread(), 0);
		throw_syserr_iffails(::WaitForSingleObject(m_hStopEvent, 0) != WAIT_OBJECT_0);

		ChangeStatus(SERVICE_START_PENDING,10000);

		//	Initialize the service subsystem
		m_pDsSyncService = im_new DsSyncService();
		m_pDsSyncService->Init(m_hStopEvent, m_pPoolMgr, (CDSSyncSvc*) m_pServiceConfiguration);

	}
	catch(imstd::exception &e)
	{
		LogMsg(LOG_DEBUG, "Failed to init ImDsSyncSvc class;  e.what %s", e.what());
		Event(ECAT_CONFIG, EVE_GENERIC| EVT_SYSERR, "At least one critical run time error has occurred. Service may not respond to incoming requests.");
	}
	catch(long)
	{
		throw_syserr_iffails(false);
	}
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// OnStopCleanup 
//
void 
ImDsSyncSvc::OnStopCleanup()
{
	try
	{
		if (m_pShutdownThread != NULL)
		{
			m_pShutdownThread->BeginThread();
		}

		ChangeStatus(SERVICE_STOP_PENDING,60000);

		ChangeStatus(SERVICE_STOP_PENDING);
	}
	catch(imstd::exception&)
	{
		;
	}
	catch(long)
	{
		;
	}
	m_bClean = true;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
