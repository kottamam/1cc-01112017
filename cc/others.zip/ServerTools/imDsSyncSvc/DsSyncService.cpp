//=============================================================================
// File: DsSyncService.cpp
//-----------------------------------------------------------------------------
// Date      Who  Modification
// --------  ---  -------------------------------------------------------------
// 03/07/02  MDL  Initial coding
//-----------------------------------------------------------------------------
// Copyright (C) 2002, iManage, Inc.
// PROPRIETARY AND CONFIDENTIAL
//=============================================================================


#include "stdafx.h"
#include "DsSyncService.h"
#include "ObjectModel.h"

#include <Verification\StackWalk.h>
#include <process.h>
#include <imLdap/imLdap.h>
#include <ShlObj.h>
#include <comutil.h>

extern DSOM::CSidMap g_SidMap;

using namespace IM;

using namespace iwSingletonLib;
#define ENCRYPT_KEY			"iManage Service"

//#############################################################################
//
//	DsSyncService
//
//#############################################################################


DsSyncService::DsSyncService() :
	m_databaseList(NULL),
	m_pPoolMgr(NULL)
{
}


DsSyncService::~DsSyncService()
{
	DWORD		dwExitCode = STILL_ACTIVE;

	//
	//	Shutdown monitor thread
	//
	if (m_hMonitorThread != NULL)
	{
		GetExitCodeThread(m_hMonitorThread, &dwExitCode);
		while (dwExitCode == STILL_ACTIVE)
		{
			WaitForSingleObject(m_hMonitorThread, INFINITE);
			GetExitCodeThread(m_hMonitorThread, &dwExitCode);
		}

		CloseHandle(m_hMonitorThread);
		m_hMonitorThread = NULL;
	}

	m_databaseList.ClearList();
}



void
DsSyncService::Init(HANDLE hStopEvent_, DBPoolMgr *pPoolMgr_, CDSSyncSvc *pServiceConfiguration_)
{
	unsigned int	uiThreadID;

	m_hStopEvent = hStopEvent_;
	m_pPoolMgr = pPoolMgr_;
	m_pServiceConfiguration = pServiceConfiguration_;

	// get registry info
	m_databaseList.LoadAll();
	pServiceConfiguration_->LoadFromRegistry( );

	ResetConnectionList( );

	// begin worker thread
	m_hMonitorThread = (HANDLE) _beginthreadex(NULL, 0, &monitorThread, (void *) this, 0, &uiThreadID);
}

void DsSyncService::ResetConnectionList( void )
{
	DSOM::CJediContext jc( "DsSyncService", "ResetConnectionList" );

	try
	{
		LogMsg( LOG_DEBUG, _T( "g_SidMap items %i" ), g_SidMap.Count() );
		g_SidMap.Reset();

		m_ConnectionList.clear( );
		for( CDSSyncSvc::CONNECTIONLIST::const_iterator iter = m_pServiceConfiguration->m_ConnectionList.begin( ); iter != m_pServiceConfiguration->m_ConnectionList.end( ); iter++ )
		{
			CDSSyncSvc_Connection* pConnection = *iter;
			if( pConnection != NULL )
			{
				m_ConnectionList.push_back( pConnection );

				CDSSyncSvc_AttributeMap* pAttributeMap = m_pServiceConfiguration->FindAttributeMap( pConnection->m_strAttributeMapName.Get( ).c_str( ) );

				// see if an entry for this connection exists in the context map
				// and if not, create one
				if( !m_ContextMap.IsMember( _bstr_t( pConnection->m_strName.Get( ).c_str( ) ) ) )
				{
					switch( pConnection->m_DSParameters.m_lServiceType.Get( ) )
					{
					case IM::CDSSyncSvc_DSParameters::Microsoft:
					case IM::CDSSyncSvc_DSParameters::Sun:
						m_ContextMap.Set( pConnection->m_strName.Get( ).c_str( ), im_new DSOM::CDSSyncContext( NULL, pConnection, pAttributeMap, m_pServiceConfiguration->m_lPageSize.Get( ) ) );
						break;

					case IM::CDSSyncSvc_DSParameters::Novell:
						m_ContextMap.Set( pConnection->m_strName.Get( ).c_str( ), im_new DSOM::CNDSSyncContext( NULL, pConnection, pAttributeMap ) );
						break;

					case IM::CDSSyncSvc_DSParameters::NT:
						m_ContextMap.Set( pConnection->m_strName.Get( ).c_str( ), im_new DSOM::CNTSyncContext( NULL, pConnection, pAttributeMap ) );
						break;
					}
				}
			}
		}
	}
	catch( DSOM::CBaseException& exception )
	{
		jc.LogMessage(exception);
	}
	catch(imstd::exception &e)
	{
		jc.LogMessage(e);
	}
	catch(long lErrorCode)
	{
		jc.LogMessage(lErrorCode);
	}
}

CDSSyncSvc_Connection* DsSyncService::GetNextConnection( void )
{
	DSOM::CJediContext jc( "DsSyncService", "GetNextConnection" );
	CDSSyncSvc_Connection* pConn = NULL;

	try
	{
		if( m_ConnectionList.empty( ) )
			ResetConnectionList( );

		if( !m_ConnectionList.empty( ) )
		{
			pConn = m_ConnectionList.front( );
			m_ConnectionList.pop_front( );
		}
	}
	catch( DSOM::CBaseException& exception )
	{
		pConn = NULL;
		jc.LogMessage(exception);
	}
	catch(imstd::exception &e)
	{
		pConn = NULL;
		jc.LogMessage(e);
	}
	catch(long lErrorCode)
	{
		pConn = NULL;
		jc.LogMessage(lErrorCode);
	}
	return pConn;
}



void
DsSyncService::dump(const char *szHeader)
{
}

unsigned __stdcall
DsSyncService::monitorThread(void *vp_)
{
	DsSyncService	*pDsSyncService = (DsSyncService *) vp_;
	DWORD		dwReturnCode;

	__try
	{
		while (1)
		{
			//
			// determine the difference between now and the next minute and wait till then
			// or till the stop event is fired
			//

			// temp debug
			dwReturnCode = WaitForSingleObject(pDsSyncService->m_hStopEvent, pDsSyncService->GetNextCycleSeconds( ) * 1000);
			//dwReturnCode = WaitForSingleObject(pDsSyncService->m_hStopEvent, 1 * 1000);

			switch (dwReturnCode)
			{
			case WAIT_TIMEOUT:
				pDsSyncService->monitorMain( );
				break;

			default:
				_endthreadex(0);

			}
		}
	}
	__except(NrtExceptionFilterForStackDump(GetExceptionInformation()))
	{
		LogMessage(LM_ERROR, TEXT("+++ Directory Service Synchronization Service Monitor Thread exception %0x; stopping service +++"), GetExceptionCode());
		SetEvent(pDsSyncService->m_hStopEvent);
	}


	return 0;
}

DSOM::CDSGeneric* DsSyncService::GetNewDSGenericInterface( CDSSyncSvc_Connection* pConnection, CDSSyncSvc_AttributeMap* pAttributeMap )
{
	DSOM::CJediContext jc( "DsSyncService", "GetNewDSGenericInterface" );
	DSOM::CDSGeneric* pDSGeneric = NULL;

	try
	{
		switch( pConnection->m_DSParameters.m_lServiceType.Get( ) )
		{
		case IM::CDSSyncSvc_DSParameters::Microsoft:
		case IM::CDSSyncSvc_DSParameters::Sun:
			pDSGeneric = im_new DSOM::CDSSyncInterface( m_pServiceConfiguration, pConnection, pAttributeMap );
			break;

		case IM::CDSSyncSvc_DSParameters::Novell:
			pDSGeneric = im_new DSOM::CNDSSyncInterface( pConnection, pAttributeMap );
			break;

		case IM::CDSSyncSvc_DSParameters::NT:
			pDSGeneric = im_new DSOM::CNTSyncInterface( pConnection, pAttributeMap );
			break;
		}

		if( pDSGeneric->Login( ) == DSOM_SUCCESS )
		{
			m_DSConnectionMap.Set( _bstr_t( pConnection->m_strName.Get( ).c_str( ) ), pDSGeneric );

			LogMsg( LOG_INFO, _T( "Login success for connection '%s'" ), ( LPCTSTR ) pConnection->m_strName.Get( ).c_str( ) );
		}
		else
		{
			LogMsg( LOG_ERROR, _T( "Login failure for connection '%s'" ), ( LPCTSTR ) pConnection->m_strName.Get( ).c_str( ) );

			if( pDSGeneric != NULL )
			{
				delete pDSGeneric;
				pDSGeneric = NULL;
			}
		}
	}
	catch( DSOM::CBaseException& exception )
	{
		pDSGeneric = NULL;
		jc.LogMessage(exception);
	}
	catch(imstd::exception &e)
	{
		pDSGeneric = NULL;
		jc.LogMessage(e);
	}
	catch(long lErrorCode)
	{
		pDSGeneric = NULL;
		jc.LogMessage(lErrorCode);
	}
	return pDSGeneric;
}

bool DsSyncService::TestDSGenericInterface( DSOM::CDSGeneric* pDSGeneric )
{
	// a test for each service provider
	// make a simple query
	// that shows we're still logged in and good to go

	DSOM::CJediContext jc( "DsSyncService", "TestDSGenericInterface" );

	bool retval = true;
	try
	{
		if( pDSGeneric == NULL )
			retval = false;
		else
		{
			if( pDSGeneric->TestConnection(retval) != DSOM_SUCCESS )
			{
				retval = false;
			}
		}
	}
	catch( DSOM::CBaseException& exception )
	{
		retval = false;
		jc.LogMessage(exception);
	}
	catch(imstd::exception &e)
	{
		retval = false;
		jc.LogMessage(e);
	}
	catch(long lErrorCode)
	{
		retval = false;
		jc.LogMessage(lErrorCode);
	}
	return retval;
}

void DsSyncService::DeleteCachedDSGenericInterface( CDSSyncSvc_Connection* pConnection )
{
	DSOM::CJediContext jc( "DsSyncService", "DeleteCachedDSGenericInterface" );
	DSOM::CDSGeneric* pDSGeneric = NULL;

	try
	{
		pDSGeneric = m_DSConnectionMap[ pConnection->m_strName.Get( ).c_str( ) ];
		if( pDSGeneric != NULL )
		{
			LogMsg( LOG_INFO, _T( "Deleting cached connection for '%s'" ), ( LPCTSTR ) pConnection->m_strName.Get( ).c_str( ) );

			// this deletes pointer
			m_DSConnectionMap.Remove( pConnection->m_strName.Get( ).c_str( ) );
		}
	}
	catch( DSOM::CBaseException& exception )
	{
		jc.LogMessage(exception);
	}
	catch(imstd::exception &e)
	{
		jc.LogMessage(e);
	}
	catch(long lErrorCode)
	{
		jc.LogMessage(lErrorCode);
	}
}


DSOM::CDSGeneric* DsSyncService::GetCachedDSGenericInterface( CDSSyncSvc_Connection* pConnection, CDSSyncSvc_AttributeMap* pAttributeMap )
{
	DSOM::CJediContext jc( "DsSyncService", "GetCachedDSGenericInterface" );

	bool bCached = false;
	DSOM::CDSGeneric* pDSGeneric = NULL;
	try
	{
		// get connection from map, if it exists
		pDSGeneric = m_DSConnectionMap[ pConnection->m_strName.Get( ).c_str( ) ];
		if( pDSGeneric == NULL )
		{
			LogMsg( LOG_INFO, _T( "Creating new connection for '%s'" ), ( LPCTSTR ) pConnection->m_strName.Get( ).c_str( ) );
			pDSGeneric = GetNewDSGenericInterface( pConnection, pAttributeMap );
		}
		else
		{
			bCached = true;
			LogMsg( LOG_INFO, _T( "Using cached connection for '%s'" ), ( LPCTSTR ) pConnection->m_strName.Get( ).c_str( ) );
		}

		if( pDSGeneric != NULL )
		{
			if( !TestDSGenericInterface( pDSGeneric ) )
			{
				if( bCached )
					LogMsg( LOG_INFO, _T( "Re-connecting cached connection (time out) for '%s'" ), ( LPCTSTR ) pConnection->m_strName.Get( ).c_str( ) );

				// this deletes pointer
				m_DSConnectionMap.Remove( pConnection->m_strName.Get( ).c_str( ) );

				pDSGeneric = GetNewDSGenericInterface( pConnection, pAttributeMap );
			}
			else
			{
				if( bCached )
					LogMsg( LOG_INFO, _T( "Cached connection tests OK for '%s'" ), ( LPCTSTR ) pConnection->m_strName.Get( ).c_str( ) );
				else
					LogMsg( LOG_INFO, _T( "Connection tests OK for '%s'" ), ( LPCTSTR ) pConnection->m_strName.Get( ).c_str( ) );
			}
		}
		else
		{
			// a NULL value means we couldn't login to LDAP server (probably invalid credentials)
		}
	}

	catch( DSOM::CBaseException& exception )
	{
		pDSGeneric = NULL;
		jc.LogMessage(exception);
	}
	catch(imstd::exception &e)
	{
		pDSGeneric = NULL;
		jc.LogMessage(e);
	}
	catch(long lErrorCode)
	{
		pDSGeneric = NULL;
		jc.LogMessage(lErrorCode);
	}

	return pDSGeneric;
}
/*******RAM******************/
void DsSyncService::authenticateConnection(CDSSyncSvc_Connection* pConnection)
{
	NrString token =  getFileToken(pConnection->m_strName.Get());
	if (token.length() == 0)
	{
		//Call iWSingleton and store it in file
		token = getTokenFromSingleton(pConnection);
		pConnection->strToken = token;
		WriteToTextFile(pConnection->m_strName.Get(),token);
	}
	else
		pConnection->strToken = token;

}

void DsSyncService::WriteToTextFile(NrCiString connectionName, IM::NrString strToken)
{
	try
	{
		EncryptedString eString(ENCRYPT_KEY);
		IM::NrString			strEncryptedString;

		eString.Encrypt(strToken.c_str(), strEncryptedString);

		
		TCHAR szPath[MAX_PATH];

		BOOL bVal = SHGetSpecialFolderPath(NULL, szPath, CSIDL_LOCAL_APPDATA, FALSE);

		IM::NrString filePath = szPath;
		filePath += "\\iManage\\Services\\ADFS";

		if (GetFileAttributes(filePath.c_str()) == INVALID_FILE_ATTRIBUTES)
			SHCreateDirectoryEx(NULL, filePath.c_str(), NULL);

		filePath += "\\";

		filePath += connectionName.c_str();
		filePath += ".tok";

		
		
		ofstream myfile;
		myfile.open(filePath.c_str());
		myfile << strEncryptedString;
		myfile.close();



		
	}
	catch (...)
	{

	}

}
IM::NrString DsSyncService::getTokenFromSingleton(CDSSyncSvc_Connection* pConnection)
{
	NrString strToken = L"";
	CoInitialize(NULL);
	try
	{
		HANDLE hSemaphore = CreateSemaphore(NULL, 1, 5, COMMON_AUTH_MUTEX_OBJECT);
		DWORD dwWaitObject  =WaitForSingleObject(hSemaphore, 60 * 100);

		if (dwWaitObject == WAIT_OBJECT_0)
		{

			ICommonAuthPtr pDispatch = NULL;
			HRESULT hr = CoCreateInstance(CLSID_CommonAuth, NULL, CLSCTX_LOCAL_SERVER, IID_ICommonAuth, (void **)&pDispatch);

			pDispatch->put_LOGINTYPE(LOGINTYPE::Saml);
			BSTR bstrCookie = SysAllocString(COMMON_AUTH_COOKIE);
			pDispatch->put_AppCookie(bstrCookie);

			DWORD processId = GetCurrentProcessId();

			BSTR bsrAppId = SysAllocString(L"");
			pDispatch->put_AppID(bsrAppId);
			pDispatch->put_TimeOut(60);
			_bstr_t bstrHostUrl = SysAllocString(_com_util::ConvertStringToBSTR(pConnection->m_DMSParameters.m_strServerURL.Get().c_str()));

			pDispatch->put_HostUri(bstrHostUrl);
			pDispatch->put_RestApiVersion(1);

			BSTR token = SysAllocString(L"");
			pDispatch->Execute(processId, &token);

			strToken = token;
		}
	}
	catch (...)
	{

	}
	CoUninitialize();
	return strToken;
}

IM::NrString DsSyncService::getFileToken(IM::NrCiString connectionName)
{
	IM::NrString strToken = L"";
	try
	{
		EncryptedString eString(ENCRYPT_KEY);
		IM::NrString			strDecryptedString;


		TCHAR szPath[MAX_PATH];

		BOOL bVal = SHGetSpecialFolderPath(NULL, szPath, CSIDL_LOCAL_APPDATA, FALSE);

		IM::NrString filePath = szPath;
		filePath += "\\iManage\\Services\\ADFS";


		filePath += "\\";

		filePath += connectionName.c_str();
		filePath += ".tok";
		const char* szFilePath = filePath.c_str();
		OFSTRUCT ofStruct;
		HFILE hFile = OpenFile(szFilePath, &ofStruct, OF_EXIST);
		if (hFile == (HFILE)INVALID_HANDLE_VALUE)
			return strToken;
		std::ifstream t(szFilePath);
		std::string str((std::istreambuf_iterator<char>(t)),
			std::istreambuf_iterator<char>());
		eString.Decrypt(str.c_str(), strDecryptedString);
		strToken = strDecryptedString;
	}
	catch (...)
	{

	}

	

	return strToken;

}

void DsSyncService::AuthenticateAllConnections()
{
	CDSSyncSvc_Connection* pConnection = NULL;
	try
	{
		if (m_ConnectionList.empty())
			return;
		else
		{
			pConnection = m_ConnectionList.front();
			m_ConnectionList.pop_front();
		}
		
		while (pConnection != NULL)
		{
			

			authenticateConnection(pConnection);

			//Get next from list
			if (m_ConnectionList.empty())
				break;
			else
			{
				pConnection = m_ConnectionList.front();
				m_ConnectionList.pop_front();
			}
		}
	}
	catch (...)
	{

	}
}
/*******RAM******************/
void
DsSyncService::monitorMain( void )
{
	DSOM::CJediContext jc( "DsSyncService", "monitorMain" );

	CDSSyncSvc_Connection* pConnection = NULL;
	DSOM::ICommunication* pDatabase = NULL;

	
	try
	{
		/*******RAM******************/
		AuthenticateAllConnections();
		ResetConnectionList();
		/*******RAM******************/
		pConnection = GetNextConnection( );
		if( pConnection != NULL )
		{
			// lookup attribute map for connection
			CDSSyncSvc_AttributeMap* pAttributeMap = m_pServiceConfiguration->FindAttributeMap( pConnection->m_strAttributeMapName.Get( ).c_str( ) );

			if (nullptr == pAttributeMap)
			{
				LogMsg(LOG_ERROR, _T("Attribute map %s not found."), pConnection->m_strAttributeMapName.Get().c_str());
				throw NRC_FAILURE;
			}

			// get context from map
			DSOM::CDSSyncContextGeneric* pSyncContext = m_ContextMap[ _bstr_t( pConnection->m_strName.Get( ).c_str( ) ) ];


			pDatabase = im_new DSOM::CMlibCommunication(pSyncContext);
			
		
			

			if( pDatabase->GetIsLoggedOn() )
			{
				DSOM::CDSGeneric* pDSGeneric = GetCachedDSGenericInterface( pConnection, pAttributeMap );

				if( ( pDSGeneric != NULL ) && ( pSyncContext != NULL ) && ( pDatabase != NULL ) )
				{
					// update persistent context objects with pointer to new CDSGeneric object
					pSyncContext->SetDSInterface( pDSGeneric );

					// ensure that synchronization always starts at first phase (even if interrupted by exception)
					pSyncContext->GetSyncState( ).ResetState();

					// perform synchronization algorithm
					DSOM::CSynchronizer Synchronizer(m_hStopEvent);
					switch( Synchronizer.Synchronize( pSyncContext, pDatabase ) )
					{
					case DSOM_SUCCESS:
						LogMsg( LOG_INFO, _T( "Synchronization success for connection '%s'" ), ( LPCTSTR ) pConnection->m_strName.Get( ).c_str( ) );
						break;
					case DSOM_FAILURE:
						LogMsg( LOG_ERROR, _T( "Synchronization failure for connection '%s'" ), ( LPCTSTR ) pConnection->m_strName.Get( ).c_str( ) );
						break;
					}
				}
				else if( pDSGeneric == NULL )
				{
					LogMsg( LOG_ERROR, _T( "Synchronization failure (unable to login and create DSOM::CDSGeneric object) for connection '%s'" ), ( LPCTSTR ) pConnection->m_strName.Get( ).c_str( ) );
				}
				else if( pSyncContext == NULL )
				{
					LogMsg( LOG_ERROR, _T( "Synchronization failure (unable to create DSOM::CDSSyncContextGeneric object) for connection '%s'" ), ( LPCTSTR ) pConnection->m_strName.Get( ).c_str( ) );
				}
				else if( pDatabase == NULL )
				{
					LogMsg( LOG_ERROR, _T( "Synchronization failure (unable to create DSOM::CDatabase object) for connection '%s'" ), ( LPCTSTR ) pConnection->m_strName.Get( ).c_str( ) );
				}
				else
				{
					LogMsg( LOG_ERROR, _T( "Synchronization failure (unable to create synchronization objects) for connection '%s'" ), ( LPCTSTR ) pConnection->m_strName.Get( ).c_str( ) );
				}
			}
			else
			{
				LogMsg( LOG_ERROR, _T( "Synchronization failure (unable to logon to database) for connection '%s'" ), ( LPCTSTR ) pConnection->m_strName.Get( ).c_str( ) );
			}

#ifdef _DEBUG
			//DeleteCachedDSGenericInterface( pConnection );
			//SetEvent(m_hStopEvent);
#endif
		}

		if( pDatabase )
		{
			delete pDatabase;
			pDatabase = NULL;
		}
	}

	catch( DSOM::CBaseException& exception )
	{
		if( pDatabase ) delete pDatabase;
		jc.LogMessage(exception);
		DeleteCachedDSGenericInterface( pConnection );
	}
	catch(imstd::exception &e)
	{
		if( pDatabase ) delete pDatabase;
		jc.LogMessage(e);
		DeleteCachedDSGenericInterface( pConnection );
	}
	catch(long lErrorCode)
	{
		if( pDatabase ) delete pDatabase;
		jc.LogMessage(lErrorCode);
		DeleteCachedDSGenericInterface( pConnection );
	}
}


#define		MODE_SCHEDULED		_T("S")
#define		MODE_CONTINUOUS		_T("C")
 
unsigned long
DsSyncService::GetNextCycleSeconds()
{

	long cycleMinutes = m_pServiceConfiguration->m_lCycleMinutes.Get();
	if( cycleMinutes == 0 )
		cycleMinutes = 1;

#ifdef _DEBUG
	// temp debug
	const unsigned long ulDefaultCycleSeconds = 0;

	//const unsigned long ulDefaultCycleSeconds = 15;
	//const unsigned long ulDefaultCycleSeconds = 60 * 60 * 3;		// 3 hours
	//const unsigned long ulDefaultCycleSeconds = 60 * 60 * 24 * 3;	// 3 days
#else
	//const unsigned long ulDefaultCycleSeconds = 60 * 60 * 3; // 3 hours

	const unsigned long ulDefaultCycleSeconds = cycleMinutes * 60;

#endif

	IM::CDSSyncSvc		serviceConfiguration(NULL);

	// Get the current schedule from the registry.
	serviceConfiguration.LoadFromRegistry();

	if (serviceConfiguration.m_strMode.Get().compare(MODE_CONTINUOUS) == 0)
	{
		if( m_ConnectionList.size( ) > 0 )
		{
			// connections remain ready to be serviced so service them immediately
			return(0);
		}
		else
		{
			// reset connection list
			ResetConnectionList( );

			// Reset counters.
			m_dtBeginTime = DateTime::Now();

			::LogMsg( LOG_INFO, "%d seconds until next synchronization.", ulDefaultCycleSeconds );

			return( ulDefaultCycleSeconds );
		}
	}
	
	// scheduled operation
		
	DateTime currentTime(DateTime::Now());

	const long lTimeSlotSeconds = 2 * 60 * 60;

	long lCurrentDayOfWeek = currentTime.GetDayOfWeek();
	if(lCurrentDayOfWeek > 6)
	{
		lCurrentDayOfWeek = 0;
	}

	const long lCurrentHour = currentTime.GetHour();
	const long lCurrentMinute = currentTime.GetMinute();
	const long lCurrentSecond = currentTime.GetSecond();
	const long lCurrentSlot = lCurrentHour / 2;
	const long lSlotStartHour = (lCurrentHour / 2) * 2;
	const unsigned long lSecondsRemainingInSlot = lTimeSlotSeconds  - ( (lCurrentHour - lSlotStartHour) * 3600 + lCurrentMinute * 60 + lCurrentSecond );

	// scheduled operation and current time is scheduled

	if (serviceConfiguration.m_bScheduleTable[lCurrentDayOfWeek][lCurrentSlot].Get())
	{
		if( m_ConnectionList.size( ) > 0 )
		{
			//
			// The current slot is scheduled and connections are ready to be serviced so don't wait
			//
			return(0);
		}
		else
		{
			//
			// The current slot is scheduled but connections are not available so wait
			//

			//
			// Reset counters.
			//
			m_dtBeginTime = DateTime::Now();

			::LogMsg(LOG_INFO, "%d seconds until next synchronization.", ulDefaultCycleSeconds);

			return(ulDefaultCycleSeconds);
		}
	}

	// scheduled operation but the current time is not scheduled

	long lSlotCount = 1;
	int j = lCurrentSlot + 1;
	for(int i = lCurrentDayOfWeek; i < 7; i++)
	{
		for(; j < 12; j++, lSlotCount++)
		{
			if(serviceConfiguration.m_bScheduleTable[i][j].Get())
			{
				// Reset counters.
				m_dtBeginTime = DateTime::Now();
				unsigned long ulNextCycleSeconds = lSecondsRemainingInSlot + (lSlotCount-1) * lTimeSlotSeconds;

				//
				// Verify that our wait time is less than or equal to a week. There are 604800 seconds in a week.
				//
				throw_assertion(ulNextCycleSeconds <= 604800);
				::LogMsg(LOG_INFO, "%d seconds until next synchronization.", ulNextCycleSeconds);

				return(ulNextCycleSeconds);
			}
		}
		j = 0;
	}

	for(int ii = 0; ii <= lCurrentDayOfWeek; ii++)
	{
		for(int jj = 0; jj < 12 && lSlotCount < 84; jj++, lSlotCount++)
		{
			if(serviceConfiguration.m_bScheduleTable[ii][jj].Get())
			{
				// Reset counters.
				m_dtBeginTime = DateTime::Now();

				unsigned long ulNextCycleSeconds = lSecondsRemainingInSlot + (lSlotCount-1) * lTimeSlotSeconds;

				//
				// Verify that our wait time is less than or equal to a week. There are 604800 seconds in a week.
				//
				throw_assertion(ulNextCycleSeconds <= 604800);
				::LogMsg(LOG_INFO, "%d seconds until next synchronization.", ulNextCycleSeconds);

				return(ulNextCycleSeconds);
			}
		}
	}

	::LogMsg(LOG_INFO, "%d seconds until next synchronization.", ulDefaultCycleSeconds);

	return(ulDefaultCycleSeconds);
}

