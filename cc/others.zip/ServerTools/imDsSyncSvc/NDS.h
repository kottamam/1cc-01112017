//=============================================================================
// File: NDS.h
//-----------------------------------------------------------------------------
// Date      Who  Modification
// --------  ---  -------------------------------------------------------------
// 04/5/02  MDL  Initial coding
//-----------------------------------------------------------------------------
// Copyright (C) 2002, iManage, Inc.
// PROPRIETARY AND CONFIDENTIAL
//=============================================================================


#pragma once

#include "StdAfx.h"
#include "ObjectModel.h"
#include <nwnet.h>
#include <nwlocale.h>

#include "ATL_CString.h"
//#include "dbIfc\dbGuiIfc.h"

namespace NDSOM
{


extern "C"
{
		//netwin32 functions
		typedef NWDSCCODE (N_API *NWDSCALLSINIT) ( nptr in, nptr out);
		typedef NWDSCCODE (N_API *NWDSCREATECONTEXTHANDLE) (NWDSContextHandle N_FAR *newHandle);
		typedef NWCCODE	(N_API *NWISDSAUTHENTICATED) (void);
		typedef NWDSCCODE (N_API *NWDSSETCONTEXT) (NWDSContextHandle context, nint key, nptr value);
		typedef NWDSCCODE (N_API *NWDSGETCONTEXT) (NWDSContextHandle context, nint key, nptr value);
		typedef NWDSCCODE (N_API *NWDSALLOCBUF) (size_t size, ppBuf_T buf);
		typedef NWDSCCODE (N_API *NWDSLIST) (NWDSContextHandle context, pnstr8 object, pnint32 interationHandle, pBuf_T subordinates);
		typedef NWDSCCODE (N_API *NWDSGETOBJECTCOUNT) (NWDSContextHandle context, pBuf_T buf, pnuint32 objectCount);
		typedef NWDSCCODE (N_API *NWDSGETOBJECTNAME) (NWDSContextHandle context, pBuf_T buf, pnstr8 objectName, pnuint32 attrCount, pObject_Info_T objectInfo);
		typedef NWDSCCODE (N_API *NWDSFREEBUF) (pBuf_T buf);
		typedef NWDSCCODE (N_API *NWDSFREECONTEXT) (NWDSContextHandle context);
		typedef NWDSContextHandle (N_API *NWDSCREATECONTEXT) (void);
		typedef NWDSCCODE (N_API *NWDSINITBUF) (NWDSContextHandle context, nuint32 operation, pBuf_T buf);
		typedef NWDSCCODE (N_API *NWDSPUTATTRNAME) (NWDSContextHandle context, pBuf_T buf, pnstr8 attrName);
		typedef NWDSCCODE (N_API *NWDSREAD) (NWDSContextHandle, pnstr8, nuint32, nbool8, pBuf_T, pnint32, pBuf_T);
		typedef NWDSCCODE (N_API *NWDSGETATTRNAME) (NWDSContextHandle, pBuf_T, pnstr8, pnuint32, pnuint32);
		typedef NWDSCCODE (N_API *NWDSGETATTRVAL) (NWDSContextHandle, pBuf_T, nuint32, nptr);
		typedef NWDSCCODE (N_API *NWDSGETATTRCOUNT) (NWDSContextHandle, pBuf_T, pnuint32);
		typedef NWDSCCODE (N_API *NWDSGETEFFECTIVERIGHTS) (NWDSContextHandle, pnstr8, pnstr8, pnstr8, pnuint32);
		typedef NWDSCCODE (N_API *NWDSAUTHENTICATE)( NWCONN_HANDLE conn, nflag32 optionsFlag, pNWDS_Session_Key_T sessionKey );
		typedef NWDSCCODE (N_API *NWDSAUTHENTICATECONN)(NWDSContextHandle context,NWCONN_HANDLE connHandle);
		typedef NWDSCCODE (N_API *NWDSCHANGEOBJECTPASSWORD)(NWDSContextHandle context,nflag32 optionsFlag,pnstr8 objectName,pnstr8 oldPassword,pnstr8 newPassword);
		typedef NWDSCCODE (N_API *NWDSGENERATEOBJECTKEYPAIR)(NWDSContextHandle contextHandle, pnstr8 objectName, pnstr8 objectPassword, nflag32 optionsFlag );
		typedef NWDSCCODE (N_API *NWDSLOGIN)(NWDSContextHandle context,nflag32 optionsFlag,pnstr8 objectName,pnstr8 password,nuint32 validityPeriod);
		typedef NWDSCCODE (N_API *NWDSLOGOUT)(NWDSContextHandle context);
		typedef NWDSCCODE (N_API *NWDSVERIFYOBJECTPASSWORD)(NWDSContextHandle context,nflag32 optionsFlag,pnstr8 objectName,pnstr8 password );
		typedef NWDSCCODE (N_API *NWDSOPENCONNTONDSSERVER)(   NWDSContextHandle context,   pnstr8            serverName,   pNWCONN_HANDLE    connHandle);
		typedef NWDSCCODE (N_API *NWDSGETDEFNAMECONTEXT)(   NWDSContextHandle context,   nuint             nameContextLen,   pnstr8            nameContext);
		typedef NWDSCCODE (N_API *NWDSSETDEFNAMECONTEXT)(   NWDSContextHandle context,   nuint             nameContextLen,   pnstr8            nameContext);
		typedef NWDSCCODE (N_API *NWDSGETMONITOREDCONNREF)(   NWDSContextHandle context,   pnuint32          connRef);
		typedef NWDSCCODE (N_API *NWDSOPENMONITOREDCONN)(   NWDSContextHandle context,   pNWCONN_HANDLE    connHandle);
		typedef NWDSCCODE (N_API *NWDSSCANCONNSFORTREES)(   NWDSContextHandle context,   nuint             numOfPtrs,   pnuint            numOfTrees,   ppnstr8           treeBufPtrs);
		typedef NWDSCCODE (N_API *NWDSSCANFORAVAILABLETREES)(   NWDSContextHandle context,   NWCONN_HANDLE     connHandle,   pnstr             scanFilter,   pnint32           scanIndex,   pnstr             treeName);
		typedef NWDSCCODE (N_API *NWDSRETURNBLOCKOFAVAILABLETREES)(   NWDSContextHandle context,   NWCONN_HANDLE     connHandle,   pnstr             scanFilter,   pnstr             lastBlocksString,   pnstr             endBoundString,   nuint32           maxTreeNames,              ppnstr            arrayOfNames,   pnuint32          numberOfTrees,   pnuint32          totalUniqueTrees);
		typedef NWDSCCODE (N_API *NWDSCANDSAUTHENTICATE)(   NWDSContextHandle context);
		typedef NWDSCCODE (N_API *NWDSPUTATTRVAL)( NWDSContextHandle context, pBuf_T buf, nuint32 syntaxID, nptr attrVal );
		typedef NWDSCCODE (N_API *NWDSADDOBJECT)( NWDSContextHandle context,    pnstr8            objectName,   pnint32           iterationHandle,   nbool8            more,   pBuf_T            objectInfo);
		typedef NWDSCCODE (N_API *NWDSADDFILTERTOKEN)(   pFilter_Cursor_T  cur,   nuint16           tok,   nptr              val,   nuint32           syntax);
		typedef NWDSCCODE (N_API *NWDSALLOCFILTER)(   ppFilter_Cursor_T cur);
		typedef NWDSCCODE (N_API *NWDSPUTFILTER)(   NWDSContextHandle       context,   pBuf_T                  buf,   pFilter_Cursor_T        cur,   void (N_FAR N_CDECL *freeVal)(nuint32 syntax, nptr val));
		typedef NWDSCCODE (N_API *NWDSSEARCH)(   NWDSContextHandle context,   pnstr8            baseObjectName,   nint              scope,   nbool8            searchAliases,   pBuf_T            filter,   nuint32           infoType,   nbool8            allAttrs,   pBuf_T            attrNames,   pnint32           iterationHandle,   nint32            countObjectsToSearch,   pnint32           countObjectsSearched,   pBuf_T            objectInfo);
		typedef NWDSCCODE (N_API *NWDSCOMPUTEATTRVALSIZE)(   NWDSContextHandle context,   pBuf_T            buf,   nuint32           syntaxID,   pnuint32          attrValSize);

		//locwin32.dll
		typedef LCONV N_FAR*  (N_API *NWLLOCALECONV) (LCONV N_FAR* lconvPtr);
		typedef  nint (N_API * NWINITUNICODETABLES) (nint countryCode, nint codePage);
		typedef  nint (N_API * NWFREEUNICODETABLES) (void);
};

/////////////////////////////////////////////////////
// CNdsWrapper

class CNdsWrapper
{
public:
	// default constructor
	CNdsWrapper( void );

	// destructor
	virtual ~CNdsWrapper( void );
	bool CheckDllFunctionPointers( void );

protected:
	HINSTANCE m_NWLibHandle;
	HINSTANCE m_NWLocalHandle;
	void InitDllFunctionPointers( void );

public:
        NWDSCALLSINIT ptrNWCallsInit;
		NWDSCREATECONTEXT ptrNWDSCreateContext;
        NWDSCREATECONTEXTHANDLE ptrNWDSCreateContextHandle;
        NWISDSAUTHENTICATED ptrNWIsDSAuthenticated;
        NWDSSETCONTEXT ptrNWDSSetContext;
        NWDSGETCONTEXT ptrNWDSGetContext;
		NWDSALLOCBUF ptrNWDSAllocBuf;
		NWDSLIST ptrNWDSList;
		NWDSGETOBJECTCOUNT ptrNWDSGetObjectCount;
		NWDSGETOBJECTNAME ptrNWDSGetObjectName;
		NWDSFREEBUF	ptrNWDSFreeBuf;
		NWDSFREECONTEXT	ptrNWDSFreeContext;
		NWDSINITBUF	ptrNWDSInitBuf;
		NWDSPUTATTRNAME	ptrNWDSPutAttrName;
		NWDSREAD ptrNWDSRead;
		NWDSGETATTRNAME ptrNWDSGetAttrName;
		NWDSGETATTRVAL ptrNWDSGetAttrVal;
		NWDSGETATTRCOUNT ptrNWDSGetAttrCount;
		NWDSGETEFFECTIVERIGHTS ptrNWDSGetEffectiveRights;
		NWDSAUTHENTICATE ptrNWDSAuthenticate;
		NWDSAUTHENTICATECONN ptrNWDSAuthenticateConn;
		NWDSCHANGEOBJECTPASSWORD ptrNWDSChangeObjectPassword;
		NWDSGENERATEOBJECTKEYPAIR ptrNWDSGenerateObjectKeyPair;
		NWDSLOGIN ptrNWDSLogin;
		NWDSLOGOUT ptrNWDSLogout;
		NWDSVERIFYOBJECTPASSWORD ptrNWDSVerifyObjectPassword;
		NWDSOPENCONNTONDSSERVER ptrNWDSOpenConnToNDSServer;
		NWDSGETDEFNAMECONTEXT ptrNWDSGetDefNameContext;
		NWDSSETDEFNAMECONTEXT ptrNWDSSetDefNameContext;
		NWDSGETMONITOREDCONNREF ptrNWDSGetMonitoredConnRef;
		NWDSOPENMONITOREDCONN ptrNWDSOpenMonitoredConn;
		NWDSSCANCONNSFORTREES ptrNWDSScanConnsForTrees;
		NWDSSCANFORAVAILABLETREES ptrNWDSScanForAvailableTrees;
		NWDSRETURNBLOCKOFAVAILABLETREES ptrNWDSReturnBlockOfAvailableTrees;
		NWDSCANDSAUTHENTICATE ptrNWDSSCanDSAuthenticate;
		NWDSPUTATTRVAL ptrNWDSPutAttrVal;
		NWDSADDOBJECT ptrNWDSAddObject;
		NWDSADDFILTERTOKEN ptrNWDSAddFilterToken;
		NWDSALLOCFILTER ptrNWDSAllocFilter;
		NWDSPUTFILTER ptrNWDSPutFilter;
		NWDSSEARCH ptrNWDSSearch;

		//locwin32.dll functions
		NWLLOCALECONV ptrNWLlocaleconv;
		NWINITUNICODETABLES ptrNWInitUnicodeTables;
		NWFREEUNICODETABLES	ptrNWFreeUnicodeTables;
		NWDSCOMPUTEATTRVALSIZE ptrNWDSComputeAttrValSize;
};



/////////////////////////////////////////////////////
// CNDS

class CNDS
{
public:
	// default constructor
	CNDS( void );

	// destructor
	virtual ~CNDS( void );

	// operations
	bool Login( LPCTSTR szContext, LPCTSTR szUid, LPCTSTR szPwd );
	bool Logout( void );
	bool ContextExists( LPCTSTR szContext );
	bool IsConnected( void );
	bool GetOrgUnits( LPCTSTR szContext, CDSORGUNITLIST& lstOU );
	bool GetUsers( LPCTSTR szContext, CDSUSERLIST& lstUser );
	bool GetGroups( LPCTSTR szContext, CDSGROUPLIST& lstGroup );
	bool GetGroupMembers( LPCTSTR szContext, CDSGroup& DSGroup );
	bool UserOrGroupExists( LPCTSTR szContext, LPCTSTR szObject );
	bool AddUser( const CDSUser& DSUser );	
	bool AddGroup( const CDSGroup& DSGroup );
	bool Search( LPCTSTR szContext, LPCTSTR szObject );

protected:
	CString m_strContext;
	CNdsWrapper m_NdsWrapper;

	// NDS members
	NWDSContextHandle m_context;
	NWDSCCODE m_ccode;
	NWCCODE	m_nwccode;
	LCONV m_lConvInfo;

	// helper methods
	void CanonicalizeDN( CString& strDN );
	void GetFirstValue( CString& strDN );
	CString GetFirstName( const CString& strFullName );
	CString GetLastName( const CString& strFullName );
	bool SetAttribute( pBuf_T& pBuf, LPCTSTR szAttributeName, nuint32 syntaxID, LPCTSTR szValue );
};




}	// namespace NDSOM