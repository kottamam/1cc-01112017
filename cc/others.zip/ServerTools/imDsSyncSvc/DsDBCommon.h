//=============================================================================
// File: DsDBCommon.h
//-----------------------------------------------------------------------------
// Date      Who  Modification
// --------  ---  -------------------------------------------------------------
// 03/21/02  MDL  Initial coding
//-----------------------------------------------------------------------------
// Copyright (C) 2002, iManage, Inc.
// PROPRIETARY AND CONFIDENTIAL
//=============================================================================

#pragma once

#if !defined(__IM_DSDBCOMMON_H__)
#define __IM_DSDBCOMMON_H__

#include <db\db.h>

class DsDBCommon:
	public DBCommon,
	public virtual IM::ObjectSignature
{
private:
	// default constructor
	DsDBCommon( void );

public:
	// standard constructor
	DsDBCommon( DBPoolMgr *pPoolMgr_, HANDLE hStopEvent_, HANDLE hAbortEvent_ );

	// destructor
	virtual ~DsDBCommon( void );

	// methods here

};



#endif	//	__IM_DSDBCOMMON_H__

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////