////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// File:	RestClientOptions.h
//
// Project: This file holds all of the compiling options
//
// Contents:	
//
//   Date    Who  Modification
// 07/23/17  Ram  Initial coding
//
// Copyright (C) 2001, iManage Technologies, Inc. ALL RIGHTS RESERVED
//                     PROPRIETARY AND CONFIDENTIAL
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef RESTCLIENT_OPTIONS_H
#define RESTCLIENT_OPTIONS_H

/* 
* Disable peer verification
*/
//#define SKIP_PEER_VERIFICATION

/* 
* Default CA bundle certificate path
* Use SetConfigurableOptions() to overwrite this during runtime.
*/
#ifndef SKIP_PEER_VERIFICATION
	#define CA_CERT_PATH ""
#endif

/* 
* Disable host name verification
*/
//#define SKIP_HOSTNAME_VERIFICATION

/* 
* Enable verbose
*/
#ifdef _DEBUG
	#define ENABLE_VERBOSE
#endif

/* 
* Enable profiling
*/
#define ENABLE_PERFORMANCE_PROFILING

/*
* Default performance profile log path. 
*/
#ifdef ENABLE_PERFORMANCE_PROFILING
	#define RESTCLIENT_PERF_LOG	""
#endif

/* 
* Enable HTTP content encoding/data compression
*/
#define ENABLE_CONTENT_ENCODING

/*
* Default content encoding algorithms to be used. 
* Use SetConfigurableOptions() to overwrite this during runtime.
*/
#ifdef ENABLE_CONTENT_ENCODING
	#define ACCEPT_ENCODING "gzip, deflate"
	#define TRANSFER_ENCODING "gzip, deflate"
#endif

/* Default timeout values
*  Use SetConfigurableOptions() to overwrite this during runtime.
*/
#define DEFAULT_CONNECTION_TIMEOUT_IN_SEC	15
#define DEFAULT_READ_TIMEOUT_IN_SEC			60

/* Default transfer speed low water mark
*  Use SetConfigurableOptions() to overwrite this during runtime.
*  Anything less than DEFAULT_LOW_SPEED_LIMIT bps during DEFAULT_READ_TIMEOUT_IN_SEC time period will be considered too slow and aborted.
*/
#define DEFAULT_LOW_SPEED_LIMIT				1024

#endif //RESTCLIENT_OPTIONS_H