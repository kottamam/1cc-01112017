#include "stdafx.h"
#pragma hdrstop

#include "fparse.h"
#include <ShlObj.h>

#import "References\iwADFS.tlb" raw_interfaces_only named_guids
using namespace iwADFS;

#define COMMON_AUTH_COOKIE _T("3CEEF535-CE6A-4C05-BEBC-333A5AC92E2C")
void ShowUsage();
void Setup(int argc, TCHAR** argv);
void InitLogFile();
BOOL  SAMLLogin();
BOOL isFileExists(CString szFilePath);
CString GetToken(CString filePath);
CString Relogin(CString filePath);
BOOL WriteToTextFile(CString csFilePath, BSTR bstrToken);
long g_lUUEncode = 0;

#ifdef _UNICODE
#define TCOUT	imstd::wcout
#else
#define TCOUT	imstd::cout
#endif

//some global variables
ResourceManager	g_resManager;
CString g_strDatabase, g_strUserID, g_strPassword, g_strFilename, g_strParentAlias,g_strLoginType,g_strServerURL;
BOOL g_bClientOnly = TRUE, g_bOverwrite = FALSE, g_bTruncate = FALSE;
TCHAR g_chDelimiter = _T('|');
ViewType _currentViewType = NONE;

int	g_iCols[8] = { 1, 2, 3, 4, 5, 6, 7, 8};
TCHAR	szSpChar[] = _T(" ,\'`\"~");

int _tmain(int argc, TCHAR** argv, TCHAR* envp[])
{
	HMODULE hModule = GetModuleHandle(NULL);
	
	AfxSetResourceHandle(hModule);
	Setup(argc, argv);
	
	InitLogFile();
	DBAdmin*	pAdmin = g_resManager.getDBAdmin();
	if(!pAdmin)
	{
		TCOUT << _T("Can't get dbadmin") << imstd::endl;
		exit(1);
	}
	if (g_strLoginType.CompareNoCase(_T("imanage")) == 0)
	{
		if (!pAdmin->Logon(g_strDatabase, g_strUserID, g_strPassword))
		{
			TCOUT << _T("Can't logon") << imstd::endl;
			exit(1);
		}
	}
	else
	{
		BOOL bVal = SAMLLogin();

	}

	pAdmin->SetCurrentDB(g_strDatabase);
	if(!pAdmin->IsIManageDB())
	{
		TCOUT << _T("It is not an WorkSite database") << imstd::endl;
		exit(1);
	}

	FILE	*inputFile = _tfopen(g_strFilename, _T("rt, ccs=UNICODE"));
	if (!inputFile)
	{
		TCOUT << _T("Can't open input file") << imstd::endl;
		return 0;
	}


	TCHAR	inputLine[2048];
	long	lLineCount = 0, nItems=0, lErr=0, lSuccess=0, lIgnore=0;
	CString strErr;
	CStringList	strTable;
	CStringList flagsTable;

	FieldParser	fieldparser;
	CString str1, str2, str3;
	TCOUT << _T("Begin loading...") << imstd::endl;

	while (_fgetts(inputLine, sizeof(inputLine), inputFile))
	{
		CString	strParse, strItem, strFlags;
		FIELDINFO	fieldinfo;
		lLineCount++;
		TCOUT << _T("Processing line #: ") << lLineCount << imstd::endl;
//		if (inputLine[_tcslen(inputLine)-1] != _T('\n'))
//		{
//			lLineCount--;
//			continue;
//		}

		//strip the string of the new line character if One is present
		if(inputLine[_tcslen(inputLine)-1] == 10) //10 which is equal to new line charector
			inputLine[_tcslen(inputLine)-1] = NULL;

		fieldparser.parseFields(inputLine, g_chDelimiter, &fieldinfo); 
		//client alias and matter alias are required fields
		if (fieldinfo.fieldCount==0 || (g_iCols[0]-1>fieldinfo.fieldCount) )
			continue;
		
		strParse = fieldinfo.fieldArray[g_iCols[0]-1];
		strParse.TrimLeft();
		strParse.TrimRight();
		strParse.MakeUpper();
		if (strParse.FindOneOf(szSpChar)!=-1)
		{
//			lLineCount--;
			continue;
		}
		strParse += _T('\n');
		if ( (g_iCols[1]-1<fieldinfo.fieldCount) && (g_iCols[1]>0) )
			strItem = fieldinfo.fieldArray[g_iCols[1]-1];
		strItem.TrimLeft();
		strItem.TrimRight();
		strParse += strItem + _T('\n');
	
		if ( (g_iCols[2]-1<fieldinfo.fieldCount) && (g_iCols[2]>0) )
		{
			strItem = fieldinfo.fieldArray[g_iCols[2]-1];
			strItem.TrimLeft();
			strItem.TrimRight();
			strItem.MakeUpper();
			if(strItem.Compare(_T("Y"))!=0 && strItem.Compare(_T("N"))!=0)
			{
				TCOUT << _T("Invalid enable flag ") << (LPCTSTR)strItem << _T(" for line ") << lLineCount;
				continue;
			}
		}
		else
			strItem = 'Y';
		strParse += strItem + _T('\n');
		strFlags += strItem + _T('\n');

		if ( (g_iCols[3]-1<fieldinfo.fieldCount) && (g_iCols[3]>0) )
		{
			strItem = fieldinfo.fieldArray[g_iCols[3]-1];
			strItem.TrimLeft();
			strItem.TrimRight();
			strItem.MakeUpper();
			if(strItem.Compare(_T("Y"))!=0 && strItem.Compare(_T("N"))!=0)
			{
				TCOUT << _T("Invalid hipaa flag ") << (LPCTSTR)strItem << _T(" for line ") << lLineCount;
				continue;
			}
		}
		else
			strItem = 'N';
		strParse += strItem + _T('\n');
		strFlags += strItem + _T('\n');
		if (g_bClientOnly==1)
		{
			strItem = fieldinfo.fieldArray[g_iCols[4]-1];
			strItem.TrimLeft();
			strItem.TrimRight();
			strItem.MakeUpper();
			if(strItem.FindOneOf(szSpChar)!=-1)
				continue;
			strParse += strItem + _T('\n');
			if ( (g_iCols[5]-1<fieldinfo.fieldCount) && (g_iCols[5]>0))
				strItem = fieldinfo.fieldArray[g_iCols[5]-1];
			strItem.TrimLeft();
			strItem.TrimRight();
			strParse += strItem + _T('\n');
			if ( (g_iCols[6]-1<fieldinfo.fieldCount) && (g_iCols[6]>0))
			{
				strItem = fieldinfo.fieldArray[g_iCols[6]-1];
				strItem.TrimLeft();
				strItem.TrimRight();
				strItem.MakeUpper();
				if(strItem.Compare(_T("Y"))!=0 && strItem.Compare(_T("N"))!=0)
				{
					TCOUT << _T("Invalid enable flag ") << (LPCTSTR)strItem << _T(" for line ") << lLineCount;
					continue;
				}
			}
			else
				strItem = 'Y';
			strParse += strItem + _T('\n');
			strFlags += strItem + _T('\n');

			if ( (g_iCols[7]-1<fieldinfo.fieldCount) && (g_iCols[7]>0))
			{
				strItem = fieldinfo.fieldArray[g_iCols[7]-1];
				strItem.TrimLeft();
				strItem.TrimRight();
				strItem.MakeUpper();
				if(strItem.Compare(_T("Y"))!=0 && strItem.Compare(_T("N"))!=0)
				{
					TCOUT << _T("Invalid hipaa flag ") << (LPCTSTR)strItem << _T(" for line ") << lLineCount;
					continue;
				}
			}
			else
				strItem = 'N';
			strParse += strItem + _T('\n');
			strFlags += strItem + _T('\n');
		}
		nItems++;
		strTable.AddTail(strParse);
		flagsTable.AddTail(strFlags);
		if (nItems>=50) {
//			if ((_currentViewType == CUSTOM1) || (_currentViewType == CUSTOM29))
				pAdmin->ImportIntoTable(strTable, _currentViewType, lErr, 
					lSuccess, lIgnore, g_strParentAlias, g_bOverwrite, g_bTruncate);
			nItems=0;
		}
	}
	if (nItems>0)
	{
//		if ((_currentViewType == CUSTOM1) || (_currentViewType == CUSTOM29))
			pAdmin->ImportIntoTable(strTable, _currentViewType, lErr, 
				lSuccess, lIgnore, g_strParentAlias, g_bOverwrite, g_bTruncate);
	}
	fclose(inputFile);

	str1.Format(_T("Entries Successfully Updated or Inserted: %ld\nErrors: %ld\n"), lSuccess, lErr);
	TCOUT << (const TCHAR*) str1 << imstd::endl;
	if(g_bOverwrite)
	{
		LogMsg(LOG_INFO, _T("Load Table Options: Filename %s:"), (LPCTSTR)g_strFilename);
		LogMsg(LOG_INFO, _T("Load Table Options: Overwrite Mode"));
		if(g_bClientOnly==0)
		{
			LogMsg(LOG_INFO, _T("Load Table Options: Import Client Only"));
			LogMsg(LOG_INFO, _T("Load Table Options: Delimiter \"%c\", Client Alias Field Number: %d, \
				Client Desc. Field Number: %d"), g_chDelimiter, g_iCols[0], g_iCols[1]);
		}
		else
		{
			LogMsg(LOG_INFO, _T("Load Table Options: Import Client and Matter"));
			LogMsg(LOG_INFO, _T("Load Table Options: Delimiter \"%c\", Client Alias Field Number %d: \
				Client Desc. Field Number %d, Matter Alias Field Number: %d, Matter Desc. Field Number: %d"), \
				g_chDelimiter, g_iCols[0], g_iCols[1], g_iCols[2], g_iCols[3]);
		}
		
		LogMsg(LOG_INFO, _T("Load Table Log: Entries Loaded %ld, Errors %ld, Entries Ignored %ld"), lSuccess, lErr, lIgnore);
	}
	else
	{
		LogMsg(LOG_INFO, _T("Load Table Options: Filename %s:"), (LPCTSTR)g_strFilename);
		LogMsg(LOG_INFO, _T("Load Table Options: Non-Overwrite Mode"));
		if(g_bClientOnly==0)
		{
			LogMsg(LOG_INFO, _T("Load Table Options: Import Client Only"));
			LogMsg(LOG_INFO, _T("Load Table Options: Delimiter \"%c\", Client Alias Field Number %d: \
				Client Desc. Field Number %d"), g_chDelimiter, g_iCols[0], g_iCols[1]);
		}
		else
		{
			LogMsg(LOG_INFO, _T("Load Table Options: Import Client and Matter"));
			LogMsg(LOG_INFO, _T("Load Table Options: Delimiter \"%c\", Client Alias Field Number %d: \
				Client Desc. Field Number: %d, Matter Alias Field Number: %d, Matter Desc. Field Number: %d"), \
				g_chDelimiter, g_iCols[0], g_iCols[1], g_iCols[2], g_iCols[3]);
		}
		
		LogMsg(LOG_INFO, _T("Load Table Log: Entries Loaded %ld, Errors %ld, Entries Ignored %ld"), lSuccess, lErr, lIgnore);
	}
	
	return 0;
}

BOOL SAMLLogin()
{
	try
	{
		TCHAR szPath[MAX_PATH];
		BOOL bVal = SHGetSpecialFolderPath(NULL, szPath, CSIDL_LOCAL_APPDATA, FALSE);

		CString filePath = szPath;
		filePath += "\\iManage\\Services\\ADFS\\";
		filePath += g_strUserID;
		filePath += "clload.tok";
		CString csToken = _T("");
		if (!isFileExists(filePath))
		{
			//Bring up login again
			csToken = Relogin(filePath);
			if (csToken.GetLength() > 0)
			{
				CComBSTR bstrParam(csToken);
				WriteToTextFile(filePath, bstrParam);
				//call mlib here
			}
		}
		else
		{
			CString csToken = GetToken(filePath);
			if (csToken.GetLength() > 0)
			{
				
				//call mlib here
			}

		}
		

		

	}
	catch (...)
	{

	}
	return true;
}
CString GetToken(CString filePath)
{
	CString csToken = _T("");
	try
	{
		EncryptedString eString(ENCRYPT_KEY);
		IM::NrString			strDecryptedString;
		CString encryptedString = _T("");
		CStdioFile file;
		if (!file.Open(filePath, CFile::modeRead))
			return csToken;
		if (!file.ReadString(encryptedString))
			return csToken;


		eString.Decrypt(encryptedString, strDecryptedString);
		csToken = strDecryptedString.c_str();

	}
	catch (...)
	{

	}
	return csToken;
}

CString Relogin(CString filePath)
{
	CString csToken = _T("");
	// TODO: Add your control notification handler code here
	CoInitialize(NULL);
	try
	{
		ICommonLoginAuthenticator* pDispatch = NULL;
		HRESULT hr = CoCreateInstance(CLSID_CommonLoginAuthenticator, NULL, CLSCTX_INPROC_SERVER, IID_ICommonLoginAuthenticator, (void **)&pDispatch);
		if (pDispatch == NULL)
		{
			MessageBox(NULL,_T("ADFS class could not be instantiated. Please check whether the required dll is present and registered"),_T("Clload"),MB_OK);
			return csToken;
		}

		
		pDispatch->put_LoginType(CommonLoginTypes::CommonLoginTypes_Saml);
		BSTR bstrCookie = SysAllocString(COMMON_AUTH_COOKIE);
		pDispatch->put_AppCookie(bstrCookie);

		DWORD processId = GetCurrentProcessId();
		pDispatch->put_ClientProcId(processId);
		BSTR bsrAppId = SysAllocString(_T(""));
		pDispatch->put_AppID(bsrAppId);
		pDispatch->put_TimeOut(60);
		CComBSTR bstrHostUrl(g_strServerURL);

		pDispatch->put_HostUri(bstrHostUrl);
		pDispatch->put_RestApiVersion(1);

		BSTR token = SysAllocString(_T(""));
		hr = pDispatch->Execute(&token);
		if (hr != S_OK || SysStringLen(token) == 0)
		{
			MessageBox(NULL,_T("Unable to get the token, please contact administrator"),_T("CLLOAD"),MB_OK);
			return csToken;
		}
		csToken = token;
		

	}
	catch (...)
	{

	}
	CoUninitialize();
	return csToken;
}

BOOL WriteToTextFile(CString csFilePath,BSTR bstrToken)
{
	CStdioFile file;
	BOOL bWritten = FALSE;
	try
	{
		EncryptedString eString(ENCRYPT_KEY);
		IM::NrString			strEncryptedString;

		eString.Encrypt(bstrToken, strEncryptedString);

		CString specialPath = _T("");
		
		const wchar_t* szFilePath = LPCTSTR(csFilePath);



		if (file.Open(szFilePath, CFile::modeCreate | CFile::modeWrite) == TRUE)
		{
			file.WriteString(strEncryptedString.c_str());
			file.Close();
		}
		bWritten = TRUE;

	}
	catch (...)
	{
		if (HANDLE(file) != INVALID_HANDLE_VALUE)
			file.Close();
	}
	return bWritten;



}

BOOL isFileExists(CString szFilePath)
{
	
	return PathFileExists(szFilePath);

}

void ShowUsage()
{
	TCOUT << imstd::endl;
	TCOUT << _T("Load data into custom tables ") << imstd::endl << imstd::endl;
	TCOUT << _T("clload </db:database userid password> </file:filename> </table:name>") << imstd::endl;
	TCOUT << _T(" [/parentAlias:parentalias] [/overwrite:flag] [/childflag:flag] [/format:[\"[delimiter]\"][column1][column2][column3][column4]]") << imstd::endl;
	TCOUT << _T("/db:          specify the database name") << imstd::endl;
	TCOUT << _T("/userid:          specify the login id (required for imanage login only)") << imstd::endl;
	TCOUT << _T("/password:          specify the password(required for imanage login only)") << imstd::endl;
	TCOUT << _T("/file:        filename for importing data") << imstd::endl;
	TCOUT << _T("/table:       specify the table name which the data is loaded into CUSTOM1 to CUSTOM30") << imstd::endl;
	TCOUT << _T("/parentalias: specify the parent alias for child custom table") << imstd::endl;
	TCOUT <<	_T("              required for CUSTOM2 and CUSTOM30, ignored for others") << imstd::endl;
	TCOUT << _T("/overwrite:   overwrite description field or not if alias exits. Must be Y or N. Default N") << imstd::endl;
	TCOUT << _T("/truncate:    truncate(if length exceeds than defined) description field or not if alias exits. Must be Y or N. Default N") << imstd::endl;
	TCOUT << _T("/childflag:   load only parent table or both parent and child table") << imstd::endl;
	TCOUT << _T("              Y for both and N for parent table only. Default Y") << imstd::endl;
	TCOUT << _T("/logintype:   saml or imanage(default imanage)") << imstd::endl;
	TCOUT << _T("/serverurl:   base url of worksite server (required in case of SAML login type)") << imstd::endl;
	TCOUT << _T("/format:      corresponding file column data to table fields") << imstd::endl;
	TCOUT << _T(" delimiter:   delimiter column, default to |") << imstd::endl;
	TCOUT << _T(" column1:     column number for custom alias field, default to 1") << imstd::endl;
	TCOUT << _T(" column2:     column number for custom description field, default to 2") << imstd::endl;
	TCOUT << _T(" column3:     column number for custom enable flag, default to 3") << imstd::endl;
	TCOUT << _T(" column4:     column number for custom hipaa flag, default to 4") << imstd::endl;
	TCOUT << _T(" column5:     column number for custom child alias field, default to 5") << imstd::endl;
	TCOUT << _T(" column6:     column number for custom child description field, default to 6") << imstd::endl;
	TCOUT << _T(" column7:     column number for custom child enable flag, default to 7") << imstd::endl;
	TCOUT << _T(" column8:     column number for custom child hipaa flag, default to 8") << imstd::endl << imstd::endl;

	TCOUT << _T("Examples:") << imstd::endl;
	TCOUT << _T("clload /db:ntdb sa \"\" /table:CUSTOM1 /file:c:\\temp\\climat.txt") << imstd::endl;
	TCOUT << _T("       /overwrite:Y /childflag:n /format:\",\" 1 2 3 4 5 6 7 8") << imstd::endl;
	TCOUT << _T("clload /db:ntdb sa \"\" /table:CUSTOM2 /parentAlias:000002 /file:c:\\temp\\climat.txt") << imstd::endl;
	TCOUT << _T("       /overwrite:Y /childflag:n /format:\",\" 1 2 3 4") << imstd::endl;
	TCOUT << _T("clload /db:ntdb sa \"\" /table:CUSTOM3 /file:c:\\temp\\climat.txt") << imstd::endl;
	TCOUT << _T("       /overwrite:Y /childflag:n /format:\",\" 1 2 3 4") << imstd::endl;
	exit(1);
}

void Setup(int argc, TCHAR** argv)
{
	if(argc==1 || _tcsicmp(argv[1], _T("/?"))==0)
	{
		ShowUsage();
		return;
	}
	g_strLoginType = _T("imanage");
	int i= 1;
	CString str;
	//check the first options
	do
	{
		if(argc<=i)
			break;
		else if(_tcsnicmp(argv[i], _T("/db:"), 4)==0)
		{
			str = argv[i];
			g_strDatabase = str.Right(str.GetLength()-4);

			
			
		}
		else if ((_tcsnicmp(argv[i], _T("/userid:"), 8) == 0))
		{
			str = argv[i];
			str = str.Right(str.GetLength() - 8);
			g_strUserID = str;

		}
		else if ((_tcsnicmp(argv[i], _T("/password:"), 10) == 0))
		{
			str = argv[i];
			str = str.Right(str.GetLength() - 10);
			g_strPassword = str;

		}
		else if(_tcsnicmp(argv[i], _T("/table:"), 7)==0)
		{
			str = argv[i];
			str = str.Right(str.GetLength()-7);

			if(_tcsicmp((LPCTSTR)str, _T("custom1"))==0)
				_currentViewType = CUSTOM1;
			else if (_tcsicmp((LPCTSTR)str, _T("custom2"))==0)
				_currentViewType = CUSTOM2;
			else if (_tcsicmp((LPCTSTR)str, _T("custom3"))==0)
				_currentViewType = CUSTOM3;
			else if (_tcsicmp((LPCTSTR)str, _T("custom4"))==0)
				_currentViewType = CUSTOM4;
			else if (_tcsicmp((LPCTSTR)str, _T("custom5"))==0)
				_currentViewType = CUSTOM5;
			else if (_tcsicmp((LPCTSTR)str, _T("custom6"))==0)
				_currentViewType = CUSTOM6;
			else if (_tcsicmp((LPCTSTR)str, _T("custom7"))==0)
				_currentViewType = CUSTOM7;
			else if (_tcsicmp((LPCTSTR)str, _T("custom8"))==0)
				_currentViewType = CUSTOM8;
			else if (_tcsicmp((LPCTSTR)str, _T("custom9"))==0)
				_currentViewType = CUSTOM9;
			else if (_tcsicmp((LPCTSTR)str, _T("custom10"))==0)
				_currentViewType = CUSTOM10;
			else if (_tcsicmp((LPCTSTR)str, _T("custom11"))==0)
				_currentViewType = CUSTOM11;
			else if (_tcsicmp((LPCTSTR)str, _T("custom12"))==0)
				_currentViewType = CUSTOM12;
			else if (_tcsicmp((LPCTSTR)str, _T("custom29"))==0)
				_currentViewType = CUSTOM29;
			else if (_tcsicmp((LPCTSTR)str, _T("custom30"))==0)
				_currentViewType = CUSTOM30;
			else 
			{
				TCOUT << _T("Invalid Table Type") << imstd::endl;
				exit(1);
			}	
		}
		else if(_tcsnicmp(argv[i], _T("/parentAlias:"), 13)==0)
		{
			str = argv[i];
			g_strParentAlias = str.Right(str.GetLength()-13);
		}
		else if(_tcsnicmp(argv[i], _T("/file:"), 6)==0)
		{
			str = argv[i];
			g_strFilename = str.Right(str.GetLength()-6);
			if(g_strFilename.IsEmpty())
			{
				TCOUT << _T("Error: empty filename!") << imstd::endl;
				ShowUsage();
				return;
			}
		}
		else if(_tcsnicmp(argv[i], _T("/format:"), 8)==0)
		{
			str = argv[i];
			str = str.Right(str.GetLength()-8);
			if(str.GetLength()==1)
			{
				g_chDelimiter = str[0];
			}
			else if(str.GetLength()!=0)
			{
				TCOUT << _T("Error: invalid delimiter!") << imstd::endl;
				ShowUsage();
				return;
			}


			i++;
			if(argc>i)
			{
				if(argc>i)
				{
					str = argv[i];
					if(str.IsEmpty() || str[0]=='/')
					{
						continue;
					}
					g_iCols[0] = _ttol(argv[i++]);
				}
				
				if(argc>i)
				{
					str = argv[i];
					if(str.IsEmpty() || str[0]=='/')
					{
						continue;
					}
					g_iCols[1] = _ttol(argv[i++]);
				}
				
				if(argc>i)
				{
					str = argv[i];
					if(str.IsEmpty() || str[0]=='/')
					{
						continue;
					}
					g_iCols[2] = _ttol(argv[i++]);
				}
				
				if(argc>i)
				{
					str = argv[i];
					if(str.IsEmpty() || str[0]=='/')
					{
						continue;
					}
					g_iCols[3] = _ttol(argv[i++]);
				}

				if(argc>i)
				{
					str = argv[i];
					if(str.IsEmpty() || str[0]=='/')
					{
						continue;
					}
					g_iCols[4] = _ttol(argv[i++]);
				}

				if(argc>i)
				{
					str = argv[i];
					if(str.IsEmpty() || str[0]=='/')
					{
						continue;
					}
					g_iCols[5] = _ttol(argv[i++]);
				}
				if(argc>i)
				{
					str = argv[i];
					if(str.IsEmpty() || str[0]=='/')
					{
						continue;
					}
					g_iCols[6] = _ttol(argv[i++]);
				}
				if(argc>i)
				{
					str = argv[i];
					if(str.IsEmpty() || str[0]=='/')
					{
						continue;
					}
					g_iCols[7] = _ttol(argv[i++]);
				}

				if(g_iCols[0]==0 || g_iCols[1]==0 || g_iCols[2]==0 || g_iCols[3]==0 || g_iCols[4]==0 || g_iCols[5]==0 || g_iCols[6]==0 || g_iCols[7]==0)
				{
					TCOUT<< _T("Column number can't be 0") << imstd::endl;
					ShowUsage();
					exit(1);
				}		
			}
		}
		else if(_tcsnicmp(argv[i], _T("/Truncate:"), 10) == 0)
		{
			str = argv[i];
			str = str.Right(str.GetLength() - 10);
			if(str.GetLength() != 1)
			{
				TCOUT << _T("Error: invalid overwrite flag") << imstd::endl;
				ShowUsage();
				return;
			}

			if(str[0] == 'Y' || str[0] == 'y')
			{
				g_bTruncate = TRUE;
			}
			else if(str[0] == 'N' || str[0] == 'n')
			{
				g_bTruncate = FALSE;
			}
			else
			{
				TCOUT << _T("Error: invalid overwrite flag") << imstd::endl;
				ShowUsage();
				return;
			}
		}
		else if(_tcsnicmp(argv[i], _T("/overwrite:"), 11)==0)
		{
			str = argv[i];
			str = str.Right(str.GetLength()-11);
			if(str.GetLength()!=1)
			{
				TCOUT << _T("Error: invalid overwrite flag") << imstd::endl;
				ShowUsage();
				return;
			}

			if(str[0]=='Y' || str[0]=='y')
			{
				g_bOverwrite = TRUE;
			}
			else if(str[0]=='N' || str[0]=='n')
			{
				g_bOverwrite = FALSE;
			}
			else
			{
				TCOUT << _T("Error: invalid overwrite flag") << imstd::endl;
				ShowUsage();
				return;
			}
		}
		else if(_tcsnicmp(argv[i], _T("/childflag:"), 11)==0)
		{
			str = argv[i];
			str = str.Right(str.GetLength()-11);
			if(str.GetLength()!=1)
			{
				TCOUT << _T("Error: invalid client only flag") << imstd::endl;
				ShowUsage();
				return;
			}

			if(str[0]=='Y' || str[0]=='y')
			{
				g_bClientOnly = TRUE;
			}
			else if(str[0]=='N' || str[0]=='n')
			{
				g_bClientOnly = FALSE;
			}
			else
			{
				TCOUT << _T("Error: invalid client only flag") << imstd::endl;
				ShowUsage();
				return;
			}
		}
		else if (_tcsnicmp(argv[i], _T("/logintype:"), 11) == 0)
		{
			str = argv[i];
			str = str.Right(str.GetLength() - 11);
			if (str.CompareNoCase(_T("saml")) != 0 && str.CompareNoCase(_T("imanage")) != 0)
			{
				TCOUT << _T("Error: invalid logintype") << imstd::endl;
				ShowUsage();
				return;
			}

			g_strLoginType = str;
			

		}
		else if (_tcsnicmp(argv[i], _T("/serverurl:"), 11) == 0)
		{
			str = argv[i];
			str = str.Right(str.GetLength() - 11);

			g_strServerURL = str;


		}
		i++;
	} while(argc>i);



	if(g_strDatabase.IsEmpty())
	{
		TCOUT << _T("Error: database name is missing!") << imstd::endl;
		ShowUsage();
		return;
	}
	if (g_strLoginType.CompareNoCase(_T("imanage")) == 0)
	{
		if (g_strUserID.IsEmpty())
		{
			TCOUT << _T("Error: user ID is missing!") << imstd::endl;
			ShowUsage();
			return;
		}
	}
	if (g_strLoginType.CompareNoCase(_T("imanage")) == 0)
	{
		if (g_strPassword.IsEmpty())
		{
			TCOUT << _T("Error: password is missing!") << imstd::endl;
			ShowUsage();
			return;
		}
	}
	if (g_strLoginType.CompareNoCase(_T("saml")) == 0)
	{
		if (g_strServerURL.IsEmpty())
		{
			TCOUT << _T("Error: user ID is missing!") << imstd::endl;
			ShowUsage();
			return;
		}
	}

	if(g_strFilename.IsEmpty())
	{
		TCOUT << _T("Error: filename is missing!") << imstd::endl;
		ShowUsage();
		return;
	}

	if(_currentViewType==NONE)
	{
		TCOUT << _T("Error: table name is missing!") << imstd::endl;
		ShowUsage();
		return;
	}

	if(_currentViewType==CUSTOM2 || _currentViewType==CUSTOM30)
	{
		if(g_strParentAlias.IsEmpty())
		{
			TCOUT << _T("Error: parent alias is missing!") << imstd::endl;
			ShowUsage();
			return;
		}
	}

	if(_currentViewType!=CUSTOM1 && _currentViewType!=CUSTOM29)
	{
		g_bClientOnly = FALSE;
	}

	if(g_chDelimiter=='\"')
	{
		TCOUT << _T("Error: delimiter can't be \"!") << imstd::endl;
		ShowUsage();
		return;
	}
}

void InitLogFile()
{
	TCHAR path_buffer[_MAX_PATH];   
	TCHAR drive[_MAX_DRIVE];   
	TCHAR dir[_MAX_DIR];
	TCHAR fname[_MAX_FNAME];   
	TCHAR ext[_MAX_EXT];

	GetModuleFileName(GetModuleHandle(NULL), path_buffer, MAX_PATH);

	_tsplitpath(path_buffer, drive, dir, fname, ext);   

	CString path = drive;
	CString strNULL;
	path += dir;

	TCHAR	szPath[MAX_PATH];
	HKEY	hKey;
	DWORD	size = MAX_PATH;
	if( RegOpenKey(HKEY_LOCAL_MACHINE, _T("Software\\Interwoven\\Worksite\\Server Common"), &hKey) == ERROR_SUCCESS )
	{
		DWORD	dwType;
		if ( RegQueryValueEx(hKey, _T("Install Path"), 0, &dwType, (LPBYTE) szPath, &size) == ERROR_SUCCESS )
		{
			RegCloseKey(hKey);
			path = szPath;
			if (!path.IsEmpty() && path.GetAt(path.GetLength()-1) != _T('\\'))
			{
				path += _T('\\');
			}
			path += fname;
			path += _T(".log");
		}
		else
		{
			path += fname;
			path += _T(".log");
		}
	}
	else
	{
		path += fname;
		path += _T(".log");
	}

	LogMsgInit(path);
}