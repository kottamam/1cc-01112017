#if !defined(_STDAFX_H_INCLUDED)
#define _STDAFX_H_INCLUDED

#pragma once

// For building with VS2008 and stlPort51
#ifdef WSNT_VS2008	//	********************* VS2008 ******************************************************************************
#include <WSNT_VS2008.h>
#endif	// WSNT_VS2008	********************* VS2008 ******************************************************************************

#include <afx.h>			// MFC
#include <afxwin.h>         // MFC core and standard components
#include <AFXPRIV.H>

#include <sqlext.h>
#include <resource.h>
#include <winsvc.h>
#include <nwalias.h>

enum ViewType
{ 
	USER, vtGROUP, ROLE, TYPE, CLASSTYPE, STOPWORDS,
	APP, PCLOCATION, CUSTOM1, CUSTOM2, CUSTOM3, CUSTOM4,
	CUSTOM5, CUSTOM6, CUSTOM7, CUSTOM8, CUSTOM9,
	CUSTOM10, CUSTOM11, CUSTOM12, CUSTOM29, CUSTOM30, SUBCLASS, 
	ROLE_PROFILES, ROLE_PROFILE_ID, LIBRARY, DOCUMENTSERVER, INDEXFILESERVER, SECURITY_TEMPLATE, NONE
};

#define	 NUMADD_CUSTOMFIELDS	26
#include <collect\db.h>
#include <toolService/ServiceMain.h>
#include <dbifc/main.h>
#include <lm.h>
#include <netclass\ntnetsrv.h>
#include "dbIfc\dbGuiIfc.h"
#include <netclass\NTADMIN.H>

#endif