//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by clload.rc
//
#define NRT_IDS_STRING5000              5000
#define NRT_IDS_STRING5020              5020
#define NRT_IDS_STRING5142              5142
#define NRT_IDS_STRING5179              5179
#define NRT_IDS_STRING10064             10064
#define NRT_IDS_STRING20079             20079
#define NRT_IDS_STRING20104             20104
#define NRT_IDS_STRING20105             20105
#define NRT_IDS_STRING20026             20106
#define NRT_IDS_STRING20203             20107
#define NRT_IDS_STRING20204             20108

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
