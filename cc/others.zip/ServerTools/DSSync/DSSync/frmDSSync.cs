﻿#region Using Directives

using DSSync.Constants;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

#endregion

namespace DSSync
{
    public partial class frmDSSync : Form
    {
        #region Constructor

        public frmDSSync()
        {
            InitializeComponent();
        }

        #endregion

        #region Private Variables

        private string MachineName = string.Empty;
        private string DSSyncServiceName = "imDsSyncSvc";
        private ServiceController service;
		private DSServiceConnections.Controllers.DCConnectionController clsDCConnectionController;

        private enum GridCols
        {
            MachineName,
            Service,
            Status,
            Comments
        }

        #endregion

        #region Form Events

        private void frmDSSync_Load(object sender, EventArgs e)
        {
            try
            {
                Initialize();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK);
            }

        }

        #endregion

        #region General Methods

        /// <summary>
        /// To initialize the DSSync form
        /// </summary>
        private void Initialize()
        {
            try
            {
                RegistryKey regKey = Registry.LocalMachine.OpenSubKey(RegistryConstants.DS_SYNC_SVC);
                MachineName = (regKey.GetValue(RegistryConstants.MACHINE_NAME) ?? string.Empty).ToString();
                DSSyncServiceName = (regKey.GetValue(RegistryConstants.DS_SYNC_SERVICE_NAME) ?? DSSyncServiceName).ToString();

                string DSSyncServiceDisplayName = string.Empty;
                string DSSyncServiceStatus = string.Empty;

                while (GetService(DSSyncServiceName, MachineName) == null)
                {
                    frmInputBox InputBox = new frmInputBox();
                    InputBox.ShowDialog("Please enter service name: ", "Service Name");
                    DSSyncServiceName = InputBox.ReturnValue;
                }

                if (service != null)
                {
                    DSSyncServiceDisplayName = service.DisplayName;
                    DSSyncServiceStatus = service.Status.ToString();
                    RegistryKey key = Registry.LocalMachine.OpenSubKey(RegistryConstants.DS_SYNC_SVC, true);
                    if (!key.GetSubKeyNames().Contains(RegistryConstants.MACHINE_NAME))
                    {
                        key.CreateSubKey(RegistryConstants.MACHINE_NAME);
                    }
                    key.SetValue(RegistryConstants.MACHINE_NAME, MachineName);
                    if (!key.GetSubKeyNames().Contains(RegistryConstants.DS_SYNC_SERVICE_NAME))
                    {
                        key.CreateSubKey(RegistryConstants.DS_SYNC_SERVICE_NAME);
                    }
                    key.SetValue(RegistryConstants.DS_SYNC_SERVICE_NAME, DSSyncServiceName);
                    key.Close();

                    dgvServiceList.Rows.Clear();
                    dgvServiceList.Rows.Add();

                    DataGridViewRow dgvRow = dgvServiceList.Rows[dgvServiceList.Rows.Count - 1];
                    dgvRow.Cells[(int)GridCols.MachineName].Value = MachineName;
                    dgvRow.Cells[(int)GridCols.Service].Value = DSSyncServiceDisplayName;
                    dgvRow.Cells[(int)GridCols.Status].Value = DSSyncServiceStatus;
                    dgvRow.Cells[(int)GridCols.Comments].Value = string.Empty;
                    if (DSSyncServiceStatus.ToLower() == "running")
                    {
                        btnStart.Enabled = false;
                        btnStop.Enabled = true;
                    }
                    else
                    {
                        btnStart.Enabled = true;
                        btnStop.Enabled = false;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// To get the details of the service running in the machine with the machine name given
        /// </summary>
        /// <param name="serviceName">Service Name</param>
        /// <param name="machineName">Machine Name</param>
        /// <returns></returns>
        private ServiceController GetService(string serviceName, string machineName)
        {
            try
            {
                ServiceController[] services = null;
                do
                {
                    try
                    {
                        if((machineName??string.Empty).Length == 0)
                        {
                            throw new InvalidOperationException();
                        }
                        services = ServiceController.GetServices(machineName);
                    }
                    catch (InvalidOperationException)
                    {
                        services = null;
                        frmInputBox InputBox = new frmInputBox();
                        
                        InputBox.ShowDialog("Please enter server name: ", "Server Name");
                        machineName = InputBox.ReturnValue;
                        if (machineName == string.Empty)
                            break;
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                } while (services == null);
                if(machineName != string.Empty)
                {
                    MachineName = machineName;
                    service = services.FirstOrDefault(s => s.ServiceName == serviceName);
                }
                else
                {
                    MessageBox.Show("No server found.");
                    Application.Exit();
                    return new ServiceController();
                }
                return service;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion

        #region Grid Events

        private void dgvServiceList_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (dgvServiceList.CurrentRow != null)
                {
                    string status = (dgvServiceList.CurrentRow.Cells[(int)GridCols.Status].Value ?? string.Empty).ToString();
                    if (status.ToLower() == "running")
                    {
                        btnStart.Enabled = false;
                        btnStop.Enabled = true;
                    }
                    else
                    {
                        btnStart.Enabled = true;
                        btnStop.Enabled = false;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK);
            }
        }

        #endregion

        #region Button Events

        private void btnStart_Click(object sender, EventArgs e)
        {
            try
            {
                if (service != null)
                {
                    service.Start();
                    Initialize();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK);
            }
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            try
            {
                if (service != null && service.CanStop)
                {
                    service.Stop();
                    Initialize();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK);
            }
        }

        private void btnSyncronization_Click(object sender, EventArgs e)
        {
            try
            {
                frmDSSyncSchedule DSSyncSchedule = new frmDSSyncSchedule();
                DSSyncSchedule.ShowDialog(MachineName);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK);
            }
        }

        private void btnConnectionList_Click(object sender, EventArgs e)
        {
			try
            {
                if (this.clsDCConnectionController == null)
                    this.clsDCConnectionController = new DSServiceConnections.Controllers.DCConnectionController(MachineName);
                this.clsDCConnectionController.openConnectionListForm(this);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        #endregion
    }
}
