﻿namespace DSServiceConnections.Forms
{
    partial class FrmAttributeMap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtMapName = new System.Windows.Forms.TextBox();
            this.lblK1SyncID = new System.Windows.Forms.Label();
            this.cboK1SyncID = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cboGroupMambers = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cboGroupName = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cboGroup = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.cboOrgUnitName = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.cboEnabled = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.cboEmail = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.cboFax = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.cboTelephone = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.cboLocation = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.cboUserName = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.cboUserID = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.btnADSDefaults = new System.Windows.Forms.Button();
            this.btnSUNONEDefaults = new System.Windows.Forms.Button();
            this.btnOK = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnHelp = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Map Name";
            // 
            // txtMapName
            // 
            this.txtMapName.Location = new System.Drawing.Point(16, 40);
            this.txtMapName.Name = "txtMapName";
            this.txtMapName.Size = new System.Drawing.Size(328, 22);
            this.txtMapName.TabIndex = 1;
            // 
            // lblK1SyncID
            // 
            this.lblK1SyncID.AutoSize = true;
            this.lblK1SyncID.Location = new System.Drawing.Point(408, 44);
            this.lblK1SyncID.Name = "lblK1SyncID";
            this.lblK1SyncID.Size = new System.Drawing.Size(53, 13);
            this.lblK1SyncID.TabIndex = 2;
            this.lblK1SyncID.Text = "K1SyncID";
            // 
            // cboK1SyncID
            // 
            this.cboK1SyncID.FormattingEnabled = true;
            this.cboK1SyncID.Location = new System.Drawing.Point(480, 40);
            this.cboK1SyncID.Name = "cboK1SyncID";
            this.cboK1SyncID.Size = new System.Drawing.Size(209, 21);
            this.cboK1SyncID.TabIndex = 3;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(199)))), ((int)(((byte)(199)))), ((int)(((byte)(199)))));
            this.panel1.Controls.Add(this.cboGroupMambers);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.cboGroupName);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.cboGroup);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Location = new System.Drawing.Point(16, 72);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(328, 144);
            this.panel1.TabIndex = 4;
            // 
            // cboGroupMambers
            // 
            this.cboGroupMambers.FormattingEnabled = true;
            this.cboGroupMambers.Items.AddRange(new object[] {
            "member",
            "uniqueMember"});
            this.cboGroupMambers.Location = new System.Drawing.Point(80, 104);
            this.cboGroupMambers.Name = "cboGroupMambers";
            this.cboGroupMambers.Size = new System.Drawing.Size(232, 21);
            this.cboGroupMambers.TabIndex = 6;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(16, 108);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Members";
            // 
            // cboGroupName
            // 
            this.cboGroupName.FormattingEnabled = true;
            this.cboGroupName.Items.AddRange(new object[] {
            "cn",
            "name"});
            this.cboGroupName.Location = new System.Drawing.Point(80, 72);
            this.cboGroupName.Name = "cboGroupName";
            this.cboGroupName.Size = new System.Drawing.Size(232, 21);
            this.cboGroupName.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(16, 76);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "Name";
            // 
            // cboGroup
            // 
            this.cboGroup.FormattingEnabled = true;
            this.cboGroup.Items.AddRange(new object[] {
            "cn",
            "sAMAccountName",
            "uid"});
            this.cboGroup.Location = new System.Drawing.Point(80, 40);
            this.cboGroup.Name = "cboGroup";
            this.cboGroup.Size = new System.Drawing.Size(232, 21);
            this.cboGroup.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(16, 44);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Group ID";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(8, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Group";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(199)))), ((int)(((byte)(199)))), ((int)(((byte)(199)))));
            this.panel2.Controls.Add(this.cboOrgUnitName);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Location = new System.Drawing.Point(16, 224);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(328, 112);
            this.panel2.TabIndex = 5;
            // 
            // cboOrgUnitName
            // 
            this.cboOrgUnitName.FormattingEnabled = true;
            this.cboOrgUnitName.Items.AddRange(new object[] {
            "cn",
            "name",
            "ou"});
            this.cboOrgUnitName.Location = new System.Drawing.Point(72, 40);
            this.cboOrgUnitName.Name = "cboOrgUnitName";
            this.cboOrgUnitName.Size = new System.Drawing.Size(240, 21);
            this.cboOrgUnitName.TabIndex = 2;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(16, 44);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(36, 13);
            this.label8.TabIndex = 1;
            this.label8.Text = "Name";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(8, 16);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(108, 13);
            this.label7.TabIndex = 0;
            this.label7.Text = "Organizational Unit";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(199)))), ((int)(((byte)(199)))), ((int)(((byte)(199)))));
            this.panel3.Controls.Add(this.cboEnabled);
            this.panel3.Controls.Add(this.label16);
            this.panel3.Controls.Add(this.cboEmail);
            this.panel3.Controls.Add(this.label15);
            this.panel3.Controls.Add(this.cboFax);
            this.panel3.Controls.Add(this.label14);
            this.panel3.Controls.Add(this.cboTelephone);
            this.panel3.Controls.Add(this.label13);
            this.panel3.Controls.Add(this.cboLocation);
            this.panel3.Controls.Add(this.label12);
            this.panel3.Controls.Add(this.cboUserName);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.cboUserID);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Location = new System.Drawing.Point(360, 72);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(328, 264);
            this.panel3.TabIndex = 6;
            // 
            // cboEnabled
            // 
            this.cboEnabled.FormattingEnabled = true;
            this.cboEnabled.Items.AddRange(new object[] {
            "userAccountControl"});
            this.cboEnabled.Location = new System.Drawing.Point(104, 224);
            this.cboEnabled.Name = "cboEnabled";
            this.cboEnabled.Size = new System.Drawing.Size(192, 21);
            this.cboEnabled.TabIndex = 14;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(32, 228);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(49, 13);
            this.label16.TabIndex = 13;
            this.label16.Text = "Enabled";
            // 
            // cboEmail
            // 
            this.cboEmail.FormattingEnabled = true;
            this.cboEmail.Items.AddRange(new object[] {
            "mail"});
            this.cboEmail.Location = new System.Drawing.Point(104, 192);
            this.cboEmail.Name = "cboEmail";
            this.cboEmail.Size = new System.Drawing.Size(192, 21);
            this.cboEmail.TabIndex = 12;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(32, 196);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(34, 13);
            this.label15.TabIndex = 11;
            this.label15.Text = "Email";
            // 
            // cboFax
            // 
            this.cboFax.FormattingEnabled = true;
            this.cboFax.Items.AddRange(new object[] {
            "facsimileTelephoneNumber"});
            this.cboFax.Location = new System.Drawing.Point(104, 160);
            this.cboFax.Name = "cboFax";
            this.cboFax.Size = new System.Drawing.Size(192, 21);
            this.cboFax.TabIndex = 10;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(32, 164);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(24, 13);
            this.label14.TabIndex = 9;
            this.label14.Text = "Fax";
            // 
            // cboTelephone
            // 
            this.cboTelephone.FormattingEnabled = true;
            this.cboTelephone.Items.AddRange(new object[] {
            "telephoneNumber"});
            this.cboTelephone.Location = new System.Drawing.Point(104, 128);
            this.cboTelephone.Name = "cboTelephone";
            this.cboTelephone.Size = new System.Drawing.Size(192, 21);
            this.cboTelephone.TabIndex = 8;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(32, 132);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(60, 13);
            this.label13.TabIndex = 7;
            this.label13.Text = "Telephone";
            // 
            // cboLocation
            // 
            this.cboLocation.FormattingEnabled = true;
            this.cboLocation.Items.AddRange(new object[] {
            "I",
            "physicalDeliveryOfficeName"});
            this.cboLocation.Location = new System.Drawing.Point(104, 96);
            this.cboLocation.Name = "cboLocation";
            this.cboLocation.Size = new System.Drawing.Size(192, 21);
            this.cboLocation.TabIndex = 6;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(32, 100);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(51, 13);
            this.label12.TabIndex = 5;
            this.label12.Text = "Location";
            // 
            // cboUserName
            // 
            this.cboUserName.FormattingEnabled = true;
            this.cboUserName.Items.AddRange(new object[] {
            "cn",
            "displayName",
            "givenName",
            "name",
            "sn",
            "userPrincipalName"});
            this.cboUserName.Location = new System.Drawing.Point(104, 64);
            this.cboUserName.Name = "cboUserName";
            this.cboUserName.Size = new System.Drawing.Size(192, 21);
            this.cboUserName.TabIndex = 4;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(32, 68);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(36, 13);
            this.label11.TabIndex = 3;
            this.label11.Text = "Name";
            // 
            // cboUserID
            // 
            this.cboUserID.FormattingEnabled = true;
            this.cboUserID.Items.AddRange(new object[] {
            "sAMAccountName",
            "uid"});
            this.cboUserID.Location = new System.Drawing.Point(104, 32);
            this.cboUserID.Name = "cboUserID";
            this.cboUserID.Size = new System.Drawing.Size(192, 21);
            this.cboUserID.TabIndex = 2;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(32, 36);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(44, 13);
            this.label10.TabIndex = 1;
            this.label10.Text = "User ID";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(16, 16);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(30, 13);
            this.label9.TabIndex = 0;
            this.label9.Text = "User";
            // 
            // btnADSDefaults
            // 
            this.btnADSDefaults.Location = new System.Drawing.Point(16, 344);
            this.btnADSDefaults.Name = "btnADSDefaults";
            this.btnADSDefaults.Size = new System.Drawing.Size(88, 30);
            this.btnADSDefaults.TabIndex = 7;
            this.btnADSDefaults.Text = "ADS Defaults";
            this.btnADSDefaults.UseVisualStyleBackColor = true;
            this.btnADSDefaults.Click += new System.EventHandler(this.btnADSDefaults_Click);
            // 
            // btnSUNONEDefaults
            // 
            this.btnSUNONEDefaults.Location = new System.Drawing.Point(112, 344);
            this.btnSUNONEDefaults.Name = "btnSUNONEDefaults";
            this.btnSUNONEDefaults.Size = new System.Drawing.Size(112, 30);
            this.btnSUNONEDefaults.TabIndex = 8;
            this.btnSUNONEDefaults.Text = "Sun ONE Defaults";
            this.btnSUNONEDefaults.UseVisualStyleBackColor = true;
            this.btnSUNONEDefaults.Click += new System.EventHandler(this.btnSUNONEDefaults_Click);
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(456, 344);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(75, 30);
            this.btnOK.TabIndex = 9;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(536, 344);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 30);
            this.btnCancel.TabIndex = 10;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnHelp
            // 
            this.btnHelp.Location = new System.Drawing.Point(616, 344);
            this.btnHelp.Name = "btnHelp";
            this.btnHelp.Size = new System.Drawing.Size(75, 30);
            this.btnHelp.TabIndex = 11;
            this.btnHelp.Text = "Help";
            this.btnHelp.UseVisualStyleBackColor = true;
            this.btnHelp.Click += new System.EventHandler(this.btnHelp_Click);
            // 
            // FrmAttributeMap
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(709, 383);
            this.Controls.Add(this.btnHelp);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.btnSUNONEDefaults);
            this.Controls.Add(this.btnADSDefaults);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.cboK1SyncID);
            this.Controls.Add(this.lblK1SyncID);
            this.Controls.Add(this.txtMapName);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmAttributeMap";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DS Synchronization Attribute Map on INNCREWIN6";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtMapName;
        private System.Windows.Forms.Label lblK1SyncID;
        private System.Windows.Forms.ComboBox cboK1SyncID;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox cboGroupMambers;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cboGroupName;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cboGroup;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ComboBox cboOrgUnitName;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ComboBox cboEnabled;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox cboEmail;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox cboFax;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox cboTelephone;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox cboLocation;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox cboUserName;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cboUserID;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnADSDefaults;
        private System.Windows.Forms.Button btnSUNONEDefaults;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnHelp;
    }
}