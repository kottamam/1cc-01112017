﻿using System;
using System.Windows.Forms;

namespace DSSync.DSServiceConnections.Forms
{
    internal partial class FrmConnProperties : Form
    {
        internal Controllers.ConnectionPropertyController MyController;
        internal Constants.FormDataModes frmItemMode;

        internal FrmConnProperties()
        {
            this.InitializeComponent();
            this.MyController = null;
            this.frmItemMode = Constants.FormDataModes.ViewItem;
        }

        private void btnCancel_Click(object sender, System.EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void cboServerType_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            try
            {
                this.txtDSServerName.Visible = false;
                this.cboDSServer.Visible = false;
                this.txtDSPort.ReadOnly = true;
                this.lblDSPortInfo.Visible = false;
                this.rdoUseServiceLogin.Enabled = false;
                this.txtRootContainerDN.ReadOnly = true;
                this.cboDefinedMap.Enabled = false;
                this.btnAddMap.Enabled = false;
                this.btnDeleteMap.Enabled = false;
                this.btnEditMap.Enabled = false;
                this.lblContext.Visible = false;
                this.txtContext.Visible = false;
                this.txtTreeID.ReadOnly = true;

                this.txtUserID.Clear();
                this.txtPassword.Clear();
                this.txtDSPort.Clear();

                switch (this.cboServerType.Text)
                {
                    case "Microsoft Active Directory":
                        this.txtDSServerName.Visible = true;
                        this.lblDSPortInfo.Visible = true;
                        this.txtDSPort.ReadOnly = false;
                        this.txtDSPort.Text = "389";
                        this.rdoUseServiceLogin.Enabled = true;
                        this.txtRootContainerDN.ReadOnly = false;
                        this.cboDefinedMap.Enabled = true;
                        this.btnAddMap.Enabled = true;
                        this.btnDeleteMap.Enabled = this.cboDefinedMap.Text.Trim().Length > 0;
                        this.btnEditMap.Enabled = this.cboDefinedMap.Text.Trim().Length > 0;
                        break;

                    case "SUN One Directory Services":
                        this.txtDSServerName.Visible = true;
                        this.lblDSPortInfo.Visible = true;
                        this.txtDSPort.ReadOnly = false;
                        this.txtRootContainerDN.ReadOnly = false;
                        this.cboDefinedMap.Enabled = true;
                        this.btnAddMap.Enabled = true;
                        this.btnDeleteMap.Enabled = this.cboDefinedMap.Text.Trim().Length > 0;
                        this.btnEditMap.Enabled = this.cboDefinedMap.Text.Trim().Length > 0;
                        break;

                    case "Novell NDS":
                        this.txtDSServerName.Visible = true;
                        this.lblContext.Visible = true;
                        this.txtContext.Visible = true;
                        this.txtTreeID.ReadOnly = false;
                        this.txtRootContainerDN.ReadOnly = false;
                        break;

                    case "Windows NT":
                        this.cboDSServer.Visible = true;
                        this.rdoOtherLogin.Checked = true;
                        break;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void rdoUseServiceLogin_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (this.rdoUseServiceLogin.Checked)
                {
                    this.txtUserID.Text = "Local System";
                    this.txtPassword.Clear();
                    this.txtUserID.ReadOnly = true;
                    this.txtPassword.ReadOnly = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void rdoOtherLogin_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (this.rdoOtherLogin.Checked)
                {
                    this.txtUserID.Clear();
                    this.txtPassword.Clear();
                    this.txtUserID.ReadOnly = false;
                    this.txtPassword.ReadOnly = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void rdoWorksitePortDefault_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (this.rdoWorksitePortDefault.Checked)
                {
                    this.txtWorksiteOtherPort.ReadOnly = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void rdoWorksitePortOther_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (this.rdoWorksitePortOther.Checked)
                {
                    this.txtWorksiteOtherPort.ReadOnly = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void chkUserMustChangePwd_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                this.chkPwdNeverExpire.Enabled = !this.chkUserMustChangePwd.Checked;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void chkPwdNeverExpire_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                this.chkUserMustChangePwd.Enabled = !this.chkPwdNeverExpire.Checked;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void txtUserDefaultPassword_TextChanged(object sender, EventArgs e)
        {
            try
            {
                this.txtUserDefaultConfirmPwd.ReadOnly = this.txtUserDefaultPassword.Text.Length == 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgvExtrnalDNS_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            try
            {
                if (this.dgvExtrnalDNS.Rows.Count == (e.RowIndex + 1))
                {
                    this.dgvExtrnalDNS.Rows.Add();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cboDefinedMap_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                this.btnDeleteMap.Enabled = this.cboDefinedMap.Text.Trim().Length > 0;
                this.btnEditMap.Enabled = this.cboDefinedMap.Text.Trim().Length > 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void txtDSPort_ReadOnlyChanged(object sender, EventArgs e)
        {
            this.txtDSPort.TabStop = !this.txtDSPort.ReadOnly;
        }
    }
}