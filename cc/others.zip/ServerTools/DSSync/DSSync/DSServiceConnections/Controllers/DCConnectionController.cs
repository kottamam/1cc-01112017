﻿using DSSync.Constants;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace DSSync.DSServiceConnections.Controllers
{
    class DCConnectionController : IDisposable
    {
        private string ServerName { get; set; }
        private Forms.FrmConnectionList frmConnectionList;
        private ConnectionPropertyController clsConnectionPropertyController;

        internal DCConnectionController(string serverName)
        {
            this.clsConnectionPropertyController = null;
            this.frmConnectionList = null;
            this.ServerName = serverName;
        }

        public void Dispose()
        {
            try
            {
                if (this.clsConnectionPropertyController != null)
                {
                    this.clsConnectionPropertyController.Dispose();
                }
                this.ServerName = null;
                if (this.frmConnectionList != null)
                {
                    this.frmConnectionList.Close();
                }
            }
            catch { }
        }

        private void FrmConnectionList_FormClosed(object sender, System.Windows.Forms.FormClosedEventArgs e)
        {
            try
            {
                if (this.frmConnectionList != null)
                {
                    this.frmConnectionList.Dispose();
                    this.frmConnectionList = null;
                }
            }
            catch { }
        }

        internal void openConnectionListForm(System.Windows.Forms.Form frmParent)
        {
            try
            {
                this.frmConnectionList = new Forms.FrmConnectionList();
                this.frmConnectionList.FormClosed += FrmConnectionList_FormClosed;
                this.frmConnectionList.MyController = this;

                this.frmConnectionList.Text = String.Format("Directory Service Connections on {0}", this.ServerName);
                this.getDSConnectionList();
                this.frmConnectionList.ShowDialog(frmParent);
            }
            catch (Exception ex)
            {
                if (this.frmConnectionList != null)
                {
                    this.frmConnectionList.Dispose();
                    this.frmConnectionList = null;
                }
                throw ex;
            }
        }

        private void getDSConnectionList()
        {
            DataGridViewRow dgvRow = null;
            Services.RegistryHandler clsRegistryHandler = null;
            List<string> lstConnName = null;
            string strSubKeyPath = "";
            object objConnName = null, objConnLibraryName = null, objConnCN = null;
            int intGridRowIndex = 0;

            this.frmConnectionList.btnEdit.Enabled = false;
            this.frmConnectionList.btnDelete.Enabled = false;
            this.frmConnectionList.btnClear.Enabled = false;

            clsRegistryHandler = new Services.RegistryHandler();
            lstConnName = clsRegistryHandler.getSubKeyNames(RegistryConstants.DS_SYNC_SVC_CONNECTIONS);

            if (lstConnName == null || lstConnName.Count == 0)
                return;

            foreach (string strConnName in lstConnName)
            {
                strSubKeyPath = string.Format("{0}\\{1}", RegistryConstants.DS_SYNC_SVC_CONNECTIONS, strConnName);
                objConnName = clsRegistryHandler.getValue(strSubKeyPath, Constants.RegistryConstants.REG_KEY_CONNECTION_NAME);

                strSubKeyPath = string.Format("{0}\\{1}\\DMS Parameters", RegistryConstants.DS_SYNC_SVC_CONNECTIONS, strConnName);
                objConnCN = clsRegistryHandler.getValue(strSubKeyPath, Constants.RegistryConstants.REG_KEY_CONNECTION_DMS_PARAM_DMS);
                objConnLibraryName = clsRegistryHandler.getValue(strSubKeyPath, Constants.RegistryConstants.REG_KEY_CONNECTION_DMS_PARAM_LIBRARY);

                intGridRowIndex = this.frmConnectionList.dgvDSConnList.Rows.Add();
                dgvRow = this.frmConnectionList.dgvDSConnList.Rows[intGridRowIndex];

                dgvRow.Cells["dgvTextColRegKey"].Value = Convert.ToString(strConnName);
                dgvRow.Cells["dgvTextColName"].Value = Convert.ToString(objConnName);
                dgvRow.Cells["dgvTextColLibrary"].Value = Convert.ToString(objConnLibraryName);
                dgvRow.Cells["dgvTextColCN"].Value = Convert.ToString(objConnCN);

                intGridRowIndex = 0;
                dgvRow = null;
                objConnName = null;
                objConnLibraryName = null;
                objConnCN = null;
            }
            clsRegistryHandler = null;

            if (this.frmConnectionList.dgvDSConnList.Rows.Count > 0)
            {
                this.frmConnectionList.btnEdit.Enabled = true;
                this.frmConnectionList.btnDelete.Enabled = true;
                this.frmConnectionList.btnClear.Enabled = true;
            }
        }

        internal void openNewConnectionForm()
        {
            if (clsConnectionPropertyController == null)
                clsConnectionPropertyController = new ConnectionPropertyController(this.ServerName);
            clsConnectionPropertyController.openPropertyForm(this.frmConnectionList.Owner);
        }

        internal void deleteSelectedConnection()
        {
            int intSelectedRowIndex = 0;
            DialogResult dialogResult;
            Services.RegistryHandler clsRegistryHandler = null;

            if (this.frmConnectionList.dgvDSConnList.SelectedRows.Count == 0)
                return;
            if (Convert.ToString(this.frmConnectionList.dgvDSConnList.SelectedRows[0].Cells["dgvTextColName"].Value).Length == 0)
                return;


            dialogResult = MessageBox.Show(this.frmConnectionList, "Are you sure you want to delete selected connection?", "Worksite Service Manager",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dialogResult == DialogResult.No)
                return;

            try
            {
                Cursor.Current = Cursors.Default;
                clsRegistryHandler = new Services.RegistryHandler();
                clsRegistryHandler.deleteSubKey(RegistryConstants.DS_SYNC_SVC_CONNECTIONS, Convert.ToString(this.frmConnectionList.dgvDSConnList.SelectedRows[0].Cells["dgvTextColRegKey"].Value));

                intSelectedRowIndex = this.frmConnectionList.dgvDSConnList.SelectedRows[0].Index;
                this.frmConnectionList.dgvDSConnList.ClearSelection();
                this.frmConnectionList.dgvDSConnList.Rows.RemoveAt(intSelectedRowIndex);
            }
            finally
            {
                intSelectedRowIndex = 0;
                clsRegistryHandler = null;
                Cursor.Current = Cursors.Default;
            }
        }

        internal void clearAllConnection()
        {
            DialogResult dialogResult;
            DataGridViewRow dgvRow = null;
            Services.RegistryHandler clsRegistryHandler = null;

            if (this.frmConnectionList.dgvDSConnList.Rows.Count == 0)
                return;

            dialogResult = MessageBox.Show(this.frmConnectionList, "Are you sure you want to clear all connections?", "Worksite Service Manager",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dialogResult == DialogResult.No)
                return;

            try
            {
                Cursor.Current = Cursors.Default;
                clsRegistryHandler = new Services.RegistryHandler();

                while (this.frmConnectionList.dgvDSConnList.Rows.Count > 0)
                {
                    this.frmConnectionList.dgvDSConnList.Rows[0].Selected = true;
                    dgvRow = this.frmConnectionList.dgvDSConnList.Rows[0];
                    if (Convert.ToString(dgvRow.Cells["dgvTextColRegKey"].Value).Length > 0)
                    {
                        clsRegistryHandler.deleteSubKey(RegistryConstants.DS_SYNC_SVC_CONNECTIONS, Convert.ToString(dgvRow.Cells["dgvTextColRegKey"].Value));
                    }
                    dgvRow = null;
                    this.frmConnectionList.dgvDSConnList.Rows[0].Selected = false;
                    this.frmConnectionList.dgvDSConnList.Rows.RemoveAt(0);
                }
                if (this.frmConnectionList.dgvDSConnList.Rows.Count > 0)
                {
                    this.frmConnectionList.btnEdit.Enabled = true;
                    this.frmConnectionList.btnDelete.Enabled = true;
                    this.frmConnectionList.btnClear.Enabled = true;
                }
                else
                {
                    this.frmConnectionList.btnEdit.Enabled = false;
                    this.frmConnectionList.btnDelete.Enabled = false;
                    this.frmConnectionList.btnClear.Enabled = false;
                }
            }
            finally
            {
                dgvRow = null;
                clsRegistryHandler = null;
                Cursor.Current = Cursors.Default;
            }
        }
    }
}