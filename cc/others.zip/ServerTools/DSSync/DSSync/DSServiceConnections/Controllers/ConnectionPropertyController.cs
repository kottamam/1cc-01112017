﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace DSSync.DSServiceConnections.Controllers
{
    class ConnectionPropertyController : IDisposable
    {
        private Forms.FrmConnProperties frmConnProperties;
        private string ServerName { get; set; }

        internal ConnectionPropertyController(string serverName)
        {
            this.frmConnProperties = null;
            this.ServerName = serverName;
        }

        public void Dispose()
        {
            try
            {
                this.ServerName = null;
                if (this.frmConnProperties != null)
                {
                    this.frmConnProperties.Close();
                }
            }
            catch { }
        }

        internal void openPropertyForm(System.Windows.Forms.Form frmParent)
        {
            try
            {
                this.frmConnProperties = new Forms.FrmConnProperties();
                this.frmConnProperties.FormClosed += FrmConnProperties_FormClosed;

                this.frmConnProperties.MyController = this;
                this.frmConnProperties.Text = String.Format("DS Synchronization Connection Properties on {0}", this.ServerName);

                this.updateServerTypeCombo();
                this.updateDefinedMapCombo();
                this.initializeForm(Constants.FormDataModes.NewItem);

                Cursor.Current = Cursors.Default;
                this.frmConnProperties.ShowDialog(frmParent);
            }
            catch (Exception ex)
            {
                if (this.frmConnProperties != null)
                {
                    this.frmConnProperties.Dispose();
                    this.frmConnProperties = null;
                }
                throw ex;
            }
        }

        private void FrmConnProperties_FormClosed(object sender, System.Windows.Forms.FormClosedEventArgs e)
        {
            try
            {
                if (this.frmConnProperties != null)
                {
                    this.frmConnProperties.Dispose();
                    this.frmConnProperties = null;
                }
            }
            catch { }
        }

        private void initializeForm(Constants.FormDataModes itemMode)
        {
            this.frmConnProperties.btnTestLogin.Enabled = false;
            this.frmConnProperties.btnBrowseRootContainerDN.Enabled = false;
            this.frmConnProperties.btnAddMap.Enabled = false;
            this.frmConnProperties.btnDeleteMap.Enabled = false;
            this.frmConnProperties.btnEditMap.Enabled = false;
            this.frmConnProperties.btnHelp.Enabled = false;
            this.frmConnProperties.btnOK.Enabled = false;
            this.frmConnProperties.btnCancel.Enabled = false;

            switch (itemMode)
            {
                case Constants.FormDataModes.NewItem:
                    this.frmConnProperties.cboServerType.SelectedIndex = 0;
                    this.frmConnProperties.txtDSPort.Text = "389";
                    this.frmConnProperties.rdoUseServiceLogin.Checked = true;
                    this.frmConnProperties.txtUserID.Text = "Local System";
                    this.frmConnProperties.rdoWorksitePortDefault.Checked = true;
                    this.frmConnProperties.chkUserMustChangePwd.Checked = true;
                    this.frmConnProperties.btnAddMap.Enabled = true;
                    this.frmConnProperties.btnHelp.Enabled = true;
                    this.frmConnProperties.btnCancel.Enabled = true;
                    this.frmConnProperties.txtUserDefaultConfirmPwd.ReadOnly = true;

                    this.frmConnProperties.cboDSServer.Text = this.ServerName;
                    this.frmConnProperties.dgvExtrnalDNS.Rows.Add();
                    this.frmConnProperties.txtConnectionName.Focus();
                    break;

                default:
                    break;
            }
        }

        private void clearForm()
        {
            this.frmConnProperties.frmItemMode = Constants.FormDataModes.ViewItem;
            this.frmConnProperties.txtConnectionName.Clear();
            this.frmConnProperties.txtDSPort.Clear();
            this.frmConnProperties.txtDSServerName.Clear();
            this.frmConnProperties.txtPassword.Clear();
            this.frmConnProperties.txtRootContainerDN.Clear();
            this.frmConnProperties.txtTreeID.Clear();
            this.frmConnProperties.txtUserDefaultConfirmPwd.Clear();
            this.frmConnProperties.txtUserDefaultPassword.Clear();
            this.frmConnProperties.txtUserID.Clear();
            this.frmConnProperties.txtWorksiteLibraryName.Clear();
            this.frmConnProperties.txtWorksiteOtherPort.Clear();
            this.frmConnProperties.txtWorksitePassword.Clear();
            this.frmConnProperties.txtWorksiteServerName.Clear();
            this.frmConnProperties.txtWorksiteUsername.Clear();
            this.frmConnProperties.txtContext.Clear();

            this.frmConnProperties.cboDefinedMap.SelectedItem = null;
            this.frmConnProperties.cboDefinedMap.Text = null;
            this.frmConnProperties.cboDefinedMap.Items.Clear();
            this.frmConnProperties.cboServerType.SelectedItem = null;
            this.frmConnProperties.cboDSServer.Items.Clear();
            this.frmConnProperties.cboDSServer.Text = null;

            this.frmConnProperties.chkPwdNeverExpire.Checked = false;
            this.frmConnProperties.chkUserMustChangePwd.Checked = false;

            this.frmConnProperties.rdoOtherLogin.Checked = false;
            this.frmConnProperties.rdoUseServiceLogin.Checked = false;
            this.frmConnProperties.rdoWorksitePortDefault.Checked = false;
            this.frmConnProperties.rdoWorksitePortOther.Checked = false;

            this.frmConnProperties.dgvExtrnalDNS.Rows.Clear();
        }

        private void updateServerTypeCombo()
        {
            Services.RegistryHandler clsRegistryHandler = new Services.RegistryHandler();
            var vIncludeOtherDir = clsRegistryHandler.getValue(Constants.RegistryConstants.DS_SYNC_SVC, Constants.RegistryConstants.DS_SYNC_INCLUDE_OTHER_DIR);

            this.frmConnProperties.cboServerType.Items.Add("Microsoft Active Directory");
            if (vIncludeOtherDir != null && Convert.ToInt32(vIncludeOtherDir) == 1)
            {
                this.frmConnProperties.cboServerType.Items.Add("SUN One Directory Services");
                this.frmConnProperties.cboServerType.Items.Add("Novell NDS");
            }
            this.frmConnProperties.cboServerType.Items.Add("Windows NT");
        }

        private void updateDefinedMapCombo()
        {
            Services.RegistryHandler clsRegistryHandler = null;
            List<string> lstMapName = null;


            clsRegistryHandler = new Services.RegistryHandler();
            lstMapName = clsRegistryHandler.getSubKeyNames(Constants.RegistryConstants.DS_SYNC_SVC_ATTRIBUTE_MAPS);
            if (lstMapName == null || lstMapName.Count == 0)
                return;

            foreach (string strMapName in lstMapName)
            {
                this.frmConnProperties.cboDefinedMap.Items.Add(strMapName);
            }
        }
    }
}