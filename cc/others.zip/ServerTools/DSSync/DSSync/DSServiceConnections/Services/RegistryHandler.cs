﻿using Microsoft.Win32;
using System.Collections.Generic;

namespace DSSync.DSServiceConnections.Services
{
    class RegistryHandler
    {
        internal List<string> getSubKeyNames(string subKeyPath)
        {
            List<string> lstSubKeyName = null;

            using (RegistryKey regKey = Registry.LocalMachine.OpenSubKey(subKeyPath, RegistryKeyPermissionCheck.ReadSubTree,
                System.Security.AccessControl.RegistryRights.ReadKey))
            {
                lstSubKeyName = new List<string>(regKey.GetSubKeyNames());
                regKey.Close();
            }
            return lstSubKeyName;
        }

        internal List<string> getValueNames(string subKeyPath)
        {
            List<string> lstValueName = null;

            using (RegistryKey regKey = Registry.LocalMachine.OpenSubKey(subKeyPath, RegistryKeyPermissionCheck.ReadSubTree,
                System.Security.AccessControl.RegistryRights.ReadKey))
            {
                lstValueName = new List<string>(regKey.GetValueNames());
                regKey.Close();
            }
            return lstValueName;
        }

        internal object getValue(string subKeyPath, string keyName)
        {
            object objKeyValue = null;

            using (RegistryKey regKey = Registry.LocalMachine.OpenSubKey(subKeyPath, RegistryKeyPermissionCheck.ReadSubTree,
                System.Security.AccessControl.RegistryRights.ReadKey))
            {
                objKeyValue = regKey.GetValue(keyName);
                regKey.Close();
            }
            return objKeyValue;
        }

        internal void deleteSubKey(string keyPath, string subKeyPath)
        {
            using (RegistryKey regKey = Registry.LocalMachine.OpenSubKey(keyPath, RegistryKeyPermissionCheck.ReadWriteSubTree,
               System.Security.AccessControl.RegistryRights.Delete))
            {
                regKey.DeleteSubKeyTree(subKeyPath);
                regKey.Close();
            }
        }
    }
}