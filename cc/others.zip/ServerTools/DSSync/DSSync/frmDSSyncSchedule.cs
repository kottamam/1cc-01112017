﻿#region Using Directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;

using DSSync.Constants;

#endregion

namespace DSSync
{
    public partial class frmDSSyncSchedule : Form
    {

        #region Constructor

        public frmDSSyncSchedule()
        {
            InitializeComponent();
        }

        #endregion

        #region Public Methods

        public DialogResult ShowDialog(string machineName)
        {
            try
            {
                this.Text = "DS Synchronization Schedule Properties" + " on " + machineName;
                InitializeForm();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK);
            }
            return base.ShowDialog();
        }

        #endregion

        #region Private Methods

        private void InitializeForm()
        {
            try
            {
                ClearScheduleCheckBoxes();
                RegistryKey key = Registry.LocalMachine.OpenSubKey(RegistryConstants.DS_SYNC_SVC);
                if (key != null)
                {
                    radSchedule.Checked = key.GetValue(RegistryConstants.DS_SYNC_MODE).ToString() == "S";
                    radContinuous.Checked = key.GetValue(RegistryConstants.DS_SYNC_MODE).ToString() == "C";
                    string scheduleString = key.GetValue(RegistryConstants.DS_SYNC_SCHEDULE).ToString().Trim().TrimEnd(',');
                    string[] schedules = scheduleString.Split(',');
                    string weekStr = "", rowStr = "";
                    foreach(string schedule in schedules)
                    {
                        int scheduleNo = Int32.Parse(schedule);
                        int week = scheduleNo / 100;
                        int row = scheduleNo % 100;
                        weekStr = "";
                        rowStr = "";
                        switch (week)
                        {
                            case 0:
                                weekStr = "SUN";
                                break;
                            case 1:
                                weekStr = "MON";
                                break;
                            case 2:
                                weekStr = "TUE";
                                break;
                            case 3:
                                weekStr = "WED";
                                break;
                            case 4:
                                weekStr = "THU";
                                break;
                            case 5:
                                weekStr = "FRI";
                                break;
                            case 6:
                                weekStr = "SAT";
                                break;
                        }
                        switch(row)
                        {
                            case 0:
                                rowStr = "1";
                                break;
                            case 2:
                                rowStr = "2";
                                break;
                            case 4:
                                rowStr = "3";
                                break;
                            case 6:
                                rowStr = "4";
                                break;
                            case 8:
                                rowStr = "5";
                                break;
                            case 10:
                                rowStr = "6";
                                break;
                            case 12:
                                rowStr = "7";
                                break;
                            case 14:
                                rowStr = "8";
                                break;
                            case 16:
                                rowStr = "9";
                                break;
                            case 18:
                                rowStr = "10";
                                break;
                            case 20:
                                rowStr = "11";
                                break;
                            case 22:
                                rowStr = "12";
                                break;
                        }

                        Control[] chk = this.pnlSchedule.Controls.Find("chk" + weekStr + rowStr, false);
                        if(chk.Length > 0 && chk[0] is CheckBox)
                        {
                            ((CheckBox)chk[0]).Checked = true;
                        }
                    }

                    pnlSchedule.Enabled = radSchedule.Checked;
                }
                key.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// To clear all check schedule check boxes
        /// </summary>
        private void ClearScheduleCheckBoxes()
        {
            try
            {
                chkSUN1.Checked = false;
                chkSUN2.Checked = false;
                chkSUN3.Checked = false;
                chkSUN4.Checked = false;
                chkSUN5.Checked = false;
                chkSUN6.Checked = false;
                chkSUN7.Checked = false;
                chkSUN8.Checked = false;
                chkSUN9.Checked = false;
                chkSUN10.Checked = false;
                chkSUN11.Checked = false;
                chkSUN12.Checked = false;
                chkMON1.Checked = false;
                chkMON2.Checked = false;
                chkMON3.Checked = false;
                chkMON4.Checked = false;
                chkMON5.Checked = false;
                chkMON6.Checked = false;
                chkMON7.Checked = false;
                chkMON8.Checked = false;
                chkMON9.Checked = false;
                chkMON10.Checked = false;
                chkMON11.Checked = false;
                chkMON12.Checked = false;
                chkTUE1.Checked = false;
                chkTUE2.Checked = false;
                chkTUE3.Checked = false;
                chkTUE4.Checked = false;
                chkTUE5.Checked = false;
                chkTUE6.Checked = false;
                chkTUE7.Checked = false;
                chkTUE8.Checked = false;
                chkTUE9.Checked = false;
                chkTUE10.Checked = false;
                chkTUE11.Checked = false;
                chkTUE12.Checked = false;
                chkWED1.Checked = false;
                chkWED2.Checked = false;
                chkWED3.Checked = false;
                chkWED4.Checked = false;
                chkWED5.Checked = false;
                chkWED6.Checked = false;
                chkWED7.Checked = false;
                chkWED8.Checked = false;
                chkWED9.Checked = false;
                chkWED10.Checked = false;
                chkWED11.Checked = false;
                chkWED12.Checked = false;
                chkTHU1.Checked = false;
                chkTHU2.Checked = false;
                chkTHU3.Checked = false;
                chkTHU4.Checked = false;
                chkTHU5.Checked = false;
                chkTHU6.Checked = false;
                chkTHU7.Checked = false;
                chkTHU8.Checked = false;
                chkTHU9.Checked = false;
                chkTHU10.Checked = false;
                chkTHU11.Checked = false;
                chkTHU12.Checked = false;
                chkFRI1.Checked = false;
                chkFRI2.Checked = false;
                chkFRI3.Checked = false;
                chkFRI4.Checked = false;
                chkFRI5.Checked = false;
                chkFRI6.Checked = false;
                chkFRI7.Checked = false;
                chkFRI8.Checked = false;
                chkFRI9.Checked = false;
                chkFRI10.Checked = false;
                chkFRI11.Checked = false;
                chkFRI12.Checked = false;
                chkSAT1.Checked = false;
                chkSAT2.Checked = false;
                chkSAT3.Checked = false;
                chkSAT4.Checked = false;
                chkSAT5.Checked = false;
                chkSAT6.Checked = false;
                chkSAT7.Checked = false;
                chkSAT8.Checked = false;
                chkSAT9.Checked = false;
                chkSAT10.Checked = false;
                chkSAT11.Checked = false;
                chkSAT12.Checked = false;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion

        #region Control Events

        private void radSchedule_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                pnlSchedule.Enabled = radSchedule.Checked;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK);
            }
        }

        /// <summary>
        /// On cancel button click; to close the form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
                this.Dispose();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK);
            }
        }

        /// <summary>
        /// On OK button click; To save the details
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnOK_Click(object sender, EventArgs e)
        {
            try
            {
                string weekStr = string.Empty, rowStr = string.Empty;
                string schedule = string.Empty;
                foreach (Control ctrl in this.pnlSchedule.Controls.OfType<CheckBox>())
                {
                    if (((CheckBox)ctrl).Checked)
                    {
                        switch (ctrl.Name.Substring(3, 3))
                        {
                            case "SUN":
                                weekStr = "0";
                                break;
                            case "MON":
                                weekStr = "1";
                                break;
                            case "TUE":
                                weekStr = "2";
                                break;
                            case "WED":
                                weekStr = "3";
                                break;
                            case "THU":
                                weekStr = "4";
                                break;
                            case "FRI":
                                weekStr = "5";
                                break;
                            case "SAT":
                                weekStr = "6";
                                break;
                        }
                        switch (ctrl.Name.Substring(6))
                        {
                            case "1":
                                rowStr = "00";
                                break;
                            case "2":
                                rowStr = "02";
                                break;
                            case "3":
                                rowStr = "04";
                                break;
                            case "4":
                                rowStr = "06";
                                break;
                            case "5":
                                rowStr = "08";
                                break;
                            case "6":
                                rowStr = "10";
                                break;
                            case "7":
                                rowStr = "12";
                                break;
                            case "8":
                                rowStr = "14";
                                break;
                            case "9":
                                rowStr = "16";
                                break;
                            case "10":
                                rowStr = "18";
                                break;
                            case "11":
                                rowStr = "20";
                                break;
                            case "12":
                                rowStr = "22";
                                break;
                        }
                        schedule += weekStr + rowStr + ",";
                        weekStr = string.Empty;
                        rowStr = string.Empty;
                    }
                }
                if(schedule == string.Empty && radSchedule.Checked)
                {
                    MessageBox.Show("Select one or more time slots to set the Directory Synchronization schedule.");
                }
                else
                {
                    RegistryKey key = Registry.LocalMachine.OpenSubKey(RegistryConstants.DS_SYNC_SVC, true);
                    key.SetValue(RegistryConstants.DS_SYNC_MODE, radSchedule.Checked ? "S" : "C");
                    key.SetValue(RegistryConstants.DS_SYNC_SCHEDULE, schedule);
                    key.Close();
                    this.Close();
                    this.Dispose();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK);
            }
        }

        #endregion
    }
}
