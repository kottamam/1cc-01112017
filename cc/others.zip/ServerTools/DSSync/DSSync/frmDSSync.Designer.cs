﻿namespace DSSync
{
    partial class frmDSSync
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDSSync));
            this.mnuDSSync = new System.Windows.Forms.MenuStrip();
            this.btnStop = new System.Windows.Forms.Button();
            this.btnStart = new System.Windows.Forms.Button();
            this.dgvServiceList = new System.Windows.Forms.DataGridView();
            this.colComputer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colService = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colState = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colComments = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnSyncronization = new System.Windows.Forms.Button();
            this.btnConnectionList = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvServiceList)).BeginInit();
            this.SuspendLayout();
            // 
            // mnuDSSync
            // 
            this.mnuDSSync.Location = new System.Drawing.Point(0, 0);
            this.mnuDSSync.Name = "mnuDSSync";
            this.mnuDSSync.Size = new System.Drawing.Size(751, 24);
            this.mnuDSSync.TabIndex = 0;
            this.mnuDSSync.Text = "mnuDSSync";
            // 
            // btnStop
            // 
            this.btnStop.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnStop.BackgroundImage")));
            this.btnStop.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnStop.Location = new System.Drawing.Point(72, 4);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(16, 16);
            this.btnStop.TabIndex = 1;
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // btnStart
            // 
            this.btnStart.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnStart.BackgroundImage")));
            this.btnStart.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnStart.FlatAppearance.BorderSize = 0;
            this.btnStart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStart.Location = new System.Drawing.Point(50, 4);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(16, 16);
            this.btnStart.TabIndex = 2;
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // dgvServiceList
            // 
            this.dgvServiceList.AllowUserToAddRows = false;
            this.dgvServiceList.AllowUserToDeleteRows = false;
            this.dgvServiceList.AllowUserToOrderColumns = true;
            this.dgvServiceList.AllowUserToResizeRows = false;
            this.dgvServiceList.BackgroundColor = System.Drawing.Color.White;
            this.dgvServiceList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvServiceList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvServiceList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colComputer,
            this.colService,
            this.colState,
            this.colComments});
            this.dgvServiceList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvServiceList.Location = new System.Drawing.Point(0, 24);
            this.dgvServiceList.Name = "dgvServiceList";
            this.dgvServiceList.RowHeadersVisible = false;
            this.dgvServiceList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvServiceList.Size = new System.Drawing.Size(751, 337);
            this.dgvServiceList.TabIndex = 3;
            this.dgvServiceList.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvServiceList_RowEnter);
            // 
            // colComputer
            // 
            this.colComputer.HeaderText = "Computer";
            this.colComputer.Name = "colComputer";
            this.colComputer.ReadOnly = true;
            this.colComputer.Width = 200;
            // 
            // colService
            // 
            this.colService.HeaderText = "Service";
            this.colService.Name = "colService";
            this.colService.ReadOnly = true;
            this.colService.Width = 250;
            // 
            // colState
            // 
            this.colState.HeaderText = "State";
            this.colState.Name = "colState";
            this.colState.ReadOnly = true;
            this.colState.Width = 150;
            // 
            // colComments
            // 
            this.colComments.HeaderText = "Comments";
            this.colComments.Name = "colComments";
            this.colComments.ReadOnly = true;
            this.colComments.Width = 150;
            // 
            // btnSyncronization
            // 
            this.btnSyncronization.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSyncronization.BackgroundImage")));
            this.btnSyncronization.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSyncronization.FlatAppearance.BorderSize = 0;
            this.btnSyncronization.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSyncronization.Location = new System.Drawing.Point(28, 4);
            this.btnSyncronization.Name = "btnSyncronization";
            this.btnSyncronization.Size = new System.Drawing.Size(16, 16);
            this.btnSyncronization.TabIndex = 4;
            this.btnSyncronization.UseVisualStyleBackColor = true;
            this.btnSyncronization.Click += new System.EventHandler(this.btnSyncronization_Click);
            // 
            // btnConnectionList
            // 
            this.btnConnectionList.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnConnectionList.BackgroundImage")));
            this.btnConnectionList.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnConnectionList.FlatAppearance.BorderSize = 0;
            this.btnConnectionList.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnConnectionList.Location = new System.Drawing.Point(6, 4);
            this.btnConnectionList.Name = "btnConnectionList";
            this.btnConnectionList.Size = new System.Drawing.Size(16, 16);
            this.btnConnectionList.TabIndex = 5;
            this.btnConnectionList.UseVisualStyleBackColor = true;
            this.btnConnectionList.Click += new System.EventHandler(this.btnConnectionList_Click);
            // 
            // frmDSSync
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(751, 361);
            this.Controls.Add(this.btnConnectionList);
            this.Controls.Add(this.btnSyncronization);
            this.Controls.Add(this.dgvServiceList);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.btnStop);
            this.Controls.Add(this.mnuDSSync);
            this.KeyPreview = true;
            this.MainMenuStrip = this.mnuDSSync;
            this.Name = "frmDSSync";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Directory Synchronization Service";
            this.Load += new System.EventHandler(this.frmDSSync_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvServiceList)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mnuDSSync;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.DataGridView dgvServiceList;
        private System.Windows.Forms.DataGridViewTextBoxColumn colComputer;
        private System.Windows.Forms.DataGridViewTextBoxColumn colService;
        private System.Windows.Forms.DataGridViewTextBoxColumn colState;
        private System.Windows.Forms.DataGridViewTextBoxColumn colComments;
        private System.Windows.Forms.Button btnSyncronization;
        private System.Windows.Forms.Button btnConnectionList;
    }
}