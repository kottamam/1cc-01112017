﻿#region Using Directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

#endregion

namespace DSSync
{
    public partial class frmInputBox : Form
    {
        #region Constroctor

        public frmInputBox()
        {
            InitializeComponent();
        }

        #endregion

        #region Public Methods

        public DialogResult ShowDialog(string message)
        {
            this.lblInfo.Text = message;
            return base.ShowDialog();
        }

        public DialogResult ShowDialog(string message, string title)
        {
            this.lblInfo.Text = message;
            this.Text = title;
            return base.ShowDialog();
        }

        public string ReturnValue { get; set; }

        #endregion

        #region Button Events

        private void btnOK_Click(object sender, EventArgs e)
        {
            try
            {
                this.ReturnValue = txtInput.Text;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            try
            {
                this.ReturnValue = string.Empty;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK);
            }
        }

        #endregion

        #region Form Events

        private void frmInputBox_Load(object sender, EventArgs e)
        {
            try
            {
                txtInput.Text = "";
                this.ReturnValue = string.Empty;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK);
            }
        }

        #endregion
    }
}
