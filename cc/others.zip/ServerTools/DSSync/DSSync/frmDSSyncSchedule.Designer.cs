﻿namespace DSSync
{
    partial class frmDSSyncSchedule
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.radSchedule = new System.Windows.Forms.RadioButton();
            this.radContinuous = new System.Windows.Forms.RadioButton();
            this.lbl0002 = new System.Windows.Forms.Label();
            this.lblSUN = new System.Windows.Forms.Label();
            this.lblMON = new System.Windows.Forms.Label();
            this.lblTUE = new System.Windows.Forms.Label();
            this.lblWED = new System.Windows.Forms.Label();
            this.lblTHU = new System.Windows.Forms.Label();
            this.lblFRI = new System.Windows.Forms.Label();
            this.lblSAT = new System.Windows.Forms.Label();
            this.chkSUN1 = new System.Windows.Forms.CheckBox();
            this.chkMON1 = new System.Windows.Forms.CheckBox();
            this.chkTUE1 = new System.Windows.Forms.CheckBox();
            this.chkWED1 = new System.Windows.Forms.CheckBox();
            this.chkTHU1 = new System.Windows.Forms.CheckBox();
            this.chkFRI1 = new System.Windows.Forms.CheckBox();
            this.chkSAT1 = new System.Windows.Forms.CheckBox();
            this.lbl0204 = new System.Windows.Forms.Label();
            this.chkSUN2 = new System.Windows.Forms.CheckBox();
            this.chkMON2 = new System.Windows.Forms.CheckBox();
            this.chkTUE2 = new System.Windows.Forms.CheckBox();
            this.chkWED2 = new System.Windows.Forms.CheckBox();
            this.chkTHU2 = new System.Windows.Forms.CheckBox();
            this.chkFRI2 = new System.Windows.Forms.CheckBox();
            this.chkSAT2 = new System.Windows.Forms.CheckBox();
            this.lbl0406 = new System.Windows.Forms.Label();
            this.lbl0608 = new System.Windows.Forms.Label();
            this.chkSUN3 = new System.Windows.Forms.CheckBox();
            this.chkMON3 = new System.Windows.Forms.CheckBox();
            this.chkSUN4 = new System.Windows.Forms.CheckBox();
            this.chkTUE3 = new System.Windows.Forms.CheckBox();
            this.chkMON4 = new System.Windows.Forms.CheckBox();
            this.chkWED3 = new System.Windows.Forms.CheckBox();
            this.chkTUE4 = new System.Windows.Forms.CheckBox();
            this.chkTHU3 = new System.Windows.Forms.CheckBox();
            this.chkWED4 = new System.Windows.Forms.CheckBox();
            this.chkFRI3 = new System.Windows.Forms.CheckBox();
            this.chkTHU4 = new System.Windows.Forms.CheckBox();
            this.chkSAT3 = new System.Windows.Forms.CheckBox();
            this.chkFRI4 = new System.Windows.Forms.CheckBox();
            this.chkSAT4 = new System.Windows.Forms.CheckBox();
            this.lbl0810 = new System.Windows.Forms.Label();
            this.lbl1214 = new System.Windows.Forms.Label();
            this.lbl1012 = new System.Windows.Forms.Label();
            this.lbl1416 = new System.Windows.Forms.Label();
            this.chkSUN5 = new System.Windows.Forms.CheckBox();
            this.chkMON5 = new System.Windows.Forms.CheckBox();
            this.chkSUN7 = new System.Windows.Forms.CheckBox();
            this.chkSUN6 = new System.Windows.Forms.CheckBox();
            this.chkMON7 = new System.Windows.Forms.CheckBox();
            this.chkTUE5 = new System.Windows.Forms.CheckBox();
            this.chkSUN8 = new System.Windows.Forms.CheckBox();
            this.chkMON6 = new System.Windows.Forms.CheckBox();
            this.chkTUE7 = new System.Windows.Forms.CheckBox();
            this.chkWED5 = new System.Windows.Forms.CheckBox();
            this.chkMON8 = new System.Windows.Forms.CheckBox();
            this.chkTUE6 = new System.Windows.Forms.CheckBox();
            this.chkWED7 = new System.Windows.Forms.CheckBox();
            this.chkTHU5 = new System.Windows.Forms.CheckBox();
            this.chkTUE8 = new System.Windows.Forms.CheckBox();
            this.chkWED6 = new System.Windows.Forms.CheckBox();
            this.chkTHU7 = new System.Windows.Forms.CheckBox();
            this.chkFRI5 = new System.Windows.Forms.CheckBox();
            this.chkWED8 = new System.Windows.Forms.CheckBox();
            this.chkTHU6 = new System.Windows.Forms.CheckBox();
            this.chkFRI7 = new System.Windows.Forms.CheckBox();
            this.chkSAT5 = new System.Windows.Forms.CheckBox();
            this.chkTHU8 = new System.Windows.Forms.CheckBox();
            this.chkFRI6 = new System.Windows.Forms.CheckBox();
            this.chkSAT7 = new System.Windows.Forms.CheckBox();
            this.chkSAT6 = new System.Windows.Forms.CheckBox();
            this.chkFRI8 = new System.Windows.Forms.CheckBox();
            this.chkSAT8 = new System.Windows.Forms.CheckBox();
            this.lbl1618 = new System.Windows.Forms.Label();
            this.lbl2022 = new System.Windows.Forms.Label();
            this.lbl1820 = new System.Windows.Forms.Label();
            this.lbl2224 = new System.Windows.Forms.Label();
            this.chkSUN9 = new System.Windows.Forms.CheckBox();
            this.chkMON9 = new System.Windows.Forms.CheckBox();
            this.chkSUN11 = new System.Windows.Forms.CheckBox();
            this.chkSUN10 = new System.Windows.Forms.CheckBox();
            this.chkMON11 = new System.Windows.Forms.CheckBox();
            this.chkTUE9 = new System.Windows.Forms.CheckBox();
            this.chkSUN12 = new System.Windows.Forms.CheckBox();
            this.chkMON10 = new System.Windows.Forms.CheckBox();
            this.chkTUE11 = new System.Windows.Forms.CheckBox();
            this.chkWED9 = new System.Windows.Forms.CheckBox();
            this.chkMON12 = new System.Windows.Forms.CheckBox();
            this.chkTUE10 = new System.Windows.Forms.CheckBox();
            this.chkWED11 = new System.Windows.Forms.CheckBox();
            this.chkTHU9 = new System.Windows.Forms.CheckBox();
            this.chkTUE12 = new System.Windows.Forms.CheckBox();
            this.chkWED10 = new System.Windows.Forms.CheckBox();
            this.chkTHU11 = new System.Windows.Forms.CheckBox();
            this.chkFRI9 = new System.Windows.Forms.CheckBox();
            this.chkWED12 = new System.Windows.Forms.CheckBox();
            this.chkTHU10 = new System.Windows.Forms.CheckBox();
            this.chkFRI11 = new System.Windows.Forms.CheckBox();
            this.chkSAT9 = new System.Windows.Forms.CheckBox();
            this.chkTHU12 = new System.Windows.Forms.CheckBox();
            this.chkFRI10 = new System.Windows.Forms.CheckBox();
            this.chkSAT11 = new System.Windows.Forms.CheckBox();
            this.chkSAT10 = new System.Windows.Forms.CheckBox();
            this.chkFRI12 = new System.Windows.Forms.CheckBox();
            this.chkSAT12 = new System.Windows.Forms.CheckBox();
            this.btnOK = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.pnlSchedule = new System.Windows.Forms.Panel();
            this.pnlSchedule.SuspendLayout();
            this.SuspendLayout();
            // 
            // radSchedule
            // 
            this.radSchedule.AutoSize = true;
            this.radSchedule.Location = new System.Drawing.Point(63, 20);
            this.radSchedule.Name = "radSchedule";
            this.radSchedule.Size = new System.Drawing.Size(70, 17);
            this.radSchedule.TabIndex = 0;
            this.radSchedule.TabStop = true;
            this.radSchedule.Text = "Schedule";
            this.radSchedule.UseVisualStyleBackColor = true;
            this.radSchedule.CheckedChanged += new System.EventHandler(this.radSchedule_CheckedChanged);
            // 
            // radContinuous
            // 
            this.radContinuous.AutoSize = true;
            this.radContinuous.Location = new System.Drawing.Point(179, 20);
            this.radContinuous.Name = "radContinuous";
            this.radContinuous.Size = new System.Drawing.Size(78, 17);
            this.radContinuous.TabIndex = 1;
            this.radContinuous.TabStop = true;
            this.radContinuous.Text = "Continuous";
            this.radContinuous.UseVisualStyleBackColor = true;
            this.radContinuous.CheckedChanged += new System.EventHandler(this.radSchedule_CheckedChanged);
            // 
            // lbl0002
            // 
            this.lbl0002.AutoSize = true;
            this.lbl0002.Location = new System.Drawing.Point(11, 41);
            this.lbl0002.Name = "lbl0002";
            this.lbl0002.Size = new System.Drawing.Size(34, 13);
            this.lbl0002.TabIndex = 1;
            this.lbl0002.Text = "00-02";
            // 
            // lblSUN
            // 
            this.lblSUN.Location = new System.Drawing.Point(55, 12);
            this.lblSUN.Name = "lblSUN";
            this.lblSUN.Size = new System.Drawing.Size(37, 13);
            this.lblSUN.TabIndex = 1;
            this.lblSUN.Text = "SUN";
            // 
            // lblMON
            // 
            this.lblMON.Location = new System.Drawing.Point(98, 12);
            this.lblMON.Name = "lblMON";
            this.lblMON.Size = new System.Drawing.Size(33, 13);
            this.lblMON.TabIndex = 1;
            this.lblMON.Text = "MON";
            // 
            // lblTUE
            // 
            this.lblTUE.Location = new System.Drawing.Point(137, 12);
            this.lblTUE.Name = "lblTUE";
            this.lblTUE.Size = new System.Drawing.Size(33, 13);
            this.lblTUE.TabIndex = 1;
            this.lblTUE.Text = "TUE";
            // 
            // lblWED
            // 
            this.lblWED.Location = new System.Drawing.Point(176, 12);
            this.lblWED.Name = "lblWED";
            this.lblWED.Size = new System.Drawing.Size(33, 13);
            this.lblWED.TabIndex = 1;
            this.lblWED.Text = "WED";
            // 
            // lblTHU
            // 
            this.lblTHU.Location = new System.Drawing.Point(218, 12);
            this.lblTHU.Name = "lblTHU";
            this.lblTHU.Size = new System.Drawing.Size(33, 13);
            this.lblTHU.TabIndex = 1;
            this.lblTHU.Text = "THU";
            // 
            // lblFRI
            // 
            this.lblFRI.Location = new System.Drawing.Point(257, 12);
            this.lblFRI.Name = "lblFRI";
            this.lblFRI.Size = new System.Drawing.Size(33, 13);
            this.lblFRI.TabIndex = 1;
            this.lblFRI.Text = "FRI";
            // 
            // lblSAT
            // 
            this.lblSAT.Location = new System.Drawing.Point(296, 12);
            this.lblSAT.Name = "lblSAT";
            this.lblSAT.Size = new System.Drawing.Size(33, 13);
            this.lblSAT.TabIndex = 1;
            this.lblSAT.Text = "SAT";
            // 
            // chkSUN1
            // 
            this.chkSUN1.AutoSize = true;
            this.chkSUN1.Location = new System.Drawing.Point(63, 41);
            this.chkSUN1.Name = "chkSUN1";
            this.chkSUN1.Size = new System.Drawing.Size(15, 14);
            this.chkSUN1.TabIndex = 0;
            this.chkSUN1.UseVisualStyleBackColor = true;
            // 
            // chkMON1
            // 
            this.chkMON1.AutoSize = true;
            this.chkMON1.Location = new System.Drawing.Point(106, 41);
            this.chkMON1.Name = "chkMON1";
            this.chkMON1.Size = new System.Drawing.Size(15, 14);
            this.chkMON1.TabIndex = 1;
            this.chkMON1.UseVisualStyleBackColor = true;
            // 
            // chkTUE1
            // 
            this.chkTUE1.AutoSize = true;
            this.chkTUE1.Location = new System.Drawing.Point(145, 41);
            this.chkTUE1.Name = "chkTUE1";
            this.chkTUE1.Size = new System.Drawing.Size(15, 14);
            this.chkTUE1.TabIndex = 2;
            this.chkTUE1.UseVisualStyleBackColor = true;
            // 
            // chkWED1
            // 
            this.chkWED1.AutoSize = true;
            this.chkWED1.Location = new System.Drawing.Point(184, 41);
            this.chkWED1.Name = "chkWED1";
            this.chkWED1.Size = new System.Drawing.Size(15, 14);
            this.chkWED1.TabIndex = 3;
            this.chkWED1.UseVisualStyleBackColor = true;
            // 
            // chkTHU1
            // 
            this.chkTHU1.AutoSize = true;
            this.chkTHU1.Location = new System.Drawing.Point(226, 41);
            this.chkTHU1.Name = "chkTHU1";
            this.chkTHU1.Size = new System.Drawing.Size(15, 14);
            this.chkTHU1.TabIndex = 4;
            this.chkTHU1.UseVisualStyleBackColor = true;
            // 
            // chkFRI1
            // 
            this.chkFRI1.AutoSize = true;
            this.chkFRI1.Location = new System.Drawing.Point(265, 41);
            this.chkFRI1.Name = "chkFRI1";
            this.chkFRI1.Size = new System.Drawing.Size(15, 14);
            this.chkFRI1.TabIndex = 5;
            this.chkFRI1.UseVisualStyleBackColor = true;
            // 
            // chkSAT1
            // 
            this.chkSAT1.AutoSize = true;
            this.chkSAT1.Location = new System.Drawing.Point(304, 41);
            this.chkSAT1.Name = "chkSAT1";
            this.chkSAT1.Size = new System.Drawing.Size(15, 14);
            this.chkSAT1.TabIndex = 6;
            this.chkSAT1.UseVisualStyleBackColor = true;
            // 
            // lbl0204
            // 
            this.lbl0204.AutoSize = true;
            this.lbl0204.Location = new System.Drawing.Point(11, 74);
            this.lbl0204.Name = "lbl0204";
            this.lbl0204.Size = new System.Drawing.Size(34, 13);
            this.lbl0204.TabIndex = 1;
            this.lbl0204.Text = "02-04";
            // 
            // chkSUN2
            // 
            this.chkSUN2.AutoSize = true;
            this.chkSUN2.Location = new System.Drawing.Point(63, 74);
            this.chkSUN2.Name = "chkSUN2";
            this.chkSUN2.Size = new System.Drawing.Size(15, 14);
            this.chkSUN2.TabIndex = 7;
            this.chkSUN2.UseVisualStyleBackColor = true;
            // 
            // chkMON2
            // 
            this.chkMON2.AutoSize = true;
            this.chkMON2.Location = new System.Drawing.Point(106, 74);
            this.chkMON2.Name = "chkMON2";
            this.chkMON2.Size = new System.Drawing.Size(15, 14);
            this.chkMON2.TabIndex = 8;
            this.chkMON2.UseVisualStyleBackColor = true;
            // 
            // chkTUE2
            // 
            this.chkTUE2.AutoSize = true;
            this.chkTUE2.Location = new System.Drawing.Point(145, 74);
            this.chkTUE2.Name = "chkTUE2";
            this.chkTUE2.Size = new System.Drawing.Size(15, 14);
            this.chkTUE2.TabIndex = 9;
            this.chkTUE2.UseVisualStyleBackColor = true;
            // 
            // chkWED2
            // 
            this.chkWED2.AutoSize = true;
            this.chkWED2.Location = new System.Drawing.Point(184, 74);
            this.chkWED2.Name = "chkWED2";
            this.chkWED2.Size = new System.Drawing.Size(15, 14);
            this.chkWED2.TabIndex = 10;
            this.chkWED2.UseVisualStyleBackColor = true;
            // 
            // chkTHU2
            // 
            this.chkTHU2.AutoSize = true;
            this.chkTHU2.Location = new System.Drawing.Point(226, 74);
            this.chkTHU2.Name = "chkTHU2";
            this.chkTHU2.Size = new System.Drawing.Size(15, 14);
            this.chkTHU2.TabIndex = 11;
            this.chkTHU2.UseVisualStyleBackColor = true;
            // 
            // chkFRI2
            // 
            this.chkFRI2.AutoSize = true;
            this.chkFRI2.Location = new System.Drawing.Point(265, 74);
            this.chkFRI2.Name = "chkFRI2";
            this.chkFRI2.Size = new System.Drawing.Size(15, 14);
            this.chkFRI2.TabIndex = 12;
            this.chkFRI2.UseVisualStyleBackColor = true;
            // 
            // chkSAT2
            // 
            this.chkSAT2.AutoSize = true;
            this.chkSAT2.Location = new System.Drawing.Point(304, 74);
            this.chkSAT2.Name = "chkSAT2";
            this.chkSAT2.Size = new System.Drawing.Size(15, 14);
            this.chkSAT2.TabIndex = 13;
            this.chkSAT2.UseVisualStyleBackColor = true;
            // 
            // lbl0406
            // 
            this.lbl0406.AutoSize = true;
            this.lbl0406.Location = new System.Drawing.Point(11, 106);
            this.lbl0406.Name = "lbl0406";
            this.lbl0406.Size = new System.Drawing.Size(34, 13);
            this.lbl0406.TabIndex = 1;
            this.lbl0406.Text = "04-06";
            // 
            // lbl0608
            // 
            this.lbl0608.AutoSize = true;
            this.lbl0608.Location = new System.Drawing.Point(11, 139);
            this.lbl0608.Name = "lbl0608";
            this.lbl0608.Size = new System.Drawing.Size(34, 13);
            this.lbl0608.TabIndex = 1;
            this.lbl0608.Text = "06-08";
            // 
            // chkSUN3
            // 
            this.chkSUN3.AutoSize = true;
            this.chkSUN3.Location = new System.Drawing.Point(63, 106);
            this.chkSUN3.Name = "chkSUN3";
            this.chkSUN3.Size = new System.Drawing.Size(15, 14);
            this.chkSUN3.TabIndex = 14;
            this.chkSUN3.UseVisualStyleBackColor = true;
            // 
            // chkMON3
            // 
            this.chkMON3.AutoSize = true;
            this.chkMON3.Location = new System.Drawing.Point(106, 106);
            this.chkMON3.Name = "chkMON3";
            this.chkMON3.Size = new System.Drawing.Size(15, 14);
            this.chkMON3.TabIndex = 15;
            this.chkMON3.UseVisualStyleBackColor = true;
            // 
            // chkSUN4
            // 
            this.chkSUN4.AutoSize = true;
            this.chkSUN4.Location = new System.Drawing.Point(63, 139);
            this.chkSUN4.Name = "chkSUN4";
            this.chkSUN4.Size = new System.Drawing.Size(15, 14);
            this.chkSUN4.TabIndex = 21;
            this.chkSUN4.UseVisualStyleBackColor = true;
            // 
            // chkTUE3
            // 
            this.chkTUE3.AutoSize = true;
            this.chkTUE3.Location = new System.Drawing.Point(145, 106);
            this.chkTUE3.Name = "chkTUE3";
            this.chkTUE3.Size = new System.Drawing.Size(15, 14);
            this.chkTUE3.TabIndex = 16;
            this.chkTUE3.UseVisualStyleBackColor = true;
            // 
            // chkMON4
            // 
            this.chkMON4.AutoSize = true;
            this.chkMON4.Location = new System.Drawing.Point(106, 139);
            this.chkMON4.Name = "chkMON4";
            this.chkMON4.Size = new System.Drawing.Size(15, 14);
            this.chkMON4.TabIndex = 22;
            this.chkMON4.UseVisualStyleBackColor = true;
            // 
            // chkWED3
            // 
            this.chkWED3.AutoSize = true;
            this.chkWED3.Location = new System.Drawing.Point(184, 106);
            this.chkWED3.Name = "chkWED3";
            this.chkWED3.Size = new System.Drawing.Size(15, 14);
            this.chkWED3.TabIndex = 17;
            this.chkWED3.UseVisualStyleBackColor = true;
            // 
            // chkTUE4
            // 
            this.chkTUE4.AutoSize = true;
            this.chkTUE4.Location = new System.Drawing.Point(145, 139);
            this.chkTUE4.Name = "chkTUE4";
            this.chkTUE4.Size = new System.Drawing.Size(15, 14);
            this.chkTUE4.TabIndex = 23;
            this.chkTUE4.UseVisualStyleBackColor = true;
            // 
            // chkTHU3
            // 
            this.chkTHU3.AutoSize = true;
            this.chkTHU3.Location = new System.Drawing.Point(226, 106);
            this.chkTHU3.Name = "chkTHU3";
            this.chkTHU3.Size = new System.Drawing.Size(15, 14);
            this.chkTHU3.TabIndex = 18;
            this.chkTHU3.UseVisualStyleBackColor = true;
            // 
            // chkWED4
            // 
            this.chkWED4.AutoSize = true;
            this.chkWED4.Location = new System.Drawing.Point(184, 139);
            this.chkWED4.Name = "chkWED4";
            this.chkWED4.Size = new System.Drawing.Size(15, 14);
            this.chkWED4.TabIndex = 24;
            this.chkWED4.UseVisualStyleBackColor = true;
            // 
            // chkFRI3
            // 
            this.chkFRI3.AutoSize = true;
            this.chkFRI3.Location = new System.Drawing.Point(265, 106);
            this.chkFRI3.Name = "chkFRI3";
            this.chkFRI3.Size = new System.Drawing.Size(15, 14);
            this.chkFRI3.TabIndex = 19;
            this.chkFRI3.UseVisualStyleBackColor = true;
            // 
            // chkTHU4
            // 
            this.chkTHU4.AutoSize = true;
            this.chkTHU4.Location = new System.Drawing.Point(226, 139);
            this.chkTHU4.Name = "chkTHU4";
            this.chkTHU4.Size = new System.Drawing.Size(15, 14);
            this.chkTHU4.TabIndex = 25;
            this.chkTHU4.UseVisualStyleBackColor = true;
            // 
            // chkSAT3
            // 
            this.chkSAT3.AutoSize = true;
            this.chkSAT3.Location = new System.Drawing.Point(304, 106);
            this.chkSAT3.Name = "chkSAT3";
            this.chkSAT3.Size = new System.Drawing.Size(15, 14);
            this.chkSAT3.TabIndex = 20;
            this.chkSAT3.UseVisualStyleBackColor = true;
            // 
            // chkFRI4
            // 
            this.chkFRI4.AutoSize = true;
            this.chkFRI4.Location = new System.Drawing.Point(265, 139);
            this.chkFRI4.Name = "chkFRI4";
            this.chkFRI4.Size = new System.Drawing.Size(15, 14);
            this.chkFRI4.TabIndex = 26;
            this.chkFRI4.UseVisualStyleBackColor = true;
            // 
            // chkSAT4
            // 
            this.chkSAT4.AutoSize = true;
            this.chkSAT4.Location = new System.Drawing.Point(304, 139);
            this.chkSAT4.Name = "chkSAT4";
            this.chkSAT4.Size = new System.Drawing.Size(15, 14);
            this.chkSAT4.TabIndex = 27;
            this.chkSAT4.UseVisualStyleBackColor = true;
            // 
            // lbl0810
            // 
            this.lbl0810.AutoSize = true;
            this.lbl0810.Location = new System.Drawing.Point(11, 171);
            this.lbl0810.Name = "lbl0810";
            this.lbl0810.Size = new System.Drawing.Size(34, 13);
            this.lbl0810.TabIndex = 1;
            this.lbl0810.Text = "08-10";
            // 
            // lbl1214
            // 
            this.lbl1214.AutoSize = true;
            this.lbl1214.Location = new System.Drawing.Point(11, 236);
            this.lbl1214.Name = "lbl1214";
            this.lbl1214.Size = new System.Drawing.Size(34, 13);
            this.lbl1214.TabIndex = 1;
            this.lbl1214.Text = "12-14";
            // 
            // lbl1012
            // 
            this.lbl1012.AutoSize = true;
            this.lbl1012.Location = new System.Drawing.Point(11, 204);
            this.lbl1012.Name = "lbl1012";
            this.lbl1012.Size = new System.Drawing.Size(34, 13);
            this.lbl1012.TabIndex = 1;
            this.lbl1012.Text = "10-12";
            // 
            // lbl1416
            // 
            this.lbl1416.AutoSize = true;
            this.lbl1416.Location = new System.Drawing.Point(11, 269);
            this.lbl1416.Name = "lbl1416";
            this.lbl1416.Size = new System.Drawing.Size(34, 13);
            this.lbl1416.TabIndex = 1;
            this.lbl1416.Text = "14-16";
            // 
            // chkSUN5
            // 
            this.chkSUN5.AutoSize = true;
            this.chkSUN5.Location = new System.Drawing.Point(63, 171);
            this.chkSUN5.Name = "chkSUN5";
            this.chkSUN5.Size = new System.Drawing.Size(15, 14);
            this.chkSUN5.TabIndex = 28;
            this.chkSUN5.UseVisualStyleBackColor = true;
            // 
            // chkMON5
            // 
            this.chkMON5.AutoSize = true;
            this.chkMON5.Location = new System.Drawing.Point(106, 171);
            this.chkMON5.Name = "chkMON5";
            this.chkMON5.Size = new System.Drawing.Size(15, 14);
            this.chkMON5.TabIndex = 29;
            this.chkMON5.UseVisualStyleBackColor = true;
            // 
            // chkSUN7
            // 
            this.chkSUN7.AutoSize = true;
            this.chkSUN7.Location = new System.Drawing.Point(63, 236);
            this.chkSUN7.Name = "chkSUN7";
            this.chkSUN7.Size = new System.Drawing.Size(15, 14);
            this.chkSUN7.TabIndex = 42;
            this.chkSUN7.UseVisualStyleBackColor = true;
            // 
            // chkSUN6
            // 
            this.chkSUN6.AutoSize = true;
            this.chkSUN6.Location = new System.Drawing.Point(63, 204);
            this.chkSUN6.Name = "chkSUN6";
            this.chkSUN6.Size = new System.Drawing.Size(15, 14);
            this.chkSUN6.TabIndex = 35;
            this.chkSUN6.UseVisualStyleBackColor = true;
            // 
            // chkMON7
            // 
            this.chkMON7.AutoSize = true;
            this.chkMON7.Location = new System.Drawing.Point(106, 236);
            this.chkMON7.Name = "chkMON7";
            this.chkMON7.Size = new System.Drawing.Size(15, 14);
            this.chkMON7.TabIndex = 43;
            this.chkMON7.UseVisualStyleBackColor = true;
            // 
            // chkTUE5
            // 
            this.chkTUE5.AutoSize = true;
            this.chkTUE5.Location = new System.Drawing.Point(145, 171);
            this.chkTUE5.Name = "chkTUE5";
            this.chkTUE5.Size = new System.Drawing.Size(15, 14);
            this.chkTUE5.TabIndex = 30;
            this.chkTUE5.UseVisualStyleBackColor = true;
            // 
            // chkSUN8
            // 
            this.chkSUN8.AutoSize = true;
            this.chkSUN8.Location = new System.Drawing.Point(63, 269);
            this.chkSUN8.Name = "chkSUN8";
            this.chkSUN8.Size = new System.Drawing.Size(15, 14);
            this.chkSUN8.TabIndex = 49;
            this.chkSUN8.UseVisualStyleBackColor = true;
            // 
            // chkMON6
            // 
            this.chkMON6.AutoSize = true;
            this.chkMON6.Location = new System.Drawing.Point(106, 204);
            this.chkMON6.Name = "chkMON6";
            this.chkMON6.Size = new System.Drawing.Size(15, 14);
            this.chkMON6.TabIndex = 36;
            this.chkMON6.UseVisualStyleBackColor = true;
            // 
            // chkTUE7
            // 
            this.chkTUE7.AutoSize = true;
            this.chkTUE7.Location = new System.Drawing.Point(145, 236);
            this.chkTUE7.Name = "chkTUE7";
            this.chkTUE7.Size = new System.Drawing.Size(15, 14);
            this.chkTUE7.TabIndex = 44;
            this.chkTUE7.UseVisualStyleBackColor = true;
            // 
            // chkWED5
            // 
            this.chkWED5.AutoSize = true;
            this.chkWED5.Location = new System.Drawing.Point(184, 171);
            this.chkWED5.Name = "chkWED5";
            this.chkWED5.Size = new System.Drawing.Size(15, 14);
            this.chkWED5.TabIndex = 31;
            this.chkWED5.UseVisualStyleBackColor = true;
            // 
            // chkMON8
            // 
            this.chkMON8.AutoSize = true;
            this.chkMON8.Location = new System.Drawing.Point(106, 269);
            this.chkMON8.Name = "chkMON8";
            this.chkMON8.Size = new System.Drawing.Size(15, 14);
            this.chkMON8.TabIndex = 50;
            this.chkMON8.UseVisualStyleBackColor = true;
            // 
            // chkTUE6
            // 
            this.chkTUE6.AutoSize = true;
            this.chkTUE6.Location = new System.Drawing.Point(145, 204);
            this.chkTUE6.Name = "chkTUE6";
            this.chkTUE6.Size = new System.Drawing.Size(15, 14);
            this.chkTUE6.TabIndex = 37;
            this.chkTUE6.UseVisualStyleBackColor = true;
            // 
            // chkWED7
            // 
            this.chkWED7.AutoSize = true;
            this.chkWED7.Location = new System.Drawing.Point(184, 236);
            this.chkWED7.Name = "chkWED7";
            this.chkWED7.Size = new System.Drawing.Size(15, 14);
            this.chkWED7.TabIndex = 45;
            this.chkWED7.UseVisualStyleBackColor = true;
            // 
            // chkTHU5
            // 
            this.chkTHU5.AutoSize = true;
            this.chkTHU5.Location = new System.Drawing.Point(226, 171);
            this.chkTHU5.Name = "chkTHU5";
            this.chkTHU5.Size = new System.Drawing.Size(15, 14);
            this.chkTHU5.TabIndex = 32;
            this.chkTHU5.UseVisualStyleBackColor = true;
            // 
            // chkTUE8
            // 
            this.chkTUE8.AutoSize = true;
            this.chkTUE8.Location = new System.Drawing.Point(145, 269);
            this.chkTUE8.Name = "chkTUE8";
            this.chkTUE8.Size = new System.Drawing.Size(15, 14);
            this.chkTUE8.TabIndex = 51;
            this.chkTUE8.UseVisualStyleBackColor = true;
            // 
            // chkWED6
            // 
            this.chkWED6.AutoSize = true;
            this.chkWED6.Location = new System.Drawing.Point(184, 204);
            this.chkWED6.Name = "chkWED6";
            this.chkWED6.Size = new System.Drawing.Size(15, 14);
            this.chkWED6.TabIndex = 38;
            this.chkWED6.UseVisualStyleBackColor = true;
            // 
            // chkTHU7
            // 
            this.chkTHU7.AutoSize = true;
            this.chkTHU7.Location = new System.Drawing.Point(226, 236);
            this.chkTHU7.Name = "chkTHU7";
            this.chkTHU7.Size = new System.Drawing.Size(15, 14);
            this.chkTHU7.TabIndex = 46;
            this.chkTHU7.UseVisualStyleBackColor = true;
            // 
            // chkFRI5
            // 
            this.chkFRI5.AutoSize = true;
            this.chkFRI5.Location = new System.Drawing.Point(265, 171);
            this.chkFRI5.Name = "chkFRI5";
            this.chkFRI5.Size = new System.Drawing.Size(15, 14);
            this.chkFRI5.TabIndex = 33;
            this.chkFRI5.UseVisualStyleBackColor = true;
            // 
            // chkWED8
            // 
            this.chkWED8.AutoSize = true;
            this.chkWED8.Location = new System.Drawing.Point(184, 269);
            this.chkWED8.Name = "chkWED8";
            this.chkWED8.Size = new System.Drawing.Size(15, 14);
            this.chkWED8.TabIndex = 52;
            this.chkWED8.UseVisualStyleBackColor = true;
            // 
            // chkTHU6
            // 
            this.chkTHU6.AutoSize = true;
            this.chkTHU6.Location = new System.Drawing.Point(226, 204);
            this.chkTHU6.Name = "chkTHU6";
            this.chkTHU6.Size = new System.Drawing.Size(15, 14);
            this.chkTHU6.TabIndex = 39;
            this.chkTHU6.UseVisualStyleBackColor = true;
            // 
            // chkFRI7
            // 
            this.chkFRI7.AutoSize = true;
            this.chkFRI7.Location = new System.Drawing.Point(265, 236);
            this.chkFRI7.Name = "chkFRI7";
            this.chkFRI7.Size = new System.Drawing.Size(15, 14);
            this.chkFRI7.TabIndex = 47;
            this.chkFRI7.UseVisualStyleBackColor = true;
            // 
            // chkSAT5
            // 
            this.chkSAT5.AutoSize = true;
            this.chkSAT5.Location = new System.Drawing.Point(304, 171);
            this.chkSAT5.Name = "chkSAT5";
            this.chkSAT5.Size = new System.Drawing.Size(15, 14);
            this.chkSAT5.TabIndex = 34;
            this.chkSAT5.UseVisualStyleBackColor = true;
            // 
            // chkTHU8
            // 
            this.chkTHU8.AutoSize = true;
            this.chkTHU8.Location = new System.Drawing.Point(226, 269);
            this.chkTHU8.Name = "chkTHU8";
            this.chkTHU8.Size = new System.Drawing.Size(15, 14);
            this.chkTHU8.TabIndex = 53;
            this.chkTHU8.UseVisualStyleBackColor = true;
            // 
            // chkFRI6
            // 
            this.chkFRI6.AutoSize = true;
            this.chkFRI6.Location = new System.Drawing.Point(265, 204);
            this.chkFRI6.Name = "chkFRI6";
            this.chkFRI6.Size = new System.Drawing.Size(15, 14);
            this.chkFRI6.TabIndex = 40;
            this.chkFRI6.UseVisualStyleBackColor = true;
            // 
            // chkSAT7
            // 
            this.chkSAT7.AutoSize = true;
            this.chkSAT7.Location = new System.Drawing.Point(304, 236);
            this.chkSAT7.Name = "chkSAT7";
            this.chkSAT7.Size = new System.Drawing.Size(15, 14);
            this.chkSAT7.TabIndex = 48;
            this.chkSAT7.UseVisualStyleBackColor = true;
            // 
            // chkSAT6
            // 
            this.chkSAT6.AutoSize = true;
            this.chkSAT6.Location = new System.Drawing.Point(304, 204);
            this.chkSAT6.Name = "chkSAT6";
            this.chkSAT6.Size = new System.Drawing.Size(15, 14);
            this.chkSAT6.TabIndex = 41;
            this.chkSAT6.UseVisualStyleBackColor = true;
            // 
            // chkFRI8
            // 
            this.chkFRI8.AutoSize = true;
            this.chkFRI8.Location = new System.Drawing.Point(265, 269);
            this.chkFRI8.Name = "chkFRI8";
            this.chkFRI8.Size = new System.Drawing.Size(15, 14);
            this.chkFRI8.TabIndex = 54;
            this.chkFRI8.UseVisualStyleBackColor = true;
            // 
            // chkSAT8
            // 
            this.chkSAT8.AutoSize = true;
            this.chkSAT8.Location = new System.Drawing.Point(304, 269);
            this.chkSAT8.Name = "chkSAT8";
            this.chkSAT8.Size = new System.Drawing.Size(15, 14);
            this.chkSAT8.TabIndex = 55;
            this.chkSAT8.UseVisualStyleBackColor = true;
            // 
            // lbl1618
            // 
            this.lbl1618.AutoSize = true;
            this.lbl1618.Location = new System.Drawing.Point(11, 301);
            this.lbl1618.Name = "lbl1618";
            this.lbl1618.Size = new System.Drawing.Size(34, 13);
            this.lbl1618.TabIndex = 1;
            this.lbl1618.Text = "16-18";
            // 
            // lbl2022
            // 
            this.lbl2022.AutoSize = true;
            this.lbl2022.Location = new System.Drawing.Point(11, 366);
            this.lbl2022.Name = "lbl2022";
            this.lbl2022.Size = new System.Drawing.Size(34, 13);
            this.lbl2022.TabIndex = 1;
            this.lbl2022.Text = "20-22";
            // 
            // lbl1820
            // 
            this.lbl1820.AutoSize = true;
            this.lbl1820.Location = new System.Drawing.Point(11, 334);
            this.lbl1820.Name = "lbl1820";
            this.lbl1820.Size = new System.Drawing.Size(34, 13);
            this.lbl1820.TabIndex = 1;
            this.lbl1820.Text = "18-20";
            // 
            // lbl2224
            // 
            this.lbl2224.AutoSize = true;
            this.lbl2224.Location = new System.Drawing.Point(11, 399);
            this.lbl2224.Name = "lbl2224";
            this.lbl2224.Size = new System.Drawing.Size(34, 13);
            this.lbl2224.TabIndex = 1;
            this.lbl2224.Text = "22-24";
            // 
            // chkSUN9
            // 
            this.chkSUN9.AutoSize = true;
            this.chkSUN9.Location = new System.Drawing.Point(63, 301);
            this.chkSUN9.Name = "chkSUN9";
            this.chkSUN9.Size = new System.Drawing.Size(15, 14);
            this.chkSUN9.TabIndex = 56;
            this.chkSUN9.UseVisualStyleBackColor = true;
            // 
            // chkMON9
            // 
            this.chkMON9.AutoSize = true;
            this.chkMON9.Location = new System.Drawing.Point(106, 301);
            this.chkMON9.Name = "chkMON9";
            this.chkMON9.Size = new System.Drawing.Size(15, 14);
            this.chkMON9.TabIndex = 57;
            this.chkMON9.UseVisualStyleBackColor = true;
            // 
            // chkSUN11
            // 
            this.chkSUN11.AutoSize = true;
            this.chkSUN11.Location = new System.Drawing.Point(63, 366);
            this.chkSUN11.Name = "chkSUN11";
            this.chkSUN11.Size = new System.Drawing.Size(15, 14);
            this.chkSUN11.TabIndex = 70;
            this.chkSUN11.UseVisualStyleBackColor = true;
            // 
            // chkSUN10
            // 
            this.chkSUN10.AutoSize = true;
            this.chkSUN10.Location = new System.Drawing.Point(63, 334);
            this.chkSUN10.Name = "chkSUN10";
            this.chkSUN10.Size = new System.Drawing.Size(15, 14);
            this.chkSUN10.TabIndex = 63;
            this.chkSUN10.UseVisualStyleBackColor = true;
            // 
            // chkMON11
            // 
            this.chkMON11.AutoSize = true;
            this.chkMON11.Location = new System.Drawing.Point(106, 366);
            this.chkMON11.Name = "chkMON11";
            this.chkMON11.Size = new System.Drawing.Size(15, 14);
            this.chkMON11.TabIndex = 71;
            this.chkMON11.UseVisualStyleBackColor = true;
            // 
            // chkTUE9
            // 
            this.chkTUE9.AutoSize = true;
            this.chkTUE9.Location = new System.Drawing.Point(145, 301);
            this.chkTUE9.Name = "chkTUE9";
            this.chkTUE9.Size = new System.Drawing.Size(15, 14);
            this.chkTUE9.TabIndex = 58;
            this.chkTUE9.UseVisualStyleBackColor = true;
            // 
            // chkSUN12
            // 
            this.chkSUN12.AutoSize = true;
            this.chkSUN12.Location = new System.Drawing.Point(63, 399);
            this.chkSUN12.Name = "chkSUN12";
            this.chkSUN12.Size = new System.Drawing.Size(15, 14);
            this.chkSUN12.TabIndex = 77;
            this.chkSUN12.UseVisualStyleBackColor = true;
            // 
            // chkMON10
            // 
            this.chkMON10.AutoSize = true;
            this.chkMON10.Location = new System.Drawing.Point(106, 334);
            this.chkMON10.Name = "chkMON10";
            this.chkMON10.Size = new System.Drawing.Size(15, 14);
            this.chkMON10.TabIndex = 64;
            this.chkMON10.UseVisualStyleBackColor = true;
            // 
            // chkTUE11
            // 
            this.chkTUE11.AutoSize = true;
            this.chkTUE11.Location = new System.Drawing.Point(145, 366);
            this.chkTUE11.Name = "chkTUE11";
            this.chkTUE11.Size = new System.Drawing.Size(15, 14);
            this.chkTUE11.TabIndex = 72;
            this.chkTUE11.UseVisualStyleBackColor = true;
            // 
            // chkWED9
            // 
            this.chkWED9.AutoSize = true;
            this.chkWED9.Location = new System.Drawing.Point(184, 301);
            this.chkWED9.Name = "chkWED9";
            this.chkWED9.Size = new System.Drawing.Size(15, 14);
            this.chkWED9.TabIndex = 59;
            this.chkWED9.UseVisualStyleBackColor = true;
            // 
            // chkMON12
            // 
            this.chkMON12.AutoSize = true;
            this.chkMON12.Location = new System.Drawing.Point(106, 399);
            this.chkMON12.Name = "chkMON12";
            this.chkMON12.Size = new System.Drawing.Size(15, 14);
            this.chkMON12.TabIndex = 78;
            this.chkMON12.UseVisualStyleBackColor = true;
            // 
            // chkTUE10
            // 
            this.chkTUE10.AutoSize = true;
            this.chkTUE10.Location = new System.Drawing.Point(145, 334);
            this.chkTUE10.Name = "chkTUE10";
            this.chkTUE10.Size = new System.Drawing.Size(15, 14);
            this.chkTUE10.TabIndex = 65;
            this.chkTUE10.UseVisualStyleBackColor = true;
            // 
            // chkWED11
            // 
            this.chkWED11.AutoSize = true;
            this.chkWED11.Location = new System.Drawing.Point(184, 366);
            this.chkWED11.Name = "chkWED11";
            this.chkWED11.Size = new System.Drawing.Size(15, 14);
            this.chkWED11.TabIndex = 73;
            this.chkWED11.UseVisualStyleBackColor = true;
            // 
            // chkTHU9
            // 
            this.chkTHU9.AutoSize = true;
            this.chkTHU9.Location = new System.Drawing.Point(226, 301);
            this.chkTHU9.Name = "chkTHU9";
            this.chkTHU9.Size = new System.Drawing.Size(15, 14);
            this.chkTHU9.TabIndex = 60;
            this.chkTHU9.UseVisualStyleBackColor = true;
            // 
            // chkTUE12
            // 
            this.chkTUE12.AutoSize = true;
            this.chkTUE12.Location = new System.Drawing.Point(145, 399);
            this.chkTUE12.Name = "chkTUE12";
            this.chkTUE12.Size = new System.Drawing.Size(15, 14);
            this.chkTUE12.TabIndex = 79;
            this.chkTUE12.UseVisualStyleBackColor = true;
            // 
            // chkWED10
            // 
            this.chkWED10.AutoSize = true;
            this.chkWED10.Location = new System.Drawing.Point(184, 334);
            this.chkWED10.Name = "chkWED10";
            this.chkWED10.Size = new System.Drawing.Size(15, 14);
            this.chkWED10.TabIndex = 66;
            this.chkWED10.UseVisualStyleBackColor = true;
            // 
            // chkTHU11
            // 
            this.chkTHU11.AutoSize = true;
            this.chkTHU11.Location = new System.Drawing.Point(226, 366);
            this.chkTHU11.Name = "chkTHU11";
            this.chkTHU11.Size = new System.Drawing.Size(15, 14);
            this.chkTHU11.TabIndex = 74;
            this.chkTHU11.UseVisualStyleBackColor = true;
            // 
            // chkFRI9
            // 
            this.chkFRI9.AutoSize = true;
            this.chkFRI9.Location = new System.Drawing.Point(265, 301);
            this.chkFRI9.Name = "chkFRI9";
            this.chkFRI9.Size = new System.Drawing.Size(15, 14);
            this.chkFRI9.TabIndex = 61;
            this.chkFRI9.UseVisualStyleBackColor = true;
            // 
            // chkWED12
            // 
            this.chkWED12.AutoSize = true;
            this.chkWED12.Location = new System.Drawing.Point(184, 399);
            this.chkWED12.Name = "chkWED12";
            this.chkWED12.Size = new System.Drawing.Size(15, 14);
            this.chkWED12.TabIndex = 80;
            this.chkWED12.UseVisualStyleBackColor = true;
            // 
            // chkTHU10
            // 
            this.chkTHU10.AutoSize = true;
            this.chkTHU10.Location = new System.Drawing.Point(226, 334);
            this.chkTHU10.Name = "chkTHU10";
            this.chkTHU10.Size = new System.Drawing.Size(15, 14);
            this.chkTHU10.TabIndex = 67;
            this.chkTHU10.UseVisualStyleBackColor = true;
            // 
            // chkFRI11
            // 
            this.chkFRI11.AutoSize = true;
            this.chkFRI11.Location = new System.Drawing.Point(265, 366);
            this.chkFRI11.Name = "chkFRI11";
            this.chkFRI11.Size = new System.Drawing.Size(15, 14);
            this.chkFRI11.TabIndex = 75;
            this.chkFRI11.UseVisualStyleBackColor = true;
            // 
            // chkSAT9
            // 
            this.chkSAT9.AutoSize = true;
            this.chkSAT9.Location = new System.Drawing.Point(304, 301);
            this.chkSAT9.Name = "chkSAT9";
            this.chkSAT9.Size = new System.Drawing.Size(15, 14);
            this.chkSAT9.TabIndex = 62;
            this.chkSAT9.UseVisualStyleBackColor = true;
            // 
            // chkTHU12
            // 
            this.chkTHU12.AutoSize = true;
            this.chkTHU12.Location = new System.Drawing.Point(226, 399);
            this.chkTHU12.Name = "chkTHU12";
            this.chkTHU12.Size = new System.Drawing.Size(15, 14);
            this.chkTHU12.TabIndex = 81;
            this.chkTHU12.UseVisualStyleBackColor = true;
            // 
            // chkFRI10
            // 
            this.chkFRI10.AutoSize = true;
            this.chkFRI10.Location = new System.Drawing.Point(265, 334);
            this.chkFRI10.Name = "chkFRI10";
            this.chkFRI10.Size = new System.Drawing.Size(15, 14);
            this.chkFRI10.TabIndex = 68;
            this.chkFRI10.UseVisualStyleBackColor = true;
            // 
            // chkSAT11
            // 
            this.chkSAT11.AutoSize = true;
            this.chkSAT11.Location = new System.Drawing.Point(304, 366);
            this.chkSAT11.Name = "chkSAT11";
            this.chkSAT11.Size = new System.Drawing.Size(15, 14);
            this.chkSAT11.TabIndex = 76;
            this.chkSAT11.UseVisualStyleBackColor = true;
            // 
            // chkSAT10
            // 
            this.chkSAT10.AutoSize = true;
            this.chkSAT10.Location = new System.Drawing.Point(304, 334);
            this.chkSAT10.Name = "chkSAT10";
            this.chkSAT10.Size = new System.Drawing.Size(15, 14);
            this.chkSAT10.TabIndex = 69;
            this.chkSAT10.UseVisualStyleBackColor = true;
            // 
            // chkFRI12
            // 
            this.chkFRI12.AutoSize = true;
            this.chkFRI12.Location = new System.Drawing.Point(265, 399);
            this.chkFRI12.Name = "chkFRI12";
            this.chkFRI12.Size = new System.Drawing.Size(15, 14);
            this.chkFRI12.TabIndex = 82;
            this.chkFRI12.UseVisualStyleBackColor = true;
            // 
            // chkSAT12
            // 
            this.chkSAT12.AutoSize = true;
            this.chkSAT12.Location = new System.Drawing.Point(304, 399);
            this.chkSAT12.Name = "chkSAT12";
            this.chkSAT12.Size = new System.Drawing.Size(15, 14);
            this.chkSAT12.TabIndex = 83;
            this.chkSAT12.UseVisualStyleBackColor = true;
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(95, 480);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(75, 30);
            this.btnOK.TabIndex = 3;
            this.btnOK.Text = "&OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(177, 480);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 30);
            this.btnCancel.TabIndex = 4;
            this.btnCancel.Text = "&Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // pnlSchedule
            // 
            this.pnlSchedule.Controls.Add(this.chkSUN1);
            this.pnlSchedule.Controls.Add(this.lbl0002);
            this.pnlSchedule.Controls.Add(this.lblSUN);
            this.pnlSchedule.Controls.Add(this.lbl0810);
            this.pnlSchedule.Controls.Add(this.chkSAT12);
            this.pnlSchedule.Controls.Add(this.lbl0406);
            this.pnlSchedule.Controls.Add(this.chkFRI12);
            this.pnlSchedule.Controls.Add(this.lbl1618);
            this.pnlSchedule.Controls.Add(this.chkSAT8);
            this.pnlSchedule.Controls.Add(this.lbl0204);
            this.pnlSchedule.Controls.Add(this.chkFRI8);
            this.pnlSchedule.Controls.Add(this.lbl1214);
            this.pnlSchedule.Controls.Add(this.chkSAT10);
            this.pnlSchedule.Controls.Add(this.lblMON);
            this.pnlSchedule.Controls.Add(this.chkSAT4);
            this.pnlSchedule.Controls.Add(this.lbl2022);
            this.pnlSchedule.Controls.Add(this.chkSAT6);
            this.pnlSchedule.Controls.Add(this.lbl1012);
            this.pnlSchedule.Controls.Add(this.chkSAT11);
            this.pnlSchedule.Controls.Add(this.lbl0608);
            this.pnlSchedule.Controls.Add(this.chkFRI4);
            this.pnlSchedule.Controls.Add(this.lbl1820);
            this.pnlSchedule.Controls.Add(this.chkSAT7);
            this.pnlSchedule.Controls.Add(this.lblTUE);
            this.pnlSchedule.Controls.Add(this.chkFRI10);
            this.pnlSchedule.Controls.Add(this.lbl1416);
            this.pnlSchedule.Controls.Add(this.chkSAT2);
            this.pnlSchedule.Controls.Add(this.lblWED);
            this.pnlSchedule.Controls.Add(this.chkFRI6);
            this.pnlSchedule.Controls.Add(this.lbl2224);
            this.pnlSchedule.Controls.Add(this.chkTHU12);
            this.pnlSchedule.Controls.Add(this.lblTHU);
            this.pnlSchedule.Controls.Add(this.chkSAT3);
            this.pnlSchedule.Controls.Add(this.lblFRI);
            this.pnlSchedule.Controls.Add(this.chkTHU8);
            this.pnlSchedule.Controls.Add(this.lblSAT);
            this.pnlSchedule.Controls.Add(this.chkSAT9);
            this.pnlSchedule.Controls.Add(this.chkMON1);
            this.pnlSchedule.Controls.Add(this.chkFRI2);
            this.pnlSchedule.Controls.Add(this.chkSUN5);
            this.pnlSchedule.Controls.Add(this.chkSAT5);
            this.pnlSchedule.Controls.Add(this.chkSUN3);
            this.pnlSchedule.Controls.Add(this.chkFRI11);
            this.pnlSchedule.Controls.Add(this.chkSUN9);
            this.pnlSchedule.Controls.Add(this.chkTHU4);
            this.pnlSchedule.Controls.Add(this.chkMON5);
            this.pnlSchedule.Controls.Add(this.chkFRI7);
            this.pnlSchedule.Controls.Add(this.chkSUN2);
            this.pnlSchedule.Controls.Add(this.chkTHU10);
            this.pnlSchedule.Controls.Add(this.chkMON9);
            this.pnlSchedule.Controls.Add(this.chkSAT1);
            this.pnlSchedule.Controls.Add(this.chkSUN7);
            this.pnlSchedule.Controls.Add(this.chkTHU6);
            this.pnlSchedule.Controls.Add(this.chkMON3);
            this.pnlSchedule.Controls.Add(this.chkWED12);
            this.pnlSchedule.Controls.Add(this.chkSUN11);
            this.pnlSchedule.Controls.Add(this.chkFRI3);
            this.pnlSchedule.Controls.Add(this.chkSUN6);
            this.pnlSchedule.Controls.Add(this.chkWED8);
            this.pnlSchedule.Controls.Add(this.chkTUE1);
            this.pnlSchedule.Controls.Add(this.chkFRI9);
            this.pnlSchedule.Controls.Add(this.chkSUN10);
            this.pnlSchedule.Controls.Add(this.chkTHU2);
            this.pnlSchedule.Controls.Add(this.chkMON7);
            this.pnlSchedule.Controls.Add(this.chkFRI5);
            this.pnlSchedule.Controls.Add(this.chkSUN4);
            this.pnlSchedule.Controls.Add(this.chkTHU11);
            this.pnlSchedule.Controls.Add(this.chkMON11);
            this.pnlSchedule.Controls.Add(this.chkWED4);
            this.pnlSchedule.Controls.Add(this.chkTUE5);
            this.pnlSchedule.Controls.Add(this.chkTHU7);
            this.pnlSchedule.Controls.Add(this.chkMON2);
            this.pnlSchedule.Controls.Add(this.chkWED10);
            this.pnlSchedule.Controls.Add(this.chkTUE9);
            this.pnlSchedule.Controls.Add(this.chkFRI1);
            this.pnlSchedule.Controls.Add(this.chkSUN8);
            this.pnlSchedule.Controls.Add(this.chkWED6);
            this.pnlSchedule.Controls.Add(this.chkTUE3);
            this.pnlSchedule.Controls.Add(this.chkTUE12);
            this.pnlSchedule.Controls.Add(this.chkSUN12);
            this.pnlSchedule.Controls.Add(this.chkTHU3);
            this.pnlSchedule.Controls.Add(this.chkMON6);
            this.pnlSchedule.Controls.Add(this.chkTUE8);
            this.pnlSchedule.Controls.Add(this.chkWED1);
            this.pnlSchedule.Controls.Add(this.chkTHU9);
            this.pnlSchedule.Controls.Add(this.chkMON10);
            this.pnlSchedule.Controls.Add(this.chkWED2);
            this.pnlSchedule.Controls.Add(this.chkTUE7);
            this.pnlSchedule.Controls.Add(this.chkTHU5);
            this.pnlSchedule.Controls.Add(this.chkMON4);
            this.pnlSchedule.Controls.Add(this.chkWED11);
            this.pnlSchedule.Controls.Add(this.chkTUE11);
            this.pnlSchedule.Controls.Add(this.chkTUE4);
            this.pnlSchedule.Controls.Add(this.chkWED5);
            this.pnlSchedule.Controls.Add(this.chkWED7);
            this.pnlSchedule.Controls.Add(this.chkTUE2);
            this.pnlSchedule.Controls.Add(this.chkTUE10);
            this.pnlSchedule.Controls.Add(this.chkWED9);
            this.pnlSchedule.Controls.Add(this.chkTHU1);
            this.pnlSchedule.Controls.Add(this.chkMON8);
            this.pnlSchedule.Controls.Add(this.chkTUE6);
            this.pnlSchedule.Controls.Add(this.chkWED3);
            this.pnlSchedule.Controls.Add(this.chkMON12);
            this.pnlSchedule.Location = new System.Drawing.Point(5, 38);
            this.pnlSchedule.Name = "pnlSchedule";
            this.pnlSchedule.Size = new System.Drawing.Size(336, 428);
            this.pnlSchedule.TabIndex = 2;
            // 
            // frmDSSyncSchedule
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(348, 528);
            this.Controls.Add(this.pnlSchedule);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.radContinuous);
            this.Controls.Add(this.radSchedule);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmDSSyncSchedule";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DS Synchronization Schedule Properties";
            this.pnlSchedule.ResumeLayout(false);
            this.pnlSchedule.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton radSchedule;
        private System.Windows.Forms.RadioButton radContinuous;
        private System.Windows.Forms.Label lbl0002;
        private System.Windows.Forms.Label lblSUN;
        private System.Windows.Forms.Label lblMON;
        private System.Windows.Forms.Label lblTUE;
        private System.Windows.Forms.Label lblWED;
        private System.Windows.Forms.Label lblTHU;
        private System.Windows.Forms.Label lblFRI;
        private System.Windows.Forms.Label lblSAT;
        private System.Windows.Forms.CheckBox chkSUN1;
        private System.Windows.Forms.CheckBox chkMON1;
        private System.Windows.Forms.CheckBox chkTUE1;
        private System.Windows.Forms.CheckBox chkWED1;
        private System.Windows.Forms.CheckBox chkTHU1;
        private System.Windows.Forms.CheckBox chkFRI1;
        private System.Windows.Forms.CheckBox chkSAT1;
        private System.Windows.Forms.Label lbl0204;
        private System.Windows.Forms.CheckBox chkSUN2;
        private System.Windows.Forms.CheckBox chkMON2;
        private System.Windows.Forms.CheckBox chkTUE2;
        private System.Windows.Forms.CheckBox chkWED2;
        private System.Windows.Forms.CheckBox chkTHU2;
        private System.Windows.Forms.CheckBox chkFRI2;
        private System.Windows.Forms.CheckBox chkSAT2;
        private System.Windows.Forms.Label lbl0406;
        private System.Windows.Forms.Label lbl0608;
        private System.Windows.Forms.CheckBox chkSUN3;
        private System.Windows.Forms.CheckBox chkMON3;
        private System.Windows.Forms.CheckBox chkSUN4;
        private System.Windows.Forms.CheckBox chkTUE3;
        private System.Windows.Forms.CheckBox chkMON4;
        private System.Windows.Forms.CheckBox chkWED3;
        private System.Windows.Forms.CheckBox chkTUE4;
        private System.Windows.Forms.CheckBox chkTHU3;
        private System.Windows.Forms.CheckBox chkWED4;
        private System.Windows.Forms.CheckBox chkFRI3;
        private System.Windows.Forms.CheckBox chkTHU4;
        private System.Windows.Forms.CheckBox chkSAT3;
        private System.Windows.Forms.CheckBox chkFRI4;
        private System.Windows.Forms.CheckBox chkSAT4;
        private System.Windows.Forms.Label lbl0810;
        private System.Windows.Forms.Label lbl1214;
        private System.Windows.Forms.Label lbl1012;
        private System.Windows.Forms.Label lbl1416;
        private System.Windows.Forms.CheckBox chkSUN5;
        private System.Windows.Forms.CheckBox chkMON5;
        private System.Windows.Forms.CheckBox chkSUN7;
        private System.Windows.Forms.CheckBox chkSUN6;
        private System.Windows.Forms.CheckBox chkMON7;
        private System.Windows.Forms.CheckBox chkTUE5;
        private System.Windows.Forms.CheckBox chkSUN8;
        private System.Windows.Forms.CheckBox chkMON6;
        private System.Windows.Forms.CheckBox chkTUE7;
        private System.Windows.Forms.CheckBox chkWED5;
        private System.Windows.Forms.CheckBox chkMON8;
        private System.Windows.Forms.CheckBox chkTUE6;
        private System.Windows.Forms.CheckBox chkWED7;
        private System.Windows.Forms.CheckBox chkTHU5;
        private System.Windows.Forms.CheckBox chkTUE8;
        private System.Windows.Forms.CheckBox chkWED6;
        private System.Windows.Forms.CheckBox chkTHU7;
        private System.Windows.Forms.CheckBox chkFRI5;
        private System.Windows.Forms.CheckBox chkWED8;
        private System.Windows.Forms.CheckBox chkTHU6;
        private System.Windows.Forms.CheckBox chkFRI7;
        private System.Windows.Forms.CheckBox chkSAT5;
        private System.Windows.Forms.CheckBox chkTHU8;
        private System.Windows.Forms.CheckBox chkFRI6;
        private System.Windows.Forms.CheckBox chkSAT7;
        private System.Windows.Forms.CheckBox chkSAT6;
        private System.Windows.Forms.CheckBox chkFRI8;
        private System.Windows.Forms.CheckBox chkSAT8;
        private System.Windows.Forms.Label lbl1618;
        private System.Windows.Forms.Label lbl2022;
        private System.Windows.Forms.Label lbl1820;
        private System.Windows.Forms.Label lbl2224;
        private System.Windows.Forms.CheckBox chkSUN9;
        private System.Windows.Forms.CheckBox chkMON9;
        private System.Windows.Forms.CheckBox chkSUN11;
        private System.Windows.Forms.CheckBox chkSUN10;
        private System.Windows.Forms.CheckBox chkMON11;
        private System.Windows.Forms.CheckBox chkTUE9;
        private System.Windows.Forms.CheckBox chkSUN12;
        private System.Windows.Forms.CheckBox chkMON10;
        private System.Windows.Forms.CheckBox chkTUE11;
        private System.Windows.Forms.CheckBox chkWED9;
        private System.Windows.Forms.CheckBox chkMON12;
        private System.Windows.Forms.CheckBox chkTUE10;
        private System.Windows.Forms.CheckBox chkWED11;
        private System.Windows.Forms.CheckBox chkTHU9;
        private System.Windows.Forms.CheckBox chkTUE12;
        private System.Windows.Forms.CheckBox chkWED10;
        private System.Windows.Forms.CheckBox chkTHU11;
        private System.Windows.Forms.CheckBox chkFRI9;
        private System.Windows.Forms.CheckBox chkWED12;
        private System.Windows.Forms.CheckBox chkTHU10;
        private System.Windows.Forms.CheckBox chkFRI11;
        private System.Windows.Forms.CheckBox chkSAT9;
        private System.Windows.Forms.CheckBox chkTHU12;
        private System.Windows.Forms.CheckBox chkFRI10;
        private System.Windows.Forms.CheckBox chkSAT11;
        private System.Windows.Forms.CheckBox chkSAT10;
        private System.Windows.Forms.CheckBox chkFRI12;
        private System.Windows.Forms.CheckBox chkSAT12;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Panel pnlSchedule;
    }
}