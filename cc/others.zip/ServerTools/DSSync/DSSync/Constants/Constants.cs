﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DSSync.Constants
{
    internal enum FormDataModes
    {
        ViewItem = 0,
        NewItem = 1,
        EditItem = 2
    }

    public static class RegistryConstants
    {
        public const string DS_SYNC_SVC = @"SOFTWARE\Interwoven\WorkSite\imDsSyncSvc";
        public const string DS_SYNC_MODE = "Mode";
        public const string DS_SYNC_SCHEDULE = "Schedule";
        public const string DS_SYNC_SERVICE_NAME = "DSSyncServiceName";
        public const string MACHINE_NAME = "MachineName";

        public const string DS_SYNC_SVC_CONNECTIONS = DS_SYNC_SVC + "\\Connections";
        public const string DS_SYNC_SVC_ATTRIBUTE_MAPS = DS_SYNC_SVC + "\\Attribute Maps";
        public const string DS_SYNC_INCLUDE_OTHER_DIR = "Include Other Directory";

        public const string REG_KEY_CONNECTION_NAME = "Name";
        public const string REG_KEY_CONNECTION_DMS_PARAM_DMS = "DMS";
        public const string REG_KEY_CONNECTION_DMS_PARAM_LIBRARY = "Library";
    }
}