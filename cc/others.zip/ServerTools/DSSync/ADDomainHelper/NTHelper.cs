﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace ADDomainHelper
{

   
    public class NTHelper
    {
        // obtains user token
        [DllImport("advapi32.dll", SetLastError = true)]
        public static extern bool LogonUser(string pszUsername, string pszDomain, string pszPassword,
            int dwLogonType, int dwLogonProvider, ref IntPtr phToken);

        // closes open handes returned by LogonUser
        [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
        public extern static bool CloseHandle(IntPtr handle);
        private string _user = string.Empty;

        public string User
        {
            get { return _user; }
            set { _user = value; }
        }
        private string _password = string.Empty;

        public string Password
        {
            get { return _password; }
            set { _password = value; }
        }
        private string _domain = string.Empty;

        public string Domain
        {
            get { return _domain; }
            set { _domain = value; }
        }

        public bool LoginDomain()
        {
            bool bSuccess = false;
            IntPtr userHandle = IntPtr.Zero;
            try
            {
                WindowsImpersonationContext impersonationContext = null;
                
                const int LOGON32_PROVIDER_DEFAULT = 0;
                
                const int LOGON32_LOGON_NETWORK = 3;
                bool loggedOn = LogonUser(_user,
                                           _domain,
                                           _password,
                                           LOGON32_LOGON_NETWORK,
                                           LOGON32_PROVIDER_DEFAULT,
                                           ref userHandle);

                if (!loggedOn)
                {

                    return false;
                }

                // Begin impersonating the user
                impersonationContext = WindowsIdentity.Impersonate(userHandle);

                if (impersonationContext != null )
                    bSuccess = true;
            }
            catch
            {
                bSuccess = false;
            }
            finally
            {
                if(userHandle != IntPtr.Zero)
                    CloseHandle(userHandle);
            }
            return bSuccess;
        }
    }
}
