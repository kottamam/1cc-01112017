﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.DirectoryServices.Protocols;
using System.DirectoryServices.ActiveDirectory;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;

namespace ADDomainHelper
{

    public class DirectoryInfo
    {
        public string Name;
        public string adsPath;
    }
    public class ADHelper
    {

        private string _user = string.Empty;

        public string User
        {
          get { return _user; }
          set { _user = value; }
        }
        private string _password=string.Empty;

        public string Password
        {
          get { return _password; }
          set { _password = value; }
        }
        private string _server = string.Empty;

        public string Server
        {
            get { return _server; }
            set { _server = value; }
        }
        public bool LoginAD()
        {
            bool bSuccess = false;
            try
            {
                LdapConnection conn = new LdapConnection(_server);
                conn.Credential = new System.Net.NetworkCredential(_user, _password);
                conn.Bind();
                bSuccess= true;
                
            }
            catch(Exception ex)
            {
                bSuccess = false;
            }
            return bSuccess;
        }

        public List<DirectoryInfo> GetDirectoryChildrenByAdsPath(string strAdsPath)
        {
            List<DirectoryInfo> lstDirectoryEntries = new List<DirectoryInfo>();
            DirectoryEntry root = null;
            string fullAdsPath = String.Format(
                        "LDAP://{0}/{1}",
                        _server,
                        strAdsPath
                        );
            root = new DirectoryEntry(fullAdsPath);

            using (DirectorySearcher searcher = new DirectorySearcher(root))
            {
                searcher.Filter = "(&(objectClass=container))";
                searcher.SearchScope = System.DirectoryServices.SearchScope.OneLevel;
                searcher.PageSize = 1000;
                foreach (SearchResult result in searcher.FindAll())
                {
                    DirectoryEntry ff = result.GetDirectoryEntry();
                    DirectoryInfo dInfo = new DirectoryInfo();
                    dInfo.Name = ff.Name;

                    dInfo.adsPath = ff.Path;

                    lstDirectoryEntries.Add(dInfo);
                }
            }

            return lstDirectoryEntries;

        }


        public List<DirectoryInfo> GetDirectoryChildren(DirectoryInfo dEntry)
        {

            List<DirectoryInfo> lstDirectoryEntries = new List<DirectoryInfo>();
            DirectoryEntry root = null;
            if (dEntry == null)
            {
                DirectoryEntry defaultRoot = new DirectoryEntry("LDAP://" + Server + "/RootDSE");
                using (defaultRoot)
                {
                    string dnc = defaultRoot.Properties["defaultNamingContext"][0].ToString();
                    

                    string adsPath = String.Format(
                        "LDAP://{0}/{1}",
                        _server,
                        dnc
                        );

                    root = new DirectoryEntry(adsPath);
                }


            }
            else
                root = new DirectoryEntry(dEntry.adsPath);
            
            using (DirectorySearcher searcher = new DirectorySearcher(root))
            {
                searcher.Filter = "(&(objectClass=container))";
                searcher.SearchScope = System.DirectoryServices.SearchScope.OneLevel;
                searcher.PageSize = 1000;
                foreach (SearchResult result in searcher.FindAll())
                {
                    DirectoryEntry ff = result.GetDirectoryEntry();
                    DirectoryInfo dInfo = new DirectoryInfo();
                    dInfo.Name = ff.Name;
                    
                    dInfo.adsPath = ff.Path;

                    lstDirectoryEntries.Add(dInfo);
                }
            }


            return lstDirectoryEntries;
        }
        
    }
}
