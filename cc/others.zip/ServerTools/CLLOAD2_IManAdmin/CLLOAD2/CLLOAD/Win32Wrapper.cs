﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CLLOAD
{
    class Win32Wrapper
    {
        public static Func<string, Type> GetTypeFromProgID = (progID) => { return Type.GetTypeFromProgID(progID); };
        public static Func<Guid, Type> GetTypeFromCLSID = (clsid) => { return Type.GetTypeFromCLSID(clsid); };
        public static Func<Type, object> CreateInstance = (type) => { return Activator.CreateInstance(type); };
    }
}
