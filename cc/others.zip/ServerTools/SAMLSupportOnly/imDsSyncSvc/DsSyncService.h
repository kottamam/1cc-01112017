//=============================================================================
// File: DsSyncService.h
//-----------------------------------------------------------------------------
// Date      Who  Modification
// --------  ---  -------------------------------------------------------------
// 03/07/02  MDL  Initial coding
//-----------------------------------------------------------------------------
// Copyright (C) 2002, iManage, Inc.
// PROPRIETARY AND CONFIDENTIAL
//=============================================================================

#include "StdAfx.h"

#include <Verification/Verification.h>
#include <stl/nrstring.h>
#include <db/db.h>
#include <Registry\Registry.h>
#include <fileServer\fileServer.h>
#include <imLdap\imLdap.h>
#include "ObjectModel.h"



namespace IM
{


typedef ObjectContainers::CObjectOwningMap< _bstr_t, DSOM::CDSSyncContextGeneric, ObjectContainers::bstrlessi > CTXMAP;
typedef ObjectContainers::CObjectOwningMap< _bstr_t, DSOM::CDSGeneric, ObjectContainers::bstrlessi > CONNMAP;
typedef ObjectContainers::CObjectOwningMap< _bstr_t, DSOM::CDatabase> DATABASEMAP;

class DsSyncService : public ObjectSignature
{
private:

	HANDLE								m_hMonitorThread;		// handle of monitor thread
	HANDLE								m_hStopEvent;
	DBPoolMgr							*m_pPoolMgr;
	IM::DsSyncDatabaseList				m_databaseList;
	CDSSyncSvc							*m_pServiceConfiguration;
	IM::CDSSyncSvc::CONNECTIONLIST		m_ConnectionList;
	CTXMAP								m_ContextMap;
	CONNMAP								m_DSConnectionMap;
	DATABASEMAP							m_DSDatabaseMap;
	DateTime							m_dtBeginTime;

	void						dump(const char *szHeader);

	static unsigned __stdcall 	monitorThread(void *p_);
	void						monitorMain( void );
	void AuthenticateAllConnections(void);
	
	unsigned long				GetNextCycleSeconds();

	void ResetConnectionList( void );
	CDSSyncSvc_Connection* GetNextConnection( void );

	DSOM::CDSGeneric* GetNewDSGenericInterface( CDSSyncSvc_Connection* pConnection, CDSSyncSvc_AttributeMap* pAttributeMap );
	bool TestDSGenericInterface( DSOM::CDSGeneric* pDSGeneric );
	DSOM::CDSGeneric* GetCachedDSGenericInterface( CDSSyncSvc_Connection* pConnection, CDSSyncSvc_AttributeMap* pAttributeMap );
	void DeleteCachedDSGenericInterface( CDSSyncSvc_Connection* pConnection );

public:

				DsSyncService();
	virtual		~DsSyncService();
	void		Init(HANDLE hStopEvent_, DBPoolMgr *pPoolMgr_, CDSSyncSvc *pServiceConfiguration_);


};


};	// namespace IM

