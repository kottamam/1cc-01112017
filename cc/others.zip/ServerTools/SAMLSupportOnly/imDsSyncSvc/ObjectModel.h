//=============================================================================
// File: ObjectModel.h
//-----------------------------------------------------------------------------
// Date      Who  Modification
// --------  ---  -------------------------------------------------------------
// 04/5/02  MDL  Initial coding
//-----------------------------------------------------------------------------
// Copyright (C) 2002, iManage, Inc.
// PROPRIETARY AND CONFIDENTIAL
//=============================================================================

#pragma once

#include "StdAfx.h"
#include "ObjectModel.h"

#include <imLdap/imLdap.h>
#include <registry\registry.h>
#include <db\db.h>
#include <dsRpcIfc\NRDsSyncSvcClient.h>
#include <sstream>
#include <fstream>



struct FileUploadInfo
{
	stlport::ifstream m_fileStream;
	ULONG64 m_fileSize;
	ULONG64 m_fileSizeLeft;
};



// forwards
namespace IM
{
	class CDSSyncSvc_Connection;
	class CDSSyncSvc_AttributeMap;
};



namespace DSOM
{



// define callback for NRDsSyncSvcClient class
BOOL waitHookCallback(long mode, long mSecs, long byteCount, void *v);





class CSidMap
{
public:
	CSidMap();
	~CSidMap();

	// adds or updates
	void AddOrUpdate( const _bstr_t& strGroupObjectSID, const _bstr_t& strUserObjectGUID );
	void RemoveIfPresent( const _bstr_t& strUserObjectGUID );

	const ObjectContainers::CUniqueBstrVector& Get( const _bstr_t& strGroupObjectSID );

	void Reset();
	int Count() { return m_mapSid2List.Count(); }

private:

	ObjectContainers::CUniqueBstrVector* get( const _bstr_t& strGroupObjectSID );


	typedef ObjectContainers::CObjectOwningMap< _bstr_t, ObjectContainers::CUniqueBstrVector, ObjectContainers::bstrlessi > SID2LISTMAP;
	SID2LISTMAP m_mapSid2List;


};


///////////////////////////////////////////////////////////////////////
// CDMSUser

// This class holds information for an DMS user object.

class CDMSUser : public CDSUser
{
private:
	// DMS attributes
	IM::CDSSyncSvc_DSParameters::LDAPTYPE m_lNOS;	// NOS
	bool bForcePasswordChange;
	bool bPasswordNeverExpires;
	std::string bstrUserNum;
	std::string strPassword;

public:
	// constructor
	CDMSUser(
		const _bstr_t& bstrDn, 
		const _bstr_t& bstrName,
		const _bstr_t& bstrParentDn,
		const _bstr_t& bstrK1SyncId,
		const _bstr_t& bstrObjectSID,
		bool		   bExternal,
		const _bstr_t& bstrUserId, 
		const _bstr_t& bstrTelephoneNumber,
		const _bstr_t& bstrMail,
		const _bstr_t& bstrFax,
		const _bstr_t& bstrLocation,
		const bool bEnabled,
		const _bstr_t& bstrPrimaryGroupID,
		IM::CDSSyncSvc_DSParameters::LDAPTYPE lNOS
		
		);

	// copy constructor
	CDMSUser( const CDMSUser& DMSUser );

	// destructor
	virtual ~CDMSUser( void );

	// member accessors
	const IM::CDSSyncSvc_DSParameters::LDAPTYPE& GetNOS( void ) const;	// returns m_lNOS

	void SetNOS( const IM::CDSSyncSvc_DSParameters::LDAPTYPE& lNOS );

	// assignment operator
	CDMSUser& operator=( const CDMSUser& DMSUser );

	// equality operator
	bool operator==( const CDMSUser& DMSUser ) const;

	const bool getForcePasswordChange() const;

	void setForcePasswordChange(bool bForcePasswordChange);
	const bool getPasswordNeverExpires() const;

	void setPasswordNeverExpires(bool bForcePasswordChange);

	const std::string getUserNum() const;

	void setUserNum(std::string userNum);
	void setUserPassword(std::string userPassword);

	const std::string getUserPassword() const;
};




// CDMSGroup

// This class holds information for an DMS group object.

class CDMSGroup : public CDSGroup
{
private:
	// DMS attributes
	IM::CDSSyncSvc_DSParameters::LDAPTYPE m_lNOS;	// NOS

public:
	// constructor
	CDMSGroup(
		const _bstr_t& bstrDn, 
		const _bstr_t& bstrName,
		const _bstr_t& bstrParentDn,
		const _bstr_t& bstrK1SyncId,
		const _bstr_t& bstrObjectSID,
		bool		   bExternal,
		const _bstr_t& bstrGroupId,
		const ObjectContainers::CUniqueBstrVector& vMembers,
		const bool bEnabled,
		IM::CDSSyncSvc_DSParameters::LDAPTYPE lNOS
		);

	// copy constructor
	CDMSGroup( const CDMSGroup& DMSGroup );

	// destructor
	virtual ~CDMSGroup( void );

	// member accessors
	const IM::CDSSyncSvc_DSParameters::LDAPTYPE& GetNOS( void ) const;	// returns m_lNOS

	void SetNOS( const IM::CDSSyncSvc_DSParameters::LDAPTYPE& lNOS );

	// assignment operator
	CDMSGroup& operator=( const CDMSGroup& DMSGroup );

	// equality operator
	bool operator==( const CDMSGroup& DMSGroup ) const;
};


typedef imstd::map< _bstr_t, _bstr_t, ObjectContainers::bstrlessi > USERUSERMAP;


/////////////////////////////////////////////////////
// CRESTCommunication

/////////////////////////////////////////////////////
// CDatabase

class CDatabase 
{
public:
	// default constructor
	CDatabase(CDSSyncContextGeneric* pDSSyncContext);

	virtual ~CDatabase(void);

	// operations
	bool GetIsLoggedOn() { return m_bLoggedOn; }

	void Login();

	DWORD GetUsers(CDSUSERLIST& UserList);
	DWORD GetGroups(CDSGROUPLIST& GroupList);
	DWORD GetUserBySyncId(const _bstr_t& strId, CDMSUser& DMSUser);
	DWORD GetGroupBySyncId(const _bstr_t& strId, CDMSGroup& DMSGroup);
	DWORD GetUserByUserId(const _bstr_t& strId, CDMSUser& DMSUser);
	DWORD GetGroupByGroupId(const _bstr_t& strId, CDMSGroup& DMSGroup);
	DWORD InsertUser(const CDSUser& DSUser);
	DWORD InsertGroup(const CDSGroup& DSGroup);
	DWORD UpdateUser(const CDSUser& DSUser);
	DWORD UpdateGroup(const CDSGroup& DSGroup);
	DWORD DisableUser(const CDSUser& DSUser);
	DWORD DisableGroup(const CDSGroup& DSGroup);
	DWORD MigrateUser(const CDSUser& DSUser, CDMSUser& dmsUser);
	DWORD MigrateGroup(const CDSGroup& DSGroup);


	DWORD UpdateUserPhoto(const CDSUser& DSUser, _bstr_t& strPhotoPath_, bool& bUserPhotoSupported);

	IM::CDSSyncSvc_DSParameters::LDAPTYPE ConvertDmsNosToDsNos(long lDmsNos);
	_bstr_t ConvertDsNosToDmsNos(IM::CDSSyncSvc_DSParameters::LDAPTYPE DsNos);


	// methods
	DWORD GetDSUserFromNRUser(NRUserEx* pNRUserEx, CDSUser*& pDSUser);
	DWORD GetDMSUserFromNRUser(NRUserEx* pNRUserEx, CDMSUser*& pDMSUser);
	DWORD GetDSGroupFromNRGroup(NRGroupEx* pNRGroupEx, CDSGroup*& pDSGroup);
	DWORD GetDMSGroupFromNRGroup(NRGroupEx* pNRGroupEx, CDMSGroup*& pDMSGroup);
	DWORD AssignGroupMembershipToDSGroup(CDMSGroup& DMSGroup);
	DWORD SetNRUserFromDSUser(NRUserEx& NRUser, const CDSUser& DSUser, const bool bSetPassword, const bool bSetEnabled);
	DWORD SetNRUserFromDMSUser(NRUserEx& NRUser, const CDMSUser& DMSUser, const bool bSetPassword, const bool bSetEnabled);
	DWORD SetNRGroupFromDSGroup(NRGroupEx& NRGroup, const CDSGroup& DSGroup, const bool bSetEnabled);
	DWORD SetNRGroupFromDMSGroup(NRGroupEx& NRGroup, const CDMSGroup& DMSGroup, const bool bSetEnabled);
	_bstr_t GetBeginningDosTime(void);
	DWORD GetUserNum(const _bstr_t& strId, long& lUserNum);
	DWORD GetUserNumBySyncId(const _bstr_t& strSyncId, long& lUserNum);
	DWORD GetDNBySyncId(const _bstr_t& strSyncId, _bstr_t& strDn);
	DWORD SetGroupMembership(const long& lGroupNum, const CDSGroup& DSGroup);
	DWORD SetGroupMembership_AllAtOnce(const long& lGroupNum, const CDSGroup& DSGroup);

	// members
	bool m_bLoggedOn;
	NRDsSyncSvcClient* m_pdb;
	CDSSyncContextGeneric* m_pDSSyncContext;

	DWORD ResolvePrimaryGroupIDMembership(CDSGroup* pDSGroup);
	
	typedef imstd::map< _bstr_t, long, ObjectContainers::bstrlessi > USERNUMMAP;
	USERNUMMAP m_mapUserIdToUserNum;
	USERNUMMAP m_mapSyncIdToUserNum;
	USERNUMMAP m_mapDistNameToUserNum;

	typedef imstd::map< _bstr_t, _bstr_t, ObjectContainers::bstrlessi > USERUSERMAP;
	USERUSERMAP m_mapUserIdToSyncId;
	USERUSERMAP m_mapUserIdToDn;
	USERUSERMAP m_mapDnToSyncId;
	USERUSERMAP m_mapDnToUserId;
	USERUSERMAP m_SyncIdToUserId;
	USERUSERMAP m_SyncIdToDn;

	DWORD UserExistsInMap(USERNUMMAP& map, const _bstr_t& id, bool& result);
	DWORD AddUserToMap(USERNUMMAP& map, const _bstr_t& id, long userNum, bool& result);
	DWORD GetUserInMap(USERNUMMAP& map, const _bstr_t& id, long& userNum, bool& result);

	DWORD UserExistsInMap(USERUSERMAP& map, const _bstr_t& id, bool& result);
	DWORD AddUserToMap(USERUSERMAP& map, const _bstr_t& id, const _bstr_t& id2, bool& result);
	DWORD GetUserInMap(USERUSERMAP& map, const _bstr_t& id, _bstr_t& id2, bool& result);

	DWORD AddUserToMaps(const _bstr_t& userId, const _bstr_t& syncId, const _bstr_t& distName, long userNum, bool& result);
	DWORD CompareGroupMems(CDSGroup& dsGroup, CDSGroup& dmsGroup, bool& result);

	DWORD GetUserFromMaps(const _bstr_t& anyId, long& userNum, bool& result);

	DWORD GetGroupMembershipForDSGroup(CDSGroup& DSGroup, ObjectContainers::CUniqueIntVector& vMems, bool& result);
	DWORD InAButNotB(ObjectContainers::CUniqueIntVector& vA, ObjectContainers::CUniqueIntVector& vB, ObjectContainers::CUniqueIntVector& vRes, bool& result);

	DWORD MemErrorMsg(ObjectContainers::CUniqueIntVector& v, _bstr_t& output);
};





/////////////////////////////////////////////////////
// CSynchronizer

class CSynchronizer
{
public:
	// standard constructor
	CSynchronizer( HANDLE hStopEvent );

	// destructor
	virtual ~CSynchronizer( void );

	// operations
	DWORD Synchronize(CDSSyncContextGeneric* pSyncContext, CDatabase* pDatabase);

	


protected:
	HANDLE m_hStopEvent;		// the service's stop event

	bool ServiceIsStopping();	// returns true if the service is stopping (if m_hStopEvent is signalled)

	// helper methods
	DWORD DS_To_Db_Users( CDSSyncContextGeneric* pSyncContext, CDatabase* pDatabase, ObjectContainers::CUniqueBstrVector& vecExternalDNList );
	DWORD DS_To_Db_Groups( CDSSyncContextGeneric* pSyncContext, CDatabase* pDatabase, ObjectContainers::CUniqueBstrVector& vecExternalDNList );
	DWORD Db_To_DS_Users( CDSSyncContextGeneric* pSyncContext, CDatabase* pDatabase );
	DWORD Db_To_DS_Groups( CDSSyncContextGeneric* pSyncContext, CDatabase* pDatabase);
};


/*
/////////////////////////////////////////////////////
// CADSSynchronizer

class CADSSynchronizer : public CSynchronizer
{
public:
	// standard constructor
	CADSSynchronizer( void );

	// destructor
	virtual ~CADSSynchronizer( void );

	// operations
	virtual DWORD Synchronize( CDSSyncContext* pDSSyncContext, CDatabase* pDatabase );

protected:
	// members

	// helper methods
	virtual DWORD DS_To_Db_Users( CDSSyncContext* pDSSyncContext, CDatabase* pDatabase );
	virtual DWORD DS_To_Db_Groups( CDSSyncContext* pDSSyncContext, CDatabase* pDatabase );
	virtual DWORD Db_To_DS_Users( CDSSyncContext* pDSSyncContext, CDatabase* pDatabase );
	virtual DWORD Db_To_DS_Groups( CDSSyncContext* pDSSyncContext, CDatabase* pDatabase );
};



/////////////////////////////////////////////////////
// CNetscapeDSSynchronizer

class CNetscapeDSSynchronizer : public CSynchronizer
{
public:
	// standard constructor
	CNetscapeDSSynchronizer( void );

	// destructor
	virtual ~CNetscapeDSSynchronizer( void );

	// operations
	virtual DWORD Synchronize( CDSSyncContext* pDSSyncContext, CDatabase* pDatabase );

protected:
	// members

	// helper methods
	virtual DWORD DS_To_Db_Users( CDSSyncContext* pDSSyncContext, CDatabase* pDatabase );
	virtual DWORD DS_To_Db_Groups( CDSSyncContext* pDSSyncContext, CDatabase* pDatabase );
	virtual DWORD Db_To_DS_Users( CDSSyncContext* pDSSyncContext, CDatabase* pDatabase );
	virtual DWORD Db_To_DS_Groups( CDSSyncContext* pDSSyncContext, CDatabase* pDatabase );
};
*/





}

