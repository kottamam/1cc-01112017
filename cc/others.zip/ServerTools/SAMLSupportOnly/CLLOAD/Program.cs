﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
//using IMANADMIN;
using Com.Interwoven.WorkSite.iManAdmin;

using System.Diagnostics;

namespace CLLOAD
{
    class Program
    {
       
        private enum logMaskVals
        {
            none = 0,
            info = 1,             
            warn = 2,
            error = 4,
            debug = 8
        }

        private enum ValidateFieldSpecifiersStatus
        {
            OK,
            WrongNumberOfFieldsForParentChild,
            WrongNumberOfFields,
            ParentIDMustBeSpecified,
            ChildIDMustBeSpecified,
            IDMustBeSpecified,
            TooManyFields,
            DisregardOverMinimum
        }

        private enum ValidateDelimiterStatus
        {
            OK,
            DelimiterWasDoubleQuotation,
            DelimiterWasTooLarge
        }

        private const int FIELD_SPECIFIER_PARENT_ID = 0;
        private const int FIELD_SPECIFIER_CHILD_ID = 4;

        private const int FIELD_SPECIFIER_ID = 0;

        private const int FIELD_SPECIFIERS_COUNT_MINIMUM = 4;
        private const int FIELD_SPECIFIERS_COUNT_PARENT_CHILD = 8;

        private const int FIELD_NOT_SPECIFIED = -1;

        private static string[] validCustomData = { "custom1", "custom2", "custom3", "custom4", "custom5", "custom6", "custom7", "custom8", "custom9", "custom10", "custom11", "custom12", "custom29", "custom30" };

        static void printUsage()
        {

            Console.WriteLine("Load data into custom tables ");
            Console.WriteLine("clload </server:servername userid password> </db:databasename> </file:filename> </table:name>");
            Console.WriteLine(" [/parentAlias:parentalias] [/overwrite:flag] [/childflag:flag]");
            Console.WriteLine(" [/format:[\"[delimiter]\"][column1 column2 column3 column4 [column5 column6 column7 column8]]");
            Console.WriteLine("/server:      specify the server name, login id and password");
            Console.WriteLine("/db:          specify the database name");
            Console.WriteLine("/file:        filename for importing data");
            Console.WriteLine("/table:       specify the table name which the data is loaded into CUSTOM1 to CUSTOM30");
            Console.WriteLine("/parentAlias: specify the parent alias for child custom table");
            Console.WriteLine("              required for CUSTOM2 and CUSTOM30, ignored for others");
            Console.WriteLine("/overwrite:   overwrite description field or not if alias exits. Must be Y or N. Default N");
            Console.WriteLine("/childflag:   load only parent table or both parent and child table");
            Console.WriteLine("              Y for both and N for parent table only. Default Y");
            Console.WriteLine("/format:      corresponding file column data to table fields");
            Console.WriteLine(" delimiter:   delimiter column, default to ,");
            Console.WriteLine(" column1:     column number for custom alias field, default to 1");
            Console.WriteLine(" column2:     column number for custom description field, default to 2");
            Console.WriteLine(" column3:     column number for custom enable flag, default to 3");
            Console.WriteLine(" column4:     column number for custom hipaa flag, default to 4");
            Console.WriteLine(" column5:     column number for custom child alias field, default to 5");
            Console.WriteLine(" column6:     column number for custom child description field, default to 6");
            Console.WriteLine(" column7:     column number for custom child enable flag, default to 7");
            Console.WriteLine(" column8:     column number for custom child hipaa flag, default to 8");
            Console.WriteLine("              set a column number value to -1 to indicate that no column should populate the field");  
        }

        static string tokenize(string arg, char delimiter, bool reverse)
        {
            try
            {
                if (!reverse)
                {
                    int start = arg.IndexOf(delimiter) + 1;
                    int length = arg.Length;
                    return (arg.Substring(start, length - start));
                }
                else
                {
                    int start = arg.IndexOf(delimiter);
                    return (arg.Substring(0, start));
                }
            }
            catch
            {
                return null;
            }
        }

        static AttributeID getAttributeID(string table)
        {
            switch(table.ToUpper())
            {
                case "CUSTOM1":
                    return AttributeID.nrCustom1;
                case "CUSTOM2":
                    return AttributeID.nrCustom2;
                case "CUSTOM3":
                    return AttributeID.nrCustom3;
                case "CUSTOM4":
                    return AttributeID.nrCustom4;
                case "CUSTOM5":
                    return AttributeID.nrCustom5;
                case "CUSTOM6":
                    return AttributeID.nrCustom6;
                case "CUSTOM7":
                    return AttributeID.nrCustom7;
                case "CUSTOM8":
                    return AttributeID.nrCustom8;
                case "CUSTOM9":
                    return AttributeID.nrCustom9;
                case "CUSTOM10":
                    return AttributeID.nrCustom10;
                case "CUSTOM11":
                    return AttributeID.nrCustom11;
                case "CUSTOM12":
                    return AttributeID.nrCustom12;
                case "CUSTOM29":
                    return AttributeID.nrCustom29;
                case "CUSTOM30":
                    return AttributeID.nrCustom30;
                default:
                    return 0;                  
            }
        }

        static bool getBool(string val)
        {
            if (val == "Y")
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        static void logWriter(StreamWriter s, string line, logMaskVals mask, logMaskVals level)
        {
            if ((mask & level) != logMaskVals.none)
            {
                DateTime now = DateTime.Now;
                s.WriteLine(now.ToString() + ":  " + level.ToString().ToUpper() + ":  " + line);
            }            
        }

        static void Main(string[] args)
        {
            //Required fields           
            String serverName = null;
            String loginType = "imanage";
            
            String userID = null;
            String password = null;
            String databaseName = null;
            String file = null;
            String table = null;
            bool tableDefined = false;
            bool bValid = true;

            //Optional fields with defaults
            String parentAlias = null;
            String overwrite = "N";
            String childFlagToken = "Y";
            bool childFlag = getBool(childFlagToken);
            String delimiter = ",";
            List<int> fields = new List<int>();
            for (int c = 1; c <= FIELD_SPECIFIERS_COUNT_PARENT_CHILD; c++)
            {
                fields.Add(c); //Set default field specifiers 1-8                
            }
            bool parserErrorFlag = false;
            string logPath = "clload.log";
            logMaskVals logMask = logMaskVals.info | logMaskVals.error; //Default log mask

            StreamWriter sWriter;
            try
            {
                sWriter = new StreamWriter(logPath, true); //Streamwriter for log file
                logWriter(sWriter, "*** BEGIN RUN -- check date ***", logMask, logMaskVals.info);
            }
            catch
            {
                Console.WriteLine("Unable to open log file for writing.");
                return;
            }                          

            //Command parser
            int i = 0;
            String curArg;
            List<int> fieldsRead = new List<int>();
            do
            {
                try
                {
                    curArg = tokenize(args[i], ':', true).ToUpper();
                    switch (curArg)
                    {
                        case "/SERVER":
                            serverName = tokenize(args[i], ':', false).ToUpper();
                            //userID = WadeNextArgument(args, ref i);
                            //password = WadeNextArgument(args, ref i);
                            break;
                        case "/LOGINTYPE":
                            loginType = tokenize(args[i], ':', false).ToUpper();
                            if (loginType != "IMANAGE" && loginType != "NETWORK")
                                throw new Exception();
                            break;
                        
                        case "/USERID":
                            userID = tokenize(args[i], ':', false).ToUpper();
                            break;

                        case "/PASSWORD":
                            password = tokenize(args[i], ':', false);
                            break;
                        case "/DB":
                            databaseName = tokenize(args[i], ':', false).ToUpper();
                            break;
                        case "/FILE":
                            file = tokenize(args[i], ':', false);
                            break;
                        case "/TABLE":
                            table = tokenize(args[i], ':', false).ToUpper();
                            break;
                        case "/PARENTALIAS":
                            parentAlias = tokenize(args[i], ':', false).ToUpper();
                            break;
                        case "/OVERWRITE":
                            overwrite = tokenize(args[i], ':', false).ToUpper();
                            break;
                        case "/CHILDFLAG":
                            childFlagToken = tokenize(args[i], ':', false).ToUpper();
                            childFlag = getBool(childFlagToken);
                            break;
                        case "/FORMAT":
                            ParseFormat(args, ref delimiter, ref fieldsRead, logMask, sWriter, ref i);
                            break;
                        case "/LOGMASK":
                            int l = Convert.ToInt16(tokenize(args[i], ':', false));
                            if (l >= 1 && l <= 15)
                            {
                                logMask = (logMaskVals)l;
                                logWriter(sWriter, "Log level set to " + logMask.ToString(), logMask, logMaskVals.info);
                            }
                            break;
                        default:
                            logWriter(sWriter, "Unrecognized value " + curArg, logMask, logMaskVals.debug);
                            sWriter.Close();
                            printUsage(); //Unknown entry, so print usage and bail out
                            return;
                    }
                    i++;
                }
                catch
                {
                    parserErrorFlag = true;
                }
            }
            while (i < args.Length && !parserErrorFlag);

            if (parserErrorFlag)
            {
                logWriter(sWriter, "Parser error.", logMask, logMaskVals.debug);
                sWriter.Close();
                printUsage();
                return;
            }

            if(loginType != "NETWORK" && loginType != "IMANAGE")
            {
                ReportUsageError(sWriter, "Unrecognized login type", logMask);
                return;
            }
            // Check that the user ID is correctly specified.
            if (loginType == "IMANAGE" && String.IsNullOrEmpty(userID))
            {
                ReportUsageError(sWriter, "A user ID must be specified with the /server switch.", logMask);
                return;
            }

            // Check that the password is correctly specified.
            if (loginType == "IMANAGE" && String.IsNullOrEmpty(password))
            {
                ReportUsageError(sWriter, "A password must be specified with the /server switch.", logMask);
                return;
            }
           
            // Check that the database is correctly specified.
            if (String.IsNullOrEmpty(databaseName))
            {
                ReportUsageError(sWriter, "A database name must be specified with the /db switch.", logMask);
                return;
            }

            // Check that the database is correctly specified.
            if (String.IsNullOrEmpty(table))
            {
                ReportUsageError(sWriter, "A table name must be specified with the /table switch.", logMask);
                return;
            }

            // Check that the delimiter is correctly specified.
            ValidateDelimiterStatus validateDelimiterStatus = ValidateDelimiter(delimiter);
            if (validateDelimiterStatus != ValidateDelimiterStatus.OK)
            {
                string delimiterValidationErrorMessage = GetDelimiterValidationErrorMessage(validateDelimiterStatus);
                ReportUsageError(sWriter, delimiterValidationErrorMessage, logMask);
                return;
            }

            // Disregard the child flag if the table given can't be a parent.
            if (!TableCanBeParent(table))
            {
                childFlag = false;
            }

            // Check if a set of field specifiers was read from the command line.
            if (fieldsRead.Count > 0)
            {
                // Make sure that all required field specifiers have been specified.
                ValidateFieldSpecifiersStatus validateFieldSpecifiersStatus = ValidateFieldSpecifiers(fieldsRead, childFlag);
                if (validateFieldSpecifiersStatus == ValidateFieldSpecifiersStatus.OK)
                {
                    // The fields can be used just as they are.
                    fields = fieldsRead;
                }
                else if (validateFieldSpecifiersStatus == ValidateFieldSpecifiersStatus.DisregardOverMinimum)
                {
                    // The any field specifiers beyond the minimum number should be disregarded.
                    fields = fieldsRead.GetRange(0, FIELD_SPECIFIERS_COUNT_MINIMUM);
                }
                else
                {
                    string fieldValidationErrorMessage = GetFieldValidationErrorMessage(validateFieldSpecifiersStatus);
                    ReportUsageError(sWriter, fieldValidationErrorMessage, logMask);
                    return;
                }
            }
            else
            {
                // A set of default specifiers should be used.
                fields = CreateDefaultFieldSpecifiers(childFlag);
            }

            if (fields.Count() < FIELD_SPECIFIERS_COUNT_PARENT_CHILD && childFlag && TableCanBeParent(table)) //Must have eight field specifiers if childFlag = Y
            {
                LogError(sWriter, "Not enough field specifiers for childFlag with CUSTOM1/CUSTOM2.", logMask, logMaskVals.debug);
                sWriter.Close();
                printUsage();
                return;
            }   
         
            if ((table == "CUSTOM2" || table == "CUSTOM30") && parentAlias == null) //parentAlias is required if table is a child table
            {
                LogError(sWriter, "parentAlias missing.", logMask, logMaskVals.debug);
                sWriter.Close();
                printUsage();
                return;
            }

            logWriter(sWriter, "Server Name = " + serverName, logMask, logMaskVals.info);
            logWriter(sWriter, "Database = " + databaseName, logMask, logMaskVals.info);
            logWriter(sWriter, "Table = " + table, logMask, logMaskVals.info);
            logWriter(sWriter, "File = " + file, logMask, logMaskVals.info);
            logWriter(sWriter, "ParentAlias = " + parentAlias, logMask, logMaskVals.info);
            logWriter(sWriter, "Overwrite = " + overwrite, logMask, logMaskVals.info);
            logWriter(sWriter, "ChildFlag = " + childFlagToken, logMask, logMaskVals.info);
            logWriter(sWriter, "Delimiter = " + delimiter, logMask, logMaskVals.info);

            //Open specified data file
            StreamReader reader;
            try
            {
                reader = new StreamReader(File.OpenRead(file));
                logWriter(sWriter, "Data file successfully opened.", logMask, logMaskVals.info);
            }
            catch (Exception e)
            {
                LogError(sWriter, "Unable to access file " + file + ":" + e.Message, logMask, logMaskVals.error);
                sWriter.Close();
                return;
            }

            //Login to WorkSite and get the specified DB

            NRTDMS dms = null;
            try
            {
                dms = new NRTDMS();
            }
            catch(System.Runtime.InteropServices.COMException cex)
            {
                if (cex.ErrorCode == -2147221164)
                {
                    logWriter(sWriter, "Unable to create DMS object--please ensure IMANADMIN.DLL is registered.", logMask, logMaskVals.error);
                    sWriter.Close();
                    return;
                }
            }           
            NRTSession session = dms.Sessions.Add(serverName);
            NRTDatabase myDB;
            if (loginType == "IMANAGE")
            {
                try
                {

                    session.Login(userID, password);
                    logWriter(sWriter, "Successfully logged into WorkSite server.", logMask, logMaskVals.info);
                }
                catch
                {
                    DualReport(sWriter, "Could not log into WorkSite server.", logMask, logMaskVals.error);
                    sWriter.Close();
                    return;
                }
            }
            else
            {
                string token = string.Empty;
                bool samlLogin = LoginSAML(session);
                if(!samlLogin)
                {
                    DualReport(sWriter, "Could not log into WorkSite server.", logMask, logMaskVals.error);
                    sWriter.Close();
                    return;
                }
            }
            try
            {
                myDB = (NRTDatabase)session.Databases.Item(databaseName);
                logWriter(sWriter, "Successfully connected to database.", logMask, logMaskVals.info);
            }
            catch
            {
                LogError(sWriter, "Could not access database " + databaseName + ".", logMask, logMaskVals.error);
                sWriter.Close();
                return;
            }

            int maximumFieldSpecifier = 0;
            foreach (int fieldSpecifier in fields)
            {
                if (fieldSpecifier > maximumFieldSpecifier)
                {
                    maximumFieldSpecifier = fieldSpecifier;
                }
            }
            if (!string.IsNullOrEmpty(table))
            {
                tableDefined = true;
                //Make call here to API to insert values                 

               

                fields = ValidateChildFlagAndfieldSpecifiers(table, ref childFlag, ref maximumFieldSpecifier, fieldsRead,sWriter,logMask);

                if (fields.Count() < FIELD_SPECIFIERS_COUNT_PARENT_CHILD && childFlag && TableCanBeParent(table)) //Must have eight field specifiers if childFlag = Y
                {
                    

                    printUsage();
                    return;
                }

                if ((table == "CUSTOM2" || table == "CUSTOM30") && parentAlias == null) //parentAlias is required if table is a child table
                {
                    

                    printUsage();
                    return;
                }

            }

            //Main file read loop

            int Counter = 0;
            while (!reader.EndOfStream)
            {
                string line = reader.ReadLine();
                if (!String.IsNullOrWhiteSpace(line))
                {
                    string[] tempStringArray = line.Split(delimiter[0]);
                    string tempString;
                    List<string> myList = new List<string>();
                    bool found = false;
                    int startindex = 0;
                    bool defaultChildFlag = childFlag;
                    if (!tableDefined)
                    {
                        table = null;
                        parentAlias = null;
                       
                        table = tempStringArray[0].ToUpper();
                        

                        
                        if (tempStringArray.Length < 8)
                        {
                            childFlag = false;
                        }
                        else
                        {

                            childFlag = defaultChildFlag;
                        }
                        maximumFieldSpecifier = 0;
                        fields = ValidateChildFlagAndfieldSpecifiers(table, ref childFlag, ref maximumFieldSpecifier, fieldsRead,sWriter,logMask);



                        if (fields.Count() < FIELD_SPECIFIERS_COUNT_PARENT_CHILD && childFlag && TableCanBeParent(table)) //Must have eight field specifiers if childFlag = Y
                        {
                            logWriter(sWriter, "Not enough field specifiers for childFlag with CUSTOM1/CUSTOM2.",logMask,logMaskVals.error);

                            continue;

                        }
                        startindex = 1;
                        if ((table == "CUSTOM2" || table == "CUSTOM30")) //parentAlias is required if table is a child table
                        {
                            parentAlias = tempStringArray[1].ToUpper();
                            startindex = 2;
                            
                            
                           
                        }

                    }

                    for (int i2 = startindex; i2 < tempStringArray.Length; i2++)
                    {
                        if (i2 < tempStringArray.Length - 1 && tempStringArray[i2].Length > 0 && tempStringArray[i2][0] == '"')
                        {
                            tempString = tempStringArray[i2].Substring(1, tempStringArray[i2].Length - 1);

                            for (int i3 = i2 + 1; i3 < tempStringArray.Length; i3++)
                            {
                                if (tempStringArray[i3][tempStringArray[i3].Length - 1] == '"')
                                {
                                    tempString = tempString + "," + tempStringArray[i3].Substring(0, tempStringArray[i3].Length - 1);
                                    i2 = i3;
                                    found = true;
                                    break;
                                }
                                else
                                {
                                    tempString = tempString + "," + tempStringArray[i3];
                                }
                            }
                            if (!found)
                            {
                                tempString = tempStringArray[i2];
                            }
                            found = false;
                        }
                        else
                        {
                             tempString = tempStringArray[i2];
                        }
                        if ((tempString.Length > 0) && tempString[0] == '"' && tempString[tempString.Length - 1] == '"')
                        {
                            myList.Add(tempString.Substring(1, tempString.Length - 2));
                        }
                        else
                        {
                            myList.Add(tempString);
                        }
                    }
                    String[] values = myList.ToArray();

                    if (values.Length < maximumFieldSpecifier)
                    {
                        LogError(sWriter, "Invalid field format in file--verify that all fields are present:", logMask, logMaskVals.error);
                        logWriter(sWriter, line, logMask, logMaskVals.error);
                        sWriter.Close();
                        return;
                    }

                    //Make call here to API to insert values                 
                    AttributeID attID = getAttributeID(table);
                    if (attID == AttributeID.nrDatabase) //This will be true if table name is invalid since function returns a zero
                    {
                        LogError(sWriter, "Invalid table name specified " + table, logMask, logMaskVals.error);
                        sWriter.Close();
                        printUsage();
                        return;
                    }
                    string aliasVal = values[fields[0] - 1]; //Get required parent field values
                    string descVal = "";
                    if (fields[1] != -1)  //If field specifier for description is -1, then leave description blank
                    {
                        descVal = values[fields[1] - 1];
                    }
                    bool enabledVal = true;
                    if (fields[2] != -1) //If field specifier for enabled flag is -1, then leave as default
                    {
                        enabledVal = getBool(values[fields[2] - 1]);
                    }
                    bool HIPAAVal = false;
                    if (fields[3] != -1) //If field specifier for HIPAA flag is -1, then leave as default
                    {
                        HIPAAVal = getBool(values[fields[3] - 1]);
                    }

                    if (parentAlias == null && (attID != AttributeID.nrCustom2 || attID != AttributeID.nrCustom30))
                    {
                        try
                        {
                            myDB.InsertParentCustomField(attID, aliasVal, descVal, enabledVal);
                        }
                        catch
                        {
                            logWriter(sWriter, "Problem inserting parent custom field for " + attID.ToString() + ", alias = " + aliasVal + ", description = " + descVal, logMask, logMaskVals.warn);
                            if (overwrite == "Y")
                            {
                                try
                                {
                                    myDB.ModifyParentCustomField(attID, aliasVal, aliasVal, descVal, enabledVal);
                                }
                                catch
                                {
                                    logWriter(sWriter, "Problem updating parent custom field for " + attID.ToString() + ", alias = " + aliasVal + ", description = " + descVal, logMask, logMaskVals.warn);
                                }
                            }
                        }
                    }
                    else                        
                    {                        
                        try
                        {
                            
                            myDB.InsertChildCustomField(attID, parentAlias, aliasVal, descVal, enabledVal);
                        }
                        catch
                        {
                            logWriter(sWriter, "Problem inserting child custom field for " + attID.ToString() + ", parentAlias = " + parentAlias + ", alias = " + aliasVal + ", description = " + descVal, logMask, logMaskVals.warn);
                            if (overwrite == "Y")
                            {
                                try
                                {
                                    myDB.ModifyChildCustomField(attID, parentAlias, aliasVal, parentAlias, aliasVal, descVal, enabledVal);
                                }
                                catch
                                {
                                    logWriter(sWriter, "Problem updating child custom field for " + attID.ToString() + ", parentAlias = " + parentAlias + ", alias = " + aliasVal + ", description = " + descVal, logMask, logMaskVals.warn);
                                }
                            }
                        }                        
                    }

                    if ((attID == AttributeID.nrCustom1 || attID == AttributeID.nrCustom29) && childFlag)
                    {
                        AttributeID childAttID;
                        if (attID == AttributeID.nrCustom1)
                        {
                            childAttID = AttributeID.nrCustom2;
                        }
                        else
                        {
                            childAttID = AttributeID.nrCustom30;
                        }
                        string childAliasVal = values[fields[4] - 1];
                        string childDescVal = "";
                        if (fields[5] != -1)  //If field specifier for description is -1, then leave description blank
                        {
                            childDescVal = values[fields[5] - 1];
                        }
                        bool childEnabledVal = true;
                        if (fields[6] != -1) //If field specifier for enabled flag is -1, then leave as default
                        {
                            childEnabledVal = getBool(values[fields[6] - 1]);
                        }
                        bool childHIPAAVal = false;
                        if (fields[7] != -1) //If field specifier for HIPAA flag is -1, then leave as default
                        {
                            childHIPAAVal = getBool(values[fields[7] - 1]);
                        }
                        try
                        {
                            myDB.InsertChildCustomField(childAttID, aliasVal, childAliasVal, childDescVal, childEnabledVal);
                        }
                        catch
                        {
                            logWriter(sWriter, "Problem inserting child custom field for " + childAttID.ToString() + ", parentAlias = " + aliasVal + ", alias = " + childAliasVal + ", description = " + childDescVal, logMask, logMaskVals.warn);
                            if (overwrite == "Y")
                            {
                                try
                                {
                                    myDB.ModifyChildCustomField(childAttID, aliasVal, childAliasVal, aliasVal, childAliasVal, childDescVal, childEnabledVal);
                                }
                                catch
                                {
                                    logWriter(sWriter, "Problem updating child custom field for " + attID.ToString() + ", parentAlias = " + aliasVal + ", alias = " + childAliasVal + ", description = " + childDescVal, logMask, logMaskVals.warn);
                                }
                            }
                        }
                    }                                                                                
                }
                Counter++;
                if ((Counter % 10) == 0)
                {
                    logWriter(sWriter, Counter.ToString() + " entries processed.", logMask, logMaskVals.info);
                }
            }
            logWriter(sWriter, Counter.ToString() + " entries processed.", logMask, logMaskVals.info);
            logWriter(sWriter, "*** END RUN -- check date***", (logMaskVals)15, logMaskVals.info); //Reset logmask to max so info will show.
            sWriter.Close();         
        }

        private static List<int> ValidateChildFlagAndfieldSpecifiers(string table, ref bool childFlag, ref int maximumFieldSpecifier, List<int> fieldsRead, StreamWriter sWriter,logMaskVals logMask)
        {
            List<int> fields = new List<int>();
            // Disregard the child flag if the table given can't be a parent.
            if (!TableCanBeParent(table))
            {
                childFlag = false;
            }

            // Check if a set of field specifiers was read from the command line.
            if (fieldsRead.Count > 0)
            {
                // Make sure that all required field specifiers have been specified.
                ValidateFieldSpecifiersStatus validateFieldSpecifiersStatus = ValidateFieldSpecifiers(fieldsRead, childFlag);
                if (validateFieldSpecifiersStatus == ValidateFieldSpecifiersStatus.OK)
                {
                    // The fields can be used just as they are.
                    fields = fieldsRead;
                }
                else if (validateFieldSpecifiersStatus == ValidateFieldSpecifiersStatus.DisregardOverMinimum)
                {
                    // The any field specifiers beyond the minimum number should be disregarded.
                    fields = fieldsRead.GetRange(0, FIELD_SPECIFIERS_COUNT_MINIMUM);
                }
                else
                {
                    string fieldValidationErrorMessage = GetFieldValidationErrorMessage(validateFieldSpecifiersStatus);
                    ReportUsageError(sWriter,fieldValidationErrorMessage,logMask);
                    return fields;
                }
            }
            else
            {
                // A set of default specifiers should be used.
                fields = CreateDefaultFieldSpecifiers(childFlag);
            }

            foreach (int fieldSpecifier in fields)
            {
                if (fieldSpecifier > maximumFieldSpecifier)
                {
                    maximumFieldSpecifier = fieldSpecifier;
                }
            }
            return fields;
        }
      
        
        private static bool LoginSAML(NRTSession session)
        {
            bool bVal = false;
            try
            {
                Com.Interwoven.WorkSite.iManAdmin.INRTCommonLoginSession commonLogin = session as Com.Interwoven.WorkSite.iManAdmin.INRTCommonLoginSession;
                commonLogin.CommonLogin();
                bVal = true;
            }
            catch
            {

            }
            return bVal;

        }

        /// <summary>
        /// LogError reports an error in the log, and notes the presence of the logged error message on the standard error stream.
        /// </summary>
        /// <param name="sWriter">the stream for the error log</param>
        /// <param name="errorMessage">the error message to report</param>
        /// <param name="logMask"></param>
        /// <param name="logLevel">the log level at which the error should be reported</param>
        private static void LogError(StreamWriter sWriter, string errorMessage, logMaskVals logMask, logMaskVals logLevel)
        {
            if ((logMask & logLevel) != logMaskVals.none)
            {
                Console.Error.WriteLine("An error has occurred that is recorded in this application's log.");
                logWriter(sWriter, errorMessage, logMask, logLevel);
            }
        }

        /// <summary>
        /// ReportUsageError reports an error in the command line parameters to the user, and prints out the usage block for reference.
        /// </summary>
        /// <param name="sWriter">the stream to which to write the error message</param>
        /// <param name="usageErrorMessage">an error message describing the usage error</param>
        /// <param name="logMask">the log mask, containing the current logging level</param>
        private static void ReportUsageError(StreamWriter sWriter, string usageErrorMessage, logMaskVals logMask)
        {
            DualReport(sWriter, usageErrorMessage, logMask, logMaskVals.error);
            sWriter.Close();
            Console.Error.WriteLine();
            printUsage();
        }

        /// <summary>
        /// DualReport reports an error to both the log and the stderr stream.
        /// </summary>
        /// <param name="sWriter">the stream to which to write the error message</param>
        /// <param name="errorToReport">an error message describing the usage error</param>
        /// <param name="logMask">the log mask, containing the current logging level</param>
        /// <param name="logLevel">the logging level of this message</param>
        private static void DualReport(StreamWriter sWriter, string errorToReport, logMaskVals logMask, logMaskVals logLevel)
        {
            logWriter(sWriter, errorToReport, logMask, logLevel);
            Console.Error.WriteLine(errorToReport);
        }

        /// <summary>
        /// WadeNextArgument attempts to get the next argument for the current switch if it exists and does not encounter the next switch.
        /// </summary>
        /// <param name="args">the command line arguments</param>
        /// <param name="i">the current index into the command line arguments</param>
        /// <returns>the next argument if it exists, or an empty string if it does not</returns>
        private static string WadeNextArgument(string[] args, ref int i)
        {
            string nextArgument = String.Empty;
            int nextArgumentIndex = i + 1;
            if ((nextArgumentIndex < args.Length) && (!args[nextArgumentIndex].StartsWith("/")))
            {
                nextArgument = args[nextArgumentIndex];
                i = nextArgumentIndex;
            }
            return nextArgument;
        }

        /// <summary>
        /// GetFieldValidationErrorMessage returns an error message to report corresponding to a given error status
        /// for field specifier validation.
        /// </summary>
        /// <param name="validateFieldSpecifiersStatus">the status of the field specifier validation</param>
        /// <returns>an error message that explains the error encountered during delimiter validation</returns>
        private static string GetFieldValidationErrorMessage(ValidateFieldSpecifiersStatus validateFieldSpecifiersStatus)
        {
            string fieldValidationErrorMessage = String.Empty;
            switch (validateFieldSpecifiersStatus)
            {
                case ValidateFieldSpecifiersStatus.WrongNumberOfFieldsForParentChild:
                    fieldValidationErrorMessage = "There needs to be eight field specifiers in order to import parent/child records.";
                    break;
                case ValidateFieldSpecifiersStatus.WrongNumberOfFields:
                    fieldValidationErrorMessage = "The number of field specifiers needed to import data into a single table is at least four or none.";
                    break;
                case ValidateFieldSpecifiersStatus.ParentIDMustBeSpecified:
                    fieldValidationErrorMessage = "No data column for the parent lookup ID was specified.";
                    break;
                case ValidateFieldSpecifiersStatus.ChildIDMustBeSpecified:
                    fieldValidationErrorMessage = "No data column for the child lookup ID was specified.";
                    break;
                case ValidateFieldSpecifiersStatus.IDMustBeSpecified:
                    fieldValidationErrorMessage = "No data column for the lookup ID was specified.";
                    break;
                case ValidateFieldSpecifiersStatus.TooManyFields:
                    fieldValidationErrorMessage = "There should not be more than eight fields given for the /format switch.";
                    break;
                default:
                    fieldValidationErrorMessage = String.Empty;
                    break;
            }
            return fieldValidationErrorMessage;
        }


        /// <summary>
        /// GetDelimiterValidationErrorMessage returns an error message to report corresponding to a given error status
        /// for delimiter validation.
        /// </summary>
        /// <param name="validateDelimiterStatus">the status of the delimiter validation</param>
        /// <returns>an error message that explains the error encountered during delimiter validation</returns>
        private static string GetDelimiterValidationErrorMessage(ValidateDelimiterStatus validateDelimiterStatus)
        {
                string delimiterValidationErrorMessage = String.Empty;
                switch(validateDelimiterStatus)
                {
                    case ValidateDelimiterStatus.DelimiterWasDoubleQuotation:
                        delimiterValidationErrorMessage = "The delimiter cannot be a double quotation mark";
                        break;
                    case ValidateDelimiterStatus.DelimiterWasTooLarge:
                        delimiterValidationErrorMessage = "The delimiter can be at most one character long.";
                        break;
                    default:
                        // Do nothing.
                        break;
                }
            return delimiterValidationErrorMessage;
        }

        /// <summary>
        /// CreateDefaultFieldSpecifiers creates the default set of field specifiers based on whether or not child table data is being imported.
        /// </summary>
        /// <param name="childFlag">true if child table data is being imported</param>
        /// <returns>a set of default field specifiers</returns>
        private static List<int> CreateDefaultFieldSpecifiers(bool childFlag)
        {
            List<int> defaultFields = new List<int>();

            // Create a default set of field specifiers.
            int numberOfSpecifiers = FIELD_SPECIFIERS_COUNT_PARENT_CHILD;
            if (childFlag)
            {
                numberOfSpecifiers = FIELD_SPECIFIERS_COUNT_PARENT_CHILD;
            }
            else
            {
                numberOfSpecifiers = FIELD_SPECIFIERS_COUNT_MINIMUM;
            }
            for (int specifierToAdd = 0; specifierToAdd < numberOfSpecifiers; ++specifierToAdd)
            {
                defaultFields.Add(specifierToAdd + 1);
            }

            return defaultFields;
        }

        /// <summary>
        /// ValidateFieldSpecifiers checks to see if all the required field specifiers have been supplied at the command line.
        /// </summary>
        /// <param name="fields">the list of field specifiers; </param>
        /// <param name="childFlag"></param>
        /// <param name="parentAlias"></param>
        /// <returns>true if the required field specifiers are specified</returns>
        private static ValidateFieldSpecifiersStatus ValidateFieldSpecifiers(List<int> fields, bool childFlag)
        {
            ValidateFieldSpecifiersStatus status = ValidateFieldSpecifiersStatus.OK;

            if (fields.Count > FIELD_SPECIFIERS_COUNT_PARENT_CHILD)
            {
                status = ValidateFieldSpecifiersStatus.TooManyFields;
            }
            else
            {
                if (childFlag)
                {
                    if (fields.Count != FIELD_SPECIFIERS_COUNT_PARENT_CHILD)
                    {
                        status = ValidateFieldSpecifiersStatus.WrongNumberOfFieldsForParentChild;
                    }
                    else
                    {
                        if (!FieldSpecified(fields[FIELD_SPECIFIER_CHILD_ID]))
                        {
                            status = ValidateFieldSpecifiersStatus.ChildIDMustBeSpecified;
                        }
                        else if (!FieldSpecified(fields[FIELD_SPECIFIER_PARENT_ID]))
                        {
                            status = ValidateFieldSpecifiersStatus.ParentIDMustBeSpecified;
                        }
                    }

                }
                else
                {
                    if (fields.Count < FIELD_SPECIFIERS_COUNT_MINIMUM)
                    {
                        status = ValidateFieldSpecifiersStatus.WrongNumberOfFields;
                    }
                    else if (!FieldSpecified(fields[FIELD_SPECIFIER_ID]))
                    {
                        status = ValidateFieldSpecifiersStatus.IDMustBeSpecified;
                    }
                    else if (fields.Count != FIELD_SPECIFIERS_COUNT_MINIMUM)
                    {
                        status = ValidateFieldSpecifiersStatus.DisregardOverMinimum;
                    }
                }
            }

            return status;
        }

        /// <summary>
        /// ValidateDelimiter returns a status that indicates whether or not the given delimiter is valid.
        /// </summary>
        /// <param name="delimiter"></param>
        /// <returns></returns>
        private static ValidateDelimiterStatus ValidateDelimiter(string delimiter)
        {
            ValidateDelimiterStatus validateDelimiterStatus = ValidateDelimiterStatus.OK;
            if (String.IsNullOrEmpty(delimiter))
            {
                validateDelimiterStatus = ValidateDelimiterStatus.OK;
            }
            else
            {
                if (delimiter.Length > 1)
                {
                    validateDelimiterStatus = ValidateDelimiterStatus.DelimiterWasTooLarge;
                }
                else if (delimiter.Length == 1)
                {
                    if (delimiter.Equals("\""))
                    {
                        validateDelimiterStatus = ValidateDelimiterStatus.DelimiterWasDoubleQuotation;
                    }
                    else
                    {
                        validateDelimiterStatus = ValidateDelimiterStatus.OK;
                    }
                }
            }

            return validateDelimiterStatus;
        }

        /// <summary>
        /// FieldSpecified checks whether a field specifier value is specified or not.
        /// </summary>
        /// <param name="fieldSpecifierValue">the value of the field specifier to check</param>
        /// <returns>true if the field specifier value indicates that it is specified</returns>
        private static bool FieldSpecified(int fieldSpecifierValue)
        {
            if ((fieldSpecifierValue > 0) && (fieldSpecifierValue != FIELD_NOT_SPECIFIED))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// TableCanBeParent returns true if the table with the given table name can be a parent table
        /// </summary>
        /// <param name="tableName">the name of the table to check whether or not it can be a parent table</param>
        /// <returns>true if the table with the given table name can be a parent table</returns>
        private static bool TableCanBeParent(string tableName)
        {
            bool tableCanBeParent = false;

            if (!String.IsNullOrEmpty(tableName))
            {
                if (tableName.ToUpper() == "CUSTOM1" || tableName.ToUpper() == "CUSTOM29")
                {
                    tableCanBeParent = true;
                }
                else
                {
                    tableCanBeParent = false;
                }
            }
            else
            {
                tableCanBeParent = false;
            }
            return tableCanBeParent;
        }

        private static void ParseFormat(string[] args, ref String delimiter, ref List<int> fields, logMaskVals logMask, StreamWriter sWriter, ref int i)
        {
            String dm_temp = tokenize(args[i], ':', false);
            if (dm_temp.Substring(0, 1).Equals("\""))
            {
                if (dm_temp.Length == 1)
                {
                    delimiter = dm_temp.Substring(0, 1);
                }
                else
                {
                    delimiter = dm_temp[1].ToString(); //Get specified delimeter and strip any quotes
                }
            }
            else
            {
                delimiter = dm_temp; //No quotes, so just get delimiter as-is
            }

            // Check if the next argument is a switch (there are no field specifiers).
            int numberOfFieldsLeft = args.Length - i; //Check for any field specifiers
            List<int> fieldsRead = new List<int>();
            if (numberOfFieldsLeft > 0)
            {
                logWriter(sWriter, "Parsing, list cleared.", logMask, logMaskVals.debug);
                bool nonNumberEncountered = false;
                for (int c = i + 1; (c < args.Length) && nonNumberEncountered == false; c++)
                {
                    if (args[c].Substring(0, 1) == "/") //Ensure it's not another switch
                    {
                        nonNumberEncountered = true;
                    }
                    else
                    {
                        int? fieldSpecifier = null;
                        try
                        {
                            fieldSpecifier = Convert.ToInt32(args[c]);
                        }
                        catch
                        {
                            fieldSpecifier = null;
                            nonNumberEncountered = true;
                        }
                        if (fieldSpecifier.HasValue)
                        {
                            fieldsRead.Add(fieldSpecifier.Value); //Add any field specifiers to corresponding int list   
                            logWriter(sWriter, "Parsing, added field value " + Convert.ToInt32(args[c]).ToString(), logMask, logMaskVals.debug);
                            i++;
                        }
                    }
                }
            }
            
            if (fieldsRead.Count == 0) //Reset default field specifiers if we cleared it but then found none
            {
                fields.Clear();
                for (int c = 1; c <= FIELD_SPECIFIERS_COUNT_PARENT_CHILD; c++)
                {
                    fields.Add(c); //Set default field specifiers 1-8
                    logWriter(sWriter, "List cleared but NOT populated, re-initializing, added field value " + c.ToString(), logMask, logMaskVals.debug);
                }
            }
            else
            {
                fields = fieldsRead;
            }

            logWriter(sWriter, "Count = " + fields.Count().ToString(), logMask, logMaskVals.debug);
        }
    }
}
