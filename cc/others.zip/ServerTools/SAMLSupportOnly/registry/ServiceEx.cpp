//=============================================================================
// File: ServiceEx.cpp
//-----------------------------------------------------------------------------
// Date      Who  Modification
// --------  ---  -------------------------------------------------------------
// 01/10/00  ZIA  Initial coding
//-----------------------------------------------------------------------------
// Copyright (C) 1999, NetRight Technologies, Inc.
// PROPRIETARY AND CONFIDENTIAL
//=============================================================================
//
//	Classes for managing service configuration information in the registry
//

#include <Registry\RegistryLib.h>

#pragma hdrstop

#include <Registry\ServiceEx.h>


//
//	DMS and indexer common registry keys
//

#define KEY_INDEXER_PATH				TEXT("Indexer Files")


//
//	DMS service properties
//


#define KEY_THREAD_COUNT					_T("Worker Threads")
#define KEY_CLUSTER_NAME					_T("Cluster Name")
#define KEY_GIVEN_SVC_PORT					_T("Given Service Port")
#define KEY_SVC_PORT						_T("Service Port")

#define KEY_DOCNUM_INCREASE					_T("DocNum Increase On Supervised Import")
#define KEY_TRUSTED_LOGON					_T("Allowed Trusted Logon")
#define KEY_ENFORCE_KERBEROS				_T("Enforce Kerberos Authentication")

#define KEY_PRELOAD_CACHE					_T("Preload Cache Data")
#define KEY_CACHE_REFRESH					_T("Cache Refresh")
#define KEY_CACHE_ROWS						_T("Cache Table Rows")
#define KEY_SHARED_CM						_T("Shared CM Cache")
#define KEY_SHARED_CM_DB					_T("CM Database")
#define KEY_GIVEN_FILE_PORT					_T("Given File Transfer Port")
#define KEY_FILE_PORT						_T("File Transfer Port")

//Elyas++
#define KEY_IMPERSONATION_ENABLED			_T("Impersonation Enabled")
#define KEY_IMPERSONATION_PASSWORD			_T("Impersonation Password")
//Elyas--
#define KEY_BACKWARDS_COMPATIBLE_ACCESS		_T("Backwards Compatible Access")

#define KEY_CASE_INSENSITIVE_ORACLE			_T("Case Insensitive Oracle")

//#define KEY_SECURE_VALIDATED_FIELDS_FILTER	_T("Secure Validated Fields Filter")
#define KEY_SECURE_VALIDATED_FIELDS_MASK	_T("Secure Validated Fields Mask")

#define KEY_ACI_INIT_ENCRYPTION				_T("ACI Init Encryption")

#define KEY_AUTHENTICATE_WEB_DB				_T("Authenticate to Web Database")

#define KEY_SECURITY_MODEL					_T("Security Model")
#define KEY_GOVERN_ENABLED					_T("Govern Enabled")

#define KEY_EMAIL_DOMAIN					_T("Email Domain")
#define KEY_SERVER_SIDE_DUPLICATE_DETECTION_TYPE		_T("Server-Side Duplicate Detection Type")
#define KEY_ADD_MAILBOXSYNC_QUEUE			_T("Add MailBoxSync Queue")
#define KEY_ADDITIONAL_EMAIL_STUB_CLASSES   _T("Additional Email Stub Classes")

#define KEY_UUENCODE						_T("UUEncode")

#define KEY_DOCCACHE_ENABLED				_T("Document Cache Enabled")
#define KEY_ADD_EMAILS_WORKLIST				_T("Add Emails To Worklist")
#define KEY_DOCCACHE_FILEPATH				_T("Document Cache File Path")
#define KEY_DOCCACHE_ROOTPATH				_T("Document Cache Root Path")
#define KEY_DOCCACHE_FILEPATH_OS			_T("Document Cache File Path OS")
#define KEY_DOCCACHE_ACCESS_METHOD			_T("Document Cache Access Method")
#define KEY_DOCCACHE_UPLOAD_WAIT_TIME		_T("Document Cache Upload Wait Time")
#define KEY_SECURE_DOCCACHE_FILEPATH		_T("Secure Document Cache File Path")
#define KEY_SECURE_DOCCACHE_ROOTPATH		_T("Secure Document Cache Root Path")
#define KEY_SECURE_DOCCACHE_FILEPATH_OS		_T("Secure Document Cache File Path OS")
#define KEY_SECURE_DOCCACHE_ACCESS_METHOD	_T("Secure Document Cache Access Method")

//CMS Service Config
#define KEY_DIR_TEMP_FILE  					_T("Directory for Temp files")
#define KEY_VERIFY_LEVEL   					_T("Verify Level")

#define KEY_LOG_EVENTS_IN_SERVER			_T("Log Events In Server")



//#define KEY_SALVAGE_SPACE	_T("Salvage Space")
//#define KEY_SALVAGE_PATH	_T("Salvage Path")
//#define KEY_SALVAGE_IN_USE	_T("Salavge In Use")

//#define KEY_CACHE_SPACE		_T("Cache Space")
//#define KEY_CACHE_PATH		_T("Cache Path")
//#define KEY_CACHE_IN_USE	_T("Cache In Use")

#define KEY_DEFAULT_DOC_CLASS				_T("Default Document Class")

#define KEY_EMAIL_TYPES						_T("Email Types")
#define KEY_PDF_TYPES						_T("PDF Types")
#define KEY_IMPORT_EMAILS_AS_DECLARED		_T("Import Emails As Declared")
			
#define KEY_KLUDGE_RETAIN_EXT_ANSI			_T("Retain extension for ANSI types")
#define KEY_KLUDGE_RETAIN_EXT_NON_EMAIL		_T("Retain extension for non-Email types")

#define KEY_KLUDGE_RETAIN_EXT_ANSI		_T("Retain extension for ANSI types")
#define KEY_KLUDGE_RETAIN_EXT_NON_EMAIL	_T("Retain extension for non-Email types")

#define KEY_WFM_ENABLED						_T("WFM Enabled")
#define KEY_WFM_SERVER						_T("iWFMServerName")

//Bulk updates enabled
#define KEY_BACKGROUND_JOBS_ENABLED			_T("Background Jobs Enabled")
#define KEY_BACKGROUND_JOBS_THREAD_TIMEOUT	_T("Background Jobs Thread Timeout")
#define KEY_BACKGROUND_JOBS_CLUSTER_ENABLED	_T("Background Jobs Cluster Enabled")
#define KEY_BACKGROUND_DOCUMENT_CHUNK_SIZE	_T("Background Jobs Document Chunk Size")
#define KEY_BACKGROUND_FOLDER_CHUNK_SIZE	_T("Background Jobs Folder Chunk Size")
#define KEY_BACKGROUND_WORKSPACE_CHUNK_SIZE	_T("Background Jobs Workspace Chunk Size")

// SEV email reconciliation subsystem
#define KEY_EMAIL_VAULT_ENABLED				_T("SEV Enabled")
#define KEY_EMAIL_VAULT_SERVER				_T("SEV Server Address")
#define KEY_EMAIL_RECONCILE_RETRY		    _T("Reconciliation Retry")
#define KEY_EMAIL_DOWNLOAD_FILE_RETRY		_T("Download File Retry")
#define KEY_EMAIL_RECONCILE_THREAD_TIMEOUT	_T("Reconcile Thread TimeOut")
#define KEY_EMAIL_RECONCILE_USERID			_T("Reconcile UserId")

//SEV-Notes integration
#define KEY_SEV_NOTES_ENABLED				_T("SEV Notes Enabled")
#define KEY_SEV_NOTES_ID_PATH				_T("SEV Notes ID Path")
#define KEY_SEV_NOTES_ID_PASSWORD			_T("SEV Notes ID Password")
#define KEY_SEV_NOTES_TEMPLATE_PATH			_T("SEV Notes Template Path")
#define KEY_SEV_NOTES_TEMP_DB_PATH			_T("SEV Notes Temp DB Path")
#define KEY_SEV_NOTES_TYPE_ALIAS			_T("SEV Notes Type Alias")

// EAS email reconciliation subsystem
#define KEY_EAS_EMAIL_ENABLED					_T("EAS Enabled")
#define KEY_EAS_EMAIL_SERVER					_T("EAS Server Address")
#define KEY_EAS_EMAIL_RECONCILE_RETRY		    _T("EAS Reconciliation Retry")
#define KEY_EAS_EMAIL_DOWNLOAD_FILE_RETRY		_T("EAS Download File Retry")
#define KEY_EAS_EMAIL_RECONCILE_THREAD_TIMEOUT	_T("EAS Reconcile Thread TimeOut")
#define KEY_EAS_EMAIL_RECONCILE_USERID			_T("EAS Reconcile UserId")
#define KEY_EAS_EMAIL_APPURL					_T("EAS App URL")
#define KEY_EAS_EMAIL_ADMINUSERID				_T("EAS Admin UserId")
#define KEY_EAS_EMAIL_ADMINPWD					_T("EAS Admin Password")

// HP ACA email reconciliation subsystem
#define KEY_ACA_EMAIL_ENABLED				_T("HPCA Enabled")
#define KEY_ACA_EMAIL_SERVER				_T("HPCA Server Address")


// FMA Client reply ports
#define KEY_FMA_CLIENT_REPLY_PORT				_T("Reply Port")
#define KEY_FMA_CLIENT_NUM_REPLY_PORTS			_T("Number of Reply Ports")


// Hosted DM Configurations
#define KEY_HOSTED_DM_ENABLED					_T("Hosted DM Enabled")
#define KEY_HOSTED_SERVICE_PORT					_T("Hosted Service Port")
#define KEY_HOSTED_FILE_PORT					_T("Hosted File Port")
#define KEY_HOSTED_SESSION_TIMEOUT				_T("Hosted Session Timeout")
#define KEY_HOSTED_SSL_ENABLED					_T("Hosted SSL Enabled")
#define KEY_USE_SSL_COMPRESSION					_T("Use SSL Compression")
#define KEY_HOSTED_SSL_CA_CERT_PATH				_T("Hosted SSL CA Cert Path")
#define KEY_HOSTED_SSL_KEY_FILE_PATH			_T("Hosted SSL Key File Path")
#define KEY_HOSTED_SSL_KEY_FILE_PASSWORD		_T("Hosted SSL Key File Password")
#define KEY_HOSTED_SSL_CIPHERS					_T("Hosted SSL Ciphers")
#define KEY_HOSTED_DISABLESSLV2					_T("Hosted Disable SSL2.0")
#define KEY_HOSTED_DISABLESSLV3					_T("Hosted Disable SSL3.0")
#define KEY_HOSTED_DISABLETLSV1					_T("Hosted Disable TLS1.0")
#define KEY_HOSTED_DISABLETLSV1_1				_T("Hosted Disable TLS1.1")
#define KEY_HOSTED_DISABLETLSV1_2				_T("Hosted Disable TLS1.2")
#define KEY_HOSTED_HTTPS_AUTHN_SERVERTYPE       _T("Hosted HTTPS Authn. Server Type")
#define KEY_HOSTED_HTTPS_AUTHN_SERVERNAME       _T("Hosted HTTPS Authn. Server Name")
#define KEY_HOSTED_HTTPS_AUTHN_SSL				_T("Hosted HTTPS Authn. SSL")
#define KEY_HOSTED_HTTPS_AUTHN_PORT				_T("Hosted HTTPS Authn. Port")
#define	KEY_ENABLE_NETWORK_LOGIN				_T("Enable Network Login")

#define KEY_ALLOW_DESC_FULLTEXT_SEARCH			_T("Allow Description Fulltext Search")
#define KEY_USE_SYSTEM_DATES					_T("Use System Dates")
#define KEY_ADVANCED_SERVER						_T("Advanced Server")
#define KEY_HPFLOW_SERVER						_T("HpFlow Server")


#define KEY_MAX_XQ								_T("Max XQ")
#define KEY_MAX_QD								_T("Max QD")
#define KEY_SLEEP_PER_BACKGROUND_SESSION		_T("Sleep Per Background Session")

#define KEY_IPV6_MULTICASTADDRESS				_T("IPV6 Multicast Address")
#define KEY_SERVER_SIDE_DUPLICATE_DETECTION		_T("Server-Side Duplicate Detection")
#define KEY_HIPAA_TEMP_DIRECTORY	     		_T("Hipaa Temp Directory")

#define KEY_USE_SESSION_LOCALE_FOR_TRANSLATION	_T("Use Session Locale for Translation")
#define KEY_ALLOW_UNICODE_DATA					_T("Allow Unicode Data")
#define KEY_FOLDER_FTSEARCH_MULTIPLIER			_T("Folder FT Search Multiplier")

#define KEY_RESET_COMINDEX_AND_INDEXED_ON_UPDATE		_T("Reset COMINDEX and INDEXED on Update")

#define KEY_RENDER_SERVER_ADDRESS				_T("Render Server Address")

#define KEY_MAX_MARKED_FOLDERS					_T("Max Marked Folders")

#define KEY_FLOW_SKIP_SSLVERIFY					_T("Flow SSL Peer Verification")

#define KEY_SSL_CERT_STORES						_T("SSL Certificate Stores")

#define KEY_FLOW_ID_LOOKUP_CACHE_LIMIT			_T("Flow ID Lookup Cache Limit")

#define KEY_FLOW_PASSWORD_COLUMN				_T("Flow Password Hash Column")

#define KEY_DIFF_SYNC_WATER_MARK				_T("Differential Sync Water Mark")

#define	KEY_FLOW_SUB_FOLDER_SUPPORT				_T("Flow Subfolder Support")

#define	KEY_FLOW_LOGO_PATH						_T("Flow Logos Path")

#define KEY_ENABLE_CRASH_DUMP					_T("Crash Dump Enable")
#define KEY_CRASH_DUMP_DIRECTORY				_T("Crash Dump Directory")

#define KEY_WORKLIST_COUNT						_T("Max Worklist Docs")
#define KEY_UID_LOGIN_TYPE						_T("UID Login Type")

#define KEY_SAML_ARTIFACT_URL					_T("SAML Artifact URL")
#define KEY_SAML_PROXY_URL						_T("SAML Proxy URL")
#define KEY_SAML_KEY_FILE						_T("SAML Key File")
#define KEY_SAML_ENDPOINT						_T("SAML Endpoint")
#define KEY_SAML_RP								_T("SAML Rp")
#define KEY_SAML_ATTRIBUTE						_T("SAML Attribute")
#define KEY_SAML_RELYINGPARTY					_T("SAML RelyingParty")

#define	KEY_ENABLE_IMPLICIT_AUDIT_TRAIL			_T("Enable Implicit Audit Trail")
#define KEY_INDEXER_DREDATETIME					_T("Indexer DREDateTime")

#define KEY_DOC_PREVIEW_ENGINE_URL				_T("Document Preview Engine URL")
#define KEY_DOC_PREVIEW_PROVIDER				_T("Document Preview Provider")
#define KEY_SMTP_SERVER_URL						_T("SMTP Server URL")
#define KEY_SMTP_MAIL_FROM_ADDRESS				_T("SMTP Mail From Address")
#define KEY_SMTP_REPLY_TO_ADDRESS				_T("SMTP Reply-To Address")
#define KEY_SMTP_REPLY_TO_DISPLAY				_T("SMTP Reply-To Display")
#define KEY_SMTP_USE_SSL						_T("SMTP Use SSL")
#define KEY_FILE_TO_FOLDER						_T("File To Folder")
#define KEY_TRUSTED_PROXIES_LIST				_T("Trusted Proxies List")
#define KEY_USAGE_TRACKING						_T("Usage Tracking")
#define KEY_DEFAULT_EMAIL_FOLDER				_T("Default Email Folder")
#define KEY_PERSONAL_SEARCH_WS_COUNT			_T("Personal Search Workspace Count")

#define KEY_IOS_POLICY							_T("iOS Policy")
#define KEY_HTML5_POLICY_PREVENT_DATA_LEAKAGE	_T("HTML5 Policy Prevent Data Leakage")
#define KEY_HTML5_POLICY_GROUP_ACCESS_LIST		_T("HTML5 Policy Group Access List")

#define KEY_ALLOW_IWL							_T("Allow IWL")

#define	KEY_ENABLE_PIPED_UPLOAD					_T("Enable Enhanced Upload")
#define	KEY_ENABLE_ENHANCED_DOWNLOAD			_T("Enable Enhanced Download")

#define	KEY_RENDER_BROKER_URL					_T("Render Broker URL")
#define	KEY_RENDER_QUEUE_NAME					_T("Render Queue Name")
#define	KEY_RENDER_EXPIRE_IN_SEC				_T("Render Time To Expire")
#define	KEY_RENDER_PERSIST_MSG					_T("Render Persist Msg")
#define	KEY_RENDER_CACHE_HOST					_T("Render Cache Host")
#define	KEY_RENDER_BROKER_LOGIN					_T("Render Broker Login")
#define	KEY_RENDER_BROKER_KEY					_T("Render Broker Key")
#define	KEY_RENDER_POOL_SIZE					_T("Render Pool Size")
#define	KEY_MSS_HOST							_T("MSH Host")
#define	KEY_DMS_RSA_KEY							_T("RSA Key")
#define	KEY_PREVIEW_CACHE_RETENTION_PERIOD		_T("Preview Cache Retention Period")
#define	KEY_OLE_DOCTYPES						_T("OLE Doc Types")

#define KEY_RABBITMQ_LOG						_T("RabbitMQ Log")

#define KEY_OCR_DISCOVERY_TYPES					_T("Discovery Types")
#define	KEY_OCR_COPY_FILE_CREATE_MODIFY_DATE	_T("Discovery Copy File Create Modify Date")
#define	KEY_OCR_REPLACE_FOR_NEW_VERSION			_T("Discovery Replace For New Version")

#define KEY_REST_ORIGIN_WHITE_LIST				_T("Origin White List")
#define KEY_IDLE_SOCKET_TIMEOUT					_T("Idle Socket Timeout")

#define	KEY_ENABLE_AUDIT_JOURNAL				_T("Enable Audit Journal")
#define KEY_ENABLE_TRASH						_T("Enable Trash")
#define	KEY_AUDIT_JOURNAL_RETENTION_PERIOD		_T("Audit Journal Retention Period")

#define	KEY_REDIS_HOST							_T("Redis Host")
#define	KEY_REDIS_PORT							_T("Redis Port")
#define	KEY_REDIS_CONNECTION_COUNT				_T("Redis Connection Count")
#define	KEY_REDIS_SENTINEL_CLUSTER_NAME			_T("Redis Sentinel Cluster Name")
#define	KEY_WORK_GRANT_TOKEN_EXPIRY				_T("Work Grant Token Expiry")
#define	KEY_WORK_BEARER_TOKEN_MAX_INACTIVITY	_T("Work Bearer Token Max Inactivity")
#define	KEY_WORK_MASTER_TOKEN_MAX_INACTIVITY	_T("Work Master Token Max Inactivity")


using namespace IM;


const char* cpDMSLogFilePath = ".\\DmsLog.txt";
const char* cpIdxSrchLogFilePath = ".\\IndxSrchLog.txt";
const char* cpIdxMgrLogFilePath = ".\\IndxMgrLog.txt";
const char* cpCMSLogFilePath = ".\\CmsLog.txt";
const char* cpIdxAgntLogFilePath = ".\\IndxAgntLog.txt";
const char* cpIndexerFilesPath = ".\\Verity";
//const char* cpFmaLogFilePath = ".\\FmaLog.txt";
const char* cpKMIdxLogFilePath = ".\\KMIdxLog.txt";
const char* cpDRESecurityLogFilePath = ".\\imDRESecurityLog.txt";
const char* cpRenderLogFilePath  = ".\\imRenderingSvcLog.txt";

//
//		Document Service registry management
//

DmsServiceConfiguration::DmsServiceConfiguration(const TCHAR *szComputerName_) :
	ServiceConfiguration(szComputerName_, KEY_DMSSVC_PATH, SZ_DMSSVC_NAME)
{
	m_strServiceDisplayName = SZ_DMSSVC_DISPLAY_NAME;
	m_strServiceScmName = SZ_DMSSVC_SCM_NAME;
	InitDMSConfiguration();
}

DmsServiceConfiguration::DmsServiceConfiguration(const TCHAR *szComputerName_,
	const TCHAR *strServicePath,
	const TCHAR *strServiceName,
	const TCHAR *strServiceDispName,
	const TCHAR *strServiceScmName)
	:ServiceConfiguration(szComputerName_, strServicePath, strServiceName)
{
	m_strServiceDisplayName = strServiceDispName;
	m_strServiceScmName = strServiceScmName;
	InitDMSConfiguration();
}

void
DmsServiceConfiguration::InitDMSConfiguration()
{
	m_strImpersonationPassword.SetEncryptFlag(true);
	m_lEnforceKerberos.Set(1);

	// general properies
	m_strLogPath.Set(NrCiString(cpDMSLogFilePath));
	m_strLogPath.SetServerOnlyFlag(true);
	m_lThreadCount.Set(10);

	// data cache management defaults
	m_bPreloadCache.Set(true);
	m_lCacheUpdateFrequency.Set(60);
	m_lCacheRowCount.Set(10);

	// RPC and file transfer port defaults
	m_bGivenServicePort.Set(true);
	m_lServicePort.Set(1080);
	//m_lServicePort.SetServerOnlyFlag(true);

	m_bGivenFilePort.Set(false);
	m_lFilePort.Set(0);
	m_lFilePort.SetServerOnlyFlag(true);

	m_bBackwardsCompatibleAccess.Set(false);

	m_bAuthenticateWebDb.Set(false);

	m_bCaseInsensitiveOracle.Set(false);

	m_lSecureValidatedFieldsMask.Set(0);

	m_bAciInitEncryption.Set(true);

	m_lSecurityModel.Set(0);
	m_bGovernEnabled.Set(false);

	m_bAddEmailsToWorklist.Set(true);
	m_lServerSideDuplicateDetectionType.Set(0);
	m_bAddMailBoxSyncQueue.Set(false);

	m_bDocCacheEnabled.Set(false);
	m_strDocCacheFilePath.SetServerOnlyFlag(true);
	m_strDocCacheFilePathOS.Set(_T("3"));
	m_strDocCacheRootPath.Set(_T("\\CacheServer"));
	m_strDocCacheRootPath.SetServerOnlyFlag(true);
	m_strDocCacheAccessMethod.Set(_T("%A%D%V"));
	m_lDocCacheUploadWaitTime.Set(60);
	//Secure doc cache location for HIPAA
	m_strSecureDocCacheFilePath.SetServerOnlyFlag(true);
	m_strSecureDocCacheFilePathOS.Set(_T("3"));
	m_strSecureDocCacheRootPath.Set(_T("\\SecureCacheServer"));
	m_strSecureDocCacheRootPath.SetServerOnlyFlag(true);
	m_strSecureDocCacheAccessMethod.Set(_T("%A%D%V"));

	m_bLogEventsInServer.Set(false);

	m_strDefaultDocClass.Set(_T("DOC"));

	m_strEmailTypes.Set(_T("MIME,GW,NOTES,EML"));
	m_strPDFTypes.Set(_T("ACROBAT,OCR"));
	m_bImportEmailsAsDeclared.Set(false);
	m_bMaxDocNumIncreaseOnSupervisedImport.Set(1);

	m_lKludgeRetainExtANSI.Set(false);
	m_lKludgeRetainExtNonEmail.Set(false);

	m_bWFMEnabled.Set(false);
	m_strWFMServerAddress.Set(_T(""));
	m_strWFMServerAddress.SetServerOnlyFlag(true);

	m_bBackgroundJobsEnabled.Set(false);
	m_lBackgroundJobsThreadTimeout.Set(30);
	m_bBackgroundJobsClusterEnabled.Set(true);
	m_lBackgroundJobsDocumentChunkSize.Set(500);
	m_lBackgroundJobsFolderChunkSize.Set(10);
	m_lBackgroundJobsWorkspaceChunkSize.Set(1);
	
	m_bSevEnabled.Set(false);
	m_strSevServerAddress.Set(_T(""));
	m_strSevServerAddress.SetServerOnlyFlag(true);
	m_lReconcileUserId.Set(_T(""));
	m_lReconcileUserId.SetServerOnlyFlag(true);
	m_strSevServerAddress.SetServerOnlyFlag(true);
	m_lReconcileThreadTimeOut.Set(1200);
	m_lReconcileRetry.Set(10);
	m_lDownloadFileRetry.Set(5);

	m_bSevNotesEnabled.Set(false);
	m_strSevNotesIdPath.Set(_T(""));
	m_strSevNotesIdPath.SetServerOnlyFlag(true);
	m_strSevNotesIdPassword.Set(_T(""));
	m_strSevNotesIdPassword.SetEncryptFlag( true );
	m_strSevNotesTemplatePath.Set(_T(""));
	m_strSevNotesTemplatePath.SetServerOnlyFlag(true);
	m_strSevNotesTempDBPath.Set(_T("SevNotesTempDB.nsf"));
	m_strSevNotesTempDBPath.SetServerOnlyFlag(true);
	m_strSevNotesTypeAlias.Set(_T("NOTES"));

	m_bEasEnabled.Set(false);
	m_strEasServerAddress.Set(_T(""));
	m_strEasServerAddress.SetServerOnlyFlag(true);
	m_strEasReconcileUserId.Set(_T(""));
	m_strEasReconcileUserId.SetServerOnlyFlag(true);
	m_lEasReconcileThreadTimeOut.Set(1200);
	m_lEasReconcileRetry.Set(10);
	m_lEasDownloadFileRetry.Set(5);
	m_strEasAppUrl.Set(_T("eas_app/easweb.dll"));
	m_strEasAppUrl.SetServerOnlyFlag(true);
	m_strEasAdminUserId.Set(_T(""));
	m_strEasAdminUserId.SetServerOnlyFlag(true);
	m_strEasAdminPassword.Set(_T(""));
	m_strEasAdminPassword.SetEncryptFlag( true );
	m_strAdditionalEmailStubClasses.Set(_T(""));

	m_bAcaEnabled.Set(false);
	m_strAcaServerEndPoint.Set(_T(""));
	m_strAcaServerEndPoint.SetServerOnlyFlag(true);

	//FMA Client reply ports
	m_lFMAClientReplyPort.Set(2638);
	m_lFMAClientReplyPort.SetServerOnlyFlag(true);
	m_lFMAClientNumberOfReplyPorts.Set(1);

	//Hosted DM Configuration
	m_bHostedDMEnabled.Set(false);
	m_lHostedServicePort.Set(1090);
	m_lHostedServicePort.SetServerOnlyFlag(true);
	m_lHostedFilePort.Set(1091);
	m_lHostedFilePort.SetServerOnlyFlag(true);
	m_lHostedSessionTimeOut.Set(600);
	m_bHostedSSLEnabled.Set(false);
	m_bUseSSLCompression.Set(false);
	m_strHostedSSLCACertPath.Set(_T(""));
	m_strHostedSSLCACertPath.SetServerOnlyFlag(true);
	m_strHostedSSLKeyFilePath.Set(_T(""));
	m_strHostedSSLKeyFilePath.SetServerOnlyFlag(true);
	m_strHostedSSLKeyFilePassword.Set(_T(""));
	m_strHostedSSLKeyFilePassword.SetEncryptFlag(true);
	m_strHostedSSLKeyFilePassword.SetServerOnlyFlag(true);
	m_strHostedSSLCiphers.Set(_T("ALL:!aNULL:!ADH:!eNULL:!LOW:!EXP:RC4+RSA:+HIGH:+MEDIUM:!IDEA"));
	m_bDisableSSLv2.Set(true);
	m_bDisableSSLv2.SetServerOnlyFlag(true);
	m_bDisableSSLv3.Set(true);
	m_bDisableSSLv3.SetServerOnlyFlag(true);
	m_bDisableTLSv1.Set(false);
	m_bDisableTLSv1.SetServerOnlyFlag(true);
	m_bDisableTLSv1_1.Set(false);
	m_bDisableTLSv1_1.SetServerOnlyFlag(true);
	m_bDisableTLSv1_2.Set(false);
	m_bDisableTLSv1_2.SetServerOnlyFlag(true);
	m_strHostedSSLCiphers.SetServerOnlyFlag(true);
	m_lHostedTrustedLoginType.Set(0);
	m_strHostedTrustedLoginServer.Set (_T(""));
	m_strHostedTrustedLoginServer.SetServerOnlyFlag(true);
	m_strHostedTrustedLoginSSL.Set(false);
	m_strHostedTrustedLoginPort.Set(0);
	m_strHostedTrustedLoginPort.SetServerOnlyFlag(true);
	m_bEnableNetworkLogin.Set(true);

	m_bAllowDescFullTextSearch.Set(true);
	m_bUseSystemDates.Set(true);
	m_bAdvancedServer.Set(false);
	m_bHpFlowServer.Set(false);

	m_lMaxXQ.Set(15000);
	m_lMaxQD.Set(4500);
	m_lSleepPerBackgroundSession.Set(1000);
	m_bServerSideDuplicateDetection.Set(false);
	m_strHipaaTempDirectory.Set(_T(""));
	m_strHipaaTempDirectory.SetServerOnlyFlag(true);
	m_strIpv6MulticastAddress.Set (_T("ff15::1"));
	m_strIpv6MulticastAddress.SetServerOnlyFlag(true);
	m_lFolderFTSearchMultiplier.Set(1);

	//
	m_bUseSessionLocaleForTranslation.Set(false);

	m_bAllowUnicodeData.Set(false);
	m_lMaxMarkedFolders.Set(1000);

	m_bResetComindexAndIndexedOnUpdate.Set(false);

	m_bFlowSSLPeerVerify.Set(true);
	m_strSslCertStores.Set(_T("Root"));
	m_strSslCertStores.SetServerOnlyFlag(true);
	m_lFlowIDLookupCacheLimit.Set(100000);
	m_strFlowPasswordColumn.Set(_T("CUSTOM1"));
	m_strFlowPasswordColumn.SetServerOnlyFlag(true);
	m_lDiffSyncWaterMark.Set(512000); //500 kb
	m_lFlowSubFolderSupport.Set(1);
	m_strFlowLogosPath.Set(_T(".\\Logos\\"));

	m_bCreateCrashDump.Set(true);
	m_bCreateCrashDump.SetServerOnlyFlag(true);
	m_strCrashDumpDirectory.Set(_T(""));
	m_strCrashDumpDirectory.SetServerOnlyFlag(true);
	m_strIndexerFiles.SetServerOnlyFlag(true);
	m_bImplicitAuditSupport.Set(false);
	m_bImplicitAuditSupport.SetServerOnlyFlag(true);
	m_bPipedUpload.Set(true);
	m_bPipedUpload.SetServerOnlyFlag(true);
	m_bEnhancedDownload.Set(false);
	m_bEnhancedDownload.SetServerOnlyFlag(true);

	m_lMaxWorklistDocs.Set(40);
	m_lUidLoginType.Set(3);

	m_strSamlAttribute.Set(_T("http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name"));
	m_strSamlAttribute.SetServerOnlyFlag(true);
	m_strSAMLArtUrl.Set(_T(""));
	m_strSAMLArtUrl.SetServerOnlyFlag(true);
	m_strSamlProxyUrl.Set(_T(""));
	m_strSamlProxyUrl.SetServerOnlyFlag(true);
	m_strSamlKeyFile.Set(_T(""));
	m_strSamlKeyFile.SetServerOnlyFlag(true);
	m_strSamlEndpoint.Set(_T(""));
	m_strSamlEndpoint.SetServerOnlyFlag(true);
	m_strSamlRp.Set(_T(""));
	m_strSamlRp.SetServerOnlyFlag(true);
	m_strSamlRelyingParty.Set(_T("logintoRp"));
	m_strSamlRelyingParty.SetServerOnlyFlag(true);
	m_bIndexDreDateTime.Set(false);

	m_strDocPreviewEngineURL.Set(_T(""));
	m_strDocPreviewEngineURL.SetServerOnlyFlag(true);
	m_lDocPreviewProvider.Set(1);
	m_strSmtpServerURL.Set(_T(""));
	m_strSmtpServerURL.SetServerOnlyFlag(true);
	m_strSmtpMailFromAddress.Set(_T(""));
	m_strSmtpMailFromAddress.SetServerOnlyFlag(true);
	m_strSmtpReplyToAddress.Set(_T(""));
	m_strSmtpReplyToAddress.SetServerOnlyFlag(true);
	m_strSmtpReplyToDisplay.Set(_T(""));
	m_strSmtpReplyToDisplay.SetServerOnlyFlag(true);
	m_bSmtpUseSSL.Set(false);
	m_strFileToFolder.Set(_T("CC"));
	m_strTrustedProxiesList.Set(_T(""));
	m_strUsageTracking.Set(_T(""));
    m_strDefaultEmailFolder.Set(_T("E-mails"));
	m_lPersonalSearchWSCount.Set(5);

	m_strHTML5PolicyPreventDataLeakage.Set(_T("low"));
	m_strHTML5PolicyGroupAccessList.Set(_T(""));
	m_striOSPolicy.Set(_T("{\"data\":{\"managed_only\":false}}"));

	m_bAllowIWL.Set(false);

	m_strOLEDocTypes.Set(_T("WORD,WORDX,WORDXT,EXCEL,EXCELX,PPT,PPTX"));
	m_bRabbitMqLog.Set(false);
	
	m_strRenderBrokerURL.Set(_T(""));
	m_strRenderBrokerURL.SetServerOnlyFlag(true);
	m_strRenderDestination.Set(_T("Q.RENDER.REQS"));
	m_strRenderRespDestination.Set(_T("Q.DMS.RENDER.RESP"));
	m_bRenderUseTopic.Set(false);
	m_bRenderSessTransacted.Set(true);
	m_lRenderMsgExpireInSec.Set(60 * 60 * 1000); //1 hour
	m_bRenderPersistMsg.Set(false);
	m_strRenderCacheHost.Set(_T("localhost"));
	m_strRenderCacheHost.SetServerOnlyFlag(true);
	m_strRenderBrokerLogin.Set(_T(""));
	m_strRenderBrokerLogin.SetServerOnlyFlag(true);
	m_strRenderBrokerKey.Set(_T(""));
	m_strRenderBrokerKey.SetServerOnlyFlag(true);
	m_lRenderPoolSize.Set(10);
	m_strMSSHost.Set(_T(""));
	m_strDMSRsaKey.Set(_T(""));
    m_strDMSRsaKey.SetServerOnlyFlag(true);

	m_lDaysToRetainPreviewCache.Set(30);

	m_strDiscoveryTypes.Set(_T("GIF,BMP,TIFF,BMP,ACROBAT,JPEG"));
	m_bOcrCopyFileCreateAndModifyDate.Set(true);
	m_bOcrReplaceForNewVersion.Set(false);

	m_strRestOriginWhiteList.Set(_T(""));

	m_lIdleSocketTimeout.Set(15);

	m_bAuditJournalEnabled.Set(false);
	m_bTrashEnabled.Set(false);
	m_lDaysToRetainAuditJournal.Set(0);

	m_strRedisHost.Set(_T("localhost"));
	m_strRedisHost.SetServerOnlyFlag(true);
	m_lRedisPort.Set(6379);
	m_lRedisPort.SetServerOnlyFlag(true);
	m_lRedisConnectionCount.Set(251);
	m_lRedisConnectionCount.SetServerOnlyFlag(true);
	m_strRedisSentinelClusterName.Set(_T(""));
	m_strRedisSentinelClusterName.SetServerOnlyFlag(true);
	m_lGrantTokenExpiryInSec.Set(5);
	m_lGrantTokenExpiryInSec.SetServerOnlyFlag(true);
	m_lBearerTokenMaxInactivityInSec.Set(4 * 60 * 60);
	m_lBearerTokenMaxInactivityInSec.SetServerOnlyFlag(true);
	m_lMasterTokenMaxInactivityInSec.Set(12 * 60 * 60);
	m_lMasterTokenMaxInactivityInSec.SetServerOnlyFlag(true);

	// load registry properties in map
	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEXER_DREDATETIME, &m_bIndexDreDateTime));

	m_propertyMap.insert(PropertyMap::value_type(KEY_MAX_MARKED_FOLDERS, &m_lMaxMarkedFolders));
	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEXER_PATH, &m_strIndexerFiles));

	m_propertyMap.insert(PropertyMap::value_type(KEY_CLUSTER_NAME, &m_strClusterName));
	m_propertyMap.insert(PropertyMap::value_type(KEY_THREAD_COUNT, &m_lThreadCount));
	m_propertyMap.insert(PropertyMap::value_type(KEY_DOCNUM_INCREASE, &m_bMaxDocNumIncreaseOnSupervisedImport));
	m_propertyMap.insert(PropertyMap::value_type(KEY_TRUSTED_LOGON, &m_bTrustedLogon));
	m_propertyMap.insert(PropertyMap::value_type(KEY_ENFORCE_KERBEROS, &m_lEnforceKerberos));

	m_propertyMap.insert(PropertyMap::value_type(KEY_GIVEN_SVC_PORT, &m_bGivenServicePort));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SVC_PORT, &m_lServicePort));
	m_propertyMap.insert(PropertyMap::value_type(KEY_GIVEN_FILE_PORT, &m_bGivenFilePort));
	m_propertyMap.insert(PropertyMap::value_type(KEY_FILE_PORT, &m_lFilePort));

	m_propertyMap.insert(PropertyMap::value_type(KEY_PRELOAD_CACHE, &m_bPreloadCache));
	m_propertyMap.insert(PropertyMap::value_type(KEY_CACHE_REFRESH, &m_lCacheUpdateFrequency));
	m_propertyMap.insert(PropertyMap::value_type(KEY_CACHE_ROWS, &m_lCacheRowCount));

	m_propertyMap.insert(PropertyMap::value_type(KEY_SHARED_CM, &m_bSharedCMCache));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SHARED_CM_DB, &m_strCMDatabase));

	m_propertyMap.insert(PropertyMap::value_type(KEY_BACKWARDS_COMPATIBLE_ACCESS, &m_bBackwardsCompatibleAccess));

	m_propertyMap.insert(PropertyMap::value_type(KEY_IMPERSONATION_ENABLED, &m_bImpersonationEnabled));
	m_propertyMap.insert(PropertyMap::value_type(KEY_IMPERSONATION_PASSWORD, &m_strImpersonationPassword));

	m_propertyMap.insert(PropertyMap::value_type(KEY_FMA_CLIENT_REPLY_PORT, &m_lFMAClientReplyPort));
	m_propertyMap.insert(PropertyMap::value_type(KEY_FMA_CLIENT_NUM_REPLY_PORTS, &m_lFMAClientNumberOfReplyPorts));

	m_propertyMap.insert(PropertyMap::value_type(KEY_HOSTED_DM_ENABLED, &m_bHostedDMEnabled));
	m_propertyMap.insert(PropertyMap::value_type(KEY_HOSTED_SERVICE_PORT, &m_lHostedServicePort));
	m_propertyMap.insert(PropertyMap::value_type(KEY_HOSTED_FILE_PORT, &m_lHostedFilePort));
	m_propertyMap.insert(PropertyMap::value_type(KEY_HOSTED_SESSION_TIMEOUT, &m_lHostedSessionTimeOut));
	m_propertyMap.insert(PropertyMap::value_type(KEY_HOSTED_SSL_ENABLED, &m_bHostedSSLEnabled));
	m_propertyMap.insert(PropertyMap::value_type(KEY_USE_SSL_COMPRESSION, &m_bUseSSLCompression));
	m_propertyMap.insert(PropertyMap::value_type(KEY_HOSTED_SSL_CA_CERT_PATH, &m_strHostedSSLCACertPath));
	m_propertyMap.insert(PropertyMap::value_type(KEY_HOSTED_SSL_KEY_FILE_PATH, &m_strHostedSSLKeyFilePath));
	m_propertyMap.insert(PropertyMap::value_type(KEY_HOSTED_SSL_KEY_FILE_PASSWORD, &m_strHostedSSLKeyFilePassword));
	m_propertyMap.insert(PropertyMap::value_type(KEY_HOSTED_SSL_CIPHERS, &m_strHostedSSLCiphers));
	m_propertyMap.insert(PropertyMap::value_type(KEY_HOSTED_DISABLESSLV2, &m_bDisableSSLv2));
	m_propertyMap.insert(PropertyMap::value_type(KEY_HOSTED_DISABLESSLV3, &m_bDisableSSLv3));
	m_propertyMap.insert(PropertyMap::value_type(KEY_HOSTED_DISABLETLSV1, &m_bDisableTLSv1));
	m_propertyMap.insert(PropertyMap::value_type(KEY_HOSTED_DISABLETLSV1_1, &m_bDisableTLSv1_1));
	m_propertyMap.insert(PropertyMap::value_type(KEY_HOSTED_DISABLETLSV1_2, &m_bDisableTLSv1_2));

	m_propertyMap.insert(PropertyMap::value_type(KEY_HOSTED_HTTPS_AUTHN_SERVERTYPE, &m_lHostedTrustedLoginType));
	m_propertyMap.insert(PropertyMap::value_type(KEY_HOSTED_HTTPS_AUTHN_SERVERNAME, &m_strHostedTrustedLoginServer));
	m_propertyMap.insert(PropertyMap::value_type(KEY_HOSTED_HTTPS_AUTHN_SSL, &m_strHostedTrustedLoginSSL));
	m_propertyMap.insert(PropertyMap::value_type(KEY_HOSTED_HTTPS_AUTHN_PORT, &m_strHostedTrustedLoginPort));
	m_propertyMap.insert(PropertyMap::value_type(KEY_ENABLE_NETWORK_LOGIN, &m_bEnableNetworkLogin));

	m_propertyMap.insert(PropertyMap::value_type(KEY_AUTHENTICATE_WEB_DB, &m_bAuthenticateWebDb));

	m_propertyMap.insert(PropertyMap::value_type(KEY_CASE_INSENSITIVE_ORACLE, &m_bCaseInsensitiveOracle));

	m_propertyMap.insert(PropertyMap::value_type(KEY_SECURE_VALIDATED_FIELDS_MASK, &m_lSecureValidatedFieldsMask));

	m_propertyMap.insert(PropertyMap::value_type(KEY_ACI_INIT_ENCRYPTION, &m_bAciInitEncryption));

	m_propertyMap.insert(PropertyMap::value_type(KEY_SECURITY_MODEL, &m_lSecurityModel));
	m_propertyMap.insert(PropertyMap::value_type(KEY_GOVERN_ENABLED, &m_bGovernEnabled));

	m_propertyMap.insert(PropertyMap::value_type(KEY_EMAIL_DOMAIN, &m_strEmailDomain));
	m_propertyMap.insert(PropertyMap::value_type(KEY_ADD_EMAILS_WORKLIST, &m_bAddEmailsToWorklist));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SERVER_SIDE_DUPLICATE_DETECTION_TYPE, &m_lServerSideDuplicateDetectionType));
	m_propertyMap.insert(PropertyMap::value_type(KEY_ADD_MAILBOXSYNC_QUEUE, &m_bAddMailBoxSyncQueue));

	m_propertyMap.insert(PropertyMap::value_type(KEY_DOCCACHE_ENABLED, &m_bDocCacheEnabled));
	m_propertyMap.insert(PropertyMap::value_type(KEY_DOCCACHE_FILEPATH, &m_strDocCacheFilePath));
	m_propertyMap.insert(PropertyMap::value_type(KEY_DOCCACHE_ROOTPATH, &m_strDocCacheRootPath));
	m_propertyMap.insert(PropertyMap::value_type(KEY_DOCCACHE_FILEPATH_OS, &m_strDocCacheFilePathOS));
	m_propertyMap.insert(PropertyMap::value_type(KEY_DOCCACHE_ACCESS_METHOD, &m_strDocCacheAccessMethod));
	m_propertyMap.insert(PropertyMap::value_type(KEY_DOCCACHE_UPLOAD_WAIT_TIME, &m_lDocCacheUploadWaitTime));
	//Secure Cache File Server JRAMANUJ-HIPAA
	m_propertyMap.insert(PropertyMap::value_type(KEY_SECURE_DOCCACHE_FILEPATH, &m_strSecureDocCacheFilePath));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SECURE_DOCCACHE_ROOTPATH, &m_strSecureDocCacheRootPath));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SECURE_DOCCACHE_FILEPATH_OS, &m_strSecureDocCacheFilePathOS));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SECURE_DOCCACHE_ACCESS_METHOD, &m_strSecureDocCacheAccessMethod));

	m_propertyMap.insert(PropertyMap::value_type(KEY_LOG_EVENTS_IN_SERVER, &m_bLogEventsInServer));

	m_propertyMap.insert(PropertyMap::value_type(KEY_DEFAULT_DOC_CLASS, &m_strDefaultDocClass));

	m_propertyMap.insert(PropertyMap::value_type(KEY_EMAIL_TYPES, &m_strEmailTypes));
	m_propertyMap.insert(PropertyMap::value_type(KEY_PDF_TYPES, &m_strPDFTypes));
	m_propertyMap.insert(PropertyMap::value_type(KEY_IMPORT_EMAILS_AS_DECLARED, &m_bImportEmailsAsDeclared));

	m_propertyMap.insert(PropertyMap::value_type(KEY_KLUDGE_RETAIN_EXT_ANSI, &m_lKludgeRetainExtANSI));
	m_propertyMap.insert(PropertyMap::value_type(KEY_KLUDGE_RETAIN_EXT_NON_EMAIL, &m_lKludgeRetainExtNonEmail));

	m_propertyMap.insert(PropertyMap::value_type(KEY_WFM_ENABLED, &m_bWFMEnabled));
	m_propertyMap.insert(PropertyMap::value_type(KEY_WFM_SERVER, &m_strWFMServerAddress));

	m_propertyMap.insert(PropertyMap::value_type(KEY_BACKGROUND_JOBS_ENABLED, &m_bBackgroundJobsEnabled));
	m_propertyMap.insert(PropertyMap::value_type(KEY_BACKGROUND_JOBS_THREAD_TIMEOUT, &m_lBackgroundJobsThreadTimeout));
	m_propertyMap.insert(PropertyMap::value_type(KEY_BACKGROUND_JOBS_CLUSTER_ENABLED, &m_bBackgroundJobsClusterEnabled));
	m_propertyMap.insert(PropertyMap::value_type(KEY_BACKGROUND_DOCUMENT_CHUNK_SIZE, &m_lBackgroundJobsDocumentChunkSize));
	m_propertyMap.insert(PropertyMap::value_type(KEY_BACKGROUND_FOLDER_CHUNK_SIZE, &m_lBackgroundJobsFolderChunkSize));
	m_propertyMap.insert(PropertyMap::value_type(KEY_BACKGROUND_WORKSPACE_CHUNK_SIZE, &m_lBackgroundJobsWorkspaceChunkSize));

	m_propertyMap.insert(PropertyMap::value_type(KEY_EMAIL_VAULT_ENABLED, &m_bSevEnabled));
	m_propertyMap.insert(PropertyMap::value_type(KEY_EMAIL_VAULT_SERVER, &m_strSevServerAddress));
	m_propertyMap.insert(PropertyMap::value_type(KEY_EMAIL_RECONCILE_RETRY, &m_lReconcileRetry));
	m_propertyMap.insert(PropertyMap::value_type(KEY_EMAIL_DOWNLOAD_FILE_RETRY, &m_lDownloadFileRetry));
	m_propertyMap.insert(PropertyMap::value_type(KEY_EMAIL_RECONCILE_THREAD_TIMEOUT, &m_lReconcileThreadTimeOut));
	m_propertyMap.insert(PropertyMap::value_type(KEY_EMAIL_RECONCILE_USERID, &m_lReconcileUserId));

	m_propertyMap.insert(PropertyMap::value_type(KEY_SEV_NOTES_ENABLED, &m_bSevNotesEnabled));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SEV_NOTES_ID_PATH, &m_strSevNotesIdPath));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SEV_NOTES_ID_PASSWORD, &m_strSevNotesIdPassword));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SEV_NOTES_TEMPLATE_PATH, &m_strSevNotesTemplatePath));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SEV_NOTES_TEMP_DB_PATH, &m_strSevNotesTempDBPath));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SEV_NOTES_TYPE_ALIAS, &m_strSevNotesTypeAlias));

	m_propertyMap.insert(PropertyMap::value_type(KEY_EAS_EMAIL_ENABLED, &m_bEasEnabled));
	m_propertyMap.insert(PropertyMap::value_type(KEY_EAS_EMAIL_SERVER, &m_strEasServerAddress));
	m_propertyMap.insert(PropertyMap::value_type(KEY_EAS_EMAIL_RECONCILE_USERID, &m_strEasReconcileUserId));
	m_propertyMap.insert(PropertyMap::value_type(KEY_EAS_EMAIL_RECONCILE_THREAD_TIMEOUT, &m_lEasReconcileThreadTimeOut));
	m_propertyMap.insert(PropertyMap::value_type(KEY_EAS_EMAIL_RECONCILE_RETRY, &m_lEasReconcileRetry));
	m_propertyMap.insert(PropertyMap::value_type(KEY_EAS_EMAIL_DOWNLOAD_FILE_RETRY, &m_lEasDownloadFileRetry));
	m_propertyMap.insert(PropertyMap::value_type(KEY_EAS_EMAIL_APPURL, &m_strEasAppUrl));
	m_propertyMap.insert(PropertyMap::value_type(KEY_EAS_EMAIL_ADMINUSERID, &m_strEasAdminUserId));
	m_propertyMap.insert(PropertyMap::value_type(KEY_EAS_EMAIL_ADMINPWD, &m_strEasAdminPassword));
	m_propertyMap.insert(PropertyMap::value_type(KEY_ADDITIONAL_EMAIL_STUB_CLASSES, &m_strAdditionalEmailStubClasses));

	m_propertyMap.insert(PropertyMap::value_type(KEY_ACA_EMAIL_ENABLED, &m_bAcaEnabled));
	m_propertyMap.insert(PropertyMap::value_type(KEY_ACA_EMAIL_SERVER, &m_strAcaServerEndPoint));

	m_propertyMap.insert(PropertyMap::value_type(KEY_ALLOW_DESC_FULLTEXT_SEARCH, &m_bAllowDescFullTextSearch));
	m_propertyMap.insert(PropertyMap::value_type(KEY_USE_SYSTEM_DATES, &m_bUseSystemDates));
	m_propertyMap.insert(PropertyMap::value_type(KEY_ADVANCED_SERVER, &m_bAdvancedServer));
	m_propertyMap.insert(PropertyMap::value_type(KEY_HPFLOW_SERVER, &m_bHpFlowServer));

	m_propertyMap.insert(PropertyMap::value_type(KEY_MAX_XQ, &m_lMaxXQ));
	m_propertyMap.insert(PropertyMap::value_type(KEY_MAX_QD, &m_lMaxQD));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SLEEP_PER_BACKGROUND_SESSION, &m_lSleepPerBackgroundSession));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SERVER_SIDE_DUPLICATE_DETECTION, &m_bServerSideDuplicateDetection));
	m_propertyMap.insert(PropertyMap::value_type(KEY_HIPAA_TEMP_DIRECTORY,&m_strHipaaTempDirectory ));
	// IPV6 support
	m_propertyMap.insert(PropertyMap::value_type(KEY_IPV6_MULTICASTADDRESS, &m_strIpv6MulticastAddress));
	//
	m_propertyMap.insert(PropertyMap::value_type(KEY_USE_SESSION_LOCALE_FOR_TRANSLATION, &m_bUseSessionLocaleForTranslation));
	m_propertyMap.insert(PropertyMap::value_type(KEY_ALLOW_UNICODE_DATA, &m_bAllowUnicodeData));
	m_propertyMap.insert(PropertyMap::value_type(KEY_FOLDER_FTSEARCH_MULTIPLIER, &m_lFolderFTSearchMultiplier));

	m_propertyMap.insert(PropertyMap::value_type(KEY_RESET_COMINDEX_AND_INDEXED_ON_UPDATE, &m_bResetComindexAndIndexedOnUpdate));

	m_propertyMap.insert(PropertyMap::value_type(KEY_FLOW_SKIP_SSLVERIFY, &m_bFlowSSLPeerVerify));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SSL_CERT_STORES, &m_strSslCertStores));
	m_propertyMap.insert(PropertyMap::value_type(KEY_FLOW_ID_LOOKUP_CACHE_LIMIT, &m_lFlowIDLookupCacheLimit));
	m_propertyMap.insert(PropertyMap::value_type(KEY_FLOW_PASSWORD_COLUMN, &m_strFlowPasswordColumn));
	m_propertyMap.insert(PropertyMap::value_type(KEY_DIFF_SYNC_WATER_MARK, &m_lDiffSyncWaterMark));
	m_propertyMap.insert(PropertyMap::value_type(KEY_FLOW_SUB_FOLDER_SUPPORT, &m_lFlowSubFolderSupport));
	m_propertyMap.insert(PropertyMap::value_type(KEY_FLOW_LOGO_PATH, &m_strFlowLogosPath));

	m_propertyMap.insert(PropertyMap::value_type(KEY_ENABLE_CRASH_DUMP, &m_bCreateCrashDump));
	m_propertyMap.insert(PropertyMap::value_type(KEY_CRASH_DUMP_DIRECTORY, &m_strCrashDumpDirectory));
	m_propertyMap.insert(PropertyMap::value_type(KEY_WORKLIST_COUNT, &m_lMaxWorklistDocs));
	m_propertyMap.insert(PropertyMap::value_type(KEY_UID_LOGIN_TYPE, &m_lUidLoginType));
	m_propertyMap.insert(PropertyMap::value_type(KEY_ENABLE_IMPLICIT_AUDIT_TRAIL, &m_bImplicitAuditSupport));
	m_propertyMap.insert(PropertyMap::value_type(KEY_ENABLE_PIPED_UPLOAD, &m_bPipedUpload));
	m_propertyMap.insert(PropertyMap::value_type(KEY_ENABLE_ENHANCED_DOWNLOAD, &m_bEnhancedDownload));

	m_propertyMap.insert(PropertyMap::value_type(KEY_SAML_ARTIFACT_URL, &m_strSAMLArtUrl));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SAML_PROXY_URL, &m_strSamlProxyUrl));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SAML_KEY_FILE, &m_strSamlKeyFile));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SAML_ENDPOINT, &m_strSamlEndpoint));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SAML_RP, &m_strSamlRp));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SAML_ATTRIBUTE, &m_strSamlAttribute));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SAML_RELYINGPARTY, &m_strSamlRelyingParty));

	m_propertyMap.insert(PropertyMap::value_type(KEY_DOC_PREVIEW_ENGINE_URL, &m_strDocPreviewEngineURL));
	m_propertyMap.insert(PropertyMap::value_type(KEY_DOC_PREVIEW_PROVIDER, &m_lDocPreviewProvider));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SMTP_SERVER_URL, &m_strSmtpServerURL));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SMTP_MAIL_FROM_ADDRESS, &m_strSmtpMailFromAddress));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SMTP_REPLY_TO_ADDRESS, &m_strSmtpReplyToAddress));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SMTP_REPLY_TO_DISPLAY, &m_strSmtpReplyToDisplay));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SMTP_USE_SSL, &m_bSmtpUseSSL));
	m_propertyMap.insert(PropertyMap::value_type(KEY_FILE_TO_FOLDER, &m_strFileToFolder));
	m_propertyMap.insert(PropertyMap::value_type(KEY_TRUSTED_PROXIES_LIST, &m_strTrustedProxiesList));
	m_propertyMap.insert(PropertyMap::value_type(KEY_USAGE_TRACKING, &m_strUsageTracking));
    m_propertyMap.insert(PropertyMap::value_type(KEY_DEFAULT_EMAIL_FOLDER, &m_strDefaultEmailFolder));
	m_propertyMap.insert(PropertyMap::value_type(KEY_PERSONAL_SEARCH_WS_COUNT, &m_lPersonalSearchWSCount));

	m_propertyMap.insert(PropertyMap::value_type(KEY_HTML5_POLICY_PREVENT_DATA_LEAKAGE, &m_strHTML5PolicyPreventDataLeakage));
	m_propertyMap.insert(PropertyMap::value_type(KEY_HTML5_POLICY_GROUP_ACCESS_LIST, &m_strHTML5PolicyGroupAccessList));
	m_propertyMap.insert(PropertyMap::value_type(KEY_IOS_POLICY, &m_striOSPolicy));

	m_propertyMap.insert(PropertyMap::value_type(KEY_ALLOW_IWL, &m_bAllowIWL));

	m_propertyMap.insert(PropertyMap::value_type(KEY_OLE_DOCTYPES, &m_strOLEDocTypes));
	m_propertyMap.insert(PropertyMap::value_type(KEY_RABBITMQ_LOG, &m_bRabbitMqLog));
	
	m_propertyMap.insert(PropertyMap::value_type(KEY_RENDER_BROKER_URL, &m_strRenderBrokerURL));
	m_propertyMap.insert(PropertyMap::value_type(KEY_RENDER_QUEUE_NAME, &m_strRenderDestination));
	m_propertyMap.insert(PropertyMap::value_type(KEY_RENDER_EXPIRE_IN_SEC, &m_lRenderMsgExpireInSec));
	m_propertyMap.insert(PropertyMap::value_type(KEY_RENDER_PERSIST_MSG, &m_bRenderPersistMsg));
	m_propertyMap.insert(PropertyMap::value_type(KEY_RENDER_CACHE_HOST, &m_strRenderCacheHost));
	m_propertyMap.insert(PropertyMap::value_type(KEY_RENDER_BROKER_LOGIN, &m_strRenderBrokerLogin));
	m_propertyMap.insert(PropertyMap::value_type(KEY_RENDER_BROKER_KEY, &m_strRenderBrokerKey));
	m_propertyMap.insert(PropertyMap::value_type(KEY_RENDER_POOL_SIZE, &m_lRenderPoolSize));
	m_propertyMap.insert(PropertyMap::value_type(KEY_MSS_HOST, &m_strMSSHost));
    m_propertyMap.insert(PropertyMap::value_type(KEY_DMS_RSA_KEY, &m_strDMSRsaKey));
    m_propertyMap.insert(PropertyMap::value_type(KEY_PREVIEW_CACHE_RETENTION_PERIOD, &m_lDaysToRetainPreviewCache));

	m_propertyMap.insert(PropertyMap::value_type(KEY_OCR_DISCOVERY_TYPES, &m_strDiscoveryTypes));
	m_propertyMap.insert(PropertyMap::value_type(KEY_REST_ORIGIN_WHITE_LIST, &m_strRestOriginWhiteList));
	m_propertyMap.insert(PropertyMap::value_type(KEY_IDLE_SOCKET_TIMEOUT, &m_lIdleSocketTimeout));

	m_propertyMap.insert(PropertyMap::value_type(KEY_ENABLE_AUDIT_JOURNAL, &m_bAuditJournalEnabled));
	m_propertyMap.insert(PropertyMap::value_type(KEY_ENABLE_TRASH, &m_bTrashEnabled));
	m_propertyMap.insert(PropertyMap::value_type(KEY_AUDIT_JOURNAL_RETENTION_PERIOD, &m_lDaysToRetainAuditJournal));

	m_propertyMap.insert(PropertyMap::value_type(KEY_OCR_COPY_FILE_CREATE_MODIFY_DATE, &m_bOcrCopyFileCreateAndModifyDate));
	m_propertyMap.insert(PropertyMap::value_type(KEY_OCR_REPLACE_FOR_NEW_VERSION, &m_bOcrReplaceForNewVersion));

	m_propertyMap.insert(PropertyMap::value_type(KEY_REDIS_HOST, &m_strRedisHost));
	m_propertyMap.insert(PropertyMap::value_type(KEY_REDIS_PORT, &m_lRedisPort));
	m_propertyMap.insert(PropertyMap::value_type(KEY_REDIS_CONNECTION_COUNT, &m_lRedisConnectionCount));
	m_propertyMap.insert(PropertyMap::value_type(KEY_REDIS_SENTINEL_CLUSTER_NAME, &m_strRedisSentinelClusterName));
	m_propertyMap.insert(PropertyMap::value_type(KEY_WORK_GRANT_TOKEN_EXPIRY, &m_lGrantTokenExpiryInSec));
	m_propertyMap.insert(PropertyMap::value_type(KEY_WORK_BEARER_TOKEN_MAX_INACTIVITY, &m_lBearerTokenMaxInactivityInSec));
	m_propertyMap.insert(PropertyMap::value_type(KEY_WORK_MASTER_TOKEN_MAX_INACTIVITY, &m_lMasterTokenMaxInactivityInSec));
}

void
DmsServiceConfiguration::GetRegistryMap(PropertyMap *&pPropertyMap_)
{
	pPropertyMap_ = &(m_propertyMap);
}

void 
DmsServiceConfiguration::GetConfigValue(const TCHAR* szName, IM::NrCiString& strValue_)
{
	strValue_ = _T("");
	try
	{
		if (GetValue(szName, strValue_) == false)
		{
			bool bValue = false;
			if (GetValue(szName, bValue) == true)
			{
				TCHAR szValue[2];
				szValue[0] = (bValue) ? 'Y' : 'N';
				szValue[1] = 0;
				strValue_ = szValue;
			}
			else
			{
				long lValue = 0;
				if (GetValue(szName, lValue) == true)
				{
					IM::NrString strValue = imstd::to_string(lValue).c_str();
					strValue_ = strValue.c_str();
				}
			}
		}
	}
	catch (std::exception &ex_)
	{
		LogMsg(LOG_ERROR, _T("DmsServiceConfiguration::GetConfigValue() - exception: %s"), ex_.what());
	}
}


//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	IndexManagerServiceConfiguration
//
//	Indexer Manager Service registry management
//
static TCHAR	*pattern[7][12] = {
{ TEXT("000"), TEXT("002"), TEXT("004"), TEXT("006"), TEXT("008"), TEXT("010"), TEXT("012"), TEXT("014"), TEXT("016"), TEXT("018"), TEXT("020"), TEXT("022")},
{ TEXT("100"), TEXT("102"), TEXT("104"), TEXT("106"), TEXT("108"), TEXT("110"), TEXT("112"), TEXT("114"), TEXT("116"), TEXT("118"), TEXT("120"), TEXT("122")},
{ TEXT("200"), TEXT("202"), TEXT("204"), TEXT("206"), TEXT("208"), TEXT("210"), TEXT("212"), TEXT("214"), TEXT("216"), TEXT("218"), TEXT("220"), TEXT("222")},
{ TEXT("300"), TEXT("302"), TEXT("304"), TEXT("306"), TEXT("308"), TEXT("310"), TEXT("312"), TEXT("314"), TEXT("316"), TEXT("318"), TEXT("320"), TEXT("322")},
{ TEXT("400"), TEXT("402"), TEXT("404"), TEXT("406"), TEXT("408"), TEXT("410"), TEXT("412"), TEXT("414"), TEXT("416"), TEXT("418"), TEXT("420"), TEXT("422")},
{ TEXT("500"), TEXT("502"), TEXT("504"), TEXT("506"), TEXT("508"), TEXT("510"), TEXT("512"), TEXT("514"), TEXT("516"), TEXT("518"), TEXT("520"), TEXT("522")},
{ TEXT("600"), TEXT("602"), TEXT("604"), TEXT("606"), TEXT("608"), TEXT("610"), TEXT("612"), TEXT("614"), TEXT("616"), TEXT("618"), TEXT("620"), TEXT("622")}
};

#define KEY_CHUNK_SIZE						TEXT("Chunk Size")
#define KEY_COLLECTION_SIZE					TEXT("Documents Per Collection")
#define KEY_VERSION_PER_DOC					TEXT("Versions Per Document")
#define KEY_INDEX_OPTIMIZE_EVER_NTH_TIME	TEXT("IndexOptimizeEveryNthTime")
#define KEY_MODE							TEXT("Mode")
#define KEY_SCHEDULE						TEXT("Schedule")
#define KEY_INDEX_SERVER					TEXT("Index Server")
	
IdxMgrServiceConfiguration::IdxMgrServiceConfiguration(const TCHAR *szComputerName_) :
	ServiceConfiguration(szComputerName_, KEY_IDXMGRSVC_PATH, SZ_IDXMGR_NAME)
{
	m_strServiceDisplayName = SZ_IDXMGR_DISPLAY_NAME;
	m_strServiceScmName = SZ_IDXMGR_SCM_NAME;

	//
	// Initialize defaults
	//

	m_strLogPath.Set(NrCiString(cpIdxMgrLogFilePath));

	// managed (SvcMgr) properties
	m_strRunMode = _T("C");
	for (int day = 0; day < 7; day++)
	{
		for (int hour = 0; hour < 12; hour++)
		{
			m_bScheduleTable[day][hour].Set(false);
		}
	}

	// internal properties thay may be overridden on special case basis
	m_lChunksize.Set(1000);
	m_lDocumentsPerCollection.Set(200000);
	m_strVersionsPerDoc.Set(_T("2.5"));
	m_lIndexOptimizeEveryNthTime.Set(20);
	m_strIndexServer.Set(_T(""));

	// load properties in map
	m_propertyMap.insert(PropertyMap::value_type(KEY_MODE, &m_strRunMode));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SCHEDULE, &m_strSchedule));

	m_propertyMap.insert(PropertyMap::value_type(KEY_CHUNK_SIZE, &m_lChunksize));
	m_propertyMap.insert(PropertyMap::value_type(KEY_COLLECTION_SIZE, &m_lDocumentsPerCollection));
	m_propertyMap.insert(PropertyMap::value_type(KEY_VERSION_PER_DOC, &m_strVersionsPerDoc));
	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEX_OPTIMIZE_EVER_NTH_TIME, &m_lIndexOptimizeEveryNthTime));
	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEX_SERVER, &m_strIndexServer));
}


void
IdxMgrServiceConfiguration::LoadFromRegistry()
{
	ServiceConfiguration::LoadFromRegistry();

	// process computed fields
	for (int day = 0; day < 7; day++)
	{
		for (int hour = 0; hour < 12; hour++)
		{
			if (m_strSchedule.Get().find(pattern[day][hour]) != -1)
				m_bScheduleTable[day][hour].Set(true);
		}
	}
}

void
IdxMgrServiceConfiguration::StoreInRegistry()
{
	NrCiString		strSchedule;

	// take computed fields and push data in registry property objects
	for (int day = 0; day < 7; day++)
	{
		for (int hour = 0; hour < 12; hour++)
		{
			if (m_bScheduleTable[day][hour].Get() == true)
			{
				strSchedule += pattern[day][hour];
				strSchedule += TEXT(", ");
			}
		}
	}

	m_strSchedule.Set(strSchedule);
	ServiceConfiguration::StoreInRegistry();
}


//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	IndexSearchServiceConfiguration
//
//	Indexer Manager Service registry management
//

	
IdxSearchServiceConfiguration::IdxSearchServiceConfiguration(const TCHAR *szComputerName_) :
	ServiceConfiguration(szComputerName_, KEY_IDXSCHSVC_PATH, SZ_IDXSCH_NAME)
{
	m_strServiceDisplayName = SZ_IDXSCH_DISPLAY_NAME;
	m_strServiceScmName = SZ_IDXSCH_SCM_NAME;

	// RPC and file transfer port defaults
	m_strLogPath.Set(NrCiString(cpIdxSrchLogFilePath));

	m_strClusterName.Set(_T(""));
	m_bGivenServicePort.Set(true);
	m_lServicePort.Set(1082);
	m_lThreadCount.Set(5l);

	m_propertyMap.insert(PropertyMap::value_type(KEY_CLUSTER_NAME,   &m_strClusterName));
	m_propertyMap.insert(PropertyMap::value_type(KEY_GIVEN_SVC_PORT, &m_bGivenServicePort));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SVC_PORT,		 &m_lServicePort));
	m_propertyMap.insert(PropertyMap::value_type(KEY_THREAD_COUNT, &m_lThreadCount));
}




//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	IndexManagerServiceConfiguration
//
//	Indexer Manager Service registry management
//

//
//	Indexer Manager service properties
//

#define KEY_LOG_PATH								TEXT("Log File Path")
#define KEY_LOG_FILTER								TEXT("Log Mask")
//#define KEY_INDEX_AGENT_PATH						TEXT("Temp Files Directory")

#define KEY_INDEX_FILTER_SEC_PER_MB					TEXT("FilterSecPerMB")
#define KEY_INDEX_FILTER_MIN_SEC_PER_MB				TEXT("FilterMinimumSecondsPerMB")

#define KEY_INDEX_INDEX_SEC_PER_MB					TEXT("IndexSecPerMB")
#define KEY_INDEX_INDEX_MIN_SEC_PER_MB				TEXT("IndexMinimumSecondsPerMB")

#define KEY_INDEX_DELETE_SEC_PER_DOC				TEXT("DeleteSecondsPerDoc")
#define KEY_INDEX_DELETE_MIN_SEC_PER_DOC			TEXT("DeleteMinimumSecondsPerDoc")

#define KEY_INDEX_SEARCH_MIN_SEC					TEXT("SearchMinSec")

#define KEY_INDEX_OPTIMIZE_EVER_NTH_TIME			TEXT("IndexOptimizeEveryNthTime")

#define KEY_INDEX_VERITY_MAXMEMORY					TEXT("VerityMaxMemory")
#define KEY_INDEX_VERITY_NUMPAGES					TEXT("VerityNumPages")

#define KEY_LOCALE									TEXT("Locale")
#define KEY_CHARACTER_SET							TEXT("Character Set")

#define KEY_SEARCH_COMMENTS_DESCRIPTION				TEXT("4.X Compatibility")


IdxAgentConfiguration::IdxAgentConfiguration(const TCHAR *szComputerName_, const TCHAR *szKeyPath_) : 
		RegistryMap(szComputerName_, HKEY_LOCAL_MACHINE, szKeyPath_)
{
	//
	// Initialize defaults
	//

	// install properties
	m_strLogPath.Set(NrCiString(cpIdxAgntLogFilePath));
	m_lLogMask.Set(LFO_ERROR | LFO_WARN | LFO_INFO | LFO_HEADER | LOG_ALL_DATA);

	m_strIndexerFiles.Set(NrCiString(cpIndexerFilesPath));

	// internal properties thay may be overridden on special case basis
	m_lFilterSecondsPerMB.Set(300);
	m_lFilterMinimumSecondsPerMB.Set(300);

	m_lIndexSecondsPerMB.Set(600);
	m_lIndexMinimumSecondsPerMB.Set(600);

	m_lDeleteSecondsPerDocument.Set(5);
	m_lDeleteMinimumSecondsPerDocument.Set(5);

	m_lSearchMinimumSeconds.Set(60);

	m_lVerityMaxMemory.Set(16384);
	m_lVerityNumPages.Set(16384);

	m_strLocale.Set(_T("englishx"));
	m_strCharacterSet.Set(_T(""));

	m_bSearchCommentsDescription.Set(false);

	// load properties in map
	m_propertyMap.insert(PropertyMap::value_type(KEY_LOG_PATH, &m_strLogPath));
	m_propertyMap.insert(PropertyMap::value_type(KEY_LOG_FILTER, &m_lLogMask));
	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEXER_PATH, &m_strIndexerFiles));

	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEX_FILTER_SEC_PER_MB, &m_lFilterSecondsPerMB));
	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEX_FILTER_MIN_SEC_PER_MB, &m_lFilterMinimumSecondsPerMB));

	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEX_INDEX_SEC_PER_MB, &m_lIndexSecondsPerMB));
	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEX_INDEX_MIN_SEC_PER_MB, &m_lIndexMinimumSecondsPerMB));

	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEX_DELETE_SEC_PER_DOC, &m_lDeleteSecondsPerDocument));
	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEX_DELETE_MIN_SEC_PER_DOC, &m_lDeleteMinimumSecondsPerDocument));

	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEX_SEARCH_MIN_SEC, &m_lSearchMinimumSeconds));

	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEX_VERITY_MAXMEMORY, &m_lVerityMaxMemory));
	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEX_VERITY_NUMPAGES, &m_lVerityNumPages));

	m_propertyMap.insert(PropertyMap::value_type(KEY_LOCALE, &m_strLocale));
	m_propertyMap.insert(PropertyMap::value_type(KEY_CHARACTER_SET, &m_strCharacterSet));

	m_propertyMap.insert(PropertyMap::value_type(KEY_SEARCH_COMMENTS_DESCRIPTION, &m_bSearchCommentsDescription));

}




//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	RulesServiceConfiguration
//
//	Rules Engine Service registry management
//
#define KEY_PROCESS_INT			_T("Interval Between Processing New Events")
#define KEY_MAINTENANCE_INT     _T("Maintenance Interval")
#define KEY_SMTP_SERVER			_T("SMTP Server")

RulesServiceConfiguration::RulesServiceConfiguration(const TCHAR *szComputerName_) :
	ServiceConfiguration(szComputerName_, KEY_RESVC_PATH, SZ_RESVC_NAME),
	m_handlerMap(szComputerName_, HKEY_LOCAL_MACHINE, KEY_REHANDLER_PATH)

{
	m_strServiceDisplayName = SZ_RESVC_DISPLAY_NAME;
	m_strServiceScmName = SZ_RESVC_SCM_NAME;

	m_lMaintenanceInterval.Set(7200);	// in seconds (default value 2 hours)
	m_strSmtpServer = _T("");
	m_lProcessInterval.Set(300);

	m_propertyMap.insert(PropertyMap::value_type(KEY_PROCESS_INT, &m_lProcessInterval));
	m_propertyMap.insert(PropertyMap::value_type(KEY_MAINTENANCE_INT, &m_lMaintenanceInterval));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SMTP_SERVER, &m_strSmtpServer));
}


RulesServiceConfiguration::~RulesServiceConfiguration()
{
}

void
RulesServiceConfiguration::LoadFromRegistry()
{
	ServiceConfiguration::LoadFromRegistry();

	m_handlerMap.LoadFromRegistry();
}

void
RulesServiceConfiguration::StoreInRegistry()
{
	ServiceConfiguration::StoreInRegistry();

	m_handlerMap.StoreInRegistry();
}



//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	FmaServiceConfiguration
//
//	FMA Service registry management
//
FmaServiceConfiguration::FmaServiceConfiguration(const TCHAR *szComputerName_) :
	ServiceConfiguration(szComputerName_, KEY_FMASVC_PATH, SZ_FMASVC_NAME)
{
	m_strServiceDisplayName = SZ_FMASVC_DISPLAY_NAME;
	m_strServiceScmName = SZ_FMASVC_SCM_NAME;

	// RPC and file transfer port defaults
//	m_strLogPath.Set(NrCiString(cpFmaLogFilePath));

}


//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	EFSServiceConfiguration
//
//	EFS Service registry management
//
EFSServiceConfiguration::EFSServiceConfiguration(const TCHAR *szComputerName_) :
	ServiceConfiguration(szComputerName_, KEY_EFSSVC_PATH, SZ_EFSSVC_NAME)
{
	m_strServiceDisplayName = SZ_EFSSVC_DISPLAY_NAME;
	m_strServiceScmName = SZ_EFSSVC_SCM_NAME;

	// RPC and file transfer port defaults
//	m_strLogPath.Set(NrCiString(cpFmaLogFilePath));

}


//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	CIFSServiceConfiguration
//
//	Interwoven WorkSite FileShare Service registry management
//
CIFSServiceConfiguration::CIFSServiceConfiguration(const TCHAR *szComputerName_) :
	ServiceConfiguration(szComputerName_, KEY_CIFSSVC_PATH, SZ_CIFSSVC_NAME)
{
	m_strServiceDisplayName = SZ_CIFSSVC_DISPLAY_NAME;
	m_strServiceScmName = SZ_CIFSSVC_SCM_NAME;
	m_strServiceScmDesc = SZ_CIFSSVC_SCM_DESC;
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	PrintRenditionServiceConfiguration
//
//	PrintRendition Service registry management
//
PrintRenditionServiceConfiguration::PrintRenditionServiceConfiguration(const TCHAR *szComputerName_) :
	ServiceConfiguration(szComputerName_, KEY_PRINTRENDSVC_PATH, SZ_PRINTRENDSVC_NAME)
{
	m_strServiceDisplayName = SZ_PRINTRENDSVC_DISPLAY_NAME;
	m_strServiceScmName = SZ_PRINTRENDSVC_SCM_NAME;

	// RPC and file transfer port defaults
	m_strLogPath.Set(NrCiString(cpRenderLogFilePath));

}

	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	RenderServiceConfiguration
//
//	Render Service registry management
//
RenderServiceConfiguration::RenderServiceConfiguration(const TCHAR *szComputerName_) :
	ServiceConfiguration(szComputerName_, KEY_RENDERSVC_PATH, SZ_RENDERSVC_NAME)
{
	m_strServiceDisplayName = SZ_RENDERSVC_DISPLAY_NAME;
	m_strServiceScmName = SZ_RENDERSVC_SCM_NAME;

	m_strClusterName.Set(_T(""));
	m_bGivenServicePort.Set(true);
	m_lServicePort.Set(4321);
	m_lThreadCount.Set(12);
	m_strServerAddress.Set(_T("localhost"));

	m_propertyMap.insert(PropertyMap::value_type(KEY_CLUSTER_NAME,   &m_strClusterName));
	m_propertyMap.insert(PropertyMap::value_type(KEY_GIVEN_SVC_PORT, &m_bGivenServicePort));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SVC_PORT,		 &m_lServicePort));
	m_propertyMap.insert(PropertyMap::value_type(KEY_THREAD_COUNT, &m_lThreadCount));
	m_propertyMap.insert(PropertyMap::value_type(KEY_RENDER_SERVER_ADDRESS, &m_strServerAddress));
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	IDXSVCConfiguration
//
//	WorkSite Indexer Service registry management
//

#define KEY_IDX_SVC_DEPLOYMENT_XML						TEXT("Deployment XML")
#define KEY_IDX_SVC_TYPE								TEXT("Indexer Type")

IDXSVCConfiguration::IDXSVCConfiguration(const TCHAR *szComputerName_) :
	ServiceConfiguration(szComputerName_, KEY_IDXSVC_PATH, SZ_IDXSVC_NAME)
{

	m_strDeploymentXML.Set(_T("deployment.xml"));
	m_lIdxSvcType.Set(0); // 0 = WorkSite Indexer; 1 = IUS

	m_propertyMap.insert(PropertyMap::value_type(KEY_IDX_SVC_TYPE, &m_lIdxSvcType));
	m_propertyMap.insert(PropertyMap::value_type(KEY_IDX_SVC_DEPLOYMENT_XML, &m_strDeploymentXML));

	LoadFromRegistry();

	long lIdxType = 0;
	if (GetValue(KEY_IDX_SVC_TYPE, lIdxType) == true)
	{
		if (lIdxType == 0)
		{
			m_strServiceDisplayName = SZ_IDXSVC_WS_IDXER_DISPLAY_NAME;
			m_strServiceScmName = SZ_IDXSVC_WS_IDXER_SCM_NAME;	
		}
		else
		{
			m_strServiceDisplayName = SZ_IDXSVC_IUS_DISPLAY_NAME;
			m_strServiceScmName = SZ_IDXSVC_IUS_SCM_NAME;	
		}
	}
	else
	{
		m_strServiceDisplayName = SZ_IDXSVC_WS_IDXER_DISPLAY_NAME;
		m_strServiceScmName = SZ_IDXSVC_WS_IDXER_SCM_NAME;	
	}
}

//
//----------------------------------------------------------------------------------------------------------------------
// WkDreServiceConfiguration Class
//----------------------------------------------------------------------------------------------------------------------
//
#define KEY_WKDRESVC_ENABLESECURITY				_T("Enable Security")
#define KEY_WKDRESVC_WSSNAME 					_T("WorkSite Server")
#define KEY_WKDRESVC_DREINIFILEPATH				_T("INI File Path")
#define KEY_WKDRESVC_WSSGIVENSERVICEPORT 		_T("Given Service Port")
#define KEY_WKDRESVC_WSSSERVICEPORT 			_T("Service Port")

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	WkDreServiceConfiguration
//
	WkDreServiceConfiguration::WkDreServiceConfiguration(
		const TCHAR *szComputerName_
	) :
		ServiceConfiguration(
			szComputerName_,
			KEY_WKDRESVC_PATH,
			SZ_WKDRESVC_NAME,
			SZ_WKDRESVC_DISPLAY_NAME,
			SZ_WKDRESVC_SCM_NAME
		),
		m_bWkEnable(false),
		m_strWorkSite(_T("")),
		m_strDreIniFilePath(_T("")),
		m_bWsSpecifyServicePort(false),
		m_lWsServicePort(1080)
{
	//
	// Note that the DRE attributes query port and index port are written to Autonomy's DRE.INI file. Therefore they
	// are not registerd as properties. At some point we may want to hoist this functionality to handle INI files as
	// well as registry settings. For now, it is implemented here as an exception to the rule.
	//
	m_propertyMap.insert(PropertyMap::value_type(KEY_WKDRESVC_DREINIFILEPATH, &m_strDreIniFilePath));
	m_propertyMap.insert(PropertyMap::value_type(KEY_WKDRESVC_ENABLESECURITY, &m_bWkEnable));
	m_propertyMap.insert(PropertyMap::value_type(KEY_WKDRESVC_WSSNAME, &m_strWorkSite));
	m_propertyMap.insert(PropertyMap::value_type(KEY_WKDRESVC_WSSGIVENSERVICEPORT, &m_bWsSpecifyServicePort));
	m_propertyMap.insert(PropertyMap::value_type(KEY_WKDRESVC_WSSSERVICEPORT, &m_lWsServicePort));
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	~WkDreServiceConfiguration
//
	WkDreServiceConfiguration::~WkDreServiceConfiguration()
{
	//
	// Intentionally left blank.
	//
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	LoadFromRegistry
//

void
WkDreServiceConfiguration::LoadFromRegistry()
{
	RegistryMap::LoadFromRegistry();

	// now load following settings from DRE.INI file
	m_lDreQueryPort.Set( GetPrivateProfileInt( _T( "SERVER" ), _T( "QUERYPORT" ), 2000, ( LPCTSTR ) m_strDreIniFilePath.Get().c_str() ) );
	m_lDreIndexPort.Set( GetPrivateProfileInt( _T( "SERVER" ), _T( "INDEXPORT" ), 2001, ( LPCTSTR ) m_strDreIniFilePath.Get().c_str() ) );
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	StoreInRegistry
//

void
WkDreServiceConfiguration::StoreInRegistry()
{
	RegistryMap::StoreInRegistry();

	TCHAR szQueryPort[ 16 ], szIndexPort[ 16 ];
	memset( szQueryPort, 0, 16 * sizeof( TCHAR ) );
	memset( szIndexPort, 0, 16 * sizeof( TCHAR ) );
	wsprintf( szQueryPort, _T( "%i" ), m_lDreQueryPort.Get( ) );
	wsprintf( szIndexPort, _T( "%i" ), m_lDreIndexPort.Get( ) );

	// now store following settings to DRE.INI file
	WritePrivateProfileString( _T( "SERVER" ), _T( "QUERYPORT" ), szQueryPort, ( LPCTSTR ) m_strDreIniFilePath.Get().c_str() );
	WritePrivateProfileString( _T( "SERVER" ), _T( "INDEXPORT" ), szIndexPort, ( LPCTSTR ) m_strDreIniFilePath.Get().c_str() );


	UINT uNumDbs = GetPrivateProfileInt( _T( "DATABASES" ), _T( "NUMDBS" ), 0, ( LPCTSTR ) m_strDreIniFilePath.Get().c_str() );

	for( UINT uIndex = 0; uIndex < uNumDbs; uIndex++ )
	{

		TCHAR szNum[ 8 ];
		memset( szNum, 8, 8 * sizeof( TCHAR ) );
		wsprintf( szNum, _T( "%u" ), uIndex );

		TCHAR szDatabase[ 32 ];
		memset( szDatabase, 0, 32 * sizeof( TCHAR ) );

		GetPrivateProfileString( _T( "DATABASES" ), szNum, _T(""), szDatabase, 31, ( LPCTSTR ) m_strDreIniFilePath.Get().c_str() );

		if( m_bWkEnable.Get( ) )
		{
			TCHAR szSecSection[ 32 ];
			memset( szSecSection, 0, 32 * sizeof( TCHAR ) );
			wsprintf( szSecSection, _T("%sSEC"), szDatabase );

			// write out two security sections
			WritePrivateProfileString( szDatabase, _T("SECURITY"), szSecSection, ( LPCTSTR ) m_strDreIniFilePath.Get().c_str() );
			
			WritePrivateProfileString( szSecSection, _T("LIBRARY"), _T("imDRESecurity.dll"), ( LPCTSTR ) m_strDreIniFilePath.Get().c_str() );
			WritePrivateProfileString( szSecSection, _T("DBName"), szDatabase, ( LPCTSTR ) m_strDreIniFilePath.Get().c_str() );
		}
		else
		{
			// delete the entire section
			WritePrivateProfileString( szDatabase, NULL, NULL, ( LPCTSTR ) m_strDreIniFilePath.Get().c_str() );

			// delete this section too
			TCHAR szSecSection[ 32 ];
			memset( szSecSection, 0, 32 * sizeof( TCHAR ) );
			wsprintf( szSecSection, _T("%sSEC"), szDatabase );

			WritePrivateProfileString( szSecSection, NULL, NULL, ( LPCTSTR ) m_strDreIniFilePath.Get().c_str() );
		}
	}
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	DeleteFromRegistry
//

void
WkDreServiceConfiguration::DeleteFromRegistry()
{
	RegistryMap::DeleteFromRegistry();

	// don't need to delete values from DRE.INI
}

	
//
//----------------------------------------------------------------------------------------------------------------------
// WkIndxrServiceConfiguration Class
//----------------------------------------------------------------------------------------------------------------------
//
#define KEY_WKINDXRSVC_DRE				_T("DRE")
#define KEY_WKINDXRSVC_LOCALSERVER		_T("Use Local Server")
#define KEY_WKINDXRSVC_CREATESUMMARY	_T("Create Document Summary")
#define KEY_WKINDXRSVC_STORECONTENT		_T("Store Document Content")
#define KEY_WKINDXRSVC_QUERYPORT		_T("Query Port")
#define KEY_WKINDXRSVC_INDEXPORT		_T("Index Port")
#define KEY_WKINDXRSVC_WORKSITE			_T("WorkSite Server")
#define KEY_WKINDXRSVC_CHUNKSIZE		_T("Chunk Size")
#define KEY_WKINDXRSVC_MODE				_T("Mode")
#define KEY_WKINDXRSVC_SCHEDULE			_T("Schedule")

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	WkIndxrServiceConfiguration
//
	WkIndxrServiceConfiguration::WkIndxrServiceConfiguration(
		const TCHAR *szComputerName_
	) :
		ServiceConfiguration(
			szComputerName_,
			KEY_WKINDXRSVC_PATH,
			SZ_WKINDXRSVC_NAME,
			SZ_WKINDXRSVC_DISPLAY_NAME,
			SZ_WKINDXRSVC_SCM_NAME
		),
		m_strDre(_T("")),
		m_bUseLocalServer(false),
		m_bCreateSummary(true),
		m_bStoreContent(false),
		m_lQueryPort(1083),
		m_lIndexPort(1084),
		m_strWorkSiteServer(_T("")),
		m_lChunkSize(1000),
		m_strRunMode(_T("C")),
		m_strSchedule(_T(""))
{
	//
	// Initialize the schedule table.
	//
	for (int day = 0; day < 7; day++)
	{
		for (int hour = 0; hour < 12; hour++)
		{
			m_bScheduleTable[day][hour].Set(false);
		}
	}

	m_propertyMap.insert(PropertyMap::value_type(KEY_WKINDXRSVC_DRE, &m_strDre));
	m_propertyMap.insert(PropertyMap::value_type(KEY_WKINDXRSVC_LOCALSERVER, &m_bUseLocalServer));
	m_propertyMap.insert(PropertyMap::value_type(KEY_WKINDXRSVC_CREATESUMMARY, &m_bCreateSummary));
	m_propertyMap.insert(PropertyMap::value_type(KEY_WKINDXRSVC_STORECONTENT, &m_bStoreContent));
	m_propertyMap.insert(PropertyMap::value_type(KEY_WKINDXRSVC_QUERYPORT, &m_lQueryPort));
	m_propertyMap.insert(PropertyMap::value_type(KEY_WKINDXRSVC_INDEXPORT, &m_lIndexPort));
	m_propertyMap.insert(PropertyMap::value_type(KEY_WKINDXRSVC_WORKSITE, &m_strWorkSiteServer));
	m_propertyMap.insert(PropertyMap::value_type(KEY_WKINDXRSVC_CHUNKSIZE, &m_lChunkSize));
	m_propertyMap.insert(PropertyMap::value_type(KEY_WKINDXRSVC_MODE, &m_strRunMode));
	m_propertyMap.insert(PropertyMap::value_type(KEY_WKINDXRSVC_SCHEDULE, &m_strSchedule));
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	~WkIndxrServiceConfiguration
//
	WkIndxrServiceConfiguration::~WkIndxrServiceConfiguration()
{
	//
	// Intentionally lef blank
	//
}


//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	LoadFromRegistry
//
void
	WkIndxrServiceConfiguration::LoadFromRegistry()
{
	ServiceConfiguration::LoadFromRegistry();

	//
	// Process computed fields
	//
	for (int day = 0; day < 7; day++)
	{
		for (int hour = 0; hour < 12; hour++)
		{
			if (m_strSchedule.Get().find(pattern[day][hour]) != -1)
				m_bScheduleTable[day][hour].Set(true);
		}
	}
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	StoreInRegistry
//
void
	WkIndxrServiceConfiguration::StoreInRegistry()
{
	NrCiString		strSchedule;

	//
	// Take computed fields and push data in registry property objects.
	//
	for (int day = 0; day < 7; day++)
	{
		for (int hour = 0; hour < 12; hour++)
		{
			if (m_bScheduleTable[day][hour].Get() == true)
			{
				strSchedule += pattern[day][hour];
				strSchedule += TEXT(", ");
			}
		}
	}

	m_strSchedule.Set(strSchedule);

	ServiceConfiguration::StoreInRegistry();
}


//
//----------------------------------------------------------------------------------------------------------------------
// WkAtIndxrServiceConfiguration Class
//----------------------------------------------------------------------------------------------------------------------
//

#define KEY_WKDRESVC_DREATCFGFILEPATH				_T("INI File Path")

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// WkAtIndxrServiceConfiguration
//
	WkAtIndxrServiceConfiguration::WkAtIndxrServiceConfiguration(
		const TCHAR *szComputerName_
	) :
		ServiceConfiguration(
			szComputerName_,
			KEY_WKATINDXRSVC_PATH,
			SZ_WKATINDXRSVC_NAME,
			SZ_WKATINDXRSVC_DISPLAY_NAME,
			SZ_WKATINDXRSVC_SCM_NAME
		),
		m_strDreAutoIndexerCfgFilePath(_T(""))
{
	m_propertyMap.insert(PropertyMap::value_type(KEY_WKDRESVC_DREATCFGFILEPATH, &m_strDreAutoIndexerCfgFilePath));
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// ~WkAtIndxrServiceConfiguration
//
	WkAtIndxrServiceConfiguration::~WkAtIndxrServiceConfiguration()
{
	//
	// Intentionally left blank.
	//
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	LoadFromRegistry
//

void
WkAtIndxrServiceConfiguration::LoadFromRegistry()
{
	ServiceConfiguration::LoadFromRegistry();

	TCHAR szDreHost[ 32 ];
	memset( szDreHost, 0, 32 * sizeof( TCHAR ) );

	// now load following settings from DRE AutoIndexer CFG file
	GetPrivateProfileString( _T( "Default" ), _T( "DreHost" ), _T("127.0.0.1"), szDreHost, 32, ( LPCTSTR ) m_strDreAutoIndexerCfgFilePath.Get().c_str() );
	m_lDreQueryPort.Set( GetPrivateProfileInt( _T( "Default" ), _T( "QueryPort" ), 2000, ( LPCTSTR ) m_strDreAutoIndexerCfgFilePath.Get().c_str() ) );
	m_lDreIndexPort.Set( GetPrivateProfileInt( _T( "Default" ), _T( "IndexPort" ), 2001, ( LPCTSTR ) m_strDreAutoIndexerCfgFilePath.Get().c_str() ) );

	m_strDreHost.Set( szDreHost  );
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	StoreInRegistry
//

void
WkAtIndxrServiceConfiguration::StoreInRegistry()
{
	ServiceConfiguration::StoreInRegistry();

	TCHAR szQueryPort[ 16 ], szIndexPort[ 16 ];
	memset( szQueryPort, 0, 16 * sizeof( TCHAR ) );
	memset( szIndexPort, 0, 16 * sizeof( TCHAR ) );
	wsprintf( szQueryPort, _T( "%i" ), m_lDreQueryPort.Get( ) );
	wsprintf( szIndexPort, _T( "%i" ), m_lDreIndexPort.Get( ) );

	WritePrivateProfileString( _T( "Default" ), _T( "DreHost" ), ( LPCTSTR ) m_strDreHost.Get( ).c_str( ), ( LPCTSTR ) m_strDreAutoIndexerCfgFilePath.Get().c_str() );
	WritePrivateProfileString( _T( "Default" ), _T( "QueryPort" ), szQueryPort, ( LPCTSTR ) m_strDreAutoIndexerCfgFilePath.Get().c_str() );
	WritePrivateProfileString( _T( "Default" ), _T( "IndexPort" ), szIndexPort, ( LPCTSTR ) m_strDreAutoIndexerCfgFilePath.Get().c_str() );
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	DeleteFromRegistry
//

void
WkAtIndxrServiceConfiguration::DeleteFromRegistry()
{
	RegistryMap::DeleteFromRegistry();

	// don't need to delete values from the DRE AutoIndexer CFG file
}





#define KEY_DSSYNCSVC_ATTRIBUTEMAP_MAPNAME			_T( "Map Name" )
#define KEY_DSSYNCSVC_ATTRIBUTEMAP_OUNAME			_T( "OU Name" )
#define KEY_DSSYNCSVC_ATTRIBUTEMAP_USERNAME			_T( "User Name" )
#define KEY_DSSYNCSVC_ATTRIBUTEMAP_USERID			_T( "User Id" )
#define KEY_DSSYNCSVC_ATTRIBUTEMAP_USERMAIL			_T( "User Email" )
#define KEY_DSSYNCSVC_ATTRIBUTEMAP_USERFAX			_T( "User Fax" )
#define KEY_DSSYNCSVC_ATTRIBUTEMAP_USERTELEPHONE	_T( "User Telephone" )
#define KEY_DSSYNCSVC_ATTRIBUTEMAP_USERLOCATION		_T( "User Location" )
#define KEY_DSSYNCSVC_ATTRIBUTEMAP_USERENABLED		_T( "User Enabled" )
#define KEY_DSSYNCSVC_ATTRIBUTEMAP_GROUPNAME		_T( "Group Name" )
#define KEY_DSSYNCSVC_ATTRIBUTEMAP_GROUPID			_T( "Group Id" )
#define KEY_DSSYNCSVC_ATTRIBUTEMAP_GROUPMEMBER		_T( "Group Member" )
#define KEY_DSSYNCSVC_ATTRIBUTEMAP_K1SYNCID			_T( "K1SyncId" )

CDSSyncSvc_AttributeMap::CDSSyncSvc_AttributeMap( const TCHAR *szComputerName_, HKEY hKey_, const TCHAR *szBaseKeyPath_ )
: IM::RegistryMap( szComputerName_, hKey_, szBaseKeyPath_ )
{
	m_strMapName.Set( _T( "" ) ); 
	m_strOUName.Set( _T( "" ) ); 
	m_strUserName.Set( _T( "" ) ); 
	m_strUserId.Set( _T( "" ) );
	m_strUserEmail.Set( _T( "" ) ); 
	m_strUserFax.Set( _T( "" ) ); 
	m_strUserTelephone.Set( _T( "" ) ); 
	m_strUserLocation.Set( _T( "" ) );
	m_strUserEnabled.Set( _T( "" ) );
	m_strGroupName.Set( _T( "" ) ); 
	m_strGroupId.Set( _T( "" ) ); 
	m_strGroupMember.Set( _T( "" ) ); 
	m_strK1SyncId.Set( _T( "" ) );

	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_ATTRIBUTEMAP_MAPNAME, &m_strMapName ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_ATTRIBUTEMAP_OUNAME, &m_strOUName ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_ATTRIBUTEMAP_USERNAME, &m_strUserName ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_ATTRIBUTEMAP_USERID, &m_strUserId ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_ATTRIBUTEMAP_USERMAIL, &m_strUserEmail ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_ATTRIBUTEMAP_USERFAX, &m_strUserFax ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_ATTRIBUTEMAP_USERTELEPHONE, &m_strUserTelephone ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_ATTRIBUTEMAP_USERLOCATION, &m_strUserLocation ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_ATTRIBUTEMAP_USERENABLED, &m_strUserEnabled ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_ATTRIBUTEMAP_GROUPNAME, &m_strGroupName ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_ATTRIBUTEMAP_GROUPID, &m_strGroupId ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_ATTRIBUTEMAP_GROUPMEMBER, &m_strGroupMember ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_ATTRIBUTEMAP_K1SYNCID, &m_strK1SyncId ) );
}

CDSSyncSvc_AttributeMap::CDSSyncSvc_AttributeMap( const CDSSyncSvc_AttributeMap& DSSyncSvc_AttributeMap )
: IM::RegistryMap( DSSyncSvc_AttributeMap )
{
	*this = DSSyncSvc_AttributeMap;
}

CDSSyncSvc_AttributeMap::~CDSSyncSvc_AttributeMap( void )
{
}

bool CDSSyncSvc_AttributeMap::operator ==( const CDSSyncSvc_AttributeMap& DSSyncSvc_AttributeMap ) const
{
	bool bRetval = false;

	if(
		( _tcsicmp( m_strMapName.Get( ).c_str( ), DSSyncSvc_AttributeMap.m_strMapName.Get( ).c_str( ) ) == 0 ) &&
		( _tcsicmp( m_strOUName.Get( ).c_str( ), DSSyncSvc_AttributeMap.m_strOUName.Get( ).c_str( ) ) == 0 ) &&
		( _tcsicmp( m_strUserName.Get( ).c_str( ), DSSyncSvc_AttributeMap.m_strUserName.Get( ).c_str( ) ) == 0 ) &&
		( _tcsicmp( m_strUserId.Get( ).c_str( ), DSSyncSvc_AttributeMap.m_strUserId.Get( ).c_str( ) ) == 0 ) &&
		( _tcsicmp( m_strUserEmail.Get( ).c_str( ), DSSyncSvc_AttributeMap.m_strUserEmail.Get( ).c_str( ) ) == 0 ) &&
		( _tcsicmp( m_strUserFax.Get( ).c_str( ), DSSyncSvc_AttributeMap.m_strUserFax.Get( ).c_str( ) ) == 0 ) &&
		( _tcsicmp( m_strUserTelephone.Get( ).c_str( ), DSSyncSvc_AttributeMap.m_strUserTelephone.Get( ).c_str( ) ) == 0 ) &&
		( _tcsicmp( m_strUserLocation.Get( ).c_str( ), DSSyncSvc_AttributeMap.m_strUserLocation.Get( ).c_str( ) ) == 0 ) &&
		( _tcsicmp( m_strUserEnabled.Get( ).c_str( ), DSSyncSvc_AttributeMap.m_strUserEnabled.Get( ).c_str( ) ) == 0 ) &&
		( _tcsicmp( m_strGroupName.Get( ).c_str( ), DSSyncSvc_AttributeMap.m_strGroupName.Get( ).c_str( ) ) == 0 ) &&
		( _tcsicmp( m_strGroupId.Get( ).c_str( ), DSSyncSvc_AttributeMap.m_strGroupId.Get( ).c_str( ) ) == 0 ) &&
		( _tcsicmp( m_strGroupMember.Get( ).c_str( ), DSSyncSvc_AttributeMap.m_strGroupMember.Get( ).c_str( ) ) == 0 ) &&
		( _tcsicmp( m_strK1SyncId.Get( ).c_str( ), DSSyncSvc_AttributeMap.m_strK1SyncId.Get( ).c_str( ) ) == 0 )
		)
	{
		bRetval = true;
	}

	return bRetval;
}

CDSSyncSvc_AttributeMap& CDSSyncSvc_AttributeMap::operator =( const CDSSyncSvc_AttributeMap& DSSyncSvc_AttributeMap )
{
	
	m_strMapName.Set( DSSyncSvc_AttributeMap.m_strMapName.Get( ).c_str( ) ); 
	m_strOUName.Set( DSSyncSvc_AttributeMap.m_strOUName.Get( ).c_str( ) ); 
	m_strUserName.Set( DSSyncSvc_AttributeMap.m_strUserName.Get( ).c_str( ) ); 
	m_strUserId.Set( DSSyncSvc_AttributeMap.m_strUserId.Get( ).c_str( ) );
	m_strUserEmail.Set( DSSyncSvc_AttributeMap.m_strUserEmail.Get( ).c_str( ) ); 
	m_strUserFax.Set( DSSyncSvc_AttributeMap.m_strUserFax.Get( ).c_str( ) ); 
	m_strUserTelephone.Set( DSSyncSvc_AttributeMap.m_strUserTelephone.Get( ).c_str( ) ); 
	m_strUserLocation.Set( DSSyncSvc_AttributeMap.m_strUserLocation.Get( ).c_str( ) );
	m_strUserEnabled.Set( DSSyncSvc_AttributeMap.m_strUserEnabled.Get( ).c_str( ) );
	m_strGroupName.Set( DSSyncSvc_AttributeMap.m_strGroupName.Get( ).c_str( ) ); 
	m_strGroupId.Set( DSSyncSvc_AttributeMap.m_strGroupId.Get( ).c_str( ) ); 
	m_strGroupMember.Set( DSSyncSvc_AttributeMap.m_strGroupMember.Get( ).c_str( ) ); 
	m_strK1SyncId.Set( DSSyncSvc_AttributeMap.m_strK1SyncId.Get( ).c_str( ) );

	m_propertyMap.clear( );
	
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_ATTRIBUTEMAP_MAPNAME, &m_strMapName ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_ATTRIBUTEMAP_OUNAME, &m_strOUName ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_ATTRIBUTEMAP_USERNAME, &m_strUserName ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_ATTRIBUTEMAP_USERID, &m_strUserId ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_ATTRIBUTEMAP_USERMAIL, &m_strUserEmail ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_ATTRIBUTEMAP_USERFAX, &m_strUserFax ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_ATTRIBUTEMAP_USERTELEPHONE, &m_strUserTelephone ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_ATTRIBUTEMAP_USERLOCATION, &m_strUserLocation ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_ATTRIBUTEMAP_USERENABLED, &m_strUserEnabled ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_ATTRIBUTEMAP_GROUPNAME, &m_strGroupName ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_ATTRIBUTEMAP_GROUPID, &m_strGroupId ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_ATTRIBUTEMAP_GROUPMEMBER, &m_strGroupMember ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_ATTRIBUTEMAP_K1SYNCID, &m_strK1SyncId ) );

	return *this;
}

bool CDSSyncSvc_AttributeMap::WellFormedUser( void ) const
{
	return
		(
			( _tcslen( m_strOUName.Get( ).c_str( ) ) > 0 )
			&& ( _tcslen( m_strUserId.Get( ).c_str( ) ) > 0 )
			&& ( _tcslen( m_strUserName.Get( ).c_str( ) ) > 0 )
			&& ( _tcslen( m_strK1SyncId.Get( ).c_str( ) ) > 0 )
//			&& ( _tcslen( m_strUserEnabled.Get( ).c_str( ) ) > 0 )
		);
}

bool CDSSyncSvc_AttributeMap::WellFormedGroup( void ) const
{
	return
		(
			( _tcslen( m_strOUName.Get( ).c_str( ) ) > 0 )
			&& ( _tcslen( m_strGroupName.Get( ).c_str( ) ) > 0 )
			&& ( _tcslen( m_strGroupId.Get( ).c_str( ) ) > 0 )
			&& ( _tcslen( m_strGroupMember.Get( ).c_str( ) ) > 0 )
			&& ( _tcslen( m_strK1SyncId.Get( ).c_str( ) ) > 0 )
		);
}





#define KEY_DSSYNCSVC_DSPARAM_SERVERNAME	_T( "Server Name" )
#define KEY_DSSYNCSVC_DSPARAM_USERID		_T( "User ID" )
#define KEY_DSSYNCSVC_DSPARAM_PASSWORD		_T( "Password" )
#define KEY_DSSYNCSVC_DSPARAM_SERVICETYPE	_T( "Service Type" )
#define KEY_DSSYNCSVC_DSPARAM_TCPIPPORT		_T( "TCP/IP Port" )

#define KEY_DSSYNCSVC_DSPARAM_CONTEXT		_T( "Context" )
#define KEY_DSSYNCSVC_DSPARAM_TREEID		_T( "Tree ID" )
#define KEY_DSSYNCSVC_DSPARAM_ENABLE_SSL	_T( "Enable SSL" )

CDSSyncSvc_DSParameters::CDSSyncSvc_DSParameters( const TCHAR *szComputerName_, HKEY hKey_, const TCHAR *szBaseKeyPath_ )
: IM::RegistryMap( szComputerName_, hKey_, szBaseKeyPath_ )
{
	m_strServerName.Set( _T( "" ) ); 
	m_strUserId.Set( _T( "" ) ); 
	m_strPassword.Set( _T( "" ) );
	m_strPassword.SetEncryptFlag( true );
	m_strContext.Set( _T( "" ) );
	m_strTreeID.Set( _T( "" ) );

	m_lServiceType.Set( 0 );
	m_lTcpipPort.Set( 0 );
	
	m_lEnableSSL.Set(0);

	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_DSPARAM_SERVERNAME, &m_strServerName ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_DSPARAM_USERID, &m_strUserId ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_DSPARAM_PASSWORD, &m_strPassword ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_DSPARAM_SERVICETYPE, &m_lServiceType ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_DSPARAM_TCPIPPORT, &m_lTcpipPort ) );
	
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_DSPARAM_CONTEXT, &m_strContext ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_DSPARAM_TREEID, &m_strTreeID ) );
	m_propertyMap.insert(PropertyMap::value_type(KEY_DSSYNCSVC_DSPARAM_ENABLE_SSL, &m_lEnableSSL));
}

CDSSyncSvc_DSParameters::CDSSyncSvc_DSParameters( const CDSSyncSvc_DSParameters& DSSyncSvc_DSParameters )
: IM::RegistryMap( DSSyncSvc_DSParameters )
{
	// invoke assignment operator
	*this = DSSyncSvc_DSParameters;
}

CDSSyncSvc_DSParameters::~CDSSyncSvc_DSParameters( void )
{
}

bool CDSSyncSvc_DSParameters::operator ==( const CDSSyncSvc_DSParameters& DSSyncSvc_DSParameters ) const
{
	bool bRetval = false;

	if(
		( _tcsicmp( m_strServerName.Get( ).c_str( ), DSSyncSvc_DSParameters.m_strServerName.Get( ).c_str( ) ) == 0 ) &&
		( _tcsicmp( m_strUserId.Get( ).c_str( ), DSSyncSvc_DSParameters.m_strUserId.Get( ).c_str( ) ) == 0 ) &&
		( _tcscmp( m_strPassword.Get( ).c_str( ), DSSyncSvc_DSParameters.m_strPassword.Get( ).c_str( ) ) == 0 ) &&
		( m_lServiceType.Get( ) == DSSyncSvc_DSParameters.m_lServiceType.Get( ) ) &&
		( m_lTcpipPort.Get( ) == DSSyncSvc_DSParameters.m_lTcpipPort.Get( ) ) &&
		
		( _tcsicmp( m_strContext.Get( ).c_str( ), DSSyncSvc_DSParameters.m_strContext.Get( ).c_str( ) ) == 0 ) &&
		( _tcsicmp( m_strTreeID.Get( ).c_str( ), DSSyncSvc_DSParameters.m_strTreeID.Get( ).c_str( ) ) == 0 )  &&
		m_lEnableSSL.Get() == DSSyncSvc_DSParameters.m_lEnableSSL.Get()
		)
	{
		bRetval = true;
	}

	return bRetval;
}

CDSSyncSvc_DSParameters& CDSSyncSvc_DSParameters::operator =( const CDSSyncSvc_DSParameters& DSSyncSvc_DSParameters )
{
	
	m_strServerName.Set( DSSyncSvc_DSParameters.m_strServerName.Get( ).c_str( ) ); 
	m_strUserId.Set( DSSyncSvc_DSParameters.m_strUserId.Get( ).c_str( ) ); 
	m_strPassword.Set( DSSyncSvc_DSParameters.m_strPassword.Get( ).c_str( ) );
	m_strPassword.SetEncryptFlag( DSSyncSvc_DSParameters.m_strPassword.IsEncrypted( ) );
	m_strContext.Set( DSSyncSvc_DSParameters.m_strContext.Get( ).c_str( ) );
	m_strTreeID.Set( DSSyncSvc_DSParameters.m_strTreeID.Get( ).c_str( ) );

	m_lServiceType.Set( DSSyncSvc_DSParameters.m_lServiceType.Get( ) );
	m_lTcpipPort.Set( DSSyncSvc_DSParameters.m_lTcpipPort.Get( ) );
	
	m_lEnableSSL.Set(DSSyncSvc_DSParameters.m_lEnableSSL.Get());

	m_propertyMap.clear( );

	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_DSPARAM_SERVERNAME, &m_strServerName ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_DSPARAM_USERID, &m_strUserId ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_DSPARAM_PASSWORD, &m_strPassword ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_DSPARAM_SERVICETYPE, &m_lServiceType ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_DSPARAM_TCPIPPORT, &m_lTcpipPort ) );
	
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_DSPARAM_CONTEXT, &m_strContext ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_DSPARAM_TREEID, &m_strTreeID ) );
	m_propertyMap.insert(PropertyMap::value_type(KEY_DSSYNCSVC_DSPARAM_ENABLE_SSL, &m_lEnableSSL));

	return *this;
}

IM::NrString CDSSyncSvc_DSParameters::GetNOSType( void ) const
{
	switch( ( CDSSyncSvc_DSParameters::LDAPTYPE ) m_lServiceType.Get( ) )
	{
	case CDSSyncSvc_DSParameters::Microsoft:
		return _T( "6" );
	case CDSSyncSvc_DSParameters::Sun:
		return _T( "7" );
	case CDSSyncSvc_DSParameters::Novell:
		return _T( "4" );
	case CDSSyncSvc_DSParameters::NT:
		return _T( "3" );
	default:
		return _T( "" );
	}
}

IM::NrString CDSSyncSvc_DSParameters::GetDSName( void ) const
{
	switch( ( CDSSyncSvc_DSParameters::LDAPTYPE ) m_lServiceType.Get( ) )
	{
	case CDSSyncSvc_DSParameters::Microsoft:
		return _T( "Microsoft Active Directory" );
	case CDSSyncSvc_DSParameters::Sun:
		return _T( "Sun ONE Directory Services" );
	case CDSSyncSvc_DSParameters::Novell:
		return _T( "Novell NDS" );
	case CDSSyncSvc_DSParameters::NT:
		return _T( "Microsoft NT" );
	default:
		return _T( "" );
	}
}





#define KEY_DSSYNCSVC_DSPARAM_DMS									_T( "DMS" )
#define KEY_DSSYNCSVC_DSPARAM_LIBRARY								_T( "Library" )
#define KEY_DSSYNCSVC_DSPARAM_USERID								_T( "User ID" )
#define KEY_DSSYNCSVC_DSPARAM_PASSWORD								_T( "Password" )
#define KEY_DSSYNCSVC_DSPARAM_DEFAULTPASSWORD						_T( "Default Password" )
#define KEY_DSSYNCSVC_DSPARAM_DEFAULTPASSWORD_NEVER_EXPIRES			_T( "Default Password Never Expires" )
#define KEY_DSSYNCSVC_DSPARAM_DEFAULTPASSWORD_MUST_BE_CHANGED		_T( "Default Password Must Be Changed" )

#define KEY_DSSYNCSVC_DSPARAM_LOGIN									_T( "LoginType" )



CDSSyncSvc_DMSParameters::CDSSyncSvc_DMSParameters( const TCHAR *szComputerName_, HKEY hKey_, const TCHAR *szBaseKeyPath_ )
: IM::RegistryMap( szComputerName_, hKey_, szBaseKeyPath_ )
{
	m_strDms.Set( _T( "" ) ); 
	m_strLibrary.Set( _T( "" ) ); 
	m_strUserId.Set( _T( "" ) ); 
	m_strPassword.Set( _T( "" ) );
	m_strPassword.SetEncryptFlag( true );
	m_lTcpipPort.Set( 0 );
	m_lLoginType.Set(0);

	
	
	
	m_strDefaultPassword.Set( _T( "" ) );
	m_strDefaultPassword.SetEncryptFlag( true );
	m_bDefaultPasswordNeverExpires.Set( false );
	m_bDefaultPasswordMustBeChanged.Set( true );

	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_DSPARAM_DMS, &m_strDms ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_DSPARAM_LIBRARY, &m_strLibrary ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_DSPARAM_USERID, &m_strUserId ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_DSPARAM_PASSWORD, &m_strPassword ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_DSPARAM_TCPIPPORT, &m_lTcpipPort ) );
	m_propertyMap.insert(PropertyMap::value_type(KEY_DSSYNCSVC_DSPARAM_LOGIN, &m_lLoginType));
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_DSPARAM_DEFAULTPASSWORD, &m_strDefaultPassword ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_DSPARAM_DEFAULTPASSWORD_NEVER_EXPIRES, &m_bDefaultPasswordNeverExpires ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_DSPARAM_DEFAULTPASSWORD_MUST_BE_CHANGED, &m_bDefaultPasswordMustBeChanged ) );
}

CDSSyncSvc_DMSParameters::CDSSyncSvc_DMSParameters( const CDSSyncSvc_DMSParameters& DSSyncSvc_DMSParameters )
: IM::RegistryMap( DSSyncSvc_DMSParameters )
{
	// invoke assignment operator
	*this = DSSyncSvc_DMSParameters;
}

CDSSyncSvc_DMSParameters::~CDSSyncSvc_DMSParameters( void )
{
}

bool CDSSyncSvc_DMSParameters::operator ==( const CDSSyncSvc_DMSParameters& DSSyncSvc_DMSParameters ) const
{
	bool bRetval = false;

	if(
		( _tcsicmp( m_strDms.Get( ).c_str( ), DSSyncSvc_DMSParameters.m_strDms.Get( ).c_str( ) ) == 0 ) &&
		( _tcsicmp( m_strLibrary.Get( ).c_str( ), DSSyncSvc_DMSParameters.m_strLibrary.Get( ).c_str( ) ) == 0 ) &&
		( _tcsicmp( m_strUserId.Get( ).c_str( ), DSSyncSvc_DMSParameters.m_strUserId.Get( ).c_str( ) ) == 0 ) &&
		( _tcscmp( m_strPassword.Get( ).c_str( ), DSSyncSvc_DMSParameters.m_strPassword.Get( ).c_str( ) ) == 0 ) &&
		( m_lTcpipPort.Get( ) == DSSyncSvc_DMSParameters.m_lTcpipPort.Get( ) ) &&
		(m_lLoginType.Get() == DSSyncSvc_DMSParameters.m_lLoginType.Get()) &&
		( _tcscmp( m_strDefaultPassword.Get( ).c_str( ), DSSyncSvc_DMSParameters.m_strDefaultPassword.Get( ).c_str( ) ) == 0 ) &&
		( m_bDefaultPasswordNeverExpires.Get( ) == DSSyncSvc_DMSParameters.m_bDefaultPasswordNeverExpires.Get( ) ) &&
		(m_bDefaultPasswordMustBeChanged.Get() == DSSyncSvc_DMSParameters.m_bDefaultPasswordMustBeChanged.Get()) &&
		(m_lTcpipPort.Get() == DSSyncSvc_DMSParameters.m_lTcpipPort.Get())
		)
	{
		bRetval = true;
	}

	return bRetval;
}

CDSSyncSvc_DMSParameters& CDSSyncSvc_DMSParameters::operator =( const CDSSyncSvc_DMSParameters& DSSyncSvc_DMSParameters )
{
	
	m_strDms.Set( DSSyncSvc_DMSParameters.m_strDms.Get( ).c_str( ) ); 
	m_strLibrary.Set( DSSyncSvc_DMSParameters.m_strLibrary.Get( ).c_str( ) ); 
	m_strUserId.Set( DSSyncSvc_DMSParameters.m_strUserId.Get( ).c_str( ) ); 
	m_strPassword.Set( DSSyncSvc_DMSParameters.m_strPassword.Get( ).c_str( ) );
	m_strPassword.SetEncryptFlag( DSSyncSvc_DMSParameters.m_strPassword.IsEncrypted( ) );
	m_lTcpipPort.Set( DSSyncSvc_DMSParameters.m_lTcpipPort.Get( ) );
	m_lLoginType.Set(DSSyncSvc_DMSParameters.m_lLoginType.Get());
	
	
	m_strDefaultPassword.Set( DSSyncSvc_DMSParameters.m_strDefaultPassword.Get( ).c_str( ) );
	m_strDefaultPassword.SetEncryptFlag( DSSyncSvc_DMSParameters.m_strDefaultPassword.IsEncrypted( ) );
	m_bDefaultPasswordNeverExpires.Set( DSSyncSvc_DMSParameters.m_bDefaultPasswordNeverExpires.Get( ) );
	m_bDefaultPasswordMustBeChanged.Set( DSSyncSvc_DMSParameters.m_bDefaultPasswordMustBeChanged.Get( ) );

	m_propertyMap.clear( );
	
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_DSPARAM_DMS, &m_strDms ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_DSPARAM_LIBRARY, &m_strLibrary ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_DSPARAM_USERID, &m_strUserId ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_DSPARAM_PASSWORD, &m_strPassword ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_DSPARAM_TCPIPPORT, &m_lTcpipPort ) );
	m_propertyMap.insert(PropertyMap::value_type(KEY_DSSYNCSVC_DSPARAM_LOGIN, &m_lLoginType));

	
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_DSPARAM_DEFAULTPASSWORD, &m_strDefaultPassword ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_DSPARAM_DEFAULTPASSWORD_NEVER_EXPIRES, &m_bDefaultPasswordNeverExpires ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_DSPARAM_DEFAULTPASSWORD_MUST_BE_CHANGED, &m_bDefaultPasswordMustBeChanged ) );

	return *this;
}





#define KEY_DSSYNCSVC_CONNECTION_NAME					_T( "Name" )
#define KEY_DSSYNCSVC_CONNECTION_NODE					_T( "Node" )
#define KEY_DSSYNCSVC_CONNECTION_ATTRIBUTEMAPNAME		_T( "Attribute Map Name" )
#define KEY_DSSYNCSVC_CONNECTION_DSPARAMETERS			_T( "\\DS Parameters" )
#define KEY_DSSYNCSVC_CONNECTION_DMSPARAMETERS			_T( "\\DMS Parameters" )
#define KEY_DSSYNCSVC_CONNECTION_DSPARAMETERS2			_T( "DS Parameters" )
#define KEY_DSSYNCSVC_CONNECTION_DMSPARAMETERS2			_T( "DMS Parameters" )
#define KEY_DSSYNCSVC_CONNECTION_EXTERNALDNS			_T( "External DNs" )
#define KEY_DSSYNCSVC_CONNECTION_FILTER					_T( "Filter" )

CDSSyncSvc_Connection::CDSSyncSvc_Connection( const TCHAR *szComputerName_, HKEY hKey_, const TCHAR *szBaseKeyPath_ )
: IM::RegistryMap( szComputerName_, hKey_, szBaseKeyPath_ ),
m_DSParameters( szComputerName_, hKey_, szBaseKeyPath_ ),
m_DMSParameters( szComputerName_, hKey_, szBaseKeyPath_ )
{
	m_strName.Set( _T( "" ) );
	m_strNode.Set( _T( "" ) );
	m_strAttributeMapName.Set( _T( "" ) );
	m_strExternalDNList.Set( _T( "" ) );
	m_strFilter.Set( _T( "" ) );

	m_DSParameters.AddPath( KEY_DSSYNCSVC_CONNECTION_DSPARAMETERS );
	m_DMSParameters.AddPath( KEY_DSSYNCSVC_CONNECTION_DMSPARAMETERS );

	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_CONNECTION_NAME, &m_strName ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_CONNECTION_NODE, &m_strNode ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_CONNECTION_ATTRIBUTEMAPNAME, &m_strAttributeMapName ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_CONNECTION_EXTERNALDNS, &m_strExternalDNList ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_CONNECTION_FILTER, &m_strFilter ) );
}

CDSSyncSvc_Connection::CDSSyncSvc_Connection( const CDSSyncSvc_Connection& DSSyncSvc_Connection )
: IM::RegistryMap( DSSyncSvc_Connection ), 
m_DSParameters( DSSyncSvc_Connection.m_DSParameters ),
m_DMSParameters( DSSyncSvc_Connection.m_DMSParameters )
{
	m_strName.Set( DSSyncSvc_Connection.m_strName.Get( ).c_str( ) );
	m_strNode.Set( DSSyncSvc_Connection.m_strNode.Get( ).c_str( ) );
	m_strAttributeMapName.Set( DSSyncSvc_Connection.m_strAttributeMapName.Get( ).c_str( ) );
	m_strExternalDNList.Set( DSSyncSvc_Connection.m_strExternalDNList.Get( ).c_str( ) );
	m_strFilter.Set( DSSyncSvc_Connection.m_strFilter.Get( ).c_str( ) );

	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_CONNECTION_NAME, &m_strName ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_CONNECTION_NODE, &m_strNode ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_CONNECTION_ATTRIBUTEMAPNAME, &m_strAttributeMapName ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_CONNECTION_EXTERNALDNS, &m_strExternalDNList ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_CONNECTION_FILTER, &m_strFilter ) );
}

CDSSyncSvc_Connection::~CDSSyncSvc_Connection( void )
{
}

bool CDSSyncSvc_Connection::operator ==( const CDSSyncSvc_Connection& DSSyncSvc_Connection ) const
{
	bool bRetval = false;

	if(
		( _tcsicmp( m_strName.Get( ).c_str( ), DSSyncSvc_Connection.m_strName.Get( ).c_str( ) ) == 0 ) &&
		( _tcsicmp( m_strNode.Get( ).c_str( ), DSSyncSvc_Connection.m_strNode.Get( ).c_str( ) ) == 0 ) &&
		( _tcsicmp( m_strFilter.Get( ).c_str( ), DSSyncSvc_Connection.m_strFilter.Get( ).c_str( ) ) == 0 ) &&
		( _tcsicmp( m_strAttributeMapName.Get( ).c_str( ), DSSyncSvc_Connection.m_strAttributeMapName.Get( ).c_str( ) ) == 0 ) &&
		( _tcsicmp( m_strExternalDNList.Get( ).c_str( ), DSSyncSvc_Connection.m_strExternalDNList.Get( ).c_str( ) ) == 0 )
		)
	{
		if( m_DSParameters == DSSyncSvc_Connection.m_DSParameters )
			if( m_DMSParameters == DSSyncSvc_Connection.m_DMSParameters )
				bRetval = true;
	}

	return bRetval;
}

CDSSyncSvc_Connection& CDSSyncSvc_Connection::operator =( const CDSSyncSvc_Connection& DSSyncSvc_Connection )
{
	
	m_strName.Set( DSSyncSvc_Connection.m_strName.Get( ).c_str( ) );
	m_strNode.Set( DSSyncSvc_Connection.m_strNode.Get( ).c_str( ) );
	m_strAttributeMapName.Set( DSSyncSvc_Connection.m_strAttributeMapName.Get( ).c_str( ) );
	m_strExternalDNList.Set( DSSyncSvc_Connection.m_strExternalDNList.Get( ).c_str( ) );
	m_strFilter.Set( DSSyncSvc_Connection.m_strFilter.Get( ).c_str( ) );

	m_DSParameters = DSSyncSvc_Connection.m_DSParameters;
	m_DMSParameters = DSSyncSvc_Connection.m_DMSParameters;

	m_propertyMap.clear( );

	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_CONNECTION_NAME, &m_strName ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_CONNECTION_NODE, &m_strNode ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_CONNECTION_ATTRIBUTEMAPNAME, &m_strAttributeMapName ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_CONNECTION_EXTERNALDNS, &m_strExternalDNList ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_CONNECTION_FILTER, &m_strFilter ) );

	return *this;
}

void CDSSyncSvc_Connection::LoadFromRegistry( )
{
	// call base class
	RegistryMap::LoadFromRegistry( );

	// read from registry
	m_DSParameters.LoadFromRegistry( );
	m_DMSParameters.LoadFromRegistry( );
}

void CDSSyncSvc_Connection::StoreInRegistry( )
{
	// call base class
	RegistryMap::StoreInRegistry( );

	// write to registry
	m_DSParameters.StoreInRegistry( );
	m_DMSParameters.StoreInRegistry( );
}

void CDSSyncSvc_Connection::DeleteFromRegistry( )
{
	// delete from registry
	m_DSParameters.DeleteFromRegistry( );
	m_DMSParameters.DeleteFromRegistry( );

	Open( NULL, KEY_WRITE );
	DeleteSubKey( KEY_DSSYNCSVC_CONNECTION_DSPARAMETERS2 );
	DeleteSubKey( KEY_DSSYNCSVC_CONNECTION_DMSPARAMETERS2 );

	// call base class
	RegistryMap::DeleteFromRegistry( );
}





#define KEY_DSSYNCSVC_ATTRIBUTEMAPS		_T( "\\Attribute Maps" )
#define KEY_DSSYNCSVC_CONNECTIONS		_T( "\\Connections" )
#define KEY_DSSYNCSVC_ATTRIBUTEMAPS2	_T( "Attribute Maps" )
#define KEY_DSSYNCSVC_CONNECTIONS2		_T( "Connections" )
#define KEY_DSSYNCSVC_SCHEDULE			_T( "Schedule" )
#define KEY_DSSYNCSVC_MODE				_T( "Mode" )
#define KEY_DSSYNCSVC_PAGESIZE			_T( "Page Size" )
#define KEY_DSSYNCSVC_CYCLEMINUTES		_T( "Cycle Minutes" )

CDSSyncSvc::CDSSyncSvc( const TCHAR *szComputerName_ )
:
	ServiceConfiguration(
		szComputerName_,
		KEY_DSSYNCSVC_PATH,
		SZ_DSSYNCSVC_NAME,
		SZ_DSSYNCSVC_DISPLAY_NAME,
		SZ_DSSYNCSVC_SCM_NAME )
{
	//
	// Initialize the schedule table.
	//
	for( int day = 0; day < 7; day++ )
	{
		for( int hour = 0; hour < 12; hour++ )
		{
			m_bScheduleTable[ day ][ hour ].Set( false );
		}
	}

	m_strSchedule.Set( _T( "" ) );
	m_strMode.Set( _T( "" ) );
	m_lPageSize.Set( 100 );
	m_lCycleMinutes.Set( 60 );

	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_SCHEDULE, &m_strSchedule ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_MODE, &m_strMode ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_PAGESIZE, &m_lPageSize ) );
	m_propertyMap.insert( PropertyMap::value_type( KEY_DSSYNCSVC_CYCLEMINUTES, &m_lCycleMinutes ) );
}

CDSSyncSvc::CDSSyncSvc( const CDSSyncSvc& DSSyncSvc )
: IM::ServiceConfiguration( DSSyncSvc )
{
	*this = DSSyncSvc;
}

CDSSyncSvc::~CDSSyncSvc( void )
{
	Clear( );
}

bool CDSSyncSvc::operator ==( const CDSSyncSvc& DSSyncSvc ) const
{
	if( _tcsicmp( m_strSchedule.Get( ).c_str( ), DSSyncSvc.m_strSchedule.Get( ).c_str( ) ) != 0 )
		return false;

	if( _tcsicmp( m_strMode.Get( ).c_str( ), DSSyncSvc.m_strMode.Get( ).c_str( ) ) != 0 )
		return false;

	if( m_lPageSize.Get( ) != DSSyncSvc.m_lPageSize.Get( ) )
		return false;

	if( m_lCycleMinutes.Get( ) != DSSyncSvc.m_lCycleMinutes.Get( ) )
		return false;

	bool bRetval = true;

	if( ( m_AttributeMapList.size( ) == DSSyncSvc.m_AttributeMapList.size( ) )
		&& 
		( m_ConnectionList.size( ) == DSSyncSvc.m_ConnectionList.size( ) ) )
	{
		{
			CONNECTIONLIST::const_iterator iterEnd = m_ConnectionList.end( );
			CONNECTIONLIST::const_iterator iter = m_ConnectionList.begin( );
			CONNECTIONLIST::const_iterator iter2 = DSSyncSvc.m_ConnectionList.begin( );
			for( ; iter != iterEnd; iter++, iter2++ )
			{
				CDSSyncSvc_Connection* pConnection = *iter;
				CDSSyncSvc_Connection* pConnection2 = *iter2;
				if( ( pConnection != NULL ) && ( pConnection2 != NULL ) )
				{
					// compare individual connections
					if( !( *pConnection == *pConnection2 ) )
					{
						bRetval = false;
						break;
					}
				}
			}
		}

		{
			ATTRIBUTEMAPLIST::const_iterator iterEnd = m_AttributeMapList.end( );
			ATTRIBUTEMAPLIST::const_iterator iter = m_AttributeMapList.begin( );
			ATTRIBUTEMAPLIST::const_iterator iter2 = DSSyncSvc.m_AttributeMapList.begin( );
			for( ; iter != iterEnd; iter++, iter2++ )
			{
				CDSSyncSvc_AttributeMap* pAttributeMap = *iter;
				CDSSyncSvc_AttributeMap* pAttributeMap2 = *iter2;
				if( ( pAttributeMap != NULL ) && ( pAttributeMap2 != NULL ) )
				{
					// compare individual attribute maps
					if( !( *pAttributeMap == *pAttributeMap2 ) )
					{
						bRetval = false;
						break;
					}
				}
			}
		}
	}
	else
	{
		// if list sizes don't match, they can't be the same

		bRetval = false;
	}
	

	return bRetval;
}

CDSSyncSvc& CDSSyncSvc::operator =( const CDSSyncSvc& DSSyncSvc )
{
	m_strSchedule.Set( DSSyncSvc.m_strSchedule.Get( ).c_str( ) );
	m_strMode.Set( DSSyncSvc.m_strMode.Get( ).c_str( ) );
	m_lPageSize.Set( DSSyncSvc.m_lPageSize.Get( ) );
	m_lCycleMinutes.Set( DSSyncSvc.m_lCycleMinutes.Get( ) );

	Clear( );

	{
		ATTRIBUTEMAPLIST::const_iterator iterEnd = DSSyncSvc.m_AttributeMapList.end( );
		for( ATTRIBUTEMAPLIST::const_iterator iter = DSSyncSvc.m_AttributeMapList.begin( ); iter != iterEnd; iter++ )
		{
			CDSSyncSvc_AttributeMap* pAttributeMap = *iter;
			if( pAttributeMap != NULL )
				m_AttributeMapList.push_back( im_new CDSSyncSvc_AttributeMap( *pAttributeMap ) );
		}
	}

	{
		CONNECTIONLIST::const_iterator iterEnd = DSSyncSvc.m_ConnectionList.end( );
		for( CONNECTIONLIST::const_iterator iter = DSSyncSvc.m_ConnectionList.begin( ); iter != iterEnd; iter++ )
		{
			CDSSyncSvc_Connection* pConnection = *iter;
			if( pConnection != NULL )
				m_ConnectionList.push_back( im_new CDSSyncSvc_Connection( *pConnection ) );
		}
	}

	return *this;
}

void CDSSyncSvc::Clear( void )
{
	try
	{
		// cleanup memory
		if( m_ConnectionList.size( ) > 0 )
			RemoveAllConnections( );

		if( m_AttributeMapList.size( ) > 0 )
			RemoveAllAttributeMaps( );
	}
	catch( ... )
	{
	}
}

void CDSSyncSvc::RemoveAllAttributeMaps( void )
{
	ATTRIBUTEMAPLIST::const_iterator iterEnd = m_AttributeMapList.end( );
	for( ATTRIBUTEMAPLIST::const_iterator iter = m_AttributeMapList.begin( ); iter != iterEnd; iter++ )
	{
		CDSSyncSvc_AttributeMap* pAttributeMap = *iter;
		if( pAttributeMap != NULL )
			delete pAttributeMap;
	}
	m_AttributeMapList.clear( );
}

void CDSSyncSvc::RemoveAllConnections( void )
{
	CONNECTIONLIST::const_iterator iterEnd = m_ConnectionList.end( );
	for( CONNECTIONLIST::const_iterator iter = m_ConnectionList.begin( ); iter != iterEnd; iter++ )
	{
		CDSSyncSvc_Connection* pConnection = *iter;
		if( pConnection != NULL )
			delete pConnection;
	}
	m_ConnectionList.clear( );
}

void CDSSyncSvc::AddAttributeMap(
	LPCTSTR szMapName, LPCTSTR szOUName, LPCTSTR szUserName, LPCTSTR szUserId, 
	LPCTSTR szUserEmail, LPCTSTR szUserFax, LPCTSTR szUserTelephone, LPCTSTR szUserLocation, LPCTSTR szUserEnabled,
	LPCTSTR szGroupName, LPCTSTR szGroupId, LPCTSTR szGroupMember,
	LPCTSTR szK1SyncId
	)
{
	IM::NrString strPath = GetBaseKeyPath( );
	strPath += KEY_DSSYNCSVC_ATTRIBUTEMAPS;
	strPath += _T( "\\" );
	strPath += szMapName;

	CDSSyncSvc_AttributeMap* pAttributeMap = im_new CDSSyncSvc_AttributeMap( GetComputerName( ).c_str( ), GetDesiredHive( ), strPath.c_str( ) );

	pAttributeMap->m_strMapName.Set( szMapName );
	pAttributeMap->m_strOUName.Set( szOUName );
	pAttributeMap->m_strUserName.Set( szUserName );
	pAttributeMap->m_strUserId.Set( szUserId );
	pAttributeMap->m_strUserEmail.Set( szUserEmail );
	pAttributeMap->m_strUserEnabled.Set( szUserEnabled );
	pAttributeMap->m_strUserFax.Set( szUserFax );
	pAttributeMap->m_strUserTelephone.Set( szUserTelephone );
	pAttributeMap->m_strUserLocation.Set( szUserLocation );
	pAttributeMap->m_strGroupName.Set( szGroupName );
	pAttributeMap->m_strGroupId.Set( szGroupId );
	pAttributeMap->m_strGroupMember.Set( szGroupMember );
	pAttributeMap->m_strK1SyncId.Set( szK1SyncId );

	m_AttributeMapList.push_back( pAttributeMap );
}

void CDSSyncSvc::AddConnection( 
	LPCTSTR szConnectionName, LPCTSTR szNode, LPCTSTR szAttributeMapName, LPCTSTR szFilter,
	LPCTSTR szDmsServer, LPCTSTR szDmsLibrary, LPCTSTR szDmsUserId, LPCTSTR szDmsPassword, long lDMSTcpipPort, long lLoginType,
	LPCTSTR szDSServer, LPCTSTR szDSUserId, LPCTSTR szDSPassword,
	LPCTSTR szDefaultPassword, bool bDefaultPasswordNeverExpires, bool bDefaultPasswordMustBeChanged,
	long lDSServiceType, long lDSTcpipPort, LPCTSTR szContext,LPCTSTR szExternalDNList,LPCTSTR szTreeID
	)
{
	IM::NrString strPath = GetBaseKeyPath( );
	strPath += KEY_DSSYNCSVC_CONNECTIONS;
	strPath += _T( "\\" );
	strPath += szConnectionName;

	CDSSyncSvc_Connection* pConnection = im_new CDSSyncSvc_Connection( GetComputerName( ).c_str( ), GetDesiredHive( ), strPath.c_str( ) );

	pConnection->m_strName.Set( szConnectionName );
	pConnection->m_strNode.Set( szNode );
	pConnection->m_strAttributeMapName.Set( szAttributeMapName );
	pConnection->m_strFilter.Set( szFilter);

	pConnection->m_DMSParameters.m_strDms.Set( szDmsServer );
	pConnection->m_DMSParameters.m_strLibrary.Set( szDmsLibrary );
	pConnection->m_DMSParameters.m_strUserId.Set( szDmsUserId );
	pConnection->m_DMSParameters.m_strPassword.Set( szDmsPassword );
	pConnection->m_DMSParameters.m_lTcpipPort.Set( lDMSTcpipPort );
	pConnection->m_DMSParameters.m_lLoginType.Set(lLoginType);
	
	pConnection->m_DMSParameters.m_strDefaultPassword.Set( szDefaultPassword );
	pConnection->m_DMSParameters.m_bDefaultPasswordNeverExpires.Set( bDefaultPasswordNeverExpires );
	pConnection->m_DMSParameters.m_bDefaultPasswordMustBeChanged.Set( bDefaultPasswordMustBeChanged );

	pConnection->m_DSParameters.m_strServerName.Set( szDSServer );
	pConnection->m_DSParameters.m_strUserId.Set( szDSUserId );
	pConnection->m_DSParameters.m_strPassword.Set( szDSPassword );
	pConnection->m_DSParameters.m_lServiceType.Set( lDSServiceType );
	pConnection->m_DSParameters.m_lTcpipPort.Set( lDSTcpipPort );
	pConnection->m_DSParameters.m_strContext.Set( szContext );
	pConnection->m_strExternalDNList.Set( szExternalDNList );
	pConnection->m_DSParameters.m_strTreeID.Set( szTreeID );


	m_ConnectionList.push_back( pConnection );
}

void CDSSyncSvc::AddConnection( CDSSyncSvc_Connection* pConnection )
{
	if( pConnection != NULL )
		m_ConnectionList.push_back( pConnection );
}

void CDSSyncSvc::AddAttributeMap( CDSSyncSvc_AttributeMap* pAttributeMap )
{
	if( pAttributeMap != NULL )
		m_AttributeMapList.push_back( pAttributeMap );
}

void CDSSyncSvc::RemoveConnection( LPCTSTR szConnectionName )
{
	CONNECTIONLIST::iterator iterEnd = m_ConnectionList.end( );
	for( CONNECTIONLIST::iterator iter = m_ConnectionList.begin( ); iter != iterEnd; iter++ )
	{
		CDSSyncSvc_Connection* pConnection = *iter;
		if( pConnection != NULL )
		{
			if( _tcsicmp( szConnectionName, pConnection->m_strName.Get( ).c_str( ) ) == 0 )
			{
				m_ConnectionList.erase( iter );
				delete pConnection;
				return;
			}
		}
	}
}

void CDSSyncSvc::RemoveAttributeMap( LPCTSTR szMapName )
{
	ATTRIBUTEMAPLIST::iterator iterEnd = m_AttributeMapList.end( );
	for( ATTRIBUTEMAPLIST::iterator iter = m_AttributeMapList.begin( ); iter != iterEnd; iter++ )
	{
		CDSSyncSvc_AttributeMap* pAttributeMap = *iter;
		if( pAttributeMap != NULL )
		{
			if( _tcsicmp( szMapName, pAttributeMap->m_strMapName.Get( ).c_str( ) ) == 0 )
			{
				m_AttributeMapList.erase( iter );
				delete pAttributeMap;
				return;
			}
		}
	}
}

// This method is exactly like base clas method
// but has the LoadFromRegistry() commented out
bool
CDSSyncSvc::GetServiceConfiguration(NrString& strLogonID_, NrString& strPassword_, bool &bAutoStartup_)
{
	SC_HANDLE		hService = GetServiceHandle();
	DWORD			dwBytesNeeded;

	if (hService == NULL)
		return false;

	if (::QueryServiceConfig(hService, m_serviceConfig, sizeof(m_serviceConfigBuf), &dwBytesNeeded) == 0)
	{
		LastErrorString		strError;
		IM::NrString strErrorMsg(TEXT("Could not get service startup information. "));
		strErrorMsg += strError;

		Event(ECAT_CONFIG, EVW_GENERIC, strErrorMsg.c_str());
		LogMessage(LM_ERROR, strErrorMsg.c_str());

		::CloseServiceHandle(hService);
		return false;
	}

	::CloseServiceHandle(hService);

	//LoadFromRegistry();


	NrString	strServiceLogonID(m_serviceConfig->lpServiceStartName);

	if (_tcsncmp(strLogonID_.c_str(), TEXT(".\\"), 2) == 0)	// strip the .\ from .\UserName
	{
		strServiceLogonID = strServiceLogonID.TrimLeft(TEXT('.'));
		strServiceLogonID = strServiceLogonID.TrimLeft(TEXT('\\'));
	}

	strLogonID_ = strServiceLogonID.c_str();
	strPassword_ = m_strPassword.Get();
	bAutoStartup_ = (m_serviceConfig->dwStartType == SERVICE_AUTO_START) ? true : false;

	return true;
}

void CDSSyncSvc::LoadFromRegistry( )
{
	// call base class
	RegistryMap::LoadFromRegistry( );

	// Enforce a max value of 500
	if( m_lPageSize.Get() > 500 )
		m_lPageSize.Set( 500 );

	//
	// Process computed fields
	//
	for (int day = 0; day < 7; day++)
	{
		for (int hour = 0; hour < 12; hour++)
		{
			if (m_strSchedule.Get().find(pattern[day][hour]) != -1)
				m_bScheduleTable[day][hour].Set(true);
		}
	}

	RemoveAllConnections( );
	RemoveAllAttributeMaps( );

	{
		IM::Registry reg( GetComputerName( ).c_str( ), GetDesiredHive( ), GetBaseKeyPath( ).c_str( ) );
		reg.AddPath( KEY_DSSYNCSVC_CONNECTIONS );

		reg.OpenOrCreate( NULL, KEY_READ );

		IM::NrString strSubkey;
		while( reg.EnumerateKey( strSubkey ) )
		{
			IM::NrString strPath = GetBaseKeyPath( );
			strPath += KEY_DSSYNCSVC_CONNECTIONS;
			strPath += _T( "\\" );
			strPath += strSubkey;

			CDSSyncSvc_Connection* pConnection = im_new CDSSyncSvc_Connection( GetComputerName( ).c_str( ), GetDesiredHive( ), strPath.c_str( ) );

			pConnection->LoadFromRegistry( );

			m_ConnectionList.push_back( pConnection );
		}

		reg.Close( );
	}

	{
		IM::Registry reg( GetComputerName( ).c_str( ), GetDesiredHive( ), GetBaseKeyPath( ).c_str( ) );
		reg.AddPath( KEY_DSSYNCSVC_ATTRIBUTEMAPS );

		reg.OpenOrCreate( NULL, KEY_READ );

		IM::NrString strSubkey;
		while( reg.EnumerateKey( strSubkey ) )
		{
			IM::NrString strPath = GetBaseKeyPath( );
			strPath += KEY_DSSYNCSVC_ATTRIBUTEMAPS;
			strPath += _T( "\\" );
			strPath += strSubkey;

			CDSSyncSvc_AttributeMap* pAttributeMap = im_new CDSSyncSvc_AttributeMap( GetComputerName( ).c_str( ), GetDesiredHive( ), strPath.c_str( ) );

			pAttributeMap->LoadFromRegistry( );

			m_AttributeMapList.push_back( pAttributeMap );
		}

		reg.Close( );
	}

}

void CDSSyncSvc::LoadFromRegistry_AttributeMapsOnly()
{
	RemoveAllAttributeMaps( );
	{
		IM::Registry reg( GetComputerName( ).c_str( ), GetDesiredHive( ), GetBaseKeyPath( ).c_str( ) );
		reg.AddPath( KEY_DSSYNCSVC_ATTRIBUTEMAPS );

		reg.OpenOrCreate( NULL, KEY_READ );

		IM::NrString strSubkey;
		while( reg.EnumerateKey( strSubkey ) )
		{
			IM::NrString strPath = GetBaseKeyPath( );
			strPath += KEY_DSSYNCSVC_ATTRIBUTEMAPS;
			strPath += _T( "\\" );
			strPath += strSubkey;

			CDSSyncSvc_AttributeMap* pAttributeMap = im_new CDSSyncSvc_AttributeMap( GetComputerName( ).c_str( ), GetDesiredHive( ), strPath.c_str( ) );

			pAttributeMap->LoadFromRegistry( );

			m_AttributeMapList.push_back( pAttributeMap );
		}

		reg.Close( );
	}
}

void CDSSyncSvc::StoreInRegistry_AttributeMapsOnly()
{
	ATTRIBUTEMAPLIST::const_iterator iterEnd = m_AttributeMapList.end( );
	for( ATTRIBUTEMAPLIST::const_iterator iter = m_AttributeMapList.begin( ); iter != iterEnd; iter++ )
	{
		CDSSyncSvc_AttributeMap* pAttributeMap = *iter;
		if( pAttributeMap != NULL )
			pAttributeMap->StoreInRegistry( );
	}
}

void CDSSyncSvc::DeleteFromRegistry_AttributeMapsOnly()
{
	ATTRIBUTEMAPLIST::const_iterator iterEnd = m_AttributeMapList.end( );
	for( ATTRIBUTEMAPLIST::const_iterator iter = m_AttributeMapList.begin( ); iter != iterEnd; iter++ )
	{
		CDSSyncSvc_AttributeMap* pAttributeMap = *iter;
		if( pAttributeMap != NULL )
		{
			IM::Registry reg( GetComputerName( ).c_str( ), GetDesiredHive( ), GetBaseKeyPath( ).c_str( ) );
			reg.AddPath( KEY_DSSYNCSVC_ATTRIBUTEMAPS );

			reg.Open( NULL, KEY_WRITE );
			reg.DeleteSubKey( pAttributeMap->m_strMapName.Get( ).c_str( ) );
			reg.Close( );
		}
	}
}

void CDSSyncSvc::StoreInRegistry( )
{
	NrCiString		strSchedule;

	//
	// Take computed fields and push data in registry property objects.
	//
	for( int day = 0; day < 7; day++ )
	{
		for( int hour = 0; hour < 12; hour++ )
		{
			if( m_bScheduleTable[ day ][ hour ].Get( ) == true )
			{
				strSchedule += pattern[ day ][ hour ];
				strSchedule += TEXT( ", " );
			}
		}
	}

	m_strSchedule.Set(strSchedule);

	// call base class
	RegistryMap::StoreInRegistry( );

	{
		CONNECTIONLIST::const_iterator iterEnd = m_ConnectionList.end( );
		for( CONNECTIONLIST::const_iterator iter = m_ConnectionList.begin( ); iter != iterEnd; iter++ )
		{
			CDSSyncSvc_Connection* pConnection = *iter;
			if( pConnection != NULL )
				pConnection->StoreInRegistry( );
		}
	}

	{
		ATTRIBUTEMAPLIST::const_iterator iterEnd = m_AttributeMapList.end( );
		for( ATTRIBUTEMAPLIST::const_iterator iter = m_AttributeMapList.begin( ); iter != iterEnd; iter++ )
		{
			CDSSyncSvc_AttributeMap* pAttributeMap = *iter;
			if( pAttributeMap != NULL )
				pAttributeMap->StoreInRegistry( );
		}
	}
}

void CDSSyncSvc::DeleteFromRegistry( )
{
		{
			CONNECTIONLIST::const_iterator iterEnd = m_ConnectionList.end( );
			for( CONNECTIONLIST::const_iterator iter = m_ConnectionList.begin( ); iter != iterEnd; iter++ )
			{
				CDSSyncSvc_Connection* pConnection = *iter;
				if( pConnection != NULL )
				{
					pConnection->DeleteFromRegistry( );

					IM::Registry reg( GetComputerName( ).c_str( ), GetDesiredHive( ), GetBaseKeyPath( ).c_str( ) );
					reg.AddPath( KEY_DSSYNCSVC_CONNECTIONS );

					reg.Open( NULL, KEY_WRITE );
					reg.DeleteSubKey( pConnection->m_strName.Get( ).c_str( ) );
					reg.Close( );
				}
			}
		}

		{
			ATTRIBUTEMAPLIST::const_iterator iterEnd = m_AttributeMapList.end( );
			for( ATTRIBUTEMAPLIST::const_iterator iter = m_AttributeMapList.begin( ); iter != iterEnd; iter++ )
			{
				CDSSyncSvc_AttributeMap* pAttributeMap = *iter;
				if( pAttributeMap != NULL )
				{
					pAttributeMap->DeleteFromRegistry( );

					IM::Registry reg( GetComputerName( ).c_str( ), GetDesiredHive( ), GetBaseKeyPath( ).c_str( ) );
					reg.AddPath( KEY_DSSYNCSVC_ATTRIBUTEMAPS );

					reg.Open( NULL, KEY_WRITE );
					reg.DeleteSubKey( pAttributeMap->m_strMapName.Get( ).c_str( ) );
					reg.Close( );
				}
			}
		}

		Open( NULL, KEY_WRITE );
		DeleteSubKey( KEY_DSSYNCSVC_ATTRIBUTEMAPS2 );
		DeleteSubKey( KEY_DSSYNCSVC_CONNECTIONS2 );

		// call base class
		//RegistryMap::DeleteFromRegistry( );

		RemoveAllConnections( );
		RemoveAllAttributeMaps( );
}

bool CDSSyncSvc::ConnectionExists( LPCTSTR szConnectionName ) const
{
	CONNECTIONLIST::const_iterator iterEnd = m_ConnectionList.end( );
	for( CONNECTIONLIST::const_iterator iter = m_ConnectionList.begin( ); iter != iterEnd; iter++ )
	{
		CDSSyncSvc_Connection* pConnection = *iter;
		if( pConnection != NULL )
		{
			if( _tcsicmp( ( LPCTSTR ) szConnectionName, ( LPCTSTR ) pConnection->m_strName.Get( ).c_str( ) ) == 0 )
			{
				return true;
			}
		}
	}

	return false;
}

bool CDSSyncSvc::AttributeMapExists( LPCTSTR szMapName ) const
{
	ATTRIBUTEMAPLIST::const_iterator iterEnd = m_AttributeMapList.end( );
	for( ATTRIBUTEMAPLIST::const_iterator iter = m_AttributeMapList.begin( ); iter != iterEnd; iter++ )
	{
		CDSSyncSvc_AttributeMap* pAttributeMap = *iter;
		if( pAttributeMap != NULL )
		{
			if( _tcsicmp( ( LPCTSTR ) szMapName, ( LPCTSTR ) pAttributeMap->m_strMapName.Get( ).c_str( ) ) == 0 )
			{
				return true;
			}
		}
	}

	return false;
}

CDSSyncSvc_Connection* CDSSyncSvc::FindConnection( LPCTSTR szConnectionName ) const
{
	CONNECTIONLIST::const_iterator iterEnd = m_ConnectionList.end( );
	for( CONNECTIONLIST::const_iterator iter = m_ConnectionList.begin( ); iter != iterEnd; iter++ )
	{
		CDSSyncSvc_Connection* pConnection = *iter;
		if( pConnection != NULL )
		{
			if( _tcsicmp( ( LPCTSTR ) szConnectionName, ( LPCTSTR ) pConnection->m_strName.Get( ).c_str( ) ) == 0 )
			{
				return pConnection;
			}
		}
	}

	return NULL;
}

CDSSyncSvc_AttributeMap* CDSSyncSvc::FindAttributeMap( LPCTSTR szMapName ) const
{
	ATTRIBUTEMAPLIST::const_iterator iterEnd = m_AttributeMapList.end( );
	for( ATTRIBUTEMAPLIST::const_iterator iter = m_AttributeMapList.begin( ); iter != iterEnd; iter++ )
	{
		CDSSyncSvc_AttributeMap* pAttributeMap = *iter;
		if( pAttributeMap != NULL )
		{
			if( _tcsicmp( ( LPCTSTR ) szMapName, ( LPCTSTR ) pAttributeMap->m_strMapName.Get( ).c_str( ) ) == 0 )
			{
				return pAttributeMap;
			}
		}
	}

	return NULL;
}

bool CDSSyncSvc::Test( void )
{
	bool bRetval = true;

	TCHAR szComputerName[ 256 ];
	memset( szComputerName, 256, sizeof( TCHAR ) * 256 );
	DWORD dwSize = 256;
	::GetComputerName( szComputerName, &dwSize );

	CDSSyncSvc svc( szComputerName );

	svc.AddAttributeMap( 
		_T( "Map1" ),
		_T( "OU1" ),
		_T( "UserName1" ),
		_T( "UserId1" ),
		_T( "UserEmail1" ),
		_T( "UserFax1" ),
		_T( "UserTelephone1" ),
		_T( "UserLocation1" ),
		_T( "UserEnabled" ),
		_T( "GroupName1" ),
		_T( "GroupId1" ),
		_T( "GroupMember1" ),
		_T( "K1SyncId1" ) 
		);

	svc.AddAttributeMap( 
		_T( "Map2" ),
		_T( "OU2" ),
		_T( "UserName2" ),
		_T( "UserId2" ),
		_T( "UserEmail2" ),
		_T( "UserFax2" ),
		_T( "UserTelephone2" ),
		_T( "UserLocation2" ),
		_T( "UserEnabled" ),
		_T( "GroupName2" ),
		_T( "GroupId2" ),
		_T( "GroupMember2" ),
		_T( "K2SyncId2" ) 
		);

	svc.AddConnection(
		_T( "Connection1" ),
		_T( "Node1" ),
		_T( "Map1" ),
		_T( "" ),
		_T( "DmsServer1" ),
		_T( "DmsLibrary1" ),
		_T( "DmsUserId1" ),
		_T( "DmsPassword1" ),
		1080, 0, 
		_T( "DSServer1" ),
		_T( "DSUserId1" ),
		_T( "DSPassword1" ),
		_T( "mhdocs" ),
		false,
		true,
		1,
		2,
		_T( "sdf" ),
		_T( "ExternalDNs1" ),
		_T( "TreeID1" )
		);

	svc.AddConnection(
		_T( "Connection2" ),
		_T( "Node2" ),
		_T( "Map2" ),
		_T( "" ),
		_T( "DmsServer2" ),
		_T( "DmsLibrary2" ),
		_T( "DmsUserId2" ),
		_T( "DmsPassword2" ),
		1080, 1, 
		_T( "DSServer2" ),
		_T( "DSUserId2" ),
		_T( "DSPassword2" ),
		_T( "mhdocs" ),
		false,
		true,
		11,
		22,
		_T( "sdf" ),
		_T( "ExternalDNs" ),
		_T( "TreeID2" )
		);

	// copy construct
	CDSSyncSvc svc2( svc );
	
	// test store
	svc.StoreInRegistry( );

	// test load
	CDSSyncSvc svc3( szComputerName );
	svc3.LoadFromRegistry( );

	// test delete
	svc.DeleteFromRegistry( );

	// verify that delete worked
	{
		IM::Registry reg( szComputerName, HKEY_LOCAL_MACHINE, KEY_DSSYNCSVC_PATH );
		reg.Open( NULL, KEY_READ );
		IM::NrString strSubkey;
		while( reg.EnumerateKey( strSubkey ) )
		{
			// if any subkeys are found
			// then last call to DeleteFromRegistry failed somewhere

			return false;
		}
		reg.Close( );
	}

	// compare svc3 and svc2
	if( !( svc2 == svc3 ) )
		bRetval = false;
	
	// remove test key
	{
		IM::Registry reg( szComputerName, HKEY_LOCAL_MACHINE, KEY_DSSYNCSVC_PATH );
		reg.Open( NULL, KEY_WRITE );
		reg.DeleteSubKey( KEY_DSSYNCSVC_PATH );
		reg.Close( );
	}

	return bRetval;
}
