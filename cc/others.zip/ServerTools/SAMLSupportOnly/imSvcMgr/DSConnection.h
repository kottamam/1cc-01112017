#if !defined(AFX_DSCONNECTION_H__A22F5732_965E_4138_A75B_16F854F4085A__INCLUDED_)
#define AFX_DSCONNECTION_H__A22F5732_965E_4138_A75B_16F854F4085A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DSConnection.h : header file
//

// COM/ATL includes
#include <comdef.h>
#include <comutil.h>
#include <tchar.h>
#include <assert.h>
#include "EditListBox.h"

// LDAP library includes
#include <imLdap/imLdap.h>
#include "E:\sourcecode\work-server\ics3p\MS_VC12\atlmfc\include\afxwin.h"




namespace DSLocal
{
	class CDSSyncSvc_AttributeMap;
	class CDSSyncSvc_DSParameters;
	class CDSSyncSvc_DMSParameters;
	class CDSSyncSvc_Connection;
	class CDSSyncSvc;
}


/////////////////////////////////////////////////////////////////////////////
// DSConnection dialog

class DSConnection : public CDialog
{
// Construction
public:
	DSConnection(CWnd* pParent = NULL);   // standard constructor
	virtual ~DSConnection( void );		// destructor

	void SetRegistryObjects( IM::CDSSyncSvc* pSyncSvc, IM::CDSSyncSvc_Connection* pConnection );
	void UpdateAttributeMap(IM::CDSSyncSvc_AttributeMap* pAttributeMapLocal, IM::CDSSyncSvc_AttributeMap* pAttributeMap);
	CString m_strServer;

	typedef enum tagMode
	{
		Edit = 0,
		Add = 1,
	} Mode;

	Mode m_Mode;

	CStringList m_OtherConnectionNames;

// Dialog Data
	//{{AFX_DATA(DSConnection)
	enum { IDD = IDD_DS_CONNECTION };
	CStatic m_stcLabelBlank;
	CStatic	m_stcPasswordMatchNot;
	CStatic	m_stcPasswordMatch;
	CButton	m_btnTest;
	CComboBox	m_cboNtDomain;
	CEdit	m_edtContext;
	CStatic m_stcLabelContext;
	CEdit	m_edtDefaultPasswordConfirm;
	CEdit	m_edtDefaultPassword;
	CButton	m_btnDefaultPasswordNeverExpires;
	CButton	m_btnDefaultMustChangePassword;
	CEdit	m_edtDmsTcpip;
	CButton	m_btnEdit;
	CButton	m_btnDelete;
	CButton	m_rdoDmsTcpip;
	
	CButton	m_rdoDmsOtherTcpip;
	CButton m_rdoDSLogin1;
	CButton m_rdoDSLogin2;
	CEdit	m_edtNode;
	CEdit	m_edtNameDesc;
	CEdit	m_edtDsUser;
	CEdit	m_edtDsTcpip;
	CEdit	m_edtDsServer;
	CEdit	m_edtDsPassword;
	CEdit	m_edtDmsUser;
	CEdit	m_edtDmsServer;
	CEdit	m_edtDmsPassword;
	CEdit	m_edtDmsLibrary;
	CComboBox	m_cboDSServerType;
	CComboBox	m_cboAttributeMaps;
	CButton	m_btnBrowse;
	CButton	m_btnAdd;
	CButton	m_btnCancel;
	CButton	m_btnHelp;
	CButton	m_btnOk;
	CEditListBox   m_listExternalDNs;
	CStatic m_stcLabelTreeID;
	CStatic m_strServerName;
	CEdit	m_edtTreeID;
	bool	m_bEnableSSL;
	CString csDmsUserName;

	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(DSConnection)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
public:
	ObjectContainers::CUniqueBstrVector m_vDomainNames;

protected:
	IM::CDSSyncSvc* m_pSyncSvc_Local;
	IM::CDSSyncSvc_Connection* m_pConnection_Local;

	bool TestLdapLogin();

	void PopulateDlgFromConnection( void );
	void PopulateAttributeMapsComboBox( void );
	void PopulateServerTypesComboBox( void );
	bool UpdateConnectionFromDlg( IM::CDSSyncSvc_Connection* pConnection );
	void EnableConnectionControls( );
	void UpdateRegistryPath( IM::CDSSyncSvc_AttributeMap* pAttributeMap );
	void SetADSCredentials( bool bUseServiceLogin );

	// Generated message map functions
	//{{AFX_MSG(DSConnection)
	virtual void OnOK();
	afx_msg void OnHelp();
	virtual void OnCancel();
	virtual BOOL OnInitDialog();
	afx_msg void OnButtonAdd();
	afx_msg void OnButtonBrowse();
	afx_msg void OnButtonEdit();
	afx_msg void OnButtonDelete();
	afx_msg void OnSelchangeComboDsServerType();
	afx_msg void OnSelchangeComboAttributeMaps();
	afx_msg void OnRadioDmsDefaultPort();
	afx_msg void OnRadioDmsOtherPort();
	afx_msg void OnEditchangeComboNtDomain();
	afx_msg void OnCheckDefaultMustChangePwd();
	afx_msg void OnButtonTestLogin();
	afx_msg void OnChangeGlobal();
	afx_msg void OnRadioDsLogin();
	afx_msg void OnSelchangeList();

	
	
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	
	CStatic m_lPasswordLabel;
	CStatic m_dmsUserNameLabel;
	
	
	CButton m_RadioIManageLogin;
	CButton m_RadioAdfsLogin;
	afx_msg void OnBnClickedRadioImanageLogin();
	afx_msg void OnBnClickedAdfsLogin();
	CStatic m_dmsPasswordText;
	
	
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DSCONNECTION_H__A22F5732_965E_4138_A75B_16F854F4085A__INCLUDED_)
