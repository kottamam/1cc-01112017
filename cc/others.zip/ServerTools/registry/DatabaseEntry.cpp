
#include <Registry\RegistryLib.h>
#pragma hdrstop

#include <Registry\DatabaseEntry.h>


using namespace IM;


#define KEY_LOGONID					TEXT("LogonID")
#define KEY_PASSWORD				TEXT("Password")
#define KEY_CONNECTION_COUNT		TEXT("Connection Count")
#define KEY_LOCATED_NEAR			TEXT("Located Near")
#define KEY_EQ_TO_THREADS			TEXT("Equal to Threads")
#define KEY_PRIMARY					TEXT("Primary")
#define KEY_USE_MAXDOP				TEXT("Use MAXDOP")
#define KEY_CONNECTION_TYPE			TEXT("Connection Type")
#define KEY_ALLOW_FLATSPACE			TEXT("Allow Flatspace Documents")

DatabaseEntry::DatabaseEntry(const TCHAR *szComputerName_, const TCHAR *szBaseKeyPath_, const TCHAR *szDatabaseName_)
			: RegistryMap(szComputerName_, HKEY_LOCAL_MACHINE, szBaseKeyPath_)
{
	m_strDatabase.Set(szDatabaseName_);

	m_strParentKeyPath = m_strBaseKeyPath;

	// update the registry map's knowledge of the base key path to point to the database itself
	m_strBaseKeyPath += TEXT("\\");
	m_strBaseKeyPath += szDatabaseName_;

	m_strLogonID.SetEncryptFlag(true);
	m_strPassword.SetEncryptFlag(true);

	m_lConnectionType.Set((long) IM::DatabaseEntry::ConnectionType::Database);

	m_propertyMap.insert(PropertyMap::value_type(KEY_LOGONID, &m_strLogonID));
	m_propertyMap.insert(PropertyMap::value_type(KEY_PASSWORD, &m_strPassword));
	m_propertyMap.insert(PropertyMap::value_type(KEY_CONNECTION_COUNT, &m_lConnectionCount));
	m_propertyMap.insert(PropertyMap::value_type(KEY_LOCATED_NEAR, &m_bLocatedNear));
	m_propertyMap.insert(PropertyMap::value_type(KEY_EQ_TO_THREADS, &m_bAsManyConnectionsAsThreads));
	m_propertyMap.insert(PropertyMap::value_type(KEY_PRIMARY, &m_bPrimary));
	m_propertyMap.insert(PropertyMap::value_type(KEY_USE_MAXDOP, &m_bUseMaxDop));
	m_propertyMap.insert(PropertyMap::value_type(KEY_CONNECTION_TYPE, &m_lConnectionType));
	m_propertyMap.insert(PropertyMap::value_type(KEY_ALLOW_FLATSPACE, &m_bAllowFlatSpaceDocuments));

	//
	//	These properties were incorrectly hard wired in DBConnectionPool and DBConnection class for DMS use
	//	They are defined here with default values for this integration to continue to work.
	//
	m_lConnectionCount.Set(2);
	m_bLocatedNear.Set(true);
	m_bUseMaxDop.Set(false);

	m_bAllowFlatSpaceDocuments.Set(true);
	m_bPrimary.Set(false);
	m_bAsManyConnectionsAsThreads.Set(false);
}

	DatabaseEntry::DatabaseEntry(const DatabaseEntry *pDatabaseEntry_)
		: RegistryMap(pDatabaseEntry_)
{
	m_lConnectionCount.Set(pDatabaseEntry_->m_lConnectionCount.Get());
	m_bLocatedNear.Set(pDatabaseEntry_->m_bLocatedNear.Get());
	m_bAsManyConnectionsAsThreads.Set(pDatabaseEntry_->m_bAsManyConnectionsAsThreads.Get());
	m_bPrimary.Set(pDatabaseEntry_->m_bPrimary.Get());
	m_bUseMaxDop.Set(pDatabaseEntry_->m_bUseMaxDop.Get());
	m_lConnectionType.Set(pDatabaseEntry_->m_lConnectionType.Get());
}

void
DatabaseEntry::RemoveFromRegistry()
{
	//
	//	iterate through all name value pairs and delete them
	//
	DeleteFromRegistry();

	Registry	dbReg(m_strComputerName.c_str(), HKEY_LOCAL_MACHINE, m_strParentKeyPath.c_str());

	dbReg.Open(NULL, KEY_ALL_ACCESS);
	dbReg.DeleteSubKey(m_strDatabase.Get().c_str());
	dbReg.Close();
}




///////////////////////////////////////////////////////////////////////////////
//
//	DatabaseEntryList base class and derived classes
//
///////////////////////////////////////////////////////////////////////////////

DatabaseEntryList::DatabaseEntryList(const _TCHAR *szComputerName_, const _TCHAR *szBaseKeyPath_) :
					m_strBaseKeyPath(szBaseKeyPath_)
{
	if (szComputerName_ == NULL)
	{
		Registry		dbReg(szComputerName_, HKEY_LOCAL_MACHINE, m_strBaseKeyPath.c_str());

		m_strComputerName = dbReg.m_strComputerName;
	}
	else
	{
		m_strComputerName = szComputerName_;
	}

}


void
DatabaseEntryList::ClearList()
{
	for( DatabaseEntryList::iterator iterator=begin();
									 iterator!=end();
									 iterator++)
		delete iterator->get();

	erase(begin(), end());
}


void
DatabaseEntryList::LoadAll()
{
	Registry		dbReg(m_strComputerName.c_str(), HKEY_LOCAL_MACHINE, m_strBaseKeyPath.c_str());
	NrString		strDatabase;


	ClearList();


	// open registry to enumerate the configured databases
	if (dbReg.OpenOrCreate(NULL, KEY_ALL_ACCESS) != true)
	{
		throw_error(GetLastError(), _T("Could not open/create Registry key for database information"));
	}


	while (dbReg.EnumerateKey(strDatabase) == true)
	{
		DatabaseEntry	*pEntry = NewEntry(strDatabase.c_str());

		pEntry->LoadFromRegistry();
		push_back(IM::STLPointer<DatabaseEntry>(static_cast<DatabaseEntry *>(pEntry)));
	}
}


DatabaseEntry *
DatabaseEntryList::Get(const _TCHAR *strDatabase_)
{
	DatabaseEntryListIterator	it;
	DatabaseEntry				*pEntry;

	for (it = begin(); it != end(); ++it)
	{
		pEntry = it->get();

		if (pEntry->m_strDatabase.Get().compare(strDatabase_) == 0)
			return pEntry;
	}

	return NULL;
}


void
DatabaseEntryList::Remove(const _TCHAR *strDatabase_)
{
	DatabaseEntryListIterator	it;
	DatabaseEntry				*pEntry;

	for (it = begin(); it != end(); ++it)
	{
		pEntry = it->get();

		if (pEntry->m_strDatabase.Get().compare(strDatabase_) == 0)
		{
			// remove the entry from the registry
			pEntry->RemoveFromRegistry();

			erase(it);
			break;	// reset iterator after erase
		}
	}

	return;
}



void
DatabaseEntryList::Add(DatabaseEntry *pEntry_)
{
	// remove any existing entry for the same database
	Remove(pEntry_->m_strDatabase.Get().c_str());

	pEntry_->StoreInRegistry();
	push_back(IM::STLPointer<DatabaseEntry>(static_cast<DatabaseEntry *>(pEntry_)));

	return;
}


