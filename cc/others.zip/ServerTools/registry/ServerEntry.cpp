
#include <Registry\RegistryLib.h>
#pragma hdrstop
#include <Registry\RegClass.h>
#include <Registry\RegistryMap.h>
#include <Registry\ServerEntry.h>


using namespace IM;

//
// ServerEntry
//
#define KEY_SPECIFY_PORT	TEXT("SpecifyPort")
#define KEY_PORT			TEXT("Port")
#define KEY_USERNAME		TEXT("Username")
#define KEY_PASSWORD		TEXT("Password")
#define KEY_MAXFOLDERLIST	TEXT("Max Folder List")
#define KEY_TIMEOUT			TEXT("Timeout")
#define KEY_TRUSTED_LOGIN	TEXT("TrustedLogin") //Vinod


const NrString	ServerEntry::ms_strDefaultServerName = "";
const bool		ServerEntry::ms_bDefaultSpecifyPort = false;
const long		ServerEntry::ms_lDefaultPort = 1080;
const NrString	ServerEntry::ms_strDefaultUsername = "";
const NrString	ServerEntry::ms_strDefaultPassword = "";
const long		ServerEntry::ms_lDefaultMaxFolderList = 10000;
const long		ServerEntry::ms_lDefaultTimeout = 30;
const bool		ServerEntry::ms_bDefaultTrustedLogin = false; //Vinod


ServerEntry::ServerEntry(const TCHAR *szComputerName_, const TCHAR *szBaseKeyPath_, const TCHAR *szServerName_)
			:	RegistryMap(szComputerName_, HKEY_LOCAL_MACHINE, szBaseKeyPath_),
				m_bSpecifyPort(ms_bDefaultSpecifyPort),
				m_lPort(ms_lDefaultPort),
				m_strUsername(ms_strDefaultUsername.c_str()),
				m_strPassword(ms_strDefaultPassword.c_str()),
				m_lMaxFolderList(ms_lDefaultMaxFolderList),
				m_lTimeout(ms_lDefaultTimeout),
				m_bTrustedLogin(ms_bDefaultTrustedLogin) //Vinod

{
	m_strServerName.Set(szServerName_);

	m_strParentKeyPath = m_strBaseKeyPath;

	// update the registry map's knowledge of the base key path to point to the server itself
	m_strBaseKeyPath += TEXT("\\");
	m_strBaseKeyPath += szServerName_;

	m_strUsername.SetEncryptFlag(true);
	m_strPassword.SetEncryptFlag(true);

	m_propertyMap.insert(PropertyMap::value_type(KEY_SPECIFY_PORT, &m_bSpecifyPort));
	m_propertyMap.insert(PropertyMap::value_type(KEY_PORT, &m_lPort));
	m_propertyMap.insert(PropertyMap::value_type(KEY_USERNAME, &m_strUsername));
	m_propertyMap.insert(PropertyMap::value_type(KEY_PASSWORD, &m_strPassword));
	m_propertyMap.insert(PropertyMap::value_type(KEY_MAXFOLDERLIST, &m_lMaxFolderList));
	m_propertyMap.insert(PropertyMap::value_type(KEY_TIMEOUT, &m_lTimeout));
	m_propertyMap.insert(PropertyMap::value_type(KEY_TRUSTED_LOGIN, &m_bTrustedLogin));//Vinod
}


	ServerEntry::ServerEntry(const ServerEntry& ServerEntry_)
		: RegistryMap((RegistryMap *)&ServerEntry_)
{
	m_strParentKeyPath = ServerEntry_.m_strParentKeyPath;

	m_propertyMap.clear();

	IM::NrCiString strTemp = ServerEntry_.m_strServerName.Get();
	m_strServerName.Set(strTemp);

	strTemp = ServerEntry_.m_strUsername.Get();
	m_strUsername.Set(strTemp);
	m_strUsername.SetEncryptFlag(true);

	strTemp = ServerEntry_.m_strPassword.Get();
	m_strPassword.Set(strTemp);
	m_strPassword.SetEncryptFlag(true);

	m_bSpecifyPort.Set(ServerEntry_.m_bSpecifyPort.Get());
	m_lPort.Set(ServerEntry_.m_lPort.Get());
	m_lMaxFolderList.Set(ServerEntry_.m_lMaxFolderList.Get());
	m_lTimeout.Set(ServerEntry_.m_lTimeout.Get());
	m_bTrustedLogin.Set(ServerEntry_.m_bTrustedLogin.Get());//Vinod

	m_propertyMap.insert(PropertyMap::value_type(KEY_SPECIFY_PORT, &m_bSpecifyPort));
	m_propertyMap.insert(PropertyMap::value_type(KEY_PORT, &m_lPort));
	m_propertyMap.insert(PropertyMap::value_type(KEY_USERNAME, &m_strUsername));
	m_propertyMap.insert(PropertyMap::value_type(KEY_PASSWORD, &m_strPassword));
	m_propertyMap.insert(PropertyMap::value_type(KEY_MAXFOLDERLIST, &m_lMaxFolderList));
	m_propertyMap.insert(PropertyMap::value_type(KEY_TIMEOUT, &m_lTimeout));
	m_propertyMap.insert(PropertyMap::value_type(KEY_TRUSTED_LOGIN, &m_bTrustedLogin));//Vinod
}


ServerEntry&
ServerEntry::operator=(const ServerEntry& ServerEntry_)
{
	m_strParentKeyPath = ServerEntry_.m_strParentKeyPath;

	// destruct existing property map
	PropertyMap::iterator	it;

	for (it = m_propertyMap.begin(); it != m_propertyMap.end(); it++)
	{
		RegistryProperty	*pRegistryProperty;

		pRegistryProperty = (*it).second;

		if (pRegistryProperty->IsInHeap() == true)
		{
			delete pRegistryProperty;
		}
	}
	m_propertyMap.clear();

	IM::NrCiString strTemp = ServerEntry_.m_strServerName.Get();
	m_strServerName.Set(strTemp);

	strTemp = ServerEntry_.m_strUsername.Get();
	m_strUsername.Set(strTemp);
	m_strUsername.SetEncryptFlag(true);

	strTemp = ServerEntry_.m_strPassword.Get();
	m_strPassword.Set(strTemp);
	m_strPassword.SetEncryptFlag(true);

	m_bSpecifyPort.Set(ServerEntry_.m_bSpecifyPort.Get());
	m_lPort.Set(ServerEntry_.m_lPort.Get());
	m_lMaxFolderList.Set(ServerEntry_.m_lMaxFolderList.Get());
	m_lTimeout.Set(ServerEntry_.m_lTimeout.Get());
	m_bTrustedLogin.Set(ServerEntry_.m_bTrustedLogin.Get());//Vinod

	m_propertyMap.insert(PropertyMap::value_type(KEY_SPECIFY_PORT, &m_bSpecifyPort));
	m_propertyMap.insert(PropertyMap::value_type(KEY_PORT, &m_lPort));
	m_propertyMap.insert(PropertyMap::value_type(KEY_USERNAME, &m_strUsername));
	m_propertyMap.insert(PropertyMap::value_type(KEY_PASSWORD, &m_strPassword));
	m_propertyMap.insert(PropertyMap::value_type(KEY_MAXFOLDERLIST, &m_lMaxFolderList));
	m_propertyMap.insert(PropertyMap::value_type(KEY_TIMEOUT, &m_lTimeout));
	m_propertyMap.insert(PropertyMap::value_type(KEY_TRUSTED_LOGIN, &m_bTrustedLogin));//Vinod

	return *this;
}


void
ServerEntry::RemoveFromRegistry()
{
	//
	//	iterate through all name value pairs and delete them
	//
	DeleteFromRegistry();

	//
	// delete self
	//
	Registry svrReg(m_strComputerName.c_str(), HKEY_LOCAL_MACHINE, m_strParentKeyPath.c_str());

	svrReg.Open(NULL, KEY_ALL_ACCESS);
	svrReg.DeleteSubKey(m_strServerName.Get().c_str());
	svrReg.Close();
}

void
ServerEntry::LogRegistry() const
{
	m_strServerName.LogProperty(TEXT("Server Name"));

	RegistryMap::LogRegistry();
}



//
// EmsDatabaseEntry
//

const NrString EmsDatabaseEntry::ms_strDefaultDatabaseName = "";
const NrString EmsDatabaseEntry::ms_strServersSubkey = "Servers";


EmsDatabaseEntry::EmsDatabaseEntry(const TCHAR *szComputerName_, const TCHAR *szBaseKeyPath_, const TCHAR *szDatabaseName_)
			:	RegistryMap(szComputerName_, HKEY_LOCAL_MACHINE, szBaseKeyPath_)
{
	m_strDatabaseName.Set(szDatabaseName_);

	m_strParentKeyPath = m_strBaseKeyPath;

	// update the registry map's knowledge of the base key path to point to the server itself
	m_strBaseKeyPath += TEXT("\\");
	m_strBaseKeyPath += szDatabaseName_;

}


	EmsDatabaseEntry::EmsDatabaseEntry(const EmsDatabaseEntry& EmsDatabaseEntry_)
		: RegistryMap(EmsDatabaseEntry_)
{
	m_strParentKeyPath = EmsDatabaseEntry_.m_strParentKeyPath;

	m_strDatabaseName	= EmsDatabaseEntry_.m_strDatabaseName;

	m_Servers.clear();

	for (imstd::vector<ServerEntry>::const_iterator	i  = EmsDatabaseEntry_.m_Servers.begin();
													i != EmsDatabaseEntry_.m_Servers.end();
													i++)
	{
		m_Servers.push_back(*i);
	}
}


EmsDatabaseEntry&
EmsDatabaseEntry::operator=(const EmsDatabaseEntry& EmsDatabaseEntry_)
{
	m_strParentKeyPath = EmsDatabaseEntry_.m_strParentKeyPath;

	(void) RegistryMap::operator=(EmsDatabaseEntry_);

	m_strDatabaseName	= EmsDatabaseEntry_.m_strDatabaseName;

	m_Servers.clear();

	for (imstd::vector<ServerEntry>::const_iterator	i  = EmsDatabaseEntry_.m_Servers.begin();
													i != EmsDatabaseEntry_.m_Servers.end();
													i++)
	{
		m_Servers.push_back(*i);
	}

	return *this;
}


void
EmsDatabaseEntry::RemoveFromRegistry()
{
	//
	//	iterate through all name value pairs and delete them
	//
	DeleteFromRegistry();

	//
	// iterate through server sub-keys and have them delete themselves
	//
	for (imstd::vector<ServerEntry>::iterator	it = m_Servers.begin();
												it != m_Servers.end();
												it++)
		it->RemoveFromRegistry();

	//
	// delete "Servers"
	//
	NrString strServerKeyPath = m_strParentKeyPath;
	strServerKeyPath += TEXT("\\");
	strServerKeyPath += m_strDatabaseName.Get();	
	Registry svrReg(m_strComputerName.c_str(), HKEY_LOCAL_MACHINE, strServerKeyPath.c_str());

	svrReg.Open(NULL, KEY_ALL_ACCESS);
	svrReg.DeleteSubKey(ms_strServersSubkey.c_str());
	svrReg.Close();


	//
	// delete self
	//
	Registry dbReg(m_strComputerName.c_str(), HKEY_LOCAL_MACHINE, m_strParentKeyPath.c_str());

	dbReg.Open(NULL, KEY_ALL_ACCESS);
	dbReg.DeleteSubKey(m_strDatabaseName.Get().c_str());
	dbReg.Close();
}


void
EmsDatabaseEntry::AddServerToRegistry(	NrString&	strServerName_,
										bool		bSpecifyPort_,
										long		lPort_,
										NrString&	strUsername_,
										NrString&	strPassword_,
										long		lMaxFolderList_
										)
{
	RemoveServerFromRegistry(strServerName_);

	// update the registry map's knowledge of the base key path to point to the server itself
	NrString strServerPath = m_strBaseKeyPath;
	strServerPath += TEXT("\\");
	strServerPath += ms_strServersSubkey.c_str();

	ServerEntry serverEntry(m_strComputerName.c_str(), strServerPath.c_str(), strServerName_.c_str());

 	serverEntry.m_strServerName.Set(strServerName_.c_str());
	serverEntry.m_bSpecifyPort.Set(bSpecifyPort_);
	serverEntry.m_lPort.Set(lPort_);
	serverEntry.m_strUsername.Set(strUsername_.c_str());
	serverEntry.m_strPassword.Set(strPassword_.c_str());
	if (lMaxFolderList_ != ServerEntry::ms_lDefaultMaxFolderList)
		serverEntry.m_lMaxFolderList.Set(lMaxFolderList_);

	serverEntry.StoreInRegistry();
	m_Servers.push_back(serverEntry);
}


void
EmsDatabaseEntry::AddServerToRegistry(	NrString&	strServerName_,
										bool		bSpecifyPort_,
										long		lPort_,
										NrString&	strUsername_,
										NrString&	strPassword_,
										long		lMaxFolderList_,
										bool		bTrustedLogin_)
{
	RemoveServerFromRegistry(strServerName_);

	// update the registry map's knowledge of the base key path to point to the server itself
	NrString strServerPath = m_strBaseKeyPath;
	strServerPath += TEXT("\\");
	strServerPath += ms_strServersSubkey.c_str();

	ServerEntry serverEntry(m_strComputerName.c_str(), strServerPath.c_str(), strServerName_.c_str());

 	serverEntry.m_strServerName.Set(strServerName_.c_str());
	serverEntry.m_bSpecifyPort.Set(bSpecifyPort_);
	serverEntry.m_lPort.Set(lPort_);
	serverEntry.m_strUsername.Set(strUsername_.c_str());
	serverEntry.m_strPassword.Set(strPassword_.c_str());
	if (lMaxFolderList_ != ServerEntry::ms_lDefaultMaxFolderList)
		serverEntry.m_lMaxFolderList.Set(lMaxFolderList_);
	serverEntry.m_bTrustedLogin.Set(bTrustedLogin_); //Vinod

	serverEntry.StoreInRegistry();
	m_Servers.push_back(serverEntry);
}


void
EmsDatabaseEntry::RemoveServerFromRegistry(NrString& strServerName_)
{
	//
	// iterate through server sub-keys and remove this one if already present
	//
	imstd::vector<ServerEntry>::iterator it = m_Servers.begin();

	while (it != m_Servers.end())
	{
		if (it->m_strServerName.Get() == strServerName_.c_str())
		{
			it->RemoveFromRegistry();
			m_Servers.erase(it);
			it = m_Servers.begin(); // erasure invalidates iterators; we must start back over
		}
		else it++;
	}
}

void
EmsDatabaseEntry::LogRegistry() const
{
	m_strDatabaseName.LogProperty(TEXT("Database Name"));

	RegistryMap::LogRegistry();
}
