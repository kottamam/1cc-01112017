////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// File:	OffSiteConfiguration.h
//
// Project: OffSite			Subsystem: Registry
//
// Contents:	Implements the registry configuration information for the EMS service.
//
//   Date    Who  Modification
// 07/21/04  AED  Initial coding.
//
// Copyright (C) 2004, Interwoven, Inc. ALL RIGHTS RESERVED
//                     PROPRIETARY AND CONFIDENTIAL
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma once

#if !defined(__IM_OFFSITECONFIGURATION_H__)
	#define __IM_OFFSITECONFIGURATION_H__

	#include <registry/Service.h>

	namespace IM
	{
		class OffSiteConfiguration : public IM::ServiceConfiguration
		{
		public:
			//
			// Constructors, destructors and initializers.
			//
					OffSiteConfiguration(const TCHAR *szComputerName_ = NULL);
			virtual	~OffSiteConfiguration(void);

		public:
			//
			// ServiceConfiguration
			//
			virtual void				LoadFromRegistry();

			RegistryBooleanProperty		m_bIsOffSiteInstalled;
			RegistryStringProperty		m_strServerName;
			RegistryLongProperty		m_lLastSyncTime;
			RegistryStringProperty		m_strChunkSize;
			RegistryStringProperty		m_strAdministrativeUsername;
			RegistryStringProperty		m_strAdministrativePassword;
			RegistryStringProperty		m_strLoginUsername;
			RegistryStringProperty		m_strLoginPassword;
			RegistryStringProperty		m_strDatabaseAdministrativeUsername;
			RegistryStringProperty		m_strDatabaseAdministrativePassword;
			RegistryStringProperty		m_strDefaultNRTWEBADMINPassword;
			RegistryStringProperty		m_strLocalServerAddress;
			RegistryLongProperty		m_lLocalServerPort;
			RegistryStringProperty		m_strDefaultDSNDriver;
			RegistryStringProperty		m_strDefaultDSNLastUser;
			RegistryStringProperty		m_strDefaultDSNServer;

			static const bool			ms_bDefaultIsOffSiteInstalled;
			static const NrString		ms_strDefaultServerName;
			static const long			ms_lDefaultLastSyncTime;
			static const NrString		ms_strDefaultChunkSize;
			static const NrString		ms_strDefaultAdministrativeUsername;
			static const NrString		ms_strDefaultAdministrativePassword;
			static const NrString		ms_strDefaultLoginUsername;
			static const NrString		ms_strDefaultLoginPassword;
			static const NrString		ms_strDefaultDatabaseAdministrativeUsername;
			static const NrString		ms_strDefaultDatabaseAdministrativePassword;
			static const NrString		ms_strDefaultDefaultNRTWEBADMINPassword;
			static const NrString		ms_strDefaultLocalServerAddress;
			static const long			ms_lDefaultLocalServerPort;
			static const NrString		ms_strDefaultDefaultDSNDriver;
			static const NrString		ms_strDefaultDefaultDSNLastUser;
			static const NrString		ms_strDefaultDefaultDSNServer;

			long						GetStatusLong(void);
		};

	};	// namespace IM

#endif	// __IM_OFFSITECONFIGURATION_H__

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
