#ifndef __REG_SERVICE_H__
#define __REG_SERVICE_H__


#pragma once

#include <Windows.h>
#include <Winsvc.h>

#include <registry\registrymap.h>

namespace IM
{

class ServiceConfiguration : public RegistryMap
{
public:

	IM::NrString		m_strServiceName;
	IM::NrString		m_strServiceDisplayName;
	IM::NrString		m_strServiceScmName;
	IM::NrString		m_strServiceScmDesc;

	bool				m_bInstalled;
	SC_HANDLE			m_hSCM;


	// installation params
	IM::RegistryStringProperty	m_strLogonID;
	IM::RegistryStringProperty	m_strPassword;
	IM::RegistryBooleanProperty	m_bStartOnBoot;
	IM::RegistryBooleanProperty	m_bUtcInUse;
	IM::RegistryBooleanProperty	m_bNoPreResolve;

	IM::RegistryStringProperty	m_strServicePath;
	IM::RegistryStringProperty	m_strLogPath;
	IM::RegistryLongProperty	m_lLogMask;
	IM::RegistryLongProperty	m_lWatchTimeout;

	// run time information
	IM::RegistryStringProperty	m_strVersion;
	IM::RegistryStringProperty	m_strComments;

	IM::RegistryLongProperty	m_lClusteringTransport;


	IM::NrCiString			m_strDomainName;
	QUERY_SERVICE_CONFIG	*m_serviceConfig;
	TCHAR					m_serviceConfigBuf[1024];



					ServiceConfiguration(const TCHAR *szComputerName_, const TCHAR *szKeyPath_, const TCHAR *szServiceName_);
					ServiceConfiguration(
						const TCHAR *szComputerName_,
						const TCHAR *szKeyPath_,
						const TCHAR *szServiceName_,
						const TCHAR *szServiceDisplayName_,
						const TCHAR *szServiceScmName_
					);

	virtual			~ServiceConfiguration();

	bool			Init(bool readOnly = false);
	void			OpenScmHandle(bool readOnly = false);
	void			CloseScmHandle();
	SC_HANDLE		GetServiceHandle(bool readOnly = false);

	bool			GetServiceConfiguration(NrString& strLogonID_, NrString& strPassword_, bool &bAutoStartup_);
	bool			SetServiceConfiguration(const TCHAR *szLogonID_, const TCHAR *szPassword_, bool bAutoStartup_);

	void			InitUserInfo();
	bool			IsAdministrator();
	void			GrantServiceLogonPrivilege(const TCHAR *szLogonID_);				// SeServiceLogonRight	SE_SERVICE_LOGON_NAME
	void			GrantActAsPartOfOperatingSystemPrivilege(const TCHAR *szLogonID_);	// SeTcbPrivilege		SE_TCB_NAME
	void			GrantInteractiveLogonPrivilege(const TCHAR *szLogonID_);				// SeInteractiveLogonRight	SE_INTERACTIVE_LOGON_NAME
	

	TCHAR			*GetStatusString();
	bool			IsInstalled()		{ return m_bInstalled; }
	bool			IsRunning()			{ return IsStatus(SERVICE_RUNNING); }
	bool			IsStopped()			{ return IsStatus(SERVICE_STOPPED); }
	bool			IsPending()			{ return (IsRunning() != true && IsStopped() != true); }
	bool			IsStatus(DWORD status);
	bool			StartService();
	bool			StopService();

	bool			Install(const TCHAR *szPath_, const TCHAR *szLogonID_, const TCHAR *szPassword_, bool bAutoStartup_);
	bool			Uninstall();

	bool			IsUserLoggedOn(TCHAR *szUserName, TCHAR *szDomainName_, TCHAR* szPassword_);

	virtual			bool operator==(const ServiceConfiguration& basicService)
					{
							return basicService.m_strComputerName.compare(m_strComputerName) == 0 &&
									basicService.m_strServiceDisplayName.compare(m_strServiceDisplayName) == 0;
					}

};


class ServiceConfigurationFactory
{

public:

	ServiceConfigurationFactory();
	virtual ~ServiceConfigurationFactory();

	ServiceConfiguration*	GetServiceConfigurationByKeyName(const TCHAR *szKeyName_);

private:
	_TCHAR					m_szComputerName[MAX_COMPUTERNAME_LENGTH + 1];

};


};	// namespace IM


#endif // __REG_SERVICE_H__
