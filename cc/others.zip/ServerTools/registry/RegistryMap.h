//
//
//

#ifndef __REG_REGISTRYMAP_H__
#define __REG_REGISTRYMAP_H__

#pragma once

#include <stream\property.h>
#include <registry\regClass.h>

namespace IM
{

class RegistryProperty
{
private:

	bool		m_bInHeap;			// property object was created on heap and thus must be deleted after use
	bool		m_bChanged;
	bool		m_bEncrypted;
	bool		m_bServerOnly;

public:

					RegistryProperty() : m_bInHeap(false), m_bChanged(false), m_bEncrypted(false), m_bServerOnly(false) {}
	virtual			~RegistryProperty() {}

	void			SetEncryptFlag(bool bFlag_)		{	m_bEncrypted = bFlag_;		}
	bool			IsEncrypted() const				{	return m_bEncrypted;		}

	void			WasChanged()					{	m_bChanged = true;			}
	bool			IsChanged()						{	return m_bChanged;			}
	void			ResetChange()					{	m_bChanged = false;			}

	void			SetHeapFlag(bool bFlag_)		{	m_bInHeap = bFlag_;			}
	bool			IsInHeap()						{	return m_bInHeap;			}

	void			SetServerOnlyFlag(bool bFlag_)	{	m_bServerOnly = bFlag_;		}
	bool			IsServerOnly()					{	return m_bServerOnly;		}

	virtual long	GetType() const = 0;
	virtual void	LogProperty(const IM::NrString& strPropertyName) const = 0;
	virtual void	GetPropertyStringValue(IM::NrString &strPropertyStringValue_) = 0;
};


class RegistryBooleanProperty : public IM::RegistryProperty, private IM::BooleanProperty
{
public:

					RegistryBooleanProperty() : IM::BooleanProperty(false) {}
					RegistryBooleanProperty(bool bValue_) : IM::BooleanProperty(bValue_) {}
	virtual			~RegistryBooleanProperty() {}

	const bool		&Get() const					{	return GetData();				}
	void			Set(bool bValue_)				{	WasChanged(); SetData(bValue_);	}
	virtual	long	GetType() const					{	return GetPropertyType();		}
	virtual void	LogProperty(const IM::NrString& strPropertyName) const;
	virtual void	GetPropertyStringValue(IM::NrString &strPropertyStringValue_);
};


class RegistryLongProperty : public IM::RegistryProperty, private IM::LongProperty
{
public:

					RegistryLongProperty() : IM::LongProperty(0) {}
					RegistryLongProperty(long lValue_) : IM::LongProperty(lValue_) {}
	virtual			~RegistryLongProperty() {}

	const long		&Get() const					{	return GetData();				}
	void			Set(long lValue_)				{	WasChanged(); SetData(lValue_);	}	
	virtual	long	GetType() const					{	return GetPropertyType();		}
	virtual void	LogProperty(const IM::NrString& strPropertyName) const;
	virtual void	GetPropertyStringValue(IM::NrString &strPropertyStringValue_);
};


class RegistryStringProperty : public IM::RegistryProperty, private IM::CiStringProperty
{
public:

					RegistryStringProperty() {}
					RegistryStringProperty(IM::NrCiString& strValue_)	{ SetData(strValue_); }
					RegistryStringProperty(const TCHAR *strValue_)		{ SetData(strValue_); }
	virtual			~RegistryStringProperty() {}

	const IM::NrCiString &Get() const				{	return GetData();					}
	void			Set(IM::NrCiString& strValue_)	{	WasChanged(); SetData(strValue_);	}	
	void			Set(const TCHAR *strValue_)		{	WasChanged(); SetData(strValue_);	}	
	virtual	long	GetType() const					{	return GetPropertyType();			}
	virtual void	LogProperty(const IM::NrString& strPropertyName) const;
	virtual void	GetPropertyStringValue(IM::NrString &strPropertyStringValue_);
};



class RegistryMap : public Registry
{
protected:
	typedef imstd::map<const IM::NrCiString, RegistryProperty *>	PropertyMap;

	PropertyMap		m_propertyMap;
	HKEY			m_hKey;

	void			SetValue(const TCHAR *szName_, bool bValue_);
	void			SetValue(const TCHAR *szName_, long lValue_);
	void			SetValue(const TCHAR *szName_, const TCHAR *strValue_);

	bool			GetValue(const TCHAR *szName_, bool& bValue_) const;
	bool			GetValue(const TCHAR *szName_, long& lValue_) const;
	bool			GetValue(const TCHAR *szName_, IM::NrCiString& strValue_) const;

	void			SetEncryptFlag(const TCHAR *szName_);
	bool			IsEncrypted(const TCHAR *szName_);


public:
					RegistryMap(const TCHAR *szComputerName_, HKEY hKey_, const TCHAR *szBaseKeyPath_);
	explicit		RegistryMap(const RegistryMap *pRegistryMap_);
					~RegistryMap();


	void			GetNames(imstd::list<IM::NrString> listOfNames_) const;

	virtual void	LoadFromRegistry();
	virtual void	StoreInRegistry();
	virtual void	DeleteFromRegistry();
	void			LogRegistry() const;
};

}; // namespace IM


#endif // __REG_REGISTRYMAP_H__

