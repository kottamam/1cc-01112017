//This class has been implemented for NT-28236 -- 9.0 upgrade/installer enhancement
//The customer customized registry key will be at "HKLM\SOFTWARE\\Interwoven\Worksite\8.0\.."
//The installer default value will be at "HKLM\SOFTWARE\\Interwoven\Worksite\Client\.."
//Get value functions will try to read the value from "HKLM\...\WorkSite\8.0\.." frist
//If the key doesn't exist or available, the value will be read from the "HKLM\..\WorkSite\Client\.." path.
//This class is intended only for reading the client customized keys. 
//Please do not use this class for anyother Registy Read or Write operations.

#include "ClientRegKey.h"
#include <Registry\Registry.h>

#define CLIENT_REGKEY_BASE _T("SOFTWARE\\Interwoven\\WorkSite\\");
#define CLIENT_REGKEY_CUSTOM _T("8.0\\");
#define CLIENT_REGKEY_INSTALL _T("Client\\");


CClientRegKey::CClientRegKey(void)
{
}

CClientRegKey::~CClientRegKey(void)
{
}

bool CClientRegKey::GetStringValue(const TCHAR *szSubKeyPath, const TCHAR *szName_, IM::NrString& strValue_)
{
	IM::NrString strClientRegKey = CLIENT_REGKEY_BASE;
	strClientRegKey += (const TCHAR*) CLIENT_REGKEY_CUSTOM;
	IM::Registry regKey(NULL, HKEY_LOCAL_MACHINE, strClientRegKey.c_str());
	regKey.AddPath(szSubKeyPath);
	bool bKeyExist = false;
	
	if (regKey.Open(NULL, KEY_READ, true))
	{
		if (regKey.GetStringValue(szName_, strValue_))
		{
			bKeyExist = true;			
		}
	}

	if (!bKeyExist)
	{
		regKey.Close();
		strClientRegKey = CLIENT_REGKEY_BASE;
		strClientRegKey += (const TCHAR*) CLIENT_REGKEY_INSTALL;
		regKey.SetPath(strClientRegKey.c_str());
		regKey.AddPath(szSubKeyPath);

		if (regKey.Open(NULL, KEY_READ, true))
		{
			if (regKey.GetStringValue(szName_, strValue_))
			{
				bKeyExist = true;
			}
		}
	}

	regKey.Close();
	return bKeyExist;
}

bool CClientRegKey::GetLongValue(const TCHAR *szSubKeyPath, const TCHAR *szName_, long &lValue_)
{
	IM::NrString strClientRegKey = CLIENT_REGKEY_BASE;
	strClientRegKey += (const TCHAR*) CLIENT_REGKEY_CUSTOM;
	IM::Registry regKey(NULL, HKEY_LOCAL_MACHINE, strClientRegKey.c_str());
	regKey.AddPath(szSubKeyPath);
	bool bKeyExist = false;
	
	if (regKey.Open(NULL, KEY_READ, true))
	{
		if (regKey.GetLongValue(szName_, lValue_))
		{
			bKeyExist = true;			
		}
	}

	if (!bKeyExist)
	{
		regKey.Close();
		strClientRegKey = CLIENT_REGKEY_BASE;
		strClientRegKey += (const TCHAR*) CLIENT_REGKEY_INSTALL;
		regKey.SetPath(strClientRegKey.c_str());
		regKey.AddPath(szSubKeyPath);

		if (regKey.Open(NULL, KEY_READ, true))
		{
			if (regKey.GetLongValue(szName_, lValue_))
			{
				bKeyExist = true;
			}
		}
	}

	regKey.Close();
	return bKeyExist;
}

bool CClientRegKey::SetLongValue(const TCHAR *szSubKeyPath, const TCHAR *szName_, long lValue_)
{
	IM::NrString strClientRegKey = CLIENT_REGKEY_BASE;
	strClientRegKey += (const TCHAR*) CLIENT_REGKEY_CUSTOM;
	IM::Registry regKey(NULL, HKEY_LOCAL_MACHINE, strClientRegKey.c_str());
	regKey.AddPath(szSubKeyPath);
	bool bKeyExist = false;
	
	if (regKey.Open(NULL, KEY_WRITE, true))
	{
		if (regKey.SetLongValue(szName_, lValue_))
		{
			bKeyExist = true;			
		}
	}

	if (!bKeyExist)
	{
		regKey.Close();
		strClientRegKey = CLIENT_REGKEY_BASE;
		strClientRegKey += (const TCHAR*) CLIENT_REGKEY_INSTALL;
		regKey.SetPath(strClientRegKey.c_str());
		regKey.AddPath(szSubKeyPath);

		if (regKey.Open(NULL, KEY_WRITE, true))
		{
			if (regKey.SetLongValue(szName_, lValue_))
			{
				bKeyExist = true;
			}
		}
	}

	regKey.Close();
	return bKeyExist;
}

bool CClientRegKey::SetStringValue(const TCHAR *szSubKeyPath, const TCHAR *szName_, IM::NrString strValue_)
{
	IM::NrString strClientRegKey = CLIENT_REGKEY_BASE;
	strClientRegKey += (const TCHAR*)CLIENT_REGKEY_CUSTOM;
	IM::Registry regKey(NULL, HKEY_LOCAL_MACHINE, strClientRegKey.c_str());
	regKey.AddPath(szSubKeyPath);
	bool bKeyExist = false;

	if (regKey.Open(NULL, KEY_WRITE, true))
	{
		if (regKey.SetStringValue(szName_, strValue_.c_str()))
		{
			bKeyExist = true;
		}
	}

	if (!bKeyExist)
	{
		regKey.Close();
		strClientRegKey = CLIENT_REGKEY_BASE;
		strClientRegKey += (const TCHAR*)CLIENT_REGKEY_INSTALL;
		regKey.SetPath(strClientRegKey.c_str());
		regKey.AddPath(szSubKeyPath);

		if (regKey.Open(NULL, KEY_WRITE, true))
		{
			if (regKey.SetStringValue(szName_, strValue_.c_str()))
			{
				bKeyExist = true;
			}
		}
	}

	regKey.Close();
	return bKeyExist;
}

bool CClientRegKey::GetDWORDValue(const TCHAR *szSubKeyPath, const TCHAR *szName_, DWORD &dValue_)
{
	long lKeyValue = dValue_;
	bool retValue = GetLongValue(szSubKeyPath, szName_, lKeyValue);
	dValue_ = lKeyValue;
	return retValue;
}

bool CClientRegKey::SetDWORDValue(const TCHAR *szSubKeyPath, const TCHAR *szName_, DWORD dValue_)
{
	return SetLongValue(szSubKeyPath, szName_, (long) dValue_);
}
