#include <Registry\RegistryLib.h>
#pragma hdrstop
#include <Registry\RegClass.h>

using namespace IM;

// Note: UTF-8 translation is used in Non-Unicode mode (because WorkSite Server operates on UTF-8).

Registry::Registry(const TCHAR *szComputerName_, HKEY hHive_, const TCHAR *szBaseKeyPath_)
{
	m_strRegistryComputerName = _T("\\\\");
	if (szComputerName_ == NULL || _tcslen(szComputerName_) == 0)
	{
		//
		// Initialize Rules Engine here.
		//

		wchar_t			szComputerName[MAX_COMPUTERNAME_LENGTH + 1];
		DWORD			dwNameSize = sizeof(szComputerName);

		::GetComputerNameW(szComputerName, &dwNameSize);
#ifndef _UNICODE
		m_strComputerName = UnicodeToUTF8(szComputerName).c_str();
#else
		m_strComputerName = szComputerName;
#endif
	
	}
	else
	{
		m_strComputerName = szComputerName_;
	}

    m_strRegistryComputerName += m_strComputerName;
	m_strBaseKeyPath = szBaseKeyPath_;
	m_hDesiredHive = hHive_;

	m_hRemoteHive = NULL;
	m_hHive = NULL;
}

	Registry::Registry(const Registry *pRegistry_) :
		m_strRegistryComputerName(pRegistry_->m_strRegistryComputerName),
		m_hDesiredHive(pRegistry_->m_hDesiredHive),
		m_hRemoteHive(pRegistry_->m_hRemoteHive),
		m_hHive(pRegistry_->m_hHive),
		m_bCreatedNew(pRegistry_->m_bCreatedNew),
		m_lEnumerateIndex(pRegistry_->m_lEnumerateIndex),
		m_strBaseKeyPath(pRegistry_->m_strBaseKeyPath),
		m_strComputerName(pRegistry_->m_strComputerName)
{
}

bool
Registry::IsKeyPresent(HKEY hHive_, const TCHAR *szSubKeyPath_)
{
	HKEY		hLocalKey = NULL;
	NrString	strKey;

	strKey = m_strBaseKeyPath;
	if (szSubKeyPath_ != NULL)
		strKey += szSubKeyPath_;	
	// determine software installation
	if (RegOpenKeyExW(hHive_, strKey.toUnicode(CP_UTF8), 0, KEY_READ, &hLocalKey) != ERROR_SUCCESS)
	{
		return false;
	}

	RegCloseKey(hLocalKey);
	return true;
}


bool
Registry::Open(const TCHAR *szSubKeyPath_, DWORD dwAccess_, bool donotOpenRemote)
{
	NrString	strKeyName;

	m_lEnumerateIndex = 0;

	strKeyName = m_strBaseKeyPath;
	if (szSubKeyPath_ != NULL)
		strKeyName += szSubKeyPath_;

	m_bCreatedNew = false;
	m_hHive = m_hDesiredHive;

	// if server name specified then connect to remote registry
	if (!m_strRegistryComputerName.empty())
	{
		if (RegConnectRegistryW(donotOpenRemote? NULL : (wchar_t *) m_strRegistryComputerName.toUnicode(CP_UTF8), m_hHive, &m_hRemoteHive) != ERROR_SUCCESS)
			return false;
	}

	return (RegOpenKeyExW(m_hRemoteHive, strKeyName.toUnicode(CP_UTF8), 0, dwAccess_, &m_hHive) == ERROR_SUCCESS);
}




bool
Registry::OpenOrCreate(const TCHAR *szSubKeyPath_, DWORD dwAccess_, bool donotOpenRemote)
{
	NrString	strKeyName;

	m_lEnumerateIndex = 0;

	strKeyName = m_strBaseKeyPath;
	if (szSubKeyPath_ != NULL)
		strKeyName += szSubKeyPath_;

	m_bCreatedNew = false;
	m_hHive = m_hDesiredHive;

	// if server name specified then connect to remote registry
	if (!m_strRegistryComputerName.empty())
	{
		if (RegConnectRegistryW(donotOpenRemote? NULL :(wchar_t *) m_strRegistryComputerName.toUnicode(CP_UTF8), m_hHive, &m_hRemoteHive) != ERROR_SUCCESS)
		{
			return false;
		}
	}

	// Open key; if could not open then attempt to create it
	if (RegOpenKeyExW(m_hRemoteHive, strKeyName.toUnicode(CP_UTF8), 0, dwAccess_, &m_hHive) != ERROR_SUCCESS)
	{
		DWORD	dwDisp;		// disposition

		// Key does not exist; create it
		if (RegCreateKeyExW(m_hRemoteHive, strKeyName.toUnicode(CP_UTF8), 0, L"", REG_OPTION_NON_VOLATILE, dwAccess_, NULL, &m_hHive, &dwDisp) != ERROR_SUCCESS)
			return false;

		m_bCreatedNew = true;
	}

	return true;
}



void
Registry::DeleteSubKey(const TCHAR *szSubKeyName_)
{
	IM::NrString srtSubKey = szSubKeyName_;
	RegDeleteKeyW(m_hHive, srtSubKey.toUnicode(CP_UTF8));
}


void
Registry::Close()
{
	if (m_hHive != NULL)
		RegCloseKey(m_hHive);
	if (m_hRemoteHive != NULL)
		RegCloseKey(m_hRemoteHive);

	m_hHive = NULL;
	m_hRemoteHive = NULL;
}



bool
Registry::EnumerateKey(NrString& strSubKey_)
{
	wchar_t		szSubKey[REGSTR_MAX_VALUE_LENGTH *4];
	DWORD		dwSize = sizeof(szSubKey);
	FILETIME	ftLastWrite;
	long		lRtnCode;

	memset(szSubKey, 0, dwSize);
	strSubKey_ = _T("");

	if ((lRtnCode = RegEnumKeyExW(
								m_hHive,
								m_lEnumerateIndex,
								szSubKey,
								&dwSize,
								0,
								NULL,
								NULL,
								&ftLastWrite)) != ERROR_SUCCESS)
	{
		if (lRtnCode != ERROR_NO_MORE_ITEMS)
		{
			throw_error(GetLastError(), _T("Error enumerating registry keys"));
		}

		return false;
	}

#ifndef _UNICODE
	strSubKey_ = UnicodeToUTF8(szSubKey).c_str();
#else
	strSubKey_ = szSubKey;
#endif
	++m_lEnumerateIndex;

	return true;
}


bool
Registry::EnumerateName(NrString& strName_, DWORD &dwType_, TCHAR *szValueBuffer_, long lBufferSize_)
{
	wchar_t		szValueName[REGSTR_MAX_VALUE_LENGTH*4];
	wchar_t		wszValueBuffer[REGSTR_MAX_VALUE_LENGTH*4];
	DWORD		dwSize = sizeof(szValueName);
	DWORD		dwValueSize = sizeof(wszValueBuffer);
	long		lRtnCode;

	memset(szValueName, 0, dwSize);
	memset(wszValueBuffer, 0, dwValueSize);
	memset(szValueBuffer_, 0, lBufferSize_);
	strName_ = _T("");

	if ((lRtnCode = RegEnumValueW(
								m_hHive,
								m_lEnumerateIndex,
								szValueName,
								&dwSize,
								0,
								&dwType_,
								(LPBYTE) wszValueBuffer,
								&dwValueSize)) != ERROR_SUCCESS)
	{
		if (lRtnCode != ERROR_NO_MORE_ITEMS)
		{
			throw_error(GetLastError(), _T("Error reading registry name-value pairs"));
		}

		return false;
	}

#ifndef _UNICODE
	strName_ = UnicodeToUTF8(szValueName).c_str();	

	if (dwType_ == REG_DWORD)
	{
		wmemcpy((wchar_t*)szValueBuffer_, wszValueBuffer, dwValueSize);
	}
	else
	{
		strcpy(szValueBuffer_, UnicodeToUTF8(wszValueBuffer));
	}
#else
	strName_ = szValueName;
	DWORD dwCharToCopy = dwValueSize;	
	if (dwType_ == REG_SZ)
	{
		dwCharToCopy /=2;
	}
	wmemcpy(szValueBuffer_, wszValueBuffer, dwCharToCopy);

#endif	

	++m_lEnumerateIndex;

	return true;
}


bool
Registry::GetStringValue(const TCHAR *szName_, NrString& strValue_)
{
	wchar_t			szValue[4096];
	unsigned long	size = sizeof(szValue);
	DWORD			dwType;
	IM::NrString	strName = szName_;

	memset(szValue, 0, size);
	strValue_ = _T("");

	if (RegQueryValueExW(m_hHive, strName.toUnicode(CP_UTF8), 0, &dwType, (LPBYTE) szValue, &size) != ERROR_SUCCESS)
		return false;

	if (dwType != REG_SZ)
	{		
		NrString		strMessage;		
		strMessage = _T("Key: ");
		strMessage += m_strBaseKeyPath;
		strMessage += _T(", Name: ");
		strMessage += strName;
		strMessage += _T(" -- Registry data type is different from requested; wanted string");


		throw_error(0, strMessage.c_str());
	}
#ifndef _UNICODE
	strValue_ = UnicodeToUTF8(szValue).c_str();
#else
	strValue_ = szValue;
#endif

	return true;
}

  

bool
Registry::SetStringValue(const TCHAR *szName_, const TCHAR *szValue_)
{
	IM::NrString _strName = szName_;
	IM::NrString _strValue = szValue_;

	long		size = (long)wcslen(_strValue.toUnicode(CP_UTF8)) * sizeof(wchar_t) + 1;		// REG_SZ requires size to include terminating NULL TCHAR

	if (RegSetValueExW(m_hHive, _strName.toUnicode(CP_UTF8), 0, REG_SZ, (const BYTE *) _strValue.toUnicode(CP_UTF8).c_str(), size) != ERROR_SUCCESS)
		return false;

	return true;
}


bool
Registry::GetLongValue(const TCHAR *szName_, long& lValue_)
{
	IM::NrString _strName = szName_;

	unsigned long	size = sizeof(long);
	DWORD			dwType;

	if (RegQueryValueExW(m_hHive, _strName.toUnicode(CP_UTF8), 0, &dwType, (LPBYTE) &lValue_, &size) != ERROR_SUCCESS)
		return false;

	if (dwType != REG_DWORD)
	{
		NrString		strMessage;		
		strMessage = _T("Key: ");
		strMessage += m_strBaseKeyPath;
		strMessage += _T(", Name: ");
		strMessage += _strName;
		strMessage += _T(" -- Registry data type is different from requested; wanted DWORD");

		throw_error(0, strMessage.c_str());
	}

	return true;
}
 


bool 
Registry::SetLongValue(const TCHAR *szName_, long lValue_)
{
	IM::NrString _strName = szName_;

	if (RegSetValueExW(m_hHive, _strName.toUnicode(CP_UTF8), 0, REG_DWORD, (const BYTE *) &lValue_, sizeof(long)) != ERROR_SUCCESS)
		return false;

	return true;
}



void
Registry::DeleteName(const TCHAR *szName_)
{
	IM::NrString _strName = szName_;
	RegDeleteValueW(m_hHive, _strName.toUnicode(CP_UTF8));
}




bool
Registry::GetStringValue(HKEY hHive_, const TCHAR *szKeyPath_, const TCHAR *szValueName_, NrString& strValueData_)
{
	wchar_t			szComputerName[MAX_COMPUTERNAME_LENGTH + 1];
	DWORD			nameSize = sizeof(szComputerName);

	::GetComputerNameW(szComputerName, &nameSize);

#ifndef _UNICODE
	Registry	svcReg(UnicodeToUTF8(szComputerName), hHive_, szKeyPath_);
#else
	Registry	svcReg(szComputerName, hHive_, szKeyPath_);
#endif

	if (svcReg.Open(NULL, KEY_ALL_ACCESS) != ERROR_SUCCESS)
		return false;

	// We have opened the register; load in the information
	return svcReg.GetStringValue(szValueName_, strValueData_);
}


	
bool
Registry::GetLongValue(HKEY hHive_, const TCHAR *szKeyPath_, const TCHAR *szValueName_, long& lValueData_)
{
	wchar_t			szComputerName[MAX_COMPUTERNAME_LENGTH + 1];
	DWORD			nameSize = sizeof(szComputerName);

	::GetComputerNameW(szComputerName, &nameSize);

#ifndef _UNICODE
	Registry	svcReg(UnicodeToUTF8(szComputerName), hHive_, szKeyPath_);
#else
	Registry	svcReg(szComputerName, hHive_, szKeyPath_);
#endif

	if (svcReg.Open(NULL, KEY_ALL_ACCESS) != ERROR_SUCCESS)
		return false;

	// We have opened the register; load in the information
	return svcReg.GetLongValue(szValueName_, lValueData_);
}


