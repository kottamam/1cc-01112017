 //=============================================================================
// File: Registry.h
//-----------------------------------------------------------------------------
// Date      Who  Modification
// --------  ---  -------------------------------------------------------------
// 07/21/99  ZUB  Initial coding
//-----------------------------------------------------------------------------
// Copyright (C) 1999, iManage, Inc.
// PROPRIETARY AND CONFIDENTIAL
//=============================================================================
//
// Main header file for Registry management classes
//

#ifndef __REG_REGISTRY_H__
#define __REG_REGISTRY_H__

#pragma once

// For building with VS2008 and stlPort51
#ifdef WSNT_VS2008	//	********************* VS2008 ******************************************************************************
#include <WSNT_VS2008.h>
#endif	// WSNT_VS2008	********************* VS2008 ******************************************************************************

#ifndef STRICT
#define STRICT 1
#endif

#include <windows.h>
#include <tchar.h>

#include <stl\NrString.h>

#include <Verification\Verification.h>
#include <Verification\Exception.h>

#include <Stream\PropertyTypes.h>
#include <Stream\Property.h>
//#include <Crypt\Crypt.h>

#include <Registry\RegClass.h>
#include <Registry\RegistryMap.h>
#include <Registry\FileServer.h>
#include <Registry\DatabaseEntry.h>
#include <Registry\Service.h>
#include <Registry\ntSystemService.h>

#include <Registry\DatabaseEntryEx.h>
#include <Registry\ServiceEx.h>
#include <Registry\EMSServiceConfiguration.h>
#include <Registry\EMSConConfiguration.h>


// ODBC DSN information
#ifndef KEY_ODBC_SRC_PATH
#define KEY_ODBC_SRC_PATH		_T("Software\\ODBC\\ODBC.INI\\ODBC Data Sources")
#endif

#define KEY_IDXMGR_IA_PATH		_T("software\\Interwoven\\WorkSite\\imIdxMgrSvc\\imIndexAgent")
#define KEY_IDXSCH_IA_PATH		_T("software\\Interwoven\\WorkSite\\imIdxSrchSvc\\imIndexAgent")

#endif __REG_REGISTRY_H__
