////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// File:	EMailSvcConfiguration.cpp
//
// Project: Email Management System		Subsystem: Email Filing Service
//
// Contents:	Implements the registry configuration information for the EmailOnline service.
//
//   Date    Who  Modification
// 08/15/12  Vinod  Initial coding.
//
// Copyright (C) 2002, iManage Technologies, Inc. ALL RIGHTS RESERVED
//                     PROPRIETARY AND CONFIDENTIAL
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


#include <EMailSvcConfiguration.h>
#include <atlenc.h>
#include <registry/RegistryLib.h>
#include <boost/algorithm/string.hpp>


#pragma hdrstop
using namespace IM;

#define KEY_STORE_ADMIN_SMTP_ADDRESS		_T("Exchange Administrator SMTP Address")
#define	KEY_STORE_ADMIN_PASSWORD			_T("Exchange Administrator Password")
#define	KEY_PROXY_SERVER					_T("Proxy Server")
#define KEY_PROXY_SERVER_PORT				_T("Proxy Server Port")
#define KEY_EXCHANGE_SERVER_PORT			_T("Exchange Server Port")
#define KEY_CLUSTER_NAME					_T("Cluster Name")
#define KEY_FMA_PORT						_T("FMA Port")
#define KEY_CLASS							_T("Class")
#define KEY_SUBCLASS						_T("SubClass")
#define KEY_TYPE							_T("Type")
#define KEY_THREAD_POOL_SIZE				_T("Thread Pool Size")
#define KEY_EMAIL_RETRIEVAL_COUNT			_T("Email Retrieval Count")
#define MAILBOX_SYNC_RECIPIENTS_LIMIT		_T("Mailbox Sync Recipients Limit")
//#define KEY_MAILBOX_SYNC_BATCH_SIZE			_T("Mailbox Sync Batch Size")
#define KEY_MESSAGE_CLASSES					_T("Message Classes")
#define KEY_EXCLUDE_MESSAGE_CLASSES			_T("Exclude Message Classes")
#define KEY_REMOVED_MESSAGE_CLASSES			_T("Removed Message Classes")
#define KEY_MINUTES_UNTIL_RETRY_FILING		_T("Retry Marked Folder Items Older By")
#define KEY_ENABLE_SEND_AND_FILE_AGENT		_T("Enable Send And File Agent")
#define KEY_ENABLE_EFS						_T("Enable EFS")
#define KEY_ENABLE_MAILBOX_SYNC				_T("Enable Mailbox Sync")
#define KEY_TARGET_DIRECTORY				_T("Target Directory")
#define KEY_DROP_DIRECTORY					_T("Drop Directory")
#define KEY_BAD_MAIL_DIRECTORY				_T("Bad Directory")
#define KEY_MINUTES_TO_BOUNCE				_T("Minutes Until Bounce")
#define KEY_SMTP_SERVERNAME					_T("SMTP Server Name")
#define KEY_SMTP_SERVERPORT					_T("SMTP Server Port")
#define KEY_SMTP_USERNAME					_T("SMTP Username")
#define KEY_SMTP_PASSWORD					_T("SMTP Password")
#define KEY_SMTP_FROM_ADDRESS				_T("SMTP From Address")
#define KEY_SMTP_REPLY_TO_ADDRESS			_T("SMTP Reply-To Address")
#define KEY_SMTP_CUSTOM						_T("SMTP Custom Bounce Message Text")
#define KEY_SMTP_INCLUDE_BOUNCED			_T("SMTP Include Original Email in Bounce")
#define KEY_SMTP_LINES_TO_QUOTE				_T("SMTP Lines To Quote")
#define KEY_BOUNCETOADMIN					_T("Bounce Only To Administrator")
#define KEY_ALLOWFOLDERNUMBERS				_T("Allow Folder Numbers in Addresses")
#define KEY_FROMLOOKUP						_T("From Address Username Access Lookup")
#define KEY_USESMTPOPENRELAY				_T("Use SMTP Open Relay")
#define KEY_DAYSTORETAINDUPLICATES			_T("Days To Retain Duplicates")
#define KEY_ALTERNATE_AUTODISCOVER_URL		_T("Alternate Autodiscover URL")
#define KEY_AUTH_MODE					 	_T("AuthMode")
#define KEY_DOMAIN 						 	_T("Domain")
#define KEY_USERNAME 					 	_T("UserName")
#define KEY_SERVER_VERSION 				 	_T("ServerVersion")
#define KEY_DELETE_XML_FILE				 	_T("DeleteXMLFiles")
#define KEY_USE_LDAP_FOR_AUTODISCOVER	 	_T("UseLDAPForAutoDiscover")
#define KEY_FIND_PROXY					 	_T("FindProxy")
#define KEY_DATA_FROM_SOCKET			 	_T("PrintDataFromSocket")
#define KEY_POLL_USER_INTERVAL			 	_T("Poll User Interval")
#define KEY_POLL_EMAILPROCESS_INTERVAL		_T("Poll Email Process Interval")
#define KEY_POLL_FOLDERPROCESS_INTERVAL		_T("Poll Folder Process Interval")
#define KEY_POLL_MBS_INTERVAL			 	_T("Poll MailboxSync Process Interval")
#define KEY_DELAY_AFTER_ALL_USER_PROCESS 	_T("Delay After All User Process")   
#define KEY_RETRIEVE_DATA_SIZE 			 	_T("Retrieve Data Size From Exch")
#define KEY_EMAIL_FILING   	 			 	_T("EnableEmailFiling")
#define KEY_LINKED_FOLDER_FILING  		 	_T("EnableFolderMapping")
#define KEY_SCRIPT_TYPE  	 			 	_T("Script")
#define KEY_SEND_DTTIME_CUST_FIELD 		 	_T("Send Time")
#define KEY_NUM_DMS_CONNECTIONS  		 	_T("NumberOfDMSConnections")
#define KEY_MBS_THREADPOOL_SIZE  		 	_T("MailboxSync Thread Pool Size")
#define KEY_MBS_BACK_SEARCH_NUM_DAYS	 	_T("Sync Last X Days")   
#define KEY_SKIP_FOLDER_LOOKUP_FREQUENCY 	_T("Folder Lookup Frequency")
#define KEY_EWS_TIMEOUT_SEC 			 	_T("EWSTimeout")
#define KEY_DIAG_UTIL 	 				 	_T("DebugDiag")
#define KEY_SCHEDULER_DIAG				 	_T("SchedulerDiag")
#define KEY_CRASHDUMP 					 	_T("EnableCrashDump")
#define KEY_CRASHDUMP_PATH 					_T("CrashDumpPath")
#define KEY_DEBUG_USERS						_T("Enable User Debugging")
#define KEY_INSTALL_PATH					_T("Install Path")
#define KEY_SERIALIZE_EWS					_T("Serialize EWS APIs")
#define KEY_CAPTURE_SOAP_REQ				_T("Capture Soap Request")
#define KEY_PROC_SPEC_USERS					_T("Enable Specific User Processing")
#define KEY_FOLDER_IN_ROOT					_T("KeepIManageFolderInRoot")
#define KEY_FILE_OLDEST_FIRST				_T("FileOldestFirst")
#define KEY_WHITELIST_MESSAGE_CLASSES		_T("UseWhiteListMsgClasses")
#define KEY_IGNORE_MSG_CLS_AFTER_X_FAILURE	_T("Ignore Message Class After X Failure")
#define KEY_MESSAGE_SIZE_FOR_FILE_ENTRY		_T("Message Size For File Entry")
#define KEY_SENT_ITEM_FILER					_T("Enable Sent Item Filer")
#define KEY_SENT_ITEM_MOVE					_T("Enable Sent Item Email Move")
#define KEY_HIDE_SYNC_ISSUE_FOLDER			_T("Hide Sync Issue Folder")
#define KEY_CLUSTER_VALIDATION				_T("Enable Cluster Validation")
#define KEY_INITIAL_SENT_ITEM_SYNC			_T("Enable Initial Sent Item Sync")

const NrString				EMailSvcConfiguration::ms_strDatabasesSubkey				= "Databases"	;
const NrString				EMailSvcConfiguration::ms_strDomainsSubkey					= "Domains"		;
const NrString				EMailSvcConfiguration::ms_strDefaultClass					= "E-MAIL"		;
const NrString				EMailSvcConfiguration::ms_strDefaultSubClass				= ""			;
const NrString				EMailSvcConfiguration::ms_strDefaultType					= "MIME"		;
const long					EMailSvcConfiguration::ms_nDefaultThreadPoolSize			= 10			;
const long					EMailSvcConfiguration::ms_nDefaultEmailRetrievalCount		= 50			;
const long					EMailSvcConfiguration::ms_nMailboxSyncRecipientLimit		= 50			;
const long					EMailSvcConfiguration::ms_nDefaultMailboxSyncBatchSize      = 100           ;
const NrString				EMailSvcConfiguration::ms_strDefaultMessageClasses			= "";
const NrString				EMailSvcConfiguration::ms_strDefaultExcludeMessageClasses   = ""			;
const NrString				EMailSvcConfiguration::ms_strDefaultRemovedMessageClasses	= ""			;
const long					EMailSvcConfiguration::ms_nDefaultMinutesUntilRetryFiling	= 600			;
const bool					EMailSvcConfiguration::ms_bDefaultEnableSendAndFileAgent	= false			;
const bool					EMailSvcConfiguration::ms_bDefaultEnableEFS					= true			;
const bool					EMailSvcConfiguration::ms_bDefaultEnableMailboxSync			= false			;
const NrString				EMailSvcConfiguration::ms_strDefaultDirectory				= ""			;
const long					EMailSvcConfiguration::ms_lDefaultMinutesToBounce			= 30			;
const NrString				EMailSvcConfiguration::ms_strDefaultSMTPServerName			= ""			;
const long					EMailSvcConfiguration::ms_lDefaultSMTPServerPort			= 25			;
const NrString				EMailSvcConfiguration::ms_strDefaultSMTPUserName			= ""			;
const NrString				EMailSvcConfiguration::ms_strDefaultSMTPPassword			= ""			;
const NrString				EMailSvcConfiguration::ms_strDefaultSMTPFromAddress			= ""			;
const NrString				EMailSvcConfiguration::ms_strDefaultSMTPReplyAddress		= ""			;
const NrString				EMailSvcConfiguration::ms_strDefaultSMTPCustomText			= "Your message was not filed in one or more of the intended WorkSite(tm) folders.";
const bool					EMailSvcConfiguration::ms_bDefaultSMTPIncludeBouncedEmail	= true			;
const long					EMailSvcConfiguration::ms_lDefaultSMTPLinesToQuote			= 25			;
const bool					EMailSvcConfiguration::ms_bDefaultBounceToAdmin				= false			;
const bool					EMailSvcConfiguration::ms_bDefaultAllowFolderNumbers		= true			;
const bool					EMailSvcConfiguration::ms_bFromLookup						= false			;
const bool					EMailSvcConfiguration::ms_bUseSMTPOpenRelay					= false			;
const long					EMailSvcConfiguration::ms_lDaysToRetainDuplicates			= 0				;
const NrString				EMailSvcConfiguration::ms_strDefaultProxyServer				= ""			;
const NrString				EMailSvcConfiguration::ms_strDefaultProxyPort				= ""			;
const NrString				EMailSvcConfiguration::ms_strDefaultExchSrvPort				= "443"			;
const NrString				EMailSvcConfiguration::ms_strDefaultAlternateURL			= ""			;
const long					EMailSvcConfiguration::ms_lAuthMode							= 0				;
const NrString				EMailSvcConfiguration::ms_strDomain 						= ""			;
const NrString				EMailSvcConfiguration::ms_strUserName 						= ""			;
const NrString				EMailSvcConfiguration::ms_strServerVersion 					= ""			;
const long					EMailSvcConfiguration::ms_lDeleteXMLFile					= 1 			;
const long					EMailSvcConfiguration::ms_lUseLDAPForAutoDiscover			= 0 			;
const long					EMailSvcConfiguration::ms_lFindProxy						= 0 			;
const long					EMailSvcConfiguration::ms_lDataFromSocket					= 0 			;
const long					EMailSvcConfiguration::ms_lPollUserInterval					= 0 			;
const long					EMailSvcConfiguration::ms_lPollEmailProcInterval			= 0				;
const long					EMailSvcConfiguration::ms_lPollFolderProcInterval			= 900000		;
const long					EMailSvcConfiguration::ms_lPollMBSProcInterval				= 21600000		;
const long					EMailSvcConfiguration::ms_lDelayAfterAllUserProcess			= 0 			;
const long					EMailSvcConfiguration::ms_lRetrieveDataSize 				= 40 			;
const long					EMailSvcConfiguration::ms_lEmailFiling   	 				= 1 			;
const long					EMailSvcConfiguration::ms_lLinkedFolderFiling  				= 1 			;
const NrString				EMailSvcConfiguration::ms_bstrScriptType  	 				= "" 			;
const long					EMailSvcConfiguration::ms_lSendDtTimeCustField 				= 21 			;
const long					EMailSvcConfiguration::ms_lNumDMSConnections  				= 32			;
const long					EMailSvcConfiguration::ms_lMBSThreadPoolSize  				= 10			;
const long					EMailSvcConfiguration::ms_lMBSBackSearchNumDays				= 1				;
const long					EMailSvcConfiguration::ms_lSkipFolderLookupFrequency		= 0				;
const long					EMailSvcConfiguration::ms_lEWSTimeoutSec 					= 90			;
const long					EMailSvcConfiguration::ms_lDiagUtil 	 					= 0				;
const long					EMailSvcConfiguration::ms_lSchedulerDiag					= 0				; 
const long					EMailSvcConfiguration::ms_lCrashDump 						= 1				;
const NrString				EMailSvcConfiguration::ms_strCrashDumpPath 					= ""			;
const long					EMailSvcConfiguration::ms_lDebugUsers						= 0				;
const NrString				EMailSvcConfiguration::ms_strInstallPath					= "C:\\Program Files (x86)\\Autonomy\\WorkSite\\Server\\";
const long					EMailSvcConfiguration::ms_lSerializeEWSAPIs					= 1				;
const long					EMailSvcConfiguration::ms_lCaptureSoapReq					= 0				;
const long					EMailSvcConfiguration::ms_lProcSpecUsers					= 0				;
const long					EMailSvcConfiguration::ms_lKeepFoldInRoot					= 0				;
const long					EMailSvcConfiguration::ms_lFileOldestFirst					= 0				;
const long					EMailSvcConfiguration::ms_lWhiteListMsgClasses				= 0				;
const long					EMailSvcConfiguration::ms_lIgnoreMsgClassAfterXFailure		= 100			;
const long					EMailSvcConfiguration::ms_lDelEntryMsgSize					= 5				;
const bool					EMailSvcConfiguration::ms_bSentItemFiler					= false			;
const bool					EMailSvcConfiguration::ms_bSentItemMove						= true			;
const bool					EMailSvcConfiguration::ms_bHideSyncIssueFold				= true			;
const bool					EMailSvcConfiguration::ms_bClusterValidation				= true			;
const bool					EMailSvcConfiguration::ms_bInitialSentItemSync				= false			;

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	EMailSvcConfiguration - Default constructor
//
EMailSvcConfiguration::EMailSvcConfiguration(const TCHAR *szComputerName_) : 
		ServiceConfiguration(szComputerName_, SZ_ONLINEEMAILSVC_PATH, SZ_ONLINEEMAILSVC_NAME)	,
			m_nServerId								(0)											,
			m_nTotalSvrsInCluster					(0)											,
			m_strClass								(ms_strDefaultClass.c_str())				,
			m_strSubClass							(ms_strDefaultSubClass.c_str())				,
			m_strDocType							(ms_strDefaultType.c_str())					,
			m_nThreadPoolSize						(ms_nDefaultThreadPoolSize)					,
			m_nEmailRetrievalCount					(ms_nDefaultEmailRetrievalCount)			,
			m_nMailboxSyncRecipientLimit			(ms_nMailboxSyncRecipientLimit)				,
			m_strMessageClasses						(ms_strDefaultMessageClasses.c_str())		,
			m_strExcludeMessageClasses				(ms_strDefaultExcludeMessageClasses.c_str()),
			m_strRemovedMessageClasses				(ms_strDefaultRemovedMessageClasses.c_str()),
			m_nMinutesUntilRetryFiling				(ms_nDefaultMinutesUntilRetryFiling)		,
			m_bEnableSendAndFileAgent				(ms_bDefaultEnableSendAndFileAgent)			,
			m_bEnableEFS							(ms_bDefaultEnableEFS)						,
			m_bEnableMailboxSync					(ms_bDefaultEnableMailboxSync)				,
			m_strDropDirectory						(ms_strDefaultDirectory.c_str())			,
			m_strBadDirectory						(ms_strDefaultDirectory.c_str())			,
			m_lMinutesToBounce						(ms_lDefaultMinutesToBounce)				,
			m_strSMTPServerName						(ms_strDefaultSMTPServerName.c_str())		,
			m_lSMTPServerPort						(ms_lDefaultSMTPServerPort)					,
			m_strSMTPUserName						(ms_strDefaultSMTPUserName.c_str())			,
			m_strSMTPPassword						(ms_strDefaultSMTPPassword.c_str())			,
			m_strSMTPFromAddress					(ms_strDefaultSMTPFromAddress.c_str())		,
			m_strSMTPReplyAddress					(ms_strDefaultSMTPReplyAddress.c_str())		,
			m_strSMTPCustomText						(ms_strDefaultSMTPCustomText.c_str())		,
			m_bSMTPIncludeBouncedEmail				(ms_bDefaultSMTPIncludeBouncedEmail)		,
			m_lSMTPLinesToQuote						(ms_lDefaultSMTPLinesToQuote)				,
			m_bBounceToAdmin						(ms_bDefaultBounceToAdmin)					,
			m_bAllowFolderNumbers					(ms_bDefaultAllowFolderNumbers)				,
			m_bFromLookup							(ms_bFromLookup)							,
			m_bUseSMTPOpenRelay						(ms_bUseSMTPOpenRelay)						,
			m_lDaysToRetainDuplicates				(ms_lDaysToRetainDuplicates)				,
			m_strExchSrvPort						(ms_strDefaultExchSrvPort.c_str())			,
			m_strProxyServer						(ms_strDefaultProxyServer.c_str())			,
			m_strProxyPort							(ms_strDefaultProxyPort.c_str())			,
			m_strAlternateAutodiscoverURL			(ms_strDefaultAlternateURL.c_str()) 		,
			m_lAuthMode  							(ms_lAuthMode)                              ,
			m_strDomain                             (ms_strDomain.c_str())                      ,
			m_strUserName                           (ms_strUserName.c_str())                    ,
			m_strServerVersion                      (ms_strServerVersion.c_str())               ,
			m_lDeleteXMLFile                        (ms_lDeleteXMLFile)                         ,
			m_lUseLDAPForAutoDiscover               (ms_lUseLDAPForAutoDiscover)                ,
			m_lFindProxy                            (ms_lFindProxy)                             ,
			m_lDataFromSocket                       (ms_lDataFromSocket)                        ,
			m_lPollUserInterval                     (ms_lPollUserInterval)                      ,
			m_lPollEmailProcInterval				(ms_lPollEmailProcInterval)					,
			m_lPollFolderProcInterval				(ms_lPollFolderProcInterval)				,
			m_lPollMBSProcInterval					(ms_lPollMBSProcInterval)					,
			m_lDelayAfterAllUserProcess             (ms_lDelayAfterAllUserProcess)              ,
			m_lRetrieveDataSize                     (ms_lRetrieveDataSize)                      ,
			m_lEmailFiling                          (ms_lEmailFiling)                           ,
			m_lLinkedFolderFiling                   (ms_lLinkedFolderFiling)                    ,
			m_bstrScriptType                        (ms_bstrScriptType.c_str())                 ,
			m_lSendDtTimeCustField                  (ms_lSendDtTimeCustField)                   ,
			m_lNumDMSConnections                    (ms_lNumDMSConnections)                     ,
			m_lMBSThreadPoolSize                    (ms_lMBSThreadPoolSize)                     ,
			m_lMBSBackSearchNumDays                 (ms_lMBSBackSearchNumDays)                  ,
			m_lSkipFolderLookupFrequency            (ms_lSkipFolderLookupFrequency)             ,
			m_lEWSTimeoutSec                        (ms_lEWSTimeoutSec)                         ,
			m_lDiagUtil                             (ms_lDiagUtil)                              ,
			m_lSchedulerDiag                        (ms_lSchedulerDiag)                         ,
			m_lCrashDump                            (ms_lCrashDump) 							,
			m_strCrashDumpPath                      (ms_strCrashDumpPath.c_str())				,
			m_lDebugUsers							(ms_lDebugUsers)							,
			m_strInstallPath						(ms_strInstallPath.c_str()) 				,
			m_lSerializeEWSAPIs 					(ms_lSerializeEWSAPIs) 						,
			m_lCaptureSoapReq 						(ms_lCaptureSoapReq) 						,
			m_lProcSpecUsers						(ms_lProcSpecUsers)							,
			m_lKeepFoldInRoot						(ms_lKeepFoldInRoot)						,
			m_lFileOldestFirst						(ms_lFileOldestFirst)						,
			m_lWhiteListMsgClasses					(ms_lWhiteListMsgClasses)					,
			m_lIgnoreMsgClassAfterXFailure			(ms_lIgnoreMsgClassAfterXFailure)			,			
			m_lDelEntryMsgSize						(ms_lDelEntryMsgSize)						,
			m_bSentItemFiler						(ms_bSentItemFiler)							,
			m_bSentItemMove							(ms_bSentItemMove)							,
			m_bHideSyncIssueFold					(ms_bHideSyncIssueFold)						,
			m_bClusterValidation					(ms_bClusterValidation)						,
			m_bInitialSentItemSync					(ms_bInitialSentItemSync)

{
	m_strServiceName			= SZ_ONLINEEMAILSVC_NAME;
	m_strServiceDisplayName		= SZ_ONLINEEMAILSVC_DISPLAY_NAME;
	m_strServiceScmName			= SZ_ONLINEEMAILSVC_SCM_NAME;
	m_strServiceScmDesc			= SZ_ONLINEEMAILSVC_DESC;

	m_strStoreAdminSMTPAddress.SetEncryptFlag(true);
	m_strStoreAdminPassword.SetEncryptFlag(true);
	m_strSMTPPassword.SetEncryptFlag(true);

	m_strTargetDirectory = NrString(GetTempFilePath().toAnsi().c_str()).c_str();
	m_propertyMap.insert(PropertyMap::value_type(KEY_STORE_ADMIN_SMTP_ADDRESS,		&m_strStoreAdminSMTPAddress));
	m_propertyMap.insert(PropertyMap::value_type(KEY_STORE_ADMIN_PASSWORD,			&m_strStoreAdminPassword));
	m_propertyMap.insert(PropertyMap::value_type(KEY_PROXY_SERVER,					&m_strProxyServer));
	m_propertyMap.insert(PropertyMap::value_type(KEY_PROXY_SERVER_PORT,				&m_strProxyPort));
	m_propertyMap.insert(PropertyMap::value_type(KEY_EXCHANGE_SERVER_PORT,			&m_strExchSrvPort));
	m_propertyMap.insert(PropertyMap::value_type(KEY_CLUSTER_NAME,					&m_strClusterName));
	m_propertyMap.insert(PropertyMap::value_type(KEY_FMA_PORT,						&m_nFmaPort));
	m_propertyMap.insert(PropertyMap::value_type(KEY_CLASS,							&m_strClass));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SUBCLASS,						&m_strSubClass));
	m_propertyMap.insert(PropertyMap::value_type(KEY_TYPE,							&m_strDocType));
	m_propertyMap.insert(PropertyMap::value_type(KEY_THREAD_POOL_SIZE,				&m_nThreadPoolSize));
	m_propertyMap.insert(PropertyMap::value_type(KEY_EMAIL_RETRIEVAL_COUNT,			&m_nEmailRetrievalCount));
	m_propertyMap.insert(PropertyMap::value_type(MAILBOX_SYNC_RECIPIENTS_LIMIT,		&m_nMailboxSyncRecipientLimit));
	m_propertyMap.insert(PropertyMap::value_type(KEY_MESSAGE_CLASSES,				&m_strMessageClasses));
	m_propertyMap.insert(PropertyMap::value_type(KEY_EXCLUDE_MESSAGE_CLASSES,		&m_strExcludeMessageClasses));
	m_propertyMap.insert(PropertyMap::value_type(KEY_REMOVED_MESSAGE_CLASSES,		&m_strRemovedMessageClasses));
	m_propertyMap.insert(PropertyMap::value_type(KEY_MINUTES_UNTIL_RETRY_FILING,	&m_nMinutesUntilRetryFiling));
	m_propertyMap.insert(PropertyMap::value_type(KEY_ENABLE_SEND_AND_FILE_AGENT,	&m_bEnableSendAndFileAgent));
	m_propertyMap.insert(PropertyMap::value_type(KEY_ENABLE_EFS,					&m_bEnableEFS));
	m_propertyMap.insert(PropertyMap::value_type(KEY_ENABLE_MAILBOX_SYNC,			&m_bEnableMailboxSync));	
	m_propertyMap.insert(PropertyMap::value_type(KEY_TARGET_DIRECTORY,				&m_strTargetDirectory));
	m_propertyMap.insert(PropertyMap::value_type(KEY_DROP_DIRECTORY,				&m_strDropDirectory));
	m_propertyMap.insert(PropertyMap::value_type(KEY_BAD_MAIL_DIRECTORY,			&m_strBadDirectory));
	m_propertyMap.insert(PropertyMap::value_type(KEY_MINUTES_TO_BOUNCE,				&m_lMinutesToBounce));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SMTP_SERVERNAME,				&m_strSMTPServerName));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SMTP_SERVERPORT,				&m_lSMTPServerPort));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SMTP_USERNAME,					&m_strSMTPUserName));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SMTP_PASSWORD,					&m_strSMTPPassword));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SMTP_FROM_ADDRESS,				&m_strSMTPFromAddress));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SMTP_REPLY_TO_ADDRESS,			&m_strSMTPReplyAddress));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SMTP_CUSTOM,					&m_strSMTPCustomText));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SMTP_INCLUDE_BOUNCED,			&m_bSMTPIncludeBouncedEmail));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SMTP_LINES_TO_QUOTE,			&m_lSMTPLinesToQuote));
	m_propertyMap.insert(PropertyMap::value_type(KEY_BOUNCETOADMIN,					&m_bBounceToAdmin));
	m_propertyMap.insert(PropertyMap::value_type(KEY_ALLOWFOLDERNUMBERS,			&m_bAllowFolderNumbers));
	m_propertyMap.insert(PropertyMap::value_type(KEY_FROMLOOKUP,					&m_bFromLookup));
	m_propertyMap.insert(PropertyMap::value_type(KEY_USESMTPOPENRELAY,				&m_bUseSMTPOpenRelay));
	m_propertyMap.insert(PropertyMap::value_type(KEY_DAYSTORETAINDUPLICATES,		&m_lDaysToRetainDuplicates));
	m_propertyMap.insert(PropertyMap::value_type(KEY_ALTERNATE_AUTODISCOVER_URL,	&m_strAlternateAutodiscoverURL));
	m_propertyMap.insert(PropertyMap::value_type(KEY_AUTH_MODE,						&m_lAuthMode));
	m_propertyMap.insert(PropertyMap::value_type(KEY_DOMAIN, 						&m_strDomain));
	m_propertyMap.insert(PropertyMap::value_type(KEY_USERNAME, 						&m_strUserName));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SERVER_VERSION, 				&m_strServerVersion));
	m_propertyMap.insert(PropertyMap::value_type(KEY_DELETE_XML_FILE,				&m_lDeleteXMLFile));
	m_propertyMap.insert(PropertyMap::value_type(KEY_USE_LDAP_FOR_AUTODISCOVER,		&m_lUseLDAPForAutoDiscover));
	m_propertyMap.insert(PropertyMap::value_type(KEY_FIND_PROXY,					&m_lFindProxy));
	m_propertyMap.insert(PropertyMap::value_type(KEY_DATA_FROM_SOCKET,				&m_lDataFromSocket));
	m_propertyMap.insert(PropertyMap::value_type(KEY_POLL_USER_INTERVAL,			&m_lPollUserInterval));
	m_propertyMap.insert(PropertyMap::value_type(KEY_POLL_EMAILPROCESS_INTERVAL,	&m_lPollEmailProcInterval));
	m_propertyMap.insert(PropertyMap::value_type(KEY_POLL_FOLDERPROCESS_INTERVAL,	&m_lPollFolderProcInterval));
	m_propertyMap.insert(PropertyMap::value_type(KEY_POLL_MBS_INTERVAL,				&m_lPollMBSProcInterval));
	m_propertyMap.insert(PropertyMap::value_type(KEY_DELAY_AFTER_ALL_USER_PROCESS,	&m_lDelayAfterAllUserProcess));
	m_propertyMap.insert(PropertyMap::value_type(KEY_RETRIEVE_DATA_SIZE, 			&m_lRetrieveDataSize));
	m_propertyMap.insert(PropertyMap::value_type(KEY_EMAIL_FILING,   	 			&m_lEmailFiling));
	m_propertyMap.insert(PropertyMap::value_type(KEY_LINKED_FOLDER_FILING,  		&m_lLinkedFolderFiling));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SCRIPT_TYPE,  	 				&m_bstrScriptType));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SEND_DTTIME_CUST_FIELD, 		&m_lSendDtTimeCustField));
	m_propertyMap.insert(PropertyMap::value_type(KEY_NUM_DMS_CONNECTIONS,  			&m_lNumDMSConnections));
	m_propertyMap.insert(PropertyMap::value_type(KEY_MBS_THREADPOOL_SIZE,  			&m_lMBSThreadPoolSize));
	m_propertyMap.insert(PropertyMap::value_type(KEY_MBS_BACK_SEARCH_NUM_DAYS,		&m_lMBSBackSearchNumDays));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SKIP_FOLDER_LOOKUP_FREQUENCY,	&m_lSkipFolderLookupFrequency));
	m_propertyMap.insert(PropertyMap::value_type(KEY_EWS_TIMEOUT_SEC, 				&m_lEWSTimeoutSec));
	m_propertyMap.insert(PropertyMap::value_type(KEY_DIAG_UTIL, 	 				&m_lDiagUtil));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SCHEDULER_DIAG,				&m_lSchedulerDiag));
    m_propertyMap.insert(PropertyMap::value_type(KEY_CRASHDUMP, 				   	&m_lCrashDump));
    m_propertyMap.insert(PropertyMap::value_type(KEY_CRASHDUMP_PATH,			    &m_strCrashDumpPath));
	m_propertyMap.insert(PropertyMap::value_type(KEY_DEBUG_USERS,                   &m_lDebugUsers));
	m_propertyMap.insert(PropertyMap::value_type(KEY_INSTALL_PATH,					&m_strInstallPath));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SERIALIZE_EWS,					&m_lSerializeEWSAPIs));
	m_propertyMap.insert(PropertyMap::value_type(KEY_CAPTURE_SOAP_REQ,				&m_lCaptureSoapReq));
	m_propertyMap.insert(PropertyMap::value_type(KEY_PROC_SPEC_USERS,				&m_lProcSpecUsers));
	m_propertyMap.insert(PropertyMap::value_type(KEY_FOLDER_IN_ROOT,				&m_lKeepFoldInRoot));
	m_propertyMap.insert(PropertyMap::value_type(KEY_FILE_OLDEST_FIRST,				&m_lFileOldestFirst));
	m_propertyMap.insert(PropertyMap::value_type(KEY_WHITELIST_MESSAGE_CLASSES,		&m_lWhiteListMsgClasses));
	m_propertyMap.insert(PropertyMap::value_type(KEY_IGNORE_MSG_CLS_AFTER_X_FAILURE, &m_lIgnoreMsgClassAfterXFailure));
	m_propertyMap.insert(PropertyMap::value_type(KEY_MESSAGE_SIZE_FOR_FILE_ENTRY,	&m_lDelEntryMsgSize));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SENT_ITEM_FILER,				&m_bSentItemFiler));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SENT_ITEM_MOVE,				&m_bSentItemMove));
	m_propertyMap.insert(PropertyMap::value_type(KEY_HIDE_SYNC_ISSUE_FOLDER,		&m_bHideSyncIssueFold));
	m_propertyMap.insert(PropertyMap::value_type(KEY_CLUSTER_VALIDATION,			&m_bClusterValidation));
	m_propertyMap.insert(PropertyMap::value_type(KEY_INITIAL_SENT_ITEM_SYNC,		&m_bInitialSentItemSync));
	
	
	
}
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	EMailSvcConfiguration - Destructor
//
EMailSvcConfiguration::~EMailSvcConfiguration()
{
	m_DomainNames.clear();
	m_Databases.clear();
}


//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	LoadFromRegistry
//
void EMailSvcConfiguration::LoadFromRegistry()
{
	ServiceConfiguration::LoadFromRegistry();

	if (m_lMinutesToBounce.Get() < 1)
	{
		m_lMinutesToBounce.Set(1L);
	}

	m_DomainNames.clear();
	m_Databases.clear();

	NrString		strDomainKeyPath = SZ_ONLINEEMAILSVC_PATH;
	strDomainKeyPath += TEXT("\\");
	strDomainKeyPath += ms_strDomainsSubkey.c_str();

	Registry		domainReg(m_strComputerName.c_str(), HKEY_LOCAL_MACHINE, strDomainKeyPath.c_str());
	NrString		strDomainName;

	if (domainReg.OpenOrCreate(NULL, KEY_ALL_ACCESS) != true)
	{
		throw_error(GetLastError(), _T("Could not open/create Registry key for domain information"));
	}

	while (domainReg.EnumerateKey(strDomainName) == true)
	{
		m_DomainNames.push_back(strDomainName);
	}

	// Get the database entries
	NrString		strDatabaseKeyPath = SZ_ONLINEEMAILSVC_PATH;
	strDatabaseKeyPath += TEXT("\\");
	strDatabaseKeyPath += ms_strDatabasesSubkey;

	Registry		dbReg(m_strComputerName.c_str(), HKEY_LOCAL_MACHINE, strDatabaseKeyPath.c_str());
	NrString		strDatabaseName;

	if (dbReg.OpenOrCreate(NULL, KEY_ALL_ACCESS) != true)
	{
		throw_error(GetLastError(), _T("Could not open/create Registry key for database information"));
	}

	while (dbReg.EnumerateKey(strDatabaseName) == true)
	{
		// each database has a list of DMS entries; get those
		NrString strServerKeyPath = strDatabaseKeyPath;
		strServerKeyPath += TEXT("\\");
		strServerKeyPath += strDatabaseName;
		strServerKeyPath += TEXT("\\");	
		strServerKeyPath += EmsDatabaseEntry::ms_strServersSubkey.c_str();

		Registry		svrReg(m_strComputerName.c_str(), HKEY_LOCAL_MACHINE, strServerKeyPath.c_str());
		NrString		strServerName;

		// open registry to enumerate the configured servers
		if (svrReg.OpenOrCreate(NULL, KEY_ALL_ACCESS) != true)
		{
			throw_error(GetLastError(), _T("Could not open/create Registry key for server information"));
		}

		EmsDatabaseEntry dbEntry(m_strComputerName.c_str(), strDatabaseKeyPath.c_str(), strDatabaseName.c_str());
		dbEntry.LoadFromRegistry();

		while (svrReg.EnumerateKey(strServerName) == true)
		{
			ServerEntry svrEntry(m_strComputerName.c_str(), strServerKeyPath.c_str(), strServerName.c_str());
			svrEntry.LoadFromRegistry();

			dbEntry.m_Servers.push_back(svrEntry);
		}

		m_Databases.push_back(dbEntry);
	}
}


void EMailSvcConfiguration::AddDatabaseToRegistry(NrString& strDatabaseName_)
{
	RemoveDatabaseFromRegistry(strDatabaseName_);

	NrString strDatabaseKeyPath = SZ_ONLINEEMAILSVC_PATH;
	strDatabaseKeyPath += TEXT("\\");
	strDatabaseKeyPath += ms_strDatabasesSubkey.c_str();

	EmsDatabaseEntry dbEntry(m_strComputerName.c_str(), strDatabaseKeyPath.c_str(), strDatabaseName_.c_str());

	dbEntry.StoreInRegistry();

	LoadFromRegistry();
}

void EMailSvcConfiguration::AddDatabaseToRegistry(	NrString&	strDatabaseName_,
													NrString&	strServerName_,
													bool		bSpecifyPort_,
													long		lPort_,
													NrString&	strUsername_,
													NrString&	strPassword_,
													long		lMaxFolderList_)
{
	LoadFromRegistry();

	RemoveDatabaseFromRegistry(strDatabaseName_);

	NrString strDatabaseKeyPath = SZ_ONLINEEMAILSVC_PATH;
	strDatabaseKeyPath += TEXT("\\");
	strDatabaseKeyPath += ms_strDatabasesSubkey.c_str();

	EmsDatabaseEntry dbEntry(m_strComputerName.c_str(), strDatabaseKeyPath.c_str(), strDatabaseName_.c_str());

	dbEntry.StoreInRegistry();

	dbEntry.AddServerToRegistry(strServerName_, bSpecifyPort_, lPort_, strUsername_, strPassword_, lMaxFolderList_);

	LoadFromRegistry();
}

void EMailSvcConfiguration::AddDatabaseToRegistry(	NrString&	strDatabaseName_,
													NrString&	strServerName_,
													bool		bSpecifyPort_,
													long		lPort_,
													NrString&	strUsername_,
													NrString&	strPassword_,
													long		lMaxFolderList_,
													bool		bTrustedLogin_)
{
	LoadFromRegistry();

	RemoveDatabaseFromRegistry(strDatabaseName_);

	NrString strDatabaseKeyPath = SZ_ONLINEEMAILSVC_PATH;
	strDatabaseKeyPath += TEXT("\\");
	strDatabaseKeyPath += ms_strDatabasesSubkey.c_str();

	EmsDatabaseEntry dbEntry(m_strComputerName.c_str(), strDatabaseKeyPath.c_str(), strDatabaseName_.c_str());

	dbEntry.StoreInRegistry();

	dbEntry.AddServerToRegistry(strServerName_, bSpecifyPort_, lPort_, strUsername_, strPassword_, lMaxFolderList_, bTrustedLogin_);

	LoadFromRegistry();
}

void EMailSvcConfiguration::RemoveDatabaseFromRegistry(NrString& strDatabaseName_)
{
	LoadFromRegistry();

	imstd::vector<EmsDatabaseEntry>::iterator	it = m_Databases.begin();
	for ( ; it != m_Databases.end(); it++)
	{
		if (it->m_strDatabaseName.Get() == strDatabaseName_)
		{
			it->RemoveFromRegistry();
		}
	}

	LoadFromRegistry();
}

void EMailSvcConfiguration::GetExchangeCredentials(NrUnicodeString* _Credentials)
{

	NrString sCredentials = "";
	sCredentials += m_strStoreAdminSMTPAddress.Get();
	sCredentials += _T(":");
	sCredentials += m_strStoreAdminPassword.Get();
	*_Credentials = sCredentials.toBase64().toUnicode().c_str();
	return;

	/*BYTE* pbData =  NULL; 
	int nRequiredLen = Base64EncodeGetRequiredLength(sCredentials.length()) + 1;
	if (0 < nRequiredLen)
	{
		pbData = im_new BYTE[nRequiredLen];
		if (NULL != pbData)
		{
			memset(pbData, 0, nRequiredLen);
			memcpy_s(pbData, nRequiredLen, sCredentials.c_str(), sCredentials.length());

			char* sEncodedData = NULL; int nEncodedLen;
			if (Base64Encode(pbData, sCredentials.length(), sEncodedData, &nEncodedLen) && (NULL != sEncodedData))
			{
				sCredentials = sEncodedData;
				delete[] sEncodedData; sEncodedData = NULL;
			}
			delete[] pbData; pbData = NULL;
		}
	}
	return sCredentials;*/
}

void EMailSvcConfiguration::AddDomainToRegistry(NrString& strDomainName_)
{
	RemoveDomainFromRegistry(strDomainName_);

	NrString strDomainKeyPath = SZ_ONLINEEMAILSVC_PATH;
	strDomainKeyPath += TEXT("\\");
	strDomainKeyPath += ms_strDomainsSubkey.c_str();
	strDomainKeyPath += TEXT("\\");

	Registry domainReg(m_strComputerName.c_str(), HKEY_LOCAL_MACHINE, strDomainKeyPath.c_str());

	domainReg.OpenOrCreate(strDomainName_.c_str(), KEY_ALL_ACCESS);
	domainReg.Close();

	LoadFromRegistry();
}


void EMailSvcConfiguration::RemoveDomainFromRegistry(NrString& strDomainName_)
{
	NrString strDomainKeyPath = SZ_ONLINEEMAILSVC_PATH;
	strDomainKeyPath += TEXT("\\");
	strDomainKeyPath += ms_strDomainsSubkey.c_str();

	Registry domainReg(m_strComputerName.c_str(), HKEY_LOCAL_MACHINE, strDomainKeyPath.c_str());

	domainReg.Open(NULL, KEY_ALL_ACCESS);
	domainReg.DeleteSubKey(strDomainName_.c_str());
	domainReg.Close();

	LoadFromRegistry();
}

NrUnicodeString EMailSvcConfiguration::GetTempFilePath()
{
	NrUnicodeString sTempPath = L"";

	try
	{
		wchar_t szTempPath[MAX_PATH] = {L"\0"};
		if	(GetTempPathW(MAX_PATH, szTempPath))
		{			
			sTempPath = szTempPath;
			if (L'\\' != sTempPath.at(sTempPath.length() - 1))
			{
				sTempPath += L"\\";
			}

			sTempPath += L"EWS\\";

			if (!PathFileExistsW(sTempPath.c_str()))
			{
				CreateDirectoryW(sTempPath.c_str(), NULL);
			}
		}
	}
	catch(...)
	{}

	return sTempPath;
}

imstd::set<NrUnicodeString> EMailSvcConfiguration::GetUsersFromFile(const boost::filesystem::path &filePath)
{
	try
	{
		boost::filesystem::wfstream fileStream(filePath, imstd::ios_base::in);
		imstd::set<NrUnicodeString> sUsers;

		if (!fileStream.is_open())
			throw imstd::exception("Unable to open file for reading.");

		for (imstd::basic_string<wchar_t> line; getline(fileStream, line);)
		{
			boost::trim(line);
			boost::to_upper(line);
			sUsers.insert(line.c_str());
		}
		fileStream.close();
		
		if (sUsers.empty())
			throw imstd::exception("File is empty or unable to read from file.");

		return sUsers;
	}
	catch (imstd::exception &e)
	{
		char buf[512]{'\0'};
		_snprintf(buf, 511, "Error reading users from file %s. Error msg: %s", NrString(filePath.c_str()).c_str(), e.what());
		throw imstd::exception(buf);
	}
	
	return imstd::set<NrUnicodeString>();
}
