//=============================================================================
// File: DatabaseEntryEx.cpp
//-----------------------------------------------------------------------------
// Date      Who  Modification
// --------  ---  -------------------------------------------------------------
// 01/10/00  ZIA  Initial coding
//-----------------------------------------------------------------------------
// Copyright (C) 1999, NetRight Technologies, Inc.
// PROPRIETARY AND CONFIDENTIAL
//=============================================================================
//
//	Classes for managing service-specific database configuration information in the registry
//

#include <Registry\RegistryLib.h>

#pragma hdrstop

#include <Registry\DatabaseEntryEx.h>
#include <Registry\ServiceEx.h>

using namespace IM;

#define KEY_INDEX_CNCTTYP			TEXT("Index Connection Type")
#define KEY_INDEX_CNCTNCNT			TEXT("Index Connection Count")

#define KEY_INDEX_SERVER			TEXT("Index Server")

#define KEY_INDEX_SERVER_GIVEN_PORT	TEXT("Index Server Given Port")
#define KEY_INDEX_SERVER_PORT		TEXT("Index Server Port")
#define KEY_INDEX_REPLY_PORT		TEXT("Index Server Reply Port")
#define KEY_INDEX_MAXROWS			TEXT("Index Max Rows")

#define KEY_INDEX_SOURCE_SERVER		TEXT("Index Source Server")
#define KEY_INDEX_SOURCE			TEXT("Index Source")
#define KEY_INDEX_PRODUCT			TEXT("Index Product")
#define KEY_INDEX_EXETYPE			TEXT("Index Exe Type")
#define KEY_INDEX_EXE				TEXT("Index Exe")
#define KEY_INDEX_PROJECT			TEXT("Index Project")
#define KEY_INDEX_RENDERFUNCTION	TEXT("Index Render Function")
#define KEY_INDEX_REP_USER			TEXT("Index Repository User")
#define KEY_INDEX_REP_PASSWORD		TEXT("Index Repository Password")
#define KEY_INDEX_HTTPS				TEXT("Index HTTPS")
#define KEY_INDEX_HTTP_DOMAIN		TEXT("Index HTTP Domain")
#define KEY_INDE_HTTP_USER			TEXT("Index HTTP User")
#define KEY_INDEX_HTTP_PASSWORD		TEXT("Index HTTP Password")
#define KEY_INDEX_SERVER_USERPWD	TEXT("Index Server UserPwd")
#define KEY_INDEX_LATEST_VERSION_SOURCE		TEXT("Index Latest Version Source")
#define KEY_INDEX_ALL_VERSIONS_SOURCE		TEXT("Index All Versions Source")

	// Digital Safe config
#define KEY_DIGITAL_SAFE_SSL_KEY_FILE			TEXT("Digital Safe SSL Key File")
#define KEY_DIGITAL_SAFE_SSL_KEY_FILE_PASSWORD	TEXT("Digital Safe SSL Key File Password")
#define KEY_DIGITAL_SAFE_SSL_CA_CERT			TEXT("Digital Safe SSL CA Cert")
#define KEY_DIGITAL_SAFE_SSL_CA_PATH			TEXT("Digital Safe SSL CA Path")
#define KEY_DIGITAL_SAFE_URL					TEXT("Digital Safe URL")
#define KEY_DIGITAL_SAFE_MAILFROM				TEXT("Digital Safe MailFrom")
#define KEY_DIGITAL_SAFE_RCPTTO					TEXT("Digital Safe RcptTo")
#define KEY_DIGITAL_SAFE_DOMAIN_NAME			TEXT("Digital Safe Domain Name")

// IDOL config
#define KEY_INDEX_REPOSITORY_NAME	TEXT("Index Repository Name")
#define KEY_INDEX_SECURITY_KEY1     _T("Index Security Key 1")
#define KEY_INDEX_SECURITY_KEY2     _T("Index Security Key 2")
#define KEY_INDEX_SECURITY_KEY3     _T("Index Security Key 3")
#define KEY_INDEX_SECURITY_KEY4     _T("Index Security Key 4")
#define KEY_ABRIDGED_SEARCH_RESULTS _T("Abridged Search Results")
#define KEY_COMBINE_SORT			 _T("Combine Sort")
#define KEY_INDEX_TIMEOUT			_T("Index Timeout")
#define KEY_INDEX_IDOL_BIAS			_T("IDOL Bias")
#define KEY_INDEX_IDOL_WORKSPACE_FILTER	_T("IDOL Workspace Filter")
#define KEY_IDOL_ALL_VERSIONS_COMBINE _T("IDOL All Versions Combine")
#define KEY_IDOL_LATEST_VERSION_COMBINE _T("IDOL Latest Version Combine")
#define KEY_AND_TEXT_QUERY_TERMS	 _T("AND Text Query Terms")
#define KEY_METADATA_ONLY_INDEX		 _T("Metadata Only Index")
#define KEY_WORKSPACE_INDEX			 _T("Workspace Index")
#define KEY_IDOL_CUSTOM_PARAMS		_T("IDOL Custom Params")
#define KEY_GROUP_CACHE_EXPIRATION	_T("Group Cache Expiration")

#define KEY_VERSION_EDITING			_T("Version Editing")
#define KEY_WORKLIST_MODE			_T("Worklist")
#define KEY_CONSOLIDATE_WORKLIST	_T("Consolidate Worklist")
#define	KEY_PERFORM_OCR_REPLACEMENT	_T("Perform OCR Replacement")
#define	KEY_INCLUDE_DISABLED_GROUPS	_T("Include Disabled Groups")
#define KEY_WEB_CONTENT				_T("Web Content")
#define KEY_HIDDEN					_T("Hidden")

#define KEY_SORT_ORDER_MASK			TEXT("Sort Order Mask")

#define KEY_GIVEN_PROXY_SERVICE_PORT	_T("Given Service Port")
#define KEY_PROXY_SERVICE_PORT			_T("Service Port")
#define KEY_PROXY_REPLY_PORT			_T("Reply Port")
#define KEY_GIVEN_PROXY_FILE_PORT		_T("Given File Transfer Port")
#define KEY_PROXY_FILE_PORT				_T("File Transfer Port")
#define KEY_UNDECLARE_RECORD			_T("Undeclare Record")
#define KEY_PROXY_IMPERSONATION			_T("Impersonation Password")
#define KEY_LOCALE                      _T("Locale")
#define KEY_CHANGE_QUEUE_TRUNCATION_TIME _T("Change Queue Truncation Time")
#define KEY_CHANGE_QUEUE_SIZE           _T("Change Queue Size In Days")
#define KEY_CHANGE_QUEUE_TRUNCATION_DISABLED _T("Change Queue Truncation Disabled")
#define KEY_CHANGE_QUEUE_CACHE_SIZE     _T("Change Queue Cache Size In Minutes")
#define KEY_CHANGE_QUEUE_CACHE_DISABLED _T("Change Queue Cache Disabled")
#define KEY_CHANGE_QUEUE_CACHE_REFRESH  _T("Change Queue Cache Refresh In Seconds")

// For HpFlow
#define KEY_HPFLOW_KEY_FILE_PWD			_T("HpFlow KeyFile Password")
#define KEY_HPFLOW_KEY_FILE_PATH			_T("HpFlow Key File Path")
#define KEY_TRUSTEDLSLOGIN						_T("HpFlow Trusted Login")
#define KEY_SSOURL                      _T("HpFlow SSOUrl")
#define KEY_BASEURL                      _T("HpFlow BaseUrl")
#define KEY_PROXYURL                      _T("HpFlow ProxyServer")
#define KEY_FOLDERNAMEFORMAT                      _T("HpFlow Folder Name Format")
#define KEY_CLIENTID                      _T("HpFlow ClientID")
#define KEY_SFURL                      _T("HpFlow StoreFrontUrl")
#define	KEY_COMPANYEMAILDOMAINS			_T("HpFlow Company Email Domains")
#define	KEY_SECURESENTFOLDERNAME		_T("HpFlow Secure Sent Links Folder Name")
#define KEY_SECURELINK_FOLDER_LOCATION			_T("HpFlow Secure Sent Links Folder Location")
#define KEY_HPFLOW_AUTHENTICATED_PROXY	_T("HpFlow Authenticated Proxy")
#define KEY_HPFLOW_PROXY_USERNAME		_T("HpFlow Proxy UserName")
#define KEY_HPFLOW_PROXY_PSWD			_T("HpFlow Proxy Password")

// SEV Configuration
#define KEY_SEV_MINIMUM_DOCNUM		    _T("SEV Minimum Docnum")
#define KEY_SEV_MAXIMUM_DOCNUM		    _T("SEV Maximum Docnum")
#define KEY_SEV_ALLOW_DOCNUM_INSERT		_T("SEV Allow Docnum Insert")

// To disable IDOL Term Expand
#define KEY_DISABLE_IDOL_TERM_EXPAND			_T("Disable IDOL Term Expand")

#define	KEY_IMANSHARE_CONNECT_TIMEOUT	_T("ImanageShare Connect Timeout")
#define	KEY_IMANSHARE_READ_TIMEOUT		_T("ImanageShare Read Timeout")

// Sync event logging
#define KEY_SYNC_LOGGING_MODE  _T("Sync Logging Mode")

// OCR Rendition Output Folder
#define KEY_OCR_RENDITION_FOLDER  _T("OCR Rendition Folder")


DmsDatabaseEntry::DmsDatabaseEntry(const TCHAR *szComputerName_, const TCHAR *szDatabaseName_)
			: DatabaseEntry(szComputerName_, KEY_DMS_DB_PATH, szDatabaseName_)
{
	m_strImpersonationPassword.SetEncryptFlag(true);
	m_strIndexRepPassword.SetEncryptFlag(true);
	m_strIndexHTTPPassword.SetEncryptFlag(true);
	m_strIndexServerUserPwd.SetEncryptFlag(true);
	m_strDigitalSafeSSLKeyFilePassword.SetEncryptFlag(true);
	m_strProxyPassword.SetEncryptFlag(true);

	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEX_CNCTTYP, &m_lIndexConnectType));
	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEX_CNCTNCNT, &m_lIndexConnectionCount));

	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEX_SERVER, &m_strIndexServer));

	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEX_SERVER_GIVEN_PORT, &m_bIndexServerGivenPort));
	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEX_SERVER_PORT, &m_lIndexServerPort));
	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEX_REPLY_PORT, &m_lIndexReplyPort));
	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEX_MAXROWS, &m_lIndexMaxRows));

	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEX_SOURCE_SERVER, &m_strIndexSourceServer));
	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEX_SOURCE, &m_strIndexSource));
	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEX_PRODUCT, &m_strIndexProduct));
	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEX_EXETYPE, &m_strIndexExeType));
	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEX_EXE, &m_strIndexExe));
	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEX_PROJECT, &m_strIndexProject));
	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEX_RENDERFUNCTION, &m_strIndexRenderFunction));
	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEX_REP_USER, &m_strIndexRepUser));
	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEX_REP_PASSWORD, &m_strIndexRepPassword));
	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEX_HTTPS, &m_bIndexHTTPS));
	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEX_HTTP_DOMAIN, &m_strIndexHTTPDomain));
	m_propertyMap.insert(PropertyMap::value_type(KEY_INDE_HTTP_USER, &m_strIndexHTTPUser));
	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEX_HTTP_PASSWORD, &m_strIndexHTTPPassword));
	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEX_SERVER_USERPWD, &m_strIndexServerUserPwd));
	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEX_LATEST_VERSION_SOURCE, &m_strIndexLatestVersionSource));
	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEX_ALL_VERSIONS_SOURCE, &m_strIndexAllVersionsSource));

	// Digital Safe config
	m_propertyMap.insert(PropertyMap::value_type(KEY_DIGITAL_SAFE_SSL_KEY_FILE, &m_strDigitalSafeSSLKeyFile));
	m_propertyMap.insert(PropertyMap::value_type(KEY_DIGITAL_SAFE_SSL_KEY_FILE_PASSWORD, &m_strDigitalSafeSSLKeyFilePassword));
	m_propertyMap.insert(PropertyMap::value_type(KEY_DIGITAL_SAFE_SSL_CA_CERT, &m_strDigitalSafeSSLCACert));
	m_propertyMap.insert(PropertyMap::value_type(KEY_DIGITAL_SAFE_SSL_CA_PATH, &m_strDigitalSafeSSLCAPath));
	m_propertyMap.insert(PropertyMap::value_type(KEY_DIGITAL_SAFE_URL, &m_strDigitalSafeURL));
	m_propertyMap.insert(PropertyMap::value_type(KEY_DIGITAL_SAFE_MAILFROM, &m_strDigitalSafeMailFrom));
	m_propertyMap.insert(PropertyMap::value_type(KEY_DIGITAL_SAFE_RCPTTO, &m_strDigitalSafeRcptTo));
	m_propertyMap.insert(PropertyMap::value_type(KEY_DIGITAL_SAFE_DOMAIN_NAME, &m_strDigitalSafeDomainName));

	// IDOL config
	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEX_REPOSITORY_NAME, &m_strRepositoryName));
	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEX_SECURITY_KEY1, &m_lSecurityKey1));
	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEX_SECURITY_KEY2, &m_lSecurityKey2));
	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEX_SECURITY_KEY3, &m_lSecurityKey3));
	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEX_SECURITY_KEY4, &m_lSecurityKey4));
	m_propertyMap.insert(PropertyMap::value_type(KEY_ABRIDGED_SEARCH_RESULTS, &m_bAbridgedSearchResults));
	m_propertyMap.insert(PropertyMap::value_type(KEY_COMBINE_SORT, &m_bCombineSort));
	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEX_TIMEOUT, &m_lIndexTimeout));
	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEX_IDOL_BIAS, &m_strIDOLBias));
	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEX_IDOL_WORKSPACE_FILTER, &m_strIDOLWorkSpaceFilter));
	m_propertyMap.insert(PropertyMap::value_type(KEY_IDOL_ALL_VERSIONS_COMBINE, &m_strAllVersionsCombine));
	m_propertyMap.insert(PropertyMap::value_type(KEY_IDOL_LATEST_VERSION_COMBINE, &m_strLatestVersionCombine));
	m_propertyMap.insert(PropertyMap::value_type(KEY_AND_TEXT_QUERY_TERMS, &m_bANDTextQueryTerms));
	m_propertyMap.insert(PropertyMap::value_type(KEY_METADATA_ONLY_INDEX, &m_bMetaDataOnlyIndex));
	m_propertyMap.insert(PropertyMap::value_type(KEY_WORKSPACE_INDEX, &m_bWorkSpaceIndex));
	m_propertyMap.insert(PropertyMap::value_type(KEY_IDOL_CUSTOM_PARAMS, &m_strCustomParams));
	m_propertyMap.insert(PropertyMap::value_type(KEY_GROUP_CACHE_EXPIRATION, &m_lGroupCacheExpirationInSeconds));

	m_propertyMap.insert(PropertyMap::value_type(KEY_VERSION_EDITING, &m_lVersionEditing));
	m_propertyMap.insert(PropertyMap::value_type(KEY_WORKLIST_MODE, &m_lWorklistMode));
	m_propertyMap.insert(PropertyMap::value_type(KEY_CONSOLIDATE_WORKLIST, &m_bConsolidateWorklist));
	m_propertyMap.insert(PropertyMap::value_type(KEY_PERFORM_OCR_REPLACEMENT, &m_bPerformOCRReplacement));
	m_propertyMap.insert(PropertyMap::value_type(KEY_INCLUDE_DISABLED_GROUPS, &m_bIncludeDisabledGroups));
	m_propertyMap.insert(PropertyMap::value_type(KEY_WEB_CONTENT, &m_bWebContent));
	m_propertyMap.insert(PropertyMap::value_type(KEY_HIDDEN, &m_bHidden));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SORT_ORDER_MASK, &m_lSortOrderMask));

	m_propertyMap.insert(PropertyMap::value_type(KEY_UNDECLARE_RECORD, &m_lUndeclareRecord));

	m_propertyMap.insert(PropertyMap::value_type(KEY_GIVEN_PROXY_SERVICE_PORT, &m_bGivenProxyServicePort));
	m_propertyMap.insert(PropertyMap::value_type(KEY_PROXY_SERVICE_PORT, &m_lProxyServicePort));
	m_propertyMap.insert(PropertyMap::value_type(KEY_PROXY_REPLY_PORT, &m_lProxyReplyPort));
	m_propertyMap.insert(PropertyMap::value_type(KEY_GIVEN_PROXY_FILE_PORT, &m_bGivenProxyFilePort));
	m_propertyMap.insert(PropertyMap::value_type(KEY_PROXY_FILE_PORT, &m_lProxyFilePort));
	m_propertyMap.insert(PropertyMap::value_type(KEY_PROXY_IMPERSONATION, &m_strImpersonationPassword));
	m_propertyMap.insert(PropertyMap::value_type(KEY_LOCALE, &m_lLocale));

	m_propertyMap.insert(PropertyMap::value_type(KEY_CHANGE_QUEUE_TRUNCATION_TIME, &m_lChangeQueueTruncationTime));
	m_propertyMap.insert(PropertyMap::value_type(KEY_CHANGE_QUEUE_SIZE, &m_lChangeQueueSizeInDays));
    m_propertyMap.insert(PropertyMap::value_type(KEY_CHANGE_QUEUE_TRUNCATION_DISABLED, &m_bChangeQueueTruncationDisabled));
    m_propertyMap.insert(PropertyMap::value_type(KEY_CHANGE_QUEUE_CACHE_SIZE, &m_lChangeQueueCacheSizeInMinutes));
    m_propertyMap.insert(PropertyMap::value_type(KEY_CHANGE_QUEUE_CACHE_DISABLED, &m_bChangeQueueCacheDisabled));
    m_propertyMap.insert(PropertyMap::value_type(KEY_CHANGE_QUEUE_CACHE_REFRESH, &m_lChangeQueueCacheRefreshInSeconds));

	// Hp Flow
	TCHAR KEY_REG_PATH[1024];
	_tcscpy(KEY_REG_PATH,KEY_DMS_DB_PATH);
	_tcscat(KEY_REG_PATH,_T("\\"));
	_tcscat(KEY_REG_PATH,szDatabaseName_);
	long lConnType = -1;

	IM::Registry	dbReg(NULL, HKEY_LOCAL_MACHINE, KEY_REG_PATH);
	if (dbReg.Open(NULL, KEY_READ))
	{
		dbReg.GetLongValue (_T("Connection Type"), lConnType);
	}
	
	// It should not be filtered here, has been done inside RegistryMap::StoreInRegistry
	
	m_propertyMap.insert(PropertyMap::value_type(KEY_HPFLOW_KEY_FILE_PWD, &m_strHpFlowKeyFilePWD));
	m_propertyMap.insert(PropertyMap::value_type(KEY_HPFLOW_KEY_FILE_PATH, &m_strHpFlowKeyFilePath));
	m_propertyMap.insert(PropertyMap::value_type(KEY_TRUSTEDLSLOGIN, &m_bLSTrustedLogin));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SSOURL, &m_strSSOUrl));
	m_propertyMap.insert(PropertyMap::value_type(KEY_BASEURL, &m_strBaseUrl));
	m_propertyMap.insert(PropertyMap::value_type(KEY_PROXYURL, &m_strProxyServer));
	m_propertyMap.insert(PropertyMap::value_type(KEY_FOLDERNAMEFORMAT, &m_strFolderNameFormat));
	m_propertyMap.insert(PropertyMap::value_type(KEY_CLIENTID, &m_strClientID));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SFURL, &m_strSFUrl));
	m_propertyMap.insert(PropertyMap::value_type(KEY_COMPANYEMAILDOMAINS, &m_strCompanyEmailDomains));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SECURESENTFOLDERNAME, &m_strSecureSentFolderName));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SECURELINK_FOLDER_LOCATION, &m_strSecureLinkFolderLocation));
	m_propertyMap.insert(PropertyMap::value_type(KEY_HPFLOW_AUTHENTICATED_PROXY, &m_bAuthenticatedProxy));
	m_propertyMap.insert(PropertyMap::value_type(KEY_HPFLOW_PROXY_USERNAME, &m_strProxyUserName));
	m_propertyMap.insert(PropertyMap::value_type(KEY_HPFLOW_PROXY_PSWD, &m_strProxyPassword));
	m_propertyMap.insert(PropertyMap::value_type(KEY_DISABLE_IDOL_TERM_EXPAND, &m_bDisableIDOLTermExpand));
	m_propertyMap.insert(PropertyMap::value_type(KEY_IMANSHARE_CONNECT_TIMEOUT, &m_lIManShareConnectTimeout));
	m_propertyMap.insert(PropertyMap::value_type(KEY_IMANSHARE_READ_TIMEOUT, &m_lIManShareReadTimeout));

	// SEV Configuration
	m_propertyMap.insert(PropertyMap::value_type(KEY_SEV_MINIMUM_DOCNUM, &m_lSEVMinDocNum));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SEV_MAXIMUM_DOCNUM, &m_lSEVMaxDocNum));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SEV_ALLOW_DOCNUM_INSERT, &m_bSEVAllowDocnumInsert));

    // Sync event logging
    m_propertyMap.insert(PropertyMap::value_type(KEY_SYNC_LOGGING_MODE, &m_lSyncLoggingMode));

	// Ocr
	m_propertyMap.insert(PropertyMap::value_type(KEY_OCR_RENDITION_FOLDER, &m_lOCRRenditionFolder));

	
	//
	// Default attribute values.
	//
	m_strHpFlowKeyFilePWD.SetEncryptFlag(true);
	m_strHpFlowKeyFilePWD.Set(_T(""));
	m_strHpFlowKeyFilePath.Set(_T(""));
	m_bLSTrustedLogin.Set (false);
	m_strSSOUrl.Set (_T("https://www.imanageshare.com"));
	m_strBaseUrl.Set (_T("https://www.imanageshare.com/api/v2"));
	m_strProxyServer.Set (_T(""));
	m_strFolderNameFormat.Set (_T("%C1ALIAS%-%C2ALIAS%.%WORKSPACE_NAME%"));
	m_strClientID.Set(_T("e142d188-745e-4ac8-ba71-7c575ac5be10"));
	m_strSFUrl.Set(_T("https://www.imanageshare.com"));
	m_strCompanyEmailDomains.Set(_T(""));
	m_strSecureSentFolderName.Set(_T("Secure Sent Links"));
	m_strSecureLinkFolderLocation.Set (_T("My Favorites"));
	m_bAuthenticatedProxy.Set(false);
	m_strProxyUserName.Set(_T(""));
	m_strProxyPassword.Set(_T(""));
	

	m_lIndexConnectType.Set(4);
	m_lIndexConnectionCount.Set(m_lConnectionCount.Get());
	m_bIndexServerGivenPort.Set(false);
	m_lIndexServerPort.Set(9000);
	m_lIndexReplyPort.Set(0);
	m_lIndexMaxRows.Set(20000);
	m_lVersionEditing.Set(0);
	m_lWorklistMode.Set(0);
	m_bConsolidateWorklist.Set(false);
	m_bPerformOCRReplacement.Set(false);
	m_bIncludeDisabledGroups.Set(true);
	m_bWebContent.Set(false);
	m_bHidden.Set(false);
	m_lSortOrderMask.Set(0);

	m_strRepositoryName.Set(_T("Worksite_V4"));
	m_lSecurityKey1.Set(123);
	m_lSecurityKey2.Set(144);
	m_lSecurityKey3.Set(564);
	m_lSecurityKey4.Set(231);
	m_bAbridgedSearchResults.Set(true);
	m_bCombineSort.Set(false);
	m_lIndexTimeout.Set(30);
	m_strIDOLBias.Set(_T("BIASDATE{%NOW%,2592000,20}:autn_date+AND+BIASDATE{%NOW%,63072000,20}:autn_date"));
	m_strIDOLWorkSpaceFilter.Set(_T("EQUAL{%ID%}:IM_TREEID"));
	m_strAllVersionsCombine.Set(_T("IM_DOCVERFAM"));
	m_strLatestVersionCombine.Set(_T("fieldcheck"));
	m_bANDTextQueryTerms.Set(true);
	m_bMetaDataOnlyIndex.Set(false);
	m_bWorkSpaceIndex.Set(false);
	m_lGroupCacheExpirationInSeconds.Set(0);

	m_bGivenProxyServicePort.Set(false);
	m_lProxyServicePort.Set(1080);
	m_lProxyReplyPort.Set(0);
	m_bGivenProxyFilePort.Set(false);
	m_lProxyFilePort.Set(1081);
	m_lLocale.Set(1033);

	m_lUndeclareRecord.Set(0);

	m_strIndexProduct.Set(_T("UniversalSearch"));
	m_strIndexExeType.Set(_T("cgi-bin"));
	m_strIndexExe.Set(_T("query-meta.exe"));
	m_strIndexProject.Set(_T("worksite"));
	m_strIndexRenderFunction.Set(_T("worksite-xml-feed"));
	m_bIndexHTTPS.Set(false);

    m_lChangeQueueTruncationTime.Set(2);
    m_lChangeQueueSizeInDays.Set(7);
    m_lChangeQueueCacheSizeInMinutes.Set(10);
    m_lChangeQueueCacheRefreshInSeconds.Set(5);

	m_lSEVMinDocNum.Set(1);
	m_lSEVMaxDocNum.Set(0);
	m_bSEVAllowDocnumInsert.Set(false);

	m_bDisableIDOLTermExpand.Set(false);
	m_lIManShareConnectTimeout.Set(3);
	m_lIManShareReadTimeout.Set(60);

    m_lSyncLoggingMode.Set(0);

	m_lOCRRenditionFolder.Set(-1);
}

	DmsDatabaseEntry::DmsDatabaseEntry(const DmsDatabaseEntry *pEntry_)
			: DatabaseEntry(pEntry_->m_strComputerName.c_str(), KEY_DMS_DB_PATH, pEntry_->m_strDatabase.Get().c_str())
{
	m_lIndexConnectType.Set(pEntry_->m_lIndexConnectType.Get());
	m_lIndexConnectionCount.Set(pEntry_->m_lIndexConnectionCount.Get());

	m_strIndexServer.Set(pEntry_->m_strIndexServer.Get().c_str());

	m_bIndexServerGivenPort.Set(pEntry_->m_bIndexServerGivenPort.Get());
	m_lIndexServerPort.Set(pEntry_->m_lIndexServerPort.Get());
	m_lIndexReplyPort.Set(pEntry_->m_lIndexReplyPort.Get());
	m_lIndexMaxRows.Set(pEntry_->m_lIndexMaxRows.Get());

	m_strIndexSourceServer.Set(pEntry_->m_strIndexSourceServer.Get().c_str());
	m_strIndexSource.Set(pEntry_->m_strIndexSource.Get().c_str());
	m_strIndexProduct.Set(pEntry_->m_strIndexProduct.Get().c_str());
	m_strIndexExeType.Set(pEntry_->m_strIndexExeType.Get().c_str());
	m_strIndexExe.Set(pEntry_->m_strIndexExe.Get().c_str());
	m_strIndexProject.Set(pEntry_->m_strIndexProject.Get().c_str());
	m_strIndexRenderFunction.Set(pEntry_->m_strIndexRenderFunction.Get().c_str());
	m_strIndexRepUser.Set(pEntry_->m_strIndexRepUser.Get().c_str());
	m_strIndexRepPassword.Set(pEntry_->m_strIndexRepPassword.Get().c_str());
	m_bIndexHTTPS.Set(pEntry_->m_bIndexHTTPS.Get());
	m_strIndexHTTPDomain.Set(pEntry_->m_strIndexHTTPDomain.Get().c_str());
	m_strIndexHTTPUser.Set(pEntry_->m_strIndexHTTPUser.Get().c_str());
	m_strIndexHTTPPassword.Set(pEntry_->m_strIndexHTTPPassword.Get().c_str());
	m_strIndexServerUserPwd.Set(pEntry_->m_strIndexServerUserPwd.Get().c_str());
	m_strIndexLatestVersionSource.Set(pEntry_->m_strIndexLatestVersionSource.Get().c_str());
	m_strIndexAllVersionsSource.Set(pEntry_->m_strIndexAllVersionsSource.Get().c_str());

	m_lVersionEditing.Set(pEntry_->m_lVersionEditing.Get());
	m_lWorklistMode.Set(pEntry_->m_lWorklistMode.Get());
	m_bConsolidateWorklist.Set(pEntry_->m_bConsolidateWorklist.Get());
	m_bPerformOCRReplacement.Set(pEntry_->m_bPerformOCRReplacement.Get());
	m_bIncludeDisabledGroups.Set(pEntry_->m_bIncludeDisabledGroups.Get());
	m_bWebContent.Set(pEntry_->m_bWebContent.Get());
	m_bHidden.Set(pEntry_->m_bHidden.Get());
	m_lSortOrderMask.Set(pEntry_->m_lSortOrderMask.Get());

	m_bGivenProxyServicePort.Set(pEntry_->m_bGivenProxyServicePort.Get());
	m_lProxyServicePort.Set(pEntry_->m_lProxyServicePort.Get());
	m_lProxyReplyPort.Set(pEntry_->m_lProxyReplyPort.Get());
	m_bGivenProxyFilePort.Set(pEntry_->m_bGivenProxyFilePort.Get());
	m_lProxyFilePort.Set(pEntry_->m_lProxyFilePort.Get());
	m_lLocale.Set(pEntry_->m_lLocale.Get());
    
    m_lChangeQueueTruncationTime.Set(pEntry_->m_lChangeQueueTruncationTime.Get());
    m_lChangeQueueSizeInDays.Set(pEntry_->m_lChangeQueueSizeInDays.Get());
    m_bChangeQueueTruncationDisabled.Set(pEntry_->m_bChangeQueueTruncationDisabled.Get());
    m_lChangeQueueCacheSizeInMinutes.Set(pEntry_->m_lChangeQueueCacheSizeInMinutes.Get());

	m_lOCRRenditionFolder.Set(pEntry_->m_lOCRRenditionFolder.Get());
}


void
DmsDatabaseEntry::GetRegistryMap(PropertyMap *&pPropertyMap_)
{
	pPropertyMap_ = &(m_propertyMap);
}



IdxMgrDatabaseEntry::IdxMgrDatabaseEntry(const TCHAR *szComputerName_, const TCHAR *szDatabaseName_)
			: DatabaseEntry(szComputerName_, KEY_IDXMGR_DB_PATH, szDatabaseName_)
{
}

IdxSearchDatabaseEntry::IdxSearchDatabaseEntry(const TCHAR *szComputerName_, const TCHAR *szDatabaseName_)
			: DatabaseEntry(szComputerName_, KEY_IDXSCH_DB_PATH, szDatabaseName_)
{
	m_lIndexMaxRows.Set(25000);

	m_propertyMap.insert(PropertyMap::value_type(KEY_INDEX_MAXROWS, &m_lIndexMaxRows));
}

ReDatabaseEntry::ReDatabaseEntry(const TCHAR *szComputerName_, const TCHAR *szDatabaseName_)
			: DatabaseEntry(szComputerName_, KEY_RE_DB_PATH, szDatabaseName_)
{
}

WkIndxrDatabaseEntry::WkIndxrDatabaseEntry(const TCHAR *szComputerName_, const TCHAR *szDatabaseName_)
			: DatabaseEntry(szComputerName_, KEY_WKINDXRSVC_DB_PATH, szDatabaseName_)
{
}

WkDreDatabaseEntry::WkDreDatabaseEntry(const TCHAR *szComputerName_, const TCHAR *szDatabaseName_)
			: DatabaseEntry(szComputerName_, KEY_WKDRESVC_DB_PATH, szDatabaseName_)
{
}

DsSyncDatabaseEntry::DsSyncDatabaseEntry(const TCHAR *szComputerName_, const TCHAR *szDatabaseName_)
			: DatabaseEntry(szComputerName_, KEY_DSSYNCSVC_DB_PATH, szDatabaseName_)
{
}

///////////////////////////////////////////////////////////////////////////////
//
//	derived classes of DatabaseEntryList
//
///////////////////////////////////////////////////////////////////////////////


//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

DmsDatabaseList::DmsDatabaseList(const _TCHAR *strComputerName_) :
			DatabaseEntryList(strComputerName_, KEY_DMS_DB_PATH)
{
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

IdxMgrDatabaseList::IdxMgrDatabaseList(const _TCHAR *strComputerName_) :
			DatabaseEntryList(strComputerName_, KEY_IDXMGR_DB_PATH)
{
}


//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

IdxSearchDatabaseList::IdxSearchDatabaseList(const _TCHAR *strComputerName_) :
			DatabaseEntryList(strComputerName_, KEY_IDXSCH_DB_PATH)
{
}


//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

ReDatabaseList::ReDatabaseList(const _TCHAR *strComputerName_) :
			DatabaseEntryList(strComputerName_, KEY_RE_DB_PATH)
{
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

WkIndxrDatabaseList::WkIndxrDatabaseList(const _TCHAR *strComputerName_) :
			DatabaseEntryList(strComputerName_, KEY_WKINDXRSVC_DB_PATH)
{
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

DsSyncDatabaseList::DsSyncDatabaseList(const _TCHAR *strComputerName_) :
			DatabaseEntryList(strComputerName_, KEY_DSSYNCSVC_DB_PATH)
{
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

WkDreDatabaseList::WkDreDatabaseList(const _TCHAR *strComputerName_) :
			DatabaseEntryList(strComputerName_, KEY_WKDRESVC_DB_PATH)
{
}

void WkDreDatabaseList::LoadAll()
{
	ClearList();

	WkDreServiceConfiguration WkDre( m_strComputerName.c_str() );
	WkDre.LoadFromRegistry();

	const TCHAR* szTemp = WkDre.m_strDreIniFilePath.Get().c_str();

	UINT uNumDbs = GetPrivateProfileInt( _T("DATABASES"), _T("NUMDBS"), 0, WkDre.m_strDreIniFilePath.Get().c_str());
  // if no DBs case, uNumDbs == -1
    int         lNumDbs = (int)uNumDbs;
    if( lNumDbs < 0 )
        uNumDbs = 0;

	for( UINT uIndex = 0; uIndex < uNumDbs; uIndex++ )
	{
		TCHAR szNum[ 8 ];
		memset( szNum, 8, 8 * sizeof( TCHAR ) );
		wsprintf( szNum, _T( "%u" ), uIndex );

		TCHAR szDatabase[ 32 ];
		memset( szDatabase, 0, 32 * sizeof( TCHAR ) );

		GetPrivateProfileString( _T("DATABASES"), szNum, _T(""), szDatabase, 32, WkDre.m_strDreIniFilePath.Get().c_str());

		WkDreDatabaseEntry* pEntry = im_new WkDreDatabaseEntry( m_strComputerName.c_str(), szDatabase );

		push_back(IM::STLPointer<DatabaseEntry>(static_cast<DatabaseEntry *>(pEntry)));
	}
	
}

void WkDreDatabaseList::Add(DatabaseEntry* pEntry)
{
	DatabaseEntryList::Add(pEntry);

	WkDreServiceConfiguration WkDre( m_strComputerName.c_str() );
	WkDre.LoadFromRegistry();

	// clear INI section "DATABASES"
	WritePrivateProfileString( _T("DATABASES"), NULL, NULL, WkDre.m_strDreIniFilePath.Get().c_str());

	TCHAR szNumDbs[ 16 ];
	memset( szNumDbs, 0, 16 * sizeof( TCHAR ) );
	wsprintf( szNumDbs, _T("%i"), size() );

	// now create "DATABASES" section anew
	WritePrivateProfileString( _T("DATABASES"), _T("NUMDBS"), szNumDbs, WkDre.m_strDreIniFilePath.Get().c_str());

	UINT uIndex = 0;
	for( DatabaseEntryPointerList::iterator iter = begin(); iter != end(); iter++ )
	{
		IM::STLPointer<DatabaseEntry> pEntry = *iter;
		
		TCHAR szKey[ 8 ];
		memset( szKey, 0, 8 * sizeof( TCHAR ) );
		wsprintf( szKey, _T("%u"), uIndex );

		TCHAR szDbName[ 32 ];
		memset( szDbName, 0, 32 * sizeof( TCHAR ) );
		wsprintf( szDbName, _T("%s"), pEntry->m_strDatabase.Get().c_str() );

		WritePrivateProfileString( _T("DATABASES"), szKey, szDbName, WkDre.m_strDreIniFilePath.Get().c_str());

		if( WkDre.m_bWkEnable.Get() )
		{
			TCHAR szSecSection[ 32 ];
			memset( szSecSection, 0, 32 * sizeof( TCHAR ) );
			wsprintf( szSecSection, _T("%sSEC"), szDbName );

			// write out two security sections
			WritePrivateProfileString( szDbName, _T("SECURITY"), szSecSection, WkDre.m_strDreIniFilePath.Get().c_str() );
			
			WritePrivateProfileString( szSecSection, _T("LIBRARY"), _T("imDRESecurity.dll"), WkDre.m_strDreIniFilePath.Get().c_str() );
			WritePrivateProfileString( szSecSection, _T("DBName"), szDbName, WkDre.m_strDreIniFilePath.Get().c_str() );
		}
		else
		{
			// delete the entire section
			WritePrivateProfileString( szDbName, NULL, NULL, WkDre.m_strDreIniFilePath.Get().c_str() );

			// delete this section too
			TCHAR szSecSection[ 32 ];
			memset( szSecSection, 0, 32 * sizeof( TCHAR ) );
			wsprintf( szSecSection, _T("%sSEC"), szDbName );

			WritePrivateProfileString( szSecSection, NULL, NULL, WkDre.m_strDreIniFilePath.Get().c_str() );
		}
		uIndex++;
	}
}

void
	WkDreDatabaseList::Remove(const _TCHAR *szDatabase_)
{
	// remove entry from list
	DatabaseEntryListIterator	it;
	DatabaseEntry				*pEntry;

	for (it = begin(); it != end(); ++it)
	{
		pEntry = it->get();

		if (pEntry->m_strDatabase.Get().compare(szDatabase_) == 0)
		{
			erase(it);
			break;	// reset iterator after erase
		}
	}

	// now remove entry from registry
	WkDreServiceConfiguration WkDre( m_strComputerName.c_str() );
	WkDre.LoadFromRegistry();

	// clear INI section "DATABASES"
	WritePrivateProfileString( _T("DATABASES"), NULL, NULL, WkDre.m_strDreIniFilePath.Get().c_str());

	TCHAR szNumDbs[ 16 ];
	memset( szNumDbs, 0, 16 * sizeof( TCHAR ) );
	wsprintf( szNumDbs, _T("%i"), size() );  //  -1 );  // SASHA; 03/20/2002

	// now create "DATABASES" section anew
	WritePrivateProfileString( _T("DATABASES"), _T("NUMDBS"), szNumDbs, WkDre.m_strDreIniFilePath.Get().c_str());

	UINT uIndex = 0;
	for( DatabaseEntryPointerList::iterator iter = begin(); iter != end(); iter++ )
	{
		IM::STLPointer<DatabaseEntry> pEntry = *iter;
		
		TCHAR szKey[ 8 ];
		memset( szKey, 0, 8 * sizeof( TCHAR ) );
		wsprintf( szKey, _T("%u"), uIndex );

		TCHAR szDbName[ 32 ];
		memset( szDbName, 0, 32 * sizeof( TCHAR ) );
		wsprintf( szDbName, _T("%s"), pEntry->m_strDatabase.Get().c_str() );

		WritePrivateProfileString( _T("DATABASES"), szKey, szDbName, WkDre.m_strDreIniFilePath.Get().c_str());

		uIndex++;
	}

	TCHAR szSecSection[ 32 ];
	memset( szSecSection, 0, 32 * sizeof( TCHAR ) );
	wsprintf( szSecSection, _T("%sSEC"), szDatabase_ );

	// write out two security sections
	WritePrivateProfileString( szDatabase_, NULL, NULL, WkDre.m_strDreIniFilePath.Get().c_str() );
	
	WritePrivateProfileString( szSecSection, NULL, NULL, WkDre.m_strDreIniFilePath.Get().c_str() );
}
