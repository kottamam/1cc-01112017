//This class has been implemented for NT-28236 -- 9.0 upgrade/installer enhancement
//The customer customized registry key will be at "HKLM\SOFTWARE\\Interwoven\Worksite\8.0\.."
//The installer default value will be at "HKLM\SOFTWARE\\Interwoven\Worksite\Client\.."
//Get value functions will try to read the value from "HKLM\...\WorkSite\8.0\.." frist
//If the key doesn't exist or available, the value will be read from the "HKLM\..\WorkSite\Client\.." path.
//This class is intended only for reading the client customized keys. 
//Please do not use this class for anyother Registy Read or Write operations.

#pragma once
#include <stl\NrString.h>

class CClientRegKey
{
public:
	CClientRegKey(void);
	~CClientRegKey(void);

	static bool	GetStringValue(const TCHAR *szSubKeyPath, const TCHAR *szName_, IM::NrString& strValue_);	
	static bool	SetStringValue(const TCHAR *szSubKeyPath, const TCHAR *szName_, IM::NrString strValue_);
	static bool	GetLongValue(const TCHAR *szSubKeyPath, const TCHAR *szName_, long &lValue_);
	static bool	SetLongValue(const TCHAR *szSubKeyPath, const TCHAR *szName_, long lValue_);
	static bool	GetDWORDValue(const TCHAR *szSubKeyPath, const TCHAR *szName_, DWORD &dValue_);
	static bool	SetDWORDValue(const TCHAR *szSubKeyPath, const TCHAR *szName_, DWORD dValue_);
};

