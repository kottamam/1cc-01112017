////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// File:	OffSiteConfiguration.cpp
//
// Project: OffSite			Subsystem: Registry
//
// Contents:	Implements the registry configuration information for the EMS service.
//
//   Date    Who  Modification
// 07/21/04  AED  Initial coding.
//
// Copyright (C) 2004, Interwoven, Inc. ALL RIGHTS RESERVED
//                     PROPRIETARY AND CONFIDENTIAL
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include <RegistryLib.h>
#include <OffSiteConfiguration.h>

#pragma hdrstop

using namespace IM;

#define KEY_IS_OFFSITE_INSTALLED				TEXT("Is OffSite Installed")
#define KEY_SERVER_NAME							TEXT("OffSite")
#define KEY_LAST_SYNC_TIME						TEXT("Last Sync Time")
#define KEY_CHUNK_SIZE							TEXT("Chunk Size")
#define KEY_ADMINISTRATIVE_USERNAME				TEXT("Administrative Username")
#define KEY_ADMINISTRATIVE_PASSWORD				TEXT("Administrative Password")
#define KEY_LOGIN_USERNAME						TEXT("Login Username")
#define KEY_LOGIN_PASSWORD						TEXT("Login Password")
#define KEY_DATABASE_ADMINISTRATIVE_USERNAME	TEXT("Database Administrative Username")
#define KEY_DATABASE_ADMINISTRATIVE_PASSWORD	TEXT("Database Administrative Password")
#define KEY_DEFAULT_NRTWEBADMIN_PASSWORD		TEXT("Default NRTWEBADMIN Password")
#define KEY_LOCAL_SERVER_ADDRESS				TEXT("Local Server Address")
#define KEY_LOCAL_SERVER_PORT					TEXT("Local Server Port")
#define KEY_DEFAULT_DSN_DRIVER					TEXT("Default DSN Driver")
#define KEY_DEFAULT_DSN_LASTUSER				TEXT("Default DSN LastUser")
#define KEY_DEFAULT_DSN_SERVER					TEXT("Default DSN Server")


const bool		OffSiteConfiguration::ms_bDefaultIsOffSiteInstalled					= true;
const NrString	OffSiteConfiguration::ms_strDefaultServerName						= _T("OffSite");
const long		OffSiteConfiguration::ms_lDefaultLastSyncTime						= 0L;
const NrString	OffSiteConfiguration::ms_strDefaultChunkSize						= _T("");
const NrString	OffSiteConfiguration::ms_strDefaultAdministrativeUsername			= _T("");
const NrString	OffSiteConfiguration::ms_strDefaultAdministrativePassword			= _T("");
const NrString	OffSiteConfiguration::ms_strDefaultLoginUsername					= _T("");
const NrString	OffSiteConfiguration::ms_strDefaultLoginPassword					= _T("");
const NrString	OffSiteConfiguration::ms_strDefaultDatabaseAdministrativeUsername	= _T("");
const NrString	OffSiteConfiguration::ms_strDefaultDatabaseAdministrativePassword	= _T("");
const NrString	OffSiteConfiguration::ms_strDefaultDefaultNRTWEBADMINPassword		= _T("");
const NrString	OffSiteConfiguration::ms_strDefaultLocalServerAddress				= _T("");
const long		OffSiteConfiguration::ms_lDefaultLocalServerPort					= 0L;
const NrString	OffSiteConfiguration::ms_strDefaultDefaultDSNDriver					= _T("");
const NrString	OffSiteConfiguration::ms_strDefaultDefaultDSNLastUser				= _T("");
const NrString	OffSiteConfiguration::ms_strDefaultDefaultDSNServer					= _T("");



//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	OffSiteConfiguration - Default constructor
//
OffSiteConfiguration::OffSiteConfiguration(const TCHAR *szComputerName_) :
	ServiceConfiguration(szComputerName_, KEY_OFFSITESVC_PATH, SZ_OFFSITESVC_NAME),
			m_bIsOffSiteInstalled(					ms_bDefaultIsOffSiteInstalled						),
			m_strServerName(						ms_strDefaultServerName.c_str()						),
			m_lLastSyncTime(						ms_lDefaultLastSyncTime								),
			m_strChunkSize(							ms_strDefaultChunkSize.c_str()						),
			m_strAdministrativeUsername(			ms_strDefaultAdministrativeUsername.c_str()			),
			m_strAdministrativePassword(			ms_strDefaultAdministrativePassword.c_str()			),
			m_strLoginUsername(						ms_strDefaultLoginUsername.c_str()					),
			m_strLoginPassword(						ms_strDefaultLoginPassword.c_str()					),
			m_strDatabaseAdministrativeUsername(	ms_strDefaultDatabaseAdministrativeUsername.c_str()	),
			m_strDatabaseAdministrativePassword(	ms_strDefaultDatabaseAdministrativePassword.c_str()	),
			m_strDefaultNRTWEBADMINPassword(		ms_strDefaultDefaultNRTWEBADMINPassword.c_str()		),
			m_strLocalServerAddress(				ms_strDefaultLocalServerAddress.c_str()				),
			m_lLocalServerPort(						ms_lDefaultLocalServerPort							),
			m_strDefaultDSNDriver(					ms_strDefaultDefaultDSNDriver.c_str()				),
			m_strDefaultDSNLastUser(				ms_strDefaultDefaultDSNLastUser.c_str()				),
			m_strDefaultDSNServer(					ms_strDefaultDefaultDSNServer.c_str()				)
{
	m_propertyMap.insert(PropertyMap::value_type(KEY_IS_OFFSITE_INSTALLED,				&m_bIsOffSiteInstalled					));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SERVER_NAME,						&m_strServerName						));
	m_propertyMap.insert(PropertyMap::value_type(KEY_LAST_SYNC_TIME,					&m_lLastSyncTime						));
	m_propertyMap.insert(PropertyMap::value_type(KEY_CHUNK_SIZE,						&m_strChunkSize							));
	m_propertyMap.insert(PropertyMap::value_type(KEY_ADMINISTRATIVE_USERNAME,			&m_strAdministrativeUsername			));
	m_propertyMap.insert(PropertyMap::value_type(KEY_ADMINISTRATIVE_PASSWORD,			&m_strAdministrativePassword			));
	m_propertyMap.insert(PropertyMap::value_type(KEY_LOGIN_USERNAME,					&m_strLoginUsername						));
	m_propertyMap.insert(PropertyMap::value_type(KEY_LOGIN_PASSWORD,					&m_strLoginPassword						));
	m_propertyMap.insert(PropertyMap::value_type(KEY_DATABASE_ADMINISTRATIVE_USERNAME,	&m_strDatabaseAdministrativeUsername	));
	m_propertyMap.insert(PropertyMap::value_type(KEY_DATABASE_ADMINISTRATIVE_PASSWORD,	&m_strDatabaseAdministrativePassword	));
	m_propertyMap.insert(PropertyMap::value_type(KEY_DEFAULT_NRTWEBADMIN_PASSWORD,		&m_strDefaultNRTWEBADMINPassword		));
	m_propertyMap.insert(PropertyMap::value_type(KEY_LOCAL_SERVER_ADDRESS,				&m_strLocalServerAddress				));
	m_propertyMap.insert(PropertyMap::value_type(KEY_LOCAL_SERVER_PORT,					&m_lLocalServerPort						));
	m_propertyMap.insert(PropertyMap::value_type(KEY_DEFAULT_DSN_DRIVER,				&m_strDefaultDSNDriver					));
	m_propertyMap.insert(PropertyMap::value_type(KEY_DEFAULT_DSN_LASTUSER,				&m_strDefaultDSNLastUser				));
	m_propertyMap.insert(PropertyMap::value_type(KEY_DEFAULT_DSN_SERVER,				&m_strDefaultDSNServer					));
}


//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	OffSiteConfiguration - Destructor
//
	OffSiteConfiguration::~OffSiteConfiguration(void)
{
}


//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	LoadFromRegistry
//
void
	OffSiteConfiguration::LoadFromRegistry()
{
	ServiceConfiguration::LoadFromRegistry();
}




long
OffSiteConfiguration::GetStatusLong(void)
{
	long			lCurrentState = 0;
	SERVICE_STATUS	serviceStatus;

	SC_HANDLE		hService = GetServiceHandle();

	if (hService == NULL)
		return -1L;

	if (ControlService(hService, SERVICE_CONTROL_INTERROGATE, &serviceStatus) == TRUE)
	{
		lCurrentState = serviceStatus.dwCurrentState;
	}

	CloseServiceHandle(hService);

	return lCurrentState;
}
