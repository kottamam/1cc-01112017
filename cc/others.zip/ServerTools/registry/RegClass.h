//
//	Class for performing registry operations
//
#ifndef __REG_REGCLASS_H__
#define __REG_REGCLASS_H__

#pragma once

namespace IM
{

class Registry : public ObjectSignature
{
private:

	IM::NrString	m_strRegistryComputerName;
	HKEY			m_hDesiredHive;
	HKEY			m_hRemoteHive;
	HKEY			m_hHive;
	bool			m_bCreatedNew;
	long			m_lEnumerateIndex;

protected:
	IM::NrString	m_strBaseKeyPath;

public:

	IM::NrString	m_strComputerName;

					Registry(const TCHAR *szComputerName_, HKEY hHive_, const TCHAR *szBaseKeyPath_);
	explicit		Registry(const Registry	*pRegistry_);
	virtual			~Registry()		{	Close();	}

	void			SetPath(const TCHAR* szBaseKeyPath) {	m_strBaseKeyPath = szBaseKeyPath; }
	void			AddPath(const TCHAR *szSubKeyPath_)	{	m_strBaseKeyPath += szSubKeyPath_;	}
	bool			IsKeyPresent(HKEY hHive_, const TCHAR *szSubKeyPath_ = NULL);

	bool			Open(const TCHAR *szSubKeyPath_, DWORD dwAccess_,bool donotOpenRemote = false);
	bool			OpenOrCreate(const TCHAR *szSubKeyPath_, DWORD dwAccess_,bool donotOpenRemote = false);
	void			DeleteSubKey(const TCHAR *szSubKeyName_);
	bool			WasKeyCreatedKey()						{ return m_bCreatedNew;	}
	void			Close();

	bool			EnumerateKey(IM::NrString& strSubKey_);
	bool			EnumerateName(IM::NrString& strName_, DWORD &dwType_, TCHAR *szValueBuffer_, long lBufferSize_);
	bool			GetStringValue(const TCHAR *szName_, IM::NrString& strValue_);
	bool			SetStringValue(const TCHAR *szName_, const TCHAR *szValue_);
	bool			GetLongValue(const TCHAR *szName_, long &lValue_);
	bool			SetLongValue(const TCHAR *szName_, long lValue_);
	void			DeleteName(const TCHAR *szName_);

	IM::NrString	GetBaseKeyPath( void ) const { return m_strBaseKeyPath; }
	HKEY			GetDesiredHive( void ) const { return m_hDesiredHive; }
	IM::NrString	GetComputerName( void ) const { return m_strComputerName; }

	static bool		GetStringValue(HKEY hHive_, const TCHAR *szKeyPath_, const TCHAR *szValueName_, IM::NrString& strValueData_);
	static bool		GetLongValue(HKEY hHive_, const TCHAR *szKeyPath_, const TCHAR *szValueName_, long& lValueData_);
};

}; // namespace IM



#endif // __REG_REGCLASS_H__