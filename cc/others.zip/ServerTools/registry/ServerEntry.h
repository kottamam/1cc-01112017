//
//	Classes for managing EMS-to-DMS server connection configuration information in the registry
//


#pragma once

#ifndef __REG_SERVER_ENTRY_H__
#define __REG_SERVER_ENTRY_H__

#include <registry\RegistryMap.h>

namespace IM
{

	class ServerEntry : public IM::RegistryMap
	{
	protected:
		IM::NrString m_strParentKeyPath; // parent location of the server data

	public:

		IM::RegistryStringProperty	m_strServerName;
		IM::RegistryBooleanProperty	m_bSpecifyPort;
		IM::RegistryBooleanProperty	m_bTrustedLogin; //Vinod
		IM::RegistryLongProperty	m_lPort;
		IM::RegistryStringProperty	m_strUsername;
		IM::RegistryStringProperty	m_strPassword;
		IM::RegistryLongProperty	m_lMaxFolderList;
		IM::RegistryLongProperty	m_lTimeout;
		

	public:
						ServerEntry(const TCHAR *szComputerName_, const TCHAR *szBaseKeyPath_, const TCHAR *szServerName_);
						ServerEntry(const ServerEntry& ServerEntry_);
		virtual			~ServerEntry() {}
		ServerEntry&	operator=(const ServerEntry& ServerEntry_);

		void			RemoveFromRegistry();
		void			LogRegistry() const;


		static const NrString	ms_strDefaultServerName;
		static const long		ms_lDefaultPort;
		static const NrString	ms_strDefaultUsername;
		static const NrString	ms_strDefaultPassword;
		static const long		ms_lDefaultMaxFolderList;
		static const long		ms_lDefaultTimeout;
		static const bool		ms_bDefaultSpecifyPort;
		static const bool		ms_bDefaultTrustedLogin; //Vinod
	};


	class EmsDatabaseEntry : public IM::RegistryMap
	{
	protected:
		IM::NrString				m_strParentKeyPath; // parent location of the server data

	public:
		IM::RegistryStringProperty	m_strDatabaseName;

		imstd::vector<ServerEntry>	m_Servers;

	public:
							EmsDatabaseEntry(const TCHAR *szComputerName_, const TCHAR *szBaseKeyPath_, const TCHAR *szDatabaseName_);
							EmsDatabaseEntry(const EmsDatabaseEntry& EmsDatabaseEntry_);
		virtual				~EmsDatabaseEntry() {	m_Servers.clear(); }
		EmsDatabaseEntry&	operator=(const EmsDatabaseEntry& EmsDatabaseEntry_);

		void				RemoveFromRegistry();
		void				AddServerToRegistry(NrString&	strServerName_,
												bool		bSpecifyPort_,
												long		lPort_,
												NrString&	strUsername_,
												NrString&	strPassword_,
												long		lMaxFolderList_);

		void				AddServerToRegistry(NrString&	strServerName_,
												bool		bSpecifyPort_,
												long		lPort_,
												NrString&	strUsername_,
												NrString&	strPassword_,
												long		lMaxFolderList_,
												bool		bTrustedLogin_);

		void				RemoveServerFromRegistry(NrString& strServerName_);
		void				LogRegistry() const;

		static const NrString ms_strDefaultDatabaseName;
		static const NrString ms_strServersSubkey;
	};


}; // namespace IM

#endif // __REG_SERVER_ENTRY_H__
