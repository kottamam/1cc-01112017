////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// File:	LNEMailSvcConfiguration.h
//
// Project: Email Management System		Subsystem: Email Filing Service
//
// Contents:	Implements the registry configuration information for the Email Filing Service.
//
//   Date    Who				Modification
// 22/03/13  Bob Kumar			Initial coding.
//
// Copyright (C) 2002, iManage Technologies, Inc. ALL RIGHTS RESERVED
//                     PROPRIETARY AND CONFIDENTIAL
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma once

#if !defined(__IM_LNEMAILSVCCONFIGURATION_H__)
	#define __IM_LNEMAILSVCCONFIGURATION_H__

	#include <registry/Service.h>
	#include <registry/ServerEntry.h>

	namespace IM
	{
		class LNEMailSvcConfiguration : public IM::ServiceConfiguration
		{
		public:
			//
			// Constructors, destructors and initializers.
			//
					LNEMailSvcConfiguration(const TCHAR *szComputerName_);
			virtual	~LNEMailSvcConfiguration();

		public:
			//
			// ServiceConfiguration
			//
			virtual void	LoadFromRegistry();
			
			void			AddDatabaseToRegistry(NrString& strDatabaseName_);
			
			void			AddDatabaseToRegistry(	NrString&	strDatabaseName_	,
													NrString&	strServerName_		,
													bool		bSpecifyPort_		,
													long		lPort_				,
													NrString&	strUsername_		,
													NrString&	strPassword_		,
													long		lMaxFolderList_);

			void			RemoveDatabaseFromRegistry(NrString& strDatabaseName_);
			void			AddDomainToRegistry(NrString& strDomainName_);
			void			RemoveDomainFromRegistry(NrString& strDomainName_);
			void			GetExchangeCredentials(NrUnicodeString* _Credentials);
			NrUnicodeString	GetTempFilePath();

		private:
			static const NrString				ms_strDatabasesSubkey;
			static const NrString				ms_strDomainsSubkey;

			static const NrString				ms_strDefaultClass;
			static const NrString				ms_strDefaultSubClass;
			static const NrString				ms_strDefaultType;
			static const long					ms_nDefaultThreadPoolSize;
			static const long					ms_nDefaultEmailRetrievalCount;
			static const NrString				ms_strDefaultMessageClasses;
			static const long					ms_nDefaultMinutesUntilRetryFiling;
			static const bool					ms_bDefaultEnableSendAndFileAgent;
			static const NrString				ms_strDefaultDirectory;
			static const long					ms_lDefaultMinutesToBounce;
			static const NrString				ms_strDefaultSMTPServerName;
			static const long					ms_lDefaultSMTPServerPort;
			static const NrString				ms_strDefaultSMTPUserName;
			static const NrString				ms_strDefaultSMTPPassword;
			static const NrString				ms_strDefaultSMTPFromAddress;	
			static const NrString				ms_strDefaultSMTPReplyAddress;
			static const NrString				ms_strDefaultSMTPCustomText;
			static const bool					ms_bDefaultSMTPIncludeBouncedEmail;
			static const long					ms_lDefaultSMTPLinesToQuote;
			static const bool					ms_bDefaultBounceToAdmin;	
			static const bool					ms_bDefaultAllowFolderNumbers;
			static const bool					ms_bFromLookup;
			static const bool					ms_bUseSMTPOpenRelay;
			static const long					ms_lDaysToRetainDuplicates;
			static const NrString				ms_strDefaultProxyServer;
			static const NrString				ms_strDefaultProxyPort;
			static const NrString				ms_strDefaultExchSrvPort;
			static const NrString				ms_strDefaultAlternateURL;

		public:
			imstd::vector<NrString>				m_DomainNames;
			imstd::vector<EmsDatabaseEntry>		m_Databases;

			IM::RegistryLongProperty			m_nServerId;						// Server ID			
			IM::RegistryLongProperty			m_nTotalSvrsInCluster;				// Total number of servers in the cluster
			IM::RegistryLongProperty			m_nWSServicePort;					// WorkSite Service port
			
			IM::RegistryStringProperty			m_strClass;
			IM::RegistryStringProperty			m_strSubClass;
			IM::RegistryStringProperty			m_strDocType;
			IM::RegistryStringProperty			m_strStoreAdminSMTPAddress;			// Administrator SMTP address
			IM::RegistryStringProperty			m_strStoreAdminPassword;			// Administrator password
			IM::RegistryStringProperty			m_strExchSrvPort;					// Exchange server Socket port
			IM::RegistryStringProperty			m_strProxyServer;					// Proxy server
			IM::RegistryStringProperty			m_strProxyPort;						// Proxy Port
			IM::RegistryStringProperty			m_strClusterName;					// Fma cluster name			
			IM::RegistryLongProperty			m_nFmaPort;							// Fma port
			IM::RegistryLongProperty			m_nThreadPoolSize;
			IM::RegistryLongProperty			m_nEmailRetrievalCount;
			IM::RegistryStringProperty			m_strMessageClasses;
			IM::RegistryLongProperty			m_nMinutesUntilRetryFiling;
			IM::RegistryBooleanProperty			m_bEnableSendAndFileAgent;
			IM::RegistryStringProperty			m_strTargetDirectory;
			IM::RegistryStringProperty			m_strDropDirectory;	
			IM::RegistryStringProperty			m_strBadDirectory;	
			IM::RegistryLongProperty			m_lMinutesToBounce;			
			IM::RegistryStringProperty			m_strSMTPServerName;
			IM::RegistryLongProperty			m_lSMTPServerPort;
			IM::RegistryStringProperty			m_strSMTPUserName;
			IM::RegistryStringProperty			m_strSMTPPassword;	
			IM::RegistryStringProperty			m_strSMTPFromAddress;
			IM::RegistryStringProperty			m_strSMTPReplyAddress;	
			IM::RegistryStringProperty			m_strSMTPCustomText;
			IM::RegistryBooleanProperty			m_bSMTPIncludeBouncedEmail;
			IM::RegistryLongProperty			m_lSMTPLinesToQuote;
			IM::RegistryBooleanProperty			m_bBounceToAdmin;
			IM::RegistryBooleanProperty			m_bAllowFolderNumbers;
			IM::RegistryBooleanProperty			m_bFromLookup;
			IM::RegistryBooleanProperty			m_bUseSMTPOpenRelay;
			IM::RegistryLongProperty			m_lDaysToRetainDuplicates;
			IM::RegistryStringProperty			m_strAlternateAutodiscoverURL;
		};

	};	// namespace IM

#endif	// __IM_LNEMAILSVCCONFIGURATION_H__

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////