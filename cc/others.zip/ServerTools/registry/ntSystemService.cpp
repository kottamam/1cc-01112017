////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// File:	ntSystemService.cpp
//
// Project: srvrLib		Subsystem: Service
//
// Contents: Implementation details of the NT System Service abstract base class.
//
//   Date    Who  Modification
// 05/23/99  GAH  Initial coding.
//
// Copyright (C) 1999, iManage Technologies, Inc. ALL RIGHTS RESERVED
//                     PROPRIETARY AND CONFIDENTIAL
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include <Registry\RegistryLib.h>

#pragma hdrstop

#include <Registry\ntSystemService.h>
#include <verification\StackWalk.h>

#include <new.h>

using namespace IM;

//======================================================================================================================
//	NTSystemService
//======================================================================================================================

//----------------------------------------------------------------------------------------------------------------------
// Static variables, etc.
//
NtSystemService		*NtSystemService::m_pService = NULL;
HANDLE				NtSystemService::m_hEventModule = NULL;

//======================================================================================================================
// Nested class StSCM (Service Control Manager) inline methods.
//======================================================================================================================

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// StSCM
//
NtSystemService::StSCM::StSCM(const IM::NrString &strServerName_)
{
	throw_syserr_iffails((m_hSCM = ::OpenSCManager(strServerName_.c_str(), NULL, SC_MANAGER_ALL_ACCESS)) != NULL);
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// ~StSCM
//
NtSystemService::StSCM::~StSCM()
{
	try
	{
		throw_syserr_iffails(::CloseServiceHandle(m_hSCM) != 0);
	}
	catch(IM::Exception &)
	{
	}
}

//======================================================================================================================
// Nested class StService
//======================================================================================================================

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// StService
//
NtSystemService::StService::StService(const IM::NrString &strServerName_, const IM::NrString &strServiceName_, bool bIsDebug_)
{
	m_bIsDebug = bIsDebug_;
	m_hSCM = NULL;
	m_hService = NULL;

	if (!m_bIsDebug)
	{
		throw_syserr_iffails((m_hSCM = ::OpenSCManager(strServerName_.c_str(), NULL, SC_MANAGER_ALL_ACCESS)) != NULL);
		throw_syserr_iffails((m_hService = ::OpenService(m_hSCM, strServiceName_.c_str(), SERVICE_ALL_ACCESS)) != NULL);
	}
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// ~StService
//
inline NtSystemService::StService::~StService()
{
	if (!m_bIsDebug)
	{
		try
		{
			throw_syserr_iffails(::CloseServiceHandle(m_hService) != 0);
		}
		catch(IM::Exception &)
		{
		}

		try
		{
			throw_syserr_iffails(::CloseServiceHandle(m_hSCM) != 0);
		}
		catch(IM::Exception &)
		{
		}
	}
}

//----------------------------------------------------------------------------------------------------------------------
// Constructors, destructors, and initializers.
//

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	NtSystemService - Overloaded constructor.
//
	NtSystemService::NtSystemService(ServiceConfiguration *pServiceConfiguration_) :
		ObjectSignature(),
		m_pServiceConfiguration(pServiceConfiguration_)
{
	//
	// Initialize state variables.
	//
	m_bIsRunning = false;
	m_bIsDebug = false;

	m_bTimeInUtc = false;
	m_bIsInstalled = false;

	m_pServiceConfiguration->LoadFromRegistry();

	//
	// Clear the dispatch table.
	//
	(void) ::memset(&m_DispatchTable[0], 0, sizeof(m_DispatchTable));

	//
	// Clear the SERVICE_STATUS data structure.
	//
	(void) ::memset(&m_Status, 0, sizeof(SERVICE_STATUS));	//***???
	m_hStatus = NULL;										//***???

	//
	// Initialize SERVICE_STATUS here so SetAcceptedControls() can be called before Startup() or override in
	// constructor of child class.
	//
	m_Status.dwServiceType = SERVICE_WIN32_OWN_PROCESS;
	m_Status.dwCurrentState = SERVICE_STOPPED;
	m_Status.dwControlsAccepted = SERVICE_ACCEPT_STOP | SERVICE_ACCEPT_SHUTDOWN; // | SERVICE_ACCEPT_PAUSE_CONTINUE | SERVICE_ACCEPT_SHUTDOWN;
	m_Status.dwWin32ExitCode = NO_ERROR;
	m_Status.dwServiceSpecificExitCode = NO_ERROR;
    m_Status.dwCheckPoint = (DWORD) 0;
	m_Status.dwWaitHint = (DWORD) DefaultWaitHint;

	//
	// To do:
	//		Update accepted controls for Windows 2000:
	//			SERVICE_ACCEPT_PARAMCHANGE
	//			SERVICE_ACCEPT_NETBINDCHANGE
	//			SERVICE_ACCEPT_HARDWAREPROFILECHANGE
	//			SERVICE_ACCEPT_POWEREVENT
	//

	//
	// Initialize the dispatch table.
	//
	m_DispatchTable[0].lpServiceName = (_TCHAR *) m_pServiceConfiguration->m_strServiceName.c_str();
	m_DispatchTable[0].lpServiceProc = NtSystemService::ServiceMain;

	//
	// Create the stop event object. The service control handler function signals this event when it receives the
	// "stop" control code.
	//
	throw_syserr_iffails((m_hStopEvent = ::CreateEvent(NULL, true, false, NULL)) != NULL);
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// ~NtSystemService - Destructor
//
NtSystemService::~NtSystemService()
{
	try
	{
		if (m_hEventModule != NULL)
		{
			(void) ::FreeLibrary((HMODULE) m_hEventModule);
			m_hEventModule = NULL;

			NRSetEventHandler(NULL);
		}
	}
	catch(IM::Exception &e)
	{
		e.LogError();
	}

	try
	{
		throw_syserr_iffails(::CloseHandle(m_hStopEvent) != 0);
	}
	catch(IM::Exception &e)
	{
		e.LogError();
	}
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Preinit
//
void
NtSystemService::Preinit()
{
	//
	// Establish handler for memory allocation failure malloc should call the depletion handler like new.
	//
	_set_new_handler(NtSystemService::MemoryDepletionHandler);
	_set_new_mode(1);

	//
	// Specify that no dialogs be displayed for file access errors.
	//
	(void) ::SetErrorMode(SEM_NOOPENFILEERRORBOX | SEM_FAILCRITICALERRORS);

	//
	// Initialize the stack dump.
	//
	IM::NrString strSymbolPath;

	if(!m_bIsDebug)	// Running as a console program?
	{
		strSymbolPath = m_pServiceConfiguration->m_strServicePath.Get();

		IM::NrString::size_type lPos = strSymbolPath.find_last_of(TEXT("."));

		if (lPos != IM::NrString::npos)	// directory or exe?
		{
			lPos = strSymbolPath.find_last_of(TEXT("\\"));

			if (lPos != IM::NrString::npos)
			{
				strSymbolPath.erase(lPos, strSymbolPath.size());
			}
		}
	}

	IM::NrtInitStackDump(strSymbolPath.c_str());

	//
	// Install event handler.
	//
	if ((m_hEventModule = LoadLibraryEx(TEXT("EventMsg.dll"), NULL, LOAD_LIBRARY_AS_DATAFILE)) == NULL)
	{
		::LogMsg(LOG_WARN, TEXT("Could not load EventMsg.dll for event reporting"));
	}
	else
	{
		NRSetEventHandler(NtSystemService::EventHandler);
	}

	//
	// Is the service installed?
	//
	StService service(m_pServiceConfiguration->m_strComputerName.c_str(), m_pServiceConfiguration->m_strServiceName, m_bIsDebug);

	m_bIsInstalled = true;

	//
	// Register the Service Control Handler.
	//
	if (!m_bIsDebug)
	{
		throw_syserr_iffails(
			((m_hStatus = ::RegisterServiceCtrlHandler(m_pServiceConfiguration->m_strServiceName.c_str(), NtSystemService::ServiceControl)) != NULL)
		);
	}

	//
	// Get the service configuration.
	//
	if (!m_bIsDebug)
	{
		DWORD dwBytesNeeded;
		char queryServiceConfig[1024];
		throw_syserr_iffails(
			::QueryServiceConfig(
				service.GetServiceHandle(),
				(QUERY_SERVICE_CONFIG *) queryServiceConfig,
				sizeof(queryServiceConfig),
				&dwBytesNeeded
			) != 0
		);
	}

	//
	// Get logon id and password from the registry.
	//

	//
	// Put build information into registry.
	//
//		setServiceRegistryStringParam(m_pServiceConfiguration->m_strServiceName, KEY_VERSION, m_strBuildVersionId);

	//
	// Set general service configuration parameters.
	//
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Init
//
void
NtSystemService::Init()
{
	ChangeStatus(SERVICE_START_PENDING);
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Run
//
void
NtSystemService::Run()
{
	m_bIsRunning = true;

	ChangeStatus(SERVICE_RUNNING);

	IM::NrString strEventMessage(m_pServiceConfiguration->m_strServiceDisplayName);
	strEventMessage += TEXT(": Started");
	Event(ECAT_INIT, EVI_GENERIC, strEventMessage.c_str());

	throw_syserr_iffails(::WaitForSingleObject(m_hStopEvent, INFINITE) != WAIT_FAILED);

	ChangeStatus(SERVICE_STOP_PENDING);

	// Add cleanup-limiting thread
	OnStopCleanup();

	ChangeStatus(SERVICE_STOPPED);

	strEventMessage = m_pServiceConfiguration->m_strServiceDisplayName;
	strEventMessage += TEXT(": Stopped");
	Event(ECAT_DS, EVW_GENERIC, strEventMessage.c_str());
}


//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Startup
//
void
NtSystemService::Startup(const TCHAR *szBinaryName_)
{
	//
	// To do:
	//		Move this message to outputdebugstring
	//
	_tprintf( TEXT("** This program is meant to run as a Windows NT Service.\n") );
	_tprintf( TEXT("** If you would like to run it as a console application\n") );
	_tprintf( TEXT("** or for debugging purposes then press CTRL-C to stop it\n") );
	_tprintf( TEXT("** and run it as:\n") );
	_tprintf( TEXT("%s -debug\n\n"), szBinaryName_ );

	throw_syserr_iffails(::StartServiceCtrlDispatcher(m_DispatchTable) != 0);
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// DebugStartup
//
void
NtSystemService::DebugStartup(int nArgC_, _TCHAR *szArgV_[])
{
	m_bIsDebug = true;

    _tprintf(TEXT("Debugging %s.\n"), m_pServiceConfiguration->m_strServiceName.c_str());

	::SetConsoleCtrlHandler(NtSystemService::DebugServiceControl, TRUE);

	m_bIsRunning = true;

	check_pointer(*szArgV_);
	IM::NrString strArgV(*szArgV_);

	Service(nArgC_, strArgV);
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// ServiceMain - static
//
void WINAPI
NtSystemService::ServiceMain(DWORD dwArgC_, LPTSTR *szArgV_)
{
	check_pointer(*szArgV_);
	IM::NrString strArgV(*szArgV_);

	check_object(m_pService);
	m_pService->Service(dwArgC_, strArgV);
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Service
//
void
NtSystemService::Service(DWORD /*dwArgC_*/, const IM::NrString &/*strArgV_*/)
{
	try
	{
		Preinit();

		Init();

		Run();
	}
	catch(IM::Exception &e)
	{
		try
		{
			e.LogError();
			ChangeStatus(SERVICE_STOPPED);
		}
		catch(IM::Exception &)
		{
		}
	}
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// DebugServiceControl - static
//
int WINAPI
NtSystemService::DebugServiceControl(DWORD dwCtrlCode_)
{
	check_object(m_pService);

	int nControlHandled;

    switch(dwCtrlCode_)
    {
        case CTRL_BREAK_EVENT:  // use Ctrl+C or Ctrl+Break to simulate
        case CTRL_C_EVENT:      // SERVICE_CONTROL_STOP in debug mode
		{
			_tprintf(TEXT("Stopping %s.\n"), m_pService->m_pServiceConfiguration->m_strServiceName.c_str());
			m_pService->OnStop();
			nControlHandled = 1;

			break;
		}
		default:
		{
			nControlHandled = 0;
			break;
		}
    }

    return (nControlHandled);
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// ServiceControl - static
//
void WINAPI
NtSystemService::ServiceControl(DWORD dwCtrlCode_)
{
	check_object(m_pService);

	m_pService->Control(dwCtrlCode_);
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Control
//
void
NtSystemService::Control(DWORD dwOpCode_)
{
	throw_assertion(m_hStatus != NULL);

	switch(dwOpCode_)
	{
		case SERVICE_CONTROL_PAUSE:
		{
			/*
			ChangeStatus(SERVICE_PAUSE_PENDING);
			OnPause();
			m_bIsPaused = true;
			ChangeStatus(SERVICE_PAUSED);
			*/

			break;
		}

		case SERVICE_CONTROL_CONTINUE:
		{
			/*
			ChangeStatus(SERVICE_CONTINUE_PENDING);
			OnContinue();
			m_bIsPaused = false;
			ChangeStatus(SERVICE_RUNNING);
			*/

			break;
		}

		case SERVICE_CONTROL_STOP:
		case SERVICE_CONTROL_SHUTDOWN:
		{
			OnStop();

			break;
		}

		case SERVICE_CONTROL_INTERROGATE:
		{
			OnInquire();
			SetServiceStatus(m_hStatus, &m_Status);

			break;
		}

		default:
		{
			SetServiceStatus(m_hStatus, &m_Status);

			break;
		}
	};
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// SetAcceptedControls
//
void
NtSystemService::SetAcceptedControls(DWORD dwControls_)
{
	m_Status.dwControlsAccepted = dwControls_ | SERVICE_ACCEPT_STOP | SERVICE_ACCEPT_SHUTDOWN;

	//dwControls_ | SERVICE_ACCEPT_STOP | SERVICE_ACCEPT_PAUSE_CONTINUE | SERVICE_ACCEPT_SHUTDOWN;
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// ChangeStatus
//
void
NtSystemService::ChangeStatus(DWORD dwState_, DWORD dwWaitHint_)
{
	if (!m_bIsDebug)
	{
		throw_assertion(m_hStatus != NULL);

		m_Status.dwWaitHint = dwWaitHint_;
		m_Status.dwServiceSpecificExitCode=NO_ERROR;

		if (m_Status.dwCurrentState == dwState_)
		{
			//
			// New point in same state.
			//
			++m_Status.dwCheckPoint;
		}
		else
		{
			if (SERVICE_STOPPED ==  dwState_ 
			  || SERVICE_RUNNING == dwState_
			  || SERVICE_PAUSED ==  dwState_)
			{
				//
				// New state transition.
				//
				m_Status.dwCheckPoint = 0;
				m_Status.dwWaitHint =  0;
			}
			else
				m_Status.dwCheckPoint = 1;
		}
		m_Status.dwCurrentState = dwState_;
 
		throw_syserr_iffails(::SetServiceStatus(m_hStatus, &m_Status) != 0);
	}

	//
	// To do:
	//		Look into 
	//			DWORD dwWin32ExitCode; 
    //			DWORD dwServiceSpecificExitCode;
	//
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// MemoryDepletionHandler - static
//
int
NtSystemService::MemoryDepletionHandler(size_t size_)
{
	::LogMsg(LOG_ERROR, TEXT("Memory allocation of size %d failed; attempting to stop service"), size_);

	IM::NrtDumpStack();

	m_pService->OnStop();

	//
	// To do: throw bad_alloc exception here
	//
	throw (long) 1;
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Install
//
void
NtSystemService::Install()
{
	//
	//	Already installed?
	//
	if(IsInstalled())
	{
		return;
	}

	//
	// Get the service manager handle.
	//
	SC_HANDLE hServiceManager;
	throw_syserr_iffails((hServiceManager = ::OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS)) != NULL);

	//
	//	Get the full path of the executable
	//
	_TCHAR szFilePath[_MAX_PATH];
	throw_syserr_iffails(::GetModuleFileName(NULL, szFilePath, sizeof(szFilePath)) != 0);

	//
	// Install the service.
	//
	SC_HANDLE hService;
	throw_syserr_iffails(
		(hService =
			::CreateService(
				hServiceManager,
				m_pServiceConfiguration->m_strServiceName.c_str(),
				m_pServiceConfiguration->m_strServiceScmName.c_str(),
				SERVICE_ALL_ACCESS,
				SERVICE_WIN32_OWN_PROCESS,
				SERVICE_DEMAND_START,
				SERVICE_ERROR_NORMAL,
				szFilePath,
				NULL,
				NULL,
				NULL,
				NULL,
				NULL
			)
		) != NULL
	);

	throw_syserr_iffails(::CloseServiceHandle(hService) != 0);
	throw_syserr_iffails(::CloseServiceHandle(hServiceManager) != 0);
}

//----------------------------------------------------------------------------------------------------------------------
// Event Message Routines - Note: This should probably be moved to the EventMsg library.
//

WORD	NtSystemService::emap[] =
{
	EVENTLOG_INFORMATION_TYPE,
	EVENTLOG_INFORMATION_TYPE,
	EVENTLOG_WARNING_TYPE,
	EVENTLOG_ERROR_TYPE
};

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// EventHandler - static
//
void
	NtSystemService::EventHandler(WORD wCategoryId_, const DWORD dwEventId_, va_list arglist)
{
	try
	{
		HANDLE			hEventSource;
		WORD			eventType = emap[ EVT_SEVERITY(dwEventId_) ];
		const _TCHAR	*szStrings[50];
		WORD			count = 0;
		int				maxInserts;

		maxInserts = GetMaxEventInserts(dwEventId_);
		while(count < 50 && count < maxInserts && (szStrings[count] = (_TCHAR *) va_arg(arglist, char *)) != NULL)
		{
			++count;
		}

		check_object(m_pService);
		check_object(m_pService->m_pServiceConfiguration);
		hEventSource = RegisterEventSource(NULL, m_pService->m_pServiceConfiguration->m_strServiceName.c_str());
		if (hEventSource != NULL)
		{
			ReportEvent(hEventSource,			// handle of event source
						eventType,				// event type
						wCategoryId_,			// event category
						dwEventId_,				// event ID
						NULL,					// current user's SID
						count,					// strings in lpszStrings
						0,						// no bytes of raw data
						szStrings,				// array of error strings
						NULL);					// no raw data
			DeregisterEventSource(hEventSource);
		}
	}
	catch(imstd::exception &)
	{
		::LogMsg(LOG_ERROR, _T("Unable to handle system event."));
	}

	return;
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// GetMaxEventInserts - static
//
int
NtSystemService::GetMaxEventInserts(DWORD dwEventId_)
{
 	char		*szMessage = NULL;
	char		*ptr;
	int			num, maxInsert = 0;

	//
	// if could not load the Event Msg file then assume that there are no arguments
	//
	if (m_hEventModule == NULL)
		return (maxInsert);

	FormatMessage (	FORMAT_MESSAGE_FROM_HMODULE | FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_IGNORE_INSERTS,
							m_hEventModule,
							dwEventId_,
							MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
							(LPTSTR) &szMessage,
							0,
							NULL);

	// determine the max number of inserts in the message
	if (szMessage == NULL)
		return 0;

	ptr = szMessage;
	while (*ptr != '\0')
	{
		if (*ptr != '%')
		{
			++ptr;
			continue;
		}

		++ptr;

		if (isdigit(*ptr) == 0)
		{
			++ptr;
			continue;
		}
		
		num = atoi(ptr);
		maxInsert = (num > maxInsert) ? num : maxInsert;

		++ptr;
	}
	if (szMessage != NULL)
		LocalFree(szMessage);


	return maxInsert;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////