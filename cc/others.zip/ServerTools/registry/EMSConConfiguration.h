//=============================================================================
// File: EMSConConfiguration.h
//-----------------------------------------------------------------------------
// Date      Who   Modification
// --------  ---   -------------------------------------------------------------
// 05/10/03  Vela  Initial coding
//-----------------------------------------------------------------------------
// Copyright (C) 1999, NetRight Technologies, Inc.
// PROPRIETARY AND CONFIDENTIAL
//=============================================================================
//
//	Classes for managing service configuration information in the registry
//

#ifndef __REG_EMSConConfiguration_H__
#define __REG_EMSConConfiguration_H__


#pragma once

#include <registry\Service.h>

namespace IM
{

	class CEMSConConfiguration : public RegistryMap
	{
	public:
				CEMSConConfiguration(const TCHAR *szComputerName_);
		virtual	~CEMSConConfiguration() {}
		
		IM::RegistryStringProperty		m_strPop3User;
		IM::RegistryStringProperty		m_strPop3Password;
		IM::RegistryLongProperty		m_lPop3Port;
		IM::RegistryLongProperty		m_lLeaveOutlookRunning;
		IM::RegistryLongProperty		m_lLeavePop3Running;
	};

};	// namespace IM



#endif __REG_EMSConConfiguration_H__
