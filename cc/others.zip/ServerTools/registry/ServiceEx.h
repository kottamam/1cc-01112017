//=============================================================================
// File: ServiceEx.h
//-----------------------------------------------------------------------------
// Date      Who  Modification
// --------  ---  -------------------------------------------------------------
// 01/10/00  ZIA  Initial coding
//-----------------------------------------------------------------------------
// Copyright (C) 1999, NetRight Technologies, Inc.
// PROPRIETARY AND CONFIDENTIAL
//=============================================================================
//
//	Classes for managing service configuration information in the registry
//

#ifndef __REG_SERVICEEX_H__
#define __REG_SERVICEEX_H__


#pragma once

#include <registry\Service.h>

namespace IM
{

class DmsServiceConfiguration : public ServiceConfiguration
{
public:
	IM::RegistryStringProperty		m_strIndexerFiles;

	IM::RegistryBooleanProperty     m_bMaxDocNumIncreaseOnSupervisedImport;
	IM::RegistryBooleanProperty		m_bTrustedLogon;
	IM::RegistryLongProperty		m_lEnforceKerberos;

	IM::RegistryStringProperty		m_strClusterName;
	IM::RegistryLongProperty		m_lThreadCount;

	// data cache management
	IM::RegistryBooleanProperty		m_bPreloadCache;
	IM::RegistryLongProperty		m_lCacheUpdateFrequency;
	IM::RegistryLongProperty		m_lCacheRowCount;
	IM::RegistryBooleanProperty		m_bSharedCMCache;
	IM::RegistryStringProperty		m_strCMDatabase;

	// RPC and file transfer socket configuration
	IM::RegistryBooleanProperty		m_bGivenServicePort;
	IM::RegistryBooleanProperty		m_bGivenFilePort;
	IM::RegistryLongProperty		m_lServicePort;
	IM::RegistryLongProperty		m_lFilePort;

	//Elyas ++
	IM::RegistryBooleanProperty		m_bImpersonationEnabled;
	IM::RegistryStringProperty		m_strImpersonationPassword;
	//Elyas --

	IM::RegistryBooleanProperty		m_bBackwardsCompatibleAccess;

	IM::RegistryBooleanProperty		m_bCaseInsensitiveOracle;	

	IM::RegistryLongProperty		m_lSecureValidatedFieldsMask;

	IM::RegistryBooleanProperty		m_bAciInitEncryption;	

	IM::RegistryBooleanProperty		m_bAuthenticateWebDb;

	IM::RegistryLongProperty		m_lSecurityModel;
	IM::RegistryBooleanProperty		m_bGovernEnabled;

	// email management
	IM::RegistryStringProperty		m_strEmailDomain;
	IM::RegistryBooleanProperty		m_bAddEmailsToWorklist;
	IM::RegistryLongProperty		m_lServerSideDuplicateDetectionType;
	IM::RegistryBooleanProperty		m_bAddMailBoxSyncQueue;

	// document cache
	IM::RegistryBooleanProperty		m_bDocCacheEnabled;
	IM::RegistryStringProperty		m_strDocCacheFilePath;
	IM::RegistryStringProperty		m_strDocCacheRootPath;
	IM::RegistryStringProperty		m_strDocCacheFilePathOS;
	IM::RegistryStringProperty		m_strDocCacheAccessMethod;
	IM::RegistryLongProperty		m_lDocCacheUploadWaitTime;
	//Secure doc cache data
	IM::RegistryStringProperty		m_strSecureDocCacheFilePath;
	IM::RegistryStringProperty		m_strSecureDocCacheRootPath;
	IM::RegistryStringProperty		m_strSecureDocCacheFilePathOS;
	IM::RegistryStringProperty		m_strSecureDocCacheAccessMethod;

	IM::RegistryBooleanProperty		m_bLogEventsInServer;	

	IM::RegistryStringProperty		m_strDefaultDocClass;

	IM::RegistryStringProperty		m_strEmailTypes;
	IM::RegistryStringProperty		m_strPDFTypes;
	IM::RegistryBooleanProperty		m_bImportEmailsAsDeclared;

	IM::RegistryLongProperty		m_lKludgeRetainExtANSI;
	IM::RegistryLongProperty		m_lKludgeRetainExtNonEmail;

	IM::RegistryBooleanProperty		m_bWFMEnabled;
	IM::RegistryStringProperty      m_strWFMServerAddress;

	IM::RegistryBooleanProperty		m_bBackgroundJobsEnabled;
	IM::RegistryLongProperty		m_lBackgroundJobsThreadTimeout;
	IM::RegistryBooleanProperty		m_bBackgroundJobsClusterEnabled;
	IM::RegistryLongProperty		m_lBackgroundJobsDocumentChunkSize;
	IM::RegistryLongProperty		m_lBackgroundJobsFolderChunkSize;
	IM::RegistryLongProperty		m_lBackgroundJobsWorkspaceChunkSize;
		
	// SEV email reconciliation subsystem
	IM::RegistryBooleanProperty		m_bSevEnabled;
	IM::RegistryStringProperty      m_strSevServerAddress;
	IM::RegistryStringProperty      m_lReconcileUserId;
	IM::RegistryLongProperty        m_lReconcileThreadTimeOut;
	IM::RegistryLongProperty        m_lReconcileRetry;
	IM::RegistryLongProperty        m_lDownloadFileRetry;
	
	//SEV-Notes integration
	IM::RegistryBooleanProperty		m_bSevNotesEnabled;
	IM::RegistryStringProperty		m_strSevNotesIdPath;
	IM::RegistryStringProperty		m_strSevNotesIdPassword;
	IM::RegistryStringProperty		m_strSevNotesTemplatePath;
	IM::RegistryStringProperty		m_strSevNotesTempDBPath;
	IM::RegistryStringProperty		m_strSevNotesTypeAlias;

	// EAS email reconciliation subsystem
	IM::RegistryBooleanProperty		m_bEasEnabled;
	IM::RegistryStringProperty      m_strEasServerAddress;
	IM::RegistryStringProperty      m_strEasReconcileUserId;
	IM::RegistryLongProperty        m_lEasReconcileThreadTimeOut;
	IM::RegistryLongProperty        m_lEasReconcileRetry;
	IM::RegistryLongProperty        m_lEasDownloadFileRetry;
	IM::RegistryStringProperty		m_strEasAppUrl;
	IM::RegistryStringProperty      m_strEasAdminUserId;
	IM::RegistryStringProperty      m_strEasAdminPassword;

	//HP ACA email reconciliation subsystem
	IM::RegistryBooleanProperty		m_bAcaEnabled;
	IM::RegistryStringProperty      m_strAcaServerEndPoint;


	IM::RegistryStringProperty		m_strAdditionalEmailStubClasses;
	IM::RegistryBooleanProperty     m_bPreserveTimeStampOnImport;

	IM::RegistryBooleanProperty		m_bAllowDescFullTextSearch;
	IM::RegistryBooleanProperty		m_bUseSystemDates;
	IM::RegistryBooleanProperty		m_bAdvancedServer;
	IM::RegistryBooleanProperty		m_bHpFlowServer;

	IM::RegistryLongProperty		m_lMaxXQ;
	IM::RegistryLongProperty		m_lMaxQD;
	IM::RegistryLongProperty		m_lSleepPerBackgroundSession;

	//FMA Client reply ports
	IM::RegistryLongProperty		m_lFMAClientReplyPort;
	IM::RegistryLongProperty		m_lFMAClientNumberOfReplyPorts;

	//Hosted DM Configuration
	IM::RegistryBooleanProperty		m_bHostedDMEnabled;
	IM::RegistryLongProperty		m_lHostedServicePort;
	IM::RegistryLongProperty		m_lHostedFilePort;
	IM::RegistryLongProperty		m_lHostedSessionTimeOut;
	IM::RegistryBooleanProperty		m_bHostedSSLEnabled;
	IM::RegistryBooleanProperty		m_bUseSSLCompression;
	IM::RegistryStringProperty		m_strHostedSSLCACertPath;
	IM::RegistryStringProperty		m_strHostedSSLKeyFilePath;
	IM::RegistryStringProperty		m_strHostedSSLKeyFilePassword;
	IM::RegistryStringProperty		m_strHostedSSLCiphers;
	IM::RegistryLongProperty		m_lHostedTrustedLoginType;
	IM::RegistryStringProperty		m_strHostedTrustedLoginServer;
	IM::RegistryBooleanProperty		m_strHostedTrustedLoginSSL;
	IM::RegistryLongProperty		m_strHostedTrustedLoginPort;
	IM::RegistryBooleanProperty		m_bDisableSSLv2;
	IM::RegistryBooleanProperty		m_bDisableSSLv3;
	IM::RegistryBooleanProperty		m_bDisableTLSv1;
	IM::RegistryBooleanProperty		m_bDisableTLSv1_1;
	IM::RegistryBooleanProperty		m_bDisableTLSv1_2;
	IM::RegistryBooleanProperty		m_bEnableNetworkLogin;

	IM::RegistryStringProperty		m_strIpv6MulticastAddress;
	IM::RegistryBooleanProperty		m_bServerSideDuplicateDetection;
	IM::RegistryStringProperty		m_strHipaaTempDirectory;

	//
	IM::RegistryBooleanProperty		m_bUseSessionLocaleForTranslation;
	IM::RegistryBooleanProperty		m_bAllowUnicodeData;

	IM::RegistryLongProperty		m_lFolderFTSearchMultiplier;

	IM::RegistryBooleanProperty		m_bResetComindexAndIndexedOnUpdate;

	IM::RegistryLongProperty		m_lMaxMarkedFolders;

	IM::RegistryBooleanProperty		m_bFlowSSLPeerVerify;
	IM::RegistryStringProperty		m_strSslCertStores;
	IM::RegistryLongProperty		m_lFlowIDLookupCacheLimit;	//no of entries
	IM::RegistryStringProperty		m_strFlowPasswordColumn;
	IM::RegistryLongProperty		m_lDiffSyncWaterMark;
	IM::RegistryLongProperty		m_lFlowSubFolderSupport;
	IM::RegistryStringProperty		m_strFlowLogosPath;

	IM::RegistryBooleanProperty		m_bCreateCrashDump;
	IM::RegistryStringProperty		m_strCrashDumpDirectory;
	IM::RegistryBooleanProperty		m_bImplicitAuditSupport;
	IM::RegistryBooleanProperty		m_bPipedUpload;
	IM::RegistryBooleanProperty		m_bEnhancedDownload;

	//Document Worklist count
	IM::RegistryLongProperty		m_lMaxWorklistDocs;

	//UID Login
	IM::RegistryLongProperty		m_lUidLoginType;

	// SAML Artifact Resolution URL
	IM::RegistryStringProperty		m_strSAMLArtUrl;
	IM::RegistryStringProperty		m_strSamlProxyUrl;
	IM::RegistryStringProperty		m_strSamlKeyFile;
	IM::RegistryStringProperty		m_strSamlEndpoint;
	IM::RegistryStringProperty		m_strSamlRp;
	IM::RegistryStringProperty		m_strSamlRelyingParty;
	IM::RegistryStringProperty		m_strSamlAttribute;

	IM::RegistryBooleanProperty		m_bIndexDreDateTime;

	IM::RegistryStringProperty		m_strDocPreviewEngineURL;
	IM::RegistryLongProperty		m_lDocPreviewProvider;
	IM::RegistryStringProperty		m_strSmtpServerURL;
	IM::RegistryStringProperty		m_strSmtpMailFromAddress;
	IM::RegistryStringProperty		m_strSmtpReplyToAddress;
	IM::RegistryStringProperty		m_strSmtpReplyToDisplay;
	IM::RegistryBooleanProperty		m_bSmtpUseSSL;
	IM::RegistryStringProperty		m_strFileToFolder;
	IM::RegistryStringProperty		m_strTrustedProxiesList;
	IM::RegistryStringProperty		m_strUsageTracking;
    IM::RegistryStringProperty		m_strDefaultEmailFolder;

	IM::RegistryLongProperty		m_lPersonalSearchWSCount;

	IM::RegistryStringProperty		m_strHTML5PolicyPreventDataLeakage;
	IM::RegistryStringProperty		m_strHTML5PolicyGroupAccessList;
	IM::RegistryStringProperty		m_striOSPolicy;

	IM::RegistryBooleanProperty		m_bAllowIWL;

	IM::RegistryStringProperty		m_strOLEDocTypes;

	//RabbitMq Log
	IM::RegistryBooleanProperty		m_bRabbitMqLog;

	//Rendition engine configs
	IM::RegistryStringProperty		m_strRenderBrokerURL;
	IM::RegistryStringProperty		m_strRenderDestination;
	IM::RegistryStringProperty		m_strRenderRespDestination;
	IM::RegistryBooleanProperty		m_bRenderUseTopic;
	IM::RegistryBooleanProperty		m_bRenderSessTransacted;
	IM::RegistryLongProperty		m_lRenderMsgExpireInSec;
	IM::RegistryBooleanProperty		m_bRenderPersistMsg;
	IM::RegistryStringProperty		m_strRenderCacheHost;
	IM::RegistryStringProperty		m_strRenderBrokerLogin;
	IM::RegistryStringProperty		m_strRenderBrokerKey;
	IM::RegistryLongProperty		m_lRenderPoolSize;
	IM::RegistryStringProperty		m_strMSSHost;
    IM::RegistryStringProperty		m_strDMSRsaKey;
    IM::RegistryLongProperty		m_lDaysToRetainPreviewCache;

	//Ocr Discovery
	IM::RegistryStringProperty		m_strDiscoveryTypes;
	IM::RegistryBooleanProperty		m_bOcrCopyFileCreateAndModifyDate;
	IM::RegistryBooleanProperty		m_bOcrReplaceForNewVersion;

	IM::RegistryStringProperty		m_strRestOriginWhiteList;
	IM::RegistryLongProperty		m_lIdleSocketTimeout;

	//Audit journal
	IM::RegistryBooleanProperty		m_bAuditJournalEnabled;
	IM::RegistryBooleanProperty		m_bTrashEnabled;
	IM::RegistryLongProperty		m_lDaysToRetainAuditJournal;

	//Session Cache
	IM::RegistryStringProperty		m_strRedisHost;
	IM::RegistryLongProperty		m_lRedisPort;
	IM::RegistryStringProperty		m_strRedisSentinelClusterName;
	IM::RegistryLongProperty		m_lRedisConnectionCount;
	IM::RegistryLongProperty		m_lGrantTokenExpiryInSec;
	IM::RegistryLongProperty		m_lBearerTokenMaxInactivityInSec;
	IM::RegistryLongProperty		m_lMasterTokenMaxInactivityInSec;


	DmsServiceConfiguration(const TCHAR *szComputerName_);

	DmsServiceConfiguration(const TCHAR *szComputerName_, 
						const TCHAR *strServicePath,
						const TCHAR *strServiceName,
						const TCHAR *strServiceDispName,
						const TCHAR *strServiceScmName);

	virtual			~DmsServiceConfiguration() {}

	void			GetRegistryMap(PropertyMap *&pPropertyMap_);

	void			GetConfigValue(const TCHAR* szName, IM::NrCiString& strValue_);

	protected:
		void InitDMSConfiguration();
};


// CMS Service configuration Added by Sujit
// BA - Sujit
class CmsServiceConfiguration : public ServiceConfiguration
{
public:
	IM::RegistryStringProperty		m_strClusterName; // Name of server cluster
	IM::RegistryLongProperty		m_lThreadCount; // Number of worker threads
	IM::RegistryStringProperty		m_strFileManagerTempDirectory; // Directory for file manager temporary files
	IM::RegistryBooleanProperty		m_bTrustedLogon; // Are trusted logons allowed?				
	IM::RegistryLongProperty		m_lVerifyLevel; // Level for verification routines
	
	//IM::RegistryBooleanProperty		m_bGivenServicePort;
	//IM::RegistryBooleanProperty		m_bGivenFilePort;
	IM::RegistryLongProperty		m_lServicePort; // Port that service listens on
	IM::RegistryLongProperty		m_lFilePort; // Port that File Server listens on
	IM::RegistryBooleanProperty		m_bBackwardsCompatibleAccess;
	CmsServiceConfiguration(const TCHAR *szComputerName_);
	virtual			~CmsServiceConfiguration() {}
};

// EA - Sujit

//
// the old indexer
//
//	Only those properties are define which will continue to be managed
//

class IdxServiceConfiguration : public ServiceConfiguration
{
public:
	// computed properties
	IM::RegistryBooleanProperty		m_bScheduleTable[7][12];

	// managed properties
	IM::RegistryStringProperty		m_strRunMode;
	IM::RegistryStringProperty		m_strIndexingOrder;
	IM::RegistryStringProperty		m_strSchedule;
	IM::RegistryLongProperty		m_lPacketSize;

	// install defaults
	IM::RegistryStringProperty		m_strIndexerFiles;

					IdxServiceConfiguration(const TCHAR *szComputerName_);
	virtual			~IdxServiceConfiguration() {}

	virtual void	LoadFromRegistry();
	virtual void	StoreInRegistry();

};


class IdxMgrServiceConfiguration : public ServiceConfiguration
{
public:

	// computed properties
	IM::RegistryBooleanProperty		m_bScheduleTable[7][12];

	// managed properties
	IM::RegistryStringProperty		m_strRunMode;
	IM::RegistryStringProperty		m_strSchedule;

	// internal defaults
	IM::RegistryLongProperty		m_lChunksize;					// doclistChunksize
	IM::RegistryLongProperty		m_lDocumentsPerCollection;		// numDocsPerCollection
	IM::RegistryStringProperty		m_strVersionsPerDoc;			// aveNumVersionsPerDoc
	IM::RegistryLongProperty		m_lIndexOptimizeEveryNthTime;	// indexOptimizeEveryNthTime
	IM::RegistryStringProperty		m_strIndexServer;

	virtual void	LoadFromRegistry();
	virtual void	StoreInRegistry();

					IdxMgrServiceConfiguration(const TCHAR *szComputerName_);
	virtual			~IdxMgrServiceConfiguration() {}

};



class IdxSearchServiceConfiguration : public ServiceConfiguration
{
	public:
				IdxSearchServiceConfiguration(const TCHAR *szComputerName_);
	virtual		~IdxSearchServiceConfiguration() {};

	public:
		// RPC and file transfer socket configuration
		IM::RegistryStringProperty		m_strClusterName;
		IM::RegistryBooleanProperty		m_bGivenServicePort;
		IM::RegistryLongProperty		m_lServicePort;
		IM::RegistryLongProperty		m_lThreadCount;
};


class IdxAgentConfiguration : public RegistryMap
{
public:

	// install defaults
	IM::RegistryStringProperty		m_strLogPath;
	IM::RegistryStringProperty		m_strIndexerFiles;

	// internal default overrides
	IM::RegistryLongProperty		m_lFilterSecondsPerMB;			// filterSecPerMB
	IM::RegistryLongProperty		m_lFilterMinimumSecondsPerMB;	// filterMinMilliSecPerMB
	IM::RegistryLongProperty		m_lIndexSecondsPerMB;			// indexSecPerMB
	IM::RegistryLongProperty		m_lIndexMinimumSecondsPerMB;	// indexMinMilliSecPerMB
	IM::RegistryLongProperty		m_lDeleteSecondsPerDocument;	// deleteMilliSecPerDoc
	IM::RegistryLongProperty		m_lDeleteMinimumSecondsPerDocument;	// deleteMinMilliSec
	IM::RegistryLongProperty		m_lSearchMinimumSeconds;		// searchMinMilliSec
	IM::RegistryLongProperty		m_lVerityMaxMemory;				// Verity MaxMemory
	IM::RegistryLongProperty		m_lVerityNumPages;				// Verity NumPages
	IM::RegistryStringProperty		m_strLocale;
	IM::RegistryStringProperty		m_strCharacterSet;
	IM::RegistryLongProperty		m_lLogMask;
	IM::RegistryBooleanProperty		m_bSearchCommentsDescription;	// Use 4.x compatible searching, the Comments and DocName searched together


					IdxAgentConfiguration(const TCHAR *szComputerName_, const TCHAR *szKeyPath_);
	virtual			~IdxAgentConfiguration() {}
};


class RulesServiceConfiguration : public ServiceConfiguration
{
private:

	RegistryMap				m_handlerMap;		//	map for rule handlers

public:

	virtual void	LoadFromRegistry();
	virtual void	StoreInRegistry();

	IM::RegistryLongProperty		m_lProcessInterval;
	IM::RegistryLongProperty		m_lMaintenanceInterval;
	IM::RegistryStringProperty		m_strSmtpServer;

					RulesServiceConfiguration(const TCHAR *szComputerName_);
	virtual			~RulesServiceConfiguration();
};


class FmaServiceConfiguration : public ServiceConfiguration
{
	public:
				FmaServiceConfiguration(const TCHAR *szComputerName_);
	virtual		~FmaServiceConfiguration() {};

};

class EFSServiceConfiguration : public ServiceConfiguration
{
	public:
				EFSServiceConfiguration(const TCHAR *szComputerName_);
	virtual		~EFSServiceConfiguration() {};

};

class CIFSServiceConfiguration : public ServiceConfiguration
{
	public:
				CIFSServiceConfiguration(const TCHAR *szComputerName_);
	virtual		~CIFSServiceConfiguration() {};

};
class PrintRenditionServiceConfiguration : public ServiceConfiguration
{
	public:
				PrintRenditionServiceConfiguration(const TCHAR *szComputerName_);
	virtual		~PrintRenditionServiceConfiguration() {};

};
class RenderServiceConfiguration : public ServiceConfiguration
{
	public:
				RenderServiceConfiguration(const TCHAR *szComputerName_);
	virtual		~RenderServiceConfiguration() {};

	IM::RegistryStringProperty		m_strClusterName;
	IM::RegistryLongProperty		m_lThreadCount;
	IM::RegistryBooleanProperty		m_bGivenServicePort;
	IM::RegistryLongProperty		m_lServicePort;
	IM::RegistryStringProperty      m_strServerAddress;
};


//WorkSite Indexer Service
class IDXSVCConfiguration : public ServiceConfiguration
{
	public:
				IDXSVCConfiguration(const TCHAR *szComputerName_);
	virtual		~IDXSVCConfiguration() {};

	IM::RegistryLongProperty		m_lIdxSvcType;
	IM::RegistryStringProperty		m_strDeploymentXML;
};


	//
	//------------------------------------------------------------------------------------------------------------------
	// WkDreServiceConfiguration Class
	//------------------------------------------------------------------------------------------------------------------
	//
	class WkDreServiceConfiguration : public ServiceConfiguration
	{
	private:
		explicit
			WkDreServiceConfiguration();

	public:
			WkDreServiceConfiguration(const TCHAR *szComputerName_);
		virtual
			~WkDreServiceConfiguration();

		void
			LoadFromRegistry();
		void
			StoreInRegistry();
		void
			DeleteFromRegistry();

		//
		// DRE Attributes
		//
		IM::RegistryStringProperty			m_strDreIniFilePath;
		IM::RegistryLongProperty			m_lDreQueryPort;
		IM::RegistryLongProperty			m_lDreIndexPort;


		//
		// Security Attributes
		//
		IM::RegistryBooleanProperty			m_bWkEnable;
		IM::RegistryStringProperty			m_strWorkSite;
		IM::RegistryBooleanProperty			m_bWsSpecifyServicePort;
		IM::RegistryLongProperty			m_lWsServicePort;
	};

	//
	//------------------------------------------------------------------------------------------------------------------
	// WkIndxrServiceConfiguration Class
	//------------------------------------------------------------------------------------------------------------------
	//
	class WkIndxrServiceConfiguration : public ServiceConfiguration
	{
	private:
		explicit
			WkIndxrServiceConfiguration();

	public:
			WkIndxrServiceConfiguration(const TCHAR *szComputerName_);

		virtual
			~WkIndxrServiceConfiguration();

		void
			LoadFromRegistry();
		void
			StoreInRegistry();

		//
		// DRE Attributes
		//
		IM::RegistryStringProperty			m_strDre;
		IM::RegistryBooleanProperty			m_bCreateSummary;
		IM::RegistryBooleanProperty			m_bStoreContent;
		IM::RegistryBooleanProperty			m_bUseLocalServer;
		IM::RegistryLongProperty			m_lQueryPort;
		IM::RegistryLongProperty			m_lIndexPort;
		IM::RegistryStringProperty			m_strWorkSiteServer;		// Used purely to aid in Moniker creation.

		//
		// General Attributes
		//
		IM::RegistryLongProperty		m_lChunkSize;

		IM::RegistryBooleanProperty		m_bScheduleTable[7][12];
		IM::RegistryStringProperty		m_strRunMode;
		IM::RegistryStringProperty		m_strSchedule;
	};

	//
	//------------------------------------------------------------------------------------------------------------------
	// WkAtIndxrServiceConfiguration Class
	//------------------------------------------------------------------------------------------------------------------
	//
	class WkAtIndxrServiceConfiguration : public ServiceConfiguration
	{
	private:
		explicit
			WkAtIndxrServiceConfiguration();

	public:
			WkAtIndxrServiceConfiguration(const TCHAR *szComputerName_);
		virtual
			~WkAtIndxrServiceConfiguration();

		//
		// DRE Attributes
		//
		IM::RegistryStringProperty			m_strDreAutoIndexerCfgFilePath;
		IM::RegistryStringProperty			m_strDreHost;
		IM::RegistryLongProperty			m_lDreQueryPort;
		IM::RegistryLongProperty			m_lDreIndexPort;

		void
			LoadFromRegistry();
		void
			StoreInRegistry();
		void
			DeleteFromRegistry();
	};


//////////////////////////////////////////////////
// CDSSyncSvc_AttributeMap

class CDSSyncSvc_AttributeMap : public IM::RegistryMap
{
public:
	// default constructor
	CDSSyncSvc_AttributeMap( const TCHAR *szComputerName_, HKEY hKey_, const TCHAR *szBaseKeyPath_ );

	// copy constructor
	CDSSyncSvc_AttributeMap( const CDSSyncSvc_AttributeMap& DSSyncSvc_AttributeMap );

	// destructor
	virtual ~CDSSyncSvc_AttributeMap( void );

	// equality operator
	bool operator ==( const CDSSyncSvc_AttributeMap& DSSyncSvc_AttributeMap ) const;

	// assignment operator
	CDSSyncSvc_AttributeMap& operator =( const CDSSyncSvc_AttributeMap& DSSyncSvc_AttributeMap );

	// data members
	IM::RegistryStringProperty m_strMapName;
	IM::RegistryStringProperty m_strOUName;
	IM::RegistryStringProperty m_strUserName;
	IM::RegistryStringProperty m_strUserId;
	IM::RegistryStringProperty m_strUserEmail;
	IM::RegistryStringProperty m_strUserFax;
	IM::RegistryStringProperty m_strUserTelephone;
	IM::RegistryStringProperty m_strUserLocation;
	IM::RegistryStringProperty m_strUserEnabled;
	IM::RegistryStringProperty m_strGroupName;
	IM::RegistryStringProperty m_strGroupId;
	IM::RegistryStringProperty m_strGroupMember;
	IM::RegistryStringProperty m_strK1SyncId;

	// misc operations
	bool WellFormedUser( void ) const;
	bool WellFormedGroup( void ) const;
};




//////////////////////////////////////////////////
// CDSSyncSvc_DSParameters

class CDSSyncSvc_DSParameters : public IM::RegistryMap
{
public:
	typedef enum tagLDAPTYPE
	{
		Microsoft = 0,
		Sun = 1,
		Novell = 2,
		NT = 3
		
	} LDAPTYPE;

public:
	// default constructor
	CDSSyncSvc_DSParameters( const TCHAR *szComputerName_, HKEY hKey_, const TCHAR *szBaseKeyPath_ );

	// copy constructor
	CDSSyncSvc_DSParameters( const CDSSyncSvc_DSParameters& DSSyncSvc_DSParameters );

	// destructor
	virtual ~CDSSyncSvc_DSParameters( void );

	// equality operator
	bool operator ==( const CDSSyncSvc_DSParameters& DSSyncSvc_DSParameters ) const;

	// assignment operator
	CDSSyncSvc_DSParameters& operator =( const CDSSyncSvc_DSParameters& DSSyncSvc_DSParameters );

	// operations
	IM::NrString GetNOSType( void ) const;
	IM::NrString GetDSName( void ) const;

	// data members
	IM::RegistryStringProperty m_strServerName;
	IM::RegistryStringProperty m_strUserId;
	IM::RegistryStringProperty m_strPassword;
	IM::RegistryLongProperty m_lServiceType;
	IM::RegistryLongProperty m_lTcpipPort;
	IM::RegistryStringProperty m_strContext;	// for Novell NDS
	IM::RegistryStringProperty m_strTreeID;
	IM::RegistryLongProperty m_lEnableSSL;
};




//////////////////////////////////////////////////
// CDSSyncSvc_DMSParameters

class CDSSyncSvc_DMSParameters : public IM::RegistryMap
{
public:
	// default constructor
	CDSSyncSvc_DMSParameters( const TCHAR *szComputerName_, HKEY hKey_, const TCHAR *szBaseKeyPath_ );

	// copy constructor
	CDSSyncSvc_DMSParameters( const CDSSyncSvc_DMSParameters& DSSyncSvc_DMSParameters );

	// destructor
	virtual ~CDSSyncSvc_DMSParameters( void );

	// equality operator
	bool operator ==( const CDSSyncSvc_DMSParameters& DSSyncSvc_DMSParameters ) const;

	// assignment operator
	CDSSyncSvc_DMSParameters& operator =( const CDSSyncSvc_DMSParameters& DSSyncSvc_DMSParameters );

	// data members
	IM::RegistryStringProperty m_strDms;
	IM::RegistryStringProperty m_strLibrary;
	IM::RegistryStringProperty m_strUserId;
	IM::RegistryStringProperty m_strPassword;
	IM::RegistryLongProperty m_lTcpipPort;
	
	IM::RegistryStringProperty m_strDefaultPassword;
	IM::RegistryBooleanProperty m_bDefaultPasswordNeverExpires;
	IM::RegistryBooleanProperty m_bDefaultPasswordMustBeChanged;
};




//////////////////////////////////////////////////
// CDSSyncSvc_Connection

class CDSSyncSvc_Connection : public IM::RegistryMap
{
public:
	// default constructor
	CDSSyncSvc_Connection( const TCHAR *szComputerName_, HKEY hKey_, const TCHAR *szBaseKeyPath_ );

	// copy constructor
	CDSSyncSvc_Connection( const CDSSyncSvc_Connection& DSSyncSvc_Connection );

	// destructor
	virtual ~CDSSyncSvc_Connection( void );

	// equality operator
	bool operator ==( const CDSSyncSvc_Connection& DSSyncSvc_Connection ) const;

	// assignment operator
	CDSSyncSvc_Connection& operator =( const CDSSyncSvc_Connection& DSSyncSvc_Connection );

	// overloads
	virtual void LoadFromRegistry( );
	virtual void StoreInRegistry( );
	virtual void DeleteFromRegistry( );

	// data members
	IM::RegistryStringProperty m_strName;
	IM::RegistryStringProperty m_strNode;
	IM::RegistryStringProperty m_strAttributeMapName;
	IM::RegistryStringProperty m_strExternalDNList;		// list of strings separated by %^% delimiter, e.g. value1%^%value2%^%value3%^%
	IM::RegistryStringProperty m_strFilter;

	// subkeys
	CDSSyncSvc_DSParameters m_DSParameters;
	CDSSyncSvc_DMSParameters m_DMSParameters;
};







class CDSSyncSvc : public IM::ServiceConfiguration
{
public:
	// typedefs
	typedef imstd::list< CDSSyncSvc_AttributeMap* > ATTRIBUTEMAPLIST;
	typedef imstd::list< CDSSyncSvc_Connection* > CONNECTIONLIST;

	// constructors
	CDSSyncSvc( const TCHAR *szComputerName_ );

	// copy constructor
	CDSSyncSvc( const CDSSyncSvc& DSSyncSvc );

	// destructor
	virtual ~CDSSyncSvc( void );

	// equality operator
	bool operator ==( const CDSSyncSvc& DSSyncSvc ) const;

	// assignment operator
	CDSSyncSvc& operator =( const CDSSyncSvc& DSSyncSvc );

	// list operations
	void Clear( void );
	void RemoveAllAttributeMaps( void );
	void RemoveAllConnections( void );
	void AddAttributeMap(
		LPCTSTR szMapName, LPCTSTR szOUName, LPCTSTR szUserName, LPCTSTR szUserId, 
		LPCTSTR szUserEmail, LPCTSTR szUserFax, LPCTSTR szUserTelephone, LPCTSTR szUserLocation, LPCTSTR szUserEnabled,
		LPCTSTR szGroupName, LPCTSTR szGroupId, LPCTSTR szGroupMember,
		LPCTSTR szK1SyncId
		);
	void AddConnection( 
		LPCTSTR szConnectionName, LPCTSTR szNode, LPCTSTR szAttributeMapName, LPCTSTR szFilter,
		LPCTSTR szDmsServer, LPCTSTR szDmsLibrary, LPCTSTR szDmsUserId, LPCTSTR szDmsPassword, long lDMSTcpipPort,
		LPCTSTR szDSServer, LPCTSTR szDSUserId, LPCTSTR szDSPassword,
		LPCTSTR szDefaultPassword, bool bDefaultPasswordNeverExpires, bool bDefaultPasswordMustBeChanged,
		long lDSServiceType, long lDSTcpipPort, LPCTSTR szContext,LPCTSTR szExternalDNList, LPCTSTR szTreeID
		);
	void AddAttributeMap( CDSSyncSvc_AttributeMap* pAttributeMap );
	void AddConnection( CDSSyncSvc_Connection* pConnection );
	void RemoveConnection( LPCTSTR szConnectionName );
	void RemoveAttributeMap( LPCTSTR szMapName );

	// overloads
	virtual void LoadFromRegistry( );
	virtual void StoreInRegistry( );
	virtual void DeleteFromRegistry( );

	void LoadFromRegistry_AttributeMapsOnly();
	void StoreInRegistry_AttributeMapsOnly();
	void DeleteFromRegistry_AttributeMapsOnly();

	// operations
	bool ConnectionExists( LPCTSTR szConnection ) const;
	bool AttributeMapExists( LPCTSTR szMap ) const;
	CDSSyncSvc_Connection* FindConnection( LPCTSTR szConnectionName ) const;
	CDSSyncSvc_AttributeMap* FindAttributeMap( LPCTSTR szMapName ) const;

	// function test
	static bool Test( void );

	// subkeys
	IM::RegistryStringProperty m_strSchedule;
	IM::RegistryStringProperty m_strMode;
	IM::RegistryBooleanProperty	m_bScheduleTable[7][12];
	IM::RegistryLongProperty m_lPageSize;
	IM::RegistryLongProperty m_lCycleMinutes;

	bool GetServiceConfiguration(NrString& strLogonID_, NrString& strPassword_, bool &bAutoStartup_);

	ATTRIBUTEMAPLIST m_AttributeMapList;
	CONNECTIONLIST m_ConnectionList;
};





};	// namespace IM



#endif __REG_SERVICEEX_H__

