//=============================================================================
// File: Service.cpp
//-----------------------------------------------------------------------------
// Date      Who  Modification
// --------  ---  -------------------------------------------------------------
// 01/10/00  ZIA  Initial coding
//-----------------------------------------------------------------------------
// Copyright (C) 1999, NetRight Technologies, Inc.
// PROPRIETARY AND CONFIDENTIAL
//=============================================================================
//
//	Classes for managing service configuration information in the registry
//

#include <Registry\RegistryLib.h>

#pragma hdrstop

#include <Registry\Registry.h>

#include <lm.h>
#include <ntsecapi.h>


//
//	Basic service properties for all services
//
#define KEY_LOGONID			_T("LogonID")
#define KEY_PASSWORD		_T("Password")
#define KEY_BOOT_STARTUP	_T("Startup on Boot")

#define KEY_SERVICE_PATH	_T("Service Path")
#define KEY_LOG_PATH		_T("Log File Path")
#define KEY_LOG_FILTER		_T("Log Mask")

#define KEY_VERSION			_T("Version")
#define KEY_COMMENTS		_T("Comments")
#define KEY_UTC_IN_USE		_T("UTC In Use")
#define KEY_NT_NOPRERESOLVE	_T("NT No PreResolve")

#define KEY_WATCH_TIMEOUT	_T("Watch Timeout Milliseconds")

#define KEY_CLUSTERINGTRANSPORT			_T("Clustering Transport")

using namespace IM;

ServiceConfiguration::ServiceConfiguration(const TCHAR *szComputerName_, const TCHAR *szKeyPath_, const TCHAR *szServiceName_) :
		RegistryMap(szComputerName_, HKEY_LOCAL_MACHINE, szKeyPath_),
		m_strServiceName(szServiceName_),
		m_hSCM(NULL),
		m_bInstalled(false)
{
	m_serviceConfig = (QUERY_SERVICE_CONFIG *) m_serviceConfigBuf;

	//
	//	Initialize registry based property map
	//
	m_strLogonID.SetEncryptFlag(true);
	m_strPassword.SetEncryptFlag(true);
	m_lLogMask.Set(LFO_ERROR | LFO_WARN | LFO_INFO | LFO_HEADER | LOG_ALL_DATA);
	m_bUtcInUse = true;
	m_bNoPreResolve = false;
	m_bStartOnBoot = true;
	m_lWatchTimeout = 600000; // 10 min

	m_lClusteringTransport.Set(0);
	m_strServicePath.SetServerOnlyFlag(true);

	m_propertyMap.insert(PropertyMap::value_type(KEY_LOGONID, &m_strLogonID));
	m_propertyMap.insert(PropertyMap::value_type(KEY_PASSWORD, &m_strPassword));
	m_propertyMap.insert(PropertyMap::value_type(KEY_BOOT_STARTUP, &m_bStartOnBoot));

	m_propertyMap.insert(PropertyMap::value_type(KEY_SERVICE_PATH, &m_strServicePath));
	m_propertyMap.insert(PropertyMap::value_type(KEY_LOG_PATH, &m_strLogPath));
	m_propertyMap.insert(PropertyMap::value_type(KEY_LOG_FILTER, &m_lLogMask));

	m_propertyMap.insert(PropertyMap::value_type(KEY_VERSION, &m_strVersion));
	m_propertyMap.insert(PropertyMap::value_type(KEY_COMMENTS, &m_strComments));
	m_propertyMap.insert(PropertyMap::value_type(KEY_UTC_IN_USE, &m_bUtcInUse));
	m_propertyMap.insert(PropertyMap::value_type(KEY_NT_NOPRERESOLVE, &m_bNoPreResolve));
	m_propertyMap.insert(PropertyMap::value_type(KEY_WATCH_TIMEOUT, &m_lWatchTimeout));
	m_propertyMap.insert(PropertyMap::value_type(KEY_CLUSTERINGTRANSPORT, &m_lClusteringTransport));
}

	ServiceConfiguration::ServiceConfiguration(
		const TCHAR *szComputerName_,
		const TCHAR *szKeyPath_,
		const TCHAR *szServiceName_,
		const TCHAR *szServiceDisplayName_,
		const TCHAR *szServiceScmName_
	) :
		RegistryMap(szComputerName_, HKEY_LOCAL_MACHINE, szKeyPath_),
		m_strServiceName(szServiceName_),
		m_strServiceDisplayName(szServiceDisplayName_),
		m_strServiceScmName(szServiceScmName_),
		m_hSCM(NULL),
		m_bInstalled(false)
{
	m_serviceConfig = (QUERY_SERVICE_CONFIG *) m_serviceConfigBuf;

	//
	//	Initialize registry based property map
	//
	m_strLogonID.SetEncryptFlag(true);
	m_strPassword.SetEncryptFlag(true);
	m_lLogMask.Set(LFO_ERROR | LFO_WARN | LFO_INFO | LFO_HEADER | LOG_ALL_DATA);
	m_bUtcInUse = true;
	m_bNoPreResolve = false;
	m_lWatchTimeout = 600000; // 10 min
	m_strServicePath.SetServerOnlyFlag(true);

	m_propertyMap.insert(PropertyMap::value_type(KEY_LOGONID, &m_strLogonID));
	m_propertyMap.insert(PropertyMap::value_type(KEY_PASSWORD, &m_strPassword));
	m_propertyMap.insert(PropertyMap::value_type(KEY_BOOT_STARTUP, &m_bStartOnBoot));

	m_propertyMap.insert(PropertyMap::value_type(KEY_SERVICE_PATH, &m_strServicePath));
	m_propertyMap.insert(PropertyMap::value_type(KEY_LOG_PATH, &m_strLogPath));
	m_propertyMap.insert(PropertyMap::value_type(KEY_LOG_FILTER, &m_lLogMask));

	m_propertyMap.insert(PropertyMap::value_type(KEY_VERSION, &m_strVersion));
	m_propertyMap.insert(PropertyMap::value_type(KEY_COMMENTS, &m_strComments));
	m_propertyMap.insert(PropertyMap::value_type(KEY_UTC_IN_USE, &m_bUtcInUse));
	m_propertyMap.insert(PropertyMap::value_type(KEY_NT_NOPRERESOLVE, &m_bNoPreResolve));
	m_propertyMap.insert(PropertyMap::value_type(KEY_WATCH_TIMEOUT, &m_lWatchTimeout));
}



ServiceConfiguration::~ServiceConfiguration()
{
	if (m_hSCM != NULL)
		CloseScmHandle();
}



bool
ServiceConfiguration::Init(bool readOnly)
{
	SC_HANDLE		hService;
    
	// attempt to open service handle
	hService = GetServiceHandle(readOnly); 
	if (hService != NULL)
	{
		m_bInstalled = true;
		::CloseServiceHandle(hService);
	}
	else
	{
		if (m_hSCM == NULL)
		{
			LastErrorString		strError;

			LogMessage(LM_ERROR, TEXT("Could not connect to Service Control Manager on %s: %s"),
				m_strComputerName.c_str(), strError.c_str());
			return false;
		}
	}

	return true;
}


void
ServiceConfiguration::OpenScmHandle(bool readOnly)
{
	if (m_hSCM == NULL)
	{
		// determine if the service is installed 
		if (readOnly)
		{
					// determine if the service is installed 
			m_hSCM = ::OpenSCManager(m_strComputerName.c_str(),	// computer running the service
									NULL,						// ServicesActive database
									SC_MANAGER_CONNECT|SC_MANAGER_ENUMERATE_SERVICE);
		}
		else
		{
			m_hSCM = ::OpenSCManager(m_strComputerName.c_str(),	// computer running the service
									NULL,						// ServicesActive database
									SC_MANAGER_ALL_ACCESS);		// full access
		}
	}
}


void
ServiceConfiguration::CloseScmHandle()
{
	::CloseServiceHandle(m_hSCM);
	m_hSCM = NULL;
}


SC_HANDLE
ServiceConfiguration::GetServiceHandle(bool readOnly)
{
	SC_HANDLE		hService;

	OpenScmHandle(readOnly);

	if (m_hSCM == NULL)
		return NULL;
	// Try to open the service
	if (readOnly)
	{
		hService = ::OpenService(m_hSCM, m_strServiceName.c_str(), SERVICE_INTERROGATE|SERVICE_START|SERVICE_STOP);
	}
	else
	{
		hService = ::OpenService(m_hSCM, m_strServiceName.c_str(), SERVICE_ALL_ACCESS);
	}
	if (hService == NULL)
	{
		m_bInstalled = false;
		return NULL;
	}

	m_bInstalled = true;

	return hService;
}


void
ServiceConfiguration::InitUserInfo()
{
	HANDLE			hProcess, hAccessToken;
	TCHAR			InfoBuffer[1000], szAccountName[200], szDomainName[200];
	PTOKEN_USER		pTokenUser = (PTOKEN_USER)InfoBuffer;
	DWORD			dwInfoBufferSize, dwAccountSize = 200, dwDomainSize = 200;
	SID_NAME_USE	snu;

	// get process access token
	hProcess = ::GetCurrentProcess();
	::OpenProcessToken(hProcess, TOKEN_READ, &hAccessToken);

	::GetTokenInformation(hAccessToken, TokenUser, InfoBuffer, 1000, &dwInfoBufferSize);

	::LookupAccountSid(
					NULL,
					pTokenUser->User.Sid,
					(TCHAR *) szAccountName,
					&dwAccountSize,
					(TCHAR *) szDomainName,
					&dwDomainSize,
					&snu);

	m_strDomainName = szDomainName;
	m_strLogonID.Set(szAccountName);
	m_strPassword.Set(TEXT("*******************"));

}


static TCHAR	*pstrStatusString[] =
{
	TEXT("Stopped"),
	TEXT("Stopped"),
	TEXT("Start Pending"),
	TEXT("Stop Pending"),
	TEXT("Running"),
	TEXT("Continue Pending"),
	TEXT("Pause Pending"),
	TEXT("Paused")
};


static TCHAR *strNotInstalled = TEXT("Service is not installed.");


TCHAR *
ServiceConfiguration::GetStatusString()
{
	long			lCurrentState = 0;
	SERVICE_STATUS	serviceStatus;

	SC_HANDLE		hService = GetServiceHandle(true);

	if (hService == NULL)
		return strNotInstalled;

	if (ControlService(hService, SERVICE_CONTROL_INTERROGATE, &serviceStatus) == TRUE)
	{
		lCurrentState = serviceStatus.dwCurrentState;
	}

	CloseServiceHandle(hService);

	return pstrStatusString[lCurrentState];
}



bool
ServiceConfiguration::IsStatus(DWORD status)
{
	bool			bAsRequested = false;
	SERVICE_STATUS	serviceStatus;
	SC_HANDLE		hService = GetServiceHandle(true);

	if (hService == NULL)
		return false;

	if (::ControlService(hService, SERVICE_CONTROL_INTERROGATE, &serviceStatus) == TRUE)
	{
		if (serviceStatus.dwCurrentState == status)
			bAsRequested = true;
	}
    else if (status == SERVICE_STOPPED)	// Stopped Service since SCM has no info
    {
    	bAsRequested = true;
    }

	CloseServiceHandle(hService);

	return bAsRequested;
}



bool
ServiceConfiguration::StartService()
{
	bool			bSuccess = true;
	SERVICE_STATUS	serviceStatus;
	SC_HANDLE		hService = GetServiceHandle(true);

	if (hService == NULL)
		return false;

	if (::ControlService(hService, SERVICE_CONTROL_INTERROGATE, &serviceStatus) == TRUE)
	{
		if (serviceStatus.dwCurrentState != 0 && serviceStatus.dwCurrentState != SERVICE_STOPPED)
		{
			CloseServiceHandle(hService);
			
			LastErrorString strError;
			IM::NrString strErrorMsg(TEXT("Could not start service. "));
			strErrorMsg += strError;

			Event(ECAT_CONFIG, EVW_GENERIC, strErrorMsg.c_str());

			return false;
		}
	}


	if (::StartService(hService, NULL, NULL) != TRUE)
    {
    	if (GetLastError() == ERROR_SERVICE_ALREADY_RUNNING)
        {
        	Event(ECAT_CONFIG, EVW_GENERIC, TEXT("Service is already running; may not have stopped completely from previous stop request."));
        	LogMessage(LM_INFO, TEXT("Service is already running; may not have stopped completely from previous stop request."));
		}
		else
		{
			LastErrorString strError;
			IM::NrString strErrorMsg(TEXT("Could not start service. "));
			strErrorMsg += strError;

			Event(ECAT_CONFIG, EVW_GENERIC, strErrorMsg.c_str());

			LogMessage(LM_ERROR, strErrorMsg.c_str());
		}
		bSuccess = false;
    }

	CloseServiceHandle(hService);

	return bSuccess;
}




bool
ServiceConfiguration::StopService()
{
	bool			bSuccess = true;
	SC_HANDLE		hService = GetServiceHandle(true);
	SERVICE_STATUS	serviceStatus;

	if (hService == NULL)
		return false;

	if (::ControlService(hService, SERVICE_CONTROL_STOP, &serviceStatus) != TRUE)
	{
		LastErrorString strError;
		IM::NrString strErrorMsg(TEXT("Could not stop service. "));
		strErrorMsg += strError;

		Event(ECAT_CONFIG, EVW_GENERIC, strErrorMsg.c_str());
		LogMessage(LM_ERROR, strErrorMsg.c_str());

		bSuccess = false;
	}

	::CloseServiceHandle(hService);

	return bSuccess;
}


bool
ServiceConfiguration::GetServiceConfiguration(NrString& strLogonID_, NrString& strPassword_, bool &bAutoStartup_)
{
	SC_HANDLE		hService = GetServiceHandle();
	DWORD			dwBytesNeeded;

	if (hService == NULL)
		return false;

	if (::QueryServiceConfig(hService, m_serviceConfig, sizeof(m_serviceConfigBuf), &dwBytesNeeded) == 0)
	{
		LastErrorString		strError;
		IM::NrString strErrorMsg(TEXT("Could not get service startup information. "));
		strErrorMsg += strError;

		Event(ECAT_CONFIG, EVW_GENERIC, strErrorMsg.c_str());
		LogMessage(LM_ERROR, strErrorMsg.c_str());

		::CloseServiceHandle(hService);
		return false;
	}

	::CloseServiceHandle(hService);

	LoadFromRegistry();


	NrString	strServiceLogonID(m_serviceConfig->lpServiceStartName);

	if (_tcsncmp(strLogonID_.c_str(), TEXT(".\\"), 2) == 0)	// strip the .\ from .\UserName
	{
		strServiceLogonID = strServiceLogonID.TrimLeft(TEXT('.'));
		strServiceLogonID = strServiceLogonID.TrimLeft(TEXT('\\'));
	}

	strLogonID_ = strServiceLogonID.c_str();
	strPassword_ = m_strPassword.Get();
	bAutoStartup_ = (m_serviceConfig->dwStartType == SERVICE_AUTO_START) ? true : false;

	return true;
}




bool
ServiceConfiguration::SetServiceConfiguration(const TCHAR *szLogonID_, const TCHAR *szPassword_, bool bAutoStartup_)
{
	TCHAR			sidBuffer[1024];
	DWORD			dwSidSz = sizeof(sidBuffer);
	PSID			pSid = (PSID) sidBuffer;
	TCHAR			szDomainName[256];
	DWORD			dwDomainNameSz = sizeof(szDomainName);
	SID_NAME_USE	sidType;

	SC_HANDLE		hService = GetServiceHandle();
	NrString		newLogonID;

	if (hService == NULL)
		return false;

	//
	// if the specified name has a "Domain\userName format then use it.  Otherwise compute the
	// domain name and prepend it to the logonID before passing it to ChangeServiceConfig.
	// NOTE: logonID may be set to ".\UserName" (from getServiceConfiguration); convert it
	// also.
	if (_tcschr(szLogonID_, TEXT('\\')) != NULL && _tcsncmp(szLogonID_, TEXT(".\\"), 2) != 0)
	{
		m_serviceConfig->lpServiceStartName = (TCHAR *) szLogonID_;
		newLogonID = szLogonID_;
	}
	else
	{
		if (_tcsncmp(szLogonID_, TEXT(".\\"), 2) == 0)	// stip the .\ from .\UserName
			szLogonID_ += 2;

		if (LookupAccountName(	m_strComputerName.c_str(),
								szLogonID_,
								pSid,
								&dwSidSz,
								szDomainName,
								&dwDomainNameSz,
								&sidType) != TRUE)
		{
			LastErrorString strError;
			IM::NrString strErrorMsg(TEXT("Could not locate information for account "));
			strErrorMsg += szLogonID_;
			strErrorMsg += TEXT(". ");
			strErrorMsg += strError;

			LogMessage(LM_WARN, strErrorMsg.c_str());

			Event(ECAT_CONFIG, EVW_GENERIC, strErrorMsg.c_str());

			return false;
		}

		newLogonID = szDomainName;
		newLogonID += TEXT("\\");
		newLogonID += szLogonID_;

		m_serviceConfig->lpServiceStartName = (TCHAR *) newLogonID.c_str();
	}
	m_serviceConfig->dwStartType = (bAutoStartup_ == true) ? SERVICE_AUTO_START : SERVICE_DEMAND_START;
	if (::ChangeServiceConfig(hService,
					SERVICE_NO_CHANGE,						// service type
					m_serviceConfig->dwStartType,			// start type
					SERVICE_NO_CHANGE,						// error control
					NULL,									// service executable path
					NULL,									// load order group
					NULL,									// load order group tag ID
					NULL,									// dependencies
					(szLogonID_[0] == '\0' ) ? _T(".\\LOCALSYSTEM") :m_serviceConfig->lpServiceStartName,	// service start name (logon ID for service)
					szPassword_,
					NULL) == 0)
	{
		LastErrorString		strError;
		IM::NrString strErrorMsg(TEXT("Could not set service startup information for account "));
		strErrorMsg += szLogonID_;
		strErrorMsg += TEXT(". ");
		strErrorMsg += strError;

		LogMessage(LM_WARN, strErrorMsg.c_str());

		Event(ECAT_CONFIG, EVW_GENERIC, strError.c_str());

		::CloseServiceHandle(hService);
		return false;
	}
	::CloseServiceHandle(hService);


	//
	//	save logonID and password in the registry
	//
	m_strLogonID.Set(szLogonID_);
	m_strPassword.Set(szPassword_);

	StoreInRegistry();
	GrantServiceLogonPrivilege(newLogonID.c_str());

	// for the sync svc, make sure its user has the "Grant as part of the operating system" right
	// and "Log on locally"
	CDSSyncSvc* pSyncSvc = dynamic_cast< CDSSyncSvc* >( this );
	if( pSyncSvc )
	{
		GrantActAsPartOfOperatingSystemPrivilege( szLogonID_ );
		GrantInteractiveLogonPrivilege( szLogonID_ );
	}

	return true;
}


bool
ServiceConfiguration::IsAdministrator()
{
	HANDLE			hAccessToken = NULL;
	UCHAR			*pTokenBuffer = NULL;
	PTOKEN_GROUPS	ptgGroups;
	DWORD			dwTokenBufferSize = 0;
	PSID			psidAdministrators = NULL;
	UINT			x;
	bool			bSuccess;

	SID_IDENTIFIER_AUTHORITY siaNtAuthority = SECURITY_NT_AUTHORITY;

	try
	{
		if (::OpenProcessToken(::GetCurrentProcess(), TOKEN_READ, &hAccessToken) != TRUE)
			throw (long) GetLastError();

		// get needed size of token bufffer
		if (::GetTokenInformation(hAccessToken, TokenGroups, pTokenBuffer, 0, &dwTokenBufferSize) != FALSE &&
			GetLastError() != ERROR_INSUFFICIENT_BUFFER)
		{
			throw (long) GetLastError();
		}
		pTokenBuffer = im_new UCHAR [dwTokenBufferSize];

		if (::GetTokenInformation(hAccessToken, TokenGroups, pTokenBuffer, dwTokenBufferSize, &dwTokenBufferSize) != TRUE)
			throw (long) GetLastError();

		CloseHandle(hAccessToken);
		hAccessToken = NULL;

		if (AllocateAndInitializeSid(	&siaNtAuthority, 2,
										SECURITY_BUILTIN_DOMAIN_RID,
										DOMAIN_ALIAS_RID_ADMINS,
										0, 0, 0, 0, 0, 0,
										&psidAdministrators) != TRUE)
		{
			throw (long) GetLastError();
		}

		// assume that we don't find the admin SID.
		bSuccess = false;

		ptgGroups = (PTOKEN_GROUPS) pTokenBuffer;
		for ( x=0; x < ptgGroups->GroupCount; x++)
		{
			if (EqualSid(psidAdministrators, ptgGroups->Groups[x].Sid))
			{
				bSuccess = true;
				break;
			}
		}
	
		FreeSid(psidAdministrators);
		delete [] pTokenBuffer;
	}
	catch (long)
	{
		if (hAccessToken != NULL)
			CloseHandle(hAccessToken);

		if (psidAdministrators != NULL)
			FreeSid(psidAdministrators);

		if (pTokenBuffer != NULL)
			delete [] pTokenBuffer;

		LastErrorString strError;
		IM::NrString strErrorMsg(TEXT("Could not determine Administrator privileges. "));
		strErrorMsg += strError;

		LogMessage(LM_WARN, strErrorMsg.c_str());
		Event(ECAT_CONFIG, EVW_GENERIC, strErrorMsg.c_str());

		return false;
	}

	return bSuccess;
}


#ifndef STATUS_SUCCESS
#define STATUS_SUCCESS                  ((NTSTATUS)0x00000000L)
#define STATUS_OBJECT_NAME_NOT_FOUND    ((NTSTATUS)0xC0000034L)
#define STATUS_INVALID_SID              ((NTSTATUS)0xC0000078L)
#endif
 

void
	ServiceConfiguration::GrantServiceLogonPrivilege(const TCHAR *szLogonID_)
{
	LSA_HANDLE				hPolicyHandle = NULL;
	LSA_OBJECT_ATTRIBUTES	objectAttributes;
	TCHAR					sidBuffer[1024];
	DWORD					dwSidSz = sizeof(sidBuffer);
	PSID					pSid = (PSID) sidBuffer;
	TCHAR					szDomainName[256];
	DWORD					dwDomainNameSz = sizeof(szDomainName);
	SID_NAME_USE			sidType;
	NrString				accountName;
	WCHAR					*wszPrimaryDC = NULL;

	try
	{
		//
		// determine the location of the user account information: in the local machine
		// or in the domain.  We are passed szLogonID as domain-name\logonID or
		// WorkGroup\logonID where workgroup happens to be the local machine.
		//

		// Get SID for user
		if (LookupAccountName(	m_strComputerName.c_str(),
								szLogonID_,
								pSid,
								&dwSidSz,
								szDomainName,
								&dwDomainNameSz,
								&sidType) != TRUE)
		{
			NrString		strLogonID(szLogonID_);
			NrString		strMessage;
			
			strMessage = _T("Could not lookup information for account ");
			strMessage += strLogonID;
			strMessage += _T(".  You may have to set account/password via the Control Panel.");

			throw_error(GetLastError(), strMessage.c_str());
		}

		LSA_UNICODE_STRING	lsaServerName;
		unsigned short		StringLength;

		StringLength = (unsigned short)_tcslen(m_strComputerName.c_str()) * sizeof(TCHAR);
		IM::NrUnicodeString strUnicode = m_strComputerName.toUnicode().c_str();
		lsaServerName.Buffer = (WCHAR *) strUnicode.c_str();
		lsaServerName.Length =  (StringLength * sizeof(WCHAR));
		lsaServerName.MaximumLength = (USHORT) ((StringLength + 1) * sizeof(WCHAR));

		memset(&objectAttributes, 0, sizeof(objectAttributes));
		if (LsaOpenPolicy(	&lsaServerName,
							&objectAttributes,
							POLICY_CREATE_ACCOUNT | POLICY_LOOKUP_NAMES,
							&hPolicyHandle) != STATUS_SUCCESS)
		{
			NrString		strLogonID(szLogonID_);
			NrString		strMessage;
			
			strMessage = _T("Could not lookup account policy information for ");
			strMessage += strLogonID;
			strMessage += _T(".  You may have to grant 'Service logon privilege' from the user manager.");

			throw_error(GetLastError(), strMessage.c_str());
		}



		// set the priviledge: code lifted from a Win NT sample
		LSA_UNICODE_STRING	PrivilegeString;

		StringLength = (unsigned short)wcslen(L"SeServiceLogonRight");
		PrivilegeString.Buffer = L"SeServiceLogonRight";
		PrivilegeString.Length = (USHORT) (StringLength * sizeof(WCHAR));
		PrivilegeString.MaximumLength = (USHORT)((StringLength + 1) * sizeof(WCHAR));

		if (LsaAddAccountRights(hPolicyHandle,
								pSid,
								&PrivilegeString,
								1) != STATUS_SUCCESS)
		{
			// could not add privilege to local SAM;  attempt to do it on the
			// domain controller

			try
			{
				LSA_UNICODE_STRING		lsaString;

				if (NetGetDCName(NULL, NULL, (LPBYTE *) &wszPrimaryDC) != NERR_Success)
					throw_error(GetLastError(), _T("NetGetDCName error"));

				if (hPolicyHandle != NULL)
				{
					LsaClose(hPolicyHandle);
					hPolicyHandle = NULL;
				}

				lsaString.Length = (USHORT) (wcslen(wszPrimaryDC) * 2);
				lsaString.MaximumLength = lsaString.Length;
				lsaString.Buffer = wszPrimaryDC;

				if (LsaOpenPolicy(	&lsaString,
									&objectAttributes,
									POLICY_CREATE_ACCOUNT | POLICY_LOOKUP_NAMES,
									&hPolicyHandle) != STATUS_SUCCESS)
				{
					NrString		strLogonID(szLogonID_);
					NrString		strMessage;
					
					strMessage = _T("Could not lookup account policy information for ");
					strMessage += strLogonID;
					strMessage += _T(".  You may have to grant 'Service logon privilege' from the user manager.");

					throw_error(GetLastError(), strMessage.c_str());
				}

				if (LsaAddAccountRights(hPolicyHandle, pSid, &PrivilegeString, 1) != STATUS_SUCCESS)
					throw_error(GetLastError(), _T("LsaAddAccountRights error"));

				LogMessage(LM_INFO, TEXT("Granted 'Service logon privilege' to account %s"), szLogonID_);
				Event(ECAT_CONFIG, EV_USR_PRIV, szLogonID_);
			}
			catch(long)
			{
				NrString		strLogonID(szLogonID_);
				NrString		strMessage;
				
				strMessage = _T("Could not grant 'Service logon privilege' to account ");
				strMessage += strLogonID;
				strMessage += _T(".  You may have to grant 'Service logon privilege' from the user manager.");

				throw_error(GetLastError(), strMessage.c_str());
			}
		}
		else
		{
			LogMessage(LM_INFO, TEXT("Granted 'Service logon privilege' to account %s"), szLogonID_);
			Event(ECAT_CONFIG, EV_USR_PRIV, szLogonID_);
		}

		LsaClose(hPolicyHandle);
	}
	catch (Exception &exception)
	{
		log_exception();

		Event(ECAT_CONFIG, EV_USR_NO_PRIV, szLogonID_);

		if (hPolicyHandle != NULL)
			LsaClose(hPolicyHandle);
	}

	if (wszPrimaryDC != NULL)
		NetApiBufferFree(wszPrimaryDC);
}



void
	ServiceConfiguration::GrantActAsPartOfOperatingSystemPrivilege(const TCHAR *szLogonID_)
{
	LSA_HANDLE				hPolicyHandle = NULL;
	LSA_OBJECT_ATTRIBUTES	objectAttributes;
	TCHAR					sidBuffer[1024];
	DWORD					dwSidSz = sizeof(sidBuffer);
	PSID					pSid = (PSID) sidBuffer;
	TCHAR					szDomainName[256];
	DWORD					dwDomainNameSz = sizeof(szDomainName);
	SID_NAME_USE			sidType;
	NrString				accountName;
	WCHAR					*wszPrimaryDC = NULL;

	try
	{
		//
		// determine the location of the user account information: in the local machine
		// or in the domain.  We are passed szLogonID as domain-name\logonID or
		// WorkGroup\logonID where workgroup happens to be the local machine.
		//

		// Get SID for user
		if (LookupAccountName(	m_strComputerName.c_str(),
								szLogonID_,
								pSid,
								&dwSidSz,
								szDomainName,
								&dwDomainNameSz,
								&sidType) != TRUE)
		{
			NrString		strLogonID(szLogonID_);
			NrString		strMessage;
			
			strMessage = _T("Could not lookup information for account ");
			strMessage += strLogonID;
			strMessage += _T(".  You may have to set account/password via the Control Panel.");

			throw_error(GetLastError(), strMessage.c_str());
		}

		LSA_UNICODE_STRING	lsaServerName;
		unsigned short		StringLength;

		StringLength = (unsigned short)_tcslen(m_strComputerName.c_str()) * sizeof(TCHAR);
		IM::NrUnicodeString strUnicode = m_strComputerName.toUnicode().c_str();
		lsaServerName.Buffer = (WCHAR *) strUnicode.c_str();
		lsaServerName.Length =  (StringLength * sizeof(WCHAR));
		lsaServerName.MaximumLength = (USHORT) ((StringLength + 1) * sizeof(WCHAR));

		memset(&objectAttributes, 0, sizeof(objectAttributes));
		if (LsaOpenPolicy(	&lsaServerName,
							&objectAttributes,
							POLICY_CREATE_ACCOUNT | POLICY_LOOKUP_NAMES,
							&hPolicyHandle) != STATUS_SUCCESS)
		{
			NrString		strLogonID(szLogonID_);
			NrString		strMessage;
			
			strMessage = _T("Could not lookup account policy information for ");
			strMessage += strLogonID;
			strMessage += _T(".  You may have to grant 'Act as part of operating system privilege' from the user manager.");

			throw_error(GetLastError(), strMessage.c_str());
		}

		bool bAlreadyGranted = false;
		ULONG CountOfRights = 0;
		LSA_UNICODE_STRING* pUserRights = NULL;
		NTSTATUS ntstatus = LsaEnumerateAccountRights( hPolicyHandle, pSid, &pUserRights, &CountOfRights );
		for( DWORD i=0; i<CountOfRights; i++ )
		{
			LSA_UNICODE_STRING	privilegeString = pUserRights[ i ];
			wchar_t* str = privilegeString.Buffer;

			if( wcscmp( str, L"SeTcbPrivilege" ) == 0 )
			{
				bAlreadyGranted = true;
				break;
			}
		}

		if( !bAlreadyGranted )
		{
			// set the priviledge: code lifted from a Win NT sample
			LSA_UNICODE_STRING	PrivilegeString;

			StringLength = (unsigned short)wcslen(L"SeTcbPrivilege");
			PrivilegeString.Buffer = L"SeTcbPrivilege";
			PrivilegeString.Length = (USHORT) (StringLength * sizeof(WCHAR));
			PrivilegeString.MaximumLength = (USHORT)((StringLength + 1) * sizeof(WCHAR));

			if (LsaAddAccountRights(hPolicyHandle,
									pSid,
									&PrivilegeString,
									1) != STATUS_SUCCESS)
			{
				// could not add privilege to local SAM;  attempt to do it on the
				// domain controller

				try
				{
					LSA_UNICODE_STRING		lsaString;

					if (NetGetDCName(NULL, NULL, (LPBYTE *) &wszPrimaryDC) != NERR_Success)
						throw_error(GetLastError(), _T("NetGetDCName error"));

					if (hPolicyHandle != NULL)
					{
						LsaClose(hPolicyHandle);
						hPolicyHandle = NULL;
					}

					lsaString.Length = (USHORT) (wcslen(wszPrimaryDC) * 2);
					lsaString.MaximumLength = lsaString.Length;
					lsaString.Buffer = wszPrimaryDC;

					if (LsaOpenPolicy(	&lsaString,
										&objectAttributes,
										POLICY_CREATE_ACCOUNT | POLICY_LOOKUP_NAMES,
										&hPolicyHandle) != STATUS_SUCCESS)
					{
						NrString		strLogonID(szLogonID_);
						NrString		strMessage;
						
						strMessage = _T("Could not lookup account policy information for ");
						strMessage += strLogonID;
						strMessage += _T(".  You may have to grant 'Act as part of operating system privilege' from the user manager.");

						throw_error(GetLastError(), strMessage.c_str());
					}

					if (LsaAddAccountRights(hPolicyHandle, pSid, &PrivilegeString, 1) != STATUS_SUCCESS)
						throw_error(GetLastError(), _T("LsaAddAccountRights error"));

					LogMessage(LM_INFO, TEXT("Granted 'Act as part of operating system privilege' to account %s"), szLogonID_);
					Event(ECAT_CONFIG, EV_USR_TCB_PRIV, szLogonID_);
				}
				catch(long)
				{
					NrString		strLogonID(szLogonID_);
					NrString		strMessage;
					
					strMessage = _T("Could not grant 'Act as part of operating system privilege' to account ");
					strMessage += strLogonID;
					strMessage += _T(".  You may have to grant 'Act as part of operating system privilege' from the user manager.");

					throw_error(GetLastError(), strMessage.c_str());
				}
			}
			else
			{
				LogMessage(LM_INFO, TEXT("Granted 'Act as part of operating system privilege' to account %s"), szLogonID_);
				Event(ECAT_CONFIG, EV_USR_TCB_PRIV, szLogonID_);
			}
		}
		else
		{
			// silently succeed
		}

		LsaClose(hPolicyHandle);
	}
	catch (Exception &exception)
	{
		log_exception();

		Event(ECAT_CONFIG, EV_USR_NO_TCB_PRIV, szLogonID_);

		if (hPolicyHandle != NULL)
			LsaClose(hPolicyHandle);
	}

	if (wszPrimaryDC != NULL)
		NetApiBufferFree(wszPrimaryDC);
}


void
	ServiceConfiguration::GrantInteractiveLogonPrivilege(const TCHAR *szLogonID_)
{
	LSA_HANDLE				hPolicyHandle = NULL;
	LSA_OBJECT_ATTRIBUTES	objectAttributes;
	TCHAR					sidBuffer[1024];
	DWORD					dwSidSz = sizeof(sidBuffer);
	PSID					pSid = (PSID) sidBuffer;
	TCHAR					szDomainName[256];
	DWORD					dwDomainNameSz = sizeof(szDomainName);
	SID_NAME_USE			sidType;
	NrString				accountName;
	WCHAR					*wszPrimaryDC = NULL;

	try
	{
		//
		// determine the location of the user account information: in the local machine
		// or in the domain.  We are passed szLogonID as domain-name\logonID or
		// WorkGroup\logonID where workgroup happens to be the local machine.
		//

		// Get SID for user
		if (LookupAccountName(	m_strComputerName.c_str(),
								szLogonID_,
								pSid,
								&dwSidSz,
								szDomainName,
								&dwDomainNameSz,
								&sidType) != TRUE)
		{
			NrString		strLogonID(szLogonID_);
			NrString		strMessage;
			
			strMessage = _T("Could not lookup information for account ");
			strMessage += strLogonID;
			strMessage += _T(".  You may have to set account/password via the Control Panel.");

			throw_error(GetLastError(), strMessage.c_str());
		}

		LSA_UNICODE_STRING	lsaServerName;
		unsigned short		StringLength;

		StringLength = (unsigned short)_tcslen(m_strComputerName.c_str()) * sizeof(TCHAR);
		IM::NrUnicodeString strUnicode = m_strComputerName.toUnicode().c_str();
		lsaServerName.Buffer = (WCHAR *) strUnicode.c_str();
		lsaServerName.Length =  (StringLength * sizeof(WCHAR));
		lsaServerName.MaximumLength = (USHORT) ((StringLength + 1) * sizeof(WCHAR));

		memset(&objectAttributes, 0, sizeof(objectAttributes));
		if (LsaOpenPolicy(	&lsaServerName,
							&objectAttributes,
							POLICY_CREATE_ACCOUNT | POLICY_LOOKUP_NAMES,
							&hPolicyHandle) != STATUS_SUCCESS)
		{
			NrString		strLogonID(szLogonID_);
			NrString		strMessage;
			
			strMessage = _T("Could not lookup account policy information for ");
			strMessage += strLogonID;
			strMessage += _T(".  You may have to grant 'Log on locally privilege' from the user manager.");

			throw_error(GetLastError(), strMessage.c_str());
		}


		bool bAlreadyGranted = false;
		ULONG CountOfRights = 0;
		LSA_UNICODE_STRING* pUserRights = NULL;
		NTSTATUS ntstatus = LsaEnumerateAccountRights( hPolicyHandle, pSid, &pUserRights, &CountOfRights );
		for( DWORD i=0; i<CountOfRights; i++ )
		{
			LSA_UNICODE_STRING	privilegeString = pUserRights[ i ];
			wchar_t* str = privilegeString.Buffer;

			if( wcscmp( str, L"SeInteractiveLogonRight" ) == 0 )
			{
				bAlreadyGranted = true;
				break;
			}
		}

		if( !bAlreadyGranted )
		{
			// set the priviledge: code lifted from a Win NT sample
			LSA_UNICODE_STRING	PrivilegeString;

			StringLength = (unsigned short)wcslen(L"SeInteractiveLogonRight");
			PrivilegeString.Buffer = L"SeInteractiveLogonRight";
			PrivilegeString.Length = (USHORT) (StringLength * sizeof(WCHAR));
			PrivilegeString.MaximumLength = (USHORT)((StringLength + 1) * sizeof(WCHAR));

			if (LsaAddAccountRights(hPolicyHandle,
									pSid,
									&PrivilegeString,
									1) != STATUS_SUCCESS)
			{
				// could not add privilege to local SAM;  attempt to do it on the
				// domain controller

				try
				{
					LSA_UNICODE_STRING		lsaString;

					if (NetGetDCName(NULL, NULL, (LPBYTE *) &wszPrimaryDC) != NERR_Success)
						throw_error(GetLastError(), _T("NetGetDCName error"));

					if (hPolicyHandle != NULL)
					{
						LsaClose(hPolicyHandle);
						hPolicyHandle = NULL;
					}

					lsaString.Length = (USHORT) (wcslen(wszPrimaryDC) * 2);
					lsaString.MaximumLength = lsaString.Length;
					lsaString.Buffer = wszPrimaryDC;

					if (LsaOpenPolicy(	&lsaString,
										&objectAttributes,
										POLICY_CREATE_ACCOUNT | POLICY_LOOKUP_NAMES,
										&hPolicyHandle) != STATUS_SUCCESS)
					{
						NrString		strLogonID(szLogonID_);
						NrString		strMessage;
						
						strMessage = _T("Could not lookup account policy information for ");
						strMessage += strLogonID;
						strMessage += _T(".  You may have to grant 'Log on locally privilege' from the user manager.");

						throw_error(GetLastError(), strMessage.c_str());
					}

					if (LsaAddAccountRights(hPolicyHandle, pSid, &PrivilegeString, 1) != STATUS_SUCCESS)
						throw_error(GetLastError(), _T("LsaAddAccountRights error"));

					LogMessage(LM_INFO, TEXT("Granted 'Log on locally privilege' to account %s"), szLogonID_);
					Event(ECAT_CONFIG, EV_USR_INTERACTIVE_LOGON_PRIV, szLogonID_);
				}
				catch(long)
				{
					NrString		strLogonID(szLogonID_);
					NrString		strMessage;
					
					strMessage = _T("Could not grant 'Log on locally privilege' to account ");
					strMessage += strLogonID;
					strMessage += _T(".  You may have to grant 'Log on locally privilege' from the user manager.");

					throw_error(GetLastError(), strMessage.c_str());
				}
			}
			else
			{
				LogMessage(LM_INFO, TEXT("Granted 'Log on locally privilege' to account %s"), szLogonID_);
				Event(ECAT_CONFIG, EV_USR_INTERACTIVE_LOGON_PRIV, szLogonID_);
			}
		}
		else
		{
			// silent succeed
		}

		LsaClose(hPolicyHandle);
	}
	catch (Exception &exception)
	{
		log_exception();

		Event(ECAT_CONFIG, EV_USR_NO_INTERACTIVE_LOGON_PRIV, szLogonID_);

		if (hPolicyHandle != NULL)
			LsaClose(hPolicyHandle);
	}

	if (wszPrimaryDC != NULL)
		NetApiBufferFree(wszPrimaryDC);
}


bool
ServiceConfiguration::IsUserLoggedOn(TCHAR *szUserName, TCHAR *szDomainName_, TCHAR* szPassword_)
{
	HANDLE	phToken;

	if (LogonUser(szUserName, szDomainName_, szPassword_, LOGON32_LOGON_SERVICE, LOGON32_PROVIDER_DEFAULT, &phToken) == FALSE)         
 		return false;
	else
		return true;
}


bool
ServiceConfiguration::Install(const TCHAR *szPath_, const TCHAR *szLogonID_, const TCHAR *szPassword_, bool bAutoStartup_)
{
	TCHAR			sidBuffer[1024];
	DWORD			dwSidSz = sizeof(sidBuffer);
	PSID			pSid = (PSID) sidBuffer;
	TCHAR			szDomainName[256];
	DWORD			dwDomainNameSz = sizeof(szDomainName);
	SID_NAME_USE	sidType;

	DWORD			dwStartType = (bAutoStartup_ == true ? SERVICE_AUTO_START : SERVICE_DEMAND_START);
		
	SC_HANDLE		hService;
	NrString		newLogonID;
	bool            isLocalSys = false;


	//
	// if the specified name has a "Domain\userName format then use it.  Otherwise compute the
	// domain name and prepend it to the logonID before passing it to ChangeServiceConfig.
	// NOTE: logonID may be set to ".\UserName" (from getServiceConfiguration); convert it
	// also.
	if (szLogonID_[0] != '\0')
	{
		if (_tcschr(szLogonID_, TEXT('\\')) != NULL && _tcsncmp(szLogonID_, TEXT(".\\"), 2) != 0)
		{
			m_serviceConfig->lpServiceStartName = (TCHAR *) szLogonID_;
			newLogonID = szLogonID_;
		}
		else
		{
			if (_tcsncmp(szLogonID_, TEXT(".\\"), 2) == 0)
				szLogonID_ += 2;

			if (::LookupAccountName(m_strComputerName.c_str(),
									szLogonID_,
									pSid,
									&dwSidSz,
									szDomainName,
									&dwDomainNameSz,
									&sidType) != TRUE)
			{
				LastErrorString strError;
				IM::NrString strErrorMsg(TEXT("Could not locate information for account "));
				strErrorMsg += szLogonID_;
				strErrorMsg += TEXT(". ");
				strErrorMsg += strError;
				LogMessage(LM_WARN, strErrorMsg.c_str());
				Event(ECAT_CONFIG, EVW_GENERIC, strErrorMsg.c_str());	
				return false;
			}

			newLogonID = szDomainName;
			newLogonID += TEXT("\\");
			newLogonID += szLogonID_;

			m_serviceConfig->lpServiceStartName = (TCHAR *) newLogonID.c_str();
		}
	}
	else
	{
		isLocalSys = true;
	}

	if (m_hSCM == NULL)
	{
		LogMessage(LM_ERROR, TEXT("Could not connect to Service Control Manager on %s"),
			m_strComputerName.c_str());
		return false;
	}

	hService = ::CreateService(
						m_hSCM,													// SCManager database
						m_strServiceName.c_str(),								// name of service
						m_strServiceScmName.c_str(),							// name to display
						SERVICE_ALL_ACCESS,										// desired access
						SERVICE_WIN32_OWN_PROCESS,								// service type
						dwStartType,											// start type
						SERVICE_ERROR_NORMAL,									// error control type
						szPath_,												// service's binary
						NULL,													// no load ordering group
						NULL,													// no tag identifier
						_T("LanmanServer\0LanmanWorkstation\0Tcpip\0Afd"),				// dependencies
						isLocalSys ? NULL : newLogonID.c_str(),					// account
						szPassword_);											// password

	if (hService == NULL)
	{
		LastErrorString strError;
		IM::NrString strErrorMsg(TEXT("Could not install service for account "));
		strErrorMsg += newLogonID;
		strErrorMsg += TEXT(". ");
		strErrorMsg += strError;
 
 		LogMessage(LM_WARN, strErrorMsg.c_str());

		Event(ECAT_CONFIG, EVW_GENERIC, strErrorMsg.c_str());

		return false;
	}

	//createservice doesn't have a field for description
    //so we use ChangeServiceConfig2
	if (!m_strServiceScmDesc.empty())
	{
		SERVICE_DESCRIPTION sd;
		sd.lpDescription = (LPTSTR) m_strServiceScmDesc.c_str();
		::ChangeServiceConfig2(hService, SERVICE_CONFIG_DESCRIPTION, &sd);
	}

	::CloseServiceHandle(hService);

	//
	//	save logonID and password in the registry
	//
	m_strLogonID.Set(szLogonID_);
	m_strPassword.Set(szPassword_);
	m_bStartOnBoot.Set(bAutoStartup_);

	StoreInRegistry();

	GrantServiceLogonPrivilege(szLogonID_);

	// for the sync svc, make sure its user has the "Grant as part of the operating system" right
	// and "Log on locally"
	CDSSyncSvc* pSyncSvc = dynamic_cast< CDSSyncSvc* >( this );
	if( pSyncSvc )
	{
		GrantActAsPartOfOperatingSystemPrivilege( szLogonID_ );
		GrantInteractiveLogonPrivilege( szLogonID_ );
	}

	m_bInstalled = true;

	return m_bInstalled;
}



bool
ServiceConfiguration::Uninstall()
{
	SC_HANDLE		hService = GetServiceHandle();
	SERVICE_STATUS	serviceStatus;

	if (hService == NULL)
		return false;

	if (IsRunning() == true)
	{
		// try to stop the service
		if (::ControlService(hService, SERVICE_CONTROL_STOP, &serviceStatus ))
		{
			Sleep(1000);

			while (::QueryServiceStatus( hService, &serviceStatus ) )
			{
				if (serviceStatus.dwCurrentState == SERVICE_STOP_PENDING )
				{
					Sleep(1000);
				}
				else
					break;
			}
		}
		else
		{
			LastErrorString strError;
			IM::NrString strErrorMsg(TEXT("Could not uninstall service. "));
			strErrorMsg += strError;

			LogMessage(LM_WARN, strErrorMsg.c_str());

			Event(ECAT_CONFIG, EVW_GENERIC, strErrorMsg.c_str());

			return false;
		}

		if (serviceStatus.dwCurrentState != SERVICE_STOPPED)
		{
			::CloseServiceHandle(hService);
			return false;
		}
	}


	// now remove the service
	if (::DeleteService(hService) == FALSE)
	{
		::CloseServiceHandle(hService);
		return false;
	}

	::CloseServiceHandle(hService);
	m_bInstalled = false;
	return true;
}


ServiceConfigurationFactory::ServiceConfigurationFactory()
{
	// local variables
    DWORD dwSize = sizeof(m_szComputerName);

    GetComputerName(m_szComputerName, &dwSize);
}


ServiceConfigurationFactory::~ServiceConfigurationFactory()
{

}


ServiceConfiguration*
ServiceConfigurationFactory::GetServiceConfigurationByKeyName(const TCHAR *szKeyName_)
{
	// local variables
	ServiceConfiguration *pService = NULL;

    if (!_tcsicmp(SZ_DMSSVC_NAME, szKeyName_))
	{
		// WorkSite Server
		pService = im_new DmsServiceConfiguration(m_szComputerName);
	}
	else if (!_tcsicmp(SZ_IDXMGR_NAME, szKeyName_))
	{
		// Index Manager
		pService = im_new IdxMgrServiceConfiguration(m_szComputerName);
	}
	else if (!_tcsicmp(SZ_IDXSCH_NAME, szKeyName_))
	{
		// Index Search
		pService = im_new IdxSearchServiceConfiguration(m_szComputerName);
	}
	else if (!_tcsicmp(SZ_RESVC_NAME, szKeyName_))
	{
		// Rules Engine
		pService = im_new RulesServiceConfiguration(m_szComputerName);
	}
	else if (!_tcsicmp(SZ_FMASVC_NAME, szKeyName_))
	{
		// Cluster Manager
		pService = im_new FmaServiceConfiguration(m_szComputerName);
	}
	else if (!_tcsicmp(SZ_EFSSVC_NAME, szKeyName_))
	{
		// Email Filing Service
		pService = im_new EFSServiceConfiguration(m_szComputerName);
	}
	else if (!_tcsicmp(SZ_WKDRESVC_NAME, szKeyName_))
	{
		// WorkKnowledge DRE
		pService = im_new WkDreServiceConfiguration(m_szComputerName);
	}
	else if (!_tcsicmp(SZ_WKINDXRSVC_NAME, szKeyName_))
	{
		// WorkKnowledge Index Manager
		pService = im_new WkIndxrServiceConfiguration(m_szComputerName);
	}
	else if (!_tcsicmp(SZ_WKATINDXRSVC_NAME, szKeyName_))
	{
		// WorkKnowledge AutoIndexer
		pService = im_new WkAtIndxrServiceConfiguration(m_szComputerName);
	}
	else if (!_tcsicmp(SZ_IDXSVC_NAME, szKeyName_))
	{
		// WorkSite Indexer Service
		pService = im_new IDXSVCConfiguration(m_szComputerName);
	}
	else if (!_tcsicmp(SZ_CIFSSVC_NAME, szKeyName_))
	{
		// Interwoven WorkSite FileShare Service
		pService = im_new CIFSServiceConfiguration(m_szComputerName);
	}
	else if (!_tcsicmp(SZ_RENDERSVC_NAME, szKeyName_))
	{
		// Render Service
		pService = im_new RenderServiceConfiguration(m_szComputerName);
	}
	else
	{
		pService = NULL;
	}

	if (pService != NULL)
	{
	    pService->Init();
	}

	return pService;
}


