////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// File:	LNEMailSvcConfiguration.cpp
//
// Project: Email Management System		Subsystem: Email Filing Service
//
// Contents:	Implements the registry configuration information for the EmailOnline service.
//
//   Date			Who					Modification
// 22/03/13			Bob Kumar			Initial coding.
//
// Copyright (C) 2002, iManage Technologies, Inc. ALL RIGHTS RESERVED
//                     PROPRIETARY AND CONFIDENTIAL
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


#include <LNEMailSvcConfiguration.h>
#include <atlenc.h>
#include <..\..\..\ics\mlib\registry\RegistryLib.h>
#pragma hdrstop
using namespace IM;

#define KEY_STORE_ADMIN_SMTP_ADDRESS		_T("Exchange Administrator SMTP Address")
#define	KEY_STORE_ADMIN_PASSWORD			_T("Exchange Administrator Password")
#define	KEY_PROXY_SERVER					_T("Proxy Server")
#define KEY_PROXY_SERVER_PORT				_T("Proxy Server Port")
#define KEY_EXCHANGE_SERVER_PORT			_T("Exchange Server Port")
#define KEY_CLUSTER_NAME					_T("Cluster Name")
#define KEY_FMA_PORT						_T("FMA Port")
#define KEY_CLASS							_T("Class")
#define KEY_SUBCLASS						_T("SubClass")
#define KEY_TYPE							_T("Type")
#define KEY_THREAD_POOL_SIZE				_T("Thread Pool Size")
#define KEY_EMAIL_RETRIEVAL_COUNT			_T("Email Retrieval Count")
#define KEY_MESSAGE_CLASSES					_T("Message Classes")
#define KEY_MINUTES_UNTIL_RETRY_FILING		_T("Retry Marked Folder Items Older By")
#define KEY_ENABLE_SEND_AND_FILE_AGENT		_T("Enable Send And File Agent")
#define KEY_TARGET_DIRECTORY				_T("Target Directory")
#define KEY_DROP_DIRECTORY					_T("Drop Directory")
#define KEY_BAD_MAIL_DIRECTORY				_T("Bad Directory")
#define KEY_MINUTES_TO_BOUNCE				_T("Minutes Until Bounce")
#define KEY_SMTP_SERVERNAME					_T("SMTP Server Name")
#define KEY_SMTP_SERVERPORT					_T("SMTP Server Port")
#define KEY_SMTP_USERNAME					_T("SMTP Username")
#define KEY_SMTP_PASSWORD					_T("SMTP Password")
#define KEY_SMTP_FROM_ADDRESS				_T("SMTP From Address")
#define KEY_SMTP_REPLY_TO_ADDRESS			_T("SMTP Reply-To Address")
#define KEY_SMTP_CUSTOM						_T("SMTP Custom Bounce Message Text")
#define KEY_SMTP_INCLUDE_BOUNCED			_T("SMTP Include Original Email in Bounce")
#define KEY_SMTP_LINES_TO_QUOTE				_T("SMTP Lines To Quote")
#define KEY_BOUNCETOADMIN					_T("Bounce Only To Administrator")
#define KEY_ALLOWFOLDERNUMBERS				_T("Allow Folder Numbers in Addresses")
#define KEY_FROMLOOKUP						_T("From Address Username Access Lookup")
#define KEY_USESMTPOPENRELAY				_T("Use SMTP Open Relay")
#define KEY_DAYSTORETAINDUPLICATES			_T("Days To Retain Duplicates")
#define KEY_ALTERNATE_AUTODISCOVER_URL		_T("Alternate Autodiscover URL")


const NrString				LNEMailSvcConfiguration::ms_strDatabasesSubkey				= "Databases"	;
const NrString				LNEMailSvcConfiguration::ms_strDomainsSubkey				= "Domains"		;
const NrString				LNEMailSvcConfiguration::ms_strDefaultClass					= "E-MAIL"		;
const NrString				LNEMailSvcConfiguration::ms_strDefaultSubClass				= ""			;
const NrString				LNEMailSvcConfiguration::ms_strDefaultType					= "NOTES"		;
const long					LNEMailSvcConfiguration::ms_nDefaultThreadPoolSize			= 10			;
const long					LNEMailSvcConfiguration::ms_nDefaultEmailRetrievalCount		= 100			;
const NrString				LNEMailSvcConfiguration::ms_strDefaultMessageClasses		= "IPM.Note;IPM.Note.WorkSite.EMS.Queued";
const long					LNEMailSvcConfiguration::ms_nDefaultMinutesUntilRetryFiling	= 600			;
const bool					LNEMailSvcConfiguration::ms_bDefaultEnableSendAndFileAgent	= true			;
const NrString				LNEMailSvcConfiguration::ms_strDefaultDirectory				= ""			;
const long					LNEMailSvcConfiguration::ms_lDefaultMinutesToBounce			= 30			;
const NrString				LNEMailSvcConfiguration::ms_strDefaultSMTPServerName		= ""			;
const long					LNEMailSvcConfiguration::ms_lDefaultSMTPServerPort			= 25			;
const NrString				LNEMailSvcConfiguration::ms_strDefaultSMTPUserName			= ""			;
const NrString				LNEMailSvcConfiguration::ms_strDefaultSMTPPassword			= ""			;
const NrString				LNEMailSvcConfiguration::ms_strDefaultSMTPFromAddress		= ""			;
const NrString				LNEMailSvcConfiguration::ms_strDefaultSMTPReplyAddress		= ""			;
const NrString				LNEMailSvcConfiguration::ms_strDefaultSMTPCustomText		= "Your message was not filed in one or more of the intended WorkSite(tm) folders.";
const bool					LNEMailSvcConfiguration::ms_bDefaultSMTPIncludeBouncedEmail	= true			;
const long					LNEMailSvcConfiguration::ms_lDefaultSMTPLinesToQuote		= 25			;
const bool					LNEMailSvcConfiguration::ms_bDefaultBounceToAdmin			= false			;
const bool					LNEMailSvcConfiguration::ms_bDefaultAllowFolderNumbers		= true			;
const bool					LNEMailSvcConfiguration::ms_bFromLookup						= false			;
const bool					LNEMailSvcConfiguration::ms_bUseSMTPOpenRelay				= false			;
const long					LNEMailSvcConfiguration::ms_lDaysToRetainDuplicates			= 0				;
const NrString				LNEMailSvcConfiguration::ms_strDefaultProxyServer			= ""			;
const NrString				LNEMailSvcConfiguration::ms_strDefaultProxyPort				= ""			;
const NrString				LNEMailSvcConfiguration::ms_strDefaultExchSrvPort			= "443"			;
const NrString				LNEMailSvcConfiguration::ms_strDefaultAlternateURL			= ""			;

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	LNEMailSvcConfiguration - Default constructor
//
LNEMailSvcConfiguration::LNEMailSvcConfiguration(const TCHAR *szComputerName_) : 
		ServiceConfiguration(szComputerName_, SZ_LNEMAILSVC_PATH, SZ_LNEMAILSVC_NAME)	,
			m_nServerId								(0)											,
			m_nTotalSvrsInCluster					(0)											,
			m_strClass								(ms_strDefaultClass.c_str())				,
			m_strSubClass							(ms_strDefaultSubClass.c_str())				,
			m_strDocType							(ms_strDefaultType.c_str())					,
			m_nThreadPoolSize						(ms_nDefaultThreadPoolSize)					,
			m_nEmailRetrievalCount					(ms_nDefaultEmailRetrievalCount)			,
			m_strMessageClasses						(ms_strDefaultMessageClasses.c_str())		,
			m_nMinutesUntilRetryFiling				(ms_nDefaultMinutesUntilRetryFiling)		,
			m_bEnableSendAndFileAgent				(ms_bDefaultEnableSendAndFileAgent)			,
			m_strDropDirectory						(ms_strDefaultDirectory.c_str())			,
			m_strBadDirectory						(ms_strDefaultDirectory.c_str())			,
			m_lMinutesToBounce						(ms_lDefaultMinutesToBounce)				,
			m_strSMTPServerName						(ms_strDefaultSMTPServerName.c_str())		,
			m_lSMTPServerPort						(ms_lDefaultSMTPServerPort)					,
			m_strSMTPUserName						(ms_strDefaultSMTPUserName.c_str())			,
			m_strSMTPPassword						(ms_strDefaultSMTPPassword.c_str())			,
			m_strSMTPFromAddress					(ms_strDefaultSMTPFromAddress.c_str())		,
			m_strSMTPReplyAddress					(ms_strDefaultSMTPReplyAddress.c_str())		,
			m_strSMTPCustomText						(ms_strDefaultSMTPCustomText.c_str())		,
			m_bSMTPIncludeBouncedEmail				(ms_bDefaultSMTPIncludeBouncedEmail)		,
			m_lSMTPLinesToQuote						(ms_lDefaultSMTPLinesToQuote)				,
			m_bBounceToAdmin						(ms_bDefaultBounceToAdmin)					,
			m_bAllowFolderNumbers					(ms_bDefaultAllowFolderNumbers)				,
			m_bFromLookup							(ms_bFromLookup)							,
			m_bUseSMTPOpenRelay						(ms_bUseSMTPOpenRelay)						,
			m_lDaysToRetainDuplicates				(ms_lDaysToRetainDuplicates)				,
			m_strExchSrvPort						(ms_strDefaultExchSrvPort.c_str())			,
			m_strProxyServer						(ms_strDefaultProxyServer.c_str())			,
			m_strProxyPort							(ms_strDefaultProxyPort.c_str())			,
			m_strAlternateAutodiscoverURL			(ms_strDefaultAlternateURL.c_str())

{
	m_strServiceName			= SZ_LNEMAILSVC_NAME;
	m_strServiceDisplayName		= SZ_LNEMAILSVC_DISPLAY_NAME;
	m_strServiceScmName			= SZ_LNEMAILSVC_SCM_NAME;
	m_strServiceScmDesc			= SZ_LNEMAILSVC_DESC;

	m_strStoreAdminSMTPAddress.SetEncryptFlag(true);
	m_strStoreAdminPassword.SetEncryptFlag(true);
	m_strSMTPPassword.SetEncryptFlag(true);

	m_strTargetDirectory = NrString(GetTempFilePath().toAnsi().c_str()).c_str();
	m_propertyMap.insert(PropertyMap::value_type(KEY_STORE_ADMIN_SMTP_ADDRESS,		&m_strStoreAdminSMTPAddress));
	m_propertyMap.insert(PropertyMap::value_type(KEY_STORE_ADMIN_PASSWORD,			&m_strStoreAdminPassword));
	m_propertyMap.insert(PropertyMap::value_type(KEY_PROXY_SERVER,					&m_strProxyServer));
	m_propertyMap.insert(PropertyMap::value_type(KEY_PROXY_SERVER_PORT,				&m_strProxyPort));
	m_propertyMap.insert(PropertyMap::value_type(KEY_EXCHANGE_SERVER_PORT,			&m_strExchSrvPort));
	m_propertyMap.insert(PropertyMap::value_type(KEY_CLUSTER_NAME,					&m_strClusterName));
	m_propertyMap.insert(PropertyMap::value_type(KEY_FMA_PORT,						&m_nFmaPort));
	m_propertyMap.insert(PropertyMap::value_type(KEY_CLASS,							&m_strClass));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SUBCLASS,						&m_strSubClass));
	m_propertyMap.insert(PropertyMap::value_type(KEY_TYPE,							&m_strDocType));
	m_propertyMap.insert(PropertyMap::value_type(KEY_THREAD_POOL_SIZE,				&m_nThreadPoolSize));
	m_propertyMap.insert(PropertyMap::value_type(KEY_EMAIL_RETRIEVAL_COUNT,			&m_nEmailRetrievalCount));
	m_propertyMap.insert(PropertyMap::value_type(KEY_MESSAGE_CLASSES,				&m_strMessageClasses));
	m_propertyMap.insert(PropertyMap::value_type(KEY_MINUTES_UNTIL_RETRY_FILING,	&m_nMinutesUntilRetryFiling));
	m_propertyMap.insert(PropertyMap::value_type(KEY_ENABLE_SEND_AND_FILE_AGENT,	&m_bEnableSendAndFileAgent));
	m_propertyMap.insert(PropertyMap::value_type(KEY_TARGET_DIRECTORY,				&m_strTargetDirectory));
	m_propertyMap.insert(PropertyMap::value_type(KEY_DROP_DIRECTORY,				&m_strDropDirectory));
	m_propertyMap.insert(PropertyMap::value_type(KEY_BAD_MAIL_DIRECTORY,			&m_strBadDirectory));
	m_propertyMap.insert(PropertyMap::value_type(KEY_MINUTES_TO_BOUNCE,				&m_lMinutesToBounce));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SMTP_SERVERNAME,				&m_strSMTPServerName));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SMTP_SERVERPORT,				&m_lSMTPServerPort));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SMTP_USERNAME,					&m_strSMTPUserName));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SMTP_PASSWORD,					&m_strSMTPPassword));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SMTP_FROM_ADDRESS,				&m_strSMTPFromAddress));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SMTP_REPLY_TO_ADDRESS,			&m_strSMTPReplyAddress));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SMTP_CUSTOM,					&m_strSMTPCustomText));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SMTP_INCLUDE_BOUNCED,			&m_bSMTPIncludeBouncedEmail));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SMTP_LINES_TO_QUOTE,			&m_lSMTPLinesToQuote));
	m_propertyMap.insert(PropertyMap::value_type(KEY_BOUNCETOADMIN,					&m_bBounceToAdmin));
	m_propertyMap.insert(PropertyMap::value_type(KEY_ALLOWFOLDERNUMBERS,			&m_bAllowFolderNumbers));
	m_propertyMap.insert(PropertyMap::value_type(KEY_FROMLOOKUP,					&m_bFromLookup));
	m_propertyMap.insert(PropertyMap::value_type(KEY_USESMTPOPENRELAY,				&m_bUseSMTPOpenRelay));
	m_propertyMap.insert(PropertyMap::value_type(KEY_DAYSTORETAINDUPLICATES,		&m_lDaysToRetainDuplicates));
	m_propertyMap.insert(PropertyMap::value_type(KEY_ALTERNATE_AUTODISCOVER_URL,	&m_strAlternateAutodiscoverURL));
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	LNEMailSvcConfiguration - Destructor
//
LNEMailSvcConfiguration::~LNEMailSvcConfiguration()
{
	m_DomainNames.clear();
	m_Databases.clear();
}


//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	LoadFromRegistry
//
void LNEMailSvcConfiguration::LoadFromRegistry()
{
	ServiceConfiguration::LoadFromRegistry();

	if (m_lMinutesToBounce.Get() < 1)
	{
		m_lMinutesToBounce.Set(1L);
	}

	m_DomainNames.clear();
	m_Databases.clear();

	NrString		strDomainKeyPath = SZ_LNEMAILSVC_PATH;
	strDomainKeyPath += TEXT("\\");
	strDomainKeyPath += ms_strDomainsSubkey.c_str();

	Registry		domainReg(m_strComputerName.c_str(), HKEY_LOCAL_MACHINE, strDomainKeyPath.c_str());
	NrString		strDomainName;

	if (domainReg.OpenOrCreate(NULL, KEY_ALL_ACCESS) != true)
	{
		throw_error(GetLastError(), _T("Could not open/create Registry key for domain information"));
	}

	while (domainReg.EnumerateKey(strDomainName) == true)
	{
		m_DomainNames.push_back(strDomainName);
	}

	// Get the database entries
	NrString		strDatabaseKeyPath = SZ_LNEMAILSVC_PATH;
	strDatabaseKeyPath += TEXT("\\");
	strDatabaseKeyPath += ms_strDatabasesSubkey;

	Registry		dbReg(m_strComputerName.c_str(), HKEY_LOCAL_MACHINE, strDatabaseKeyPath.c_str());
	NrString		strDatabaseName;

	if (dbReg.OpenOrCreate(NULL, KEY_ALL_ACCESS) != true)
	{
		throw_error(GetLastError(), _T("Could not open/create Registry key for database information"));
	}

	while (dbReg.EnumerateKey(strDatabaseName) == true)
	{
		// each database has a list of DMS entries; get those
		NrString strServerKeyPath = strDatabaseKeyPath;
		strServerKeyPath += TEXT("\\");
		strServerKeyPath += strDatabaseName;
		strServerKeyPath += TEXT("\\");	
		strServerKeyPath += EmsDatabaseEntry::ms_strServersSubkey.c_str();

		Registry		svrReg(m_strComputerName.c_str(), HKEY_LOCAL_MACHINE, strServerKeyPath.c_str());
		NrString		strServerName;

		// open registry to enumerate the configured servers
		if (svrReg.OpenOrCreate(NULL, KEY_ALL_ACCESS) != true)
		{
			throw_error(GetLastError(), _T("Could not open/create Registry key for server information"));
		}

		EmsDatabaseEntry dbEntry(m_strComputerName.c_str(), strDatabaseKeyPath.c_str(), strDatabaseName.c_str());
		dbEntry.LoadFromRegistry();

		while (svrReg.EnumerateKey(strServerName) == true)
		{
			ServerEntry svrEntry(m_strComputerName.c_str(), strServerKeyPath.c_str(), strServerName.c_str());
			svrEntry.LoadFromRegistry();

			dbEntry.m_Servers.push_back(svrEntry);
		}

		m_Databases.push_back(dbEntry);
	}
}


void LNEMailSvcConfiguration::AddDatabaseToRegistry(NrString& strDatabaseName_)
{
	RemoveDatabaseFromRegistry(strDatabaseName_);

	NrString strDatabaseKeyPath = SZ_LNEMAILSVC_PATH;
	strDatabaseKeyPath += TEXT("\\");
	strDatabaseKeyPath += ms_strDatabasesSubkey.c_str();

	EmsDatabaseEntry dbEntry(m_strComputerName.c_str(), strDatabaseKeyPath.c_str(), strDatabaseName_.c_str());

	dbEntry.StoreInRegistry();

	LoadFromRegistry();
}

void LNEMailSvcConfiguration::AddDatabaseToRegistry(	NrString&	strDatabaseName_,
													NrString&	strServerName_,
													bool		bSpecifyPort_,
													long		lPort_,
													NrString&	strUsername_,
													NrString&	strPassword_,
													long		lMaxFolderList_)
{
	LoadFromRegistry();

	RemoveDatabaseFromRegistry(strDatabaseName_);

	NrString strDatabaseKeyPath = SZ_LNEMAILSVC_PATH;
	strDatabaseKeyPath += TEXT("\\");
	strDatabaseKeyPath += ms_strDatabasesSubkey.c_str();

	EmsDatabaseEntry dbEntry(m_strComputerName.c_str(), strDatabaseKeyPath.c_str(), strDatabaseName_.c_str());

	dbEntry.StoreInRegistry();

	dbEntry.AddServerToRegistry(strServerName_, bSpecifyPort_, lPort_, strUsername_, strPassword_, lMaxFolderList_);

	LoadFromRegistry();
}


void LNEMailSvcConfiguration::RemoveDatabaseFromRegistry(NrString& strDatabaseName_)
{
	LoadFromRegistry();

	imstd::vector<EmsDatabaseEntry>::iterator	it = m_Databases.begin();
	for ( ; it != m_Databases.end(); it++)
	{
		if (it->m_strDatabaseName.Get() == strDatabaseName_)
		{
			it->RemoveFromRegistry();
		}
	}

	LoadFromRegistry();
}

void LNEMailSvcConfiguration::GetExchangeCredentials(NrUnicodeString* _Credentials)
{

	NrString sCredentials = "";
	sCredentials += m_strStoreAdminSMTPAddress.Get();
	sCredentials += _T(":");
	sCredentials += m_strStoreAdminPassword.Get();
	*_Credentials = sCredentials.toBase64().toUnicode().c_str();
	return;

	/*BYTE* pbData =  NULL; 
	int nRequiredLen = Base64EncodeGetRequiredLength(sCredentials.length()) + 1;
	if (0 < nRequiredLen)
	{
		pbData = im_new BYTE[nRequiredLen];
		if (NULL != pbData)
		{
			memset(pbData, 0, nRequiredLen);
			memcpy_s(pbData, nRequiredLen, sCredentials.c_str(), sCredentials.length());

			char* sEncodedData = NULL; int nEncodedLen;
			if (Base64Encode(pbData, sCredentials.length(), sEncodedData, &nEncodedLen) && (NULL != sEncodedData))
			{
				sCredentials = sEncodedData;
				delete[] sEncodedData; sEncodedData = NULL;
			}
			delete[] pbData; pbData = NULL;
		}
	}
	return sCredentials;*/
}

void LNEMailSvcConfiguration::AddDomainToRegistry(NrString& strDomainName_)
{
	RemoveDomainFromRegistry(strDomainName_);

	NrString strDomainKeyPath = SZ_LNEMAILSVC_PATH;
	strDomainKeyPath += TEXT("\\");
	strDomainKeyPath += ms_strDomainsSubkey.c_str();
	strDomainKeyPath += TEXT("\\");

	Registry domainReg(m_strComputerName.c_str(), HKEY_LOCAL_MACHINE, strDomainKeyPath.c_str());

	domainReg.OpenOrCreate(strDomainName_.c_str(), KEY_ALL_ACCESS);
	domainReg.Close();

	LoadFromRegistry();
}


void LNEMailSvcConfiguration::RemoveDomainFromRegistry(NrString& strDomainName_)
{
	NrString strDomainKeyPath = SZ_LNEMAILSVC_PATH;
	strDomainKeyPath += TEXT("\\");
	strDomainKeyPath += ms_strDomainsSubkey.c_str();

	Registry domainReg(m_strComputerName.c_str(), HKEY_LOCAL_MACHINE, strDomainKeyPath.c_str());

	domainReg.Open(NULL, KEY_ALL_ACCESS);
	domainReg.DeleteSubKey(strDomainName_.c_str());
	domainReg.Close();

	LoadFromRegistry();
}

NrUnicodeString LNEMailSvcConfiguration::GetTempFilePath()
{
	NrUnicodeString sTempPath = L"";

	try
	{
		wchar_t szTempPath[MAX_PATH] = {L"\0"};
		if	(GetTempPathW(MAX_PATH, szTempPath))
		{			
			sTempPath = szTempPath;
			if (L'\\' != sTempPath.at(sTempPath.length() - 1))
			{
				sTempPath += L"\\";
			}

			sTempPath += L"LNWCS\\";

			if (!PathFileExistsW(sTempPath.c_str()))
			{
				CreateDirectoryW(sTempPath.c_str(), NULL);
			}
		}
	}
	catch(...)
	{}

	return sTempPath;
}
