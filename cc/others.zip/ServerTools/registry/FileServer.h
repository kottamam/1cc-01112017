#ifndef __REG_FILE_SERVER_H__
#define __REG_FILE_SERVER_H__


namespace IM
{

	class FileServerConfiguration : public RegistryMap
{
public:
	IM::RegistryBooleanProperty		m_bUseServiceAccount;
	IM::RegistryStringProperty		m_strNtLogonID;
	IM::RegistryStringProperty		m_strNtPassword;

	IM::RegistryBooleanProperty		m_bIsBinderyConnection;
	IM::RegistryStringProperty		m_strNwUserContext;
	IM::RegistryStringProperty		m_strNwLogonID;
	IM::RegistryStringProperty		m_strNwPassword;


					FileServerConfiguration(const _TCHAR *szComputerName_);
	virtual			~FileServerConfiguration()	{}
};

}; // namespace IM

#endif __REG_FILE_SERVER_H__
