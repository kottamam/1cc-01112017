////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// File:	EMSServiceConfiguration.cpp
//
// Project: Email Management System		Subsystem: Email Filing Service
//
// Contents:	Implements the registry configuration information for the EMS service.
//
//   Date    Who  Modification
// 12/11/02  GAH  Initial coding.
//
// Copyright (C) 2002, iManage Technologies, Inc. ALL RIGHTS RESERVED
//                     PROPRIETARY AND CONFIDENTIAL
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include <RegistryLib.h>
#include <EMSServiceConfiguration.h>

#pragma hdrstop

using namespace IM;

#define KEY_TARGET_DIRECTORY		TEXT("Target Directory")
#define KEY_DROP_DIRECTORY			TEXT("Drop Directory")
#define KEY_BAD_MAIL_DIRECTORY		TEXT("Bad Directory")
#define KEY_CLASS					TEXT("Class")
#define KEY_SUBCLASS				TEXT("SubClass")
#define KEY_TYPE					TEXT("Type")
#define KEY_MINUTES_TO_BOUNCE		TEXT("Minutes Until Bounce")
#define KEY_SMTP_SERVERNAME			TEXT("SMTP Server Name")
#define KEY_SMTP_SERVERPORT			TEXT("SMTP Server Port")
#define KEY_SMTP_USERNAME			TEXT("SMTP Username")
#define KEY_SMTP_PASSWORD			TEXT("SMTP Password")
#define KEY_SMTP_FROM_ADDRESS		TEXT("SMTP From Address")
#define KEY_SMTP_REPLY_TO_ADDRESS	TEXT("SMTP Reply-To Address")
#define KEY_SMTP_CUSTOM				TEXT("SMTP Custom Bounce Message Text")
#define KEY_SMTP_INCLUDE_BOUNCED	TEXT("SMTP Include Original Email in Bounce")
#define KEY_SMTP_LINES_TO_QUOTE		TEXT("SMTP Lines To Quote")
#define KEY_SPECIFYOUTLOOK			TEXT("Specify Outlook Settings")
#define KEY_OUTLOOKPROFILE			TEXT("Outlook Profile Name")
#define KEY_OUTLOOKPASSWORD			TEXT("Outlook Password")
#define KEY_BOUNCETOADMIN			TEXT("Bounce Only To Administrator")
#define KEY_ALLOWFOLDERNUMBERS		TEXT("Allow Folder Numbers in Addresses")
#define KEY_FROMLOOKUP				TEXT("From Address Username Access Lookup")
#define KEY_USESMTPOPENRELAY		TEXT("Use SMTP Open Relay")
#define KEY_MAXWAITFORTERMINATION	TEXT("Max Wait For Termination")

#define KEY_DAYSTORETAINDUPLICATES	TEXT("Days To Retain Duplicates")
#define KEY_DUP_DETECT_COLUMN		TEXT("Duplicate Detection Additional Column")

const NrString	EMSServiceConfiguration::ms_strDefaultDomain				= "";
const NrString	EMSServiceConfiguration::ms_strDefaultDirectory				= "";
const NrString	EMSServiceConfiguration::ms_strDefaultClass					= "E-MAIL";
const NrString	EMSServiceConfiguration::ms_strDefaultSubClass				= "";
const NrString	EMSServiceConfiguration::ms_strDefaultType					= "MIME";
const long		EMSServiceConfiguration::ms_lDefaultMinutesToBounce			= 30;
const bool		EMSServiceConfiguration::ms_bDefaultSpecifyOutlookSettings	= false;
const NrString	EMSServiceConfiguration::ms_strDefaultOutlookProfile		= "";
const NrString	EMSServiceConfiguration::ms_strDefaultOutlookPassword		= "";

const NrString	EMSServiceConfiguration::ms_strDefaultSMTPServerName		= "";
const long		EMSServiceConfiguration::ms_lDefaultSMTPServerPort			= 25;
const NrString	EMSServiceConfiguration::ms_strDefaultSMTPUserName			= "";
const NrString	EMSServiceConfiguration::ms_strDefaultSMTPPassword			= "";
const NrString	EMSServiceConfiguration::ms_strDefaultSMTPFromAddress		= "";
const NrString	EMSServiceConfiguration::ms_strDefaultSMTPReplyAddress		= "";
const NrString	EMSServiceConfiguration::ms_strDefaultSMTPCustomText		= "Your message was not filed in one or more of the intended WorkSite(tm) folders.";
const bool		EMSServiceConfiguration::ms_bDefaultSMTPIncludeBouncedEmail	= true;
const long		EMSServiceConfiguration::ms_lDefaultSMTPLinesToQuote		= 25;


const NrString	EMSServiceConfiguration::ms_strDomainsSubkey				= "Domains";
const NrString	EMSServiceConfiguration::ms_strDatabasesSubkey				= "Databases";

const bool		EMSServiceConfiguration::ms_bDefaultBounceToAdmin			= false;
const bool		EMSServiceConfiguration::ms_bDefaultAllowFolderNumbers		= false;

const bool		EMSServiceConfiguration::ms_bFromLookup						= false;

const bool		EMSServiceConfiguration::ms_bUseSMTPOpenRelay				= false;

const long		EMSServiceConfiguration::ms_lmsMaxWaitForTermination		= 300 * 1000;

const long		EMSServiceConfiguration::ms_lDaysToRetainDuplicates			= 0;
const long		EMSServiceConfiguration::ms_lDupDetectAdditionalColumn		= -1;

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	EMSServiceConfiguration - Default constructor
//
EMSServiceConfiguration::EMSServiceConfiguration(const TCHAR *szComputerName_) :
	ServiceConfiguration(szComputerName_, KEY_EMSSVC_PATH, SZ_EMSSVC_NAME),
			m_strTargetDirectory(ms_strDefaultDirectory.c_str()),
			m_strDropDirectory(ms_strDefaultDirectory.c_str()),
			m_strBadDirectory(ms_strDefaultDirectory.c_str()),
			m_strClass(ms_strDefaultClass.c_str()),
			m_strSubClass(ms_strDefaultSubClass.c_str()),
			m_strType(ms_strDefaultType.c_str()),
			m_lMinutesToBounce(ms_lDefaultMinutesToBounce),
			m_strSMTPServerName(ms_strDefaultSMTPServerName.c_str()),
			m_lSMTPServerPort(ms_lDefaultSMTPServerPort),
			m_strSMTPUserName(ms_strDefaultSMTPUserName.c_str()),
			m_strSMTPPassword(ms_strDefaultSMTPPassword.c_str()),
			m_strSMTPFromAddress(ms_strDefaultSMTPFromAddress.c_str()),
			m_strSMTPReplyAddress(ms_strDefaultSMTPReplyAddress.c_str()),
			m_strSMTPCustomText(ms_strDefaultSMTPCustomText.c_str()),
			m_bSMTPIncludeBouncedEmail(ms_bDefaultSMTPIncludeBouncedEmail),
			m_lSMTPLinesToQuote(ms_lDefaultSMTPLinesToQuote),
			m_bSpecifyOutlookSettings(ms_bDefaultSpecifyOutlookSettings),
			m_strOutlookProfile(ms_strDefaultOutlookProfile.c_str()),
			m_strOutlookPassword(ms_strDefaultOutlookPassword.c_str()),
			m_bBounceToAdmin(ms_bDefaultBounceToAdmin),
			m_bAllowFolderNumbers(ms_bDefaultAllowFolderNumbers),
			m_bFromLookup(ms_bFromLookup),
			m_bUseSMTPOpenRelay(ms_bUseSMTPOpenRelay),
			m_lmsMaxWaitForTermination(ms_lmsMaxWaitForTermination),
			m_lDaysToRetainDuplicates(ms_lDaysToRetainDuplicates),
			m_lDupDetectAdditionalColumn(ms_lDupDetectAdditionalColumn)
{
	m_strServiceDisplayName = SZ_EMSSVC_DISPLAY_NAME;
	m_strServiceScmName = SZ_EMSSVC_SCM_NAME;

	m_strSMTPUserName.SetEncryptFlag(true);
	m_strSMTPPassword.SetEncryptFlag(true);
	m_lLogMask.Set(LFO_ERROR | LFO_WARN | LFO_INFO | LFO_HEADER | LOG_ALL_DATA);

	TCHAR tempDir[MAX_PATH];
	(void) ::GetTempPath(sizeof(tempDir)/sizeof(TCHAR), tempDir);
	m_strTargetDirectory = tempDir;

	m_propertyMap.insert(PropertyMap::value_type(KEY_TARGET_DIRECTORY,		&m_strTargetDirectory));
	m_propertyMap.insert(PropertyMap::value_type(KEY_DROP_DIRECTORY,		&m_strDropDirectory));
	m_propertyMap.insert(PropertyMap::value_type(KEY_BAD_MAIL_DIRECTORY,	&m_strBadDirectory));
	m_propertyMap.insert(PropertyMap::value_type(KEY_CLASS,					&m_strClass));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SUBCLASS,				&m_strSubClass));
	m_propertyMap.insert(PropertyMap::value_type(KEY_TYPE,					&m_strType));
	m_propertyMap.insert(PropertyMap::value_type(KEY_MINUTES_TO_BOUNCE,		&m_lMinutesToBounce));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SMTP_SERVERNAME,		&m_strSMTPServerName));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SMTP_SERVERPORT,		&m_lSMTPServerPort));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SMTP_USERNAME,			&m_strSMTPUserName));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SMTP_PASSWORD,			&m_strSMTPPassword));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SMTP_FROM_ADDRESS,		&m_strSMTPFromAddress));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SMTP_REPLY_TO_ADDRESS,	&m_strSMTPReplyAddress));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SMTP_CUSTOM,			&m_strSMTPCustomText));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SMTP_INCLUDE_BOUNCED,	&m_bSMTPIncludeBouncedEmail));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SMTP_LINES_TO_QUOTE,	&m_lSMTPLinesToQuote));
	m_propertyMap.insert(PropertyMap::value_type(KEY_SPECIFYOUTLOOK,		&m_bSpecifyOutlookSettings));
	m_propertyMap.insert(PropertyMap::value_type(KEY_OUTLOOKPROFILE,		&m_strOutlookProfile));
	m_propertyMap.insert(PropertyMap::value_type(KEY_OUTLOOKPASSWORD,		&m_strOutlookPassword));
	m_propertyMap.insert(PropertyMap::value_type(KEY_BOUNCETOADMIN,			&m_bBounceToAdmin));
	m_propertyMap.insert(PropertyMap::value_type(KEY_ALLOWFOLDERNUMBERS,	&m_bAllowFolderNumbers));
	m_propertyMap.insert(PropertyMap::value_type(KEY_FROMLOOKUP,			&m_bFromLookup));
	m_propertyMap.insert(PropertyMap::value_type(KEY_USESMTPOPENRELAY,		&m_bUseSMTPOpenRelay));
	m_propertyMap.insert(PropertyMap::value_type(KEY_MAXWAITFORTERMINATION,	&m_lmsMaxWaitForTermination));
	m_propertyMap.insert(PropertyMap::value_type(KEY_DAYSTORETAINDUPLICATES,&m_lDaysToRetainDuplicates));
	m_propertyMap.insert(PropertyMap::value_type(KEY_DUP_DETECT_COLUMN,		&m_lDupDetectAdditionalColumn));
}


//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	EMSServiceConfiguration - Destructor
//
	EMSServiceConfiguration::~EMSServiceConfiguration()
{
	m_DomainNames.clear();
	m_Databases.clear();
}


//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	LoadFromRegistry
//
void
	EMSServiceConfiguration::LoadFromRegistry()
{
	ServiceConfiguration::LoadFromRegistry();

	if (m_lMinutesToBounce.Get() < 1)
		m_lMinutesToBounce.Set(1L);

	m_DomainNames.clear();
	m_Databases.clear();

	// open registry to get the domain names
	NrString		strDomainKeyPath = KEY_EMSSVC_PATH;
	strDomainKeyPath += TEXT("\\");
	strDomainKeyPath += ms_strDomainsSubkey.c_str();

	Registry		domainReg(m_strComputerName.c_str(), HKEY_LOCAL_MACHINE, strDomainKeyPath.c_str());
	NrString		strDomainName;

	if (domainReg.OpenOrCreate(NULL, KEY_ALL_ACCESS) != true)
	{
		throw_error(GetLastError(), _T("Could not open/create Registry key for domain information"));
	}

	while (domainReg.EnumerateKey(strDomainName) == true)
	{
		m_DomainNames.push_back(strDomainName);
	}

	// Get the database entries
	NrString		strDatabaseKeyPath = KEY_EMSSVC_PATH;
	strDatabaseKeyPath += TEXT("\\");
	strDatabaseKeyPath += ms_strDatabasesSubkey.c_str();

	Registry		dbReg(m_strComputerName.c_str(), HKEY_LOCAL_MACHINE, strDatabaseKeyPath.c_str());
	NrString		strDatabaseName;

	if (dbReg.OpenOrCreate(NULL, KEY_ALL_ACCESS) != true)
	{
		throw_error(GetLastError(), _T("Could not open/create Registry key for database information"));
	}

	while (dbReg.EnumerateKey(strDatabaseName) == true)
	{
		// each database has a list of DMS entries; get those
		NrString strServerKeyPath = strDatabaseKeyPath;
		strServerKeyPath += TEXT("\\");
		strServerKeyPath += strDatabaseName;
		strServerKeyPath += TEXT("\\");	
		strServerKeyPath += EmsDatabaseEntry::ms_strServersSubkey.c_str();

		Registry		svrReg(m_strComputerName.c_str(), HKEY_LOCAL_MACHINE, strServerKeyPath.c_str());
		NrString		strServerName;


		// open registry to enumerate the configured servers
		if (svrReg.OpenOrCreate(NULL, KEY_ALL_ACCESS) != true)
		{
			throw_error(GetLastError(), _T("Could not open/create Registry key for server information"));
		}

		EmsDatabaseEntry dbEntry(m_strComputerName.c_str(), strDatabaseKeyPath.c_str(), strDatabaseName.c_str());
		dbEntry.LoadFromRegistry();

		while (svrReg.EnumerateKey(strServerName) == true)
		{
			ServerEntry svrEntry(m_strComputerName.c_str(), strServerKeyPath.c_str(), strServerName.c_str());
			svrEntry.LoadFromRegistry();

			dbEntry.m_Servers.push_back(svrEntry);
		}

		m_Databases.push_back(dbEntry);
	}
}


void
	EMSServiceConfiguration::AddDatabaseToRegistry(NrString& strDatabaseName_)
{
	RemoveDatabaseFromRegistry(strDatabaseName_);

	NrString strDatabaseKeyPath = KEY_EMSSVC_PATH;
	strDatabaseKeyPath += TEXT("\\");
	strDatabaseKeyPath += ms_strDatabasesSubkey.c_str();

	EmsDatabaseEntry dbEntry(m_strComputerName.c_str(), strDatabaseKeyPath.c_str(), strDatabaseName_.c_str());

	dbEntry.StoreInRegistry();

	LoadFromRegistry();
}

void
	EMSServiceConfiguration::AddDatabaseToRegistry(	NrString&	strDatabaseName_,
													NrString&	strServerName_,
													bool		bSpecifyPort_,
													long		lPort_,
													NrString&	strUsername_,
													NrString&	strPassword_,
													long		lMaxFolderList_)
{
	LoadFromRegistry();

	RemoveDatabaseFromRegistry(strDatabaseName_);

	NrString strDatabaseKeyPath = KEY_EMSSVC_PATH;
	strDatabaseKeyPath += TEXT("\\");
	strDatabaseKeyPath += ms_strDatabasesSubkey.c_str();

	EmsDatabaseEntry dbEntry(m_strComputerName.c_str(), strDatabaseKeyPath.c_str(), strDatabaseName_.c_str());

	dbEntry.StoreInRegistry();

	dbEntry.AddServerToRegistry(strServerName_, bSpecifyPort_, lPort_, strUsername_, strPassword_, lMaxFolderList_);

	LoadFromRegistry();
}


void
	EMSServiceConfiguration::RemoveDatabaseFromRegistry(NrString& strDatabaseName_)
{
	LoadFromRegistry();

	for (imstd::vector<EmsDatabaseEntry>::iterator	it = m_Databases.begin();
												it != m_Databases.end();
												it++)
		if (it->m_strDatabaseName.Get() == strDatabaseName_)
			it->RemoveFromRegistry();

	LoadFromRegistry();
}


void
	EMSServiceConfiguration::AddDomainToRegistry(NrString& strDomainName_)
{
	RemoveDomainFromRegistry(strDomainName_);

	NrString strDomainKeyPath = KEY_EMSSVC_PATH;
	strDomainKeyPath += TEXT("\\");
	strDomainKeyPath += ms_strDomainsSubkey.c_str();
	strDomainKeyPath += TEXT("\\");

	Registry domainReg(m_strComputerName.c_str(), HKEY_LOCAL_MACHINE, strDomainKeyPath.c_str());

	domainReg.OpenOrCreate(strDomainName_.c_str(), KEY_ALL_ACCESS);
	domainReg.Close();

	LoadFromRegistry();
}


void
	EMSServiceConfiguration::RemoveDomainFromRegistry(NrString& strDomainName_)
{
	NrString strDomainKeyPath = KEY_EMSSVC_PATH;
	strDomainKeyPath += TEXT("\\");
	strDomainKeyPath += ms_strDomainsSubkey.c_str();

	Registry domainReg(m_strComputerName.c_str(), HKEY_LOCAL_MACHINE, strDomainKeyPath.c_str());

	domainReg.Open(NULL, KEY_ALL_ACCESS);
	domainReg.DeleteSubKey(strDomainName_.c_str());
	domainReg.Close();

	LoadFromRegistry();
}
