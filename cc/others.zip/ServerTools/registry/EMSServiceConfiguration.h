////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// File:	EMSServiceConfiguration.h
//
// Project: Email Management System		Subsystem: Email Filing Service
//
// Contents:	Implements the registry configuration information for the EMS service.
//
//   Date    Who  Modification
// 12/11/02  GAH  Initial coding.
//
// Copyright (C) 2002, iManage Technologies, Inc. ALL RIGHTS RESERVED
//                     PROPRIETARY AND CONFIDENTIAL
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma once

#if !defined(__IM_EMSSERVICECONFIGURATION_H__)
	#define __IM_EMSSERVICECONFIGURATION_H__

	#include <registry/Service.h>
	#include <registry/ServerEntry.h>

	namespace IM
	{
		class EMSServiceConfiguration : public IM::ServiceConfiguration
		{
		public:
			//
			// Constructors, destructors and initializers.
			//
					EMSServiceConfiguration(const TCHAR *szComputerName_);
			virtual	~EMSServiceConfiguration();

		public:
			//
			// ServiceConfiguration
			//
			virtual void	LoadFromRegistry();
			void			AddDatabaseToRegistry(NrString& strDatabaseName_);
			void			AddDatabaseToRegistry(	NrString&	strDatabaseName_,
													NrString&	strServerName_,
													bool		bSpecifyPort_,
													long		lPort_,
													NrString&	strUsername_,
													NrString&	strPassword_,
													long		lMaxFolderList_);
			void			RemoveDatabaseFromRegistry(NrString& strDatabaseName_);
			void			AddDomainToRegistry(NrString& strDomainName_);
			void			RemoveDomainFromRegistry(NrString& strDomainName_);

			imstd::vector<NrString> m_DomainNames;
			imstd::vector<EmsDatabaseEntry> m_Databases;

			IM::RegistryStringProperty	m_strTargetDirectory;
			IM::RegistryStringProperty	m_strDropDirectory;
			IM::RegistryStringProperty	m_strBadDirectory;
			IM::RegistryStringProperty	m_strClass;
			IM::RegistryStringProperty	m_strSubClass;
			IM::RegistryStringProperty	m_strType;
			IM::RegistryLongProperty	m_lMinutesToBounce;
			IM::RegistryStringProperty	m_strSMTPServerName;
			IM::RegistryLongProperty	m_lSMTPServerPort;
			IM::RegistryStringProperty	m_strSMTPUserName;
			IM::RegistryStringProperty	m_strSMTPPassword;
			IM::RegistryStringProperty	m_strSMTPFromAddress;
			IM::RegistryStringProperty	m_strSMTPReplyAddress;
			IM::RegistryStringProperty	m_strSMTPCustomText;
			IM::RegistryBooleanProperty	m_bSMTPIncludeBouncedEmail;
			IM::RegistryLongProperty	m_lSMTPLinesToQuote;
			IM::RegistryBooleanProperty	m_bSpecifyOutlookSettings;
			IM::RegistryStringProperty	m_strOutlookProfile;
			IM::RegistryStringProperty	m_strOutlookPassword;
			IM::RegistryBooleanProperty	m_bBounceToAdmin;
			IM::RegistryBooleanProperty	m_bAllowFolderNumbers;
			IM::RegistryBooleanProperty	m_bFromLookup;
			IM::RegistryBooleanProperty	m_bUseSMTPOpenRelay;
			IM::RegistryLongProperty	m_lmsMaxWaitForTermination;
			IM::RegistryLongProperty	m_lDaysToRetainDuplicates;
			IM::RegistryLongProperty	m_lDupDetectAdditionalColumn;


			static const NrString	ms_strDefaultDomain;
			static const NrString	ms_strDefaultDirectory;
			static const NrString	ms_strDefaultClass;
			static const NrString	ms_strDefaultSubClass;
			static const NrString	ms_strDefaultType;
			static const long		ms_lDefaultMinutesToBounce;
			static const NrString	ms_strDefaultSMTPServerName;
			static const long		ms_lDefaultSMTPServerPort;
			static const NrString	ms_strDefaultSMTPUserName;
			static const NrString	ms_strDefaultSMTPPassword;
			static const NrString	ms_strDefaultSMTPFromAddress;
			static const NrString	ms_strDefaultSMTPReplyAddress;
			static const NrString	ms_strDefaultSMTPCustomText;
			static const bool		ms_bDefaultSMTPIncludeBouncedEmail;
			static const long		ms_lDefaultSMTPLinesToQuote;
			static const bool		ms_bDefaultSpecifyOutlookSettings;
			static const NrString	ms_strDefaultOutlookProfile;
			static const NrString	ms_strDefaultOutlookPassword;

			static const NrString	ms_strDomainsSubkey;
			static const NrString	ms_strDatabasesSubkey;
			static const bool		ms_bDefaultBounceToAdmin;
			static const bool		ms_bDefaultAllowFolderNumbers;
			static const bool		ms_bFromLookup;
			static const bool		ms_bUseSMTPOpenRelay;

			static const long		ms_lmsMaxWaitForTermination;
			static const long		ms_lDaysToRetainDuplicates;
			static const long		ms_lDupDetectAdditionalColumn;
		};

	};	// namespace IM

#endif	// __IM_EMSSERVICECONFIGURATION_H__

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
