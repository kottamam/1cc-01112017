////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// File:	EMailSvcConfiguration.h
//
// Project: Email Management System		Subsystem: Email Filing Service
//
// Contents:	Implements the registry configuration information for the EmailOnline service.
//
//   Date    Who  Modification
// 08/15/12  Vinod  Initial coding.
//
// Copyright (C) 2002, iManage Technologies, Inc. ALL RIGHTS RESERVED
//                     PROPRIETARY AND CONFIDENTIAL
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma once

#if !defined(__IM_EMAILSVCCONFIGURATION_H__)
	#define __IM_EMAILSVCCONFIGURATION_H__

	#include <registry/Service.h>
	#include <registry/ServerEntry.h>
	#include <boost/filesystem.hpp>
	#include <boost/filesystem/fstream.hpp>
	#include <set>

	namespace IM
	{
		class EMailSvcConfiguration : public IM::ServiceConfiguration
		{
		public:
			//
			// Constructors, destructors and initializers.
			//
					EMailSvcConfiguration(const TCHAR *szComputerName_);
			virtual	~EMailSvcConfiguration();

		public:
			//
			// ServiceConfiguration
			//
			virtual void	LoadFromRegistry();
			
			void			AddDatabaseToRegistry(NrString& strDatabaseName_);
			
			void			AddDatabaseToRegistry(	NrString&	strDatabaseName_	,
													NrString&	strServerName_		,
													bool		bSpecifyPort_		,
													long		lPort_				,
													NrString&	strUsername_		,
													NrString&	strPassword_		,
													long		lMaxFolderList_);

			void			AddDatabaseToRegistry(	NrString&	strDatabaseName_	,
													NrString&	strServerName_		,
													bool		bSpecifyPort_		,
													long		lPort_				,
													NrString&	strUsername_		,
													NrString&	strPassword_		,
													long		lMaxFolderList_		,
													bool		bTrustedLogin_);

			void			RemoveDatabaseFromRegistry(NrString& strDatabaseName_);
			void			AddDomainToRegistry(NrString& strDomainName_);
			void			RemoveDomainFromRegistry(NrString& strDomainName_);
			void			GetExchangeCredentials(NrUnicodeString* _Credentials);
			NrUnicodeString	GetTempFilePath();
			imstd::set<NrUnicodeString> GetUsersFromFile(const boost::filesystem::path &filePath);

		private:
			static const NrString				ms_strDatabasesSubkey;
			static const NrString				ms_strDomainsSubkey;

			static const NrString				ms_strDefaultClass;
			static const NrString				ms_strDefaultSubClass;
			static const NrString				ms_strDefaultType;
			static const long					ms_nDefaultThreadPoolSize;
			static const long					ms_nDefaultEmailRetrievalCount;
			static const long					ms_nMailboxSyncRecipientLimit;
			static const long					ms_nDefaultMailboxSyncBatchSize;
			static const NrString				ms_strDefaultMessageClasses;
			static const NrString				ms_strDefaultExcludeMessageClasses;
			static const NrString				ms_strDefaultRemovedMessageClasses;
			static const long					ms_nDefaultMinutesUntilRetryFiling;
			static const bool					ms_bDefaultEnableSendAndFileAgent;
			static const bool					ms_bDefaultEnableEFS;
			static const bool					ms_bDefaultEnableMailboxSync;
			static const NrString				ms_strDefaultDirectory;
			static const long					ms_lDefaultMinutesToBounce;
			static const NrString				ms_strDefaultSMTPServerName;
			static const long					ms_lDefaultSMTPServerPort;
			static const NrString				ms_strDefaultSMTPUserName;
			static const NrString				ms_strDefaultSMTPPassword;
			static const NrString				ms_strDefaultSMTPFromAddress;	
			static const NrString				ms_strDefaultSMTPReplyAddress;
			static const NrString				ms_strDefaultSMTPCustomText;
			static const bool					ms_bDefaultSMTPIncludeBouncedEmail;
			static const long					ms_lDefaultSMTPLinesToQuote;
			static const bool					ms_bDefaultBounceToAdmin;	
			static const bool					ms_bDefaultAllowFolderNumbers;
			static const bool					ms_bFromLookup;
			static const bool					ms_bUseSMTPOpenRelay;
			static const long					ms_lDaysToRetainDuplicates;
			static const NrString				ms_strDefaultProxyServer;
			static const NrString				ms_strDefaultProxyPort;
			static const NrString				ms_strDefaultExchSrvPort;
			static const NrString				ms_strDefaultAlternateURL;
			static const long					ms_lAuthMode;					
			static const NrString				ms_strDomain; 					
			static const NrString				ms_strUserName; 					
			static const NrString				ms_strServerVersion; 			
			static const long					ms_lDeleteXMLFile;				
			static const long					ms_lUseLDAPForAutoDiscover;		
			static const long					ms_lFindProxy;					
			static const long					ms_lDataFromSocket;				
			static const long					ms_lPollUserInterval;			
			static const long					ms_lPollEmailProcInterval;
			static const long					ms_lPollFolderProcInterval;
			static const long					ms_lPollMBSProcInterval;
			static const long					ms_lDelayAfterAllUserProcess;	
			static const long					ms_lRetrieveDataSize; 			
			static const long					ms_lEmailFiling;   	 			
			static const long					ms_lLinkedFolderFiling;  		
			static const NrString				ms_bstrScriptType;  	 			
			static const long					ms_lSendDtTimeCustField; 		
			static const long					ms_lNumDMSConnections;  			
			static const long					ms_lMBSThreadPoolSize;  			
			static const long					ms_lMBSBackSearchNumDays;		
			static const long					ms_lSkipFolderLookupFrequency;	
			static const long					ms_lEWSTimeoutSec; 				
			static const long					ms_lDiagUtil;; 	 				
			static const long					ms_lSchedulerDiag;				
			static const long					ms_lCrashDump; 					
			static const NrString				ms_strCrashDumpPath;
			static const long					ms_lDebugUsers;
			static const NrString				ms_strInstallPath;
			static const long					ms_lSerializeEWSAPIs;
			static const long					ms_lCaptureSoapReq;
			static const long					ms_lProcSpecUsers;
			static const long					ms_lKeepFoldInRoot;
			static const long					ms_lFileOldestFirst;
			static const long					ms_lWhiteListMsgClasses;
			static const long					ms_lIgnoreMsgClassAfterXFailure;
			static const long					ms_lDelEntryMsgSize;
			static const bool					ms_bSentItemFiler;
			static const bool					ms_bSentItemMove;
			static const bool					ms_bHideSyncIssueFold;
			static const bool					ms_bClusterValidation;
			static const bool					ms_bInitialSentItemSync;

		public:
			imstd::vector<NrString>				m_DomainNames;
			imstd::vector<EmsDatabaseEntry>		m_Databases;

			IM::RegistryLongProperty			m_nServerId;						// Server ID			
			IM::RegistryLongProperty			m_nTotalSvrsInCluster;				// Total number of servers in the cluster
			IM::RegistryLongProperty			m_nWSServicePort;					// WorkSite Service port
			
			IM::RegistryStringProperty			m_strClass;
			IM::RegistryStringProperty			m_strSubClass;
			IM::RegistryStringProperty			m_strDocType;
			IM::RegistryStringProperty			m_strStoreAdminSMTPAddress;			// Administrator SMTP address
			IM::RegistryStringProperty			m_strStoreAdminPassword;			// Administrator password
			IM::RegistryStringProperty			m_strExchSrvPort;					// Exchange server Socket port
			IM::RegistryStringProperty			m_strProxyServer;					// Proxy server
			IM::RegistryStringProperty			m_strProxyPort;						// Proxy Port
			IM::RegistryStringProperty			m_strClusterName;					// Fma cluster name			
			IM::RegistryLongProperty			m_nFmaPort;							// Fma port
			IM::RegistryLongProperty			m_nThreadPoolSize;
			IM::RegistryLongProperty			m_nEmailRetrievalCount;
			IM::RegistryLongProperty			m_nMailboxSyncRecipientLimit;
			IM::RegistryStringProperty			m_strMessageClasses;
			IM::RegistryStringProperty			m_strExcludeMessageClasses;
			IM::RegistryStringProperty			m_strRemovedMessageClasses;
			IM::RegistryLongProperty			m_nMinutesUntilRetryFiling;
			IM::RegistryBooleanProperty			m_bEnableSendAndFileAgent;
			IM::RegistryBooleanProperty			m_bEnableEFS;
			IM::RegistryBooleanProperty			m_bEnableMailboxSync;			
			IM::RegistryStringProperty			m_strTargetDirectory;
			IM::RegistryStringProperty			m_strDropDirectory;	
			IM::RegistryStringProperty			m_strBadDirectory;	
			IM::RegistryLongProperty			m_lMinutesToBounce;			
			IM::RegistryStringProperty			m_strSMTPServerName;
			IM::RegistryLongProperty			m_lSMTPServerPort;
			IM::RegistryStringProperty			m_strSMTPUserName;
			IM::RegistryStringProperty			m_strSMTPPassword;	
			IM::RegistryStringProperty			m_strSMTPFromAddress;
			IM::RegistryStringProperty			m_strSMTPReplyAddress;	
			IM::RegistryStringProperty			m_strSMTPCustomText;
			IM::RegistryBooleanProperty			m_bSMTPIncludeBouncedEmail;
			IM::RegistryLongProperty			m_lSMTPLinesToQuote;
			IM::RegistryBooleanProperty			m_bBounceToAdmin;
			IM::RegistryBooleanProperty			m_bAllowFolderNumbers;
			IM::RegistryBooleanProperty			m_bFromLookup;
			IM::RegistryBooleanProperty			m_bUseSMTPOpenRelay;
			IM::RegistryLongProperty			m_lDaysToRetainDuplicates;
			IM::RegistryStringProperty			m_strAlternateAutodiscoverURL;
			IM::RegistryLongProperty  			m_lAuthMode;
			IM::RegistryStringProperty 			m_strDomain;
			IM::RegistryStringProperty 			m_strUserName;
			IM::RegistryStringProperty 			m_strServerVersion;
			IM::RegistryLongProperty 			m_lDeleteXMLFile;
			IM::RegistryLongProperty 			m_lUseLDAPForAutoDiscover;
			IM::RegistryLongProperty 			m_lFindProxy;
			IM::RegistryLongProperty 			m_lDataFromSocket;
			IM::RegistryLongProperty 			m_lPollUserInterval;
			IM::RegistryLongProperty 			m_lPollEmailProcInterval;
			IM::RegistryLongProperty 			m_lPollFolderProcInterval;
			IM::RegistryLongProperty 			m_lPollMBSProcInterval;
			IM::RegistryLongProperty 			m_lDelayAfterAllUserProcess;
			IM::RegistryLongProperty 			m_lRetrieveDataSize;
			IM::RegistryLongProperty 			m_lEmailFiling;
			IM::RegistryLongProperty 			m_lLinkedFolderFiling;
			IM::RegistryStringProperty 			m_bstrScriptType;
			IM::RegistryLongProperty 			m_lSendDtTimeCustField;
			IM::RegistryLongProperty 			m_lNumDMSConnections;
			IM::RegistryLongProperty 			m_lMBSThreadPoolSize;
			IM::RegistryLongProperty 			m_lMBSBackSearchNumDays;
			IM::RegistryLongProperty 			m_lSkipFolderLookupFrequency;
			IM::RegistryLongProperty 			m_lEWSTimeoutSec;
			IM::RegistryLongProperty 			m_lDiagUtil;
			IM::RegistryLongProperty 			m_lSchedulerDiag;
			IM::RegistryLongProperty 			m_lCrashDump;
			IM::RegistryStringProperty 			m_strCrashDumpPath;
			IM::RegistryLongProperty			m_lDebugUsers;
			IM::RegistryStringProperty			m_strInstallPath;
			IM::RegistryLongProperty			m_lSerializeEWSAPIs;
			IM::RegistryLongProperty			m_lCaptureSoapReq;
			IM::RegistryLongProperty			m_lProcSpecUsers;
			IM::RegistryLongProperty			m_lKeepFoldInRoot;
			IM::RegistryLongProperty			m_lFileOldestFirst;
			IM::RegistryLongProperty 			m_lWhiteListMsgClasses;
			IM::RegistryLongProperty 			m_lIgnoreMsgClassAfterXFailure;			
			IM::RegistryLongProperty 			m_lDelEntryMsgSize;
			IM::RegistryBooleanProperty			m_bSentItemFiler;
			IM::RegistryBooleanProperty			m_bSentItemMove;
			IM::RegistryBooleanProperty			m_bHideSyncIssueFold;
			IM::RegistryBooleanProperty			m_bClusterValidation;
			IM::RegistryBooleanProperty			m_bInitialSentItemSync;
		};

	};	// namespace IM


#endif	// __IM_EMAILSVCCONFIGURATION_H__

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
