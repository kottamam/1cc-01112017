//
//

#include <Registry\RegistryLib.h>
#pragma hdrstop
#include <Registry\RegClass.h>
#include <Registry\RegistryMap.h>
#include <regstr.h>

using namespace IM;

//
//	Encryption Key
//
#define ENCRYPT_KEY			"iManage Service"


	RegistryMap::RegistryMap(const TCHAR *szComputerName_, HKEY hKey_, const TCHAR *szBaseKeyPath_)
		: Registry(szComputerName_, hKey_, szBaseKeyPath_), m_hKey(hKey_)
{
}

	RegistryMap::RegistryMap(
		const RegistryMap *pRegistryMap_
	) :
		Registry(pRegistryMap_),
		m_propertyMap(pRegistryMap_->m_propertyMap),
		m_hKey(pRegistryMap_->m_hKey)
{
}

RegistryMap::~RegistryMap()
{
	PropertyMap::iterator	it;

	for (it = m_propertyMap.begin(); it != m_propertyMap.end(); it++)
	{
		RegistryProperty	*pRegistryProperty;

		pRegistryProperty = (*it).second;

		if (pRegistryProperty->IsInHeap() == true)
		{
			delete pRegistryProperty;
		}
	}
	m_propertyMap.clear();
}



void
RegistryMap::LoadFromRegistry()
{
	// open registry key
	if (OpenOrCreate(NULL, KEY_READ) != true)
	{
		NrString		strMessage;

		strMessage = _T("Key: ");
		strMessage += m_strBaseKeyPath;
		strMessage += _T(", Cannot open");

		throw_error(GetLastError(), strMessage.c_str());
	}

	// load name value pair
	NrString	strName;
	DWORD		dwValueType;
	TCHAR		szValueBuffer[1024];
	long		lValueBufferSize = sizeof(szValueBuffer);
	memset(szValueBuffer, 0, lValueBufferSize);

	while (EnumerateName(strName, dwValueType, szValueBuffer, lValueBufferSize) != false)
	{
		switch (dwValueType)
		{

		case REG_SZ:
			if (_tcslen(szValueBuffer) == 1 && (szValueBuffer[0] == TEXT('Y') || szValueBuffer[0] == TEXT('y')  ||
												szValueBuffer[0] == TEXT('N')  || szValueBuffer[0] == TEXT('n')))
			{
				bool	bValue = false;

				if (szValueBuffer[0] == TEXT('Y') || szValueBuffer[0] == TEXT('y'))
					bValue = true;

				SetValue(strName.c_str(), bValue);
			}
			else if(IsEncrypted(strName.c_str()) == true)
			{
				EncryptedString		eString(ENCRYPT_KEY);
				NrString			strPlainValue;

				eString.Decrypt(szValueBuffer, strPlainValue);

				SetValue(strName.c_str(), strPlainValue.c_str());
			}
			else
			{
				SetValue(strName.c_str(), szValueBuffer);
			}

			break;

		case REG_DWORD:

			long	lValue;

			memcpy(&lValue, szValueBuffer, sizeof(lValue));
			SetValue(strName.c_str(), lValue);

			break;

		default:
			continue;
		}
	}

	Registry::Close();
}



void
RegistryMap::StoreInRegistry()
{
	// open registry key
	if (OpenOrCreate(NULL, KEY_ALL_ACCESS) != true)
	{
		NrString		strMessage;

		strMessage = _T("Key: ");
		strMessage += m_strBaseKeyPath;
		strMessage += _T(", Cannot open");

		throw_error(GetLastError(), strMessage.c_str());
	}

	try
	{
		// Store name value pairs
		NrString				strName;
		PropertyMap::iterator	it;
		RegistryProperty		*pRegistryProperty;
		RegistryBooleanProperty			*pBooleanProperty;
		RegistryLongProperty			*pLongProperty;
		RegistryStringProperty			*pStringProperty;
		NrCiString				strBooleanValue;

		long lConType = -1;
		it = m_propertyMap.find (_T("Connection Type"));
		if(it != m_propertyMap.end ())
		{
			RegistryProperty	*p= it->second;
			lConType = ((RegistryLongProperty *)p)->Get ();
		}

		for (it = m_propertyMap.begin(); it != m_propertyMap.end(); it++)
		{

			strName = (*it).first;
			pRegistryProperty = (*it).second;

			// Don't add HpFlow based config. items to registry for Non-HpFlow(Worksite and Proxy) databases
			if( lConType != 2)
			{
				if(_tcscmp(strName.c_str (), _T("HpFlow BaseUrl")) == 0 || _tcscmp(strName.c_str (), _T("HpFlow ClientID")) == 0 || _tcscmp(strName.c_str (), _T("HpFlow Folder Name Format")) == 0 ||
					_tcscmp(strName.c_str (),_T("HpFlow ProxyServer")) == 0 || _tcscmp(strName.c_str (), _T("HpFlow SSOUrl")) == 0 || _tcscmp(strName.c_str (), _T("HpFlow Key File Path")) == 0 ||
					_tcscmp(strName.c_str (),_T("HpFlow KeyFile Password")) == 0 || _tcscmp(strName.c_str (),_T("HpFlow Secure Sent Links Folder Location")) == 0 || _tcscmp(strName.c_str (), _T("HpFlow Secure Sent Links Folder Name")) == 0 ||
					_tcscmp(strName.c_str (),_T("HpFlow StoreFrontUrl")) == 0 || _tcscmp(strName.c_str (),_T("HpFlow Trusted Login")) == 0 || _tcscmp(strName.c_str (),_T("HpFlow Company Email Domains")) == 0 )
				{
					continue;
				}
			}

			if (pRegistryProperty->IsChanged() == false)
				continue;


			// remove the old information
			DeleteName(strName.c_str());

			// save the new information
			switch (pRegistryProperty->GetType())
			{
			case BooleanPropertyType:

				pBooleanProperty = (RegistryBooleanProperty *) pRegistryProperty;

				strBooleanValue = (pBooleanProperty->Get() == true) ? TEXT("Y") : TEXT("N");
				if (SetStringValue(strName.c_str(), strBooleanValue.c_str()) == false)
					throw_error(GetLastError(), _T("Could not store boolean value in registry"));

				break;

			case LongPropertyType:

				pLongProperty = (RegistryLongProperty *) pRegistryProperty;
				if (SetLongValue(strName.c_str(), pLongProperty->Get()) == false)
					throw_error(GetLastError(), _T("Could not store long value in registry"));

				break;

			case CiStringPropertyType:

				pStringProperty = (RegistryStringProperty *) pRegistryProperty;

				// if the value has to be encrypted then encrypt it before storing
				if (pStringProperty->IsEncrypted() == true)
				{
					EncryptedString		eString(ENCRYPT_KEY);
					NrString			strEncryptedString;

					eString.Encrypt(pStringProperty->Get().c_str(), strEncryptedString);
					if (SetStringValue(strName.c_str(), strEncryptedString.c_str()) == false)
						throw_error(GetLastError(), _T("Could not store string value in registry"));
				}
				else
				{
					if (SetStringValue(strName.c_str(), pStringProperty->Get().c_str()) == false)
						throw_error(GetLastError(), _T("Could not store string value in registry"));
				}

				break;
			}
		}
	}
	catch (Exception &exception)
	{
		Close();

		log_exception();
		throw;
	}

	Close();
}


void
RegistryMap::DeleteFromRegistry()
{
	// open registry key
	if (Open(NULL, KEY_ALL_ACCESS) != true)
	{
		NrString		strMessage;

		strMessage = _T("Key: ");
		strMessage += m_strBaseKeyPath;
		strMessage += _T(", Cannot open");

		throw_error(GetLastError(), strMessage.c_str());
	}

	// load names in list
	NrString	strName;
	DWORD		dwValueType;
	TCHAR		szValueBuffer[REGSTR_MAX_VALUE_LENGTH*4];
	long		lValueBufferSize = sizeof(szValueBuffer);
	imstd::list<NrString>	nameList;

	memset(szValueBuffer, 0, lValueBufferSize);

	while (EnumerateName(strName, dwValueType, szValueBuffer, lValueBufferSize) != false)
	{
		nameList.push_back(strName.c_str());
	}
	while (nameList.size() != 0)
	{
		strName = nameList.front();
		nameList.pop_front();

		DeleteName(strName.c_str());
	}

	Registry::Close();
}




void
RegistryMap::LogRegistry() const
{
	NrString					strPropertyName;
	PropertyMap::const_iterator	it;
	RegistryProperty			*pRegistryProperty;

	for (it = m_propertyMap.begin(); it != m_propertyMap.end(); it++)
	{
		strPropertyName = (*it).first;
		pRegistryProperty = (*it).second;
		pRegistryProperty->LogProperty(strPropertyName);
	}
}



void
RegistryMap::SetEncryptFlag(const TCHAR *szName_)
{
	PropertyMap::iterator	it;
	RegistryProperty		*pRegistryProperty;


	if ((it = m_propertyMap.find(szName_)) != m_propertyMap.end())
	{
		pRegistryProperty = (*it).second;
		pRegistryProperty->SetEncryptFlag(true);
	}
}



bool
RegistryMap::IsEncrypted(const TCHAR *szName_)
{
	PropertyMap::iterator	it;
	RegistryProperty		*pRegistryProperty;


	if ((it = m_propertyMap.find(szName_)) != m_propertyMap.end())
	{
		pRegistryProperty = (*it).second;
		return pRegistryProperty->IsEncrypted();
	}

	return false;
}



void
RegistryMap::SetValue(const TCHAR *szName_, bool bValue_)
{
	PropertyMap::iterator	it;
	RegistryProperty		*pRegistryProperty;


	if ((it = m_propertyMap.find(szName_)) != m_propertyMap.end())
	{
		pRegistryProperty = (*it).second;

		// if existing property is not Boolean then replace it
		if (dynamic_cast<RegistryBooleanProperty *>(pRegistryProperty) == NULL)
		{
			m_propertyMap.erase(it);
			if (pRegistryProperty->IsInHeap() == true)
			{
				delete pRegistryProperty;
			}

			SetValue(szName_, bValue_);
		}
		else
		{
			RegistryBooleanProperty		*pBooleanProperty = (RegistryBooleanProperty *) pRegistryProperty;
			pBooleanProperty->Set(bValue_);
			pBooleanProperty->ResetChange();
		}
	}
	else
	{
		RegistryBooleanProperty *pBooleanProperty = im_new RegistryBooleanProperty(bValue_);
		pBooleanProperty->SetHeapFlag(true);
		m_propertyMap.insert(PropertyMap::value_type(szName_, pBooleanProperty));
	}
}


void
RegistryMap::SetValue(const TCHAR *szName_, long lValue_)
{
	PropertyMap::iterator	it;
	RegistryProperty		*pRegistryProperty;


	if ((it = m_propertyMap.find(szName_)) != m_propertyMap.end())
	{
		pRegistryProperty = (*it).second;

		// if existing property is not long then replace it
		if (dynamic_cast<RegistryLongProperty *>(pRegistryProperty) == NULL)
		{
			m_propertyMap.erase(it);
			if (pRegistryProperty->IsInHeap() == true)
			{
				delete pRegistryProperty;
			}

			SetValue(szName_, lValue_);
		}
		else
		{
			RegistryLongProperty *pLongProperty = (RegistryLongProperty *) pRegistryProperty;
			pLongProperty->Set(lValue_);
			pLongProperty->ResetChange();
		}
	}
	else
	{
		RegistryLongProperty *pLongProperty = im_new RegistryLongProperty(lValue_);
		pLongProperty->SetHeapFlag(true);
		m_propertyMap.insert(PropertyMap::value_type(szName_, pLongProperty));
	}
}


void
RegistryMap::SetValue(const TCHAR *szName_, const TCHAR *strValue_)
{
	PropertyMap::iterator	it;
	RegistryProperty		*pRegistryProperty;


	if ((it = m_propertyMap.find(szName_)) != m_propertyMap.end())
	{
		pRegistryProperty = (*it).second;

		// if existing property is not Boolean then replace it
		if (dynamic_cast<RegistryStringProperty *>(pRegistryProperty) == NULL)
		{
			m_propertyMap.erase(it);
			if (pRegistryProperty->IsInHeap() == true)
			{
				delete pRegistryProperty;
			}

			SetValue(szName_, strValue_);
		}
		else
		{
			RegistryStringProperty *pStringProperty = (RegistryStringProperty *) pRegistryProperty;
			pStringProperty->Set(NrCiString(strValue_));
			pStringProperty->ResetChange();
		}
	}
	else
	{
		RegistryStringProperty *pStringProperty = im_new RegistryStringProperty(NrCiString(strValue_));
		pStringProperty->SetHeapFlag(true);
		m_propertyMap.insert(PropertyMap::value_type(szName_, pStringProperty));
	}
}



bool
RegistryMap::GetValue(const TCHAR *szName_, bool& bValue_) const
{
	PropertyMap::const_iterator	it;
	RegistryProperty			*pRegistryProperty;


	if ((it = m_propertyMap.find(szName_)) == m_propertyMap.end())
		return false;

	pRegistryProperty = (*it).second;

	// if existing property is not Boolean then replace it
	if (dynamic_cast<RegistryBooleanProperty *>(pRegistryProperty) == NULL)
		return false;

	RegistryBooleanProperty	*pBooleanProperty = (RegistryBooleanProperty *) pRegistryProperty;
	bValue_ = pBooleanProperty->Get();

	return true;
}


bool
RegistryMap::GetValue(const TCHAR *szName_, long& lValue_) const
{
	PropertyMap::const_iterator	it;
	RegistryProperty			*pRegistryProperty;


	if ((it = m_propertyMap.find(szName_)) == m_propertyMap.end())
		return false;

	pRegistryProperty = (*it).second;

	// if existing property is not Boolean then replace it
	if (dynamic_cast<RegistryLongProperty *>(pRegistryProperty) == NULL)
		return false;

	RegistryLongProperty	*pLongProperty = (RegistryLongProperty *) pRegistryProperty;
	lValue_ = pLongProperty->Get();

	return true;
}


bool
RegistryMap::GetValue(const TCHAR *szName_, NrCiString& strValue_) const
{
	PropertyMap::const_iterator	it;
	RegistryProperty			*pRegistryProperty;


	if ((it = m_propertyMap.find(szName_)) == m_propertyMap.end())
		return false;

	pRegistryProperty = (*it).second;

	// if existing property is not Boolean then replace it
	if (dynamic_cast<RegistryStringProperty *>(pRegistryProperty) == NULL)
		return false;

	RegistryStringProperty	*pStringProperty = (RegistryStringProperty *) pRegistryProperty;
	strValue_ = pStringProperty->Get();

	return true;
}


void
RegistryMap::GetNames(imstd::list<IM::NrString> listOfNames_) const
{
	PropertyMap::const_iterator	it;

	for (it = m_propertyMap.begin(); it != m_propertyMap.end(); it++)
	{
		listOfNames_.push_back((*it).first);
	}
}



void
RegistryBooleanProperty::LogProperty(const IM::NrString& strPropertyName) const
{
	if(IsEncrypted())
	{
		::LogMsg(LOG_HEADER, TEXT("Registry value: %s - %s"), strPropertyName.c_str(), TEXT("************************************"));
	}
	else
	{
		IM::NrString strVal = (Get() == true) ? TEXT("Y") : TEXT("N");
		::LogMsg(LOG_HEADER, TEXT("Registry value: %s - %s"), strPropertyName.c_str(), strVal.c_str());
	}
}


void
RegistryLongProperty::LogProperty(const IM::NrString& strPropertyName) const
{
	if(IsEncrypted())
	{
		::LogMsg(LOG_HEADER, TEXT("Registry value: %s - %s"), strPropertyName.c_str(), TEXT("************************************"));
	}
	else
	{
		::LogMsg(LOG_HEADER, TEXT("Registry value: %s - %d"), strPropertyName.c_str(), Get());
	}
}


void
RegistryStringProperty::LogProperty(const IM::NrString& strPropertyName) const
{
	if(IsEncrypted())
	{
		::LogMsg(LOG_HEADER, TEXT("Registry value: %s - %s"), strPropertyName.c_str(), TEXT("************************************"));
	}
	else
	{
		::LogMsg(LOG_HEADER, TEXT("Registry value: %s - %s"), strPropertyName.c_str(), Get().c_str());
	}
}


void
RegistryBooleanProperty::GetPropertyStringValue(IM::NrString &strPropertyStringValue_)
{
	if(IsEncrypted())
	{
		strPropertyStringValue_ = TEXT("************************************");
	}
	else
	{
		strPropertyStringValue_ = (Get() == true) ? TEXT("Y") : TEXT("N");
	}
}


void
RegistryLongProperty::GetPropertyStringValue(IM::NrString &strPropertyStringValue_)
{
	if(IsEncrypted())
	{
		strPropertyStringValue_ = TEXT("************************************");
	}
	else
	{
		_TCHAR szValue[MAX_PATH];
		_stprintf(szValue, _T("%d"), Get());
		strPropertyStringValue_ = szValue;
	}
}


void
RegistryStringProperty::GetPropertyStringValue(IM::NrString &strPropertyStringValue_)
{
	if(IsEncrypted())
	{
		strPropertyStringValue_ = TEXT("************************************");
	}
	else
	{
		strPropertyStringValue_ = Get().c_str();
	}
}
