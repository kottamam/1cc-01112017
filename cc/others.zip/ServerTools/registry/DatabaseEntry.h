//
//	Classes for managing database configuration information in the registry
//


#pragma once

#ifndef __REG_DATABASE_ENTRY_H__
#define __REG_DATABASE_ENTRY_H__

#include <registry\RegistryMap.h>

namespace IM
{
class DatabaseEntryList;

class DatabaseEntry : public IM::RegistryMap
{
public:
	friend DatabaseEntryList;

	enum ConnectionType
	{
		Database = 0,
		DMSProxy = 1,
		HpFlow = 2
	};

	IM::NrString				m_strParentKeyPath;			// parent location of the database data

public:

	IM::RegistryStringProperty	m_strDatabase;

	IM::RegistryStringProperty	m_strLogonID;
	IM::RegistryStringProperty	m_strPassword;

	IM::RegistryLongProperty	m_lConnectionCount;
	IM::RegistryBooleanProperty	m_bLocatedNear;

	IM::RegistryBooleanProperty	m_bUseMaxDop;

	IM::RegistryBooleanProperty	m_bPrimary;
	IM::RegistryBooleanProperty	m_bAsManyConnectionsAsThreads;

	IM::RegistryLongProperty	m_lConnectionType;
	IM::RegistryBooleanProperty	m_bAllowFlatSpaceDocuments;

public:
				DatabaseEntry(const TCHAR *szComputerName_, const TCHAR *szBaseKeyPath_, const TCHAR *szDatabaseName_);
	explicit	DatabaseEntry(const DatabaseEntry *pDatabaseEntry_);
	virtual		~DatabaseEntry() {}

	void		RemoveFromRegistry();
};





typedef IM::STLPointer<DatabaseEntry>		DatabaseEntryPointer;
typedef imstd::list<DatabaseEntryPointer>	DatabaseEntryPointerList;


class DatabaseEntryList : public DatabaseEntryPointerList
{
public:

	typedef DatabaseEntryList::iterator		DatabaseEntryListIterator;

public:
	IM::NrString	m_strComputerName;
	IM::NrString	m_strBaseKeyPath;

					DatabaseEntryList(const _TCHAR *strComputerName_, const _TCHAR *szBaseKeyPath_);
	virtual			~DatabaseEntryList()		{	ClearList();	}

	virtual void	LoadAll();
	void			ClearList();
	DatabaseEntry	*Get(const _TCHAR *strDatabase_);

	virtual void	Add(DatabaseEntry *pEntry);
	virtual void	Remove(const _TCHAR *strDatabase_);

	virtual DatabaseEntry *NewEntry(const _TCHAR *strDatabase_) = 0;
};





}; // namespace IM

#endif __REG_DATABASE_ENTRY_H__
