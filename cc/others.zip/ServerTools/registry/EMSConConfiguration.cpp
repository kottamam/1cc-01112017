#include <Registry\RegistryLib.h>
#pragma hdrstop
#include <Registry\RegClass.h>
#include <Registry\RegistryMap.h>
#include <Registry\EMSConConfiguration.h>


using namespace IM;


#define KEY_EMSCON_PATH				TEXT("SOFTWARE\\Interwoven\\WorkSite\\imEMSSvc\\imEMSCon")
#define KEY_POP3_USERNAME			TEXT("Pop3 UserName")
#define KEY_POP3_PASSWORD			TEXT("Pop3 Password")
#define KEY_POP3_PORT				TEXT("Pop3 Port")
#define KEY_LEAVE_OUTLOOK_RUNNING	TEXT("LeaveOutlookRunning")
#define KEY_LEAVE_POP3_RUNNING		TEXT("LeavePop3Running")


CEMSConConfiguration::CEMSConConfiguration(const TCHAR *szComputerName_)
			: RegistryMap(szComputerName_, HKEY_LOCAL_MACHINE, KEY_EMSCON_PATH)
{
	m_strPop3User			= _T("");
	m_strPop3Password		= _T("");
	m_lPop3Port				= 110;
	m_lLeaveOutlookRunning	= false;
	m_lLeavePop3Running		= false;

	m_strPop3User.SetEncryptFlag(true);
	m_strPop3Password.SetEncryptFlag(true);

	m_propertyMap.insert(PropertyMap::value_type(KEY_POP3_USERNAME, &m_strPop3User));
	m_propertyMap.insert(PropertyMap::value_type(KEY_POP3_PASSWORD, &m_strPop3Password));
	m_propertyMap.insert(PropertyMap::value_type(KEY_POP3_PORT, &m_lPop3Port));
	m_propertyMap.insert(PropertyMap::value_type(KEY_LEAVE_OUTLOOK_RUNNING, &m_lLeaveOutlookRunning));
	m_propertyMap.insert(PropertyMap::value_type(KEY_LEAVE_POP3_RUNNING, &m_lLeavePop3Running));
	
}

