//=============================================================================
// File: RegistryLib.h
//-----------------------------------------------------------------------------
// Date      Who  Modification
// --------  ---  -------------------------------------------------------------
// 07/21/99  ZUB  Initial coding
//-----------------------------------------------------------------------------
// Copyright (C) 1999, iManage, Inc.
// PROPRIETARY AND CONFIDENTIAL
//=============================================================================
//
// Main header file for Registry management classes
//

#pragma once

#ifndef __REG_REGISTRYLIB_H__
#define __REG_REGISTRYLIB_H__

#define STRICT 1

#include <windows.h>
#include <tchar.h>
#include <regstr.h>

#include <stl\NrString.h>

#include <Verification\Verification.h>
#include <Verification\Exception.h>

#include <Stream\PropertyTypes.h>
#include <Stream\Property.h>
#include <Crypt\Crypt.h>


#define log_exception()					LogMessage(exception.m_pszFile, exception.m_lLine,					\
												LM_FILE_OUTPUT | LM_STANDARD_OUTPUT, LM_LEVEL_ERROR,		\
												TEXT("Exception: %s - Error %d"),							\
												(AnsiToUnicode(exception.what())).c_str(), exception.m_lCode)

// DMS
#define SZ_DMSSVC_NAME			_T("imDmsSvc")

#ifdef _WIN64
#define SZ_DMSSVC_DISPLAY_NAME	_T("WorkSite Server")
#define SZ_DMSSVC_SCM_NAME		_T("Interwoven WorkSite Server")
#else
#define SZ_DMSSVC_DISPLAY_NAME	_T("WorkSite Server")
#define SZ_DMSSVC_SCM_NAME		_T("WorkSite Server")
#endif

#define KEY_DMSSVC_PATH			_T("software\\Interwoven\\WorkSite\\imDmsSvc")
#define KEY_DMS_DB_PATH			_T("software\\Interwoven\\WorkSite\\imDmsSvc\\Databases")

// Index Manager
#define SZ_IDXMGR_NAME			_T("imIdxMgrSvc")
#define SZ_IDXMGR_DISPLAY_NAME	_T("Index Manager")
#define SZ_IDXMGR_SCM_NAME		_T("Interwoven WorkSite Index Manager Service")

#define KEY_IDXMGRSVC_PATH		_T("software\\Interwoven\\WorkSite\\imIdxMgrSvc")
#define KEY_IDXMGR_DB_PATH		_T("software\\Interwoven\\WorkSite\\imIdxMgrSvc\\Databases")

// Index Search
#define SZ_IDXSCH_NAME			_T("imIdxSrchSvc")
#define SZ_IDXSCH_DISPLAY_NAME	_T("Index Search")
#define SZ_IDXSCH_SCM_NAME		_T("Interwoven WorkSite Index Search Service")

#define KEY_IDXSCHSVC_PATH		_T("software\\Interwoven\\WorkSite\\imIdxSrchSvc")
#define KEY_IDXSCH_DB_PATH		_T("software\\Interwoven\\WorkSite\\imIdxSrchSvc\\Databases")

// Rules Engine
#define SZ_RESVC_NAME			_T("imRulesEngine")
#define SZ_RESVC_DISPLAY_NAME	_T("Rules Engine")
#define SZ_RESVC_SCM_NAME		_T("Interwoven WorkSite Rules Engine Service")

#define KEY_RESVC_PATH			_T("software\\Interwoven\\WorkSite\\imRulesEngine")
#define KEY_RE_DB_PATH			_T("software\\Interwoven\\WorkSite\\imRulesEngine\\Databases")
#define KEY_REHANDLER_PATH		_T("software\\Interwoven\\WorkSite\\imRulesEngine\\Handlers")

// EMS
#define SZ_EMSSVC_NAME			_T("imEmsSvc")
#define SZ_EMSSVC_DISPLAY_NAME	_T("Communications Server")
#define SZ_EMSSVC_SCM_NAME		_T("Interwoven WorkSite Communications Service")

#define KEY_EMSSVC_PATH			_T("software\\Interwoven\\WorkSite\\imEMSSvc")

// FMA
#define SZ_FMASVC_NAME			_T("imFmaSvc")
#define SZ_FMASVC_DISPLAY_NAME	_T("Cluster Manager")
#define SZ_FMASVC_SCM_NAME		_T("Interwoven WorkSite Cluster Manager Service")

#define KEY_FMASVC_PATH		_T("software\\Interwoven\\WorkSite\\imFmaSvc")

// EFS
#define SZ_EFSSVC_NAME			_T("imEFSSvc")
#define SZ_EFSSVC_DISPLAY_NAME	_T("Email Filing Service")
#define SZ_EFSSVC_SCM_NAME		_T("WorkSite Email Filing Service")

#define KEY_EFSSVC_PATH					_T("software\\Interwoven\\WorkSite\\imEFSSvc")

#define SZ_ONLINEEMAILSVC_NAME			_T("imEMailSvc") 
#define SZ_ONLINEEMAILSVC_DISPLAY_NAME	_T("Exchange Online Service") 
#define SZ_ONLINEEMAILSVC_SCM_NAME		_T("WorkSite Exchange Online Service") 
#define SZ_ONLINEEMAILSVC_PATH			_T("SOFTWARE\\Interwoven\\Worksite\\imEmailSvc")
#define SZ_ONLINEEMAILSVC_DESC			_T("Provides E-Mail Filing services for Exchange")

// WCS for Notes 9.0 SP1
#define SZ_LNEMAILSVC_NAME			_T("imLNEMailSvc") 
#define SZ_LNEMAILSVC_DISPLAY_NAME	_T("WorkSite Communication Server") 
#define SZ_LNEMAILSVC_SCM_NAME		_T("WorkSite Communication Service") 
#define SZ_LNEMAILSVC_PATH			_T("SOFTWARE\\Interwoven\\Worksite\\imLNEMailSvc")
#define SZ_LNEMAILSVC_DESC			_T("Provides E-Mail Filing services for Lotus Notes")

// PrintRendition
#define SZ_PRINTRENDSVC_NAME			_T("imPrintRenditionSvc")
#define SZ_PRINTRENDSVC_DISPLAY_NAME	_T("Print Rendition Service")
#define SZ_PRINTRENDSVC_SCM_NAME		_T("Interwoven WorkSite PrintRendition Service")

#define KEY_PRINTRENDSVC_PATH		_T("software\\Interwoven\\WorkSite\\imPrintRenditionSvc")

// Render Service
#define SZ_RENDERSVC_NAME			_T("imRenderSvc")
#define SZ_RENDERSVC_DISPLAY_NAME	_T("Render Service")
#define SZ_RENDERSVC_SCM_NAME		_T("Interwoven WorkSite Render Service")

#define KEY_RENDERSVC_PATH		_T("software\\Interwoven\\WorkSite\\imRenderSvc")


//CIFS
#define SZ_CIFSSVC_NAME			_T("imFileShare")
#define SZ_CIFSSVC_DISPLAY_NAME	_T("iManage WorkSite FileShare")
#define SZ_CIFSSVC_SCM_NAME		_T("imFileShare")
#define SZ_CIFSSVC_SCM_DESC     _T("Provides access to WorkSite via a file share")

#define KEY_CIFSSVC_PATH		_T("software\\Interwoven\\WorkSite\\CIFS")

//
// WorkKnowledge DRE
//
#define SZ_WKDRESVC_NAME			_T("imWkDreSvc")
#define SZ_WKDRESVC_DISPLAY_NAME	_T("WorkKnowledge DRE")
#define SZ_WKDRESVC_SCM_NAME		_T("Interwoven WorkKnowledge Dynamic Reasoning Engine Service")

#define KEY_WKDRESVC_PATH			_T("software\\Interwoven\\WorkSite\\imWkDreSvc")
#define KEY_WKDRESVC_DB_PATH		_T("software\\Interwoven\\WorkSite\\imWkDreSvc\\Databases")

//
// WorkKnowledge Indexer
//
#define SZ_WKINDXRSVC_NAME			_T("imWkIdxMgrSvc")
#define SZ_WKINDXRSVC_DISPLAY_NAME	_T("WorkKnowledge Index Manager")
#define SZ_WKINDXRSVC_SCM_NAME		_T("Interwoven WorkKnowledge Index Manager Service")

#define KEY_WKINDXRSVC_PATH			_T("software\\Interwoven\\WorkSite\\imWkIdxMgrSvc")
#define KEY_WKINDXRSVC_DB_PATH		_T("software\\Interwoven\\WorkSite\\imWkIdxMgrSvc\\Databases")

//
// WorkKnowledge AutoIndexer
//
#define SZ_WKATINDXRSVC_NAME			_T("imWkAtIndxrSvc")
#define SZ_WKATINDXRSVC_DISPLAY_NAME	_T("WorkKnowledge AutoIndexer")
#define SZ_WKATINDXRSVC_SCM_NAME		_T("Interwoven WorkKnowledge AutoIndexer Service")

#define KEY_WKATINDXRSVC_PATH		_T("software\\Interwoven\\WorkSite\\imWkAtIndxrSvc")

//
// File Server connection information (Global for all services)
//
#define KEY_FS_PATH				_T("software\\Interwoven\\WorkSite\\File Servers")

// ODBC DSN information
#define KEY_ODBC_SRC_PATH		_T("Software\\ODBC\\ODBC.INI\\ODBC Data Sources")


//
// Directory Service Synchronization Service
//
#define SZ_DSSYNCSVC_NAME			_T("imDsSyncSvc")
#define SZ_DSSYNCSVC_DISPLAY_NAME	_T("Directory Synchronization Service")
#define SZ_DSSYNCSVC_SCM_NAME		_T("Interwoven WorkSite Directory Synchronization Service")
#define KEY_DSSYNCSVC_PATH			_T("software\\Interwoven\\WorkSite\\imDsSyncSvc")
#define KEY_DSSYNCSVC_DB_PATH		_T("software\\Interwoven\\WorkSite\\imDsSyncSvc\\Databases")

// OffSite
#define SZ_OFFSITESVC_NAME			_T("OffSite")
#define SZ_OFFSITESVC_DISPLAY_NAME	_T("OffSite Service")
#define SZ_OFFSITESVC_SCM_NAME		_T("Interwoven WorkSite OffSite Service")

#define KEY_OFFSITESVC_PATH			_T("software\\Interwoven\\WorkSite\\OffSite")

//WorkSite Indexer
#define SZ_IDXSVC_NAME			_T("imIdxSvc")
#define SZ_IDXSVC_WS_IDXER_DISPLAY_NAME	_T("WorkSite Indexer")
#define SZ_IDXSVC_WS_IDXER_SCM_NAME		_T("WorkSite Indexer Service")
#define SZ_IDXSVC_IUS_DISPLAY_NAME	_T("IUS Indexer")
#define SZ_IDXSVC_IUS_SCM_NAME		_T("IUS Indexer Service")
#define KEY_IDXSVC_PATH			_T("software\\Interwoven\\WorkSite\\imIdxSvc")


#endif __REG_REGISTRYLIB_H__