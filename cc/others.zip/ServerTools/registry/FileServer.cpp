
#include <Registry\RegistryLib.h>
#pragma hdrstop

#include <Registry\RegistryMap.h>
#include <Registry\FileServer.h>


using namespace IM;



#define KEY_NT_USE_SVC		TEXT("NT Use Service Account")
#define KEY_NT_LOGONID		TEXT("NT Logon ID")
#define KEY_NT_PASSWORD		TEXT("NT Password")

#define KEY_NW_BINDERY_CON	TEXT("NW Bindery Connection")
#define KEY_NW_CONTEXT		TEXT("NW User Context")
#define KEY_NW_LOGONID		TEXT("NW Logon ID")
#define KEY_NW_PASSWORD		TEXT("NW Password")



FileServerConfiguration::FileServerConfiguration(const _TCHAR *szComputerName_)
			: RegistryMap(szComputerName_, HKEY_LOCAL_MACHINE, KEY_FS_PATH)
{
	// Windows NT or UNC connection properties
	m_bUseServiceAccount.Set(true);

	m_strNtLogonID.SetEncryptFlag(true);
	m_strNtPassword.SetEncryptFlag(true);

	m_propertyMap.insert(PropertyMap::value_type(KEY_NT_USE_SVC, &m_bUseServiceAccount));
	m_propertyMap.insert(PropertyMap::value_type(KEY_NT_LOGONID, &m_strNtLogonID));
	m_propertyMap.insert(PropertyMap::value_type(KEY_NT_PASSWORD, &m_strNtPassword));


	// Novell NetWare File Server
	m_bIsBinderyConnection.Set(true);

	m_strNwLogonID.SetEncryptFlag(true);
	m_strNwPassword.SetEncryptFlag(true);

	m_propertyMap.insert(PropertyMap::value_type(KEY_NW_BINDERY_CON, &m_bIsBinderyConnection));
	m_propertyMap.insert(PropertyMap::value_type(KEY_NW_CONTEXT, &m_strNwUserContext));
	m_propertyMap.insert(PropertyMap::value_type(KEY_NW_LOGONID, &m_strNwLogonID));
	m_propertyMap.insert(PropertyMap::value_type(KEY_NW_PASSWORD, &m_strNwPassword));

}

