//=============================================================================
// File: DatabaseEntryEx.h
//-----------------------------------------------------------------------------
// Date      Who  Modification
// --------  ---  -------------------------------------------------------------
// 01/10/00  ZIA  Initial coding
//-----------------------------------------------------------------------------
// Copyright (C) 1999, NetRight Technologies, Inc.
// PROPRIETARY AND CONFIDENTIAL
//=============================================================================
//
//	Classes for managing service-specific database configuration information in the registry
//

#pragma once

#ifndef __REG_DATABASE_ENTRYEX_H___
#define __REG_DATABASE_ENTRYEX_H___

#include <registry\DatabaseEntry.h>

namespace IM
{


//
// classes derived from DatabaseEntry
//

class DmsDatabaseEntry : public DatabaseEntry
{
public:
				DmsDatabaseEntry(const TCHAR *szComputerName_, const TCHAR *szDatabaseName_);
	explicit	DmsDatabaseEntry(const DmsDatabaseEntry *pEntry_);
	virtual		~DmsDatabaseEntry() {}

	void		GetRegistryMap(PropertyMap *&pPropertyMap_);

	//
	// Index Connection Type indicates what type of index search connection we are making.
	// It can have the following values:
	// 1 - Direct Connection
	// 2 - Proxy Connection
	// 3 - Search Service Connection
	// 4 - No Connection
	//
	IM::RegistryLongProperty			m_lIndexConnectType;

	IM::RegistryLongProperty			m_lIndexConnectionCount;

	//
	// Index server is the name of the cluster to which a connection is made for index searches.
	// It is only valid for a proxy or search service connection.
	//
	IM::RegistryStringProperty			m_strIndexServer;

	IM::RegistryBooleanProperty			m_bIndexServerGivenPort;
	IM::RegistryLongProperty			m_lIndexServerPort;
	IM::RegistryLongProperty			m_lIndexReplyPort;

	//
	// This is a hidden key which allows the user to specify how many rows are to returned
	// when performing a search on a direct or proxy proxy index search. There is no GUI to
	// set this key.
	//
	IM::RegistryLongProperty			m_lIndexMaxRows;

	IM::RegistryStringProperty			m_strIndexSourceServer;
	IM::RegistryStringProperty			m_strIndexSource;
	IM::RegistryStringProperty			m_strIndexProduct;			// Hidden
	IM::RegistryStringProperty			m_strIndexExeType;			// Hidden
	IM::RegistryStringProperty			m_strIndexExe;				// Hidden
	IM::RegistryStringProperty			m_strIndexProject;			// Hidden
	IM::RegistryStringProperty			m_strIndexRenderFunction;	// Hidden
	IM::RegistryStringProperty			m_strIndexRepUser;
	IM::RegistryStringProperty			m_strIndexRepPassword;
	IM::RegistryBooleanProperty			m_bIndexHTTPS;
	IM::RegistryStringProperty			m_strIndexHTTPDomain;
	IM::RegistryStringProperty			m_strIndexHTTPUser;
	IM::RegistryStringProperty			m_strIndexHTTPPassword;
	//
	// Brought to you by the Department of Redundancy department. Re-align later... -GH-
	//
	IM::RegistryStringProperty			m_strIndexServerUserPwd;
	IM::RegistryStringProperty			m_strIndexLatestVersionSource;
	IM::RegistryStringProperty			m_strIndexAllVersionsSource;

	// Digital Safe config
	IM::RegistryStringProperty m_strDigitalSafeSSLKeyFile;
	IM::RegistryStringProperty m_strDigitalSafeSSLKeyFilePassword;
	IM::RegistryStringProperty m_strDigitalSafeSSLCACert;
	IM::RegistryStringProperty m_strDigitalSafeSSLCAPath;
	IM::RegistryStringProperty m_strDigitalSafeURL;
	IM::RegistryStringProperty m_strDigitalSafeMailFrom;
	IM::RegistryStringProperty m_strDigitalSafeRcptTo;
	IM::RegistryStringProperty m_strDigitalSafeDomainName;

	// IDOL config
	IM::RegistryStringProperty			m_strRepositoryName;
	IM::RegistryLongProperty			m_lSecurityKey1;
	IM::RegistryLongProperty			m_lSecurityKey2;
	IM::RegistryLongProperty			m_lSecurityKey3;
	IM::RegistryLongProperty			m_lSecurityKey4;
	IM::RegistryBooleanProperty			m_bAbridgedSearchResults;
	IM::RegistryBooleanProperty			m_bCombineSort;
	IM::RegistryLongProperty			m_lIndexTimeout;
	IM::RegistryStringProperty			m_strIDOLBias;
	IM::RegistryStringProperty			m_strIDOLWorkSpaceFilter;
	IM::RegistryStringProperty			m_strAllVersionsCombine;
	IM::RegistryStringProperty			m_strLatestVersionCombine;
	IM::RegistryBooleanProperty			m_bANDTextQueryTerms;
	IM::RegistryBooleanProperty			m_bMetaDataOnlyIndex;
	IM::RegistryBooleanProperty			m_bWorkSpaceIndex;
	IM::RegistryStringProperty			m_strCustomParams;
	IM::RegistryLongProperty			m_lGroupCacheExpirationInSeconds;

	IM::RegistryLongProperty			m_lVersionEditing;
	IM::RegistryLongProperty			m_lWorklistMode;

	IM::RegistryBooleanProperty			m_bConsolidateWorklist;
	IM::RegistryBooleanProperty			m_bPerformOCRReplacement;
	IM::RegistryBooleanProperty			m_bIncludeDisabledGroups;
	IM::RegistryBooleanProperty			m_bWebContent;
	IM::RegistryBooleanProperty			m_bHidden;

	IM::RegistryLongProperty			m_lSortOrderMask;

	IM::RegistryBooleanProperty			m_bGivenProxyServicePort;
	IM::RegistryLongProperty			m_lProxyServicePort;
	IM::RegistryLongProperty			m_lProxyReplyPort;
	IM::RegistryBooleanProperty			m_bGivenProxyFilePort;
	IM::RegistryLongProperty			m_lProxyFilePort;

	IM::RegistryLongProperty			m_lUndeclareRecord;

	IM::RegistryStringProperty			m_strImpersonationPassword;
	IM::RegistryLongProperty			m_lLocale;

	IM::RegistryBooleanProperty			m_bChangeQueueTruncationDisabled;
    IM::RegistryLongProperty            m_lChangeQueueTruncationTime;
    IM::RegistryLongProperty            m_lChangeQueueSizeInDays;
    
	IM::RegistryBooleanProperty			m_bChangeQueueCacheDisabled;
    IM::RegistryLongProperty            m_lChangeQueueCacheSizeInMinutes;
    IM::RegistryLongProperty            m_lChangeQueueCacheRefreshInSeconds;

	// HPFlow Configuration
	IM::RegistryStringProperty			m_strHpFlowKeyFilePWD;
	IM::RegistryStringProperty			m_strHpFlowKeyFilePath;
	IM::RegistryBooleanProperty			m_bLSTrustedLogin;
	IM::RegistryStringProperty			m_strSSOUrl;
	IM::RegistryStringProperty			m_strBaseUrl;
	IM::RegistryStringProperty			m_strProxyServer;
	IM::RegistryStringProperty			m_strFolderNameFormat;
	IM::RegistryStringProperty			m_strClientID;
	IM::RegistryStringProperty			m_strSFUrl;
	IM::RegistryStringProperty			m_strCompanyEmailDomains;
	IM::RegistryStringProperty			m_strSecureSentFolderName;
	IM::RegistryStringProperty			m_strSecureLinkFolderLocation;
	IM::RegistryBooleanProperty			m_bAuthenticatedProxy;
	IM::RegistryStringProperty			m_strProxyUserName;
	IM::RegistryStringProperty			m_strProxyPassword;
	IM::RegistryBooleanProperty			m_bDisableIDOLTermExpand;
	IM::RegistryLongProperty			m_lIManShareConnectTimeout;
	IM::RegistryLongProperty			m_lIManShareReadTimeout;

	// SEV Configuration
    IM::RegistryLongProperty            m_lSEVMinDocNum;
	IM::RegistryLongProperty            m_lSEVMaxDocNum;
	IM::RegistryBooleanProperty			m_bSEVAllowDocnumInsert;

    // Sync event logging
    IM::RegistryLongProperty		    m_lSyncLoggingMode;

	// OCR
	IM::RegistryLongProperty			m_lOCRRenditionFolder;

};

class IdxMgrDatabaseEntry : public DatabaseEntry
{
public:
				IdxMgrDatabaseEntry(const TCHAR *szComputerName_, const TCHAR *szDatabaseName_);
	virtual		~IdxMgrDatabaseEntry() {}

	unsigned long m_ulMaxLibraryDocNum;
	unsigned long m_ulMinLibraryDocNum;
};

class IdxSearchDatabaseEntry : public DatabaseEntry
{
public:
				IdxSearchDatabaseEntry(const TCHAR *szComputerName_, const TCHAR *szDatabaseName_);
	virtual		~IdxSearchDatabaseEntry() {}
	IM::RegistryLongProperty			m_lIndexMaxRows;
};


class ReDatabaseEntry : public DatabaseEntry
{
public:
				ReDatabaseEntry(const TCHAR *szComputerName_, const TCHAR *szDatabaseName_);
	virtual		~ReDatabaseEntry() {}
};

class WkIndxrDatabaseEntry : public DatabaseEntry
{
public:
				WkIndxrDatabaseEntry(const TCHAR *szComputerName_, const TCHAR *szDatabaseName_);
	virtual		~WkIndxrDatabaseEntry() {}
};

class WkDreDatabaseEntry : public DatabaseEntry
{
public:
				WkDreDatabaseEntry(const TCHAR *szComputerName_, const TCHAR *szDatabaseName_);
	virtual		~WkDreDatabaseEntry() {}

};

class DsSyncDatabaseEntry : public DatabaseEntry
{
public:
				DsSyncDatabaseEntry(const TCHAR *szComputerName_, const TCHAR *szDatabaseName_);
	virtual		~DsSyncDatabaseEntry() {}
};



//
// classes derived from DatabaseEntryList
//

class DmsDatabaseList : public DatabaseEntryList
{
public:
					DmsDatabaseList(const _TCHAR *strComputerName_);
	virtual			~DmsDatabaseList() {}

	virtual DatabaseEntry *NewEntry(const _TCHAR *strDatabase_)
	{
		return im_new DmsDatabaseEntry(m_strComputerName.c_str(), strDatabase_);
	}
};

class IdxMgrDatabaseList : public DatabaseEntryList
{
public:
					IdxMgrDatabaseList(const _TCHAR *strComputerName_);
	virtual			~IdxMgrDatabaseList() {}

	virtual DatabaseEntry *NewEntry(const _TCHAR *strDatabase_)
	{
		return im_new IdxMgrDatabaseEntry(m_strComputerName.c_str(), strDatabase_);
	}
};


class IdxSearchDatabaseList : public DatabaseEntryList
{
public:
					IdxSearchDatabaseList(const _TCHAR *strComputerName_);
	virtual			~IdxSearchDatabaseList() {}

	virtual DatabaseEntry *NewEntry(const _TCHAR *strDatabase_)
	{
		return im_new IdxSearchDatabaseEntry(m_strComputerName.c_str(), strDatabase_);
	}
};


class ReDatabaseList : public DatabaseEntryList
{
public:
					ReDatabaseList(const _TCHAR *strComputerName_);
	virtual			~ReDatabaseList() {}

	virtual DatabaseEntry *NewEntry(const _TCHAR *strDatabase_)
	{
		return im_new ReDatabaseEntry(m_strComputerName.c_str(), strDatabase_);
	}
};

class WkIndxrDatabaseList : public DatabaseEntryList
{
public:
					WkIndxrDatabaseList(const _TCHAR *strComputerName_);
	virtual			~WkIndxrDatabaseList() {}

	virtual DatabaseEntry *NewEntry(const _TCHAR *strDatabase_)
	{
		return im_new WkIndxrDatabaseEntry(m_strComputerName.c_str(), strDatabase_);
	}
};

class WkDreDatabaseList : public DatabaseEntryList
{
public:
					WkDreDatabaseList(const _TCHAR *strComputerName_);
	virtual			~WkDreDatabaseList() {}

	virtual DatabaseEntry *NewEntry(const _TCHAR *strDatabase_)
	{
		return im_new WkDreDatabaseEntry(m_strComputerName.c_str(), strDatabase_);
	}

	void LoadAll();
	void Add(DatabaseEntry* pEntry);
	void Remove(const _TCHAR *strDatabase_);
};

class DsSyncDatabaseList : public DatabaseEntryList
{
public:
					DsSyncDatabaseList(const _TCHAR *strComputerName_);
	virtual			~DsSyncDatabaseList() {}

	virtual DatabaseEntry *NewEntry(const _TCHAR *strDatabase_)
	{
		return im_new DsSyncDatabaseEntry(m_strComputerName.c_str(), strDatabase_);
	}
};




}; // namespace IM

#endif __REG_DATABASE_ENTRYEX_H___
