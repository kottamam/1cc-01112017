////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// File:	ntSystemService.h
//
// Project: srvrLib		Subsystem: Service
//
// Contents: Interface details of the NT System Service abstract base class.
//
//   Date    Who  Modification
// 05/21/99  GAH  Initial coding.
// 01/14/00  ZIA  Updates for improved registry management
//
// Copyright (C) 1999, iManage, Inc. All Rights reserved PROPRIETARY AND CONFIDENTIAL
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma once

#ifndef __REG_NTSYSTEMSERVICE_H__
#define __REG_NTSYSTEMSERVICE_H__

#include <verification\verification.h>
#include <verification\exception.h>
#include <stl\NrString.h>
#include <registry\Service.h>
#include <util\ShutdownWatchDogThread.h>

namespace IM
{
//==============================================================================================================
// NtSystemService
//==============================================================================================================

class NtSystemService :
	public virtual IM::ObjectSignature
{
	friend class IMUtil::ShutdownWatchDogThread;

//--------------------------------------------------------------------------------------------------------------
// Scoped structures.
//
private:
	enum
	{
		DefaultWaitHint = 3000
	};

//==============================================================================================================
// Nested class StSCM.
//==============================================================================================================
protected:
	class StSCM : public IM::ObjectSignature
	{
	public:
		StSCM(const IM::NrString &strServerName_);
		~StSCM();

		SC_HANDLE GetSCMHandle() const;

	private:
		SC_HANDLE	m_hSCM;
	};

//==============================================================================================================
// Nested class StService.
//==============================================================================================================
protected:
	class StService : public IM::ObjectSignature
	{
	public:
		StService(const IM::NrString &strServerName_, const IM::NrString &strServiceName_, bool bIsDebug_);
		~StService();

		SC_HANDLE	GetServiceHandle() const;

	private:
		SC_HANDLE	m_hService;
		SC_HANDLE	m_hSCM;
		bool		m_bIsDebug;
	};

//--------------------------------------------------------------------------------------------------------------
// Constructors, destructors, and initializers.
//

//
// Make default constructor and copy constructor private to enforce singleton pattern for NtSystemService.
// All other constructors and destrutor are protected to allow NtSystemService to be subclassed.
//
private:
	NtSystemService();
	NtSystemService(const NtSystemService&);

	void					Preinit();

protected:
	NtSystemService(IM::ServiceConfiguration *pServiceConfiguration_);
	virtual ~NtSystemService() throw();

	virtual void			Init();

public:
	virtual void			Destroy();

//--------------------------------------------------------------------------------------------------------------
// System Agent methods.
//
protected:
	virtual void			Run();
	virtual void			OnStopCleanup()	{	/* overload to perform service cleanup after STOP request */	}

	virtual void			Service(DWORD dwArgC_, const IM::NrString &strArgV_);
	virtual void			Control(DWORD dwOpCode_);

	virtual void			SetAcceptedControls(DWORD dwControls_);
	void					ChangeStatus(
								DWORD dwState_,
								DWORD dwWaitHint_ = (DWORD) DefaultWaitHint
							);

public:
	virtual void			Startup(const TCHAR *szBinaryName_);
	virtual void			DebugStartup(int nArgC_, _TCHAR *szArgV_[]) throw();

	static void WINAPI		ServiceMain(DWORD dwArgC_, LPTSTR *szArgV_);
	static void WINAPI		ServiceControl(DWORD dwCtrlCode_);
	static int WINAPI		DebugServiceControl(DWORD dwCtrlCode_);
	static int				MemoryDepletionHandler(size_t size_);

//--------------------------------------------------------------------------------------------------------------
// Installation methods.
//
public:
	bool					IsInstalled() const;

	virtual void			Install();
	virtual bool			Uninstall() {/* to do */ return(false);};

//--------------------------------------------------------------------------------------------------------------
// Event handlers.
//
protected:

	virtual void			OnStop();
	virtual void			OnInquire() {/* to do */};

//--------------------------------------------------------------------------------------------------------------
// Accessors.
//
public:
	static NtSystemService*				GetService();

	DWORD								GetExitCode() const;

	IM::NrString&						GetVersion(IM::NrString &strVersion_) const;
	IM::NrString&						GetName(IM::NrString &strName_) const;
	IM::NrString&						GetDisplayName(IM::NrString &strDisplayName_) const;
	IM::NrString&						GetServerName(IM::NrString &strServerName) const;

	bool								IsRunning() const;
	bool								IsPaused() const;
	bool								IsDebug() const;

//--------------------------------------------------------------------------------------------------------------
// Event Message Routines - Note: This should probably be moved and encapsulated in the EventMsg library.
//
public:
	//
	// Event handler map table
	//
	static WORD	emap[];

	static void WINAPIV		EventHandler(WORD wCategoryId_, const DWORD dwEventId_, va_list arglist) throw();

private:
	static HANDLE			m_hEventModule;

	static int				GetMaxEventInserts(DWORD dwEventId_);

//--------------------------------------------------------------------------------------------------------------
// Service configuration data.
//
protected:
	IM::ServiceConfiguration	*m_pServiceConfiguration;

//--------------------------------------------------------------------------------------------------------------
// Members
//
protected:
	static NtSystemService		*m_pService;			// One and only one service.

	SERVICE_TABLE_ENTRY			m_DispatchTable[2];
	SERVICE_STATUS				m_Status;
	SERVICE_STATUS_HANDLE		m_hStatus;

	HANDLE						m_hStopEvent;			// service stop event


	bool						m_bIsRunning;			// Running state of the service.
	bool						m_bIsPaused;			// Paused state of the service.
	bool						m_bIsDebug;				// Debugging service?

	bool						m_bTimeInUtc;			// Use time values based on UTC?
	bool						m_bIsInstalled;			// Is the service installed?

	IM::NrString				m_strName;				// System name for the service or executable name.
	IM::NrString				m_strComments;
};

//==============================================================================================================
// NtSystemService inline methods.
//

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// IsDebug
//
inline bool
	NtSystemService::IsDebug() const
{
	return(m_bIsDebug);
}

//==============================================================================================================
// Nested class StSCM (Service Control Manager) inline methods.
//==============================================================================================================

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// GetSCMHandle
//
inline SC_HANDLE NtSystemService::StSCM::GetSCMHandle() const
{
	return (m_hSCM);
}

//==============================================================================================================
// Nested class StService inline methods.
//==============================================================================================================

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// StService
//
inline SC_HANDLE
NtSystemService::StService::GetServiceHandle() const
{
	return (m_hService);
}

//--------------------------------------------------------------------------------------------------------------
// Constructors, destructors, and initializers.
//

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Destroy
//
inline void
NtSystemService::Destroy()
{
	check_object(m_pService);
	delete m_pService;
	m_pService = NULL;
}

//--------------------------------------------------------------------------------------------------------------
// OnStop
//
inline void
NtSystemService::OnStop()
{
//	ChangeStatus(SERVICE_STOP_PENDING);

	throw_syserr_iffails(::SetEvent(m_hStopEvent) != 0);

//	::Sleep(NtSystemService::DefaultWaitHint);

//	ChangeStatus(SERVICE_STOP_PENDING);

	m_bIsRunning = false;
}

//--------------------------------------------------------------------------------------------------------------
// Accessors.
//

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	GetService
//
inline NtSystemService*
NtSystemService::GetService()
{
	check_object(m_pService);
	return(m_pService);
}
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// GetName
//
inline IM::NrString&
NtSystemService::GetName(IM::NrString &strName_) const
{
	strName_ = m_pServiceConfiguration->m_strServiceName;
	return (strName_);
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// GetDisplayName
//
inline IM::NrString&
	NtSystemService::GetDisplayName(IM::NrString &strDisplayName_) const
{
	strDisplayName_ = m_pServiceConfiguration->m_strServiceDisplayName;
	return (strDisplayName_);
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// GetServerName
//
inline IM::NrString&
NtSystemService::GetServerName(IM::NrString &strServerName_) const
{
	strServerName_ = m_pServiceConfiguration->m_strComputerName;
	return (strServerName_);
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// GetVersion
//
inline IM::NrString&
NtSystemService::GetVersion(IM::NrString &strVersion_) const
{
	strVersion_ = m_pServiceConfiguration->m_strVersion.Get();
	return (strVersion_);
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// GetExitCode
//
inline DWORD NtSystemService::GetExitCode() const
{
	return(m_Status.dwWin32ExitCode);
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// IsInstall
//
inline bool
NtSystemService::IsInstalled() const
{
	return (m_bIsInstalled);
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// IsInstall
//
inline bool
NtSystemService::IsRunning() const
{
	return (m_bIsRunning);
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// IsInstall
//
inline bool
NtSystemService::IsPaused() const
{
	return (m_bIsPaused);
}


};	// namespace ImService

#endif	// __REG_NTSYSTEMSERVICE_H__

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
