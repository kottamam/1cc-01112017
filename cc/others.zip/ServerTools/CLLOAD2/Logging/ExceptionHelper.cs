using System;
using System.Reflection;

namespace iManage.Logging
{
	
	/// <summary>
	/// Summary description for ExceptionHelper.
	/// </summary>
	public sealed class ExceptionHelper
	{
		#region private constructor

		private ExceptionHelper()
		{
		}

		#endregion

		#region public static methods

		#region XML::DOC
		/// <summary>
		/// Map the java exception to .net. This will allow us to avoid making references
		/// to the WOM .NET dlls and vsjlib directly.
		/// </summary>
		/// <param name="ex"></param>
		/// <returns>A valid ControllerExceptions type. If the method cannot map the java exception
		/// it returns a ControllerExceptions.UnknownException.
		/// </returns>
		#endregion
	
		#region XML::DOC
		/// <summary>
		/// Localization support removed to simplifiy dependencies. Call Localization.getResourceString(ExceptionHelper.MapException(ex).ToString()) instead.
		/// </summary>
		/// <param name="ex"></param>
		/// <returns>ExceptionHelper.MapException(ex).ToString() - <b>not</b> localized.</returns>
		#endregion
	

		/// <summary>
		/// Checks for java stack trace information and appends it to Exception.StackTrace property if found.
		/// </summary>
		/// <param name="ex">The exception.</param>
		/// <returns>ex.StackTrace, plus additional stack trace from the underlying java exception, if found.</returns>
		public static string GetCompleteStackTrace(Exception ex)
		{
			string completeStackTrace = string.Empty;

			completeStackTrace = ex.StackTrace;

			MethodInfo method = ex.GetType().GetMethod("getStackTraceAsString"); 
			
			if (method != null)
			{
				completeStackTrace += System.Environment.NewLine + System.Environment.NewLine;
				completeStackTrace += "Server Stack Trace: " + System.Environment.NewLine + System.Environment.NewLine;
				completeStackTrace += (string)method.Invoke(ex,new object[]{});
			}

			//get any inner exceptions too
			if( null != ex.InnerException )
			{
				completeStackTrace = GetCompleteStackTrace( ex.InnerException ) + System.Environment.NewLine + "----" + System.Environment.NewLine + completeStackTrace;
			}

			return completeStackTrace;
		}

        /// <summary>
        /// Find the message associated with the exception
        /// </summary>
        /// <param name="exception"></param>
        /// <returns></returns>
        public static string FindMessage(Exception exception)
        {
            if (!string.IsNullOrEmpty(exception.Message) || exception.InnerException == null)
            {
                return exception.Message;
            }
            return FindMessage(exception.InnerException);
        }


       

		#endregion

		#region private static helper methods

		#region XML::DOC
		/// <summary>
		/// Converts the given string type to controller exception enumeration type.
		/// returns null if it cannot find
		/// </summary>
		/// <param name="type"></param>
		/// <param name="Value"></param>
		/// <returns></returns>
		#endregion
		private static object StringToEnum(Type type, string Value)
		{
			foreach ( FieldInfo fi in type.GetFields() )
				if ( fi.Name == Value )
					return fi.GetValue( null );    // We use null because enumeration values are static

			return null;
		}

		#endregion
	}
}