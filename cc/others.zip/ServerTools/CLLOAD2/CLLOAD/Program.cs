﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using iManage.Logging;

using System.Net;
using System.Web.Script;
using System.Web.Script.Serialization;
using CLLOAD.Entities;
using CLLOAD.Helpers;

namespace CLLOAD
{
    class Program
    {

        private enum logMaskVals
        {
            none = 0,
            info = 1,             
            warn = 2,
            error = 4,
            debug = 8
        }

        private enum ValidateFieldSpecifiersStatus
        {
            OK,
            WrongNumberOfFieldsForParentChild,
            WrongNumberOfFields,
            ParentIDMustBeSpecified,
            ChildIDMustBeSpecified,
            IDMustBeSpecified,
            TooManyFields,
            DisregardOverMinimum
        }

        private enum ValidateDelimiterStatus
        {
            OK,
            DelimiterWasDoubleQuotation,
            DelimiterWasTooLarge
        }

        private const int FIELD_SPECIFIER_PARENT_ID = 0;
        private const int FIELD_SPECIFIER_CHILD_ID = 4;

        private const int FIELD_SPECIFIER_ID = 0;

        private const int FIELD_SPECIFIERS_COUNT_MINIMUM = 4;
        private const int FIELD_SPECIFIERS_COUNT_PARENT_CHILD = 8;

        private const int FIELD_NOT_SPECIFIED = -1;

        private static string[] validCustomData = { "custom1", "custom2", "custom3", "custom4", "custom5", "custom6", "custom7", "custom8", "custom9", "custom10", "custom11", "custom12", "custom29", "custom30" };

        static void printUsage()
        {
            Console.WriteLine("CLLOAD can be used load data into custom tables in two ways:");
            Console.WriteLine("Method 1:");
            
            Console.WriteLine("clload </server:servername userid password> </db:databasename> </file:filename>");
            Console.WriteLine(" [/table:name] [/parentAlias:parentalias] [/overwrite:flag] [/childflag:flag] [/logmask:level]");
            Console.WriteLine(" [/format:[\"[delimiter]\"][column1 column2 column3 column4 [column5 column6 column7 column8]]");
            Console.WriteLine("/server:      specify the server name, login id and password");
            Console.WriteLine("/db:          specify the database name");
            Console.WriteLine("/file:        filename for importing data");
            Console.WriteLine("/table:       specify the table name which the data is loaded into CUSTOM1 to CUSTOM30 value of table must be present either as a part of parameter or should be avilable in csv(input file).");
            Console.WriteLine("/parentAlias: specify the parent alias for child custom table");
            Console.WriteLine("              required for CUSTOM2 and CUSTOM30, ignored for others");
            Console.WriteLine("/overwrite:   overwrite description field or not if alias exits. Must be Y or N. Default N");
            Console.WriteLine("/childflag:   load only parent table or both parent and child table");
            Console.WriteLine("              Y for both and N for parent table only. Default Y");
            Console.WriteLine("/logmask:   info or warn or error or debug level of logging");
            Console.WriteLine("/format:      corresponding file column data to table fields");
            Console.WriteLine(" delimiter:   delimiter column, default to ,");
            Console.WriteLine(" column1:     column number for custom alias field, default to 1");
            Console.WriteLine(" column2:     column number for custom description field, default to 2");
            Console.WriteLine(" column3:     column number for custom enable flag, default to 3");
            Console.WriteLine(" column4:     column number for custom hipaa flag, default to 4");
            Console.WriteLine(" column5:     column number for custom child alias field, default to 5");
            Console.WriteLine(" column6:     column number for custom child description field, default to 6");
            Console.WriteLine(" column7:     column number for custom child enable flag, default to 7");
            Console.WriteLine(" column8:     column number for custom child hipaa flag, default to 8");
            Console.WriteLine("              set a column number value to -1 to indicate that no column should populate the field");
            Console.WriteLine("Method 2:");
            Console.WriteLine("  [/overwrite:flag] [/childflag:flag] [/logmask:level]");
            Console.WriteLine(" [/format:[\"[delimiter]\"][column3 column4 column5 column6 [column7 column8 column9 column10]]");
            Console.WriteLine("/server:      specify the server name, login id and password");
            Console.WriteLine("/db:          specify the database name");
            Console.WriteLine("/file:        filename for importing data");
            
            
            Console.WriteLine("/overwrite:   overwrite description field or not if alias exits. Must be Y or N. Default N");
            Console.WriteLine("/childflag:   load only parent table or both parent and child table");
            Console.WriteLine("              Y for both and N for parent table only. Default Y");
            Console.WriteLine("/logmask:   info or warn or error or debug level of logging");
            Console.WriteLine("/format:      corresponding file column data to table fields");
            Console.WriteLine(" delimiter:   delimiter column, default to ,");
            Console.WriteLine(" column1:     This column will be table name of the custom data");
            Console.WriteLine(" column2:     Present only if column 1 is CUSTOM2 or CUSTOM 29 and indicates the parent custom alias value to add this to");
            Console.WriteLine(" column3:     column number for custom alias field, default to 1");
            Console.WriteLine(" column4:     column number for custom description field, default to 2");
            Console.WriteLine(" column5:     column number for custom enable flag, default to 3");
            Console.WriteLine(" column6:     column number for custom hipaa flag, default to 4");
            Console.WriteLine(" column7:     column number for custom child alias field, default to 5");
            Console.WriteLine(" column8:     column number for custom child description field, default to 6");
            Console.WriteLine(" column9:     column number for custom child enable flag, default to 7");
            Console.WriteLine(" column10:     column number for custom child hipaa flag, default to 8");
            Console.WriteLine("              set a column number value to -1 to indicate that no column should populate the field");

        }

        static string tokenize(string arg, char delimiter, bool reverse)
        {
            try
            {
                if (!reverse)
                {
                    int start = arg.IndexOf(delimiter) + 1;
                    int length = arg.Length;
                    return (arg.Substring(start, length - start));
                }
                else
                {
                    int start = arg.IndexOf(delimiter);
                    return (arg.Substring(0, start));
                }
            }
            catch
            {
                return null;
            }
        }

       
        static bool getBool(string val)
        {
            if (val == "Y")
            {
                return true;
            }
            else
            {
                return false;
            }
        }

      

        static void Main(string[] args)
        {
            LogHelper.SetLoglevel("info");
            LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Main started- Check date");
            
            LoginEntity logEntity = new LoginEntity();
            String serverName = null;

            
            try
            {
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                //Required fields           
              //  ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(delegate { return true; });

                ServicePointManager.ServerCertificateValidationCallback = CertificateValidationCallBack;

                String userID = null;
                String password = null;
                String databaseName = null;
                String file = null;
                String table = null;
                bool bValid = true;
                bool tableDefined = false;

                //Optional fields with defaults
                String parentAlias = null;
                String overwrite = "N";
                String childFlagToken = "Y";
                bool childFlag = getBool(childFlagToken);
                String delimiter = ",";
                List<int> fields = new List<int>();
                for (int c = 1; c <= FIELD_SPECIFIERS_COUNT_PARENT_CHILD; c++)
                {
                    fields.Add(c); //Set default field specifiers 1-8                
                }
                bool parserErrorFlag = false;
                



                LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "*** BEGIN RUN ***");
            

                //Command parser
                int i = 0;
                String curArg;
                List<int> fieldsRead = new List<int>();
                do
                {
                    try
                    {
                        curArg = tokenize(args[i], ':', true).ToUpper();
                        switch (curArg)
                        {
                            case "/SERVER":
                                serverName = tokenize(args[i], ':', false);
                                userID = WadeNextArgument(args, ref i);
                                password = WadeNextArgument(args, ref i);
                                break;
                            case "/DB":
                                databaseName = tokenize(args[i], ':', false).ToUpper();
                                break;
                            case "/FILE":
                                file = tokenize(args[i], ':', false);
                                break;
                            case "/TABLE":
                                table = tokenize(args[i], ':', false).ToUpper();
                                break;
                            case "/PARENTALIAS":
                                parentAlias = tokenize(args[i], ':', false).ToUpper();
                                break;
                            case "/OVERWRITE":
                                overwrite = tokenize(args[i], ':', false).ToUpper();
                                break;
                            case "/CHILDFLAG":
                                childFlagToken = tokenize(args[i], ':', false).ToUpper();
                                childFlag = getBool(childFlagToken);
                                break;
                            case "/FORMAT":
                                ParseFormat(args, ref delimiter, ref fieldsRead,   ref i);
                                break;
                            case "/LOGMASK":
                                string level = tokenize(args[i], ':', false).ToLower();
                                if (level == "info" || level == "all" || level == "debug" || level=="error" || level=="warn")
                                {
                                    LogHelper.SetLoglevel(level);
                                    
                                    LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Log level set to " + level.ToString());
                                }
                                break;
                            default:
                                LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Unrecognized value " + curArg);
                                
                                printUsage(); //Unknown entry, so print usage and bail out
                                return;
                        }
                        i++;
                    }
                    catch
                    {
                        parserErrorFlag = true;
                    }
                }
                while (i < args.Length && !parserErrorFlag);

                if (parserErrorFlag)
                {
                    LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Parser error.");
                    
                    printUsage();
                    return;
                }

                // Check that the user ID is correctly specified.
                if (String.IsNullOrEmpty(userID))
                {
                    ReportUsageError( "A user ID must be specified with the /server switch.");
                    return;
                }

                // Check that the password is correctly specified.
                if (String.IsNullOrEmpty(password))
                {
                    ReportUsageError("A password must be specified with the /server switch.");
                    return;
                }

                // Check that the database is correctly specified.
                if (String.IsNullOrEmpty(databaseName))
                {
                    ReportUsageError( "A database name must be specified with the /db switch.");
                    return;
                }

                 

                // Check that the delimiter is correctly specified.
                ValidateDelimiterStatus validateDelimiterStatus = ValidateDelimiter(delimiter);
                if (validateDelimiterStatus != ValidateDelimiterStatus.OK)
                {
                    string delimiterValidationErrorMessage = GetDelimiterValidationErrorMessage(validateDelimiterStatus);
                    ReportUsageError( delimiterValidationErrorMessage);
                    return;
                }

              
                LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Server Name = " + serverName);
                LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Database = " + databaseName);
                LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Table = " + table);
                LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "File = " + file);
                LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "ParentAlias = " + parentAlias);
                LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Overwrite = " + overwrite);
                LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "ChildFlag = " + childFlagToken);
                LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Delimiter = " + delimiter);

                //Open specified data file
                StreamReader reader;
                try
                {
                    reader = new StreamReader(File.OpenRead(file));
                    LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Data file successfully opened.");
                }
                catch (Exception e)
                {
                    LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Unable to access file " + file + ":" + e.Message);
                    
                    return;
                }

                //Login to WorkSite and get the specified DB
                
                LoginHelper helper = new LoginHelper();
                logEntity = helper.Login(userID, password, serverName);
                if (logEntity.AuthToken == null || logEntity.AuthToken.Trim().Length == 0)
                {
                    DualReport( "Could not log into WorkSite server.");
                    
                    return;
                }



                int maximumFieldSpecifier = 0;
                if (!string.IsNullOrEmpty(table))
                {
                    tableDefined = true;
                    //Make call here to API to insert values                 
                    
                    bValid = validateTable(table);
                    if (!bValid) //This will be true if table name is invalid since function returns a zero
                    {
                        LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Invalid table name specified " + table);

                        printUsage();
                        return;
                    }

                    fields= ValidateChildFlagAndfieldSpecifiers(table, ref childFlag,ref maximumFieldSpecifier, fieldsRead);

                    if (fields.Count() < FIELD_SPECIFIERS_COUNT_PARENT_CHILD && childFlag && TableCanBeParent(table)) //Must have eight field specifiers if childFlag = Y
                    {
                        LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Not enough field specifiers for childFlag with CUSTOM1/CUSTOM2.");

                        printUsage();
                        return;
                    }

                    if ((table == "CUSTOM2" || table == "CUSTOM30") && parentAlias == null) //parentAlias is required if table is a child table
                    {
                        LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "parentAlias missing.");

                        printUsage();
                        return;
                    }

                }


                bValid = validateDatabase(databaseName, serverName, logEntity.AuthToken);
                if (!bValid) //This will be true if table name is invalid since function returns a zero
                {
                    LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Either the database is invalid or the user does not have access to the database" + databaseName);
                    
                    printUsage();
                    return;
                }
                //Main file read loop
                
                int Counter = 0;
                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();
                    if (!String.IsNullOrWhiteSpace(line))
                    {
                        string[] tempStringArray = line.Split(delimiter[0]);
                        string tempString;
                        List<string> myList = new List<string>();
                        bool found = false;
                        int startindex = 0;
                        bool defaultChildFlag = childFlag;
                        if (!tableDefined)
                        {
                            table = null;
                            parentAlias = null;
                            bValid = validateTable(tempStringArray[0].ToUpper());
                                if (!bValid) //This will be true if table name is invalid since function returns a zero
                                {
                                  LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Invalid table name specified " + table);

                                  //  printUsage();
                                  continue;
                                }
                                else
                                {
                                    table = tempStringArray[0].ToUpper();
                                    // Disregard the child flag if the table given can't be a parent.
                                    
                                      //  childFlag = TableCanBeParent(table);
                                   

                                }
                                if (tempStringArray.Length < 8)
                                {
                                    childFlag = false;
                                }
                                else
                                {

                                    childFlag = defaultChildFlag;
                                }
                                maximumFieldSpecifier = 0;
                                fields = ValidateChildFlagAndfieldSpecifiers(table, ref childFlag,ref maximumFieldSpecifier, fieldsRead);
                               


                                if (fields.Count() < FIELD_SPECIFIERS_COUNT_PARENT_CHILD && childFlag && TableCanBeParent(table)) //Must have eight field specifiers if childFlag = Y
                                {
                                    LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Not enough field specifiers for childFlag with CUSTOM1/CUSTOM2.");

                                    continue;

                                }
                            startindex = 1;
                            if ((table == "CUSTOM2" || table == "CUSTOM30")) //parentAlias is required if table is a child table
                            {
                                parentAlias = tempStringArray[1].ToUpper();
                                startindex = 2;
                                string parentTable = "custom1";
                                if (table.ToLower() == "custom30")
                                    parentTable = "custom29";
                                CustomDataEntity parentCustom = GetParentCustomValue(parentTable, parentAlias, databaseName, logEntity.AuthToken, serverName);
                                if (parentCustom.id == null || parentCustom.id.Trim().Length == 0)
                                {
                                    LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "parentAlias is Invalid.");
                                    continue;
                                }                               
                            }
                            
                        }

                        for (int i2 = startindex; i2 < tempStringArray.Length; i2++)
                        {
                            if (i2 < tempStringArray.Length - 1 && tempStringArray[i2].Length > 0 && tempStringArray[i2][0] == '"')
                            {
                                tempString = tempStringArray[i2].Substring(1, tempStringArray[i2].Length - 1);

                                for (int i3 = i2 + 1; i3 < tempStringArray.Length; i3++)
                                {
                                    if (tempStringArray[i3][tempStringArray[i3].Length - 1] == '"')
                                    {
                                        tempString = tempString + "," + tempStringArray[i3].Substring(0, tempStringArray[i3].Length - 1);
                                        i2 = i3;
                                        found = true;
                                        break;
                                    }
                                    else
                                    {
                                        tempString = tempString + "," + tempStringArray[i3];
                                    }
                                }
                                if (!found)
                                {
                                    tempString = tempStringArray[i2];
                                }
                                found = false;
                            }
                            else
                            {
                                tempString = tempStringArray[i2];
                            }
                            if ((tempString.Length > 0) && tempString[0] == '"' && tempString[tempString.Length - 1] == '"')
                            {
                                myList.Add(tempString.Substring(1, tempString.Length - 2));
                            }
                            else
                            {
                                myList.Add(tempString);
                            }
                        }
                        String[] values = myList.ToArray();

                        if (values.Length < maximumFieldSpecifier)
                        {
                            LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Invalid field format in file--verify that all fields are present:");
                            LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, line);
                            
                            return;
                        }

                        //Do not do anything here, let the custom value be string make it lower may be


                        string aliasVal = values[fields[0] - 1]; //Get required parent field values
                        string descVal = "";
                        if (fields[1] != -1)  //If field specifier for description is -1, then leave description blank
                        {
                            descVal = values[fields[1] - 1];
                        }
                        bool enabledVal = true;
                        if (fields[2] != -1) //If field specifier for enabled flag is -1, then leave as default
                        {
                            enabledVal = getBool(values[fields[2] - 1]);
                        }
                        bool HIPAAVal = false;
                        if (fields[3] != -1) //If field specifier for HIPAA flag is -1, then leave as default
                        {
                            HIPAAVal = getBool(values[fields[3] - 1]);
                        }

                        if (parentAlias == null && (table.ToLower() != "custom2" || table.ToLower() != "custom30"))
                        {
                            CustomDataEntity parentCustom = GetParentCustomValue(table, aliasVal, databaseName, logEntity.AuthToken, serverName);
                            if (parentCustom.id == null || parentCustom.id.Trim().Length == 0)
                            {
                                PostNewParentCustomData(table, aliasVal, descVal, enabledVal, HIPAAVal, databaseName, logEntity.AuthToken, serverName);
                            }
                            else
                            {
                                if (overwrite == "Y")
                                {
                                    //Check with Nancy if they want to update isHipaa or enabled
                                    if (descVal.ToLower() != parentCustom.Description.ToLower() || HIPAAVal != parentCustom.hipaa || enabledVal != parentCustom.enabled)
                                        UpdateParentCustomData(table, aliasVal, descVal, enabledVal, HIPAAVal, databaseName, logEntity.AuthToken, serverName);
                                }

                            }

                        }
                        else
                        {
                            string parentTable = "custom1";
                            if (table.ToLower() == "custom30")
                                parentTable = "custom29";
                            //childAliasVal, aliasVal, table, childTable, databaseName, logEntity.AuthToken, serverName
                            HandleChildCustomData(aliasVal, parentAlias, parentTable, table, descVal, enabledVal, HIPAAVal, databaseName, logEntity.AuthToken, serverName, overwrite);

                        }

                        if ((table.ToLower() == "custom1" || table.ToLower() == "custom29") && childFlag)
                        {
                            string childTable;
                            if (table.ToLower() == "custom1")
                            {
                                childTable = "custom2";
                            }
                            else
                            {
                                childTable = "custom30";
                            }
                            string childAliasVal = values[fields[4] - 1];
                            string childDescVal = "";
                            if (fields[5] != -1)  //If field specifier for description is -1, then leave description blank
                            {
                                childDescVal = values[fields[5] - 1];
                            }
                            bool childEnabledVal = true;
                            if (fields[6] != -1) //If field specifier for enabled flag is -1, then leave as default
                            {
                                childEnabledVal = getBool(values[fields[6] - 1]);
                            }
                            bool childHIPAAVal = false;
                            if (fields[7] != -1) //If field specifier for HIPAA flag is -1, then leave as default
                            {
                                childHIPAAVal = getBool(values[fields[7] - 1]);
                            }

                            HandleChildCustomData(childAliasVal, aliasVal, table, childTable, childDescVal, childEnabledVal, childHIPAAVal, databaseName, logEntity.AuthToken, serverName, overwrite);


                        }
                    }
                    Counter++;
                    if ((Counter % 10) == 0)
                    {
                        LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, Counter.ToString() + " entries processed.");
                    }
                }
                LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, Counter.ToString() + " entries processed.");
                LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "*** END RUN ***");
            }
            catch(Exception ex)
            {
                LogHelper.PublishException(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, ExceptionType.Errors,ex,"in Main");
                
                
            }
            finally
            {
                
                if (logEntity != null && logEntity.AuthToken != null && logEntity.AuthToken.Trim().Length > 0 && serverName != null && serverName.Trim().Length > 0)
                    LogOff(logEntity.AuthToken,serverName);
                
            }
            LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "*** END RUN *** - Check date");
        }

        private static List<int> ValidateChildFlagAndfieldSpecifiers(string table, ref bool childFlag,ref int maximumFieldSpecifier, List<int> fieldsRead)
        {
            List<int> fields = new List<int>();
            // Disregard the child flag if the table given can't be a parent.
            if (!TableCanBeParent(table))
            {
                childFlag = false;
            }

            // Check if a set of field specifiers was read from the command line.
            if (fieldsRead.Count > 0)
            {
                // Make sure that all required field specifiers have been specified.
                ValidateFieldSpecifiersStatus validateFieldSpecifiersStatus = ValidateFieldSpecifiers(fieldsRead, childFlag);
                if (validateFieldSpecifiersStatus == ValidateFieldSpecifiersStatus.OK)
                {
                    // The fields can be used just as they are.
                    fields = fieldsRead;
                }
                else if (validateFieldSpecifiersStatus == ValidateFieldSpecifiersStatus.DisregardOverMinimum)
                {
                    // The any field specifiers beyond the minimum number should be disregarded.
                    fields = fieldsRead.GetRange(0, FIELD_SPECIFIERS_COUNT_MINIMUM);
                }
                else
                {
                    string fieldValidationErrorMessage = GetFieldValidationErrorMessage(validateFieldSpecifiersStatus);
                    ReportUsageError(fieldValidationErrorMessage);
                    return fields;
                }
            }
            else
            {
                // A set of default specifiers should be used.
                fields = CreateDefaultFieldSpecifiers(childFlag);
            }

            foreach (int fieldSpecifier in fields)
            {
                if (fieldSpecifier > maximumFieldSpecifier)
                {
                    maximumFieldSpecifier = fieldSpecifier;
                }
            }
            return fields;
        }

        private static bool validateDatabase(string databaseName, string serverName, string authToken)
        {
            bool bValid = false;
            LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Vaidating database " + databaseName);
            try
            {

                string URL = serverName + ServiceURL.operations_url.Replace("{libraryId}", databaseName).Replace("{customerId}", ServiceURL.customer_id);
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(URL);
                request.Method = "GET";
                request.Headers.Add("X-Auth-Token", authToken);

                JavaScriptSerializer jSerialize = new JavaScriptSerializer();


                WebResponse webResponse = request.GetResponse();
                Stream webStream = webResponse.GetResponseStream();
                StreamReader responseReader = new StreamReader(webStream);
                string responseData = responseReader.ReadToEnd();
                responseReader.Close();
                OperationsEntity operations = jSerialize.Deserialize<OperationsEntity>(responseData);

                if (operations != null && operations.data != null )
                {
                    bValid = true;
                    
                }
                
                    

            }
            catch(Exception ex)
            {
                LogHelper.PublishException(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType,ExceptionType.Errors,ex,"In validateDatabase");
                

                bValid = false;
            }
            LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Vaidated database and the result is " + bValid.ToString());
            return bValid;
        }

        private static void LogOff(string authToken,string serverName)
        {
            LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "LOgging off server " + serverName);
            try
            {
                string logoffUrl = ServiceURL.logout_url;
                string URL = serverName + logoffUrl;
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(URL);
                request.Method = "GET";
                request.Headers.Add("X-Auth-Token", authToken);

                JavaScriptSerializer jSerialize = new JavaScriptSerializer();


                WebResponse webResponse = request.GetResponse();
                Stream webStream = webResponse.GetResponseStream();
                StreamReader responseReader = new StreamReader(webStream);
                string responseData = responseReader.ReadToEnd();
                responseReader.Close();
                

            }
            catch(Exception ex)
            {
                LogHelper.PublishException(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, ExceptionType.Errors, ex, "in Logoff");
                


            }
            LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Logged off successfully");
        }

        private static void HandleChildCustomData(string aliasVal, string parentAlias, string parentTable, string childTable, string childDescVal,bool childEnabledVal,bool childHIPAAVal, string databaseName, string authToken, string serverName,string overwrite)
        {
            LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "HAndling child " + aliasVal + " for parent" + parentAlias);
            try
            {
                LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Getting child " + aliasVal + " for parent" + parentAlias);
                CustomDataEntity childCustom = GetChildCustomValue(aliasVal, parentAlias, parentTable, childTable, databaseName, authToken, serverName);
                if (childCustom.id == null || childCustom.id.Trim().Length == 0)
                {
                    LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Posting a new  child " + aliasVal + " for parent" + parentAlias);
                    //POST
                    PostNewChildCustomData(aliasVal, parentAlias, parentTable, childTable, childDescVal, childEnabledVal, childHIPAAVal, databaseName, authToken, serverName);
                }
                else
                {
                    if (overwrite.ToLower() == "y")
                    {
                        if (childDescVal.ToLower() != childCustom.Description.ToLower() || childHIPAAVal != childCustom.hipaa || childEnabledVal != childCustom.enabled)
                        {
                            //PUT
                            LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Updating child " + aliasVal + " for parent" + parentAlias);
                            UpdateChildCustomData(aliasVal, parentAlias, parentTable, childTable, childDescVal, childEnabledVal, childHIPAAVal, databaseName, authToken, serverName);
                        }
                        else
                            LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Nothing changed so not updating");
                    }
                    else
                        LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Overwrite set to NO so not overwriting");
                }
            }
            catch(Exception ex)
            {
                LogHelper.PublishException(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, ExceptionType.Errors, ex, "in Handle custom data");
                
            }
            LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Handled child " + aliasVal + " for parent" + parentAlias);
        }

        private static void UpdateChildCustomData(string childAlias, string parentAlias, string parentTable, string childTable, string childDescVal, bool childEnabledVal, bool childHIPAAVal, string databaseName, string authToken, string serverName)
        {
            LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Update child " + childAlias + " for parent" + parentAlias);
            try
            {
                string post_url = ServiceURL.post_custom_data_url.Replace("{custom_table}", childTable.ToLower()).Replace("{libraryId}", System.Web.HttpUtility.UrlEncode(databaseName)).Replace("{customerId}", ServiceURL.customer_id);
                string URL = serverName + post_url;
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(URL);
                request.Method = "PUT";
                request.Headers.Add("X-Auth-Token", authToken);
                Dictionary<string, object> keyvaluePair = new Dictionary<string, object>();
                
                keyvaluePair.Add("description", childDescVal);
                keyvaluePair.Add("enabled", childEnabledVal);
                keyvaluePair.Add("hipaa", childHIPAAVal);
                keyvaluePair.Add("id", childAlias);
                CustomDataEntity parent = new CustomDataEntity();
                parent.id = parentAlias;
                keyvaluePair.Add("parent", parent);
                keyvaluePair.Add("wstype", childTable.ToLower());
                JavaScriptSerializer jSerialize = new JavaScriptSerializer();
                string body = jSerialize.Serialize(keyvaluePair);
                request.ContentType = "application/json";
                request.ContentLength = body.Length;
                StreamWriter requestWriter = new StreamWriter(request.GetRequestStream(), System.Text.Encoding.ASCII);
                requestWriter.Write(body);
                requestWriter.Close();

                WebResponse webResponse = request.GetResponse();
                Stream webStream = webResponse.GetResponseStream();
                StreamReader responseReader = new StreamReader(webStream);
                string responseData = responseReader.ReadToEnd();
                responseReader.Close();
            }
            catch(Exception ex)
            {
                LogHelper.PublishException(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, ExceptionType.Errors, ex, "In UpdateChildCustomData");
                
            }
            LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Updated child " + childAlias + " for parent" + parentAlias);

        }

        private static void PostNewChildCustomData(string childAlias, string parentAlias, string parentTable, string childTable, string childDescVal, bool childEnabledVal, bool childHIPAAVal, string databaseName, string authToken, string serverName)
        {
            LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Adding child " + childAlias + " for parent" + parentAlias);
            try
            {
                string post_url = ServiceURL.post_custom_data_url.Replace("{custom_table}", childTable.ToLower()).Replace("{libraryId}", System.Web.HttpUtility.UrlEncode(databaseName)).Replace("{customerId}", ServiceURL.customer_id);
                string URL = serverName + post_url;
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(URL);
                request.Method = "POST";
                request.Headers.Add("X-Auth-Token", authToken);
                Dictionary<string, object> keyvaluePair = new Dictionary<string, object>();
                
                keyvaluePair.Add("description", childDescVal);
                keyvaluePair.Add("enabled", childEnabledVal);
                keyvaluePair.Add("hipaa", childHIPAAVal);
                keyvaluePair.Add("id", childAlias);
                CustomDataEntity parent = new CustomDataEntity();
                parent.id = parentAlias;
                keyvaluePair.Add("parent", parent);
                keyvaluePair.Add("wstype", childTable.ToLower());
                JavaScriptSerializer jSerialize = new JavaScriptSerializer();
                string body = jSerialize.Serialize(keyvaluePair);
                request.ContentType = "application/json";
                request.ContentLength = body.Length;
                StreamWriter requestWriter = new StreamWriter(request.GetRequestStream(), System.Text.Encoding.ASCII);
                requestWriter.Write(body);
                requestWriter.Close();

                WebResponse webResponse = request.GetResponse();
                Stream webStream = webResponse.GetResponseStream();
                StreamReader responseReader = new StreamReader(webStream);
                string responseData = responseReader.ReadToEnd();
                responseReader.Close();

            }
            catch(Exception ex)
            {
                LogHelper.PublishException(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, ExceptionType.Errors, ex, "in PostNewCustomData");
                

            }
            LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Added child " + childAlias + " for parent" + parentAlias);
        }

        private static CustomDataEntity GetChildCustomValue(string childAliasVal, string parentAlias, string parentTable, string childTable, string databaseName, string authToken, string serverName)
        {
            LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Getting child " + childAliasVal + " for parent" + parentAlias);
            CustomDataEntity customChild = new CustomDataEntity();
            try
            {
                string get_child_custom_url = ServiceURL.search_child_custom_data_url.Replace("{parent_custom_table}", parentTable.ToLower()).Replace("{parent_alias}", parentAlias).Replace("{custom_table}", childTable.ToLower()).Replace("{libraryId}", databaseName).Replace("{customerId}", ServiceURL.customer_id);
                string URL = serverName + get_child_custom_url + "?alias=" + childAliasVal;
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(URL);
                request.Method = "GET";
                request.Headers.Add("X-Auth-Token", authToken);

                JavaScriptSerializer jSerialize = new JavaScriptSerializer();


                WebResponse webResponse = request.GetResponse();
                Stream webStream = webResponse.GetResponseStream();
                StreamReader responseReader = new StreamReader(webStream);
                string responseData = responseReader.ReadToEnd();
                responseReader.Close();
                GenericEntity<CustomDataEntity> listCustoms = jSerialize.Deserialize<GenericEntity<CustomDataEntity>>(responseData);
                if (listCustoms != null && listCustoms.data != null && listCustoms.data.Count > 0)
                    customChild = listCustoms.data[0];

            }
            catch(Exception ex)
            {
                LogHelper.PublishException(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, ExceptionType.Errors, ex, "In GetChildCustomValue");
                

                
            }
            LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "returing child " + childAliasVal + " for parent" + parentAlias);
            return customChild;
        }

        private static void UpdateParentCustomData(string table, string aliasVal, string descVal, bool enabledVal, bool HIPAAVal, string databaseName, string authToken, string serverName)
        {
            LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Updating  parent " + aliasVal);
            try
            {
                string post_url = ServiceURL.post_custom_data_url.Replace("{custom_table}", table.ToLower()).Replace("{libraryId}",System.Web.HttpUtility.UrlEncode(databaseName)).Replace("{customerId}", ServiceURL.customer_id);
                string URL = serverName + post_url;
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(URL);
                request.Method = "PUT";
                request.Headers.Add("X-Auth-Token", authToken);
                Dictionary<string, object> keyvaluePair = new Dictionary<string, object>();
                
                keyvaluePair.Add("description", descVal);
                keyvaluePair.Add("enabled", enabledVal);
                keyvaluePair.Add("hipaa", HIPAAVal);
                keyvaluePair.Add("id", aliasVal);
                keyvaluePair.Add("wstype", table.ToLower());
                JavaScriptSerializer jSerialize = new JavaScriptSerializer();
                string body = jSerialize.Serialize(keyvaluePair);
                request.ContentType = "application/json";
                request.ContentLength = body.Length;
                StreamWriter requestWriter = new StreamWriter(request.GetRequestStream(), System.Text.Encoding.ASCII);
                requestWriter.Write(body);
                requestWriter.Close();

                WebResponse webResponse = request.GetResponse();
                Stream webStream = webResponse.GetResponseStream();
                StreamReader responseReader = new StreamReader(webStream);
                string responseData = responseReader.ReadToEnd();
                responseReader.Close();

            }
            catch(Exception ex)
            {
                LogHelper.PublishException(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, ExceptionType.Errors, ex, "in UpdateParentCustomData");
                

            }
            LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Updated parent " + aliasVal);
        }

        private static void PostNewParentCustomData(string table, string aliasVal, string descVal, bool enabledVal,bool hipaaVal, string databaseName, string authToken, string serverName)
        {
            LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Adding  parent " + aliasVal);
            try
            {
                string post_url = ServiceURL.post_custom_data_url.Replace("{custom_table}", table.ToLower()).Replace("{libraryId}", System.Web.HttpUtility.UrlEncode(databaseName)).Replace("{customerId}", ServiceURL.customer_id);
                string URL = serverName + post_url;
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(URL);
                request.Method = "POST";
                request.Headers.Add("X-Auth-Token", authToken);
                Dictionary<string, object> keyvaluePair = new Dictionary<string, object>();
                
                keyvaluePair.Add("description", descVal);
                keyvaluePair.Add("enabled", enabledVal);
                keyvaluePair.Add("hipaa", hipaaVal);
                keyvaluePair.Add("id", aliasVal);
                keyvaluePair.Add("wstype", table.ToLower());
                JavaScriptSerializer jSerialize = new JavaScriptSerializer();
                string body = jSerialize.Serialize(keyvaluePair);
                request.ContentType = "application/json";
                request.ContentLength = body.Length;
                StreamWriter requestWriter = new StreamWriter(request.GetRequestStream(), System.Text.Encoding.ASCII);
                requestWriter.Write(body);
                requestWriter.Close();

                WebResponse webResponse = request.GetResponse();
                Stream webStream = webResponse.GetResponseStream();
                StreamReader responseReader = new StreamReader(webStream);
                string responseData = responseReader.ReadToEnd();
                responseReader.Close();
               
            }
            catch(Exception ex)
            {
                LogHelper.PublishException(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, ExceptionType.Errors, ex, "In PostNewParentCustomData");
                

            }
            LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Added  parent " + aliasVal);
        }

        private static CustomDataEntity GetParentCustomValue(string table, string aliasVal, string databaseName, string authToken,string serverName)
        {
            LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Getting  parent " + aliasVal);
            CustomDataEntity customentity = new CustomDataEntity();
            customentity.id = string.Empty;
            try
            {
                string search_url = ServiceURL.search_custom_data_url.Replace("{custom_table}", table.ToLower()).Replace("{libraryId}",System.Web.HttpUtility.UrlEncode(databaseName)).Replace("{customerId}", ServiceURL.customer_id);
                string URL = serverName + search_url + "?alias=" + System.Web.HttpUtility.UrlEncode(aliasVal);
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(URL);
                request.Method = "GET";
                request.Headers.Add("X-Auth-Token", authToken);
               
                JavaScriptSerializer jSerialize = new JavaScriptSerializer();
                
               
                WebResponse webResponse = request.GetResponse();
                Stream webStream = webResponse.GetResponseStream();
                StreamReader responseReader = new StreamReader(webStream);
                string responseData = responseReader.ReadToEnd();
                responseReader.Close();
                GenericEntity<CustomDataEntity> listCustoms =  jSerialize.Deserialize<GenericEntity<CustomDataEntity>>(responseData);
                if (listCustoms != null && listCustoms.data != null && listCustoms.data.Count > 0)
                    customentity = listCustoms.data[0];
            }
            catch(Exception ex)
            {
                LogHelper.PublishException(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, ExceptionType.Errors, ex, "In GetParentCustomValue");
                
            }
            LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Got  parent " + aliasVal);
            return customentity;
        }

        private static bool validateTable(string table)
        {
            return validCustomData.Contains(table.ToLower());
        }

        

        
       
        /// <summary>
        /// ReportUsageError reports an error in the command line parameters to the user, and prints out the usage block for reference.
        /// </summary>
        /// <param name="sWriter">the stream to which to write the error message</param>
        /// <param name="usageErrorMessage">an error message describing the usage error</param>
        /// <param name="logMask">the log mask, containing the current logging level</param>
        private static void ReportUsageError( string usageErrorMessage)
        {
            DualReport( usageErrorMessage);
            
            Console.Error.WriteLine();
            printUsage();
        }

        /// <summary>
        /// DualReport reports an error to both the log and the stderr stream.
        /// </summary>
        /// <param name="sWriter">the stream to which to write the error message</param>
        /// <param name="errorToReport">an error message describing the usage error</param>
        /// <param name="logMask">the log mask, containing the current logging level</param>
        /// <param name="logLevel">the logging level of this message</param>
        private static void DualReport( string errorToReport)
        {
            LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, errorToReport);
            Console.Error.WriteLine(errorToReport);
        }

        /// <summary>
        /// WadeNextArgument attempts to get the next argument for the current switch if it exists and does not encounter the next switch.
        /// </summary>
        /// <param name="args">the command line arguments</param>
        /// <param name="i">the current index into the command line arguments</param>
        /// <returns>the next argument if it exists, or an empty string if it does not</returns>
        private static string WadeNextArgument(string[] args, ref int i)
        {
            string nextArgument = String.Empty;
            int nextArgumentIndex = i + 1;
            if ((nextArgumentIndex < args.Length) && (!args[nextArgumentIndex].StartsWith("/")))
            {
                nextArgument = args[nextArgumentIndex];
                i = nextArgumentIndex;
            }
            return nextArgument;
        }

        /// <summary>
        /// GetFieldValidationErrorMessage returns an error message to report corresponding to a given error status
        /// for field specifier validation.
        /// </summary>
        /// <param name="validateFieldSpecifiersStatus">the status of the field specifier validation</param>
        /// <returns>an error message that explains the error encountered during delimiter validation</returns>
        private static string GetFieldValidationErrorMessage(ValidateFieldSpecifiersStatus validateFieldSpecifiersStatus)
        {
            string fieldValidationErrorMessage = String.Empty;
            switch (validateFieldSpecifiersStatus)
            {
                case ValidateFieldSpecifiersStatus.WrongNumberOfFieldsForParentChild:
                    fieldValidationErrorMessage = "There needs to be eight field specifiers in order to import parent/child records.";
                    break;
                case ValidateFieldSpecifiersStatus.WrongNumberOfFields:
                    fieldValidationErrorMessage = "The number of field specifiers needed to import data into a single table is at least four or none.";
                    break;
                case ValidateFieldSpecifiersStatus.ParentIDMustBeSpecified:
                    fieldValidationErrorMessage = "No data column for the parent lookup ID was specified.";
                    break;
                case ValidateFieldSpecifiersStatus.ChildIDMustBeSpecified:
                    fieldValidationErrorMessage = "No data column for the child lookup ID was specified.";
                    break;
                case ValidateFieldSpecifiersStatus.IDMustBeSpecified:
                    fieldValidationErrorMessage = "No data column for the lookup ID was specified.";
                    break;
                case ValidateFieldSpecifiersStatus.TooManyFields:
                    fieldValidationErrorMessage = "There should not be more than eight fields given for the /format switch.";
                    break;
                default:
                    fieldValidationErrorMessage = String.Empty;
                    break;
            }
            return fieldValidationErrorMessage;
        }


        /// <summary>
        /// GetDelimiterValidationErrorMessage returns an error message to report corresponding to a given error status
        /// for delimiter validation.
        /// </summary>
        /// <param name="validateDelimiterStatus">the status of the delimiter validation</param>
        /// <returns>an error message that explains the error encountered during delimiter validation</returns>
        private static string GetDelimiterValidationErrorMessage(ValidateDelimiterStatus validateDelimiterStatus)
        {
                string delimiterValidationErrorMessage = String.Empty;
                switch(validateDelimiterStatus)
                {
                    case ValidateDelimiterStatus.DelimiterWasDoubleQuotation:
                        delimiterValidationErrorMessage = "The delimiter cannot be a double quotation mark";
                        break;
                    case ValidateDelimiterStatus.DelimiterWasTooLarge:
                        delimiterValidationErrorMessage = "The delimiter can be at most one character long.";
                        break;
                    default:
                        // Do nothing.
                        break;
                }
            return delimiterValidationErrorMessage;
        }

        /// <summary>
        /// CreateDefaultFieldSpecifiers creates the default set of field specifiers based on whether or not child table data is being imported.
        /// </summary>
        /// <param name="childFlag">true if child table data is being imported</param>
        /// <returns>a set of default field specifiers</returns>
        private static List<int> CreateDefaultFieldSpecifiers(bool childFlag)
        {
            List<int> defaultFields = new List<int>();

            // Create a default set of field specifiers.
            int numberOfSpecifiers = FIELD_SPECIFIERS_COUNT_PARENT_CHILD;
            if (childFlag)
            {
                numberOfSpecifiers = FIELD_SPECIFIERS_COUNT_PARENT_CHILD;
            }
            else
            {
                numberOfSpecifiers = FIELD_SPECIFIERS_COUNT_MINIMUM;
            }
            for (int specifierToAdd = 0; specifierToAdd < numberOfSpecifiers; ++specifierToAdd)
            {
                defaultFields.Add(specifierToAdd + 1);
            }

            return defaultFields;
        }

        /// <summary>
        /// ValidateFieldSpecifiers checks to see if all the required field specifiers have been supplied at the command line.
        /// </summary>
        /// <param name="fields">the list of field specifiers; </param>
        /// <param name="childFlag"></param>
        /// <param name="parentAlias"></param>
        /// <returns>true if the required field specifiers are specified</returns>
        private static ValidateFieldSpecifiersStatus ValidateFieldSpecifiers(List<int> fields, bool childFlag)
        {
            ValidateFieldSpecifiersStatus status = ValidateFieldSpecifiersStatus.OK;

            if (fields.Count > FIELD_SPECIFIERS_COUNT_PARENT_CHILD)
            {
                status = ValidateFieldSpecifiersStatus.TooManyFields;
            }
            else
            {
                if (childFlag)
                {
                    if (fields.Count != FIELD_SPECIFIERS_COUNT_PARENT_CHILD)
                    {
                        status = ValidateFieldSpecifiersStatus.WrongNumberOfFieldsForParentChild;
                    }
                    else
                    {
                        if (!FieldSpecified(fields[FIELD_SPECIFIER_CHILD_ID]))
                        {
                            status = ValidateFieldSpecifiersStatus.ChildIDMustBeSpecified;
                        }
                        else if (!FieldSpecified(fields[FIELD_SPECIFIER_PARENT_ID]))
                        {
                            status = ValidateFieldSpecifiersStatus.ParentIDMustBeSpecified;
                        }
                    }

                }
                else
                {
                    if (fields.Count < FIELD_SPECIFIERS_COUNT_MINIMUM)
                    {
                        status = ValidateFieldSpecifiersStatus.WrongNumberOfFields;
                    }
                    else if (!FieldSpecified(fields[FIELD_SPECIFIER_ID]))
                    {
                        status = ValidateFieldSpecifiersStatus.IDMustBeSpecified;
                    }
                    else if (fields.Count != FIELD_SPECIFIERS_COUNT_MINIMUM)
                    {
                        status = ValidateFieldSpecifiersStatus.DisregardOverMinimum;
                    }
                }
            }

            return status;
        }

        /// <summary>
        /// ValidateDelimiter returns a status that indicates whether or not the given delimiter is valid.
        /// </summary>
        /// <param name="delimiter"></param>
        /// <returns></returns>
        private static ValidateDelimiterStatus ValidateDelimiter(string delimiter)
        {
            ValidateDelimiterStatus validateDelimiterStatus = ValidateDelimiterStatus.OK;
            if (String.IsNullOrEmpty(delimiter))
            {
                validateDelimiterStatus = ValidateDelimiterStatus.OK;
            }
            else
            {
                if (delimiter.Length > 1)
                {
                    validateDelimiterStatus = ValidateDelimiterStatus.DelimiterWasTooLarge;
                }
                else if (delimiter.Length == 1)
                {
                    if (delimiter.Equals("\""))
                    {
                        validateDelimiterStatus = ValidateDelimiterStatus.DelimiterWasDoubleQuotation;
                    }
                    else
                    {
                        validateDelimiterStatus = ValidateDelimiterStatus.OK;
                    }
                }
            }

            return validateDelimiterStatus;
        }

        /// <summary>
        /// FieldSpecified checks whether a field specifier value is specified or not.
        /// </summary>
        /// <param name="fieldSpecifierValue">the value of the field specifier to check</param>
        /// <returns>true if the field specifier value indicates that it is specified</returns>
        private static bool FieldSpecified(int fieldSpecifierValue)
        {
            if ((fieldSpecifierValue > 0) && (fieldSpecifierValue != FIELD_NOT_SPECIFIED))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// TableCanBeParent returns true if the table with the given table name can be a parent table
        /// </summary>
        /// <param name="tableName">the name of the table to check whether or not it can be a parent table</param>
        /// <returns>true if the table with the given table name can be a parent table</returns>
        private static bool TableCanBeParent(string tableName)
        {
            bool tableCanBeParent = false;

            if (!String.IsNullOrEmpty(tableName))
            {
                if (tableName.ToUpper() == "CUSTOM1" || tableName.ToUpper() == "CUSTOM29")
                {
                    tableCanBeParent = true;
                }
                else
                {
                    tableCanBeParent = false;
                }
            }
            else
            {
                tableCanBeParent = false;
            }
            return tableCanBeParent;
        }

        private static void ParseFormat(string[] args, ref String delimiter, ref List<int> fields,  ref int i)
        {
            String dm_temp = tokenize(args[i], ':', false);
            if (dm_temp.Substring(0, 1).Equals("\""))
            {
                if (dm_temp.Length == 1)
                {
                    delimiter = dm_temp.Substring(0, 1);
                }
                else
                {
                    delimiter = dm_temp[1].ToString(); //Get specified delimeter and strip any quotes
                }
            }
            else
            {
                delimiter = dm_temp; //No quotes, so just get delimiter as-is
            }

            // Check if the next argument is a switch (there are no field specifiers).
            int numberOfFieldsLeft = args.Length - i; //Check for any field specifiers
            List<int> fieldsRead = new List<int>();
            if (numberOfFieldsLeft > 0)
            {
                LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Parsing, list cleared.");
                bool nonNumberEncountered = false;
                for (int c = i + 1; (c < args.Length) && nonNumberEncountered == false; c++)
                {
                    if (args[c].Substring(0, 1) == "/") //Ensure it's not another switch
                    {
                        nonNumberEncountered = true;
                    }
                    else
                    {
                        int? fieldSpecifier = null;
                        try
                        {
                            fieldSpecifier = Convert.ToInt32(args[c]);
                        }
                        catch
                        {
                            fieldSpecifier = null;
                            nonNumberEncountered = true;
                        }
                        if (fieldSpecifier.HasValue)
                        {
                            fieldsRead.Add(fieldSpecifier.Value); //Add any field specifiers to corresponding int list   
                            LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Parsing, added field value " + Convert.ToInt32(args[c]).ToString());
                            i++;
                        }
                    }
                }
            }
            
            if (fieldsRead.Count == 0) //Reset default field specifiers if we cleared it but then found none
            {
                fields.Clear();
                for (int c = 1; c <= FIELD_SPECIFIERS_COUNT_PARENT_CHILD; c++)
                {
                    fields.Add(c); //Set default field specifiers 1-8
                    LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "List cleared but NOT populated, re-initializing, added field value " + c.ToString());
                }
            }
            else
            {
                fields = fieldsRead;
            }

            LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Count = " + fields.Count().ToString());
        }

        private static bool CertificateValidationCallBack(
       object sender,
       System.Security.Cryptography.X509Certificates.X509Certificate certificate,
       System.Security.Cryptography.X509Certificates.X509Chain chain,
       System.Net.Security.SslPolicyErrors sslPolicyErrors)
        {
            // If the certificate is a valid, signed certificate, return true.
            if (sslPolicyErrors == System.Net.Security.SslPolicyErrors.None)
            {
                return true;
            }

            // If there are errors in the certificate chain, look at each error to determine the cause.
            if ((sslPolicyErrors & System.Net.Security.SslPolicyErrors.RemoteCertificateChainErrors) != 0)
            {
                if (chain != null && chain.ChainStatus != null)
                {
                    foreach (System.Security.Cryptography.X509Certificates.X509ChainStatus status in chain.ChainStatus)
                    {
                        if ((certificate.Subject == certificate.Issuer) &&
                           (status.Status == System.Security.Cryptography.X509Certificates.X509ChainStatusFlags.UntrustedRoot))
                        {
                            // Self-signed certificates with an untrusted root are valid. 
                            continue;
                        }
                        else
                        {
                            if (status.Status != System.Security.Cryptography.X509Certificates.X509ChainStatusFlags.NoError)
                            {
                                // If there are any other errors in the certificate chain, the certificate is invalid,
                                // so the method returns false.
                                return false;
                            }
                        }
                    }
                }

                // When processing reaches this line, the only errors in the certificate chain are 
                // untrusted root errors for self-signed certificates. These certificates are valid
                // for default Exchange server installations, so return true.
                return true;
            }
            else
            {
                // In all other cases, return false.
                return false;
            }
        }

    }
}
