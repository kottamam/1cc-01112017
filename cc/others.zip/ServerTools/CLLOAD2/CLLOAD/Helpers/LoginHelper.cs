﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using CLLOAD.Entities;
using CLLOAD.Utilities;
using iManage.Logging;
namespace CLLOAD.Helpers
{
    class LoginHelper:BasicJsonHandler
    {
        public LoginEntity Login(string username, string password, string serverURL)
        {
            LoginEntity entity = new LoginEntity();
            try
            {
                string url = serverURL + ServiceURL.WorksiteLogin;
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                request.Method = "PUT";
                Dictionary<string, string> keyvaluePair = new Dictionary<string, string>();
                keyvaluePair.Add("user_id", username);
                keyvaluePair.Add("password", password);
                JavaScriptSerializer jSerialize = new JavaScriptSerializer();
                string body = jSerialize.Serialize(keyvaluePair);
                request.ContentType = "application/json";
                request.ContentLength = body.Length;
                StreamWriter requestWriter = new StreamWriter(request.GetRequestStream(), System.Text.Encoding.ASCII);
                requestWriter.Write(body);
                requestWriter.Close();
                WebResponse webResponse = request.GetResponse();
                Stream webStream = webResponse.GetResponseStream();
                StreamReader responseReader = new StreamReader(webStream);
                string responseData = responseReader.ReadToEnd();
                responseReader.Close();

                if (responseData != null && responseData.Trim().Length > 0)
                {

                    Dictionary<string, object> obj = jSerialize.DeserializeObject(responseData) as Dictionary<string, object>;
                    entity.AuthToken = obj["X-Auth-Token"] as string;
                }
                
            }
            catch (Exception ex)
            {
                LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, ex.Message+" "+ex.InnerException);
           
            }
            return entity;
        }
    }
}
