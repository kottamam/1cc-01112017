﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace CLLOAD.Entities
{
    [Serializable]
    public class LoginEntity
    {
        private string _authToken = string.Empty;

        [JsonProperty(PropertyName = "X-Auth-Token")]
        public string AuthToken
        {
            get { return _authToken; }
            set { _authToken = value; }
        }

        private int _max_age = 0;

        public int max_age
        {
            get { return _max_age; }
            set { _max_age = value; }
        }
    }
}
