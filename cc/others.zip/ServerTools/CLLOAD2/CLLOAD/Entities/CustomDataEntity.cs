﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CLLOAD.Entities
{
    class CustomDataEntity
    {
        private string _id = string.Empty;

        public string id
        {
            get { return _id; }
            set { _id = value; }
        }
        private string _description = string.Empty;

        public string Description
        {
            get { return _description; }
            set { _description = value; }
        }

        private bool _hipaa = false;

        public bool hipaa
        {
            get { return _hipaa; }
            set { _hipaa = value; }
        }

        private bool _enabled = true;

        public bool enabled
        {
            get { return _enabled; }
            set { _enabled = value; }
        }

        private string _wstype = string.Empty;

        public string wstype
        {
            get { return _wstype; }
            set { _wstype = value; }
        }


    }
}
