﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CLLOAD.Entities
{
    class OperationsEntity
    {
        private object _data = string.Empty;

        public object data
        {
            get { return _data; }
            set { _data = value; }
        }
    }
}
