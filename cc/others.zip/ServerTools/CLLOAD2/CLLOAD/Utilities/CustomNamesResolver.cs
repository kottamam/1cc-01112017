﻿using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System.Collections.Generic;

namespace CLLOAD.Utilities
{
    public class CustomNamesResolver : DefaultContractResolver
    {
        private Dictionary<string, string> keys;
        public CustomNamesResolver(Dictionary<string, string> OldNewKey) 
        {
            keys = OldNewKey;
        }
        protected override IList<JsonProperty> CreateProperties(System.Type type, MemberSerialization memberSerialization)
        {
            // Let the base class create all the JsonProperties 
            // using the short names
            IList<JsonProperty> list = base.CreateProperties(type, memberSerialization);

            // Now inspect each property and replace the 
            // short name with the real property name
            foreach (JsonProperty prop in list)
            {

                if (keys.ContainsKey(prop.UnderlyingName))
                    prop.PropertyName = keys[prop.UnderlyingName];

                if (prop.PropertyType.IsClass)
                {

                    var nestedObjProperties = base.CreateProperties(prop.PropertyType, memberSerialization);
                    foreach (JsonProperty nestedjProperty in nestedObjProperties)
                    {
                        if (keys.ContainsKey(nestedjProperty.UnderlyingName))
                            nestedjProperty.PropertyName = keys[nestedjProperty.UnderlyingName];
                    }
                }

            }

            return list;
        }
    }
}
