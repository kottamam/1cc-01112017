﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.Web.Script.Serialization;

namespace CLLOAD.Utilities
{
    public class BasicJsonHandler
    {
        /// <summary>
        /// This will provide Json string corresponding to the given Entity. You can override this method if you need
        /// </summary>
        /// <param name="entity">Any Object which we want to convert into JSON  string form</param>
        /// <returns>JSON string</returns>
        public virtual  string SerializeObject(object entity)
        {
            JavaScriptSerializer jSerialize = new JavaScriptSerializer();
            return jSerialize.Serialize(entity);
            
        }


        /// <summary>
        /// Deserialze given JSON string and returns a List of Entities of type T. You can override this method if you need
        /// </summary>
        /// <typeparam name="T">GenericEntity of any type</typeparam>
        /// <param name="JSON">JSON string</param>
        /// <returns>List<GenericEntity></returns>
        public virtual List<T> DeserializeJSON<T>(string JSON)
        {
            JavaScriptSerializer jSerialize = new JavaScriptSerializer();
            List<T> UserObject = jSerialize.Deserialize<List<T>>(JSON);
            return UserObject;
        }

        /// <summary>
        /// Deserialze given JSON string and returns an Entity of type T. You can override this method if you need
        /// </summary>
        /// <typeparam name="T">GenericEntity of any type</typeparam>
        /// <param name="JSON">JSON string</param>
        /// <returns>GenericEntity as Object</returns>
        public virtual object DeserializeJSONString<T>(string JSON)
        {
            JavaScriptSerializer jSerialize = new JavaScriptSerializer();
            T UserObject = jSerialize.Deserialize<T>(JSON);
            return UserObject;
        }


        /// <summary>
        /// Deserialze given JSON string and returns a List of Entities of type T. You can override this method if you need
        /// </summary>
        /// <typeparam name="T">GenericEntity of any type</typeparam>
        /// <param name="JSON">JSON string</param>
        /// <param name="keyChanges">Entity Mapping key's in Business entity and Rest API</param>
        /// <returns>List<GenericEntity></returns>
        public virtual List<T> DeserializeJSON<T>(string JSON, Dictionary<string, string> keyChanges)
        {
            JsonSerializerSettings settings = new JsonSerializerSettings();
            settings.Formatting = Formatting.Indented;
            settings.ContractResolver = new CustomNamesResolver(keyChanges);
            List<T> entity = JsonConvert.DeserializeObject<List<T>>(JSON, settings);
            return entity;
        }
        
         
        /// <summary>
        /// Deserialze given JSON string and returns an Entity of type T. You can override this method if you need
        /// </summary>
        /// <typeparam name="T">GenericEntity of any type</typeparam>
        /// <param name="JSON">JSON string</param>
        /// <param name="keyChanges">Entity Mapping key's in Business entity and Rest API</param>
        /// <returns>GenericEntity as Object</returns>
        public virtual object DeserializeJSONString<T>(string JSON, Dictionary<string, string> keyChanges)
        {
            JsonSerializerSettings settings = new JsonSerializerSettings();
            settings.Formatting = Formatting.Indented;
            settings.ContractResolver = new CustomNamesResolver(keyChanges);
            T entity = JsonConvert.DeserializeObject<T>(JSON, settings);
            return entity;
        }
        public virtual string JsonSerialize(object obj)
        {
            
            string entity = JsonConvert.SerializeObject(obj);
            return entity;
        }
    }
}
