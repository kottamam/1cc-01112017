﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CLLOAD
{
    static class ServiceURL
    {
        public const string WorksiteLogin = "/api/v1/session/login";
        public const string search_custom_data_url = "/api/v2/customers/{customerId}/libraries/{libraryId}/customs/{custom_table}/search";
        public const string post_custom_data_url = "/api/v2/customers/{customerId}/libraries/{libraryId}/customs/{custom_table}";
        public const string search_child_custom_data_url = "/api/v2/customers/{customerId}/libraries/{libraryId}/customs/{parent_custom_table}/{parent_alias}/{custom_table}/search" ;
        public const string post_child_custom_data_url = "/api/v1/customs/{{childtable}}";
        public const string logout_url = "/api/v1/session/logout";
        public const string operations_url = "/api/v2/customers/{customerId}/libraries/{libraryId}/operations";
        public const string customer_id = "imanage";
    }
}
