#if !defined(AFX_JDBCSOURCE_H__8DFAF4F3_B00B_11D4_8C39_00C04F0935D0__INCLUDED_)
#define AFX_JDBCSOURCE_H__8DFAF4F3_B00B_11D4_8C39_00C04F0935D0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// JDBCSource.h : header file
//
#include <string>
using namespace std;
/////////////////////////////////////////////////////////////////////////////
// CJDBCSource dialog
class CJDBCSource : public CDialog
{
// Construction
public:
	CJDBCSource(CWnd* pParent = NULL);   // standard constructor
	~CJDBCSource();
	CString strDSNName;
	CString strPassword;
	CString strUserName;
// Dialog Data
	//{{AFX_DATA(CJDBCSource)
	enum { IDD = IDD_SELECT_JDBC };
	CListBox	m_lstDataSource;
	CStringList* pDSNList;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CJDBCSource)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	CObList* dsnList;
	void GetDataSourceList();
	void ParseDataSource(string line);
	void ReplaceChars(string& modifyMe, string findMe);
	// Generated message map functions
	//{{AFX_MSG(CJDBCSource)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnDblclkJdbcList();
	afx_msg void OnSelchangeJdbcList();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_JDBCSOURCE_H__8DFAF4F3_B00B_11D4_8C39_00C04F0935D0__INCLUDED_)
