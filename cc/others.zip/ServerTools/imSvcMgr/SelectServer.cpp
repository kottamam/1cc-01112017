// SelectServer.cpp : implementation file
//

#include "stdafx.h"
#include "imSvcMgr.h"
#include "SelectServer.h"
#include "DomainInfo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern DomainInfoMgr	gDomainInfoMgr;


/////////////////////////////////////////////////////////////////////////////
// SelectServer dialog


SelectServer::SelectServer(CWnd* pParent /*=NULL*/)
	: CDialog(SelectServer::IDD, (CWnd*)pParent)
{
	//{{AFX_DATA_INIT(SelectServer)
	m_Server = _T("");
	//}}AFX_DATA_INIT
	m_Selected.m_TreeItem = NULL;
	bDomainListInitialized = false;
}


void SelectServer::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(SelectServer)
	DDX_Control(pDX, IDC_SELECT_SERVER_TREE, m_TreeCtrl);
//	DDX_Text(pDX, IDC_EDIT_SERVER, m_Server);
	//}}AFX_DATA_MAP
}

BOOL SelectServer::OnInitDialog() 
{
	CDialog::OnInitDialog();
	m_Server = _T("");
	GetDlgItem(IDC_EDIT_SERVER)->SetFocus();
	GetDlgItem(IDC_EDIT_SERVER)->SetWindowText(_T(""));
	GetDlgItem(IDOK)->EnableWindow(0);
	SetDefID(IDCANCEL);

	//domain imange List
	CBitmap bitmap_domain;
	m_domainImagelist.DeleteImageList();
	m_domainImagelist.Create(16, 16, ILC_MASK, 6, 4);
	bitmap_domain.LoadBitmap(IDB_SELECT_SERVER_BM);
	m_domainImagelist.Add(&bitmap_domain, (COLORREF)0xFFFFFF);
	bitmap_domain.DeleteObject();
	bitmap_domain.LoadBitmap(IDB_LEAF_SERVER_BM);
	m_domainImagelist.Add(&bitmap_domain, (COLORREF)0xFFFFFF);
	bitmap_domain.DeleteObject();
	m_TreeCtrl.SetImageList(&m_domainImagelist, TVSIL_NORMAL);

	//Server image List
	CBitmap bitmap_svr;	
	m_svrImagelist.Create(16, 16, ILC_MASK, 6, 4);
	bitmap_svr.LoadBitmap(IDB_SELECT_SERVER_BM);
	m_svrImagelist.Add(&bitmap_svr, (COLORREF)0xFFFFFF);
	bitmap_svr.DeleteObject();
	bitmap_svr.LoadBitmap(IDB_LEAF_SERVER_BM);
	m_svrImagelist.Add(&bitmap_svr, (COLORREF)0xFFFFFF);
	bitmap_svr.DeleteObject();
	m_TreeCtrl.SetImageList(&m_svrImagelist, TVSIL_NORMAL);

	loadDomains();
	return 0;
}

BEGIN_MESSAGE_MAP(SelectServer, CDialog)
	//{{AFX_MSG_MAP(SelectServer)
	ON_NOTIFY(NM_DBLCLK, IDC_SELECT_SERVER_TREE, OnDblclkSelectServerTree)
	ON_NOTIFY(TVN_SELCHANGED, IDC_SELECT_SERVER_TREE, OnSelchangedSelectServerTree)
	ON_EN_CHANGE(IDC_EDIT_SERVER, OnChangeEditServer)
	ON_BN_CLICKED(IDHELP, OnHelp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

void SelectServer::loadDomains()
{
	if (bDomainListInitialized == true)
		return;

	if (gDomainInfoMgr.bInitialized != true)
		return;

	NetResourceList				list;
	NetResourceList::iterator	iter;
	NetResource					*pResource;

	gDomainInfoMgr.getDomainNameList(list);	
	

	TV_INSERTSTRUCT curTreeItem;
	curTreeItem.hInsertAfter = TVI_SORT;
	curTreeItem.item.mask = TVIF_IMAGE | TVIF_TEXT;
	HTREEITEM hItem = NULL;

	for (iter = list.begin(); iter != list.end(); ++iter)
	{
		curTreeItem.hParent = NULL;
		curTreeItem.hInsertAfter = TVI_SORT;
		curTreeItem.item.pszText = (_TCHAR*)(*iter).name.c_str();
		TreeNode aNode;

		aNode.Data = pResource = new NetResource((*iter));
		pResource->bGotInfo = false;

		if (pResource->bContainer == true)
			curTreeItem.item.iImage = 0;
		else
			curTreeItem.item.iImage = 1;

		curTreeItem.item.iSelectedImage = curTreeItem.item.iImage;
		aNode.m_TreeItem = m_TreeCtrl.InsertItem(&curTreeItem);
		m_ParentNodes.AddTail(aNode);
		
		if (!_tcscmp(curTreeItem.item.pszText, _T("NETRIGHT.COM")))
			hItem = aNode.m_TreeItem;
	}

	bDomainListInitialized = true;

	//	Determine the primay domain for this machine and expand its root node
	IM::NrString domainName;

	if (GetPrimaryDomainName(domainName) == false)
		return;

	//	Locate the node at the root level of the tree.
	//	Select it and perform expansion by calling double click
	CList<TreeNode, TreeNode&>& aList = m_ParentNodes;
	POSITION pos = aList.GetHeadPosition();

	while (pos != NULL)
	{
		TreeNode aNode = aList.GetNext(pos);
		m_Selected = aNode;
		loadServers(false);
	}

	if (hItem != NULL)
		m_TreeCtrl.Expand(hItem, TVE_EXPAND );
}

SelectServer::~SelectServer()
{
}

void SelectServer::loadServers(bool bWarn)
{
	if (m_Selected.m_TreeItem == NULL)
		return;

	// attempt to load server for container nodes only
	if (m_TreeCtrl.ItemHasChildren(m_Selected.m_TreeItem) != 0)
		return;

	if (m_Selected.Data == NULL)
		return;

	NetResource	*pNetResource = (NetResource *)m_Selected.Data;

	// if the node is not a container then we are done
	if (pNetResource->bContainer != true)
		return;

	// if we have already loaded information then done
	if (pNetResource->bGotInfo == true)
		return;

	// clean any current leaf information
	if (m_TreeCtrl.ItemHasChildren(m_Selected.m_TreeItem) == 1)
		m_TreeCtrl.DeleteItem(m_Selected.m_TreeItem);

	ServerNameList	serverList;
	bool			bGotInfo;
	const IM::NrCiString aString((_TCHAR*)(LPCTSTR)m_TreeCtrl.GetItemText(m_Selected.m_TreeItem));

	gDomainInfoMgr.getServersInDomain(aString, serverList, bGotInfo);

	if (serverList.empty() && bWarn == true)
	{
		Report(REP_INFO, IDS_SELECT_180);
		return;
	}	

	ServerNameList::iterator i;
	TV_INSERTSTRUCT curTreeItem;
	
	for (i = serverList.begin(); i != serverList.end(); ++i)
	{
		curTreeItem.hInsertAfter = TVI_SORT;
		curTreeItem.item.iImage = 1;
		curTreeItem.item.mask = TVIF_IMAGE| TVIF_SELECTEDIMAGE | TVIF_TEXT;
		curTreeItem.hParent = m_Selected.m_TreeItem;
		curTreeItem.hInsertAfter = TVI_SORT;
		curTreeItem.item.iSelectedImage = curTreeItem.item.iImage;
		curTreeItem.item.pszText = (_TCHAR*)(*i).c_str();
		m_TreeCtrl.InsertItem(&curTreeItem);
	}

	pNetResource->bGotInfo = bGotInfo; 
}

void SelectServer::OnDblclkSelectServerTree(NMHDR* pNMHDR, LRESULT* pResult) 
{
	HTREEITEM anItem = m_TreeCtrl.GetSelectedItem();

	if (anItem != NULL)
	{
		if (!ParentIsPresent(anItem))
		{
			loadServers(true);
			CString aString = m_TreeCtrl.GetItemText(anItem);
			GetDlgItem(IDC_EDIT_SERVER)->SetWindowText(aString);
			m_Server = aString;
			*pResult = 1;
			Changed();
			EndDialog(IDOK);
			return;
		}
	}
	
	*pResult = 0;
}

bool SelectServer::ParentIsPresent(HTREEITEM anItem)
{
	CList<TreeNode, TreeNode&>& aList = m_ParentNodes;
	POSITION pos = aList.GetHeadPosition();

	while (pos != NULL)
	{
		TreeNode aNode = aList.GetNext(pos);

		if (aNode.m_TreeItem == anItem)
			return(true);
	}

	return(false);
}

void SelectServer::OnSelchangedSelectServerTree(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
	HTREEITEM anItem = m_TreeCtrl.GetSelectedItem();

	if (anItem != NULL)
	{
		if (ParentIsPresent(anItem))
			GetDlgItem(IDC_EDIT_SERVER)->SetWindowText(_T(""));
		else
		{
			CString aString = m_TreeCtrl.GetItemText(anItem);
			GetDlgItem(IDC_EDIT_SERVER)->SetWindowText(aString);
			m_Server = aString;
		}

		*pResult = 1;
		Changed();
		return;
	}
	
	*pResult = 0;
}

void SelectServer::Changed() 
{
	CString aString;
	
	GetDlgItem(IDC_EDIT_SERVER)->GetWindowText(aString);

	if (aString != "")
	{
		GetDlgItem(IDOK)->EnableWindow(1);
		SetDefID(IDOK);

		CWnd* aCwnd = GetDlgItem(IDC_EDIT_SERVER);

		if (aCwnd && IsWindow(aCwnd->GetSafeHwnd()))
		{
			GetDlgItem(IDC_EDIT_SERVER)->GetWindowText(aString);
			m_Server = aString;
		}
	}
	else
	{
		GetDlgItem(IDOK)->EnableWindow(0);
		SetDefID(IDCANCEL);
	}
}

void SelectServer::OnChangeEditServer() 
{
	Changed();
}

void SelectServer::OnHelp() 
{
	::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, 13);
}
