#if !defined(AFX_RULESMANAGERPROP_H__3AB92DA4_0EEA_11D4_8BE2_00C04F0935D0__INCLUDED_)
#define AFX_RULESMANAGERPROP_H__3AB92DA4_0EEA_11D4_8BE2_00C04F0935D0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// RulesManagerProp.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CRulesManagerProp dialog

class CRulesManagerProp : public CDialog
{
// Construction
public:
	CRulesManagerProp(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CRulesManagerProp)
	enum { IDD = IDD_DIALOG_RULES_MGR };
	CSpinButtonCtrl	m_ctrlSpinRule;
	long	m_lProcessInt;
	CString	m_smtpServer;
	//}}AFX_DATA

	IM::RulesServiceConfiguration	*m_pService;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRulesManagerProp)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CRulesManagerProp)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnChangeEditProcessInt();
	afx_msg void OnChangeEditSmtpServer();
	afx_msg void OnHelp();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RULESMANAGERPROP_H__3AB92DA4_0EEA_11D4_8BE2_00C04F0935D0__INCLUDED_)

