#include "StdAfx.h"
#include "DSObjectModel.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


namespace DSLocal
{

CDSSyncSvc_AttributeMap::CDSSyncSvc_AttributeMap( void )
:
	m_strMapName( _T( "" ) ),
	m_strOUName( _T( "" ) ),
	m_strUserName( _T( "" ) ),
	m_strUserId( _T( "" ) ),
	m_strUserEmail( _T( "" ) ),
	m_strUserFax( _T( "" ) ),
	m_strUserTelephone( _T( "" ) ),
	m_strUserLocation( _T( "" ) ),
	m_strGroupName( _T( "" ) ),
	m_strGroupId( _T( "" ) ), 
	m_strGroupMember( _T( "" ) ),
	m_strK1SyncId( _T( "" ) )
{
}

CDSSyncSvc_AttributeMap::CDSSyncSvc_AttributeMap( const CDSSyncSvc_AttributeMap& DSSyncSvc_AttributeMap )
{
	*this = DSSyncSvc_AttributeMap;
}

CDSSyncSvc_AttributeMap::~CDSSyncSvc_AttributeMap( void )
{
}

bool CDSSyncSvc_AttributeMap::operator ==( const CDSSyncSvc_AttributeMap& DSSyncSvc_AttributeMap ) const
{
	bool bRetval = false;

	if(
		( _tcsicmp( ( LPCTSTR ) m_strMapName, ( LPCTSTR ) DSSyncSvc_AttributeMap.m_strMapName ) == 0 ) &&
		( _tcsicmp( ( LPCTSTR ) m_strOUName, ( LPCTSTR ) DSSyncSvc_AttributeMap.m_strOUName ) == 0 ) &&
		( _tcsicmp( ( LPCTSTR ) m_strUserName, ( LPCTSTR ) DSSyncSvc_AttributeMap.m_strUserName ) == 0 ) &&
		( _tcsicmp( ( LPCTSTR ) m_strUserId, ( LPCTSTR ) DSSyncSvc_AttributeMap.m_strUserId ) == 0 ) &&
		( _tcsicmp( ( LPCTSTR ) m_strUserEmail, ( LPCTSTR ) DSSyncSvc_AttributeMap.m_strUserEmail ) == 0 ) &&
		( _tcsicmp( ( LPCTSTR ) m_strUserFax, ( LPCTSTR ) DSSyncSvc_AttributeMap.m_strUserFax ) == 0 ) &&
		( _tcsicmp( ( LPCTSTR ) m_strUserTelephone, ( LPCTSTR ) DSSyncSvc_AttributeMap.m_strUserTelephone ) == 0 ) &&
		( _tcsicmp( ( LPCTSTR ) m_strUserLocation, ( LPCTSTR ) DSSyncSvc_AttributeMap.m_strUserLocation ) == 0 ) &&
		( _tcsicmp( ( LPCTSTR ) m_strGroupName, ( LPCTSTR ) DSSyncSvc_AttributeMap.m_strGroupName ) == 0 ) &&
		( _tcsicmp( ( LPCTSTR ) m_strGroupId, ( LPCTSTR ) DSSyncSvc_AttributeMap.m_strGroupId ) == 0 ) &&
		( _tcsicmp( ( LPCTSTR ) m_strGroupMember, ( LPCTSTR ) DSSyncSvc_AttributeMap.m_strGroupMember ) == 0 ) &&
		( _tcsicmp( ( LPCTSTR ) m_strK1SyncId, ( LPCTSTR ) DSSyncSvc_AttributeMap.m_strK1SyncId ) == 0 )
		)
	{
		bRetval = true;
	}

	return bRetval;
}

CDSSyncSvc_AttributeMap& CDSSyncSvc_AttributeMap::operator =( const CDSSyncSvc_AttributeMap& DSSyncSvc_AttributeMap )
{
	m_strMapName = DSSyncSvc_AttributeMap.m_strMapName; 
	m_strOUName = DSSyncSvc_AttributeMap.m_strOUName; 
	m_strUserName = DSSyncSvc_AttributeMap.m_strUserName; 
	m_strUserId = DSSyncSvc_AttributeMap.m_strUserId;
	m_strUserEmail = DSSyncSvc_AttributeMap.m_strUserEmail; 
	m_strUserFax = DSSyncSvc_AttributeMap.m_strUserFax; 
	m_strUserTelephone = DSSyncSvc_AttributeMap.m_strUserTelephone; 
	m_strUserLocation = DSSyncSvc_AttributeMap.m_strUserLocation;
	m_strGroupName = DSSyncSvc_AttributeMap.m_strGroupName; 
	m_strGroupId = DSSyncSvc_AttributeMap.m_strGroupId; 
	m_strGroupMember = DSSyncSvc_AttributeMap.m_strGroupMember; 
	m_strK1SyncId = DSSyncSvc_AttributeMap.m_strK1SyncId;

	return *this;
}






CDSSyncSvc_DSParameters::CDSSyncSvc_DSParameters( void )
:
	m_strServerName( _T( "" ) ),
	m_strUserId( _T( "" ) ),
	m_strPassword( _T( "" ) ),
	m_lServiceType( 0 ),
	m_lTcpipPort( 0 )
{
}

CDSSyncSvc_DSParameters::CDSSyncSvc_DSParameters( const CDSSyncSvc_DSParameters& DSSyncSvc_DSParameters )
{
	// invoke assignment operator
	*this = DSSyncSvc_DSParameters;
}

CDSSyncSvc_DSParameters::~CDSSyncSvc_DSParameters( void )
{
}

bool CDSSyncSvc_DSParameters::operator ==( const CDSSyncSvc_DSParameters& DSSyncSvc_DSParameters ) const
{
	bool bRetval = false;

	if(
		( _tcsicmp( ( LPCTSTR ) m_strServerName, ( LPCTSTR ) DSSyncSvc_DSParameters.m_strServerName ) == 0 ) &&
		( _tcsicmp( ( LPCTSTR ) m_strUserId, ( LPCTSTR ) DSSyncSvc_DSParameters.m_strUserId ) == 0 ) &&
		( _tcsicmp( ( LPCTSTR ) m_strPassword, ( LPCTSTR ) DSSyncSvc_DSParameters.m_strPassword ) == 0 ) &&
		( m_lServiceType == DSSyncSvc_DSParameters.m_lServiceType ) &&
		( m_lTcpipPort == DSSyncSvc_DSParameters.m_lTcpipPort )
		)
	{
		bRetval = true;
	}

	return bRetval;
}

CDSSyncSvc_DSParameters& CDSSyncSvc_DSParameters::operator =( const CDSSyncSvc_DSParameters& DSSyncSvc_DSParameters )
{
	m_strServerName = DSSyncSvc_DSParameters.m_strServerName;
	m_strUserId = DSSyncSvc_DSParameters.m_strUserId;
	m_strPassword = DSSyncSvc_DSParameters.m_strPassword;

	m_lServiceType = DSSyncSvc_DSParameters.m_lServiceType;
	m_lTcpipPort = DSSyncSvc_DSParameters.m_lTcpipPort;

	return *this;
}




CDSSyncSvc_DMSParameters::CDSSyncSvc_DMSParameters( void )
:
	m_strDms( _T( "" ) ),
	m_strLibrary( _T( "" ) ),
	m_strUserId( _T( "" ) ),
	m_strPassword( _T( "" ) )
{
}

CDSSyncSvc_DMSParameters::CDSSyncSvc_DMSParameters( const CDSSyncSvc_DMSParameters& DSSyncSvc_DMSParameters )
{
	// invoke assignment operator
	*this = DSSyncSvc_DMSParameters;
}

CDSSyncSvc_DMSParameters::~CDSSyncSvc_DMSParameters( void )
{
}

bool CDSSyncSvc_DMSParameters::operator ==( const CDSSyncSvc_DMSParameters& DSSyncSvc_DMSParameters ) const
{
	bool bRetval = false;

	if(
		( _tcsicmp( ( LPCTSTR ) m_strDms, ( LPCTSTR ) DSSyncSvc_DMSParameters.m_strDms ) == 0 ) &&
		( _tcsicmp( ( LPCTSTR ) m_strLibrary, ( LPCTSTR ) DSSyncSvc_DMSParameters.m_strLibrary ) == 0 ) &&
		( _tcsicmp( ( LPCTSTR ) m_strUserId, ( LPCTSTR ) DSSyncSvc_DMSParameters.m_strUserId ) == 0 ) &&
		( _tcsicmp( ( LPCTSTR ) m_strPassword, ( LPCTSTR ) DSSyncSvc_DMSParameters.m_strPassword ) == 0 )
		)
	{
		bRetval = true;
	}

	return bRetval;
}

CDSSyncSvc_DMSParameters& CDSSyncSvc_DMSParameters::operator =( const CDSSyncSvc_DMSParameters& DSSyncSvc_DMSParameters )
{
	m_strDms = DSSyncSvc_DMSParameters.m_strDms;
	m_strLibrary = DSSyncSvc_DMSParameters.m_strLibrary;
	m_strUserId = DSSyncSvc_DMSParameters.m_strUserId;
	m_strPassword = DSSyncSvc_DMSParameters.m_strPassword;

	return *this;
}






CDSSyncSvc_Connection::CDSSyncSvc_Connection( void )
:
	m_DSParameters( ),
	m_DMSParameters( ),
	m_strName( _T( "" ) ),
	m_strNode( _T( "" ) ),
	m_strAttributeMapName( _T( "" ) )
{
}

CDSSyncSvc_Connection::CDSSyncSvc_Connection( const CDSSyncSvc_Connection& DSSyncSvc_Connection )
:
	m_strName( DSSyncSvc_Connection.m_strName ),
	m_strNode( DSSyncSvc_Connection.m_strNode ),
	m_strAttributeMapName( DSSyncSvc_Connection.m_strAttributeMapName ),
	m_DSParameters( DSSyncSvc_Connection.m_DSParameters ),
	m_DMSParameters( DSSyncSvc_Connection.m_DMSParameters )
{
}

CDSSyncSvc_Connection::~CDSSyncSvc_Connection( void )
{
}

bool CDSSyncSvc_Connection::operator ==( const CDSSyncSvc_Connection& DSSyncSvc_Connection ) const
{
	bool bRetval = false;

	if(
		( _tcsicmp( ( LPCTSTR ) m_strName, ( LPCTSTR ) DSSyncSvc_Connection.m_strName ) == 0 ) &&
		( _tcsicmp( ( LPCTSTR ) m_strNode, ( LPCTSTR ) DSSyncSvc_Connection.m_strNode ) == 0 ) &&
		( _tcsicmp( ( LPCTSTR ) m_strAttributeMapName, ( LPCTSTR ) DSSyncSvc_Connection.m_strAttributeMapName ) == 0 )
		)
	{
		if( m_DSParameters == DSSyncSvc_Connection.m_DSParameters )
			if( m_DMSParameters == DSSyncSvc_Connection.m_DMSParameters )
				bRetval = true;
	}

	return bRetval;
}

CDSSyncSvc_Connection& CDSSyncSvc_Connection::operator =( const CDSSyncSvc_Connection& DSSyncSvc_Connection )
{
	
	m_strName = DSSyncSvc_Connection.m_strName;
	m_strNode = DSSyncSvc_Connection.m_strNode;
	m_strAttributeMapName = DSSyncSvc_Connection.m_strAttributeMapName;

	m_DSParameters = DSSyncSvc_Connection.m_DSParameters;
	m_DMSParameters = DSSyncSvc_Connection.m_DMSParameters;

	return *this;
}




CDSSyncSvc::CDSSyncSvc( void )
{
}

CDSSyncSvc::CDSSyncSvc( const CDSSyncSvc& DSSyncSvc )
{
	*this = DSSyncSvc;
}

CDSSyncSvc::~CDSSyncSvc( void )
{
	Clear( );
}

bool CDSSyncSvc::operator ==( const CDSSyncSvc& DSSyncSvc ) const
{
	bool bRetval = true;

	if( ( m_AttributeMapList.size( ) == DSSyncSvc.m_AttributeMapList.size( ) )
		&& 
		( m_ConnectionList.size( ) == DSSyncSvc.m_ConnectionList.size( ) ) )
	{
		{
			CONNECTIONLIST::const_iterator iterEnd = m_ConnectionList.end( );
			CONNECTIONLIST::const_iterator iter = m_ConnectionList.begin( );
			CONNECTIONLIST::const_iterator iter2 = DSSyncSvc.m_ConnectionList.begin( );
			for( ; iter != iterEnd; iter++, iter2++ )
			{
				CDSSyncSvc_Connection* pConnection = *iter;
				CDSSyncSvc_Connection* pConnection2 = *iter2;
				if( ( pConnection != NULL ) && ( pConnection2 != NULL ) )
				{
					// compare individual connections
					if( !( *pConnection == *pConnection2 ) )
					{
						bRetval = false;
						break;
					}
				}
			}
		}

		{
			ATTRIBUTEMAPLIST::const_iterator iterEnd = m_AttributeMapList.end( );
			ATTRIBUTEMAPLIST::const_iterator iter = m_AttributeMapList.begin( );
			ATTRIBUTEMAPLIST::const_iterator iter2 = DSSyncSvc.m_AttributeMapList.begin( );
			for( ; iter != iterEnd; iter++, iter2++ )
			{
				CDSSyncSvc_AttributeMap* pAttributeMap = *iter;
				CDSSyncSvc_AttributeMap* pAttributeMap2 = *iter2;
				if( ( pAttributeMap != NULL ) && ( pAttributeMap2 != NULL ) )
				{
					// compare individual attribute maps
					if( !( *pAttributeMap == *pAttributeMap2 ) )
					{
						bRetval = false;
						break;
					}
				}
			}
		}
	}
	else
	{
		// if list sizes don't match, they can't be the same

		bRetval = false;
	}
	

	return bRetval;
}

CDSSyncSvc& CDSSyncSvc::operator =( const CDSSyncSvc& DSSyncSvc )
{
	Clear( );

	{
		ATTRIBUTEMAPLIST::const_iterator iterEnd = DSSyncSvc.m_AttributeMapList.end( );
		for( ATTRIBUTEMAPLIST::const_iterator iter = DSSyncSvc.m_AttributeMapList.begin( ); iter != iterEnd; iter++ )
		{
			CDSSyncSvc_AttributeMap* pAttributeMap = *iter;
			if( pAttributeMap != NULL )
				m_AttributeMapList.push_back( new CDSSyncSvc_AttributeMap( *pAttributeMap ) );
		}
	}

	{
		CONNECTIONLIST::const_iterator iterEnd = DSSyncSvc.m_ConnectionList.end( );
		for( CONNECTIONLIST::const_iterator iter = DSSyncSvc.m_ConnectionList.begin( ); iter != iterEnd; iter++ )
		{
			CDSSyncSvc_Connection* pConnection = *iter;
			if( pConnection != NULL )
				m_ConnectionList.push_back( new CDSSyncSvc_Connection( *pConnection ) );
		}
	}

	return *this;
}

void CDSSyncSvc::Clear( void )
{
	// cleanup memory
	if( m_ConnectionList.size( ) > 0 )
		RemoveAllConnections( );

	if( m_AttributeMapList.size( ) > 0 )
		RemoveAllAttributeMaps( );
}

void CDSSyncSvc::RemoveAllAttributeMaps( void )
{
	ATTRIBUTEMAPLIST::const_iterator iterEnd = m_AttributeMapList.end( );
	for( ATTRIBUTEMAPLIST::const_iterator iter = m_AttributeMapList.begin( ); iter != iterEnd; iter++ )
	{
		CDSSyncSvc_AttributeMap* pAttributeMap = *iter;
		if( pAttributeMap != NULL )
			delete pAttributeMap;
	}
	m_AttributeMapList.clear( );
}

void CDSSyncSvc::RemoveAllConnections( void )
{
	CONNECTIONLIST::const_iterator iterEnd = m_ConnectionList.end( );
	for( CONNECTIONLIST::const_iterator iter = m_ConnectionList.begin( ); iter != iterEnd; iter++ )
	{
		CDSSyncSvc_Connection* pConnection = *iter;
		if( pConnection != NULL )
			delete pConnection;
	}
	m_ConnectionList.clear( );
}

void CDSSyncSvc::AddAttributeMap(
	LPCTSTR szMapName, LPCTSTR szOUName, LPCTSTR szUserName, LPCTSTR szUserId, 
	LPCTSTR szUserEmail, LPCTSTR szUserFax, LPCTSTR szUserTelephone, LPCTSTR szUserLocation,
	LPCTSTR szGroupName, LPCTSTR szGroupId, LPCTSTR szGroupMember,
	LPCTSTR szK1SyncId
	)
{
	CDSSyncSvc_AttributeMap* pAttributeMap = new CDSSyncSvc_AttributeMap( );

	pAttributeMap->m_strMapName = szMapName;
	pAttributeMap->m_strOUName = szOUName;
	pAttributeMap->m_strUserName = szUserName;
	pAttributeMap->m_strUserId = szUserId;
	pAttributeMap->m_strUserEmail = szUserEmail;
	pAttributeMap->m_strUserFax = szUserFax;
	pAttributeMap->m_strUserTelephone = szUserTelephone;
	pAttributeMap->m_strUserLocation = szUserLocation;
	pAttributeMap->m_strGroupName = szGroupName;
	pAttributeMap->m_strGroupId = szGroupId;
	pAttributeMap->m_strGroupMember = szGroupMember;
	pAttributeMap->m_strK1SyncId = szK1SyncId;

	m_AttributeMapList.push_back( pAttributeMap );
}

void CDSSyncSvc::AddConnection( 
	LPCTSTR szConnectionName, LPCTSTR szNode, LPCTSTR szAttributeMapName,
	LPCTSTR szDmsServer, LPCTSTR szDmsLibrary, LPCTSTR szDmsUserId, LPCTSTR szDmsPassword,
	LPCTSTR szDSServer, LPCTSTR szDSUserId, LPCTSTR szDSPassword,
	long lDSServiceType, long lDSTcpipPort
	)
{
	CDSSyncSvc_Connection* pConnection = new CDSSyncSvc_Connection( );

	pConnection->m_strName = szConnectionName;
	pConnection->m_strNode = szNode;
	pConnection->m_strAttributeMapName = szAttributeMapName;

	pConnection->m_DMSParameters.m_strDms = szDmsServer;
	pConnection->m_DMSParameters.m_strLibrary = szDmsLibrary;
	pConnection->m_DMSParameters.m_strUserId = szDmsUserId;
	pConnection->m_DMSParameters.m_strPassword = szDmsPassword;

	pConnection->m_DSParameters.m_strServerName = szDSServer;
	pConnection->m_DSParameters.m_strUserId = szDSUserId;
	pConnection->m_DSParameters.m_strPassword = szDSPassword;
	pConnection->m_DSParameters.m_lServiceType = lDSServiceType;
	pConnection->m_DSParameters.m_lTcpipPort = lDSTcpipPort;

	m_ConnectionList.push_back( pConnection );
}

void CDSSyncSvc::AddConnection( CDSSyncSvc_Connection* pConnection )
{
	if( pConnection != NULL )
		m_ConnectionList.push_back( pConnection );
}

void CDSSyncSvc::AddAttributeMap( CDSSyncSvc_AttributeMap* pAttributeMap )
{
	if( pAttributeMap != NULL )
		m_AttributeMapList.push_back( pAttributeMap );
}

void CDSSyncSvc::RemoveConnection( LPCTSTR szConnectionName )
{
	CONNECTIONLIST::iterator iterEnd = m_ConnectionList.end( );
	for( CONNECTIONLIST::iterator iter = m_ConnectionList.begin( ); iter != iterEnd; iter++ )
	{
		CDSSyncSvc_Connection* pConnection = *iter;
		if( pConnection != NULL )
		{
			if( _tcsicmp( ( LPCTSTR ) szConnectionName, ( LPCTSTR ) pConnection->m_strName ) == 0 )
			{
				m_ConnectionList.erase( iter );
				delete pConnection;
				return;
			}
		}
	}
}

void CDSSyncSvc::RemoveAttributeMap( LPCTSTR szMapName )
{
	ATTRIBUTEMAPLIST::iterator iterEnd = m_AttributeMapList.end( );
	for( ATTRIBUTEMAPLIST::iterator iter = m_AttributeMapList.begin( ); iter != iterEnd; iter++ )
	{
		CDSSyncSvc_AttributeMap* pAttributeMap = *iter;
		if( pAttributeMap != NULL )
		{
			if( _tcsicmp( ( LPCTSTR ) szMapName, ( LPCTSTR ) pAttributeMap->m_strMapName ) == 0 )
			{
				m_AttributeMapList.erase( iter );
				delete pAttributeMap;
				return;
			}
		}
	}
}

bool CDSSyncSvc::ConnectionExists( LPCTSTR szConnectionName ) const
{
	CONNECTIONLIST::const_iterator iterEnd = m_ConnectionList.end( );
	for( CONNECTIONLIST::const_iterator iter = m_ConnectionList.begin( ); iter != iterEnd; iter++ )
	{
		CDSSyncSvc_Connection* pConnection = *iter;
		if( pConnection != NULL )
		{
			if( _tcsicmp( ( LPCTSTR ) szConnectionName, ( LPCTSTR ) pConnection->m_strName ) == 0 )
			{
				return true;
			}
		}
	}

	return false;
}

bool CDSSyncSvc::AttributeMapExists( LPCTSTR szMapName ) const
{
	ATTRIBUTEMAPLIST::const_iterator iterEnd = m_AttributeMapList.end( );
	for( ATTRIBUTEMAPLIST::const_iterator iter = m_AttributeMapList.begin( ); iter != iterEnd; iter++ )
	{
		CDSSyncSvc_AttributeMap* pAttributeMap = *iter;
		if( pAttributeMap != NULL )
		{
			if( _tcsicmp( ( LPCTSTR ) szMapName, ( LPCTSTR ) pAttributeMap->m_strMapName ) == 0 )
			{
				return true;
			}
		}
	}

	return false;
}

CDSSyncSvc_Connection* CDSSyncSvc::FindConnection( LPCTSTR szConnectionName )
{
	CONNECTIONLIST::const_iterator iterEnd = m_ConnectionList.end( );
	for( CONNECTIONLIST::const_iterator iter = m_ConnectionList.begin( ); iter != iterEnd; iter++ )
	{
		CDSSyncSvc_Connection* pConnection = *iter;
		if( pConnection != NULL )
		{
			if( _tcsicmp( ( LPCTSTR ) szConnectionName, ( LPCTSTR ) pConnection->m_strName ) == 0 )
			{
				return pConnection;
			}
		}
	}

	return NULL;
}

CDSSyncSvc_AttributeMap* CDSSyncSvc::FindAttributeMap( LPCTSTR szMapName )
{
	ATTRIBUTEMAPLIST::const_iterator iterEnd = m_AttributeMapList.end( );
	for( ATTRIBUTEMAPLIST::const_iterator iter = m_AttributeMapList.begin( ); iter != iterEnd; iter++ )
	{
		CDSSyncSvc_AttributeMap* pAttributeMap = *iter;
		if( pAttributeMap != NULL )
		{
			if( _tcsicmp( ( LPCTSTR ) szMapName, ( LPCTSTR ) pAttributeMap->m_strMapName ) == 0 )
			{
				return pAttributeMap;
			}
		}
	}

	return NULL;
}



}	// namespace DSLocal





