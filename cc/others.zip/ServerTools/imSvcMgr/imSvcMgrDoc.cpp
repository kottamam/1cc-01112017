// imSvcMgrDoc.cpp : implementation of the CSvcMgrDoc class
//

#include "stdafx.h"
#include "imSvcMgr.h"
#include <Report\Report.h>

#include "imSvcMgrView.h"
#include "imSvcMgrDoc.h"
#include "CntrItem.h"
#include "SrvrItem.h"
#include "Registry\RegistryLib.h"
#include "registry\emailsvcconfiguration.h"
#include "registry\LNEMailSvcConfiguration.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const CString strLogViewerAppPath = _T(".\\imLogView.exe");
#define KEY_IMANAGE_INSTALL_PATH	"Software\\Interwoven\\Worksite\\Server Common"

/////////////////////////////////////////////////////////////////////////////
// CSvcMgrDoc

IMPLEMENT_DYNCREATE(CSvcMgrDoc, COleServerDoc)

BEGIN_MESSAGE_MAP(CSvcMgrDoc, COleServerDoc)
	//{{AFX_MSG_MAP(CSvcMgrDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Enable default OLE container implementation
	ON_UPDATE_COMMAND_UI(ID_EDIT_PASTE, COleServerDoc::OnUpdatePasteMenu)
	ON_UPDATE_COMMAND_UI(ID_EDIT_PASTE_LINK, COleServerDoc::OnUpdatePasteLinkMenu)
	ON_UPDATE_COMMAND_UI(ID_OLE_EDIT_CONVERT, OnUpdateObjectVerbMenu)
	ON_COMMAND(ID_OLE_EDIT_CONVERT, COleServerDoc::OnEditConvert)
//	ON_UPDATE_COMMAND_UI(ID_OLE_EDIT_LINKS, COleServerDoc::OnUpdateEditLinksMenu)
	ON_UPDATE_COMMAND_UI(ID_OLE_EDIT_LINKS, OnUpdateEditLinksMenu)
	ON_COMMAND(ID_OLE_EDIT_LINKS, COleServerDoc::OnEditLinks)
	ON_UPDATE_COMMAND_UI_RANGE(ID_OLE_VERB_FIRST, ID_OLE_VERB_LAST, COleServerDoc::OnUpdateObjectVerbMenu)

	ON_COMMAND(ID_REGISTER_SERVER, OnRegisterServer)
	ON_COMMAND(ID_FIND_SERVERS, OnFindServers)
	ON_COMMAND(ID_UNREGISTER_SERVER, OnUnregisterServer)
	ON_COMMAND(ID_START_SERVICE, OnStartService)
	ON_COMMAND(ID_STOP_SERVICE, OnStopService)
	ON_COMMAND(ID_VIEW_LOG, OnViewLog)
	ON_COMMAND(ID_DATABASES_SETUP, OnDatabasesSetup)
	ON_COMMAND(ID_FILE_SERVER_SETUP, OnFileServerSetup)
	ON_COMMAND(ID_SERVICE_PROPERTIES, OnServiceProperties)
	ON_COMMAND(ID_STARTUP_PROPERTIES, OnStartupProperties)
	ON_COMMAND(ID_SERVICE_ABOUT, OnServiceAbout)

END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(CSvcMgrDoc, COleServerDoc)
	//{{AFX_DISPATCH_MAP(CSvcMgrDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//      DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()

// Note: we add support for IID_ISvcMgr to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .ODL file.

// {2F0775FF-D7EC-11D2-8C4D-00C04F68F9B3}
static const IID IID_ISvcMgr =
{ 0x2f0775ff, 0xd7ec, 0x11d2, { 0x8c, 0x4d, 0x0, 0xc0, 0x4f, 0x68, 0xf9, 0xb3 } };

BEGIN_INTERFACE_MAP(CSvcMgrDoc, COleServerDoc)
	INTERFACE_PART(CSvcMgrDoc, IID_ISvcMgr, Dispatch)
END_INTERFACE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSvcMgrDoc construction/destruction

CSvcMgrDoc::CSvcMgrDoc()
{
	// Use OLE compound files
	EnableCompoundFile();

	// TODO: add one-time construction code here

	EnableAutomation();

	AfxOleLockApp();
	m_pSelectedService = NULL;
	check(m_serviceList.size() == 0);
}

CSvcMgrDoc::~CSvcMgrDoc()
{
	AfxOleUnlockApp();

	ServiceList::iterator	it;

	for (it = m_serviceList.begin(); it != m_serviceList.end(); it++)
	{
		delete it->get();
	}
}

void CSvcMgrDoc::OnRegisterServer()
{
	try
	{
		POSITION pos = GetFirstViewPosition();

		if (pos != NULL)
			((CSvcMgrView*)GetNextView(pos))->RegisterServer();
	}
	catch(IM::Exception & e)
	{
		AfxMessageBox(e.m_strWhat.c_str());
	}
}

void CSvcMgrDoc::OnFindServers()
{
	try
	{
		POSITION pos = GetFirstViewPosition();

		if (pos != NULL)
			((CSvcMgrView*)GetNextView(pos))->Find_Servers();
	}
	catch(IM::Exception & e)
	{
		AfxMessageBox(e.m_strWhat.c_str());
	}
}

void CSvcMgrDoc::OnUnregisterServer()
{
	try
	{
		POSITION pos = GetFirstViewPosition();

		if (pos != NULL)
			((CSvcMgrView*)GetNextView(pos))->UnregisterServer();
	}
	catch(IM::Exception & e)
	{
		AfxMessageBox(e.m_strWhat.c_str());
	}
}

void CSvcMgrDoc::OnStartService()
{
	try
	{
		POSITION pos = GetFirstViewPosition();

		if (pos != NULL)
			((CSvcMgrView*)GetNextView(pos))->StartService();
	}
	catch(IM::Exception & e)
	{
		AfxMessageBox(e.m_strWhat.c_str());
	}
}

void CSvcMgrDoc::OnStopService()
{
	try
	{
		POSITION pos = GetFirstViewPosition();

		if (pos != NULL)
			((CSvcMgrView*)GetNextView(pos))->StopService();
	}
	catch(IM::Exception & e)
	{
		AfxMessageBox(e.m_strWhat.c_str());
	}
}

void CSvcMgrDoc::OnViewLog()
{
	ServiceConfiguration		*pService = GetSelectedService();


	if (pService == NULL)
		return;

	TCHAR	*pszCurDir = NULL;
	PROCESS_INFORMATION	procInfo;

	try
	{
		pService->LoadFromRegistry();
		const TCHAR	*szLogFile = pService->m_strLogPath.Get().c_str();
		STARTUPINFO	startUpInfo;		
		IM::NrString commandLine;

		NrString		strInstallPathKey = KEY_IMANAGE_INSTALL_PATH;
		NrString		strLogViewerPath;
		IM::Registry	logpathReg(NULL, HKEY_LOCAL_MACHINE, strInstallPathKey.c_str());		
		DWORD			dwSize;
		BOOL			fResult;

		bool bInstallPath = false;
		strLogViewerPath = _T(".\\");
		if (logpathReg.Open(NULL, KEY_ALL_ACCESS))
		{
			if (logpathReg.GetStringValue(_T("Install Path"), strLogViewerPath))
			{
				bInstallPath = true;
			}
		}

		// If I don't find the install path key in the registry, then I use the current dir	of the Service.
		if(!bInstallPath)
		{
			IM::NrString strSvcPath = pService->m_strServicePath.Get().c_str();
			IM::NrString::size_type	pos = strSvcPath.find_last_of('\\');
			if (pos != IM::NrString::npos)
			{
				strLogViewerPath = strSvcPath.substr(0, pos+1);			
			}
		}

		commandLine = _T("\"");
		commandLine += _T(".\\imLogView.exe ");
		GetStartupInfo(&startUpInfo);
		startUpInfo.wShowWindow = SW_SHOW;
		commandLine += pService->m_strLogPath.Get().c_str();
		commandLine += _T("\"");

		dwSize = GetCurrentDirectory(0, NULL);
		pszCurDir = new TCHAR[dwSize+1]; // + 1 is not necessary?
		if (!pszCurDir)
			return;

		GetCurrentDirectory(dwSize, pszCurDir);
		SetCurrentDirectory((_TCHAR *)strLogViewerPath.c_str());

		//	Startup the log viewer application and pass it the file name
		fResult = CreateProcess(strLogViewerAppPath, (_TCHAR *) commandLine.c_str(), 0, 0, TRUE, DETACHED_PROCESS, 0,0,
			&startUpInfo, &procInfo);

		SetCurrentDirectory(pszCurDir);		

		if(!fResult)
		{
			LastErrorString		errorString;

			Report(REP_WARN, IDS_MAIN_141, errorString.c_str());
			return;
		}		
	}
	catch(IM::Exception & e)
	{
		AfxMessageBox(e.m_strWhat.c_str());		
	}

	if (pszCurDir != NULL)	
		delete [] pszCurDir;
	
	CloseHandle(procInfo.hProcess);
	CloseHandle(procInfo.hThread);
}

void CSvcMgrDoc::OnDatabasesSetup()
{
	try
	{
		POSITION pos = GetFirstViewPosition();

		if (pos != NULL)
			((CSvcMgrView*)GetNextView(pos))->DataBaseSetup();
	}
	catch(IM::Exception & e)
	{
		AfxMessageBox(e.m_strWhat.c_str());		
	}
}

void CSvcMgrDoc::OnFileServerSetup()
{
	try
	{
		POSITION pos = GetFirstViewPosition();

		if (pos != NULL)
			((CSvcMgrView*)GetNextView(pos))->FileServerSetup();
	}
	catch(IM::Exception & e)
	{
		AfxMessageBox(e.m_strWhat.c_str());		
	}
}

void CSvcMgrDoc::OnServiceProperties()
{
	try
	{
		POSITION pos = GetFirstViewPosition();

		if (pos != NULL)
			((CSvcMgrView*)GetNextView(pos))->ServiceProperties();
	}
	catch(IM::Exception & e)
	{
		AfxMessageBox(e.m_strWhat.c_str());		
	}
}

void CSvcMgrDoc::OnStartupProperties()
{
	try
	{
		POSITION pos = GetFirstViewPosition();

		if (pos != NULL)
			((CSvcMgrView*)GetNextView(pos))->StartupProperties();
	}
	catch(IM::Exception & e)
	{
		AfxMessageBox(e.m_strWhat.c_str());		
	}
}

void CSvcMgrDoc::OnServiceAbout()
{
	try
	{
		POSITION pos = GetFirstViewPosition();

		if (pos != NULL)
			((CSvcMgrView*)GetNextView(pos))->Service_About();
	}
	catch(IM::Exception & e)
	{
		AfxMessageBox(e.m_strWhat.c_str());		
	}
}

void CSvcMgrDoc::OnUpdateEditLinksMenu( CCmdUI* pCmdUI )
{
}

void CSvcMgrDoc::OnUpdateObjectVerbMenu( CCmdUI* pCmdUI )
{
}

BOOL CSvcMgrDoc::OnNewDocument()
{
	if (!COleServerDoc::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	SetTitle(_T(""));
	return TRUE;
}


/////////////////////////////////////////////////////////////////////////////
// CSvcMgrDoc server implementation

COleServerItem* CSvcMgrDoc::OnGetEmbeddedItem()
{
	// OnGetEmbeddedItem is called by the framework to get the COleServerItem
	//  that is associated with the document.  It is only called when necessary.

	CSvcMgrSrvrItem* pItem = new CSvcMgrSrvrItem(this);
	ASSERT_VALID(pItem);
	return pItem;
}



/////////////////////////////////////////////////////////////////////////////
// CSvcMgrDoc serialization

void CSvcMgrDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}

	// Calling the base class COleServerDoc enables serialization
	//  of the container document's COleClientItem objects.
	COleServerDoc::Serialize(ar);
}

/////////////////////////////////////////////////////////////////////////////
// CSvcMgrDoc diagnostics

#ifdef _DEBUG
void CSvcMgrDoc::AssertValid() const
{
	COleServerDoc::AssertValid();
}

void CSvcMgrDoc::Dump(CDumpContext& dc) const
{
	COleServerDoc::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSvcMgrDoc commands

bool CSvcMgrDoc::isServerInList(const IM::NrString& aServerName)
{
	ServiceList::iterator it;

	if (m_serviceList.empty())
		return false;

	for (it = m_serviceList.begin(); it != m_serviceList.end(); ++it)
	{
		ServiceConfiguration	*pService = it->get();
		if (pService->m_strComputerName.compare(aServerName.c_str()) == 0)
			return true;
	}

	return false;
}

bool CSvcMgrDoc::addServer(const IM::NrString& serverName, bool verbose)
{
	bool bImanageServer = false;
	SC_HANDLE hSCM;
	CImageList* pImageList;
	CBitmap bitmap;

	pImageList = new CImageList(); 
	pImageList->Create(10, 11, ILC_COLOR32, 2, 2);

	bitmap.LoadBitmap(IDB_SERVER_ON);
	pImageList->Add(&bitmap, (COLORREF)0);
	bitmap.DeleteObject();
 
	bitmap.LoadBitmap(IDB_SERVER_OFF);
	pImageList->Add(&bitmap, (COLORREF)0);
	bitmap.DeleteObject();

	//	attempt to connect to the SCM on the server to determine if it is up
	//	and allows access

//	if ((hSCM = OpenSCManager(serverName.c_str(), NULL, GENERIC_READ|GENERIC_WRITE|GENERIC_EXECUTE)) == NULL)
	if ((hSCM = OpenSCManager(serverName.c_str(), NULL, SC_MANAGER_CONNECT|SC_MANAGER_ENUMERATE_SERVICE)) == NULL)
	{
		DWORD errCode = GetLastError();
		if (errCode == ERROR_ACCESS_DENIED)
			int p = 1;
		if(errCode ==ERROR_DATABASE_DOES_NOT_EXIST)
			int q= 1;
		if (errCode == ERROR_INVALID_PARAMETER)
			int r= 2;
		if (verbose)
		{
			LastErrorString	eString;
			Report(REP_WARN, IDS_MAIN_146, serverName.c_str(), eString.c_str());  
		}   
 
		return false;
	} 
 
	CloseServiceHandle(hSCM);  

	// attempt to connect to the services

	if (AddService(new DmsServiceConfiguration(serverName.c_str()), pImageList) == true)
		bImanageServer = true;
	
	if (AddService(new IdxMgrServiceConfiguration(serverName.c_str()), pImageList) == true)
		bImanageServer = true;

	if (AddService(new IdxSearchServiceConfiguration(serverName.c_str()), pImageList) == true)
		bImanageServer = true;

	if (AddService(new RulesServiceConfiguration(serverName.c_str()), pImageList) == true)
		bImanageServer = true;

	if (AddService(new FmaServiceConfiguration(serverName.c_str()), pImageList) == true)
		bImanageServer = true;

	if (AddService(new EFSServiceConfiguration(serverName.c_str()), pImageList) == true)
		bImanageServer = true;

	if (AddService(new IM::PrintRenditionServiceConfiguration(serverName.c_str()), pImageList) == true)
		bImanageServer = true;

	if (AddService(new WkIndxrServiceConfiguration(serverName.c_str()), pImageList) == true)
		bImanageServer = true;

	if (AddService(new WkAtIndxrServiceConfiguration(serverName.c_str()), pImageList) == true)
		bImanageServer = true;

	if (AddService(new WkDreServiceConfiguration(serverName.c_str()), pImageList) == true)
		bImanageServer = true;
	
	if (AddService(new CDSSyncSvc(serverName.c_str()), pImageList) == true)
		bImanageServer = true;

	if (AddService(new EMSServiceConfiguration(serverName.c_str()), pImageList) == true)
		bImanageServer = true;

	if (AddService(new CIFSServiceConfiguration(serverName.c_str()), pImageList) == true)
		bImanageServer = true;

	if (AddService(new IDXSVCConfiguration(serverName.c_str()), pImageList) == true)
		bImanageServer = true;

	if (AddService(new IM::EMailSvcConfiguration(serverName.c_str()), pImageList) == true)
		bImanageServer = true;

	if (AddService(new IM::LNEMailSvcConfiguration(serverName.c_str()), pImageList) == true)
		bImanageServer = true;
	
	// if could not find a service then inform user
	if (bImanageServer != true)
	{
		// Check whether the user is an administrator. Non admins need to be given registry permissions to view the contents
		LPUSER_INFO_1 pBuf = NULL;
		DWORD dwLevel = 0;
		DWORD dwPrefMaxLen = MAX_PREFERRED_LENGTH;
		DWORD dwEntriesRead = 0;
		DWORD dwTotalEntries = 0;
		wchar_t* lpBuffer = new wchar_t[UNLEN + 1];
		DWORD lpBufLen = UNLEN + 1;
		if (GetUserNameW (lpBuffer, &lpBufLen) != 0)
		{
			NET_API_STATUS  status;
			if ((status = NetUserGetInfo(NULL, lpBuffer, 1, (LPBYTE *)&pBuf)) == NERR_Success)
			{
				if (pBuf != NULL)
				{
					if (pBuf->usri1_priv == USER_PRIV_ADMIN)
					{
						if (verbose == true)
						{
							Report(REP_INFO, IDS_MAIN_147, serverName.c_str());
						}
					}
					else
					{
						if (verbose == true)
						{
							Report(REP_INFO, IDS_STRING61447, serverName.c_str());
						}
					}
				    NetApiBufferFree(pBuf);
					delete [] lpBuffer;
					return false;
				}
				else
				{
					Report(REP_INFO, IDS_STRING61448, serverName.c_str());
				}
			}
			else 
			{
				Report(REP_INFO, IDS_STRING61448, serverName.c_str());
			}
		}
		else
		{
			Report(REP_INFO, IDS_STRING61448, serverName.c_str());
		}
		delete [] lpBuffer;
		return false;
	}

	return true;
}


bool
CSvcMgrDoc::AddService(ServiceConfiguration *pService_, 	CImageList* pImageList_)
{
	POSITION pos = GetFirstViewPosition();
	CSvcMgrView* aView = (CSvcMgrView*)GetNextView(pos);
	aView->GetListCtrl().SetImageList(pImageList_, LVSIL_SMALL);
	int nItem = 0;
	int image;

	// if could not initialize service object or if the service is not installed
	// then punt the service object
	if (pService_->Init(false) != true || pService_->IsInstalled() != true)
	{
		delete pService_;
		return false;
	}
	else
	{
		try
		{
			pService_->LoadFromRegistry();
		}
		catch(IM::Exception &)
		{
		}

		m_serviceList.push_front(pService_);
		
		if (pService_->IsRunning() == true)
			image = 0;
		else
			image = 1;
		
		nItem = aView->GetListCtrl().InsertItem(0, pService_->m_strComputerName.c_str(), image);
		aView->GetListCtrl().SetItemText(nItem, 1, pService_->m_strServiceDisplayName.c_str());
		aView->GetListCtrl().SetItemText(nItem, 2, pService_->GetStatusString());
		aView->GetListCtrl().SetItemText(nItem, 3, pService_->m_strComments.Get().c_str());
	} 

	return true;
}
