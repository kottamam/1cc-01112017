#if !defined _CEDITLISTBOX_H_
#define _CEDITLISTBOX_H_


/////////////////////////////////////////////////////////////////////////////
// CEListBox window

class CEditListBox : public CListBox
{
// Construction
public:
	CEditListBox();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEListBox)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

// Implementation
public:
	CEdit* m_pEdit;
	int EndEdit();
	void InitEdit(CPoint);
	virtual ~CEditListBox();

	// Generated message map functions
protected:
	//{{AFX_MSG(CEListBox)
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CEDITLISTBOX_H___6BDD526A_D82F_45D9_9AAD_1D00CE6664AA__INCLUDED_)
