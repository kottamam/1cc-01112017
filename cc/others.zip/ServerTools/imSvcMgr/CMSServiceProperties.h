#if !defined(AFX_CMSSERVICEPROPERTIES_H__3AB92DA2_0EEA_11D4_8BE2_00C04F0935D0__INCLUDED_)
#define AFX_CMSSERVICEPROPERTIES_H__3AB92DA2_0EEA_11D4_8BE2_00C04F0935D0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CMSServiceProperties.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCMSServiceProperties dialog
class DocService;

class CCMSServiceProperties : public CDialog
{
// Construction
public:
	CCMSServiceProperties(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CCMSServiceProperties)
	enum { IDD = IDD_CMS_PROPERTIES };
	CSpinButtonCtrl	m_ctrlSpinCtrl;
	CString	m_strEditCluster;
	CString	m_strTempFileName;
	long	m_lFilePort;
	long	m_lSvcPort;
	//}}AFX_DATA

	IM::CmsServiceConfiguration	*m_pService;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCMSServiceProperties)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CCMSServiceProperties)
	virtual BOOL OnInitDialog();
	afx_msg void OnGivenFilePort();
	afx_msg void OnGivenServPort();
	virtual void OnOK();
	afx_msg void OnChange();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CMSSERVICEPROPERTIES_H__3AB92DA2_0EEA_11D4_8BE2_00C04F0935D0__INCLUDED_)
