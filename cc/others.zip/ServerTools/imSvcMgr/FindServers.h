#if !defined(AFX_FINDSERVERS_H__02BEFF0F_DB01_11D2_8C4E_00C04F68F9B3__INCLUDED_)
#define AFX_FINDSERVERS_H__02BEFF0F_DB01_11D2_8C4E_00C04F68F9B3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FindServers.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// FindServers dialog

#include "imSvcMgrDoc.h"

class FindServers : public CDialog
{
// Construction
public:
	FindServers(CWnd* pParent = NULL);   // standard constructor
	~FindServers(); 

	void SetDocument(CSvcMgrDoc* aDoc)
		{ m_Document = aDoc; }
	
	CSvcMgrDoc* GetMyDocument()
		{ return(m_Document); }
	
// Dialog Data
	//{{AFX_DATA(FindServers)
	enum { IDD = IDD_FIND_SERVERS };
	CAnimateCtrl	m_AnimateCtrl;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(FindServers)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(FindServers)
	virtual BOOL OnInitDialog();
	afx_msg void OnHelp();
	virtual void OnCancel();
	//}}AFX_MSG
	afx_msg void OnTimer( UINT_PTR nIDEvent );
	CSvcMgrDoc* m_Document;
private:
	bool bStop;
	UINT_PTR m_TimerID;

	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FINDSERVERS_H__02BEFF0F_DB01_11D2_8C4E_00C04F68F9B3__INCLUDED_)
