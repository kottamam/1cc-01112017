//
//	Header file for finding servers using backend worker threads
//

#ifndef __DOMAIN_INFO_H__
#define __DOMAIN_INFO_H__

#include <stl\NrString.h>
#include <stl\STLPointer.h>
#include <list>

class DomainInfoMgr;

class NetResource
{
public:

	IM::NrCiString	name;
	bool			bContainer;
	bool			bGotInfo;

	BOOL		operator==(const NetResource& x)	{ return x.name == name; }

	NetResource() {}
	NetResource(const NetResource &x)
	{
		name = x.name;
		bContainer = x.bContainer;
		bGotInfo = x.bGotInfo;
	}
};



typedef imstd::list<IM::NrString>	ServerNameList;
typedef imstd::list<NetResource>	NetResourceList;


class DomainInfo
{
public:

	IM::NrCiString		name;
	NETRESOURCE			netResource;
	ServerNameList		serverList;

	bool				bGotInfo;
	CRITICAL_SECTION	csLock;

	BOOL		operator==(const DomainInfo& x)	{ return x.name == name; }

				DomainInfo()			{	InitializeCriticalSection(&csLock);	bGotInfo = false; }
				~DomainInfo()			{	DeleteCriticalSection(&csLock);	}


	void				lock()			{	EnterCriticalSection(&csLock);	}
	void				unlock()		{	LeaveCriticalSection(&csLock);	}
};


class DomainInfoWorker
{
	DomainInfoMgr	*mgr;
	DomainInfo		*domain;

	HANDLE			hThread;

public:
	bool			bDoneWork;

					DomainInfoWorker(DomainInfoMgr *mgr, DomainInfo *domain);
					~DomainInfoWorker();

	BOOL			operator==(const DomainInfoWorker& x)	{ return x.hThread == hThread; }

	static void		workerThread(DomainInfoWorker *worker);
};



class DomainInfoMgr
{
public:
	typedef IM::STLPointer<DomainInfo>		DomainInfoPointer;
	typedef imstd::list<DomainInfoPointer>	DomainList;

	typedef IM::STLPointer<DomainInfoWorker>		DomainInfoWorkerPointer;
	typedef imstd::list<DomainInfoWorkerPointer>	WorkerList;

	DomainList			domainList;
	WorkerList			workerList;

	CRITICAL_SECTION	csLock;
	HANDLE				hThread;
	HANDLE			   	hStopEvent;

	bool				bInitialized;
	bool				bIsStopped;

	NETRESOURCE			microsoftResource;

				DomainInfoMgr();
				~DomainInfoMgr();

	void				lock()			{	EnterCriticalSection(&csLock);	}
	void				unlock()		{	LeaveCriticalSection(&csLock);	}

	static void			managerThread(DomainInfoMgr *mgr);
	void				workerCleanup();

	void				StartWork();
	void				StopWork()		{	SetEvent(hStopEvent);	}
	bool				IsStopped()		{	return bIsStopped;		}

	void				getDomainNameList(NetResourceList &list);
	void				getServersInDomain(const IM::NrCiString domainName, ServerNameList &list, bool &bGotAll);
};

#endif __DOMAIN_INFO_H__


