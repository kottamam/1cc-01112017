#include "stdafx.h"
#include "imSvcMgr.h"
#include "LookupManager.h"

using namespace IM;

LookupWork::LookupWork()
{
	m_pDmsService = NULL;
	m_pIdxMgrService = NULL;
	m_pIdxSearchService = NULL;
	m_pRulesSearchService = NULL;
	m_pFmaService = NULL;
	m_pEFSService = NULL;
	m_pPrintRendService = NULL;
	m_pWkDreService = NULL;
	m_pKMIdxService = NULL;
	m_pWkAtIdxService = NULL;
	m_pDSSyncSvc = NULL;
	m_pEmsService = NULL;
	m_pCifsService = NULL;
	m_pIDXService  = NULL;
	m_pEOLService  = NULL;
	m_pLNService = NULL;
}

LookupWork::~LookupWork()
{
	if (m_pDmsService != NULL)
		delete m_pDmsService;

	if (m_pIdxMgrService != NULL)
		delete m_pIdxMgrService;

	if (m_pIdxSearchService != NULL)
		delete m_pIdxSearchService;

	if (m_pRulesSearchService != NULL)
		delete m_pRulesSearchService;

	if (m_pFmaService != NULL)
		delete m_pFmaService;

	if (m_pEFSService != NULL)
		delete m_pEFSService;

	if (m_pPrintRendService != NULL)
		delete m_pPrintRendService;

	if (m_pWkDreService != NULL)
	{
		delete m_pWkDreService;
	}

	if (m_pKMIdxService != NULL)	//KM Addition
		delete m_pKMIdxService;

	if (m_pWkAtIdxService != NULL)
	{
		delete m_pWkAtIdxService;
	}

	if (m_pEmsService != NULL)
	{
		delete m_pEmsService;
	}

	if( m_pDSSyncSvc != NULL )
		delete m_pDSSyncSvc;

	
	if (m_pCifsService != NULL)
	{
		delete m_pCifsService;
	}

	if (m_pIDXService  != NULL)
	{
		delete m_pIDXService;
	}

	if (NULL != m_pEOLService)
	{
		delete m_pEOLService; m_pEOLService = NULL;
	}

	if( NULL != m_pLNService )
	{
		delete m_pLNService ; m_pLNService = NULL;
	}
}


LookupWorker::LookupWorker(LookupWork *work, LookupManager *mgr)
{
	DWORD		threadID;

	this->work = work;
	lookupMgr = mgr;

	bDoneWork = false;

	hThread = CreateThread(0, 0,
					(LPTHREAD_START_ROUTINE) LookupWorker::workerThread, (LPVOID *) this, 0, &threadID);
}

LookupWorker::~LookupWorker()
{
	DWORD		dwExitCode;

	GetExitCodeThread(hThread, &dwExitCode);
	while (dwExitCode == STILL_ACTIVE)
	{
		Sleep(1000);
		GetExitCodeThread(hThread, &dwExitCode);
	}
	CloseHandle(hThread);

	if (work != NULL)
		delete work;
}

void
LookupWorker::workerThread(LookupWorker *pWorker_)
{
	LookupWork	*work = pWorker_->work;

	//
	// attempt to connect to the services
	// if could not initialize service object or if the service is not installed
	// then punt the service object
	//

	// DMS
	try
	{
		DmsServiceConfiguration	*pDmsService = new DmsServiceConfiguration(work->serverName.c_str());
		if (pDmsService->Init(true) != TRUE || pDmsService->IsInstalled() != TRUE)
			delete pDmsService;
		else
		{
			pDmsService->LoadFromRegistry();
			work->m_pDmsService = pDmsService;
		}
	}
	catch(IM::Exception &e)
	{
		AfxMessageBox(e.m_strWhat.c_str());
	}


	// *** repeat for other services

	try
	{
		IdxMgrServiceConfiguration	*pIdxMgrService = new IdxMgrServiceConfiguration(work->serverName.c_str());
		// if could not initialize service object or if the service is not installed
		// then punt the service object
		if (pIdxMgrService->Init(true) != TRUE || pIdxMgrService->IsInstalled() != TRUE)
			delete pIdxMgrService;
		else
		{
			pIdxMgrService->LoadFromRegistry();
			work->m_pIdxMgrService = pIdxMgrService;
		}
	}
	catch(IM::Exception &e)
	{
		AfxMessageBox(e.m_strWhat.c_str());
	}

	try
	{
		IdxSearchServiceConfiguration	*pIdxSearchService = new IdxSearchServiceConfiguration(work->serverName.c_str());
		// if could not initialize service object or if the service is not installed
		// then punt the service object
		if (pIdxSearchService->Init(true) != TRUE || pIdxSearchService->IsInstalled() != TRUE)
			delete pIdxSearchService;
		else
		{
			pIdxSearchService->LoadFromRegistry();
			work->m_pIdxSearchService = pIdxSearchService;
		}
	}
	catch(IM::Exception &e)
	{
		AfxMessageBox(e.m_strWhat.c_str());
	}

	try
	{
		RulesServiceConfiguration	*pRulesSearchService = new RulesServiceConfiguration(work->serverName.c_str());
		// if could not initialize service object or if the service is not installed
		// then punt the service object
		if (pRulesSearchService->Init(true) != TRUE || pRulesSearchService->IsInstalled() != TRUE)
			delete pRulesSearchService;
		else
		{
			pRulesSearchService->LoadFromRegistry();
			work->m_pRulesSearchService = pRulesSearchService;
		}
	}
	catch(IM::Exception &e)
	{
		AfxMessageBox(e.m_strWhat.c_str());
	}

	try
	{
		FmaServiceConfiguration	*pFmaService = new FmaServiceConfiguration(work->serverName.c_str());
		// if could not initialize service object or if the service is not installed
		// then punt the service object
		if (pFmaService->Init(true) != TRUE || pFmaService->IsInstalled() != TRUE)
			delete pFmaService;
		else
		{
			pFmaService->LoadFromRegistry();
			work->m_pFmaService = pFmaService;
		}
	}
	catch(IM::Exception &e)
	{
		AfxMessageBox(e.m_strWhat.c_str());
	}

	try
	{
		EFSServiceConfiguration	*pEFSService = new EFSServiceConfiguration(work->serverName.c_str());
		// if could not initialize service object or if the service is not installed
		// then punt the service object
		if (pEFSService->Init(true) != TRUE || pEFSService->IsInstalled() != TRUE)
			delete pEFSService;
		else
		{
			pEFSService->LoadFromRegistry();
			work->m_pEFSService = pEFSService;
		}
	}
	catch(IM::Exception &e)
	{
		AfxMessageBox(e.m_strWhat.c_str());
	}

	try
	{
		PrintRenditionServiceConfiguration 	*pPrintRendService = new PrintRenditionServiceConfiguration(work->serverName.c_str());
		// if could not initialize service object or if the service is not installed
		// then punt the service object
		if (pPrintRendService->Init(true) != TRUE || pPrintRendService->IsInstalled() != TRUE)
			delete pPrintRendService;
		else
		{
			pPrintRendService->LoadFromRegistry();
			work->m_pPrintRendService = pPrintRendService;
		}
	}
	catch(IM::Exception &e)
	{
		AfxMessageBox(e.m_strWhat.c_str());
	}

	try
	{
		WkDreServiceConfiguration	*pWkDreService = new WkDreServiceConfiguration(work->serverName.c_str());
		if (pWkDreService->Init(true) != TRUE || pWkDreService->IsInstalled() != TRUE)
			delete pWkDreService;
		else
		{
			pWkDreService->LoadFromRegistry();			
			work->m_pWkDreService = pWkDreService;
		}
	}
	catch(IM::Exception &e)
	{
		AfxMessageBox(e.m_strWhat.c_str());
	}

	try
	{
		WkIndxrServiceConfiguration	*pKMIdxService = new WkIndxrServiceConfiguration(work->serverName.c_str());
		if (pKMIdxService->Init(true) != TRUE || pKMIdxService->IsInstalled() != TRUE)
			delete pKMIdxService;
		else
		{
			pKMIdxService->LoadFromRegistry();
			work->m_pKMIdxService = pKMIdxService;
		}
	}
	catch(IM::Exception &e)
	{
		AfxMessageBox(e.m_strWhat.c_str());
	}

	try
	{
		WkAtIndxrServiceConfiguration	*pWkAtIndxrService = new WkAtIndxrServiceConfiguration(work->serverName.c_str());
		if (pWkAtIndxrService->Init(true) != TRUE || pWkAtIndxrService->IsInstalled() != TRUE)
			delete pWkAtIndxrService;
		else
		{
			pWkAtIndxrService->LoadFromRegistry();
			work->m_pWkAtIdxService = pWkAtIndxrService;
		}
	}
	catch(IM::Exception &e)
	{
		AfxMessageBox(e.m_strWhat.c_str());
	}

	try
	{
		CDSSyncSvc	*pDSSyncSvc = new CDSSyncSvc(work->serverName.c_str());
		if (pDSSyncSvc->Init(true) != TRUE || pDSSyncSvc->IsInstalled() != TRUE)
			delete pDSSyncSvc;
		else
		{
			pDSSyncSvc->LoadFromRegistry();
			work->m_pDSSyncSvc = pDSSyncSvc;
		}
	}
	catch(IM::Exception &e)
	{
		AfxMessageBox(e.m_strWhat.c_str());
	}

	try
	{
		EMSServiceConfiguration	*pEmsService = new EMSServiceConfiguration(work->serverName.c_str());
		if (pEmsService->Init(true) != TRUE || pEmsService->IsInstalled() != TRUE)
			delete pEmsService;
		else
		{
			pEmsService->LoadFromRegistry();
			work->m_pEmsService = pEmsService;
		}
	}
	catch(IM::Exception &e)
	{
		AfxMessageBox(e.m_strWhat.c_str());
	}

	//CIFS
	try
	{
		CIFSServiceConfiguration	*pCifsService = new CIFSServiceConfiguration(work->serverName.c_str());
		if (pCifsService->Init(true) != TRUE || pCifsService->IsInstalled() != TRUE)
			delete pCifsService;
		else
		{
			pCifsService->LoadFromRegistry();
			work->m_pCifsService = pCifsService;
		}
	}
	catch(IM::Exception &e)
	{
		AfxMessageBox(e.m_strWhat.c_str());
	}

	//WorkSite Indexer Service
	try
	{
		IDXSVCConfiguration			*pIDXService = new IDXSVCConfiguration(work->serverName.c_str());
		if (pIDXService->Init(true) != TRUE || pIDXService->IsInstalled() != TRUE)
			delete pIDXService;
		else
		{
			pIDXService->LoadFromRegistry();
			work->m_pIDXService = pIDXService;
		}
	}
	catch(IM::Exception &e)
	{
		AfxMessageBox(e.m_strWhat.c_str());
	}

	// Exchange Online Service
	try
	{
		EMailSvcConfiguration *pEOLService = new EMailSvcConfiguration(work->serverName.c_str());
		if (!pEOLService->Init(true) || !pEOLService->IsInstalled())
		{
			delete pEOLService;
		}
		else
		{
			pEOLService->LoadFromRegistry();
			work->m_pEOLService = pEOLService;
		}
	}
	catch(IM::Exception &e)
	{
		AfxMessageBox(e.m_strWhat.c_str());
	}

	// Lotus Notes Service
	try
	{
		LNEMailSvcConfiguration *pLNService = new LNEMailSvcConfiguration(work->serverName.c_str());
		if (!pLNService->Init(true) || !pLNService->IsInstalled())
		{
			delete pLNService;
		}
		else
		{
			pLNService->LoadFromRegistry();
			work->m_pLNService = pLNService;
		}
	}
	catch(IM::Exception &e)
	{
		AfxMessageBox(e.m_strWhat.c_str());
	}

	//	put results in the results list
	pWorker_->lookupMgr->lock();
	pWorker_->lookupMgr->resultList.push_front(work);
	pWorker_->work = NULL;
	pWorker_->lookupMgr->unlock();

	pWorker_->bDoneWork = true;
}


LookupManager::LookupManager()
{
	DWORD	threadID;

	hStopEvent = CreateEvent( NULL, TRUE, FALSE, NULL);
	InitializeCriticalSection(&csLock);

	//	Start the manager thread
	hThread = CreateThread(0, 0,
					(LPTHREAD_START_ROUTINE) LookupManager::managerThread, (LPVOID *) this, 0, &threadID);

	if (hThread == NULL)
		Report(REP_WARN, IDS_LOOKUP_130);
}

LookupManager::~LookupManager()
{
	DWORD		dwExitCode;

	SetEvent(hStopEvent);
	Sleep(100);		// allow workers to die

	// zap manager thread
	GetExitCodeThread(hThread, &dwExitCode);
	while (dwExitCode == STILL_ACTIVE)
	{
		Sleep(1000);
		GetExitCodeThread(hThread, &dwExitCode);
	}

	// zap workers
	workerList.clear();

	// destroy any available results
	resultList.clear();

	CloseHandle(hStopEvent);
	DeleteCriticalSection(&csLock);
}


void LookupManager::workerCleanup()
{
	lock();
	WorkerList::iterator iter = workerList.begin();

	while (iter != workerList.end())
	{
		if (iter->get()->bDoneWork == true)
		{
			workerList.erase(iter);
			iter = workerList.begin();
		}
		else
			++iter;
	}

	unlock();
}


void
LookupManager::managerThread(LookupManager *mgr)
{
	long		ret;

	while (1)
	{
		ret = WaitForSingleObject(mgr->hStopEvent, 60 * 1000);
		switch (ret)
		{
		case WAIT_TIMEOUT:
			// get rid of any workers that are done with work
			mgr->workerCleanup();
			break;

		default:
			ExitThread(0);
		}
	}
}



void
LookupManager::addRequest(const IM::NrString& serverName, bool bAtInitialization)
{
	LookupWork	*work = new LookupWork;

	work->serverName = serverName;
	work->bAtInitialization = bAtInitialization;

	lock();
	LookupWorker *pWorker_ = new LookupWorker(work, this);
	workerList.push_front(pWorker_);
	unlock();
}

bool
	LookupManager::getResult(
		IM::NrString& serverName,
		bool& bConnected,
		bool& bAtInitialization,
		IM::DmsServiceConfiguration*&		pDmsService_,
		IM::IdxMgrServiceConfiguration*&	pIdxMgrService_,
		IM::IdxSearchServiceConfiguration*&	pIdxSearchService_,
		IM::RulesServiceConfiguration*&		pRulesSearchService_,
		IM::FmaServiceConfiguration*&		pFmaService_,
		IM::EFSServiceConfiguration*&		pEFSService_,
		IM::PrintRenditionServiceConfiguration*& pPrintRendService_,
		IM::WkDreServiceConfiguration*&		pWkDreService_,
		IM::WkIndxrServiceConfiguration*&	pKMIdxService_,
		IM::WkAtIndxrServiceConfiguration*&	pWkAtIdxService_,
		IM::CDSSyncSvc*&					pDSSyncSvc_,
		IM::EMSServiceConfiguration*&		pEmsService_,
		IM::CIFSServiceConfiguration*&		pCifsService_,
		IM::IDXSVCConfiguration*&			pIDXService_,
		IM::EMailSvcConfiguration*&			pEOLService_,
		IM::LNEMailSvcConfiguration*&		pLNService_
	)
{
	lock();

	if (resultList.empty())
	{
		unlock();
		return false;
	}

	LookupWorkPointer work = resultList.front();
	unlock();

	serverName = work->serverName;
	bAtInitialization = work->bAtInitialization;
	pDmsService_ = work->m_pDmsService;
	pIdxMgrService_ = work->m_pIdxMgrService;
	pIdxSearchService_ = work->m_pIdxSearchService;
	pRulesSearchService_ = work->m_pRulesSearchService;
	pFmaService_ = work->m_pFmaService;
	pEFSService_ = work->m_pEFSService;
	pPrintRendService_ = work->m_pPrintRendService;
	pWkDreService_ = work->m_pWkDreService;
	pKMIdxService_ = work->m_pKMIdxService;
	pWkAtIdxService_ = work->m_pWkAtIdxService;
	pDSSyncSvc_ = work->m_pDSSyncSvc;
	pEmsService_ = work->m_pEmsService;
	pCifsService_ = work->m_pCifsService;
	pIDXService_ = work->m_pIDXService;
	pEOLService_ = work->m_pEOLService;
	pLNService_ = work->m_pLNService;

	if (
			work->m_pDmsService != NULL ||
			work->m_pIdxMgrService != NULL ||
			work->m_pIdxSearchService != NULL ||
			work->m_pRulesSearchService != NULL ||
			work->m_pFmaService != NULL ||
			work->m_pEFSService != NULL ||
			work->m_pPrintRendService != NULL ||
			work->m_pWkDreService != NULL ||
			work->m_pKMIdxService != NULL ||
			work->m_pWkAtIdxService != NULL ||
			work->m_pDSSyncSvc != NULL ||
			work->m_pEmsService != NULL ||
			work->m_pCifsService != NULL ||
			work->m_pIDXService != NULL ||
			work->m_pEOLService != NULL ||
			work->m_pLNService != NULL 
		)
	{		
		bConnected = true;
	}
	else
	{
		bConnected = false;
	}

	work->m_pDmsService = NULL;
	work->m_pIdxMgrService = NULL;
	work->m_pIdxSearchService = NULL;
	work->m_pRulesSearchService = NULL;
	work->m_pFmaService = NULL;
	work->m_pEFSService = NULL;
	work->m_pPrintRendService = NULL;
	work->m_pWkDreService = NULL;
	work->m_pKMIdxService = NULL;
	work->m_pWkAtIdxService = NULL;
	work->m_pDSSyncSvc = NULL;
	work->m_pEmsService = NULL;
	work->m_pCifsService = NULL;
	work->m_pIDXService = NULL;
	work->m_pEOLService = NULL;
	work->m_pLNService = NULL;

	resultList.pop_front();
	return true;
}

