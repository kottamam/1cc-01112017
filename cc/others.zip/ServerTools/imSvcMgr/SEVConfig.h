#pragma once

class SEVConfig : public CDialog
{
	DECLARE_DYNAMIC(SEVConfig)

public:
	SEVConfig(IM::DmsServiceConfiguration	*pService, CWnd* pParent = NULL);
	virtual ~SEVConfig();

	IM::DmsServiceConfiguration	*m_pService;
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedCancel();
	afx_msg void OnBnClickedNotesIDPathBrowse();
	afx_msg void OnBnClickedNotesTemplatePathBrowse();
	afx_msg void OnBnClickedNotesTempDBPathBrowse();

	enum { IDD = IDD_SEV };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);
	virtual BOOL OnInitDialog();
	void OnChange();
	afx_msg void OnNotesEnabled();

	DECLARE_MESSAGE_MAP()
};