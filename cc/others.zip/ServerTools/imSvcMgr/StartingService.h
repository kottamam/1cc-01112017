#if !defined(AFX_STARTINGSERVICE_H__6943B9B3_DB05_11D2_8C4E_00C04F68F9B3__INCLUDED_)
#define AFX_STARTINGSERVICE_H__6943B9B3_DB05_11D2_8C4E_00C04F68F9B3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// StartingService.h : header file
//

#define ST_START	1
#define ST_STOP		2
#define ST_EXIT		3

/////////////////////////////////////////////////////////////////////////////
// StartingService dialog

class StartingService : public CDialog
{
// Construction
public:
	StartingService(CWnd* pParent = NULL);   // standard constructor
	~StartingService();   
	long startType;
	IM::ServiceConfiguration	*m_pService;

// Dialog Data
	//{{AFX_DATA(StartingService)
	enum { IDD = IDD_STARTING_SERVICE };
	CProgressCtrl	m_StartStopProgress;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(StartingService)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(StartingService)
	virtual BOOL OnInitDialog();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	UINT_PTR m_TimerID;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STARTINGSERVICE_H__6943B9B3_DB05_11D2_8C4E_00C04F68F9B3__INCLUDED_)
