// DataBaseProp.cpp : implementation file 
//

#include <stdafx.h>

#include <imSvcMgr.h>
#include <DataBaseProp.h>
#include <SelectODBC.h>
#include <VelocityProp.h>
#include <VerityProp.h>
#include <DatabaseAdvProp.h>
#include <IdolIndexerProp.h>


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif    

/////////////////////////////////////////////////////////////////////////////
// DataBaseProp dialog


DataBaseProp::DataBaseProp(CWnd* pParent /*=NULL*/)
	: CDialog(DataBaseProp::IDD, pParent)
{
	//{{AFX_DATA_INIT(DataBaseProp)
	m_DatabaseValue = _T("");
	m_LogonID = _T("");
	m_Password = _T("");
	m_ConnectionCount = _T("");
	m_Connections = FALSE;
	m_nConnection = 0;
	m_pEntry = NULL;
	m_bEnableCacheFile = FALSE;
	m_DigitalSafeURL = _T("");
	m_DigitalSafeMailFrom = _T("");
	m_DigitalSafeRcptTo = _T("");
	m_DigitalSafeDomainName = _T("");
	m_DigitalSafeSSLKeyFile = _T("");
	m_DigitalSafeSSLKeyFilePassword = _T("");
	m_DigitalSafeSSLCACert = _T("");
	m_DigitalSafeSSLCAPath = _T("");
	//}}AFX_DATA_INIT
}


void DataBaseProp::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(DataBaseProp)
	DDX_Control(pDX, IDC_SPIN_CONNECTION_COUNT, m_SpinConnectionCount);
	DDX_Control(pDX, IDC_USE_DATABASE, m_UseDatabase);
	DDX_Control(pDX, IDC_WEB_CONTENT, m_WebContent);
	DDX_Control(pDX, IDC_HIDDEN, m_Hidden);
	DDX_Control(pDX, IDC_ODBC_BROWSE, m_OdbcBrowse);
	DDX_Control(pDX, IDC_ODBC_NAME, m_OdbcName);
	DDX_Text(pDX, IDC_ODBC_NAME, m_DatabaseValue);
	DDX_Text(pDX, IDC_LOGONID, m_LogonID);
	DDX_Text(pDX, IDC_PASSWORD, m_Password);
	DDX_Text(pDX, IDC_CONNECT_COUNT_EDIT, m_ConnectionCount);
	DDX_Check(pDX, IDC_CONNECTIONS, m_Connections);
	DDX_Check(pDX, IDC_ENABLE_CACHE_FILESERVER, m_bEnableCacheFile);
	DDX_Control(pDX, IDC_COMBO_IDX_SEARCH, m_cboIdxSearch);
	DDX_Control(pDX, IDC_BUTTON_CONFIGURE, m_btnConfigure);

	DDX_Text(pDX, IDC_DS_URL, m_DigitalSafeURL);
	DDX_Text(pDX, IDC_DS_MAILFROM, m_DigitalSafeMailFrom);
	DDX_Text(pDX, IDC_DS_RCPTTO, m_DigitalSafeRcptTo);
	DDX_Text(pDX, IDC_DS_DOMAIN, m_DigitalSafeDomainName);
	DDX_Text(pDX, IDC_DS_SSL_KEYFILE, m_DigitalSafeSSLKeyFile);
	DDX_Text(pDX, IDC_DS_SSL_KEYFILEPWD, m_DigitalSafeSSLKeyFilePassword);
	DDX_Text(pDX, IDC_DS_SSL_CACERT, m_DigitalSafeSSLCACert);
	DDX_Text(pDX, IDC_DS_SSL_CAPATH, m_DigitalSafeSSLCAPath);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(DataBaseProp, CDialog)
	//{{AFX_MSG_MAP(DataBaseProp)
	ON_BN_CLICKED(IDC_ODBC_BROWSE, OnOdbcBrowse)
	ON_EN_CHANGE(IDC_ODBC_NAME, Changed)
	ON_BN_CLICKED(IDHELP, OnHelp)
	ON_EN_CHANGE(IDC_LOGONID, Changed)
	ON_EN_CHANGE(IDC_PASSWORD, Changed)
	ON_BN_CLICKED(IDC_USE_DATABASE, Changed)
	ON_BN_CLICKED(IDC_WEB_CONTENT, Changed)
	ON_BN_CLICKED(IDC_HIDDEN, Changed)
	ON_BN_CLICKED(IDC_CONNECTIONS, Changed)
	ON_EN_CHANGE(IDC_CONNECT_COUNT_EDIT, Changed)
//	ON_EN_CHANGE(IDC_IDX_SERVER_NAME, Changed)
//	ON_BN_CLICKED(IDC_IDX_GIVEN_SERV_PORT, Changed)
//	ON_EN_CHANGE(IDC_IDX_SERVICE_PORT, Changed)
	ON_BN_CLICKED(IDC_ENABLE_CACHE_FILESERVER, OnEnableCacheFileserver)
	ON_BN_CLICKED(IDC_BUTTON_CONFIGURE, OnConfigure)
	ON_CBN_SELCHANGE(IDC_COMBO_IDX_SEARCH, OnSelchangeComboIdxSearch)
	ON_BN_CLICKED(IDC_BUTTON_ADVANCED, OnAdvanced)

	ON_EN_CHANGE(IDC_DS_URL, Changed)
	ON_EN_CHANGE(IDC_DS_MAILFROM, Changed)
	ON_EN_CHANGE(IDC_DS_RCPTTO, Changed)
	ON_EN_CHANGE(IDC_DS_DOMAIN, Changed)
	ON_EN_CHANGE(IDC_DS_SSL_KEYFILE, Changed)
	ON_EN_CHANGE(IDC_DS_SSL_KEYFILEPWD, Changed)
	ON_EN_CHANGE(IDC_DS_SSL_CACERT, Changed)
	ON_EN_CHANGE(IDC_DS_SSL_CAPATH, Changed)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// DataBaseProp message handlers
 
BOOL DataBaseProp::OnInitDialog()  
{
	UpdateData(0);

	IM::NrCiString strAdvancedServer(_T(""));
	IM::NrCiString strCacheEnabled(_T(""));

	IM::Registry	dbReg(NULL, HKEY_LOCAL_MACHINE, TEXT("Software\\Interwoven\\WorkSite\\imDmsSvc"));
	if (dbReg.Open(NULL, KEY_READ))
	{
		dbReg.GetStringValue(TEXT("Advanced Server"), strAdvancedServer);
		dbReg.GetStringValue(TEXT("Document Cache Enabled"), strCacheEnabled);

	}
	bool bAdvancedServer = strAdvancedServer == _T("Y") ? true : false;
	bool bCacheEnabled = strCacheEnabled == _T("Y") ? true : false;

	if(bAdvancedServer)
	{
		GetDlgItem(IDC_ENABLE_CACHE_FILESERVER)->ShowWindow(SW_SHOW);

		GetDlgItem(IDC_ENABLE_CACHE_FILESERVER)->EnableWindow(bCacheEnabled);
	}
	else
	{
		GetDlgItem(IDC_ENABLE_CACHE_FILESERVER)->ShowWindow(SW_HIDE);
	}

	m_cboIdxSearch.AddString(_T("Disable Indexer"));
	m_cboIdxSearch.AddString(_T("IDOL Indexer"));


	// if MODIFY
	if (m_DatabaseValue.IsEmpty() == FALSE)
    {
	    m_bAddMode = true;
    	m_OdbcName.EnableWindow(false);
        m_OdbcBrowse.EnableWindow(false);

		// Get repository information for this database and display
		m_pEntry = (IM::DmsDatabaseEntry *) m_pDatabaseList->Get((LPCTSTR)m_DatabaseValue);

		if (m_pEntry == NULL)
	    {
	    	Report(REP_WARN, IDS_DBPROP_115);
	        SendMessage(WM_CLOSE);
	        return TRUE;
	    }

		m_LogonID = m_pEntry->m_strLogonID.Get().c_str();
		m_Password = m_pEntry->m_strPassword.Get().c_str();
		((CButton*)GetDlgItem(IDC_USE_DATABASE))->SetCheck(m_pEntry->m_bPrimary.Get());
		((CButton*)GetDlgItem(IDC_WEB_CONTENT))->SetCheck(m_pEntry->m_bWebContent.Get());
		((CButton*)GetDlgItem(IDC_HIDDEN))->SetCheck(m_pEntry->m_bHidden.Get());

		if(bAdvancedServer)
		{
			m_bEnableCacheFile = !m_pEntry->m_bLocatedNear.Get();
			((CButton*)GetDlgItem(IDC_ENABLE_CACHE_FILESERVER))->SetCheck(m_bEnableCacheFile);
		}
		else
		{
			((CButton*)GetDlgItem(IDC_ENABLE_CACHE_FILESERVER))->SetCheck(false);
			m_bEnableCacheFile = false;
		}

		// only allow one web content database, for now....
		if ((m_bAllowWebContent == false) && (m_pEntry->m_bWebContent.Get() == false))
		{
			GetDlgItem(IDC_WEB_CONTENT)->EnableWindow(0);
		}
		else
		{
			GetDlgItem(IDC_WEB_CONTENT)->EnableWindow();
		}

		if (((CButton*)GetDlgItem(IDC_WEB_CONTENT))->GetCheck() == 0)
		{
			((CButton*)GetDlgItem(IDC_HIDDEN))->SetCheck(0);
			GetDlgItem(IDC_HIDDEN)->EnableWindow(0);
		}
		else
		{
			GetDlgItem(IDC_HIDDEN)->EnableWindow();
		}

		m_UseDatabase.EnableWindow(true);

		CString aString;
		_itot(m_pEntry->m_lConnectionCount.Get(), (_TCHAR*)(LPCSTR)aString.GetBuffer(10), 10);
		aString.ReleaseBuffer();
		m_ConnectionCount = aString;

		if (m_pEntry->m_bAsManyConnectionsAsThreads.Get() == true)
		{
			GetDlgItem(IDC_CONNECT_COUNT_EDIT)->EnableWindow(false);
			GetDlgItem(IDC_SPIN_CONNECTION_COUNT)->EnableWindow(false);
		}
		else
		{
			GetDlgItem(IDC_CONNECT_COUNT_EDIT)->EnableWindow();
			GetDlgItem(IDC_SPIN_CONNECTION_COUNT)->EnableWindow();
		}

		((CButton*)GetDlgItem(IDC_CONNECTIONS))->SetCheck(m_pEntry->m_bAsManyConnectionsAsThreads.Get());
        m_Connections = m_pEntry->m_bAsManyConnectionsAsThreads.Get();

		// 1 - Direct Connection (NO LONGER SUPPORTED - No Connection)
		// 2 - Proxy Connection (NO LONGER SUPPORTED - No Connection)
		// 3 - Search Service Connection
		// 4 - No Connection
		// 5 - Vivisimo Connection

		m_nConnection = m_pEntry->m_lIndexConnectType.Get();
		switch(m_nConnection)
		{
			case 0:
			case 1:
			case 2:
			{
				//
				// Deprecated settings. Clear and treat as disabled.
				//
				m_nConnection = 4;
				m_cboIdxSearch.SetCurSel(0);
				((CButton*) GetDlgItem(IDC_BUTTON_CONFIGURE))->EnableWindow(false);

				break;
			}
			case 3:
			{
				//
				// Verity search service connection
				//
				m_cboIdxSearch.SetCurSel(1);
				((CButton*) GetDlgItem(IDC_BUTTON_CONFIGURE))->EnableWindow(true);

				break;
			}
			case 4:
			{
				//
				// Disabled
				//
				m_cboIdxSearch.SetCurSel(0);
				((CButton*) GetDlgItem(IDC_BUTTON_CONFIGURE))->EnableWindow(false);

				break;
			}
			case 5:
			{
				m_cboIdxSearch.SetCurSel(2);
				((CButton*) GetDlgItem(IDC_BUTTON_CONFIGURE))->EnableWindow(true);

				break;
			}
			case 6:
			{
				m_cboIdxSearch.SetCurSel(1);
				((CButton*) GetDlgItem(IDC_BUTTON_CONFIGURE))->EnableWindow(true);

				break;
			}
			default:
			{
				//
				// Invalid setting. Clear and treat as disabled.
				//
				m_nConnection = 4;
				m_cboIdxSearch.SetCurSel(0);
				((CButton*) GetDlgItem(IDC_BUTTON_CONFIGURE))->EnableWindow(false);

				break;
			}

		}
		//Digital Safe configuration
		m_DigitalSafeURL = m_pEntry->m_strDigitalSafeURL.Get().c_str();
		m_DigitalSafeMailFrom = m_pEntry->m_strDigitalSafeMailFrom.Get().c_str();
		m_DigitalSafeRcptTo =m_pEntry->m_strDigitalSafeRcptTo.Get().c_str();
		m_DigitalSafeDomainName =m_pEntry->m_strDigitalSafeDomainName.Get().c_str();
		m_DigitalSafeSSLKeyFile =m_pEntry->m_strDigitalSafeSSLKeyFile.Get().c_str();
		m_DigitalSafeSSLKeyFilePassword = m_pEntry->m_strDigitalSafeSSLKeyFilePassword.Get().c_str();
		m_DigitalSafeSSLCACert = m_pEntry->m_strDigitalSafeSSLCACert.Get().c_str();
		m_DigitalSafeSSLCAPath = m_pEntry->m_strDigitalSafeSSLCAPath.Get().c_str();
    }
    else	// else ADD
    {
	    m_bAddMode = false;
        GetDlgItem(IDC_ODBC_NAME)->EnableWindow();
        GetDlgItem(IDC_ODBC_BROWSE)->EnableWindow();
        GetDlgItem(IDC_ODBC_NAME)->SetWindowText(_T(""));
		m_LogonID = _T("");
        m_Password = _T("");

		// Make repository information for this database.
		m_pEntry = new IM::DmsDatabaseEntry(_T("DUMMY"), _T("DUMMY"));

		m_UseDatabase.EnableWindow(true);
		if (m_bAllowPrimary == true)
		{
			m_UseDatabase.SetCheck(true);
		}
		else
		{
			m_UseDatabase.SetCheck(0);
		}
 
		// only allow one web content database, for now....
		if (m_bAllowWebContent == false)
		{
			GetDlgItem(IDC_WEB_CONTENT)->EnableWindow(0);
		}
		else
		{
			GetDlgItem(IDC_WEB_CONTENT)->EnableWindow();
		}

        m_Connections = true; 
        m_ConnectionCount = _T("0");
        GetDlgItem(IDC_CONNECT_COUNT_EDIT)->EnableWindow(false);
		m_OdbcName.SetFocus();

		m_nConnection = 4;
		m_cboIdxSearch.SetCurSel(0);
		((CButton*) GetDlgItem(IDC_BUTTON_CONFIGURE))->EnableWindow(false);

		//Digital Safe
		m_DigitalSafeURL = _T("");
		m_DigitalSafeMailFrom = _T("");
		m_DigitalSafeRcptTo = _T("");
		m_DigitalSafeDomainName = _T("");
		m_DigitalSafeSSLKeyFile = _T("");
		m_DigitalSafeSSLKeyFilePassword = _T("");
		m_DigitalSafeSSLCACert = _T("");
		m_DigitalSafeSSLCAPath = _T("");
	}


	// Allow OK button only after a change
	GetDlgItem(IDOK)->EnableWindow(false);

	SetDefID(IDCANCEL);

	m_SpinConnectionCount.SetRange(0, 100);
	m_SpinConnectionCount.SetBuddy(GetDlgItem(IDC_CONNECT_COUNT_EDIT));

	CDialog::OnInitDialog();

//	OnSelchangeComboIdxSearch();

	return(0);
}

void DataBaseProp::OnOdbcBrowse() 
{
	SelectODBC aSelectODBCdlg;
	aSelectODBCdlg.m_pDatabaseList = m_pDatabaseList;

	if (aSelectODBCdlg.DoModal() == IDOK)
	{
		m_OdbcName.SetWindowText(aSelectODBCdlg.odbcSourceName.c_str());
//		GetDlgItem(IDOK)->EnableWindow(true);
//		SetDefID(IDOK);
	}
}

void DataBaseProp::Changed() 
{
	if (!GetDlgItem(IDOK) || !::IsWindow(GetDlgItem(IDOK)->m_hWnd))
		return;

	if (((CButton*)GetDlgItem(IDC_CONNECTIONS))->GetCheck() == 1)
	{
		GetDlgItem(IDC_CONNECT_COUNT_EDIT)->EnableWindow(0);
		GetDlgItem(IDC_SPIN_CONNECTION_COUNT)->EnableWindow(0);
	}
	else
	{
		GetDlgItem(IDC_CONNECT_COUNT_EDIT)->EnableWindow();
		GetDlgItem(IDC_SPIN_CONNECTION_COUNT)->EnableWindow();
	}

	if (((CButton*)GetDlgItem(IDC_WEB_CONTENT))->GetCheck() == 0)
	{
		((CButton*)GetDlgItem(IDC_HIDDEN))->SetCheck(0);
		GetDlgItem(IDC_HIDDEN)->EnableWindow(0);
	}
	else
	{
		GetDlgItem(IDC_HIDDEN)->EnableWindow();
	}

	GetDlgItem(IDOK)->EnableWindow(true);
	SetDefID(IDOK);
}

void DataBaseProp::OnOK() 
{
	GetDlgItem(IDC_LOGONID)->GetWindowText(m_LogonID);
	GetDlgItem(IDC_PASSWORD)->GetWindowText(m_Password);

	GetDlgItem(IDC_DS_URL)->GetWindowText(m_DigitalSafeURL);
	GetDlgItem(IDC_DS_MAILFROM)->GetWindowText(m_DigitalSafeMailFrom);
	GetDlgItem(IDC_DS_RCPTTO)->GetWindowText(m_DigitalSafeRcptTo);
	GetDlgItem(IDC_DS_DOMAIN)->GetWindowText(m_DigitalSafeDomainName);
	GetDlgItem(IDC_DS_SSL_KEYFILE)->GetWindowText(m_DigitalSafeSSLKeyFile);
	GetDlgItem(IDC_DS_SSL_KEYFILEPWD)->GetWindowText(m_DigitalSafeSSLKeyFilePassword);
	GetDlgItem(IDC_DS_SSL_CACERT)->GetWindowText(m_DigitalSafeSSLCACert);
	GetDlgItem(IDC_DS_SSL_CAPATH)->GetWindowText(m_DigitalSafeSSLCAPath);

	m_OdbcName.GetWindowText(m_SavedOdbcName);
	GetDlgItem(IDC_CONNECT_COUNT_EDIT)->GetWindowText(m_ConnectionCount);

	if (!m_bAddMode)
    {
		IM::DmsDatabaseEntry *pEntry = NULL;
		pEntry = m_pEntry;
		m_pEntry = (IM::DmsDatabaseEntry *) m_pDatabaseList->NewEntry(m_SavedOdbcName);

		//
		// This is a butt ugly hack... -GH-
		//		
		m_pEntry->m_strIndexSourceServer.Set(pEntry->m_strIndexSourceServer.Get().c_str());
		m_pEntry->m_strIndexSource.Set(pEntry->m_strIndexSource.Get().c_str());
		m_pEntry->m_strIndexRepUser.Set(pEntry->m_strIndexRepUser.Get().c_str());
		m_pEntry->m_strIndexRepPassword.Set(pEntry->m_strIndexRepPassword.Get().c_str());
		m_pEntry->m_bIndexHTTPS.Set(pEntry->m_bIndexHTTPS.Get());
		m_pEntry->m_strIndexHTTPDomain.Set(pEntry->m_strIndexHTTPDomain.Get().c_str());
		m_pEntry->m_strIndexHTTPUser.Set(pEntry->m_strIndexHTTPUser.Get().c_str());
		m_pEntry->m_strIndexHTTPPassword.Set(pEntry->m_strIndexHTTPPassword.Get().c_str());
//		m_pEntry->m_strIndexLatestVersionSource.Set(pEntry->m_strIndexLatestVersionSource.Get().c_str());
//		m_pEntry->m_strIndexAllVersionsSource.Set(pEntry->m_strIndexAllVersionsSource.Get().c_str());
		m_pEntry->m_strIndexServer.Set(pEntry->m_strIndexServer.Get().c_str());
		m_pEntry->m_strIndexServerUserPwd.Set(pEntry->m_strIndexServerUserPwd.Get().c_str());
		m_pEntry->m_strIndexProduct.Set(pEntry->m_strIndexProduct.Get().c_str());
		m_pEntry->m_bIndexServerGivenPort.Set(pEntry->m_bIndexServerGivenPort.Get());
		m_pEntry->m_lIndexServerPort.Set(pEntry->m_lIndexServerPort.Get());

		m_pEntry->m_bAllowFlatSpaceDocuments.Set(pEntry->m_bAllowFlatSpaceDocuments.Get());
		m_pEntry->m_lUndeclareRecord.Set(pEntry->m_lUndeclareRecord.Get());
		m_pEntry->m_lLocale.Set(pEntry->m_lLocale.Get());
		
		m_pEntry->m_strRepositoryName.Set(pEntry->m_strRepositoryName.Get().c_str());
		m_pEntry->m_lSecurityKey1.Set(pEntry->m_lSecurityKey1.Get());
		m_pEntry->m_lSecurityKey2.Set(pEntry->m_lSecurityKey2.Get());
		m_pEntry->m_lSecurityKey3.Set(pEntry->m_lSecurityKey3.Get());
		m_pEntry->m_lSecurityKey4.Set(pEntry->m_lSecurityKey4.Get());

		delete pEntry;
	}

	m_pEntry->m_lConnectionType.Set(IM::DatabaseEntry::Database);

	m_pEntry->m_strLogonID.Set(m_LogonID);
	m_pEntry->m_strPassword.Set(m_Password);
	m_pEntry->m_bPrimary.Set((((CButton*)GetDlgItem(IDC_USE_DATABASE))->GetCheck() == 1));
	m_pEntry->m_bWebContent.Set((((CButton*)GetDlgItem(IDC_WEB_CONTENT))->GetCheck() == 1));
	m_pEntry->m_bHidden.Set((((CButton*)GetDlgItem(IDC_HIDDEN))->GetCheck() == 1));
	m_pEntry->m_bAsManyConnectionsAsThreads.Set((((CButton*)GetDlgItem(IDC_CONNECTIONS))->GetCheck() == 1));
	m_pEntry->m_lConnectionCount.Set(_ttoi(m_ConnectionCount));
	m_pEntry->m_lIndexConnectType.Set(m_nConnection);
	m_bEnableCacheFile = ((CButton*)GetDlgItem(IDC_ENABLE_CACHE_FILESERVER))->GetCheck();
	m_pEntry->m_bLocatedNear.Set(!(m_bEnableCacheFile == BST_CHECKED));

	//Digital Safe configuration
	m_pEntry->m_strDigitalSafeURL.Set(m_DigitalSafeURL);
	m_pEntry->m_strDigitalSafeMailFrom.Set(m_DigitalSafeMailFrom);
	m_pEntry->m_strDigitalSafeRcptTo.Set(m_DigitalSafeRcptTo);
	m_pEntry->m_strDigitalSafeDomainName.Set(m_DigitalSafeDomainName);
	m_pEntry->m_strDigitalSafeSSLKeyFile.Set(m_DigitalSafeSSLKeyFile);
	m_pEntry->m_strDigitalSafeSSLKeyFilePassword.Set(m_DigitalSafeSSLKeyFilePassword);
	m_pEntry->m_strDigitalSafeSSLCACert.Set(m_DigitalSafeSSLCACert);
	m_pEntry->m_strDigitalSafeSSLCAPath.Set(m_DigitalSafeSSLCAPath);

	CString strIndexServer;
	CString strIndexPort;
	long lIndexPort = 0;
	bool bSpecifyPort = false;

	try
	{
		if (!m_bAddMode)
		{
			m_pDatabaseList->Add(m_pEntry);
		}
		m_pEntry->StoreInRegistry();
	}
	catch (IM::Exception &)
	{
		Report(REP_WARN, IDS_DBPROP_117);
		return;
	}
	
	CDialog::OnOK();
}

void DataBaseProp::OnHelp() 
{	
	::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, 22);
}

void DataBaseProp::OnEnableCacheFileserver() 
{
	Changed();
}

void DataBaseProp::OnSelchangeComboIdxSearch()
{
	long lIdxSearchType = m_cboIdxSearch.GetCurSel( );

	switch(lIdxSearchType)
	{
	case 0:
		{
			//
			// Disable Indexer
			//
			((CButton*) GetDlgItem(IDC_BUTTON_CONFIGURE))->EnableWindow(false);
			m_nConnection = 4;

			break;
		}
	case 1:
		{
			//
			// Enable IDOL Indexer
			//
			((CButton*) GetDlgItem(IDC_BUTTON_CONFIGURE))->EnableWindow(true);
			m_nConnection = 6;

			break;
		}
	default:
		{
			((CButton*) GetDlgItem(IDC_BUTTON_CONFIGURE))->EnableWindow(false);
			m_nConnection = 4;

			break;
		}
	}

	Changed();
}

void DataBaseProp::OnConfigure()
{
	long lIdxSearchType = m_cboIdxSearch.GetCurSel( );

	switch(lIdxSearchType)
	{
	case 1:
		{
			//
			// Present IDOL Indexer Configuration Dialog
			//
			m_OdbcName.GetWindowText(m_SavedOdbcName);
			IdolIndexerProp *pIdolIdxrDlg = new IdolIndexerProp(m_pEntry,m_SavedOdbcName, this);

			if (pIdolIdxrDlg->DoModal() == IDOK)
			{
				Changed();
			}

			delete pIdolIdxrDlg;

			break;
		}
	default:
		{
			break;
		}
	};
}

void DataBaseProp::OnAdvanced()
{	
	DataBaseAdvProp *pDbAdvPropDlg = new DataBaseAdvProp(m_pEntry, this);	
	if (pDbAdvPropDlg->DoModal() == IDOK)
	{
		Changed();
	}
	delete pDbAdvPropDlg;
}
