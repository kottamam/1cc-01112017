#if !defined(__ServerProp_H__)
#define __ServerProp_H__

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ServerProp.h : header file
//

//class DmsDatabaseList;

/////////////////////////////////////////////////////////////////////////////
// ServerProp dialog

class ServerProp : public CDialog
{
// Construction
public:
	ServerProp(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(ServerProp)
	enum { IDD = IDD_SERVER_PROPERTIES };
	CSpinButtonCtrl	m_SpinConnectionCount;
	CString	m_DatabaseValue;
	CString	m_LogonID;
	CString	m_Password;
	CString	m_ConnectionCount;
	BOOL	m_Connections;
	int		m_nConnectionType;
	CString	m_strServer;
	BOOL	m_bSpecifyServicePort;
	CString	m_strServicePort;
	BOOL	m_bSpecifyFilePort;
	CString	m_strFilePort;
	//}}AFX_DATA
	IM::DatabaseEntryList	*m_pDatabaseList;
	IM::DmsDatabaseEntry	*m_pEntry;
    bool					m_bAddMode;
	CString					m_SavedOdbcName;
	long					m_lLocale;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(ServerProp)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(ServerProp)
	virtual BOOL OnInitDialog();
	afx_msg void Changed();
	virtual void OnOK();
	afx_msg void OnHelp();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	bool needPrimaryDatabase();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(__ServerProp_H__)