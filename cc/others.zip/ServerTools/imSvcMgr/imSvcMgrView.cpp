#include "stdafx.h"
#include "imSvcMgr.h"
#include <Report\Report.h>


#include "SelectServer.h"
#include "FindServers.h"
#include "StartingService.h"
#include "DatabaseSetup.h"
#include "DMSServiceProp.h"
#include "DMSStartup.h"
#include "idxMgrProperties.h"
#include "serviceAbout.h" 
#include "mainfrm.h"
#include "IDXSearchServiceProp.h"

#include "imSvcMgrDoc.h"
#include "CntrItem.h"
#include "listctrlex.h"
#include "imSvcMgrView.h"
#include "FileServerPropertySheet.h"
#include "LookupManager.h"

#include "RulesManagerProp.h"
#include "KMIndexerProperties.h"
#include "WkAtIndxrProperties.h"
#include "WkDreProperties.h"
#include "EmsServiceProp.h"
#include "IdxSvcProp.h"
#include "EOLServiceProp.h"
#include "LNServiceProp.h"

#include "DSConnections.h"
#include "DSSchedule.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern LookupManager	*gpLookupMgr;


IMPLEMENT_DYNCREATE(CSvcMgrView, CListView)

BEGIN_MESSAGE_MAP(CSvcMgrView, CListView)
	//{{AFX_MSG_MAP(CSvcMgrView)
	ON_WM_DESTROY()
	ON_WM_SETFOCUS()
	ON_WM_SIZE()
	ON_COMMAND(ID_OLE_INSERT_NEW, OnInsertObject)
	ON_COMMAND(ID_CANCEL_EDIT_CNTR, OnCancelEditCntr)
	ON_COMMAND(ID_CANCEL_EDIT_SVC, OnCancelEditSvc)
	ON_WM_HSCROLL()
	ON_WM_VSCROLL()
	ON_WM_TIMER()
	ON_NOTIFY_REFLECT(NM_CLICK, OnClick)
	ON_NOTIFY_REFLECT(LVN_COLUMNCLICK, OnColumnclick)
	ON_WM_KEYDOWN()
	ON_NOTIFY_REFLECT(NM_RCLICK, OnClick)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CListView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CListView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CListView::OnFilePrintPreview)
	ON_UPDATE_COMMAND_UI(ID_UNREGISTER_SERVER, OnUpdateDisplay)
	ON_UPDATE_COMMAND_UI(ID_START_SERVICE, OnUpdateStart)
	ON_UPDATE_COMMAND_UI(ID_STOP_SERVICE, OnUpdateStop)
	ON_UPDATE_COMMAND_UI(ID_DATABASES_SETUP, OnUpdateDisplayDbSetup)
	ON_UPDATE_COMMAND_UI(ID_FILE_SERVER_SETUP, OnUpdateDisplayFileServer)
	ON_UPDATE_COMMAND_UI(ID_SERVICE_PROPERTIES, OnUpdateDisplaySvcProperties)
	ON_UPDATE_COMMAND_UI(ID_STARTUP_PROPERTIES, OnUpdateDisplay)
	ON_UPDATE_COMMAND_UI(ID_SERVICE_ABOUT, OnUpdateDisplay)
	ON_UPDATE_COMMAND_UI(ID_VIEW_LOG, OnUpdateViewLog)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSvcMgrView construction/destruction

CSvcMgrView::CSvcMgrView()
	: CListView()
{
	//{{AFX_DATA_INIT(CSvcMgrView)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_pSelection = NULL;
	// TODO: add construction code here
}

CSvcMgrView::~CSvcMgrView()
{
}

void CSvcMgrView::DoDataExchange(CDataExchange* pDX)
{
	CListView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSvcMgrView)
	//}}AFX_DATA_MAP
}

BOOL CSvcMgrView::PreCreateWindow(CREATESTRUCT& cs)
{
	cs.style = cs.style | LVS_REPORT | LVS_SORTASCENDING | LVS_SINGLESEL;   
	//cs.dwExStyle = cs.dwExStyle | LVS_EX_FULLROWSELECT;
	return CListView::PreCreateWindow(cs);
}

void CSvcMgrView::OnInitialUpdate()
{
	CListView::OnInitialUpdate();

	m_headerctrl.SubclassWindow(::GetDlgItem(GetListCtrl().m_hWnd,0));

	LRESULT dwStyle = ::SendMessage(GetListCtrl().GetSafeHwnd(), LVM_GETEXTENDEDLISTVIEWSTYLE, 0L, 0L);
	dwStyle |= LVS_EX_FULLROWSELECT;	
	::SendMessage(GetListCtrl().GetSafeHwnd(), LVM_SETEXTENDEDLISTVIEWSTYLE, 0L, dwStyle);
	
	CRect rect;
	GetListCtrl().DeleteAllItems();
	GetParentFrame()->RecalcLayout();

	m_pSelection = NULL;    // initialize selection

	LV_COLUMN lvc;
	lvc.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;

	// insert 4 columns and modify the new header items
	GetListCtrl().GetWindowRect(&rect);

	GetListCtrl().InsertColumn(0, _T("Computer"), LVCFMT_LEFT, (rect.Width() * 4/16), 0);
	GetListCtrl().InsertColumn(1, _T("Service"), LVCFMT_LEFT, (rect.Width() * 6/16), 1);
	GetListCtrl().InsertColumn(2, _T("State"), LVCFMT_LEFT, (rect.Width() * 2/16), 2);
	GetListCtrl().InsertColumn(3, _T("Comments"), LVCFMT_LEFT, (rect.Width() * 4/16) - 2, 3);


	HD_ITEM curItem;

	// retrieve embedded header control
	CHeaderCtrl* pHdrCtrl = NULL;
	pHdrCtrl = GetListCtrl().GetHeaderCtrl();
	pHdrCtrl->SetImageList(NULL);

	// add bmaps to each header item
	curItem.pszText = _T("Computer");
	curItem.mask = HDI_TEXT;
	curItem.iImage = 0;
	curItem.fmt= HDF_LEFT | HDI_TEXT | HDF_STRING;
	pHdrCtrl->SetItem(0, &curItem);

	curItem.pszText = _T("Service");
	curItem.mask = HDI_TEXT;
	curItem.iImage = 0;
	curItem.fmt= HDF_LEFT | HDI_TEXT | HDF_STRING;
	pHdrCtrl->SetItem(1, &curItem);

	curItem.pszText = _T("State");
	curItem.mask = HDI_TEXT;
	curItem.iImage = 0;
	curItem.fmt = HDF_LEFT | HDI_TEXT | HDF_STRING;
	pHdrCtrl->SetItem(2, &curItem);

	curItem.pszText = _T("Comments");
	curItem.mask = HDI_TEXT;
	curItem.iImage = 0;
	curItem.fmt = HDF_LEFT | HDI_TEXT | HDF_STRING;
	pHdrCtrl->SetItem(3, &curItem);

	m_TimerID = SetTimer(3000, 5000, NULL); 
}

/////////////////////////////////////////////////////////////////////////////
// CSvcMgrView printing

BOOL CSvcMgrView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CSvcMgrView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CSvcMgrView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

void CSvcMgrView::OnPrint(CDC* pDC, CPrintInfo* /*pInfo*/)
{
	// TODO: add customized printing code here
}

void CSvcMgrView::OnDestroy()
{
	// Deactivate the item on destruction; this is important
	// when a splitter view is being used.
   CListView::OnDestroy();
   COleClientItem* pActiveItem = GetDocument()->GetInPlaceActiveItem(this);
   if (pActiveItem != NULL && pActiveItem->GetActiveView() == this)
   {
      pActiveItem->Deactivate();
      ASSERT(GetDocument()->GetInPlaceActiveItem(this) == NULL);
   }
}


/////////////////////////////////////////////////////////////////////////////
// OLE Client support and commands

BOOL CSvcMgrView::IsSelected(const CObject* pDocItem) const
{
	// The implementation below is adequate if your selection consists of
	//  only CSvcMgrCntrItem objects.  To handle different selection
	//  mechanisms, the implementation here should be replaced.
	return pDocItem == m_pSelection;
}

void CSvcMgrView::OnInsertObject()
{
	// Invoke the standard Insert Object dialog box to obtain information
	//  for new CSvcMgrCntrItem object.
	COleInsertDialog dlg;
	if (dlg.DoModal() != IDOK)
		return;

	BeginWaitCursor();

	CSvcMgrCntrItem* pItem = NULL;
	TRY
	{
		// Create new item connected to this document.
		CSvcMgrDoc* pDoc = GetDocument();
		ASSERT_VALID(pDoc);
		pItem = new CSvcMgrCntrItem(pDoc);
		ASSERT_VALID(pItem);

		// Initialize the item from the dialog data.
		if (!dlg.CreateItem(pItem))
			AfxThrowMemoryException();  // any exception will do
		ASSERT_VALID(pItem);
		
        if (dlg.GetSelectionType() == COleInsertDialog::createNewItem)
			pItem->DoVerb(OLEIVERB_SHOW, this);

		ASSERT_VALID(pItem);

		// As an arbitrary user interface design, this sets the selection
		//  to the last item inserted.

		// TODO: reimplement selection as appropriate for your application

		m_pSelection = pItem;   // set selection to last inserted item
		pDoc->UpdateAllViews(NULL);
	}
	CATCH(CException, e)
	{
		if (pItem != NULL)
		{
			ASSERT_VALID(pItem);
			pItem->Delete();
		}
		AfxMessageBox(IDP_FAILED_TO_CREATE);
	}
	END_CATCH

	EndWaitCursor();
}

// The following command handler provides the standard keyboard
//  user interface to cancel an in-place editing session.  Here,
//  the container (not the server) causes the deactivation.
void CSvcMgrView::OnCancelEditCntr()
{
	// Close any in-place active item on this view.
	COleClientItem* pActiveItem = GetDocument()->GetInPlaceActiveItem(this);
	if (pActiveItem != NULL)
	{
		pActiveItem->Close();
	}
	ASSERT(GetDocument()->GetInPlaceActiveItem(this) == NULL);
}

// Special handling of OnSetFocus and OnSize are required for a container
//  when an object is being edited in-place.
void CSvcMgrView::OnSetFocus(CWnd* pOldWnd)
{
	COleClientItem* pActiveItem = GetDocument()->GetInPlaceActiveItem(this);
	if (pActiveItem != NULL &&
		pActiveItem->GetItemState() == COleClientItem::activeUIState)
	{
		// need to set focus to this item if it is in the same view
		CWnd* pWnd = pActiveItem->GetInPlaceWindow();
		if (pWnd != NULL)
		{
			pWnd->SetFocus();   // don't call the base class
			return;
		}
	}

	CListView::OnSetFocus(pOldWnd);
}

void CSvcMgrView::OnSize(UINT nType, int cx, int cy)
{
	CListView::OnSize(nType, cx, cy);
}

/////////////////////////////////////////////////////////////////////////////
// OLE Server support

// The following command handler provides the standard keyboard
//  user interface to cancel an in-place editing session.  Here,
//  the server (not the container) causes the deactivation.
void CSvcMgrView::OnCancelEditSvc()
{
	GetDocument()->OnDeactivateUI(FALSE);
}

/////////////////////////////////////////////////////////////////////////////
// CSvcMgrView diagnostics

#ifdef _DEBUG
void CSvcMgrView::AssertValid() const
{
	CListView::AssertValid();
}

void CSvcMgrView::Dump(CDumpContext& dc) const
{
	CListView::Dump(dc);
}

CSvcMgrDoc* CSvcMgrView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CSvcMgrDoc)));
	return (CSvcMgrDoc*)m_pDocument;
}
#endif //_DEBUG 

///////////////////////////////////////////////////////////////////////////// 
// CSvcMgrView message handlers

void CSvcMgrView::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	CListView::OnHScroll(nSBCode, nPos, pScrollBar);
}

void CSvcMgrView::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	CListView::OnVScroll(nSBCode, nPos, pScrollBar);
}

void CSvcMgrView::RegisterServer()
{
	SelectServer aSelectServerDlg;

	if (aSelectServerDlg.DoModal() == IDOK)
	{
		if (aSelectServerDlg.m_Server.c_str() == _T(""))
			return;

		if (GetDocument()->isServerInList(aSelectServerDlg.m_Server.c_str()) == true)
			Report(REP_INFO, IDS_MAIN_148, aSelectServerDlg.m_Server.c_str());
		else
		{
			IM::NrString *newServer = new IM::NrString(aSelectServerDlg.m_Server);
			CWaitCursor wait;

			if (GetDocument()->addServer(aSelectServerDlg.m_Server.c_str()) == true)
			{
				// add server name to registry
				IM::Registry		serverReg(NULL, HKEY_CURRENT_USER, KEY_NRSCONF_PATH);
				serverReg.AddPath(_T("\\"));
				serverReg.AddPath(newServer->c_str());
				serverReg.OpenOrCreate(NULL, KEY_ALL_ACCESS);
			}
		}
	}
}

void CSvcMgrView::UnregisterServer()
{
	if (GetSelectedService() == NULL)
		return;

	// remove server (with potentially multiple services) from the service list
	IM::NrString aServerName = GetSelectedService()->m_strComputerName.c_str();
	ServiceList::iterator it = GetDocument()->GetServiceList().begin();
	
	while (it != GetDocument()->GetServiceList().end())
	{
		if (it->get()->m_strComputerName.compare(aServerName.c_str()) == 0)
		{
			GetDocument()->GetServiceList().erase(it);
			it = GetDocument()->GetServiceList().begin();
		}
		else
			++it;
	}

	SetSelectedService(NULL);

	// remove server (with potentially multiple services from the ListView control
	int index;
	LVFINDINFO pFindInfo;
	pFindInfo.flags = LVFI_STRING;
	pFindInfo.psz = aServerName.c_str();

/*	if ((index = GetListCtrl().FindItem(&pFindInfo)) != -1)
		GetListCtrl().DeleteItem(index);

	if ((index = GetListCtrl().FindItem(&pFindInfo)) != -1)
		GetListCtrl().DeleteItem(index);

	if ((index = GetListCtrl().FindItem(&pFindInfo)) != -1)
	*/
	while((index = GetListCtrl().FindItem(&pFindInfo)) != -1)
	{
		GetListCtrl().DeleteItem(index);	
	}

	// remove server from registry
	IM::Registry serverReg(NULL, HKEY_CURRENT_USER, KEY_NRSCONF_PATH);

	if (serverReg.Open(NULL, KEY_ALL_ACCESS) == true)
		serverReg.DeleteSubKey(aServerName.c_str());

	UpdateDisplay();
}

void CSvcMgrView::Find_Servers()
{
	FindServers aFindServersDlg;
	aFindServersDlg.SetDocument(GetDocument());
	aFindServersDlg.DoModal();
}

void CSvcMgrView::StartService()
{
	if (GetSelectedService() == NULL)
		return;

	// determine the current displayed status; if matching request then done
	if (GetSelectedService()->IsRunning() == true)
	{
		UpdateDisplay();
		return;
	}

	StartingService aStartingServiceDlg;
	aStartingServiceDlg.startType = ST_START;
	aStartingServiceDlg.m_pService = GetSelectedService();
	aStartingServiceDlg.DoModal();
	UpdateDisplay();
}

void CSvcMgrView::StopService()
{
	if (GetSelectedService() == NULL)
		return;

	// determine the current displayed status; if matching request then done
	if (GetSelectedService()->IsStopped() == true)
	{
		UpdateDisplay();
		return;
	}

	StartingService aStartingServiceDlg;
	aStartingServiceDlg.startType = ST_STOP;
	aStartingServiceDlg.m_pService = GetSelectedService();
	aStartingServiceDlg.DoModal();
	UpdateDisplay();
}
 
void CSvcMgrView::DataBaseSetup()
{
	if (GetSelectedService() == NULL)
		return;

	if (dynamic_cast<CDSSyncSvc *>(GetSelectedService()) != NULL)
	{
		IM::CDSSyncSvc SyncSvc( GetSelectedService( )->m_strComputerName.c_str( ) );
		SyncSvc.LoadFromRegistry( );

		DSConnections dlg( this );
		dlg.m_strServer = GetSelectedService( )->m_strComputerName.c_str( );
		dlg.SetRegistryObject( &SyncSvc );
		dlg.DoModal( );
	}
	else
	{
		DatabaseSetup aDatabaseSetupDlg;
		aDatabaseSetupDlg.serverName = GetSelectedService()->m_strComputerName.c_str();
		aDatabaseSetupDlg.strDisplayName = GetSelectedService()->m_strServiceDisplayName;
		if (dynamic_cast<DmsServiceConfiguration *>(GetSelectedService()) != NULL)
			aDatabaseSetupDlg.serviceType = SVC_DMS;
		else if (dynamic_cast<IdxMgrServiceConfiguration *>(GetSelectedService()) != NULL)
			aDatabaseSetupDlg.serviceType = SVC_IDXMGR;
		else if (dynamic_cast<IdxSearchServiceConfiguration *>(GetSelectedService()) != NULL)
			aDatabaseSetupDlg.serviceType = SVC_IDXSCH;
		else if (dynamic_cast<RulesServiceConfiguration *>(GetSelectedService()) != NULL)
			aDatabaseSetupDlg.serviceType = SVC_RULE;
		else if (dynamic_cast<FmaServiceConfiguration *>(GetSelectedService()) != NULL)
			aDatabaseSetupDlg.serviceType = SVC_FMA;
		else if (dynamic_cast<EFSServiceConfiguration *>(GetSelectedService()) != NULL)
			aDatabaseSetupDlg.serviceType = SVC_EFS;
		else if (dynamic_cast<PrintRenditionServiceConfiguration *>(GetSelectedService()) != NULL)
			aDatabaseSetupDlg.serviceType = SVC_PRINTREND;
		else if (dynamic_cast<WkDreServiceConfiguration *>(GetSelectedService()) != NULL)
			aDatabaseSetupDlg.serviceType = SVC_WKDRE;
		else if (dynamic_cast<WkIndxrServiceConfiguration *>(GetSelectedService()) != NULL)
			aDatabaseSetupDlg.serviceType = SVC_WKIDX;
		else if (dynamic_cast<WkAtIndxrServiceConfiguration *>(GetSelectedService()) != NULL)
			aDatabaseSetupDlg.serviceType = SVC_WKATIDX;
		else if (dynamic_cast<IM::EMSServiceConfiguration *>(GetSelectedService()) != NULL)
			aDatabaseSetupDlg.serviceType = SVC_EMS;
		else if (dynamic_cast<IM::CIFSServiceConfiguration *>(GetSelectedService()) != NULL)
			aDatabaseSetupDlg.serviceType = SVC_CIFS;
		else if (dynamic_cast<IM::IDXSVCConfiguration*>(GetSelectedService()) != NULL)
			aDatabaseSetupDlg.serviceType = SVC_IDX;
		else if (dynamic_cast<IM::EMailSvcConfiguration*>(GetSelectedService()) != NULL)
			aDatabaseSetupDlg.serviceType = SVC_EOL;
		else if (dynamic_cast<IM::LNEMailSvcConfiguration*>(GetSelectedService()) != NULL)
			aDatabaseSetupDlg.serviceType = SVC_LN;
		else
			return;

		aDatabaseSetupDlg.DoModal();
	}
}

void CSvcMgrView::FileServerSetup()
{
	if (GetSelectedService() == NULL)
		return;

	FileServerPropSheet propSheet;
	IM::FileServerConfiguration *pFileServerConfiguration = new IM::FileServerConfiguration(GetSelectedService()->m_strComputerName.c_str());

	propSheet.m_psh.dwFlags |= PSH_NOAPPLYNOW;
	propSheet.m_pFileServerConfiguration = pFileServerConfiguration;
	IM::NrString aCaption = BuildCaption(IDS_FILE_231, pFileServerConfiguration->m_strComputerName.c_str());
	propSheet.SetTitle(aCaption.c_str());
	propSheet.DoModal();
	delete pFileServerConfiguration;
}

void CSvcMgrView::ServiceProperties()
{
	if (GetSelectedService() == NULL)
		return;
    // determine service type and display and manage appropriate properties dialog
	if (dynamic_cast<DmsServiceConfiguration *>(GetSelectedService()) != NULL)
	{
		DMSServiceProp aServicePropertiesDlg;
		aServicePropertiesDlg.m_pService = (DmsServiceConfiguration *) GetSelectedService();
		aServicePropertiesDlg.DoModal();
	}
	//Rules service conf
	if (dynamic_cast<RulesServiceConfiguration *>(GetSelectedService()) != NULL)
	{
		CRulesManagerProp pDlg;
		pDlg.m_pService = (RulesServiceConfiguration *) GetSelectedService();
		pDlg.DoModal();
	}

	if (dynamic_cast<IdxMgrServiceConfiguration *>(GetSelectedService()) != NULL)
	{
		IdxMgrProperties aIdxMgrPropertiesDlg;
		aIdxMgrPropertiesDlg.m_pService = (IdxMgrServiceConfiguration *) GetSelectedService();
		aIdxMgrPropertiesDlg.DoModal();
	}

	if (dynamic_cast<IdxSearchServiceConfiguration *>(GetSelectedService()) != NULL)
	{
		CIDXSearchServiceProp aIdxSearchPropertiesDlg;
		aIdxSearchPropertiesDlg.m_pService = (IdxSearchServiceConfiguration *) GetSelectedService();
		aIdxSearchPropertiesDlg.DoModal();
	}

	if (dynamic_cast<WkDreServiceConfiguration *>(GetSelectedService()) != NULL)
	{
		WkDreProperties aWkPropDlg;
		aWkPropDlg.m_pService = (WkDreServiceConfiguration *) GetSelectedService();
		aWkPropDlg.DoModal();
	}

	if (dynamic_cast<WkIndxrServiceConfiguration *>(GetSelectedService()) != NULL)
	{
		KMIndexerProperties aWkPropDlg;
		aWkPropDlg.m_pService = (WkIndxrServiceConfiguration *) GetSelectedService();
		aWkPropDlg.DoModal();
	}

	if (dynamic_cast<WkAtIndxrServiceConfiguration *>(GetSelectedService()) != NULL)
	{
		WkAtIndxrProperties aWkPropDlg;
		aWkPropDlg.m_pService = (WkAtIndxrServiceConfiguration *) GetSelectedService();
		aWkPropDlg.DoModal();
	}

	if (dynamic_cast<CDSSyncSvc *>(GetSelectedService()) != NULL)
	{
		IM::CDSSyncSvc SyncSvc( GetSelectedService( )->m_strComputerName.c_str( ) );
		SyncSvc.LoadFromRegistry( );

		DSSchedule dlg( this );
		dlg.m_strServer = GetSelectedService( )->m_strComputerName.c_str( );
		dlg.m_pService = &SyncSvc;
		dlg.DoModal( );
	}

	if (dynamic_cast<EMSServiceConfiguration *>(GetSelectedService()) != NULL)
	{
		EmsServiceProp aEmsPropDlg;
		aEmsPropDlg.m_pService = (EMSServiceConfiguration *) GetSelectedService();
		aEmsPropDlg.DoModal();
	}

	if (dynamic_cast<IDXSVCConfiguration *>(GetSelectedService()) != NULL)
	{
		CIdxSvcProp aIdxSvcPropDlg;
		aIdxSvcPropDlg.m_pService = (IDXSVCConfiguration *) GetSelectedService();
		aIdxSvcPropDlg.DoModal();
	}

	if (dynamic_cast<EMailSvcConfiguration *>(GetSelectedService()) != NULL)
	{
		CEOLServiceProp oEolSvcPropDlg;
		oEolSvcPropDlg.m_pService = (EMailSvcConfiguration*)GetSelectedService();
		oEolSvcPropDlg.DoModal();
	}

	if (dynamic_cast<LNEMailSvcConfiguration *>(GetSelectedService()) != NULL)
	{
		CLNServiceProp oLNSvcPropDlg;
		oLNSvcPropDlg.m_pService = (LNEMailSvcConfiguration*)GetSelectedService();
		oLNSvcPropDlg.DoModal();
	}
}

void CSvcMgrView::StartupProperties()
{
	if (GetSelectedService() == NULL)
		return;

	DMSStartup aStartupDlg;
	aStartupDlg.m_pService = GetSelectedService();
	aStartupDlg.DoModal();
	UpdateDisplay();
}

void CSvcMgrView::Service_About()
{
	if (GetSelectedService() == NULL)
		return;

	ServiceAbout aServiceAboutDlg;
	aServiceAboutDlg.m_pService = GetSelectedService();
	aServiceAboutDlg.DoModal();
	UpdateDisplay();
}

void CSvcMgrView::UpdateDisplay() 
{
	if (GetSelectedService() == NULL)
	{
		((CMainFrame*)AfxGetMainWnd())->m_wndToolBar.LoadToolBar(IDR_MAINFRAME);
		return;
	}
	else
		((CMainFrame*)AfxGetMainWnd())->m_wndToolBar.LoadToolBar(IDR_MAINFRAME2);

	int nItem = GetListCtrl().GetNextItem(-1, LVNI_ALL | LVNI_SELECTED);
	LV_ITEM lvitem;
	lvitem.mask = LVIF_TEXT | LVIF_IMAGE;
	lvitem.iItem = nItem;
	lvitem.iSubItem = 0;

	if (GetSelectedService()->IsRunning() == TRUE)
		lvitem.iImage = 0;
	else
		lvitem.iImage = 1;

	lvitem.pszText = (_TCHAR*)GetSelectedService()->m_strComputerName.c_str();
	GetListCtrl().SetItem(&lvitem); // modify existing item (the sub-item text)

	lvitem.iSubItem = 1;
	lvitem.pszText = (_TCHAR*)GetSelectedService()->m_strServiceDisplayName.c_str();
	GetListCtrl().SetItem(&lvitem); // modify existing item (the sub-item text)

	lvitem.iSubItem = 2;
	lvitem.pszText = (_TCHAR*)GetSelectedService()->GetStatusString();
	GetListCtrl().SetItem(&lvitem); // modify existing item (the sub-item text)

	lvitem.iSubItem = 3;
	lvitem.pszText = (_TCHAR*)GetSelectedService()->m_strComments.Get().c_str();
	GetListCtrl().SetItem(&lvitem); // modify existing item (the sub-item text)
}

void CSvcMgrView::OnUpdateDisplay(CCmdUI* pCmdUI) 
{
	if (GetSelectedService() == NULL)
		pCmdUI->Enable(FALSE);
	else
		pCmdUI->Enable(TRUE);
}

void CSvcMgrView::OnUpdateDisplayFileServer(CCmdUI* pCmdUI) 
{
	if (GetSelectedService() == NULL)
		pCmdUI->Enable(FALSE);
	else if(dynamic_cast<FmaServiceConfiguration *>(GetSelectedService()) != NULL)
		pCmdUI->Enable(FALSE);
	else if(dynamic_cast<PrintRenditionServiceConfiguration *>(GetSelectedService()) != NULL)
		pCmdUI->Enable(FALSE);
	else if(dynamic_cast<EFSServiceConfiguration *>(GetSelectedService()) != NULL)
		pCmdUI->Enable(FALSE);
	else if(dynamic_cast<WkDreServiceConfiguration *>(GetSelectedService()) != NULL)
		pCmdUI->Enable(FALSE);
	else if(dynamic_cast<WkAtIndxrServiceConfiguration *>(GetSelectedService()) != NULL)
		pCmdUI->Enable(FALSE);
	else if(dynamic_cast<EMSServiceConfiguration *>(GetSelectedService()) != NULL)
		pCmdUI->Enable(FALSE);
	else if (dynamic_cast<CDSSyncSvc *>(GetSelectedService()) != NULL)
		pCmdUI->Enable(FALSE);
	else if(dynamic_cast<CIFSServiceConfiguration *>(GetSelectedService()) != NULL)
		pCmdUI->Enable(FALSE);
	else if(dynamic_cast<IDXSVCConfiguration *>(GetSelectedService()) != NULL)
		pCmdUI->Enable(FALSE);
	else if(dynamic_cast<EMailSvcConfiguration *>(GetSelectedService()) != NULL)
		pCmdUI->Enable(FALSE);
	else if(dynamic_cast<LNEMailSvcConfiguration *>(GetSelectedService()) != NULL)
		pCmdUI->Enable(FALSE);
	else
		pCmdUI->Enable(TRUE);
}

void CSvcMgrView::OnUpdateDisplayDbSetup(CCmdUI* pCmdUI) 
{
	if (GetSelectedService() == NULL)
		pCmdUI->Enable(FALSE);
	else if(dynamic_cast<FmaServiceConfiguration *>(GetSelectedService()) != NULL)
		pCmdUI->Enable(FALSE);
	else if(dynamic_cast<PrintRenditionServiceConfiguration *>(GetSelectedService()) != NULL)
		pCmdUI->Enable(FALSE);
	else if(dynamic_cast<EFSServiceConfiguration *>(GetSelectedService()) != NULL)
		pCmdUI->Enable(FALSE);
	else if(dynamic_cast<WkAtIndxrServiceConfiguration *>(GetSelectedService()) != NULL)
		pCmdUI->Enable(FALSE);
	else if(dynamic_cast<CIFSServiceConfiguration *>(GetSelectedService()) != NULL)
		pCmdUI->Enable(FALSE);
	else if(dynamic_cast<IDXSVCConfiguration *>(GetSelectedService()) != NULL)
		pCmdUI->Enable(FALSE);
	else
		pCmdUI->Enable(TRUE);
}

void CSvcMgrView::OnUpdateDisplaySvcProperties(CCmdUI* pCmdUI) 
{
	if (GetSelectedService() == NULL)
		pCmdUI->Enable(FALSE);
	else if(dynamic_cast<FmaServiceConfiguration *>(GetSelectedService()) != NULL)
		pCmdUI->Enable(FALSE);
	else if(dynamic_cast<PrintRenditionServiceConfiguration *>(GetSelectedService()) != NULL)
		pCmdUI->Enable(FALSE);
	else if(dynamic_cast<EFSServiceConfiguration *>(GetSelectedService()) != NULL)
		pCmdUI->Enable(FALSE);
	else if(dynamic_cast<CIFSServiceConfiguration *>(GetSelectedService()) != NULL)
		pCmdUI->Enable(FALSE);	
	else
		pCmdUI->Enable(TRUE);
}

void CSvcMgrView::OnUpdateViewLog(CCmdUI* pCmdUI) 
{
	if (GetSelectedService() == NULL)
		pCmdUI->Enable(FALSE);
	else
	{
		_TCHAR	szComputerName[MAX_COMPUTERNAME_LENGTH + 1];
		DWORD	nameSize = sizeof(szComputerName);
		GetComputerName(szComputerName, &nameSize);

		if (_tcsicmp(GetSelectedService()->m_strComputerName.c_str(), szComputerName) != 0)
		{
			pCmdUI->Enable(FALSE);
		}
		else
		{
			if(dynamic_cast<WkAtIndxrServiceConfiguration *>(GetSelectedService()) != NULL)
				pCmdUI->Enable(FALSE);
			else
				pCmdUI->Enable(TRUE);
		}
	}
}

void CSvcMgrView::OnUpdateStop(CCmdUI* pCmdUI) 
{
	if (GetSelectedService() == NULL)
	{
		pCmdUI->Enable(FALSE);
		return;
	}

	if (GetSelectedService()->IsRunning() == TRUE)
		pCmdUI->Enable(TRUE);
	else
		pCmdUI->Enable(FALSE);
}

void CSvcMgrView::OnUpdateStart(CCmdUI* pCmdUI) 
{
	if (GetSelectedService() == NULL)
	{
		pCmdUI->Enable(FALSE);
		return; 
	}

	if (GetSelectedService()->IsRunning() == TRUE)
		pCmdUI->Enable(FALSE);
	else
		pCmdUI->Enable(TRUE);
}

void CSvcMgrView::OnTimer(UINT_PTR nIDEvent) 
{
	static bool bFirstTime = true;

	if (bFirstTime)
	{
		IM::Registry			svrReg(NULL, HKEY_CURRENT_USER, KEY_NRSCONF_PATH);
		NrString 				serverName;

		// determine the list of registered servers and load information
		if (svrReg.OpenOrCreate(NULL, KEY_ALL_ACCESS) != true)
		{
			Event(ECAT_CONFIG, EVE_GENERIC, IDS_MAIN_142);
			return;
		}

		while (svrReg.EnumerateKey(serverName) == true)
		{
			// ensure upper case when getting from registry
			serverName.toUpper();

			if (GetDocument()->isServerInList(serverName.c_str()) == true)
				continue;

			NrString	strServerName(serverName);
			gpLookupMgr->addRequest(strServerName, true);
		}

		bFirstTime = false;
		return;
	}

	IM::NrString 					strComputerName;
	bool							bConnected, bAtInitialization;

	DmsServiceConfiguration			*pDmsService = NULL;
	IdxMgrServiceConfiguration		*pIdxMgrService = NULL;
	IdxSearchServiceConfiguration	*pIdxSearchService = NULL;
	RulesServiceConfiguration		*pRulesSearchService = NULL;
	FmaServiceConfiguration			*pFmaService = NULL;
	EFSServiceConfiguration			*pEFSService = NULL;
	PrintRenditionServiceConfiguration *pPrintRendService = NULL;
	WkDreServiceConfiguration		*pWkDreService = NULL;
	WkIndxrServiceConfiguration		*pWkIndexerService = NULL;
	WkAtIndxrServiceConfiguration	*pWkAutoIndexerService = NULL;
	CDSSyncSvc						*pDSSyncSvc = NULL;
		EMSServiceConfiguration			*pEmsService = NULL;
	CIFSServiceConfiguration		*pCifsService = NULL;
	IDXSVCConfiguration				*pIDXService  = NULL;
	EMailSvcConfiguration			*pEOLService  = NULL;
	LNEMailSvcConfiguration			*pLNService	= NULL;

	while (
		gpLookupMgr->getResult(
			strComputerName,
			bConnected,
			bAtInitialization,
			pDmsService,
			pIdxMgrService,
			pIdxSearchService,
			pRulesSearchService,
			pFmaService,
			pEFSService,
			pPrintRendService,
			pWkDreService,
			pWkIndexerService,
			pWkAutoIndexerService,
			pDSSyncSvc,
			pEmsService,
			pCifsService,
			pIDXService,
			pEOLService,
			pLNService
		) == true)
	{
		if (bConnected == false)
		{
			if (bAtInitialization == true)
			{
				IM::NrString msg = BuildCaption(IDS_MAIN_143, strComputerName.c_str());
				IM::NrString title = BuildCaption(IDS_MAIN_144);

				if (::MessageBox(NULL, msg.c_str(), title.c_str(), MB_YESNO | MB_ICONQUESTION) == IDYES)
				{
					IM::Registry	serverReg(NULL, HKEY_CURRENT_USER, KEY_NRSCONF_PATH);

					if (serverReg.OpenOrCreate(NULL, KEY_ALL_ACCESS) != true)
					{
						Report(REP_WARN, IDS_MAIN_145);
						return;
					}

					serverReg.DeleteSubKey(strComputerName.c_str());
				}
			}

			continue;
		}

		// store computer information in registry and laod information if any of the iManage services are present
		if (
				pDmsService != NULL ||
				pIdxMgrService != NULL ||
				pIdxSearchService != NULL ||
				pRulesSearchService != NULL ||
				pFmaService != NULL ||
				pEFSService != NULL ||
				pPrintRendService != NULL ||
				pWkDreService != NULL ||
				pWkIndexerService != NULL ||
				pWkAutoIndexerService != NULL ||
				pDSSyncSvc != NULL ||
				pEmsService != NULL ||
				pCifsService != NULL ||
				pIDXService != NULL ||
				pEOLService != NULL ||
				pLNService != NULL
			)
		{
			if (GetDocument()->isServerInList(strComputerName.c_str()) == true)
				continue;

			try
			{
				if (GetDocument()->addServer(strComputerName.c_str(), false) == true)
				{
					// add server name to registry
					IM::Registry	serverReg(NULL, HKEY_CURRENT_USER, KEY_NRSCONF_PATH);

					serverReg.AddPath(_T("\\"));
					serverReg.AddPath(strComputerName.c_str());
					serverReg.OpenOrCreate(NULL, KEY_ALL_ACCESS);
				}
			}
			catch(Exception &e)
			{
				AfxMessageBox(e.m_strWhat.c_str());
			}
		}

		if (pDmsService != NULL)
		{
			GetDocument()->GetServiceList().push_front(pDmsService);
		}

		if (pIdxMgrService != NULL)
		{
			GetDocument()->GetServiceList().push_front(pIdxMgrService);
		}

		if (pIdxSearchService != NULL)
		{
			GetDocument()->GetServiceList().push_front(pIdxSearchService);
		}

		if (pRulesSearchService != NULL)
		{
			GetDocument()->GetServiceList().push_front(pRulesSearchService);
		}

		if (pFmaService != NULL)
		{
			GetDocument()->GetServiceList().push_front(pFmaService);
		}

		if (pEFSService != NULL)
		{
			GetDocument()->GetServiceList().push_front(pEFSService);
		}

		if (pPrintRendService != NULL)
		{
			GetDocument()->GetServiceList().push_front(pPrintRendService);
		}

		if (pWkDreService != NULL)
		{
			GetDocument()->GetServiceList().push_front(pWkDreService);
		}

		if (pWkIndexerService != NULL)
		{
			GetDocument()->GetServiceList().push_front(pWkIndexerService);
		}

		if (pWkAutoIndexerService != NULL)
		{
			GetDocument()->GetServiceList().push_front(pWkAutoIndexerService);
		}
		
		if (pDSSyncSvc != NULL)
		{
			GetDocument()->GetServiceList().push_front(pDSSyncSvc);
		}

		if (pEmsService != NULL)
		{
			GetDocument()->GetServiceList().push_front(pEmsService);
		}

		if (pCifsService != NULL)
		{
			GetDocument()->GetServiceList().push_front(pCifsService);
		}

		if (pIDXService != NULL)
		{
			GetDocument()->GetServiceList().push_front(pIDXService);
		}

		if (pEOLService != NULL)
		{
			GetDocument()->GetServiceList().push_front(pEOLService);
		}

		if (pLNService != NULL)
		{
			GetDocument()->GetServiceList().push_front(pLNService);
		}


		pDmsService = NULL;
		pIdxMgrService = NULL;
		pIdxSearchService = NULL;
		pRulesSearchService = NULL;
		pFmaService = NULL;
		pEFSService = NULL;
		pPrintRendService = NULL;
		pWkDreService = NULL;
		pWkIndexerService = NULL;
		pWkAutoIndexerService = NULL;
		pDSSyncSvc = NULL;
		pEmsService = NULL;
		pCifsService = NULL;
		pIDXService = NULL;
		pEOLService = NULL;
		pLNService = NULL ;
	}
	CListView::OnTimer(nIDEvent);
}

void CSvcMgrView::OnClick(NMHDR* pNMHDR, LRESULT* pResult) 
{
	HD_NOTIFY *phdn = (HD_NOTIFY *) pNMHDR;
	if (pNMHDR == NULL || GetListCtrl().GetSelectedCount() == 0)
	{
		if (GetSelectedService() != NULL)
		{
			SetSelectedService(NULL);
			UpdateDisplay();
		}
		return;
	}

	if (GetListCtrl().GetSelectedCount() == NULL)
	{
		SetSelectedService(NULL);
		UpdateDisplay();
		return;
	}

	int nItem = GetListCtrl().GetNextItem(-1, LVNI_ALL | LVNI_SELECTED);
	CString aServerName = GetListCtrl().GetItemText(nItem, 0);
	CString aServiceDisplayName = GetListCtrl().GetItemText(nItem, 1);

//	BasicService* service = new BasicService(aName, _T(""));
//	service->serviceDisplayName = GetListCtrl().GetItemText(nItem, 1);

	ServiceList::iterator it;

	for (it = GetDocument()->GetServiceList().begin(); it != GetDocument()->GetServiceList().end(); ++it)
	{
		ServiceConfiguration	*pService = it->get();

		check_object(pService);
		if (pService->m_strComputerName.compare((const TCHAR *) aServerName) == 0 &&
			pService->m_strServiceDisplayName.compare((const TCHAR *) aServiceDisplayName) == 0)
		{
			SetSelectedService(pService); 
			UpdateDisplay();
			*pResult = 0;
		}
	}

	*pResult = 1;
}

BOOL CSvcMgrView::SortTextItems (int nCol, BOOL bAscending, int low, int high)
{
        if( nCol >= ((CHeaderCtrl*)GetListCtrl().GetDlgItem(0))->GetItemCount() )
           return FALSE;

        if( high == -1 ) high = GetListCtrl().GetItemCount() - 1;

        int lo = low;
        int hi = high;
        CString midItem;

        if( hi <= lo ) return FALSE;
        
		midItem = GetListCtrl().GetItemText((lo+hi)/2, nCol);	

        // loop through the list until indices cross
        while( lo <= hi )
        {
                // rowText will hold all column text for one row
                CStringArray rowText;
				int nImage;

                // find the first element that is greater than or equal to 
                // the partition element starting from the left Index.
                if( bAscending )
                        while((lo < high) &&  GetListCtrl().GetItemText(lo, nCol).CompareNoCase(midItem) < 0)
                                ++lo;
                else
                        while(( lo < high) && GetListCtrl().GetItemText(lo, nCol).CompareNoCase(midItem) > 0)
//                        while( ( lo < high ) && (CompareByType( GetListCtrl().GetItemText(lo, nCol),midItem, nCol) > 0 ) )
                                ++lo;

                // find an element that is smaller than or equal to 
                // the partition element starting from the right Index.
                if( bAscending )
                        while(( hi > low) && GetListCtrl().GetItemText(hi, nCol).CompareNoCase(midItem) > 0)
                                --hi;
                else
                        while(( hi > low) && GetListCtrl().GetItemText(hi, nCol).CompareNoCase(midItem) < 0)
                                --hi;

                // if the indexes have not crossed, swap
                // and if the items are not equal
                if( lo <= hi )
                {
                        // swap only if the items are not equal
                        if(_tcscmp(GetListCtrl().GetItemText(lo, nCol), GetListCtrl().GetItemText(hi, nCol)) != 0)
                        {
                                // swap the rows
								int lvitemloRow, lvitemloCol, lvitemloiMage;
								int lvitemhiRow, lvitemhiCol, lvitemhiiMage;
								CString lvitemloStr, lvitemhiStr;
								LV_ITEM lvItem;
								lvItem.mask = LVIF_TEXT | LVIF_IMAGE;

                                int nColCount = 
                                        ((CHeaderCtrl*)GetListCtrl().GetDlgItem(0))->GetItemCount();
                                rowText.SetSize( nColCount );
                                int i;
								TCHAR str[_MAX_FNAME];

                                for( i=0; i<nColCount; i++)
								{
                                    //   rowText[i] = GetListCtrl().GetItemText(lo, i);									
   									lvItem.iItem = lo;
									lvItem.iSubItem = i;
									lvItem.pszText = str;		
									lvItem.cchTextMax = sizeof(str);
									GetListCtrl().GetItem(&lvItem);
									rowText[i] = str;
									nImage = lvItem.iImage;
                                }

                                lvitemloRow = lo;
                                lvitemloCol = 0;
 
                                lvitemhiCol = lvitemloCol;
                                lvitemhiRow = hi;

                                //lvitemloStr = GetListCtrl().GetItemText(lvitemloRow, lvitemloCol);								
								lvItem.iItem = lvitemloRow;
								lvItem.iSubItem = lvitemloCol;
								lvItem.pszText = str;
								lvItem.cchTextMax = sizeof(str);		
								GetListCtrl().GetItem(&lvItem);
								lvitemloStr = str;		
								lvitemloiMage = lvItem.iImage;

                                //lvitemhiStr = GetListCtrl().GetItemText(lvitemhiRow, lvitemhiCol);								
								lvItem.iItem = lvitemhiRow;
								lvItem.iSubItem = lvitemhiCol;
								lvItem.pszText = str;
								lvItem.cchTextMax = sizeof(str);		
								GetListCtrl().GetItem(&lvItem);
								lvitemhiStr = str;
								lvitemhiiMage = lvItem.iImage;

                                for( i=0; i<nColCount; i++)
								{										
									//GetListCtrl().SetItemText(lo, i, m_lstRole.GetItemText(hi, i));
									lvItem.iItem = hi;
									lvItem.iSubItem = i;
									lvItem.pszText = str;									
									lvItem.cchTextMax = sizeof(str);
									GetListCtrl().GetItem(&lvItem);									
									int iImage = lvItem.iImage;

									lvItem.iItem = lo;
									lvItem.iSubItem = i;
									lvItem.iImage = iImage;
									lvItem.pszText = str;
									GetListCtrl().SetItem(&lvItem);
								}
								
                                lvitemhiRow = lo;
								//GetListCtrl().SetItemText(lvitemhiRow, lvitemhiCol, lvitemhiStr);
								lvItem.iItem = lvitemhiRow;
								lvItem.iSubItem = lvitemhiCol;
								lvItem.iImage = lvitemhiiMage;
								lvItem.pszText = (LPTSTR)(LPCTSTR)lvitemhiStr;
								GetListCtrl().SetItem(&lvItem);
                                
                                for( i=0; i<nColCount; i++)
								{
								//	GetListCtrl().SetItemText(hi, i, rowText[i]);
									lvItem.iItem = hi;
									lvItem.iSubItem = i;									
									lvItem.pszText = (LPTSTR)(LPCTSTR)rowText[i];
									lvItem.iImage = nImage;
									GetListCtrl().SetItem(&lvItem);
								}
								
                                lvitemloRow = hi;
								//GetListCtrl().SetItemText(lvitemloRow, lvitemloCol, lvitemloStr);
								lvItem.iItem = lvitemloRow;
								lvItem.iSubItem = lvitemloCol;
								lvItem.iImage = lvitemloiMage;
								lvItem.pszText = (LPTSTR)(LPCTSTR)lvitemloStr;
								GetListCtrl().SetItem(&lvItem);                                
                        }

                        ++lo;
                        --hi;
                }
        }

        // If the right index has not reached the left side of array
        // must now sort the left partition.
        if( low < hi )
                SortTextItems( nCol, bAscending , low, hi);

        // If the left index has not reached the right side of array
        // must now sort the right partition.
        if( lo < high )
                SortTextItems( nCol, bAscending , lo, high );

        return TRUE;

}

void CSvcMgrView::OnColumnclick(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	BeginWaitCursor();

	_nSortedColumn = pNMListView->iSubItem;
	_bSortAscending = !_bSortAscending;

	GetListCtrl().SetRedraw(FALSE);
	SortTextItems(_nSortedColumn, _bSortAscending);
	m_headerctrl.SetSortImage( _nSortedColumn, _bSortAscending );
	GetListCtrl().SetRedraw(TRUE);
	GetListCtrl().Invalidate();
	EndWaitCursor();
	*pResult = 0;
}


void CSvcMgrView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	CListView::OnKeyDown(nChar, nRepCnt, nFlags);

	if (GetListCtrl().GetSelectedCount() == 0)
	{
		if (GetSelectedService() != NULL)
		{
			SetSelectedService(NULL);
			UpdateDisplay();
		}
		return;
	}

	if (GetListCtrl().GetSelectedCount() == NULL)
	{
		SetSelectedService(NULL);
		UpdateDisplay();
		return;
	}

	int nItem = GetListCtrl().GetNextItem(-1, LVNI_ALL | LVNI_SELECTED);
	CString aServerName = GetListCtrl().GetItemText(nItem, 0);
	CString aServiceDisplayName = GetListCtrl().GetItemText(nItem, 1);

//	BasicService* service = new BasicService(aName, _T(""));
//	service->serviceDisplayName = GetListCtrl().GetItemText(nItem, 1);

	ServiceList::iterator it;

	for (it = GetDocument()->GetServiceList().begin(); it != GetDocument()->GetServiceList().end(); ++it)
	{
		ServiceConfiguration	*pService = it->get();

		check_object(pService);
		if (pService->m_strComputerName.compare((const TCHAR *) aServerName) == 0 &&
			pService->m_strServiceDisplayName.compare((const TCHAR *) aServiceDisplayName) == 0)
		{
			SetSelectedService(pService); 
			UpdateDisplay();
		}
	}
}
