#if !defined(AFX_LNDATABASEPROP_H__B3AB0948_E46F_43f8_A122_DA9D62EB9A45__INCLUDED_)
#define AFX_LNDATABASEPROP_H__B3AB0948_E46F_43f8_A122_DA9D62EB9A45__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif

#include "registry\LNEMailSvcConfiguration.h"

class LNDatabaseProp : public CDialog
{
// Construction
public:
	LNDatabaseProp(CWnd* pParent = NULL);   // standard constructor
	// Dialog Data
	//{{AFX_DATA(LNDatabaseProp)
	enum { IDD = IDD_EMS_DB_PROP2 };
	CString	m_DatabaseName;
	CButton	m_EnablePort;
	CString	m_Password;
	long	m_Port;
	CString	m_ServerName;
	CString	m_Username;
	//}}AFX_DATA

	IM::LNEMailSvcConfiguration *m_pServiceConfiguration;

	CString						m_SavedDatabaseName;
	long						m_lSavedMaxFolderList;

	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(LNDatabaseProp)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL


// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(LNDatabaseProp)
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnHelp();
	afx_msg void OnChange();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
#endif