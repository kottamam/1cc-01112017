// DatabaseSetup.cpp : implementation file
//

#include <stdafx.h>

#include <imSvcMgr.h>
#include <DatabaseSetup.h>
#include <DataBaseProp.h>
#include <ServerProp.h>
#include <LinkSiteServerProp.h>
#include <IdxDbProp.h>
#include <EMSDatabaseProp2.h>
#include <EOLDatabaseProp.h>
#include <LNDatabaseProp.h>
#include <stl/NrString.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

using namespace IM;

/////////////////////////////////////////////////////////////////////////////
// DatabaseSetup dialog


DatabaseSetup::DatabaseSetup(CSvcMgrDoc* pParent /*=NULL*/)
	: CDialog(DatabaseSetup::IDD, (CWnd*)pParent)
{
	//{{AFX_DATA_INIT(DatabaseSetup)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_pDatabaseList = NULL;
	m_pServiceConfiguration = NULL;
	m_pEOLConfiguration = NULL;
	m_pLNConfiguration = NULL;
}


void DatabaseSetup::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(DatabaseSetup)
	DDX_Control(pDX, IDC_DELETE_DATABASE, m_DeleteButton);
	DDX_Control(pDX, IDC_MODIFY_DATABASE, m_ModifyButton);
	DDX_Control(pDX, IDC_ADD_DB_BUTTON, m_AddDBButton);
	DDX_Control(pDX, IDC_ADD_DB_BUTTON2, m_AddLinkSiteDBButton);
	DDX_Control(pDX, IDC_ADD_SERVER_BUTTON, m_AddServerButton);
	DDX_Control(pDX, IDC_LIST2, m_DatabaseList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(DatabaseSetup, CDialog)
	//{{AFX_MSG_MAP(DatabaseSetup)
	ON_LBN_SELCHANGE(IDC_LIST2, OnSelchangeList2)
	ON_BN_CLICKED(IDC_ADD_DB_BUTTON, OnAddDBButton)
	ON_BN_CLICKED(IDC_ADD_DB_BUTTON2, OnAddLinkSiteDBButton)
	ON_BN_CLICKED(IDC_ADD_SERVER_BUTTON, OnAddServerButton)
	ON_BN_CLICKED(IDC_MODIFY_DATABASE, OnModifyDatabase)
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDC_DELETE_DATABASE, OnDeleteDatabase)
	ON_BN_CLICKED(IDHELP, OnHelp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// DatabaseSetup message handlers
bool DatabaseSetup::needPrimaryDatabase()
{
	if (serviceType != SVC_DMS)
		return false;

	IM::DatabaseEntryList::DatabaseEntryListIterator	it;
	IM::DatabaseEntry									*pEntry;

	for (it = m_pDatabaseList->begin(); it != m_pDatabaseList->end(); ++it)
	{
		pEntry = cast_object(IM::DatabaseEntry *, it->get());

		if (pEntry->m_bPrimary.Get() == true)
			return false; 
	}

	return true;
}

bool DatabaseSetup::NeedWebContentDatabase()
{
	if (serviceType != SVC_DMS)
		return false;

	IM::DatabaseEntryList::DatabaseEntryListIterator	it;
	IM::DmsDatabaseEntry								*pEntry;

	for (it = m_pDatabaseList->begin(); it != m_pDatabaseList->end(); ++it)
	{
		pEntry = cast_object(IM::DmsDatabaseEntry *, it->get());

		if (pEntry->m_bWebContent.Get() == true)
			return false; 
	}

	return true;
}

BOOL DatabaseSetup::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_ModifyButton.EnableWindow(false);
	m_DeleteButton.EnableWindow(false);
	m_bHavePrimary = false;

	// initialize repositoryList
	if (m_pDatabaseList != NULL)
	{
		delete m_pDatabaseList;
		m_pDatabaseList = NULL;
	}

	if (m_pServiceConfiguration != NULL)
	{
		delete m_pServiceConfiguration;
		m_pServiceConfiguration = NULL;
	}

	if (m_pEOLConfiguration != NULL)
	{
		delete m_pEOLConfiguration;
		m_pEOLConfiguration = NULL;
	}

	if (m_pLNConfiguration != NULL)
	{
		delete m_pLNConfiguration;
		m_pLNConfiguration = NULL;
	}

	IM::NrString aCaption = strDisplayName;
	aCaption += _T(" ");
	aCaption += BuildCaption(IDS_DATABASE_102, serverName.c_str());
	SetWindowText(aCaption.c_str());

	// initialize the database list
	m_DatabaseList.ResetContent();

	IM::NrCiString strAdvancedServer(_T(""));
	IM::NrCiString strCacheEnabled(_T(""));
	IM::NrCiString strHpFlowServer(_T(""));

	IM::Registry	dbReg(NULL, HKEY_LOCAL_MACHINE, TEXT("Software\\Interwoven\\WorkSite\\imDmsSvc"));
	if (dbReg.Open(NULL, KEY_READ))
	{
		dbReg.GetStringValue(TEXT("Advanced Server"), strAdvancedServer);
		dbReg.GetStringValue(TEXT("Document Cache Enabled"), strCacheEnabled);
		dbReg.GetStringValue(TEXT("HpFlow Server"), strHpFlowServer);
	}
	bool bAdvancedServer = strAdvancedServer == _T("Y") ? true : false;
	bool bCacheEnabled = strCacheEnabled == _T("Y") ? true : false;
	bool bHpFlowServer = strHpFlowServer == _T("Y") ? true : false;

	if (serviceType == SVC_DMS)
	{
		if(bAdvancedServer)
		{
			m_AddServerButton.ShowWindow(SW_SHOW);

			if(bCacheEnabled)
			{
				m_AddServerButton.EnableWindow(true);
			}
		}
		else
		{
			m_AddServerButton.ShowWindow(SW_HIDE);
		}
	
		
		bool blFlowServerAdded = false;
		IM::DatabaseEntryList		*pDatabaseList = (IM::DatabaseEntryList *) new IM::DmsDatabaseList(serverName.c_str());;
		try
		{
			((IM::DatabaseEntryList *) pDatabaseList)->LoadAll();
		}
		catch (Exception &)
		{
			Report(REP_WARN, IDS_DATABASE_101, serverName.c_str());
			SendMessage(WM_CLOSE);
			return TRUE;
		}

		IM::DatabaseEntryList::DatabaseEntryListIterator	it;
		IM::DatabaseEntry									*pEntry;

		for (it = pDatabaseList->begin(); it != pDatabaseList->end(); ++it)
		{
			pEntry = cast_object(IM::DatabaseEntry *, it->get());
			blFlowServerAdded = (pEntry->m_lConnectionType.Get ()  == DatabaseEntry::ConnectionType ::HpFlow ? true : false);
			if(blFlowServerAdded)
				break;
		}

		if(!blFlowServerAdded)
		{
			m_AddLinkSiteDBButton.ShowWindow(SW_SHOW);
			m_AddLinkSiteDBButton.EnableWindow(true);
		}
		else
		{
			m_AddLinkSiteDBButton.ShowWindow(SW_HIDE);
		}

		delete pDatabaseList;
		
		

		m_pDatabaseList = (IM::DatabaseEntryList *) new IM::DmsDatabaseList(serverName.c_str());
	}
	else if (serviceType == SVC_IDXMGR)
	{
		m_AddServerButton.ShowWindow(SW_HIDE);
		m_AddLinkSiteDBButton.ShowWindow(SW_HIDE);

		m_pDatabaseList = (IM::DatabaseEntryList *) new IM::IdxMgrDatabaseList(serverName.c_str());
	}
	else if (serviceType == SVC_IDXSCH)
	{
		m_AddServerButton.ShowWindow(SW_HIDE);
		m_AddLinkSiteDBButton.ShowWindow(SW_HIDE);

		m_pDatabaseList = (IM::DatabaseEntryList *) new IM::IdxSearchDatabaseList(serverName.c_str());
	}
	else if (serviceType == SVC_RULE)
	{
		m_AddServerButton.ShowWindow(SW_HIDE);
		m_AddLinkSiteDBButton.ShowWindow(SW_HIDE);

		m_pDatabaseList = (IM::DatabaseEntryList *) new IM::ReDatabaseList(serverName.c_str());
	}
	else if(serviceType == SVC_WKDRE)
	{
		m_AddServerButton.ShowWindow(SW_HIDE);
		m_AddLinkSiteDBButton.ShowWindow(SW_HIDE);

		m_pDatabaseList = (IM::DatabaseEntryList *) new IM::WkDreDatabaseList(serverName.c_str());
	}
	else if(serviceType == SVC_WKIDX)
	{
		m_AddServerButton.ShowWindow(SW_HIDE);
		m_AddLinkSiteDBButton.ShowWindow(SW_HIDE);

		m_pDatabaseList = (IM::DatabaseEntryList *) new IM::WkIndxrDatabaseList(serverName.c_str());
	}
	else if(serviceType == SVC_EMS)
	{
		try
		{
			m_AddServerButton.ShowWindow(SW_HIDE);
			m_AddLinkSiteDBButton.ShowWindow(SW_HIDE);

			m_pServiceConfiguration = (IM::EMSServiceConfiguration *) new IM::EMSServiceConfiguration(NULL);
			m_pServiceConfiguration->LoadFromRegistry();

			for (imstd::vector<EmsDatabaseEntry>::iterator j = m_pServiceConfiguration->m_Databases.begin(); j != m_pServiceConfiguration->m_Databases.end(); ++j)
				m_DatabaseList.AddString(j->m_strDatabaseName.Get().c_str());
		}
		catch (Exception &)
		{
			Report(REP_WARN, IDS_DATABASE_101, serverName.c_str());
			SendMessage(WM_CLOSE);
			return TRUE;
		}
		
		return 0;
	}
	else if(SVC_EOL == serviceType)
	{
		try
		{
			m_AddServerButton.ShowWindow(SW_HIDE);
			m_AddLinkSiteDBButton.ShowWindow(SW_HIDE);

			m_pEOLConfiguration = (IM::EMailSvcConfiguration *) new IM::EMailSvcConfiguration(NULL);
			m_pEOLConfiguration->LoadFromRegistry();

			imstd::vector<EmsDatabaseEntry>::iterator j = m_pEOLConfiguration->m_Databases.begin();
			for ( ; j != m_pEOLConfiguration->m_Databases.end(); ++j)
				m_DatabaseList.AddString(j->m_strDatabaseName.Get().c_str());
		}
		catch (Exception &)
		{
			Report(REP_WARN, IDS_DATABASE_101, serverName.c_str());
			SendMessage(WM_CLOSE);
			return TRUE;
		}		
		return 0;
	}
	else if(SVC_LN == serviceType)
	{
		try
		{
			m_AddServerButton.ShowWindow(SW_HIDE);
			m_AddLinkSiteDBButton.ShowWindow(SW_HIDE);

			m_pLNConfiguration = (IM::LNEMailSvcConfiguration *) new IM::LNEMailSvcConfiguration(NULL);
			m_pLNConfiguration->LoadFromRegistry();

			imstd::vector<EmsDatabaseEntry>::iterator j = m_pLNConfiguration->m_Databases.begin();
			for ( ; j != m_pLNConfiguration->m_Databases.end(); ++j)
				m_DatabaseList.AddString(j->m_strDatabaseName.Get().c_str());
		}
		catch (Exception &)
		{
			Report(REP_WARN, IDS_DATABASE_101, serverName.c_str());
			SendMessage(WM_CLOSE);
			return TRUE;
		}		
		return 0;
	}

	try
	{
		((IM::DatabaseEntryList *) m_pDatabaseList)->LoadAll();
	}
	catch (Exception &)
	{
		Report(REP_WARN, IDS_DATABASE_101, serverName.c_str());
		SendMessage(WM_CLOSE);
		return TRUE;
	}

	IM::DatabaseEntryList::DatabaseEntryListIterator	it;
	IM::DatabaseEntry									*pEntry;

	for (it = m_pDatabaseList->begin(); it != m_pDatabaseList->end(); ++it)
	{
		pEntry = cast_object(IM::DatabaseEntry *, it->get());
		m_DatabaseList.AddString(pEntry->m_strDatabase.Get().c_str());
	}
	
	return 0;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void DatabaseSetup::OnSelchangeList2() 
{
	if (m_DatabaseList.GetCurSel() != LB_ERR)
	{
		m_ModifyButton.EnableWindow(true);
		m_DeleteButton.EnableWindow(true);
	}
}
void DatabaseSetup::OnAddLinkSiteDBButton() 
{
	if (serviceType == SVC_DMS)
	{
		LinkSiteServerProp aServerPropDlg;
		aServerPropDlg.m_pDatabaseList = (IM::DmsDatabaseList *) m_pDatabaseList;

		if (aServerPropDlg.DoModal() == IDOK)
		{
			m_DatabaseList.AddString(aServerPropDlg.m_SavedOdbcName);

			m_AddLinkSiteDBButton.ShowWindow(SW_HIDE);
		}
	}
	
}


void DatabaseSetup::OnAddDBButton() 
{
	if (serviceType == SVC_DMS)
	{
		DataBaseProp aDataBasePropDlg;
		aDataBasePropDlg.m_pDatabaseList = (IM::DmsDatabaseList *) m_pDatabaseList;
		aDataBasePropDlg.m_bAllowPrimary = needPrimaryDatabase();
		aDataBasePropDlg.m_bAllowWebContent = NeedWebContentDatabase();

		if (aDataBasePropDlg.DoModal() == IDOK)
		{
			m_DatabaseList.AddString(aDataBasePropDlg.m_SavedOdbcName);
		}
	}
	else if (serviceType == SVC_EMS)
	{
		EMSDatabaseProp2 aEmsDbPropDlg;
		aEmsDbPropDlg.m_pServiceConfiguration = m_pServiceConfiguration;

		if (aEmsDbPropDlg.DoModal() == IDOK)
		{
			int nIndex = 0;
			while ((nIndex = m_DatabaseList.FindStringExact(nIndex, aEmsDbPropDlg.m_SavedDatabaseName)) != LB_ERR)
			{
			   m_DatabaseList.DeleteString( nIndex );
			}
			m_DatabaseList.AddString(aEmsDbPropDlg.m_SavedDatabaseName);
		}
	}
	else if(serviceType == SVC_EOL)
	{
		EOLDatabaseProp aEolDbPropDlg;
		aEolDbPropDlg.m_pServiceConfiguration = m_pEOLConfiguration;

		if (aEolDbPropDlg.DoModal() == IDOK)
		{
			int nIndex = 0;
			while ((nIndex = m_DatabaseList.FindStringExact(nIndex, aEolDbPropDlg.m_SavedDatabaseName)) != LB_ERR)
			{
			   m_DatabaseList.DeleteString( nIndex );
			}
			m_DatabaseList.AddString(aEolDbPropDlg.m_SavedDatabaseName);
		}
	}
	else if(serviceType == SVC_LN)
	{
		LNDatabaseProp oLNDbPropDlg;
		oLNDbPropDlg.m_pServiceConfiguration = m_pLNConfiguration;

		if (oLNDbPropDlg.DoModal() == IDOK)
		{
			int nIndex = 0;
			while ((nIndex = m_DatabaseList.FindStringExact(nIndex, oLNDbPropDlg.m_SavedDatabaseName)) != LB_ERR)
			{
			   m_DatabaseList.DeleteString( nIndex );
			}
			m_DatabaseList.AddString(oLNDbPropDlg.m_SavedDatabaseName);
		}
	}
	else
	{
		IdxDbProp aIdxDbPropDlg;
		aIdxDbPropDlg.m_pDatabaseList = (IM::DatabaseEntryList *) m_pDatabaseList;
		aIdxDbPropDlg.m_bAllowPrimary = needPrimaryDatabase();

		if (aIdxDbPropDlg.DoModal() == IDOK)
			m_DatabaseList.AddString(aIdxDbPropDlg.m_SavedOdbcName);
	}
}

void DatabaseSetup::OnAddServerButton() 
{
	if (serviceType == SVC_DMS)
	{
		ServerProp aServerPropDlg;
		aServerPropDlg.m_pDatabaseList = (IM::DmsDatabaseList *) m_pDatabaseList;

		if (aServerPropDlg.DoModal() == IDOK)
		{
			m_DatabaseList.AddString(aServerPropDlg.m_SavedOdbcName);
		}
	}
}

void DatabaseSetup::OnModifyDatabase()  
{
	int index;
	CString aString;

	// if no record selected then done.
	if ((index = m_DatabaseList.GetCurSel()) == LB_ERR)
    	return;

	m_DatabaseList.GetText(index, aString);

	if (serviceType == SVC_DMS)
	{
		//
		// Connection Type
		//
		IM::NrString strDatabaseKey(_T("Software\\Interwoven\\WorkSite\\imDmsSvc\\Databases\\"));
		IM::NrString strDatabase(aString);
		strDatabaseKey += strDatabase;

		long lConnectionType = 0;

		IM::Registry	dbReg(NULL, HKEY_LOCAL_MACHINE, strDatabaseKey.c_str());
		if (dbReg.Open(NULL, KEY_READ))
		{
			dbReg.GetLongValue(TEXT("Connection Type"), lConnectionType);
		}

		if (lConnectionType == IM::DatabaseEntry::Database)
		{
			DataBaseProp aDataBasePropDlg;

			aDataBasePropDlg.m_DatabaseValue = aString;
			aDataBasePropDlg.m_pDatabaseList = (IM::DmsDatabaseList *) m_pDatabaseList;
			aDataBasePropDlg.m_bAllowPrimary = needPrimaryDatabase();
			aDataBasePropDlg.m_bAllowWebContent = NeedWebContentDatabase();

			aDataBasePropDlg.DoModal();
		}
		else if(lConnectionType == IM::DatabaseEntry::HpFlow )
		{
			LinkSiteServerProp aServerPropDlg;

			aServerPropDlg.m_DatabaseValue = aString;
			aServerPropDlg.m_pDatabaseList = (IM::DmsDatabaseList *) m_pDatabaseList;

			aServerPropDlg.DoModal();
		}
		else // Server
		{
			ServerProp aServerPropDlg;

			aServerPropDlg.m_DatabaseValue = aString;
			aServerPropDlg.m_pDatabaseList = (IM::DmsDatabaseList *) m_pDatabaseList;

			aServerPropDlg.DoModal();
		}
	}
	else if (serviceType == SVC_EMS)
	{
		EMSDatabaseProp2 aEmsDbPropDlg;

		aEmsDbPropDlg.m_DatabaseName = aString;
		aEmsDbPropDlg.m_pServiceConfiguration = m_pServiceConfiguration;

		aEmsDbPropDlg.DoModal();
	}
	else if (serviceType == SVC_EOL)
	{
		EOLDatabaseProp oEolDbPropDlg;
		oEolDbPropDlg.m_DatabaseName = aString;
		oEolDbPropDlg.m_pServiceConfiguration = m_pEOLConfiguration;

		oEolDbPropDlg.DoModal();
	}
	else if (serviceType == SVC_LN)
	{
		LNDatabaseProp oLNDbPropDlg;
		oLNDbPropDlg.m_DatabaseName = aString;
		oLNDbPropDlg.m_pServiceConfiguration = m_pLNConfiguration;

		oLNDbPropDlg.DoModal();
	}
	else 
	{
		IdxDbProp aIdxDbPropDlg;

		aIdxDbPropDlg.m_DatabaseValue = aString;
		aIdxDbPropDlg.m_pDatabaseList = (IM::DatabaseEntryList *) m_pDatabaseList;
		aIdxDbPropDlg.m_bAllowPrimary = needPrimaryDatabase();

		aIdxDbPropDlg.DoModal();
	}
}

void DatabaseSetup::OnClose() 
{
	if (serviceType == SVC_DMS && needPrimaryDatabase() == true)
		Report(REP_WARN, IDS_DATABASE_104);	

	CDialog::OnClose();
}

void DatabaseSetup::OnDeleteDatabase() 
{
	// disable the delete and modify buttons
	GetDlgItem(IDC_MODIFY_DATABASE)->EnableWindow(false);
	GetDlgItem(IDC_DELETE_DATABASE)->EnableWindow(false);

	// if no record selected then done.
	int index;
	CString aString;

	// if no record selected then done.
	if ((index = m_DatabaseList.GetCurSel()) == LB_ERR)
		return;

 	m_DatabaseList.GetText(index, aString);
	IM::NrString databaseName = aString;

	try
	{
		if (serviceType == SVC_EMS)
		{
			m_pServiceConfiguration->RemoveDatabaseFromRegistry(databaseName);
		}
		else if(serviceType == SVC_EOL)
		{
			m_pEOLConfiguration->RemoveDatabaseFromRegistry(databaseName);
		}
		else if(serviceType == SVC_LN)
		{
			m_pLNConfiguration->RemoveDatabaseFromRegistry(databaseName);
		}
		else
		{
			// remove the entry from the repository list
			m_pDatabaseList->Remove(databaseName.c_str());

			IM::NrCiString strHpFlowServer(_T(""));

			IM::Registry	dbReg(NULL, HKEY_LOCAL_MACHINE, TEXT("Software\\Interwoven\\WorkSite\\imDmsSvc"));
			if (dbReg.Open(NULL, KEY_READ))
			{
				dbReg.GetStringValue(TEXT("HpFlow Server"), strHpFlowServer);
			}
			bool bHpFlowServer = strHpFlowServer == _T("Y") ? true : false;

	

			bool blFlowServerAdded = false;
			

			IM::DatabaseEntryList::DatabaseEntryListIterator	it;
			IM::DatabaseEntry									*pEntry;

			for (it = m_pDatabaseList->begin(); it != m_pDatabaseList->end(); ++it)
			{
				pEntry = cast_object(IM::DatabaseEntry *, it->get());
				blFlowServerAdded = (pEntry->m_lConnectionType.Get ()  == DatabaseEntry::ConnectionType ::HpFlow ? true : false);
				if(blFlowServerAdded)
					break;
			}

			if(!blFlowServerAdded)
			{
				m_AddLinkSiteDBButton.ShowWindow(SW_SHOW);
				m_AddLinkSiteDBButton.EnableWindow(true);
			}
			else
			{
				m_AddLinkSiteDBButton.ShowWindow(SW_HIDE);
			}
			

		}
	}
	catch(...)
	{
	}

	// Remove the database entry from the list box
	m_DatabaseList.DeleteString(index);
}



void DatabaseSetup::OnCancel() 
{
	if (serviceType == SVC_DMS && needPrimaryDatabase() == true)
		Report(REP_WARN, IDS_DATABASE_104);	
	
	CDialog::OnCancel();
}

void DatabaseSetup::OnHelp() 
{
	::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, 18);
}
