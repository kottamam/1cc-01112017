// FileServerPropertyPage1.h : header file
//

#ifndef __FILESERVERPROPERTYPAGE1_H__
#define __FILESERVERPROPERTYPAGE1_H__

/////////////////////////////////////////////////////////////////////////////
// FileServerPropertyPage dialog

class FileServerConnectionInfo;

class FileServerPropertyPage : public CPropertyPage
{
	DECLARE_DYNCREATE(FileServerPropertyPage)

// Construction
public:
	FileServerPropertyPage();
	~FileServerPropertyPage();

// Dialog Data
	//{{AFX_DATA(FileServerPropertyPage)
	enum { IDD = IDD_PROPPAGE1 };
	CString	m_Context;
	CString	m_LogonIdEdit;
	CString	m_PasswordEdit;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(FileServerPropertyPage)
	public:
	virtual void OnOK();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(FileServerPropertyPage)
	virtual BOOL OnInitDialog();
	afx_msg void OnChangeContextEdit();
	afx_msg void OnChangeLogonidEdit();
	afx_msg void OnChangePasswordEdit();
	afx_msg void OnBindery();
	afx_msg void OnNds();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	void Changed();
};


/////////////////////////////////////////////////////////////////////////////
// FileServerPropertyPage2 dialog

class FileServerPropertyPage2 : public CPropertyPage
{
	DECLARE_DYNCREATE(FileServerPropertyPage2)

// Construction
public:
	FileServerPropertyPage2();
	~FileServerPropertyPage2();

// Dialog Data
	//{{AFX_DATA(FileServerPropertyPage2)
	enum { IDD = IDD_PROPPAGE2 };
	CString	m_NTLogonID;
	CString	m_NTPassword;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(FileServerPropertyPage2)
	public:
	virtual void OnOK();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(FileServerPropertyPage2)
	virtual BOOL OnInitDialog();
	afx_msg void OnChangeNtLogonid();
	afx_msg void OnChangeNtPassword();
	afx_msg void OnNtServiceLogonOnly();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
	void Changed();
};



#endif // __FILESERVERPROPERTYPAGE1_H__
