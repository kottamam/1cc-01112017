// HeaderCtrlEx.cpp : implementation file
//

#include "stdafx.h"
#include "PortableClient.h"
#include "HeaderCtrlEx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CHeaderCtrlEx

CHeaderCtrlEx::CHeaderCtrlEx()
{
	m_pImageList = NULL;
}

CHeaderCtrlEx::~CHeaderCtrlEx()
{
}


BEGIN_MESSAGE_MAP(CHeaderCtrlEx, CDbViewHeaderCtrl)
	//{{AFX_MSG_MAP(CHeaderCtrlEx)
	ON_WM_SETCURSOR()
	ON_WM_NCHITTEST()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHeaderCtrlEx message handlers

BOOL CHeaderCtrlEx::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	if (m_bAllowDrag)
		return CDbViewHeaderCtrl::OnSetCursor(pWnd, nHitTest, message);
	else
		return TRUE;	
	
	//return CDbViewHeaderCtrl::OnSetCursor(pWnd, nHitTest, message);
}

LRESULT CHeaderCtrlEx::OnNcHitTest(CPoint point) 
{
	POINT clientPoint = point;
	ScreenToClient( &clientPoint );
	m_bAllowDrag = IsDragAllowed( clientPoint );
	
	//return CHeaderCtrl::OnNcHitTest(point);
	return CDbViewHeaderCtrl::OnNcHitTest(point);
}

BOOL CHeaderCtrlEx::IsDragAllowed( CPoint point )
{
	// We will extract information about the header 
	// using this structure
	HD_ITEM hi;
	hi.mask = HDI_WIDTH;	// We want the column width.

	// We keep a running sum of the horizontal location
	// of each column's divider.
	int dividerLocations = 0;

	// The amount of space around the dividor inside of which one 
	// can begin the dragging operation is equal to the width of 
	// the cursor, centered at the dividor.  So we need to trap 
	// the cursor a distance of half the cursor width to each 
	// side of the dividor.
	int dragWidth = GetSystemMetrics( SM_CXCURSOR );

	// Since we have no need to apply this test for columns for which 
	// we want to enable dragging, we do not need to go beyond the last 
	// column for which we want to disable dragging in our 'for loop'.
	BOOL allowDrag = TRUE;

	for (int i = 0; i < 4; ++i) {
		GetItem(i, &hi);

		// hi.cxy contains the width of the i'th column.
		dividerLocations += hi.cxy;

		// Here is where we place the indexes for the columns 
		// for which we want to disable dragging.
		if (i == 0)  //first column
		      if (point.x > dividerLocations - dragWidth/2 &&
			  point.x < dividerLocations + dragWidth/2)
				allowDrag = FALSE;
		}

	return allowDrag;
}

CImageList* CHeaderCtrlEx::SetImageList( CImageList* pImageList )
{
	CImageList *pPrevList = m_pImageList;	
	m_pImageList = pImageList;
	return pPrevList;
}

int CHeaderCtrlEx::GetItemImage( int nItem )
{
	int imageIndex;

	if ( m_mapImageIndex.Lookup( nItem, imageIndex ) )	
		return imageIndex;

	return -1;
}

void CHeaderCtrlEx::SetItemImage( int nItem, int nImage )
{
	// Save the image index	
	m_mapImageIndex[nItem] = nImage;
	
	// Change the item to ownder drawn	
	HD_ITEM hditem;	
	
	hditem.mask = HDI_FORMAT;
	GetItem( nItem, &hditem );	
	hditem.fmt |= HDF_OWNERDRAW;
	SetItem( nItem, &hditem );	
	
	// Invalidate header control so that it gets redrawn
	Invalidate();
}


void CHeaderCtrlEx::DrawItem( LPDRAWITEMSTRUCT lpDrawItemStruct )
{
	CDC dc;

	dc.Attach( lpDrawItemStruct->hDC );
	
	// Get the column rect
	CRect rcLabel( lpDrawItemStruct->rcItem );
	
	// Save DC
	int nSavedDC = dc.SaveDC();

	// Set clipping region to limit drawing within column	
	CRgn rgn;
	rgn.CreateRectRgnIndirect( &rcLabel );
	dc.SelectObject( &rgn );
	rgn.DeleteObject();	
	
    // Draw the background
    dc.FillRect(rcLabel, &CBrush(::GetSysColor(COLOR_3DFACE)));

	// Labels are offset by a certain amount  
	// This offset is related to the width of a space character
	int offset = dc.GetTextExtent(_T(" "), 1 ).cx*2;	
	
	// Draw image from image list
	int imageIndex;
	
	if (m_pImageList && 
		m_mapImageIndex.Lookup( lpDrawItemStruct->itemID, imageIndex ) )
	{
		if( imageIndex != -1 )
		{
			m_pImageList->Draw(&dc, imageIndex, 
						CPoint( rcLabel.left + offset - 3,offset/3 - 1),
						ILD_TRANSPARENT );
			
			// Now adjust the label rectangle
			IMAGEINFO imageinfo;
			if( m_pImageList->GetImageInfo( imageIndex, &imageinfo ) )			
			{
				rcLabel.left += offset/2 + 
					imageinfo.rcImage.right - imageinfo.rcImage.left;
			}
		}
	}

	// Get the column text and format
	TCHAR buf[256];
	HD_ITEM hditem;	

	hditem.mask = HDI_TEXT | HDI_FORMAT;
	hditem.pszText = buf;
	hditem.cchTextMax = 255;

	GetItem( lpDrawItemStruct->itemID, &hditem );

	// Determine format for drawing column label
	UINT uFormat = DT_SINGLELINE | DT_NOPREFIX | DT_NOCLIP 
						| DT_VCENTER | DT_END_ELLIPSIS ;
	
	if( hditem.fmt & HDF_CENTER)
		uFormat |= DT_CENTER;
	else if( hditem.fmt & HDF_RIGHT)
		uFormat |= DT_RIGHT;
	else
		uFormat |= DT_LEFT;

	// Adjust the rect if the mouse button is pressed on it
	if( lpDrawItemStruct->itemState == ODS_SELECTED )
	{
		rcLabel.left++;
		rcLabel.top += 2;
		rcLabel.right++;
	}
	
    // Adjust the rect further if Sort arrow is to be displayed
    if( lpDrawItemStruct->itemID == (UINT)m_nSortCol )
    {
        rcLabel.right -= 3 * offset;
    }

	rcLabel.left += offset;
	rcLabel.right -= offset;
	
	// Draw column label
	if( rcLabel.left < rcLabel.right )
		dc.DrawText(buf,-1,rcLabel, uFormat);

    // Draw the Sort arrow
    if( lpDrawItemStruct->itemID == (UINT)m_nSortCol )
    {
        CRect rcIcon( lpDrawItemStruct->rcItem );

        // Set up pens to use for drawing the triangle
        CPen penLight(PS_SOLID, 1, GetSysColor(COLOR_3DHILIGHT));
        CPen penShadow(PS_SOLID, 1, GetSysColor(COLOR_3DSHADOW));
        CPen *pOldPen = dc.SelectObject( &penLight );

        if( m_bSortAsc )
        {
			// Draw triangle pointing upwards
            dc.MoveTo( rcIcon.right - 2*offset, offset-1);
            dc.LineTo( rcIcon.right - 3*offset/2, rcIcon.bottom - offset );
            dc.LineTo( rcIcon.right - 5*offset/2-2, rcIcon.bottom - offset );
            dc.MoveTo( rcIcon.right - 5*offset/2-1, rcIcon.bottom - offset-1 );

            dc.SelectObject( &penShadow );
            dc.LineTo( rcIcon.right - 2*offset, offset-2);
        }
        else
        {
			// Draw triangle pointing downwords
            dc.MoveTo( rcIcon.right - 3*offset/2, offset-1);
            dc.LineTo( rcIcon.right - 2*offset-1, rcIcon.bottom - offset + 1 );
            dc.MoveTo( rcIcon.right - 2*offset-1, rcIcon.bottom - offset );

            dc.SelectObject( &penShadow );
            dc.LineTo( rcIcon.right - 5*offset/2-1, offset -1 );
            dc.LineTo( rcIcon.right - 3*offset/2, offset -1);
        }

        // Restore the pen
        dc.SelectObject( pOldPen );
	}

	// Restore dc
	dc.RestoreDC( nSavedDC );
	
	// Detach the dc before returning
	dc.Detach();
}
