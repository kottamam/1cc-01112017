//
//	Header file for finding servers using backend worker threads
//

#ifndef __SEARCH_THREAD__
#define __SEARCH_THREAD__

class SearchWorker;
class SearchServers;

#include <stl\NrString.h>
#include <stl\STLPointer.h>
#include <list>

//
//	This class should be declared as a static object
//

class SearchWorker
{
public:
	SearchServers	*parent;

	HANDLE			hWorkerStopEvent;
	HANDLE			hThread;

					SearchWorker();
					~SearchWorker();

	BOOL			operator==(const SearchWorker& x)	{ return x.hThread == hThread; }

	static void		WorkerThread(SearchWorker *worker);

	bool			allowsConnection(const IM::NrString& szServerName);
};

class ServerInfo
{
public:
	IM::NrString	domainName;
	IM::NrString	serverName;

	BOOL			operator==(const ServerInfo& x)	{ return (x.domainName == domainName && x.serverName == serverName); }

};


class SearchServers
{
public:
	typedef IM::STLPointer<SearchWorker>		SearchWorkerPointer;
	typedef imstd::list<SearchWorkerPointer>	WorkerList;

	HANDLE					hDoneEvent;
	bool					bGotAllInfo;
	CRITICAL_SECTION		csLock;
	WorkerList				workerList;

	typedef IM::STLPointer<ServerInfo> ServerInfoPointer;
	imstd::list<ServerInfoPointer> serverFoundList;

	SearchServers();
	~SearchServers();

	void	lock()									{	EnterCriticalSection(&csLock);	}
	void	unlock()								{	LeaveCriticalSection(&csLock);	}

	void	startSearch();
	void	stopSearch();
	bool	doneSearch();
	bool	gotAllInfo();
	bool	IsStopped()								{	return workerList.size() == 0;	}

	void	addServerInfo(const IM::NrString& domainName, const IM::NrString& serverName);
	bool	getServerInfo(ServerInfo& serverInfo);
};

#endif __SEARCH_THREAD__

