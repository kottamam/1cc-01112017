//---------------------------------------------------------------------------
#ifndef ServiceLookupH
#define ServiceLookupH
#include <registry\EMailSvcConfiguration.h>
#include "registry\LNEMailSvcConfiguration.h"

class LookupManager;

class LookupWork
{
public:
	IM::NrString		serverName;
	bool				bAtInitialization;
	bool				bGotService;

	IM::DmsServiceConfiguration			*m_pDmsService;
	IM::IdxMgrServiceConfiguration		*m_pIdxMgrService;
	IM::IdxSearchServiceConfiguration	*m_pIdxSearchService;
	IM::RulesServiceConfiguration		*m_pRulesSearchService;
	IM::FmaServiceConfiguration			*m_pFmaService;
	IM::EFSServiceConfiguration			*m_pEFSService;
	IM::PrintRenditionServiceConfiguration *m_pPrintRendService;
	IM::WkDreServiceConfiguration		*m_pWkDreService;
	IM::WkIndxrServiceConfiguration		*m_pKMIdxService;
	IM::WkAtIndxrServiceConfiguration	*m_pWkAtIdxService;
	IM::CDSSyncSvc						*m_pDSSyncSvc;
	IM::EMSServiceConfiguration			*m_pEmsService;
	IM::CIFSServiceConfiguration		*m_pCifsService;
	IM::IDXSVCConfiguration				*m_pIDXService;
	IM::EMailSvcConfiguration			*m_pEOLService;
	IM::LNEMailSvcConfiguration			*m_pLNService;

					LookupWork();
					~LookupWork();

	BOOL			operator==(const LookupWork& x)	{ return (x.serverName == serverName); }

};

class LookupWorker
{
	LookupManager	*lookupMgr;
	LookupWork		*work;


	HANDLE			hStopEvent;
	HANDLE			hThread;

public:
	bool			bDoneWork;

					LookupWorker(LookupWork *work, LookupManager *mgr);
					~LookupWorker();

	BOOL			operator==(const LookupWorker& x)	{ return x.hThread == hThread; }

	static void		workerThread(LookupWorker *worker);
};


class LookupManager
{
	friend LookupWorker;

private:

	typedef IM::STLPointer<LookupWork>			LookupWorkPointer;
	typedef imstd::list<LookupWorkPointer>		WorkList;

	typedef IM::STLPointer<LookupWorker>		LookupWorkerPointer;
	typedef imstd::list<LookupWorkerPointer>	WorkerList;

	WorkList			resultList;

	CRITICAL_SECTION	csLock;

	WorkerList			workerList;

	HANDLE				hThread;

	HANDLE			   	hStopEvent;

	void				lock()			{	EnterCriticalSection(&csLock);	}
	void				unlock()		{	LeaveCriticalSection(&csLock);	}

	static void			managerThread(LookupManager *mgr);

	void				workerCleanup();

public :

					LookupManager();
					~LookupManager();

	void			addRequest(const IM::NrString& strComputerName_, bool bAtInitialization);
	bool
		getResult(
			IM::NrString& strComputerName_,
			bool& bConnected_,
			bool& bAtInitialization_,
			IM::DmsServiceConfiguration*&		pDmsService_,
			IM::IdxMgrServiceConfiguration*&	pIdxMgrService_,
			IM::IdxSearchServiceConfiguration*&	pIdxSearchService_,
			IM::RulesServiceConfiguration*&		pRulesSearchService_,
			IM::FmaServiceConfiguration*&		pFmaService_,
			IM::EFSServiceConfiguration*&		pEFSService_,
			IM::PrintRenditionServiceConfiguration*& pPrintRendService_,
			IM::WkDreServiceConfiguration*&		pWkDreService_,
			IM::WkIndxrServiceConfiguration*&	pKMIdxService_,
			IM::WkAtIndxrServiceConfiguration*&	pWkAtIdxService_,
			IM::CDSSyncSvc*&					pDSSyncSvc_,
			IM::EMSServiceConfiguration*&		pEmsService_,
			IM::CIFSServiceConfiguration*&		pCifsService_,
			IM::IDXSVCConfiguration*&			pIDXService_,
			IM::EMailSvcConfiguration*&			pEOLService_,
			IM::LNEMailSvcConfiguration*&		pLNService_
		);
};
#endif ServiceLookupH
//---------------------------------------------------------------------------

