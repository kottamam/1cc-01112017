#if !defined(AFX_DSCONNECTIONS_H__EEC43E3C_7447_4A2C_AE9D_4D4A6193CF01__INCLUDED_)
#define AFX_DSCONNECTIONS_H__EEC43E3C_7447_4A2C_AE9D_4D4A6193CF01__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DSConnections.h : header file
//


namespace DSLocal
{
	class CDSSyncSvc_AttributeMap;
	class CDSSyncSvc_DSParameters;
	class CDSSyncSvc_DMSParameters;
	class CDSSyncSvc_Connection;
	class CDSSyncSvc;
}


/////////////////////////////////////////////////////////////////////////////
// DSConnections dialog

class DSConnections : public CDialog
{
// Construction
public:
	DSConnections(CWnd* pParent = NULL);   // standard constructor
	virtual ~DSConnections( void );			// destructor

	void AddConnectionToList( IM::CDSSyncSvc_Connection* pConnection );
	void UpdateConnection(IM::CDSSyncSvc_Connection* pConnection_Local, IM::CDSSyncSvc_Connection* pConnection);
	void AddAllConnectionsToList( );
	void SetRegistryObject( IM::CDSSyncSvc* pSyncSvc );
	CString m_strServer;
	void EnableButtons( const BOOL bEnable );
	void AssignRemoteToLocal_AttributeMapsOnly( void );

// Dialog Data
	//{{AFX_DATA(DSConnections)
	enum { IDD = IDD_DS_CONNECTIONS };
	CButton	m_btnClear;
	CButton	m_btnOk;
	CButton	m_btnHelp;
	CListCtrl	m_list;
	CButton	m_btnEdit;
	CButton	m_btnDelete;
	CButton	m_btnCopy;
	CButton	m_btnAdd;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(DSConnections)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	void InitListControl( void );
	IM::CDSSyncSvc* m_pSyncSvc_Remote;
	IM::CDSSyncSvc* m_pSyncSvc_Local;
	void AddConnectionsFromRegistryObject( void );
	void AssignRemoteToLocal( void );
	void ApplyChanges();
	CString GetNextCopyName( IM::CDSSyncSvc_Connection *pCurrentConnection );
	bool ConnectionNameExists( CString strName );
	void UpdateRegistryPaths( IM::CDSSyncSvc_Connection *pConnection );	

	void DoSize( int cx, int cy );
	afx_msg void OnGetMinMaxInfo( MINMAXINFO FAR* lpMMI );

	// Generated message map functions
	//{{AFX_MSG(DSConnections)
	virtual void OnOK();
	afx_msg void OnDblclkListConnections(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnButtonEdit();
	afx_msg void OnButtonDelete();
	afx_msg void OnButtonCopy();
	afx_msg void OnButtonAdd();
	virtual BOOL OnInitDialog();
	afx_msg void OnClickListConnections(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnButtonClear();
	afx_msg void OnClose();
	afx_msg BOOL OnHelpInfo(HELPINFO* pHelpInfo);
	afx_msg void OnHelp();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DSCONNECTIONS_H__EEC43E3C_7447_4A2C_AE9D_4D4A6193CF01__INCLUDED_)
