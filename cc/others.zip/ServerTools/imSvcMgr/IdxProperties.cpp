// IdxProperties.cpp : implementation file
//

#include "stdafx.h"
#include "imSvcMgr.h"
#include "IdxProperties.h"
#include <stl/NrString.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// IdxProperties dialog


IdxProperties::IdxProperties(CWnd* pParent /*=NULL*/)
	: CDialog(IdxProperties::IDD, pParent)
{
	//{{AFX_DATA_INIT(IdxProperties)
	m_BlockSize = _T("");
	//}}AFX_DATA_INIT
	
	int matrix[7][12] = {
	{	IDC_CB000, IDC_CB001, IDC_CB002, IDC_CB003, IDC_CB004, IDC_CB005, IDC_CB006, IDC_CB007, IDC_CB008, IDC_CB009, IDC_CB010, IDC_CB011	},
	{	IDC_CB100, IDC_CB101, IDC_CB102, IDC_CB103, IDC_CB104, IDC_CB105, IDC_CB106, IDC_CB107, IDC_CB108, IDC_CB109, IDC_CB110, IDC_CB111	},
	{	IDC_CB200, IDC_CB201, IDC_CB202, IDC_CB203, IDC_CB204, IDC_CB205, IDC_CB206, IDC_CB207, IDC_CB208, IDC_CB209, IDC_CB210, IDC_CB211	},
	{	IDC_CB300, IDC_CB301, IDC_CB302, IDC_CB303, IDC_CB304, IDC_CB305, IDC_CB306, IDC_CB307, IDC_CB308, IDC_CB309, IDC_CB310, IDC_CB311	},
	{	IDC_CB400, IDC_CB401, IDC_CB402, IDC_CB403, IDC_CB404, IDC_CB405, IDC_CB406, IDC_CB407, IDC_CB408, IDC_CB409, IDC_CB410, IDC_CB411	},
	{	IDC_CB500, IDC_CB501, IDC_CB502, IDC_CB503, IDC_CB504, IDC_CB505, IDC_CB506, IDC_CB507, IDC_CB508, IDC_CB509, IDC_CB510, IDC_CB511	},
	{	IDC_CB600, IDC_CB601, IDC_CB602, IDC_CB603, IDC_CB604, IDC_CB605, IDC_CB606, IDC_CB607, IDC_CB608, IDC_CB609, IDC_CB610, IDC_CB611	},
	};

    for (int i = 0; i < 7; i++)
    {
    	for (int j = 0; j < 12; j++)
        	cbMatrix[i][j] = matrix[i][j];
    }
}

bool IdxProperties::IdIsChild(int id)
{
	for (int i = 0; i < 7; i++)
    {
    	for (int j = 0; j < 12; j++)
        	if (id == cbMatrix[i][j])
				return(true);
    }

	return(false);
}

void IdxProperties::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(IdxProperties)
	DDX_Control(pDX, IDC_SPIN_BLOCK_SIZE, m_SpinBlockSize);
	DDX_Text(pDX, IDC_BLOCK_SIZE, m_BlockSize);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(IdxProperties, CDialog)
	//{{AFX_MSG_MAP(IdxProperties)
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDC_SCHEDULE_RB, OnScheduleRb)
	ON_BN_CLICKED(IDC_CONTINUOUS_RB, OnContinuousRb)
	ON_EN_CHANGE(IDC_BLOCK_SIZE, OnChangeBlockSize)
	ON_BN_CLICKED(IDC_NONE_RB, OnNoneRb)
	ON_BN_CLICKED(IDC_OLDEST_RB, OnOldestRb)
	ON_BN_CLICKED(IDC_LATEST_RB, OnLatestRb)
	ON_BN_CLICKED(IDHELP, OnHelp)
	//}}AFX_MSG_MAP 
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// IdxProperties message handlers

BOOL IdxProperties::OnInitDialog() 
{
	m_pService->LoadFromRegistry();

	CString aString;
	_itot(m_pService->m_lPacketSize.Get(), (_TCHAR*)(LPCSTR)aString.GetBuffer(10), 10);
	aString.ReleaseBuffer();
	IM::NrString blockSize(aString);
	m_BlockSize	= blockSize.c_str();

	if (m_pService->m_strIndexingOrder.Get().compare(_T("X")) == 0)
		((CButton*)GetDlgItem(IDC_NONE_RB))->SetCheck(1);
	else if (m_pService->m_strIndexingOrder.Get().compare(_T("A")) == 0)
		((CButton*)GetDlgItem(IDC_OLDEST_RB))->SetCheck(1);
    else
		((CButton*)GetDlgItem(IDC_LATEST_RB))->SetCheck(1);

    if (m_pService->m_strRunMode.Get().compare(_T("C")) == 0)
    {
		((CButton*)GetDlgItem(IDC_CONTINUOUS_RB))->SetCheck(1);
		DisableScheduleMatrix();
    }
    else
    {
		((CButton*)GetDlgItem(IDC_SCHEDULE_RB))->SetCheck(1);
        EnableScheduleMatrix();
    }

    for (int i = 0; i < 7; i++)
    {
    	for (int j = 0; j < 12; j++)
        {
        	if (m_pService->m_bScheduleTable[i][j].Get() == true)
            	((CButton*)GetDlgItem(cbMatrix[i][j]))->SetCheck(1);
        }
    }

	GetDlgItem(IDC_BLOCK_SIZE)->SetFocus();
	IM::NrString aCaption = BuildCaption(IDS_PROP_110, m_pService->m_strServiceDisplayName.c_str(), m_pService->m_strComputerName.c_str());
	SetWindowText(aCaption.c_str());
	GetDlgItem(IDOK)->EnableWindow(0);
	SetDefID(IDCANCEL);
	CDialog::OnInitDialog();
	m_SpinBlockSize.SetRange(0, 100);
	m_SpinBlockSize.SetBuddy(GetDlgItem(IDC_BLOCK_SIZE));
	return 0;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void IdxProperties::EnableScheduleMatrix()
{
    for (int i = 0; i < 7; i++)
    {
    	for (int j = 0; j < 12; j++)
        	GetDlgItem(cbMatrix[i][j])->EnableWindow();
    }
}

void IdxProperties::DisableScheduleMatrix()
{
    for (int i = 0; i < 7; i++)
    {
    	for (int j = 0; j < 12; j++)
        	GetDlgItem(cbMatrix[i][j])->EnableWindow(0);
    }
}

void IdxProperties::OnOK() 
{
	if(((CButton*)GetDlgItem(IDC_SCHEDULE_RB))->GetCheck() == 1)
	{
		bool bScheduled = false;

		for (int i = 0; i < 7; i++)
		{
			for (int j = 0; j < 12; j++)
			{
				if (((CButton*)GetDlgItem(cbMatrix[i][j]))->GetCheck() == 1)
				{
					bScheduled = true;
					break;
				}
			}
		}

		if (bScheduled == false)
		{
    		Report(REP_WARN, IDS_IDXPROP_260);
			return;
		}
	}

	CString aString;
	GetDlgItem(IDC_BLOCK_SIZE)->GetWindowText(aString);
	m_pService->m_lPacketSize.Set(_ttoi(aString));

	CButton* aNoneButton = (CButton*)GetDlgItem(IDC_NONE_RB);
	CButton* aOldestButton = (CButton*)GetDlgItem(IDC_OLDEST_RB);
	CButton* aScheduleButton = (CButton*)GetDlgItem(IDC_SCHEDULE_RB);

    m_pService->m_strIndexingOrder.Set((aNoneButton->GetCheck() == 1) ? _T("X") : ((aOldestButton->GetCheck() == 1) ?  _T("A") : _T("D")));
	m_pService->m_strRunMode.Set((aScheduleButton->GetCheck() == 1) ?  _T("S") : _T("C"));

	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j < 12; j++)
		{
			m_pService->m_bScheduleTable[i][j].Set(((CButton*)GetDlgItem(cbMatrix[i][j]))->GetCheck() == 1);
		}
	}

	m_pService->StoreInRegistry();
	CDialog::OnOK();
}

void IdxProperties::OnClose() 
{
	// if scheduled run then verify that there is at least one scheduled quantum
/*	if(((CButton*)GetDlgItem(IDC_SCHEDULE_RB))->GetCheck() == 0)
		return;

	bool bScheduled = false;

	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j < 12; j++)
		{
			if (((CButton*)GetDlgItem(cbMatrix[i][j]))->GetCheck() == 1)
			{
				bScheduled = true;
				break;
			}
		}
	}

	if (bScheduled == false)
    	Report(REP_WARN, IDS_IDXPROP_260);*/
	
	CDialog::OnClose();
}

void IdxProperties::OnScheduleRb() 
{
	Changed();
	CButton* aScheduleButton = (CButton*)GetDlgItem(IDC_SCHEDULE_RB);

    if (aScheduleButton->GetCheck() == 1)
    	EnableScheduleMatrix();
    else
    	DisableScheduleMatrix();
}

void IdxProperties::OnContinuousRb() 
{
	Changed();

	CButton* aScheduleButton = (CButton*)GetDlgItem(IDC_SCHEDULE_RB);
    
    if (aScheduleButton->GetCheck() == 1)
    	EnableScheduleMatrix();
    else
    	DisableScheduleMatrix();
}


BOOL IdxProperties::OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo) 
{
	if (IdIsChild(nID))
		Changed();

	return CDialog::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);
}

void IdxProperties::Changed()
{
	GetDlgItem(IDOK)->EnableWindow(true);
	SetDefID(IDOK);
}

void IdxProperties::OnChangeBlockSize() 
{
	Changed();
}

void IdxProperties::OnNoneRb() 
{
	Changed();
}

void IdxProperties::OnOldestRb() 
{
	Changed();
}

void IdxProperties::OnLatestRb() 
{
	Changed();
}

void IdxProperties::OnCancel() 
{
	// if scheduled run then verify that there is at least one scheduled quantum
/*	if(((CButton*)GetDlgItem(IDC_SCHEDULE_RB))->GetCheck() == 0)
	{
		CDialog::OnCancel();
		return;
	}

	bool bScheduled = false;

	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j < 12; j++)
		{
			if (((CButton*)GetDlgItem(cbMatrix[i][j]))->GetCheck() == 1)
			{
				bScheduled = true;
				break;
			}
		}
	}

	if (bScheduled == false)
    	Report(REP_WARN, IDS_IDXPROP_260);
	else*/
	CDialog::OnCancel();
}

void IdxProperties::OnHelp() 
{
	//WinHelp(29, HELP_CONTEXT);
	HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, 29);
}
