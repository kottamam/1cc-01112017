// EMSDatabaseProp2.cpp : implementation file
//

#include <stdafx.h>

#include <imSvcMgr.h>
#include <EMSDatabaseProp2.h>
#include <stl/NrString.h>


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// EMSDatabaseProp2 dialog


EMSDatabaseProp2::EMSDatabaseProp2(CWnd* pParent /*=NULL*/)
	: CDialog(EMSDatabaseProp2::IDD, pParent)
{
	//{{AFX_DATA_INIT(EMSDatabaseProp2)
	m_DatabaseName = IM::EmsDatabaseEntry::ms_strDefaultDatabaseName.c_str();
	m_Password = IM::ServerEntry::ms_strDefaultPassword.c_str();
	m_Port = IM::ServerEntry::ms_lDefaultPort;
	m_ServerName = IM::ServerEntry::ms_strDefaultServerName.c_str();
	m_Username = IM::ServerEntry::ms_strDefaultUsername.c_str();
	//}}AFX_DATA_INIT
}


void EMSDatabaseProp2::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(EMSDatabaseProp2)
	DDX_Text(pDX, IDC_EMS_DB_NAME, m_DatabaseName);
	DDX_Control(pDX, IDC_EMS_ENABLE_PORT, m_EnablePort);
	DDX_Text(pDX, IDC_EMS_PASSWORD, m_Password);
	DDX_Text(pDX, IDC_EMS_PORT, m_Port);
	DDX_Text(pDX, IDC_EMS_SVR_NAME, m_ServerName);
	DDX_Text(pDX, IDC_EMS_USERNAME, m_Username);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(EMSDatabaseProp2, CDialog)
	//{{AFX_MSG_MAP(EMSDatabaseProp2)
	ON_BN_CLICKED(IDC_HELP, OnHelp)
	ON_EN_CHANGE(IDC_EMS_DB_NAME, OnChange)
	ON_EN_CHANGE(IDC_EMS_PASSWORD, OnChange)
	ON_BN_CLICKED(IDC_EMS_ENABLE_PORT, OnChange)
	ON_EN_CHANGE(IDC_EMS_PORT, OnChange)
	ON_EN_CHANGE(IDC_EMS_SVR_NAME, OnChange)
	ON_EN_CHANGE(IDC_EMS_USERNAME, OnChange)
	ON_BN_CLICKED(IDHELP, OnHelp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// EMSDatabaseProp2 message handlers

BOOL EMSDatabaseProp2::OnInitDialog() 
{
	UpdateData(0);

	m_lSavedMaxFolderList = IM::ServerEntry::ms_lDefaultMaxFolderList;
	m_pServiceConfiguration->LoadFromRegistry();

	// if MODIFY
	if (m_DatabaseName != IM::EmsDatabaseEntry::ms_strDefaultDatabaseName.c_str())
    {
		GetDlgItem(IDC_EMS_DB_NAME)->EnableWindow(false);
		try
		{
			// Get repository information for this database and display
			for (imstd::vector<IM::EmsDatabaseEntry>::iterator	it = m_pServiceConfiguration->m_Databases.begin();
															it != m_pServiceConfiguration->m_Databases.end();
															it++)
				if (it->m_strDatabaseName.Get() == m_DatabaseName)
				{
					imstd::vector<IM::ServerEntry>::iterator j = it->m_Servers.begin();
					m_ServerName = j->m_strServerName.Get().c_str();
					m_Username = j->m_strUsername.Get().c_str();
					m_Password = j->m_strPassword.Get().c_str();
					m_Port = j->m_lPort.Get();
					m_lSavedMaxFolderList = j->m_lMaxFolderList.Get();
					m_EnablePort.SetCheck(j->m_bSpecifyPort.Get());
					GetDlgItem(IDC_EMS_PORT)->EnableWindow(j->m_bSpecifyPort.Get());

					break;
				}
		}
		catch (long)
		{
			Report(REP_WARN, IDS_DATABASE_101, m_DatabaseName);
			SendMessage(WM_CLOSE);
			return TRUE;
		}
	}
	else	// else ADD
	{
		GetDlgItem(IDC_EMS_DB_NAME)->EnableWindow();
		GetDlgItem(IDC_EMS_USERNAME)->EnableWindow();
		GetDlgItem(IDC_EMS_PASSWORD)->EnableWindow();
		GetDlgItem(IDC_EMS_SVR_NAME)->EnableWindow();

		m_DatabaseName	= IM::EmsDatabaseEntry::ms_strDefaultDatabaseName.c_str();
		m_Password		= IM::ServerEntry::ms_strDefaultPassword.c_str();
		m_Username		= IM::ServerEntry::ms_strDefaultUsername.c_str();
		m_ServerName	= IM::ServerEntry::ms_strDefaultServerName.c_str();

		((CButton*) GetDlgItem(IDC_EMS_ENABLE_PORT))->SetCheck(0);
		m_EnablePort.SetCheck(false);
		GetDlgItem(IDC_EMS_PORT)->EnableWindow(false);
	}

	// Allow OK button only after a change
	GetDlgItem(IDOK)->EnableWindow(false);
	SetDefID(IDCANCEL);
	CDialog::OnInitDialog();

	return 0;
}


void EMSDatabaseProp2::OnChange() 
{
	if (!GetDlgItem(IDOK) || !::IsWindow(GetDlgItem(IDOK)->m_hWnd))
		return;

	if (((CButton*)GetDlgItem(IDC_EMS_ENABLE_PORT))->GetCheck() == 0)
		GetDlgItem(IDC_EMS_PORT)->EnableWindow(0);
	else
		GetDlgItem(IDC_EMS_PORT)->EnableWindow();

	GetDlgItem(IDC_EMS_DB_NAME)->GetWindowText(m_DatabaseName);
	GetDlgItem(IDC_EMS_USERNAME)->GetWindowText(m_Username);
	GetDlgItem(IDC_EMS_PASSWORD)->GetWindowText(m_Password);
	GetDlgItem(IDC_EMS_SVR_NAME)->GetWindowText(m_ServerName);

	m_DatabaseName.TrimLeft();
	m_DatabaseName.TrimRight();
	m_Username.TrimLeft();
	m_Username.TrimRight();
	m_Password.TrimLeft();
	m_Password.TrimRight();
	m_ServerName.TrimLeft();
	m_ServerName.TrimRight();

	if (m_DatabaseName.IsEmpty() || m_Username.IsEmpty() || m_Password.IsEmpty() || m_ServerName.IsEmpty())
	{
		GetDlgItem(IDOK)->EnableWindow(false);
		SetDefID(IDCANCEL);
		return;
	}

	GetDlgItem(IDOK)->EnableWindow(true);
	SetDefID(IDOK);	
}

void EMSDatabaseProp2::OnOK() 
{
	GetDlgItem(IDC_EMS_DB_NAME)->GetWindowText(m_DatabaseName);
	GetDlgItem(IDC_EMS_USERNAME)->GetWindowText(m_Username);
	GetDlgItem(IDC_EMS_PASSWORD)->GetWindowText(m_Password);
	GetDlgItem(IDC_EMS_SVR_NAME)->GetWindowText(m_ServerName);
	CString strPort;
	GetDlgItem(IDC_EMS_PORT)->GetWindowText(strPort);

	m_DatabaseName.TrimLeft();
	m_DatabaseName.TrimRight();
	m_Username.TrimLeft();
	m_Username.TrimRight();
	m_Password.TrimLeft();
	m_Password.TrimRight();
	m_ServerName.TrimLeft();
	m_ServerName.TrimRight();
	strPort.TrimLeft();
	strPort.TrimRight();

	m_Port = _ttoi(strPort);

	IM::NrString strDatabaseName	= m_DatabaseName;
	IM::NrString strServerName		= m_ServerName;
	IM::NrString strUsername		= m_Username;
	IM::NrString strPassword		= m_Password;


	m_pServiceConfiguration->AddDatabaseToRegistry(	strDatabaseName,
													strServerName,
													m_EnablePort.GetCheck() == 1,
													m_Port,
													strUsername,
													strPassword,
													m_lSavedMaxFolderList);
	m_SavedDatabaseName = m_DatabaseName;
	m_pServiceConfiguration->LoadFromRegistry();
	CDialog::OnOK();
}

void EMSDatabaseProp2::OnCancel() 
{
	// TODO: Add extra cleanup here
	
	CDialog::OnCancel();
}

void EMSDatabaseProp2::OnHelp() 
{
	::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, 22);
}

