#if !defined(AFX_IDXDBPROP_H__F6C40D66_DE09_11D2_8C54_00C04F68F9B3__INCLUDED_)
#define AFX_IDXDBPROP_H__F6C40D66_DE09_11D2_8C54_00C04F68F9B3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// IdxDbProp.h : header file
//

class IdxDatabaseList;

/////////////////////////////////////////////////////////////////////////////
// IdxDbProp dialog

class IdxDbProp : public CDialog
{
// Construction
public:
	IdxDbProp(CWnd* pParent = NULL);   // standard constructor
	IM::DatabaseEntryList	*m_pDatabaseList;
	bool					m_bAllowPrimary;

// Dialog Data
	//{{AFX_DATA(IdxDbProp)
	enum { IDD = IDD_IDX_DB_PROPERTIES };
	CButton	m_OdbcBrowse;
	CEdit	m_OdbcName;
	CString	m_DatabaseValue;
	CString	m_LogonID;
	CString	m_Password;
	//}}AFX_DATA
	CString m_SavedOdbcName;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(IdxDbProp)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(IdxDbProp)
	afx_msg void OnBrowseIdxDb();
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnChangeIdxLogonid();
	afx_msg void OnChangeIdxPassword();
	afx_msg void OnClose();
	afx_msg void OnHelp();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_IDXDBPROP_H__F6C40D66_DE09_11D2_8C54_00C04F68F9B3__INCLUDED_)
