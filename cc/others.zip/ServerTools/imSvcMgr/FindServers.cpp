// FindServers.cpp : implementation file
//

#include "stdafx.h"

#include "imSvcMgr.h"
#include "searchthread.h"
#include "FindServers.h"
#include "mainfrm.h"
#include "imSvcMgrDoc.h"
#include "imSvcMgrView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


extern SearchServers gSearchServers;


/////////////////////////////////////////////////////////////////////////////
// FindServers dialog


FindServers::FindServers(CWnd* pParent /*=NULL*/)
	: CDialog(FindServers::IDD, (CWnd*)pParent)
{
	//{{AFX_DATA_INIT(FindServers)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	bStop = false;
}

FindServers::~FindServers()
{
//	KillTimer(m_TimerID);
}

void FindServers::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(FindServers)
	DDX_Control(pDX, IDC_ANIMATE, m_AnimateCtrl);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(FindServers, CDialog)
	//{{AFX_MSG_MAP(FindServers)
	ON_BN_CLICKED(IDHELP, OnHelp)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// FindServers message handlers

void FindServers::OnTimer(UINT_PTR eventID)
{
	ServerInfo serverInfo;

	if (bStop == true)
	{
		gSearchServers.stopSearch();
		SendMessage(WM_CLOSE);
		return;
	}

	// get servers till there is no more to process
	while (gSearchServers.getServerInfo(serverInfo) != false)
	{
		if (m_Document->isServerInList(serverInfo.serverName.c_str()) == true)
			continue;

		try
		{
			if (m_Document->addServer(serverInfo.serverName.c_str(), false) == true)
			{
				// add server name to registry
				IM::Registry	serverReg(NULL, HKEY_CURRENT_USER, KEY_NRSCONF_PATH);

				serverReg.AddPath(_T("\\"));
				serverReg.AddPath(serverInfo.serverName.c_str());
				serverReg.OpenOrCreate(NULL, KEY_ALL_ACCESS);
			}
		}
		catch(Exception &e)
		{
			AfxMessageBox(e.m_strWhat.c_str());
		}

		if (bStop == true)
		{
			gSearchServers.stopSearch();
			SendMessage(WM_CLOSE);
			return;
		}
	}

	if (gSearchServers.doneSearch() == true)
	{
		gSearchServers.stopSearch();

		if (gSearchServers.gotAllInfo() != true)
			Report(REP_INFO, IDS_SEARCH_171);

		KillTimer(m_TimerID);
		SendMessage(WM_CLOSE);
	}
}

BOOL FindServers::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	bStop = false;

	DWORD aStyle = WS_CHILD|WS_VISIBLE|ACS_CENTER;  
	gSearchServers.startSearch();
	m_AnimateCtrl.Open(_T("Findcomp.avi"));
	m_TimerID = SetTimer(1000, 2000, NULL); 
	return 0;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void FindServers::OnHelp() 
{
	::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, 32);		
}

void FindServers::OnCancel() 
{
	bStop = true;
	CDialog::OnCancel();
}
