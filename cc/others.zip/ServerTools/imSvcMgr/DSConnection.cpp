// DSConnection.cpp : implementation file
//

#include "stdafx.h"
#include "imsvcmgr.h"
#include "DSConnection.h"
#include "DSConnections.h"
#include "DSAttributeMap.h"
#include "DSNode2.h"
#include <imLDAP/NDS.h>

#include "RestCommunication.h"
#include "Base64Encoding.h"




#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

using namespace iwADFS;
#define ENCRYPT_KEY			"iManage Service"

// fowards
UINT DomainNamesThread( LPVOID pVoid );

BOOL isDlgClosed = FALSE;
/////////////////////////////////////////////////////////////////////////////
// DSConnection dialog


DSConnection::DSConnection(CWnd* pParent /*=NULL*/)
	: CDialog(DSConnection::IDD, pParent), m_pSyncSvc_Local( NULL ), m_pConnection_Local( NULL ), m_Mode( Add ), m_strServer( _T( "" ) )
{
	//{{AFX_DATA_INIT(DSConnection)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

DSConnection::~DSConnection( void )
{
}

void DSConnection::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(DSConnection)
	DDX_Control(pDX, IDC_LBL_BLANK, m_stcLabelBlank);
	DDX_Control(pDX, IDC_LBL_CONTEXT, m_stcLabelContext);
	DDX_Control(pDX, IDC_EDIT_CONTEXT, m_edtContext);
	DDX_Control(pDX, IDC_PWD_MATCH_NOT, m_stcPasswordMatchNot);
	DDX_Control(pDX, IDC_PWD_MATCH, m_stcPasswordMatch);
	DDX_Control(pDX, IDC_BUTTON_TEST_LOGIN, m_btnTest);
	DDX_Control(pDX, IDC_COMBO_NTDOMAIN, m_cboNtDomain);
	DDX_Control(pDX, IDC_EDIT_DEFAULT_PWD_CONFIRM, m_edtDefaultPasswordConfirm);
	DDX_Control(pDX, IDC_EDIT_DEFAULT_PWD, m_edtDefaultPassword);
	DDX_Control(pDX, IDC_CHECK_DEFAULT_PWD_NEVER_EXPIRES, m_btnDefaultPasswordNeverExpires);
	DDX_Control(pDX, IDC_CHECK_DEFAULT_MUST_CHANGE_PWD, m_btnDefaultMustChangePassword);
	DDX_Control(pDX, IDC_EDIT_DMS_TCPIP, m_edtDmsTcpip);
	DDX_Control(pDX, IDC_BUTTON_EDIT1, m_btnEdit);
	DDX_Control(pDX, IDC_BUTTON_DELETE, m_btnDelete);
	DDX_Control(pDX, IDC_RADIO_DMS_DEFAULTPORT, m_rdoDmsTcpip);
	DDX_Control(pDX, IDC_RADIO_DMS_OTHERPORT, m_rdoDmsOtherTcpip);
	DDX_Control(pDX, IDC_RADIO_DSLOGIN1, m_rdoDSLogin1);
	DDX_Control(pDX, IDC_RADIO_DSLOGIN2, m_rdoDSLogin2);
	DDX_Control(pDX, IDC_EDIT_NODE, m_edtNode);
	DDX_Control(pDX, IDC_EDIT_NAMEDESC, m_edtNameDesc);
	DDX_Control(pDX, IDC_EDIT_DS_USER_DN, m_edtDsUser);
	DDX_Control(pDX, IDC_EDIT_DS_SERVER_TCPIP, m_edtDsTcpip);
	DDX_Control(pDX, IDC_EDIT_DS_SERVER_NAME, m_edtDsServer);
	DDX_Control(pDX, IDC_EDIT_DS_PASSWORD, m_edtDsPassword);
	DDX_Control(pDX, IDC_EDIT_DMS_USER, m_edtDmsUser);
	DDX_Control(pDX, IDC_EDIT_DMS_SERVER, m_edtDmsServer);
	DDX_Control(pDX, IDC_EDIT_DMS_PASSWORD, m_edtDmsPassword);
	DDX_Control(pDX, IDC_EDIT_DMS_LIBRARY, m_edtDmsLibrary);
	DDX_Control(pDX, IDC_COMBO_DS_SERVER_TYPE, m_cboDSServerType);
	DDX_Control(pDX, IDC_COMBO_ATTRIBUTE_MAPS, m_cboAttributeMaps);
	DDX_Control(pDX, IDC_BUTTON_BROWSE, m_btnBrowse);
	DDX_Control(pDX, IDC_BUTTON_ADD1, m_btnAdd);
	DDX_Control(pDX, IDCANCEL, m_btnCancel);
	DDX_Control(pDX, IDHELP, m_btnHelp);
	DDX_Control(pDX, IDOK, m_btnOk);
	DDX_Control(pDX, IDC_LIST_EXTERNALDNS, m_listExternalDNs);
	DDX_Control(pDX, IDC_LBL_TREEID, m_stcLabelTreeID);
	DDX_Control(pDX, IDC_STATIC_SERVERNAME, m_strServerName);
	DDX_Control(pDX, IDC_EDIT_TREEID, m_edtTreeID);

	//}}AFX_DATA_MAP

	DDX_Control(pDX, IDC_STATIC_USER_NAME, m_dmsUserNameLabel);

	DDX_Control(pDX, IDC_RADIO_IMANAGE_LOGIN, m_RadioIManageLogin);
	DDX_Control(pDX, IDC_RADIO_ADFS_LOGIN, m_RadioAdfsLogin);
	DDX_Control(pDX, IDC_DMS_PASSWORD, m_dmsPasswordText);
	
	DDX_Control(pDX, IDC_SERVER_URL, m_edtServerURL);
}


BEGIN_MESSAGE_MAP(DSConnection, CDialog)
	//{{AFX_MSG_MAP(DSConnection)
	ON_BN_CLICKED(IDHELP, OnHelp)
	ON_BN_CLICKED(IDC_BUTTON_ADD1, OnButtonAdd)
	ON_BN_CLICKED(IDC_BUTTON_BROWSE, OnButtonBrowse)
	ON_BN_CLICKED(IDC_BUTTON_EDIT1, OnButtonEdit)
	ON_BN_CLICKED(IDC_BUTTON_DELETE, OnButtonDelete)
	ON_CBN_SELCHANGE(IDC_COMBO_DS_SERVER_TYPE, OnSelchangeComboDsServerType)
	ON_CBN_SELCHANGE(IDC_COMBO_ATTRIBUTE_MAPS, OnSelchangeComboAttributeMaps)
	ON_BN_CLICKED(IDC_RADIO_DSLOGIN1, OnRadioDsLogin)
	ON_BN_CLICKED(IDC_RADIO_DSLOGIN2, OnRadioDsLogin)
	ON_BN_CLICKED(IDC_RADIO_DMS_DEFAULTPORT, OnRadioDmsDefaultPort)
	ON_BN_CLICKED(IDC_RADIO_DMS_OTHERPORT, OnRadioDmsOtherPort)
	ON_CBN_EDITCHANGE(IDC_COMBO_NTDOMAIN, OnEditchangeComboNtDomain)
	ON_BN_CLICKED(IDC_CHECK_DEFAULT_MUST_CHANGE_PWD, OnCheckDefaultMustChangePwd)
	ON_BN_CLICKED(IDC_BUTTON_TEST_LOGIN, OnButtonTestLogin)
	ON_EN_CHANGE(IDC_EDIT_NAMEDESC, OnChangeGlobal)
	ON_BN_CLICKED(IDC_CHECK_DEFAULT_PWD_NEVER_EXPIRES, OnCheckDefaultMustChangePwd)
	ON_EN_CHANGE(IDC_EDIT_DS_SERVER_TCPIP, OnChangeGlobal)
	ON_EN_CHANGE(IDC_EDIT_DS_SERVER_NAME, OnChangeGlobal)
	ON_EN_CHANGE(IDC_EDIT_DS_USER_DN, OnChangeGlobal)
	ON_EN_CHANGE(IDC_EDIT_DS_PASSWORD, OnChangeGlobal)
	ON_EN_CHANGE(IDC_EDIT_NODE, OnChangeGlobal)
	ON_EN_CHANGE(IDC_EDIT_DMS_SERVER, OnChangeGlobal)
	ON_EN_CHANGE(IDC_EDIT_DMS_LIBRARY, OnChangeGlobal)
	ON_EN_CHANGE(IDC_EDIT_DMS_USER, OnChangeGlobal)
	ON_EN_CHANGE(IDC_EDIT_DMS_PASSWORD, OnChangeGlobal)
	ON_EN_CHANGE(IDC_EDIT_DMS_TCPIP, OnChangeGlobal)
	ON_EN_CHANGE(IDC_EDIT_DEFAULT_PWD, OnChangeGlobal)
	ON_EN_CHANGE(IDC_EDIT_DEFAULT_PWD_CONFIRM, OnChangeGlobal)
	ON_EN_CHANGE(IDC_EDIT_CONTEXT, OnChangeGlobal)
	ON_LBN_SELCHANGE(IDC_LIST_EXTERNALDNS, OnSelchangeList)
	ON_EN_CHANGE(IDC_EDIT_TREEID, OnChangeGlobal)	

	//}}AFX_MSG_MAP
	
	ON_BN_CLICKED(IDC_SAML_LOGIN, &DSConnection::OnBnClickedSamlLogin)
	ON_BN_CLICKED(IDC_RADIO_IMANAGE_LOGIN, &DSConnection::OnBnClickedRadioImanageLogin)
	ON_BN_CLICKED(IDC_RADIO_ADFS_LOGIN, &DSConnection::OnBnClickedAdfsLogin)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// DSConnection message handlers

HANDLE hDomainNames = NULL;

BOOL DSConnection::OnInitDialog() 
{
	CDialog::OnInitDialog();

	m_bEnableSSL = false;
	
	// TODO: Add extra initialization here
	CString strCaption;
	strCaption.Format( _T( "DS Synchronization Connection Properties on %s" ), m_strServer );
	SetWindowText( strCaption );

	hDomainNames = CreateEvent( NULL, FALSE, FALSE, NULL );
	isDlgClosed = FALSE;
	AfxBeginThread( DomainNamesThread, ( LPVOID ) this );
	//DomainNamesThread( ( LPVOID ) this );

	PopulateAttributeMapsComboBox( );
	PopulateServerTypesComboBox( );
	PopulateDlgFromConnection( );

	OnSelchangeComboDsServerType( );
	OnSelchangeComboAttributeMaps( );
	OnCheckDefaultMustChangePwd( );

	OnChangeGlobal();
	//OnChangeEditNode( );
	//OnChangeEditDefaultPwd( );
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}


UINT DomainNamesThread( LPVOID pVoid )
{
	DSConnection* pConnection = reinterpret_cast< DSConnection* >( pVoid );
	if( pConnection != NULL )
	{
		CString strDomain = _T( "" );
		pConnection->m_cboNtDomain.GetWindowText( strDomain );

		CString strLoadingMsg = _T( "Loading domains..." );
		//pConnection->m_cboNtDomain.ResetContent( );
		pConnection->m_cboNtDomain.AddString( strLoadingMsg );
		//pConnection->m_cboNtDomain.SelectString( -1, strLoadingMsg );

		DSOM::CNT nt;
		ObjectContainers::CUniqueBstrVector vDomainNames; 
		nt.getDomainNames( vDomainNames );

		if (isDlgClosed)
		{
			return 0;
		}

		pConnection->m_vDomainNames = vDomainNames;

		pConnection->m_cboNtDomain.ResetContent( );

		for( ObjectContainers::CUniqueBstrVector::Const_Iterator iter = pConnection->m_vDomainNames.Begin( ); iter != pConnection->m_vDomainNames.End( ); iter++ )
		{
			if (isDlgClosed)
			{
				return 0;
			}
			_bstr_t strDomain = *iter;
			pConnection->m_cboNtDomain.AddString( strDomain );
		}

		if( strDomain.GetLength() == 0 )
		{
			_bstr_t strCurrentDomain = _T( "" );
			nt.getCurrentDomain( strCurrentDomain );

			pConnection->m_cboNtDomain.SelectString( -1, strCurrentDomain );
		}
		else
			pConnection->m_cboNtDomain.SetWindowText( strDomain );

		SetEvent( hDomainNames );
	}

	return 0;
}

void DSConnection::SetRegistryObjects( IM::CDSSyncSvc* pSyncSvc, IM::CDSSyncSvc_Connection* pConnection )
{
	if( ( pSyncSvc != NULL ) && ( pConnection != NULL ) )
	{
		m_pSyncSvc_Local = pSyncSvc;
		m_pConnection_Local = pConnection;
	}
}

bool DSConnection::UpdateConnectionFromDlg( IM::CDSSyncSvc_Connection* pConnection )
{
	if( m_pSyncSvc_Local == NULL )
		return false;

	CString strName( _T( "" ) ), strNode( _T( "" ) ), strAttributeMapName( _T( "" ) );
	CString strDSTcpip( _T( "" ) ), strDSServer( _T( "" ) ), strDSUser( _T( "" ) ), strDSPassword( _T( "" ) );
	CString strDMSServer( _T( "" ) ), strDMSLibrary( _T( "" ) ), strDMSUser( _T( "" ) ), strDMSPassword( _T( "" ) ), strDMSTcpip( _T( "" ) );
	CString strDefaultPassword( _T( "" ) ), strDefaultPasswordConfirm( _T( "" ) );
	CString strContext( _T( "" ) );
	CString strTreeID( _T( "" ) );
	bool bDefaultPasswordNeverExpires( false ), bDefaultMustChangePassword( false );
	long lDSServiceType( 0 );
	CString strExternalDNList( _T( "" ) );

	lDSServiceType = m_cboDSServerType.GetCurSel( );

	m_edtNameDesc.GetWindowText( strName );


	// DS settings

	if( lDSServiceType == IM::CDSSyncSvc_DSParameters::NT )
	{
		//WaitForSingleObject( hDomainNames, INFINITE );

		// the NT domain is the "DS Server"
		int iCurSel = m_cboNtDomain.GetCurSel( );
		if( iCurSel == -1 )
		{
			m_cboNtDomain.GetWindowText( strDSServer );
		}
		else
		{
			m_cboNtDomain.GetLBText( iCurSel, strDSServer );
		}

		m_edtDsUser.GetWindowText( strDSUser );
		m_edtDsPassword.GetWindowText( strDSPassword );

		CString strDomainUser = strDSServer + _T( "\\" ) + strDSUser;
		//m_pSyncSvc_Local->GrantActAsPartOfOperatingSystemPrivilege( strDomainUser );
		m_pSyncSvc_Local->GrantInteractiveLogonPrivilege( strDomainUser );
	}
	else	// not NT
	{
		m_edtNode.GetWindowText( strNode );

		if( lDSServiceType != IM::CDSSyncSvc_DSParameters::Novell )
		{
			m_cboAttributeMaps.GetWindowText( strAttributeMapName );

			m_edtDsTcpip.GetWindowText( strDSTcpip );
		}
		else // Novell
		{
			m_edtTreeID.GetWindowText( strTreeID );
			m_edtContext.GetWindowText( strContext );

			strAttributeMapName = _T( "" );
			strDSTcpip = _T( "" );
		}
		

		m_edtDsServer.GetWindowText( strDSServer );
		if( m_rdoDSLogin1.GetCheck() )
		{
			// empty values mean "Use Service Login"
			strDSUser = _T( "" );
			strDSPassword = _T( "" );
		}
		else
		{
			m_edtDsUser.GetWindowText( strDSUser );
			m_edtDsPassword.GetWindowText( strDSPassword );
		}
			
	}



	// DMS settings
	
	m_edtDmsServer.GetWindowText( strDMSServer );
	
	m_edtDmsLibrary.GetWindowText( strDMSLibrary );
	
	m_edtDmsUser.GetWindowText( strDMSUser );
	
	m_edtDmsPassword.GetWindowText( strDMSPassword );

	m_edtDmsTcpip.GetWindowText( strDMSTcpip );

	m_edtDefaultPassword.GetWindowText( strDefaultPassword );
	m_edtDefaultPasswordConfirm.GetWindowText( strDefaultPasswordConfirm );

	bDefaultPasswordNeverExpires = m_btnDefaultPasswordNeverExpires.GetCheck( ) ? true : false;
	bDefaultMustChangePassword = m_btnDefaultMustChangePassword.GetCheck( ) ? true : false;
	
	pConnection->m_strName.Set( ( LPCTSTR ) strName );
	pConnection->m_strNode.Set( ( LPCTSTR ) strNode );
	pConnection->m_strAttributeMapName.Set( ( LPCTSTR ) strAttributeMapName );

	pConnection->m_DSParameters.m_lServiceType.Set( lDSServiceType );
	pConnection->m_DSParameters.m_lTcpipPort.Set( ( _ttol( ( LPCTSTR ) strDSTcpip ) ) );
	pConnection->m_DSParameters.m_lEnableSSL.Set(m_bEnableSSL ? 1 : 0);

	pConnection->m_DSParameters.m_strServerName.Set( ( LPCTSTR ) strDSServer );
	pConnection->m_DSParameters.m_strUserId.Set( ( LPCTSTR ) strDSUser );
	pConnection->m_DSParameters.m_strPassword.Set( ( LPCTSTR ) strDSPassword );
	pConnection->m_DSParameters.m_strContext.Set( ( LPCTSTR ) strContext );
	pConnection->m_DSParameters.m_strTreeID.Set( ( LPCTSTR ) strTreeID );

	pConnection->m_DMSParameters.m_strDms.Set( ( LPCTSTR ) strDMSServer );
	pConnection->m_DMSParameters.m_strLibrary.Set( ( LPCTSTR ) strDMSLibrary );
	pConnection->m_DMSParameters.m_strUserId.Set( ( LPCTSTR ) strDMSUser );
	pConnection->m_DMSParameters.m_strPassword.Set( ( LPCTSTR ) strDMSPassword );
	pConnection->m_DMSParameters.m_strDefaultPassword.Set( ( LPCTSTR ) strDefaultPassword );
	pConnection->m_DMSParameters.m_bDefaultPasswordNeverExpires.Set( bDefaultPasswordNeverExpires );
	pConnection->m_DMSParameters.m_bDefaultPasswordMustBeChanged.Set( bDefaultMustChangePassword );

	// External DNs Implementation start	
	if(( lDSServiceType == IM::CDSSyncSvc_DSParameters::Microsoft )||(lDSServiceType == IM::CDSSyncSvc_DSParameters::Sun))
	{
		m_listExternalDNs.EnableWindow(TRUE);
		
		int nCount = m_listExternalDNs.GetCount();
		for(int i =0; i<=nCount-1; ++i)
		{
			CString strLocalExternalDNs;
			m_listExternalDNs.GetText(i, strLocalExternalDNs);
			if (!strLocalExternalDNs.IsEmpty())
				strExternalDNList += _T("%^%") + strLocalExternalDNs;	
		}
		strExternalDNList.TrimLeft (_T("%^%"));
		pConnection->m_strExternalDNList.Set( ( LPCTSTR ) strExternalDNList );	
	}
	else
	{
		m_listExternalDNs.EnableWindow(FALSE);
	}
	//End
	CString csServerURL;
	m_edtServerURL.GetWindowText(csServerURL);
	pConnection->m_DMSParameters.m_strServerURL.Set((LPCTSTR)csServerURL);
	
	if( m_rdoDmsOtherTcpip.GetCheck( ) && ( strDMSTcpip.GetLength( ) > 0 ) )
		pConnection->m_DMSParameters.m_lTcpipPort.Set( ( _ttol( ( LPCTSTR ) strDMSTcpip ) ) );
	else
		pConnection->m_DMSParameters.m_lTcpipPort.Set( 0 );

	if (m_RadioIManageLogin.GetCheck())
		pConnection->m_DMSParameters.m_lLoginType.Set(0);
	else
		pConnection->m_DMSParameters.m_lLoginType.Set(1);

	
	
	
	return true;
}

void DSConnection::OnOK() 
{
	if( !UpdateConnectionFromDlg( m_pConnection_Local ) )
		return;

	if( hDomainNames != NULL )
		CloseHandle( hDomainNames );
	isDlgClosed = TRUE;
	
	CDialog::OnOK();
}

void DSConnection::OnHelp() 
{
	::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, 53);
}

void DSConnection::OnCancel() 
{
	if( hDomainNames != NULL )
		CloseHandle( hDomainNames );
	
	isDlgClosed = TRUE;
	CDialog::OnCancel();
}

void DSConnection::PopulateAttributeMapsComboBox( void )
{
	IM::CDSSyncSvc* pSyncSvc_Local = new IM::CDSSyncSvc(m_strServer);
	pSyncSvc_Local->LoadFromRegistry_AttributeMapsOnly();
	if( pSyncSvc_Local != NULL )
	{
		m_cboAttributeMaps.ResetContent( );

		IM::CDSSyncSvc::ATTRIBUTEMAPLIST::const_iterator iterEnd = pSyncSvc_Local->m_AttributeMapList.end( );
		for( IM::CDSSyncSvc::ATTRIBUTEMAPLIST::const_iterator iter = pSyncSvc_Local->m_AttributeMapList.begin( ); iter != iterEnd; iter++ )
		{
			IM::CDSSyncSvc_AttributeMap* pAttributeMap = *iter;
			CString mapName = pAttributeMap->m_strMapName.Get( ).c_str();
			if(( pAttributeMap != NULL ) && (mapName != ""))
				m_cboAttributeMaps.AddString(pAttributeMap->m_strMapName.Get( ).c_str() );
		}
	}
	delete pSyncSvc_Local;
}

void DSConnection::PopulateServerTypesComboBox( void )
{
	/*
	0 = Microsoft Active Directory
	1 = Sun ONE Server
	2 = Novell NDS
	3 = Windows NT
	*/
}

void DSConnection::PopulateDlgFromConnection( void )
{
	if( m_pConnection_Local != NULL )
	{
		m_OtherConnectionNames.RemoveAll();

		m_bEnableSSL = (m_pConnection_Local->m_DSParameters.m_lEnableSSL.Get() != 0);
		CString strName = m_pConnection_Local->m_strName.Get( ).c_str( );

		IM::CDSSyncSvc::CONNECTIONLIST::const_iterator clIter;
		for( clIter = m_pSyncSvc_Local->m_ConnectionList.begin(); clIter != m_pSyncSvc_Local->m_ConnectionList.end(); clIter++ )
		{
			IM::CDSSyncSvc_Connection* pConn = *clIter;
			if( pConn != m_pConnection_Local )
				m_OtherConnectionNames.AddTail( pConn->m_strName.Get( ).c_str( ) );
		}

		m_edtNameDesc.SetWindowText( m_pConnection_Local->m_strName.Get( ).c_str( ) );
		m_edtNode.SetWindowText( m_pConnection_Local->m_strNode.Get( ).c_str( ) );
		m_cboAttributeMaps.SelectString( -1, m_pConnection_Local->m_strAttributeMapName.Get( ).c_str( ) );

		m_cboDSServerType.SetCurSel( m_pConnection_Local->m_DSParameters.m_lServiceType.Get( ) );

		CString strTcpip;
		strTcpip.Format( _T( "%i" ), m_pConnection_Local->m_DSParameters.m_lTcpipPort.Get( ) );
		m_edtDsTcpip.SetWindowText( strTcpip );

		

		if( m_pConnection_Local->m_DSParameters.m_lServiceType.Get( ) == IM::CDSSyncSvc_DSParameters::NT )
		{
			int ret = m_cboNtDomain.SelectString( -1, m_pConnection_Local->m_DSParameters.m_strServerName.Get( ).c_str( ) );
			if( ret == CB_ERR )
			{
				m_cboNtDomain.SetWindowText( m_pConnection_Local->m_DSParameters.m_strServerName.Get( ).c_str( ) );
			}
		}

		m_edtDsServer.SetWindowText( m_pConnection_Local->m_DSParameters.m_strServerName.Get( ).c_str( ) );
		m_edtDsUser.SetWindowText( m_pConnection_Local->m_DSParameters.m_strUserId.Get( ).c_str( ) );
		m_edtDsPassword.SetWindowText( m_pConnection_Local->m_DSParameters.m_strPassword.Get( ).c_str( ) );
		m_edtContext.SetWindowText( m_pConnection_Local->m_DSParameters.m_strContext.Get( ).c_str( ) );
		m_edtTreeID.SetWindowText( m_pConnection_Local->m_DSParameters.m_strTreeID.Get( ).c_str( ) );

		CString strDsUserId = m_pConnection_Local->m_DSParameters.m_strUserId.Get( ).c_str( );


		// if the DSUser is blank/null
		// then "Use Service Account" will be checked
		if( m_pConnection_Local->m_DSParameters.m_lServiceType.Get( ) == IM::CDSSyncSvc_DSParameters::Microsoft )
		{
			CString user = m_pConnection_Local->m_DSParameters.m_strUserId.Get( ).c_str( );
			if( user.GetLength() == 0 )
			{
				m_rdoDSLogin1.SetCheck(1);
				m_rdoDSLogin2.SetCheck(0);
			}
			else
			{
				m_rdoDSLogin1.SetCheck(0);
				m_rdoDSLogin2.SetCheck(1);
			}
			OnRadioDsLogin();
		}
		else
		{
			m_rdoDSLogin1.SetCheck(0);
			m_rdoDSLogin2.SetCheck(1);
		}

		m_edtDmsServer.SetWindowText( m_pConnection_Local->m_DMSParameters.m_strDms.Get( ).c_str( ) );
		m_edtDmsLibrary.SetWindowText( m_pConnection_Local->m_DMSParameters.m_strLibrary.Get( ).c_str( ) );
		m_edtDmsUser.SetWindowText( m_pConnection_Local->m_DMSParameters.m_strUserId.Get( ).c_str( ) );
		m_edtDmsPassword.SetWindowText( m_pConnection_Local->m_DMSParameters.m_strPassword.Get( ).c_str( ) );
		m_edtDefaultPassword.SetWindowText( m_pConnection_Local->m_DMSParameters.m_strDefaultPassword.Get( ).c_str( ) );
		m_edtDefaultPasswordConfirm.SetWindowText( m_pConnection_Local->m_DMSParameters.m_strDefaultPassword.Get( ).c_str( ) );
		m_btnDefaultPasswordNeverExpires.SetCheck( m_pConnection_Local->m_DMSParameters.m_bDefaultPasswordNeverExpires.Get( ) );
		m_btnDefaultMustChangePassword.SetCheck( m_pConnection_Local->m_DMSParameters.m_bDefaultPasswordMustBeChanged.Get( ) );

		// External DNs implementation
		if(( m_pConnection_Local->m_DSParameters.m_lServiceType.Get( ) == IM::CDSSyncSvc_DSParameters::Microsoft )||(m_pConnection_Local->m_DSParameters.m_lServiceType.Get( ) == IM::CDSSyncSvc_DSParameters::Sun))
		{
			m_listExternalDNs.EnableWindow(TRUE);
			CString originalString = m_pConnection_Local->m_strExternalDNList.Get( ).c_str( );
			TCHAR* delimiters = _T("%^%");
			TCHAR * token = _tcstok(originalString.GetBuffer(originalString.GetLength()), delimiters);
			int i =0;
			while (token != NULL)
			{	
				m_listExternalDNs.InsertString(i, token);
				token = _tcstok(NULL, delimiters);
				i++;
			}
		}
		else
		{
			m_listExternalDNs.EnableWindow(FALSE);
		}
		//end


		if( m_pConnection_Local->m_DSParameters.m_lServiceType.Get( ) == IM::CDSSyncSvc_DSParameters::Novell )
		{
			m_cboAttributeMaps.EnableWindow( FALSE );
			m_btnAdd.EnableWindow( FALSE );
			m_btnDelete.EnableWindow( FALSE );
			m_btnEdit.EnableWindow( FALSE );

			m_edtDsTcpip.EnableWindow( FALSE );
			m_edtDsTcpip.SetWindowText( _T( "" ) );
		}
		else if( m_pConnection_Local->m_DSParameters.m_lServiceType.Get( ) == IM::CDSSyncSvc_DSParameters::NT )
		{
			m_cboAttributeMaps.EnableWindow( FALSE );
			m_btnAdd.EnableWindow( FALSE );
			m_btnDelete.EnableWindow( FALSE );
			m_btnEdit.EnableWindow( FALSE );
		}
		else
		{
			m_cboAttributeMaps.EnableWindow( TRUE );
			m_btnAdd.EnableWindow( TRUE );

			long lAttributeMap = m_cboAttributeMaps.GetCurSel( );
			bool bEnable = lAttributeMap != -1;

			m_btnDelete.EnableWindow( bEnable );
			m_btnEdit.EnableWindow( bEnable );

			m_edtDsTcpip.EnableWindow( TRUE );
		}

		


		
		if( m_pConnection_Local->m_DMSParameters.m_lTcpipPort.Get( ) == 0 )
		{
			m_rdoDmsTcpip.SetCheck( TRUE );
			m_rdoDmsOtherTcpip.SetCheck( FALSE );
			m_edtDmsTcpip.SetWindowText( _T( "" ) );
			m_edtDmsTcpip.EnableWindow( FALSE );
		}
		else
		{
			strTcpip.Format( _T( "%i" ), m_pConnection_Local->m_DMSParameters.m_lTcpipPort.Get( ) );

			m_rdoDmsTcpip.SetCheck( FALSE );
			m_rdoDmsOtherTcpip.SetCheck( TRUE );
			m_edtDmsTcpip.SetWindowText( strTcpip );
			m_edtDmsTcpip.EnableWindow( TRUE );
		}

		m_edtServerURL.SetWindowText(m_pConnection_Local->m_DMSParameters.m_strServerURL.Get().c_str());
		if (m_pConnection_Local->m_DMSParameters.m_lLoginType.Get() == 0)
		{
			m_RadioIManageLogin.SetCheck(1);
			m_RadioAdfsLogin.SetCheck(0);
			OnBnClickedRadioImanageLogin();

		}
		else
		{
			m_RadioIManageLogin.SetCheck(0);
			m_RadioAdfsLogin.SetCheck(1);
			OnBnClickedAdfsLogin();
		}
		OnChangeGlobal();
	}
}

void DSConnection::UpdateRegistryPath( IM::CDSSyncSvc_AttributeMap* pAttributeMap )
{
	if( pAttributeMap != NULL )
	{
		// hard-coded value from Registry/ServiceEx.cpp
		// #define KEY_DSSYNCSVC_ATTRIBUTEMAPS		_T( "\\Attribute Maps" )
		_bstr_t newPath = m_pSyncSvc_Local->GetBaseKeyPath( ).c_str( );
		newPath +=  _T( "\\Attribute Maps\\" );
		newPath += pAttributeMap->m_strMapName.Get( ).c_str( );
		pAttributeMap->SetPath( newPath );
	}
}
void DSConnection::UpdateAttributeMap(IM::CDSSyncSvc_AttributeMap* pAttributeMapLocal, IM::CDSSyncSvc_AttributeMap* pAttributeMap)
{
	pAttributeMapLocal->m_strMapName.Set(pAttributeMap->m_strMapName.Get( ).c_str( ));
	pAttributeMapLocal->m_strOUName.Set( pAttributeMap->m_strOUName.Get( ).c_str( ));
	pAttributeMapLocal->m_strUserName.Set( pAttributeMap->m_strUserName.Get( ).c_str( ));
	pAttributeMapLocal->m_strUserId.Set( pAttributeMap->m_strUserId.Get( ).c_str( ));
	pAttributeMapLocal->m_strUserEmail.Set(pAttributeMap->m_strUserEmail.Get( ).c_str( ));
	pAttributeMapLocal->m_strUserFax.Set(pAttributeMap->m_strUserFax.Get( ).c_str( ));
	pAttributeMapLocal->m_strUserTelephone.Set(pAttributeMap->m_strUserTelephone.Get( ).c_str( ));
	pAttributeMapLocal->m_strUserLocation.Set( pAttributeMap->m_strUserLocation.Get( ).c_str( ));
	pAttributeMapLocal->m_strUserEnabled.Set(pAttributeMap->m_strUserEnabled.Get( ).c_str( ));
	pAttributeMapLocal->m_strGroupName.Set(pAttributeMap->m_strGroupName.Get( ).c_str( ));
	pAttributeMapLocal->m_strGroupId.Set(pAttributeMap->m_strGroupId.Get( ).c_str( ));
	pAttributeMapLocal->m_strGroupMember.Set( pAttributeMap->m_strGroupMember.Get( ).c_str( ));
	pAttributeMapLocal->m_strK1SyncId.Set(pAttributeMap->m_strK1SyncId.Get( ).c_str( ));
}

void DSConnection::OnButtonAdd() 
{
	IM::CDSSyncSvc* pSyncSvc_Temp = new IM::CDSSyncSvc(m_strServer);
	IM::CDSSyncSvc* pSyncSvc_Local = new IM::CDSSyncSvc(m_strServer);
	pSyncSvc_Local->LoadFromRegistry_AttributeMapsOnly();

	if( pSyncSvc_Local != NULL )
	{
		IM::CDSSyncSvc_AttributeMap* pAttributeMap = new IM::CDSSyncSvc_AttributeMap( pSyncSvc_Local->GetComputerName( ).c_str( ), pSyncSvc_Local->GetDesiredHive( ), pSyncSvc_Local->GetBaseKeyPath( ).c_str( ) );	

		DSAttributeMap dlg( this );
		dlg.m_strServer = m_strServer;
		dlg.m_Mode = DSAttributeMap::Add;
		dlg.SetRegistryObjects( pSyncSvc_Local, pAttributeMap );
		if( dlg.DoModal( ) == IDOK )
		{
			UpdateRegistryPath( pAttributeMap );
			pSyncSvc_Temp->AddAttributeMap( pAttributeMap );
			pSyncSvc_Temp->StoreInRegistry_AttributeMapsOnly();

			m_cboAttributeMaps.AddString( pAttributeMap->m_strMapName.Get( ).c_str( ));
			m_cboAttributeMaps.SelectString( -1, pAttributeMap->m_strMapName.Get( ).c_str( ) );
			OnSelchangeComboAttributeMaps();
		}
		else
		{
			delete pAttributeMap;
		}
	}
	delete pSyncSvc_Temp;
	delete pSyncSvc_Local;
}

void DSConnection::OnButtonEdit() 
{	
	int nIndex = m_cboAttributeMaps.GetCurSel();
	CString strSelectedText ;
	m_cboAttributeMaps.GetLBText( nIndex, strSelectedText);

	if(strSelectedText != "")
	{
		IM::CDSSyncSvc* pSyncSvc_Temp = new IM::CDSSyncSvc(m_strServer);
		IM::CDSSyncSvc* pSyncSvc_Local = new IM::CDSSyncSvc(m_strServer);
		pSyncSvc_Local->LoadFromRegistry_AttributeMapsOnly();

		if( pSyncSvc_Local != NULL )
		{
			IM::CDSSyncSvc_AttributeMap* pAttributeMapBefore = new IM::CDSSyncSvc_AttributeMap( pSyncSvc_Local->GetComputerName( ).c_str( ), pSyncSvc_Local->GetDesiredHive( ), pSyncSvc_Local->GetBaseKeyPath( ).c_str( ) );	
			IM::CDSSyncSvc_AttributeMap* pAttributeMapAfter = new IM::CDSSyncSvc_AttributeMap( pSyncSvc_Local->GetComputerName( ).c_str( ), pSyncSvc_Local->GetDesiredHive( ), pSyncSvc_Local->GetBaseKeyPath( ).c_str( ) );	
			IM::CDSSyncSvc_AttributeMap* pAttributeMap = pSyncSvc_Local->FindAttributeMap(strSelectedText);
			
			UpdateAttributeMap(pAttributeMapBefore,pAttributeMap);

			if( pAttributeMap != NULL )
			{
				DSAttributeMap dlg( this );
				dlg.m_strServer = m_strServer;
				dlg.m_Mode = DSAttributeMap::Edit;
				dlg.SetRegistryObjects( pSyncSvc_Local, pAttributeMap );
				if( dlg.DoModal( ) == IDOK )
				{
					UpdateRegistryPath( pAttributeMapBefore);
					pSyncSvc_Temp->AddAttributeMap( pAttributeMapBefore );
					pSyncSvc_Temp->DeleteFromRegistry_AttributeMapsOnly();
					pSyncSvc_Temp->Clear();
					
					UpdateAttributeMap(pAttributeMapAfter,pAttributeMap);
					CString mapName = pAttributeMap->m_strMapName.Get( ).c_str( );
					UpdateRegistryPath( pAttributeMapAfter );
					pSyncSvc_Temp->AddAttributeMap( pAttributeMapAfter );
					pSyncSvc_Temp->StoreInRegistry_AttributeMapsOnly();
					
					PopulateAttributeMapsComboBox( );
					m_cboAttributeMaps.SelectString( -1, mapName);
					OnSelchangeComboAttributeMaps();
				}
			}
		}
		delete pSyncSvc_Temp;
		delete pSyncSvc_Local;				
	}	
}

void DSConnection::OnButtonDelete() 
{
	int nIndex = m_cboAttributeMaps.GetCurSel();
	CString strSelectedText ;
	m_cboAttributeMaps.GetLBText( nIndex, strSelectedText);

	if(strSelectedText != "")
	{
		IM::CDSSyncSvc* pSyncSvc_Temp = new IM::CDSSyncSvc(m_strServer);
		IM::CDSSyncSvc* pSyncSvc_Local = new IM::CDSSyncSvc(m_strServer);
		pSyncSvc_Local->LoadFromRegistry_AttributeMapsOnly();

		if( pSyncSvc_Local != NULL )
		{
			IM::CDSSyncSvc_AttributeMap* pAttributeMapLocal = new IM::CDSSyncSvc_AttributeMap( pSyncSvc_Local->GetComputerName( ).c_str( ), pSyncSvc_Local->GetDesiredHive( ), pSyncSvc_Local->GetBaseKeyPath( ).c_str( ) );	
			IM::CDSSyncSvc_AttributeMap* pAttributeMap = pSyncSvc_Local->FindAttributeMap(strSelectedText);
			
			UpdateAttributeMap(pAttributeMapLocal,pAttributeMap);
			pSyncSvc_Temp->AddAttributeMap( pAttributeMapLocal );
			pSyncSvc_Temp->DeleteFromRegistry_AttributeMapsOnly();
			
			PopulateAttributeMapsComboBox( );
			OnSelchangeComboAttributeMaps();
		}
		delete pSyncSvc_Temp;
		delete pSyncSvc_Local;		
	}	
}

void DSConnection::OnButtonBrowse() 
{
	IM::CDSSyncSvc* pSyncSvc_Local = new IM::CDSSyncSvc(m_strServer);
	pSyncSvc_Local->LoadFromRegistry();
	IM::CDSSyncSvc_Connection* pConnection = new IM::CDSSyncSvc_Connection( pSyncSvc_Local->GetComputerName( ).c_str( ), pSyncSvc_Local->GetDesiredHive( ), pSyncSvc_Local->GetBaseKeyPath( ).c_str( ) );
	if( UpdateConnectionFromDlg( pConnection ) )
	{
		DSNode2 dlg( this );
		dlg.m_strServer = m_strServer;
		dlg.SetRegistryObjects( pSyncSvc_Local, pConnection );
		if( dlg.DoModal( ) == IDOK )
		{
			m_edtNode.SetWindowText( dlg.m_strNode );
		}
	}

	delete pConnection;
}

void DSConnection::OnRadioDmsDefaultPort() 
{
	m_edtDmsTcpip.EnableWindow( FALSE );
	OnChangeGlobal();
}

void DSConnection::OnRadioDmsOtherPort() 
{
	m_edtDmsTcpip.EnableWindow( TRUE );
	OnChangeGlobal();
}

void DSConnection::OnSelchangeComboAttributeMaps() 
{
	long lAttributeMap = m_cboAttributeMaps.GetCurSel( );
	bool bEnable = lAttributeMap != -1;

	m_btnDelete.EnableWindow( bEnable );
	m_btnEdit.EnableWindow( bEnable );

	OnChangeGlobal();
}

void DSConnection::EnableConnectionControls( )
{
	int iServerType = m_cboDSServerType.GetCurSel( );

	bool bADS = iServerType == 0;
	bool bSunONE = iServerType == 1;
	bool bNovell = iServerType == 2;
	bool bNT = iServerType == 3;
	
	m_edtDsServer.ShowWindow( !bNT ? SW_SHOW : SW_HIDE );
	m_cboNtDomain.ShowWindow( !bNT ? SW_HIDE : SW_SHOW );
	m_edtDsServer.UpdateWindow( );
	m_cboNtDomain.UpdateWindow( );
	m_edtDsTcpip.EnableWindow( !bNT );

	m_stcLabelContext.ShowWindow( bNovell ? SW_SHOW : SW_HIDE );
	m_edtContext.ShowWindow( bNovell ? SW_SHOW : SW_HIDE );
	m_stcLabelBlank.ShowWindow( bADS || bSunONE ? SW_SHOW : SW_HIDE );

	//if( !bNT )
	//	m_edtDsTcpip.SetWindowText( _T( "" ) );

	m_cboAttributeMaps.EnableWindow( !bNT && !bNovell );
	m_btnAdd.EnableWindow( !bNT && !bNovell );

	long lAttributeMap = m_cboAttributeMaps.GetCurSel( );
	bool bSelectedAttributeMap = lAttributeMap != -1;

	m_btnDelete.EnableWindow( !bNT && !bNovell && bSelectedAttributeMap );
	m_btnEdit.EnableWindow( !bNT && !bNovell && bSelectedAttributeMap );

	m_edtNode.EnableWindow( !bNT );
	m_btnBrowse.EnableWindow( !bNT );
	//m_btnTest.EnableWindow( !bNT );
	m_btnTest.EnableWindow( TRUE );
	m_listExternalDNs.EnableWindow( !bNT && !bNovell);
	m_stcLabelTreeID.EnableWindow(!bNT && !bSunONE && !bADS);
	m_edtTreeID.EnableWindow(!bNT && !bSunONE&& !bADS );

}


void DSConnection::OnSelchangeComboDsServerType() 
{
	long lDSServiceType = m_cboDSServerType.GetCurSel( );

	EnableConnectionControls( );	

	//OnChangeEditNode( );
	//OnChangeEditDefaultPwd( );

	if( lDSServiceType == IM::CDSSyncSvc_DSParameters::NT )
	{
		DSOM::CNT nt;

		int iCurSel = m_cboNtDomain.GetCurSel();
		if( iCurSel == -1 )
		{
			CString strDomain = _T( "" );
			m_cboNtDomain.GetWindowText( strDomain );
			if( strDomain.GetLength() == 0 )
			{
				_bstr_t strCurrentDomain = _T( "" );
				nt.getCurrentDomain( strCurrentDomain );
				int ret = m_cboNtDomain.SelectString( -1, strCurrentDomain );
				if( ret == CB_ERR )
				{
					m_cboNtDomain.SetWindowText( ( LPCTSTR ) strCurrentDomain );
				}
			}
		}

		m_edtDsTcpip.EnableWindow( FALSE );
		m_edtDsTcpip.SetWindowText( _T( "" ) );

		m_edtDsUser.SetWindowText( m_pConnection_Local->m_DSParameters.m_strUserId.Get( ).c_str( ) );
		m_edtDsPassword.SetWindowText( m_pConnection_Local->m_DSParameters.m_strPassword.Get( ).c_str( ) );

		m_edtDsUser.EnableWindow(TRUE);
		m_edtDsPassword.EnableWindow(TRUE);
	}
	else if( lDSServiceType == IM::CDSSyncSvc_DSParameters::Novell )
	{
		m_cboAttributeMaps.EnableWindow( FALSE );
		m_edtDsTcpip.EnableWindow( FALSE );
		m_edtDsTcpip.SetWindowText( _T( "" ) );

		m_edtDsUser.SetWindowText( m_pConnection_Local->m_DSParameters.m_strUserId.Get( ).c_str( ) );
		m_edtDsPassword.SetWindowText( m_pConnection_Local->m_DSParameters.m_strPassword.Get( ).c_str( ) );

		m_edtDsUser.EnableWindow(TRUE);
		m_edtDsPassword.EnableWindow(TRUE);
	}
	else if( lDSServiceType == IM::CDSSyncSvc_DSParameters::Microsoft )
	{
		m_cboAttributeMaps.EnableWindow( TRUE );
		m_edtDsTcpip.EnableWindow( TRUE );

		if( m_pConnection_Local->m_DSParameters.m_lServiceType.Get( ) == IM::CDSSyncSvc_DSParameters::Microsoft )
		{
			CString strTcpip;
			strTcpip.Format( _T( "%i" ), m_pConnection_Local->m_DSParameters.m_lTcpipPort.Get( ) );
			m_edtDsTcpip.SetWindowText( strTcpip );
		}
		else
			m_edtDsTcpip.SetWindowText( _T( "389" ) );

		SetADSCredentials( m_rdoDSLogin1.GetCheck() == 1 );
	}
	else //if( lDSServiceType == IM::CDSSyncSvc_DSParameters::Netscape )
	{
		m_cboAttributeMaps.EnableWindow( TRUE );
		m_edtDsTcpip.EnableWindow( TRUE );

		if( m_pConnection_Local->m_DSParameters.m_lServiceType.Get( ) == IM::CDSSyncSvc_DSParameters::Sun )
		{
			CString strTcpip;
			strTcpip.Format( _T( "%i" ), m_pConnection_Local->m_DSParameters.m_lTcpipPort.Get( ) );
			m_edtDsTcpip.SetWindowText( strTcpip );
		}
		else
			m_edtDsTcpip.SetWindowText( _T( "" ) );

		m_edtDsUser.SetWindowText( m_pConnection_Local->m_DSParameters.m_strUserId.Get( ).c_str( ) );
		m_edtDsPassword.SetWindowText( m_pConnection_Local->m_DSParameters.m_strPassword.Get( ).c_str( ) );
		m_edtDsUser.EnableWindow(TRUE);
		m_edtDsPassword.EnableWindow(TRUE);
	}

	OnChangeGlobal();
}


void DSConnection::OnEditchangeComboNtDomain() 
{
	OnChangeGlobal();
}


void DSConnection::OnCheckDefaultMustChangePwd() 
{
	bool bChecked1 = m_btnDefaultMustChangePassword.GetCheck() ? true : false;
	bool bChecked2 = m_btnDefaultPasswordNeverExpires.GetCheck() ? true : false;

	if( !bChecked1 && !bChecked2 )
	{
		m_btnDefaultMustChangePassword.EnableWindow( TRUE );
		m_btnDefaultPasswordNeverExpires.EnableWindow( TRUE );
	}
	else
	{
		if( bChecked1 )
		{
			m_btnDefaultMustChangePassword.EnableWindow( TRUE );
			m_btnDefaultPasswordNeverExpires.EnableWindow( FALSE );
		}
		else // bChecked2
		{
			m_btnDefaultMustChangePassword.EnableWindow( FALSE );
			m_btnDefaultPasswordNeverExpires.EnableWindow( TRUE );
		}
	}

	OnChangeGlobal();
}


void DSConnection::OnButtonTestLogin() 
{
	if( TestLdapLogin() )
	{
		//AfxMessageBox( _T( "Login Successful." ) );
	}
	else
	{
		//AfxMessageBox( _T( "Login Failed." ) );
	}
}

bool DSConnection::TestLdapLogin() 
{
	IM::CDSSyncSvc* pSyncSvc_Local = new IM::CDSSyncSvc(m_strServer);
	pSyncSvc_Local->LoadFromRegistry();
	IM::CDSSyncSvc_Connection* pConnection = new IM::CDSSyncSvc_Connection( pSyncSvc_Local->GetComputerName( ).c_str( ), pSyncSvc_Local->GetDesiredHive( ), pSyncSvc_Local->GetBaseKeyPath( ).c_str( ) );
	if( UpdateConnectionFromDlg( pConnection ) )
	{
	}

	if( ( pSyncSvc_Local == NULL ) || ( pConnection == NULL ) )
		return false;

	bool retval = true;
	DSOM::CDSGeneric* m_pDSGeneric;

	// look up attribute map
	IM::CDSSyncSvc_AttributeMap* pAttributeMap_Local = NULL;
	pAttributeMap_Local = pSyncSvc_Local->FindAttributeMap( pConnection->m_strAttributeMapName.Get( ).c_str( ) );

	IM::CDSSyncSvc_DSParameters::LDAPTYPE ldapType = ( IM::CDSSyncSvc_DSParameters::LDAPTYPE ) pConnection->m_DSParameters.m_lServiceType.Get( );
	switch( ldapType )
	{
	case IM::CDSSyncSvc_DSParameters::Microsoft:
	case IM::CDSSyncSvc_DSParameters::Sun:
		m_pDSGeneric = new DSOM::CDSSyncInterface( pSyncSvc_Local, pConnection, pAttributeMap_Local );
		break;
	case IM::CDSSyncSvc_DSParameters::Novell:
		m_pDSGeneric = new DSOM::CNDSSyncInterface( pConnection, pAttributeMap_Local );
		break;
	case IM::CDSSyncSvc_DSParameters::NT:
		{
			/*
			CString strDomainUser = pConnection->m_DSParameters.m_strServerName.Get().c_str();
			strDomainUser += _T( "\\" );
			strDomainUser += pConnection->m_DSParameters.m_strUserId.Get().c_str();
			m_pSyncSvc_Local->GrantActAsPartOfOperatingSystemPrivilege( strDomainUser );
			m_pSyncSvc_Local->GrantInteractiveLogonPrivilege( strDomainUser );
			*/

			m_pDSGeneric = new DSOM::CNTSyncInterface( pConnection, pAttributeMap_Local );

		}
		break;
	}

	_bstr_t strErrMsg = _T( "" );
	int iRet = DSOM_SUCCESS;
	try
	{
		iRet = m_pDSGeneric->Login( );
	}

	catch( DSOM::CGenericException& e )
	{
		strErrMsg = e.GetErrorString();
		iRet = DSOM_FAILURE;
	}
	catch( DSOM::CLdapException& e )
	{
		strErrMsg = e.GetErrorString();
		iRet = DSOM_FAILURE;
	}
	catch( DSOM::CCppException& e )
	{
		strErrMsg = e.GetErrorString();
		iRet = DSOM_FAILURE;
	}
	catch(imstd::exception e)
	{
		strErrMsg = e.what();
		iRet = DSOM_FAILURE;
	}
	catch(long lErrorCode)
	{
		lErrorCode;
		iRet = DSOM_FAILURE;
	}
	catch( ... )
	{
		iRet = DSOM_FAILURE;
	}

	if( iRet != DSOM_SUCCESS )
	{
		retval = false;

		if( ldapType == IM::CDSSyncSvc_DSParameters::Novell )
		{
			DSOM::CNDSSyncInterface* base = dynamic_cast< DSOM::CNDSSyncInterface* >( m_pDSGeneric );
			if( base->GetNDSInterface()->m_bUsingExistingConnection )
			{
				_bstr_t existingUserId = base->GetNDSInterface()->m_szExistingUser;
				_bstr_t msg = "Login failed: User '";
				msg += existingUserId;
				msg += "' already authenticated.";
				AfxMessageBox( msg );
			}
			else
			{
				if( strErrMsg.length() > 0 )
				{
					_bstr_t msg = _T( "Login failed. " );
					msg += strErrMsg;
					AfxMessageBox( strErrMsg );
				}
				else
					AfxMessageBox( _T( "Login Failed." ) );
			}
		}
		else
		{
			if( strErrMsg.length() > 0 )
			{
				_bstr_t msg = _T( "Login failed. " );
				msg += strErrMsg;
				AfxMessageBox( strErrMsg );
			}
			else
				AfxMessageBox( _T( "Login Failed." ) );
		}
	}
	else
	{
		if( ldapType == IM::CDSSyncSvc_DSParameters::Novell )
		{
			DSOM::CNDSSyncInterface* base = dynamic_cast< DSOM::CNDSSyncInterface* >( m_pDSGeneric );
			if( base->GetNDSInterface()->m_bUsingExistingConnection )
			{
				AfxMessageBox( _T( "Login successful; specified credentials already authenticated." ) );
			}
			else
				AfxMessageBox( _T( "Login Successful." ) );
		}
		else
		{
			AfxMessageBox( _T( "Login Successful." ) );
		}

		if( ldapType != IM::CDSSyncSvc_DSParameters::NT )
		{
			CString strCurrentDn;
			m_edtNode.GetWindowText( strCurrentDn );

			if( ( strCurrentDn.GetLength() == 0 ) && ( ldapType != IM::CDSSyncSvc_DSParameters::Novell ) )
			{
				DSOM::CDSSyncInterface* base = dynamic_cast< DSOM::CDSSyncInterface* >( m_pDSGeneric );
				_bstr_t dn = _T( "" );
				base->GetDSInterface()->GetDefaultNamingContext( dn );
				strCurrentDn = (LPCTSTR)dn;
				m_edtNode.SetWindowText( strCurrentDn );
			}
			else if( ldapType == IM::CDSSyncSvc_DSParameters::Novell )
			{
				DSOM::CNDSSyncInterface* base = dynamic_cast< DSOM::CNDSSyncInterface* >( m_pDSGeneric );
				strCurrentDn = ( LPCTSTR ) base->GetNDSInterface()->GetDefaultNamingContext();
				m_edtNode.SetWindowText( strCurrentDn );
			}
		}
	}

	if( m_pDSGeneric != NULL )
	{
		m_pDSGeneric->Logout( );

		delete m_pDSGeneric;
		m_pDSGeneric = NULL;
	}

	delete pConnection;
	delete pSyncSvc_Local;

	return retval;
}

void DSConnection::SetADSCredentials( bool bUseServiceLogin )
{
	if( bUseServiceLogin )
	{
		static bool bInit = false;
		static IM::NrString user;
		static IM::NrString pwd;
		static bool bAuto;
		if( !bInit )
		{
			m_pSyncSvc_Local->GetServiceConfiguration( user, pwd, bAuto );
			bInit = true;
		}

		m_edtDsUser.SetWindowText( user.c_str() );
		m_edtDsPassword.SetWindowText( pwd.c_str() );

		m_edtDsUser.EnableWindow( FALSE );
		m_edtDsPassword.EnableWindow( FALSE );
	}
	else
	{
		m_edtDsUser.SetWindowText( m_pConnection_Local->m_DSParameters.m_strUserId.Get( ).c_str( ) );
		m_edtDsPassword.SetWindowText( m_pConnection_Local->m_DSParameters.m_strPassword.Get( ).c_str( ) );

		m_edtDsUser.EnableWindow(TRUE);
		m_edtDsPassword.EnableWindow(TRUE);
	}
}

void DSConnection::OnRadioDsLogin()
{
	SetADSCredentials( m_rdoDSLogin1.GetCheck() == 1 );
}


void DSConnection::OnChangeGlobal() 
{
	bool bEnableOKButton = true;
	bool bEnableTestButton = true;
	bool bEnableBrowseButton = true;

	CString strName( _T( "" ) ), strNode( _T( "" ) ), strAttributeMapName( _T( "" ) );
	CString strDSTcpip( _T( "" ) ), strDSServer( _T( "" ) ), strDSUser( _T( "" ) ), strDSPassword( _T( "" ) );
	CString strDMSServer( _T( "" ) ), strDMSLibrary( _T( "" ) ), strDMSUser( _T( "" ) ), strDMSPassword( _T( "" ) ), strDMSTcpip( _T( "" ) );
	CString strDefaultPassword( _T( "" ) ), strDefaultPasswordConfirm( _T( "" ) );
	CString strContext( _T( "" ) );
	CString strTreeID( _T( "" ) );
	bool bDefaultPasswordNeverExpires( false ), bDefaultMustChangePassword( false );
	long lDSServiceType( 0 );

	lDSServiceType = m_cboDSServerType.GetCurSel( );

	m_edtNameDesc.GetWindowText( strName );
	if( strName.GetLength( ) == 0 )
		bEnableOKButton = false;

	if( m_Mode == Add )
	{
		if( m_pSyncSvc_Local->ConnectionExists( strName ) )
			bEnableOKButton = false;
	}
	else if( m_Mode == Edit )
	{
		// if any other connection has this name
		// besides this one (before editing)
		// then don't allow

		POSITION pos = m_OtherConnectionNames.Find( strName );
		if( pos != NULL )
			bEnableOKButton = false;
	}

	// DS settings
	m_edtDsUser.GetWindowText( strDSUser );
	m_edtDsPassword.GetWindowText( strDSPassword );

	if( lDSServiceType == IM::CDSSyncSvc_DSParameters::NT )
	{
		// the NT domain is the "DS Server"
		int iCurSel = m_cboNtDomain.GetCurSel( );
		if( iCurSel == -1 )
		{
			m_cboNtDomain.GetWindowText( strDSServer );
			if( strDSServer.GetLength() == 0 )
				bEnableOKButton = false;
		}
		else
		{
			m_cboNtDomain.GetLBText( iCurSel, strDSServer );

			if( strDSServer == _T( "Loading domains..." ) )
				bEnableOKButton = false;
		}

		bEnableTestButton = true;
		bEnableBrowseButton = false;

		if( strDSUser.GetLength( ) == 0 )
		{
			bEnableOKButton = false;
			bEnableTestButton = false;
			bEnableBrowseButton = false;
		}
	}
	else	// not NT
	{
		m_edtNode.GetWindowText( strNode );
		if( strNode.GetLength( ) == 0 )
		{
			bEnableOKButton = false;
		}

		if( lDSServiceType != IM::CDSSyncSvc_DSParameters::Novell )
		{
			m_cboAttributeMaps.GetWindowText( strAttributeMapName );
			if( strAttributeMapName.GetLength( ) == 0 )
			{
				bEnableOKButton = false;
				bEnableTestButton = false;
				bEnableBrowseButton = false;
			}

			/*
			m_edtDsTcpip.GetWindowText( strDSTcpip );
			if( strDSTcpip.GetLength( ) == 0 )
			{
				// these were false before; but now we want
				// to let the user leave this blank
				// BLANK means default (GC first, then LDAP port)
				// Non-blank means that port will always be used
				bEnableOKButton = true;
				bEnableTestButton = true;
				bEnableBrowseButton = true;
			}
			*/
		}
		else // Novell
		{
			m_edtContext.GetWindowText( strContext );
			if( strContext.GetLength() == 0 )
			{
				bEnableOKButton = false;
				bEnableTestButton = false;
				bEnableBrowseButton = false;
			}
			m_edtTreeID.GetWindowText( strTreeID );
			if( strTreeID.GetLength() == 0 )
			{
				bEnableOKButton = false;
				bEnableTestButton = false;
				bEnableBrowseButton = false;
			}

			strAttributeMapName = _T( "" );
			strDSTcpip = _T( "" );
		}
		
		m_edtDsServer.GetWindowText( strDSServer );
		if( strDSServer.GetLength( ) == 0 )
		{
			bEnableOKButton = false;
			bEnableTestButton = false;
			bEnableBrowseButton = false;
		}
		
		if( strDSUser.GetLength( ) == 0 )
		{
			bEnableOKButton = false;
			bEnableTestButton = false;
			bEnableBrowseButton = false;
		}
		
	}

	if( lDSServiceType == IM::CDSSyncSvc_DSParameters::Microsoft )
	{
		m_rdoDSLogin1.EnableWindow( TRUE );
		m_rdoDSLogin2.EnableWindow( TRUE );
	}
	else
	{
		m_rdoDSLogin1.EnableWindow( FALSE );
		m_rdoDSLogin2.EnableWindow( TRUE );
		m_rdoDSLogin1.SetCheck(0);
		m_rdoDSLogin2.SetCheck(1);

		//if( _tcsicmp( strDSUser, m_pConnection_Local->m_DSParameters.m_strUserId.Get( ).c_str( ) ) != 0 )
		//	m_edtDsUser.SetWindowText( m_pConnection_Local->m_DSParameters.m_strUserId.Get( ).c_str( ) );

		//if( _tcscmp( strDSPassword, m_pConnection_Local->m_DSParameters.m_strPassword.Get( ).c_str( ) ) != 0 )
		//	m_edtDsPassword.SetWindowText( m_pConnection_Local->m_DSParameters.m_strPassword.Get( ).c_str( ) );
	}


	// DMS settings
	
	m_edtDmsServer.GetWindowText( strDMSServer );
	if( strDMSServer.GetLength( ) == 0 )
	{
		bEnableOKButton = false;
	}
	
	m_edtDmsLibrary.GetWindowText( strDMSLibrary );
	if( strDMSLibrary.GetLength( ) == 0 )
	{
		bEnableOKButton = false;
	}
	
	m_edtDmsUser.GetWindowText( strDMSUser );
	if( strDMSUser.GetLength( ) == 0 )
	{
		bEnableOKButton = false;
	}
		
	m_edtDmsPassword.GetWindowText( strDMSPassword );

	m_edtDmsTcpip.GetWindowText( strDMSTcpip );
	if( m_rdoDmsOtherTcpip.GetCheck( ) && ( strDMSTcpip.GetLength( ) == 0 ) )
	{
		bEnableOKButton = false;
	}

	m_edtDefaultPassword.GetWindowText( strDefaultPassword );
	m_edtDefaultPasswordConfirm.GetWindowText( strDefaultPasswordConfirm );
	if( ( strDefaultPassword.GetLength( ) == 0 ) || ( strDefaultPasswordConfirm.GetLength( ) == 0 ) || ( strDefaultPassword != strDefaultPasswordConfirm ) )
	{
		m_stcPasswordMatch.ShowWindow( SW_HIDE );
		m_stcPasswordMatchNot.ShowWindow( SW_SHOW );

		bEnableOKButton = false;
	}
	else if( strDefaultPassword == strDefaultPasswordConfirm )
	{
		m_stcPasswordMatch.ShowWindow( SW_SHOW );
		m_stcPasswordMatchNot.ShowWindow( SW_HIDE );
	}
	else
	{
		m_stcPasswordMatch.ShowWindow( SW_HIDE );
		m_stcPasswordMatchNot.ShowWindow( SW_SHOW );
	}

	m_edtDefaultPasswordConfirm.EnableWindow( strDefaultPassword.GetLength( ) > 0 );

	bDefaultPasswordNeverExpires = m_btnDefaultPasswordNeverExpires.GetCheck( ) ? true : false;
	bDefaultMustChangePassword = m_btnDefaultMustChangePassword.GetCheck( ) ? true : false;

	m_btnOk.EnableWindow( bEnableOKButton ? TRUE : FALSE );
	m_btnBrowse.EnableWindow( bEnableBrowseButton ? TRUE : FALSE );
	m_btnTest.EnableWindow( bEnableTestButton ? TRUE : FALSE );
}

void DSConnection::OnSelchangeList()
{
	m_listExternalDNs.EndEdit();
} 




void DSConnection::WriteToTextFile(BSTR bstrToken)
{
	CStdioFile file;
	try
	{
		EncryptedString eString(ENCRYPT_KEY);
		IM::NrString			strEncryptedString;

		eString.Encrypt(bstrToken, strEncryptedString);

		CString specialPath = _T("");
		TCHAR szPath[MAX_PATH];

		BOOL bVal = SHGetSpecialFolderPath(NULL, szPath, CSIDL_LOCAL_APPDATA, FALSE);

		CString filePath = szPath;
		filePath += "\\iManage\\Services\\ADFS";

		if (GetFileAttributes(filePath) == INVALID_FILE_ATTRIBUTES)
			SHCreateDirectoryEx(NULL,filePath, NULL);
		filePath += "\\";
		CString csValue;
		m_edtNameDesc.GetWindowText(csValue);
		filePath += csValue;
		filePath += ".tok";
		const wchar_t* szFilePath = LPCTSTR(filePath);
		

		
		if (file.Open(szFilePath, CFile::modeCreate | CFile::modeWrite) == TRUE)
		{
			file.WriteString(strEncryptedString.c_str());
			file.Close();
		}
		
		
	}
	catch (...)
	{
		if (HANDLE(file) != INVALID_HANDLE_VALUE)
			file.Close();
	}
	


	
}

void DSConnection::OnBnClickedSamlLogin()
{
	// TODO: Add your control notification handler code here
	CoInitialize(NULL);
	try
	{
		ICommonLoginAuthenticator* pDispatch= NULL;
		HRESULT hr = CoCreateInstance(CLSID_CommonLoginAuthenticator, NULL, CLSCTX_INPROC_SERVER, IID_ICommonLoginAuthenticator, (void **)&pDispatch);
		if (pDispatch == NULL)
		{
			MessageBox(_T("ADFS class could not be instantiated. Please check whether the required dll is present and registered"));
			return;
		}
		
		CString strDMSServer = _T("");
		m_edtServerURL.GetWindowText(strDMSServer);
		if (strDMSServer.GetLength() == 0)
		{
			MessageBox(_T("Please enter the server URL in the text box and click the button again"));
			return;
		}
		pDispatch->put_LoginType(CommonLoginTypes::CommonLoginTypes_Saml);
		BSTR bstrCookie = SysAllocString(COMMON_AUTH_COOKIE);
		pDispatch->put_AppCookie(bstrCookie);

		DWORD processId = GetCurrentProcessId();
		pDispatch->put_ClientProcId(processId);
		BSTR bsrAppId = SysAllocString(_T(""));
		pDispatch->put_AppID(bsrAppId);
		pDispatch->put_TimeOut(60);
		CComBSTR bstrHostUrl(strDMSServer);
		
		pDispatch->put_HostUri(bstrHostUrl);
		pDispatch->put_RestApiVersion(1);

		BSTR token = SysAllocString(_T(""));
		hr = pDispatch->Execute(&token);
		if (hr != S_OK || SysStringLen(token) == 0)
		{
			MessageBox(_T("Unable to get the token, please contact administrator"));
			return;
		}
		WriteToTextFile(token);
		
	}
	catch (...)
	{

	}
	CoUninitialize();
}


void DSConnection::OnBnClickedRadioImanageLogin()
{
	// TODO: Add your control notification handler code here
	m_edtServerURL.ShowWindow(SW_HIDE);
	
	m_edtDmsUser.ShowWindow(SW_SHOW);
	m_edtDmsUser.ShowWindow(SW_SHOW);
	m_dmsPasswordText.ShowWindow(SW_SHOW);
	m_edtDmsPassword.ShowWindow(SW_SHOW);
	
	m_dmsUserNameLabel.SetWindowText(_T("User Name"));
	OnChangeGlobal();
}


void DSConnection::OnBnClickedAdfsLogin()
{
	// TODO: Add your control notification handler code here
	m_edtServerURL.ShowWindow(SW_SHOW);
	m_edtDmsUser.ShowWindow(SW_HIDE);
	
	m_edtDmsUser.ShowWindow(SW_HIDE);
	m_dmsPasswordText.ShowWindow(SW_HIDE);
	m_edtDmsPassword.ShowWindow(SW_HIDE);
	
	m_dmsUserNameLabel.SetWindowText(_T("Server URL"));
	OnChangeGlobal();
}
