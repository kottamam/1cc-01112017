// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "imSvcMgr.h"

#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const TCHAR CMainFrame::s_profileRect[]				= _T("Rect");
const TCHAR CMainFrame::s_profileMax[]				= _T("max");
/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
	// Global help commands
	//ON_COMMAND(ID_HELP_FINDER, CFrameWnd::OnHelpFinder)
	ON_COMMAND(ID_HELP_FINDER, CMainFrame::OnHelp)
	ON_COMMAND(ID_HELP, CMainFrame::OnHelp)
	ON_COMMAND(ID_CONTEXT_HELP, CMainFrame::OnHelp)
	ON_COMMAND(ID_DEFAULT_HELP, CMainFrame::OnHelp)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
	
}

CMainFrame::~CMainFrame()
{
}

void CMainFrame::OnHelp()
{
	CWinApp* app = AfxGetApp();
	::HtmlHelp(NULL, app->m_pszHelpFilePath, HH_HELP_CONTEXT, 3);
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_BUTTON, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this))// ||
//		!m_wndStatusBar.SetIndicators(indicators,
//		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
//	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
//	EnableDocking(CBRS_ALIGN_ANY);
//	DockControlBar(&m_wndToolBar);

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;

	CRect rc = GetMainFrameWndRect();
	cs.x = rc.left;
	cs.y = rc.top;
	cs.cx = rc.Width();
	cs.cy = rc.Height();

	cs.style &= ~FWS_ADDTOTITLE;   
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers


void CMainFrame::WinHelp(DWORD dwData, UINT nCmd) 
{
	// TODO: Add your specialized code here and/or call the base class		
	switch (dwData)
	{
	case HIDD_DIALOG_ADVANCED:
		::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, 59);
		break;

	case HIDD_DB_PROPERTIES:
		::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, 22);
		break;

	case HIDD_DATABASE_SETUP:
		::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, 18);
		break;			

	case HIDD_DMS_PROPERTIES:
		::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, 28);
		break;

	case HIDD_DMS_STARTUP:
		::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, 17);
		break;

	case HIDD_DS_ATTRIBUTEMAP:
		::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, 56);
		break;

	case HIDD_DS_CONNECTION:
		::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, 53);
		break;

	case HIDD_DS_CONNECTIONS:
		::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, 55);
		break;

	case HIDD_DS_NODE:
		::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, 54);
		break;

	case HIDD_DS_SCHEDULE:
		::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, 52);
		break;

	case HIDD_PROPPAGE1:
		::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, IF_YOUR_FILE_SERVER_IS_NOVELL_NETWARE);
		break;

	case HIDD_PROPPAGE2:
		::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, IF_YOUR_FILE_SERVER_IS_WINDOWS_NT);
		break;

	case HIDD_FIND_SERVERS:
		::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, 32);
		break;

	case HIDD_IDX_DB_PROPERTIES:
		::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, CONFIGURING_RULES_ENGINE_DATABASE_PROPERTIES);
		break;

	case HIDD_IDXMGR_PROPERTIES:
		::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, 29);
		break;

	case HIDD_IDXSEARCH_PROPERTIES:
		::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, 6);
		break;

	case HIDD_DIALOG_RULES_MGR:
		::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, RULES_ENGINE_SERVICE_PROPERTIES_SETUP);
		break;

	case HIDD_SELECT_ODBC:
		::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, 33);
		break;

	case HIDD_SELECT_SERVER:
		::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, 13);
		break;

	case HIDD_SERVER_PROPERTIES:
		::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, 11);
		break;
	
	case HIDD_STARTING_SERVICE:
		::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, TO_REGISTER_A_SERVER);
		break;

	case HIDD_KMINDEXER_PROPERTIES:
	case HIDD_WKDRE:	
		::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, 17);
		break;

	case HIDD_SERVICE_ABOUT:
		::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, ABOUT_COMMAND);
		break;

	case HIDD_IDXSEARCH_VELOCITY:
		::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, CONFIGURING_INDEXER_CONNECTION_PROPERTIES);
		break;

	default:
		::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, 1);
		break;
	}
}


CRect CMainFrame::GetMainFrameWndRect()
{
	CString strText;	
	CRect rect;	
	
	IM::Registry	serverReg(NULL, HKEY_CURRENT_USER, KEY_NRSCONF_PATH);
	if (serverReg.OpenOrCreate(NULL, KEY_READ | KEY_WRITE) == true){
		IM::NrString imString;
		serverReg.GetStringValue(s_profileRect, imString);		
		strText = imString.c_str();
		serverReg.Close();
	}
	
	if (!strText.IsEmpty()) {
		rect.left = _ttol((const TCHAR*) strText);
		rect.top = _ttol((const TCHAR*) strText + 5);
		rect.right = _ttol((const TCHAR*) strText + 10);
		rect.bottom = _ttol((const TCHAR*) strText + 15);
	}
	else {
		rect.left = (::GetSystemMetrics(SM_CXFULLSCREEN) - 400) /2;
		rect.right = rect.left + 400;

		rect.top = (::GetSystemMetrics(SM_CYFULLSCREEN) - 300) / 2;		
		rect.bottom = rect.top + 300;		
	}
	return rect;
}

void CMainFrame::SetAndShowWindow()
{
	WINDOWPLACEMENT wndpl;
	int nCmdShow = SW_NORMAL;;
	UINT flags;
	BOOL bMaximized = FALSE;
	
	IM::Registry	serverReg(NULL, HKEY_CURRENT_USER, KEY_NRSCONF_PATH);
	if (serverReg.OpenOrCreate(NULL, KEY_READ | KEY_WRITE) == true){		
		serverReg.GetLongValue(s_profileMax, (long&)bMaximized);		
		serverReg.Close();
	}
	
	if (FALSE != bMaximized){
		nCmdShow = SW_SHOWMAXIMIZED;
		flags = WPF_RESTORETOMAXIMIZED;

		wndpl.length = sizeof(WINDOWPLACEMENT);
		wndpl.showCmd = nCmdShow;
		wndpl.flags = flags;
		wndpl.ptMinPosition = CPoint(0, 0);
		wndpl.ptMaxPosition =
			CPoint(-::GetSystemMetrics(SM_CXBORDER),
				   -::GetSystemMetrics(SM_CYBORDER));	
		wndpl.rcNormalPosition = GetMainFrameWndRect();

		SetWindowPlacement(&wndpl);
	}

	ShowWindow(nCmdShow);
}

void CMainFrame::OnDestroy() 
{
	CString strText;
	BOOL bMaximized;
	WINDOWPLACEMENT wndpl;

	wndpl.length = sizeof(WINDOWPLACEMENT);
	// gets current window position and
	//  iconized/maximized status
	GetWindowPlacement(&wndpl);

	if (wndpl.showCmd == SW_SHOWNORMAL) {		
		bMaximized = FALSE;
	}
	else if (wndpl.showCmd == SW_SHOWMAXIMIZED) {		
		bMaximized = TRUE;
	} 
	else if (wndpl.showCmd == SW_SHOWMINIMIZED) {		
		if (wndpl.flags) {
			bMaximized = TRUE;
		}
		else {
			bMaximized = FALSE;
		}
	}
	strText.Format(_T("%04d %04d %04d %04d"),
	               wndpl.rcNormalPosition.left,
	               wndpl.rcNormalPosition.top,
	               wndpl.rcNormalPosition.right,
	               wndpl.rcNormalPosition.bottom);


	IM::Registry	serverReg(NULL, HKEY_CURRENT_USER, KEY_NRSCONF_PATH);
	if (serverReg.OpenOrCreate(NULL, KEY_READ | KEY_WRITE) == true){		
		serverReg.SetStringValue(s_profileRect, strText);
		serverReg.SetLongValue(s_profileMax, bMaximized);		
		serverReg.Close();
	}

	CFrameWnd::OnDestroy();	
}
