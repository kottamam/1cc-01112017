// CntrItem.h : interface of the CSvcMgrCntrItem class
//

#if !defined(AFX_CNTRITEM_H__2F077612_D7EC_11D2_8C4D_00C04F68F9B3__INCLUDED_)
#define AFX_CNTRITEM_H__2F077612_D7EC_11D2_8C4D_00C04F68F9B3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CSvcMgrDoc;
class CSvcMgrView;

class CSvcMgrCntrItem : public COleClientItem
{
	DECLARE_SERIAL(CSvcMgrCntrItem)

// Constructors
public:
	CSvcMgrCntrItem(CSvcMgrDoc* pContainer = NULL);
		// Note: pContainer is allowed to be NULL to enable IMPLEMENT_SERIALIZE.
		//  IMPLEMENT_SERIALIZE requires the class have a constructor with
		//  zero arguments.  Normally, OLE items are constructed with a
		//  non-NULL document pointer.

// Attributes
public:
	CSvcMgrDoc* GetDocument()
		{ return (CSvcMgrDoc*)COleClientItem::GetDocument(); }
	CSvcMgrView* GetActiveView()
		{ return (CSvcMgrView*)COleClientItem::GetActiveView(); }

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSvcMgrCntrItem)
	public:
	virtual void OnChange(OLE_NOTIFICATION wNotification, DWORD dwParam);
	virtual void OnActivate();
	protected:
	virtual void OnGetItemPosition(CRect& rPosition);
	virtual void OnDeactivateUI(BOOL bUndoable);
	virtual BOOL OnChangeItemPosition(const CRect& rectPos);
	virtual BOOL CanActivate();
	//}}AFX_VIRTUAL

// Implementation
public:
	~CSvcMgrCntrItem();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	virtual void Serialize(CArchive& ar);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CNTRITEM_H__2F077612_D7EC_11D2_8C4D_00C04F68F9B3__INCLUDED_)
