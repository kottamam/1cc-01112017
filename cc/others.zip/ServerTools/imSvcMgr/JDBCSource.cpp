// JDBCSource.cpp : implementation file
//
#include "stdafx.h"
#include "imsvcmgr.h"
#include "JDBCSource.h"


#include <iostream>
#include <fstream>
using namespace std;


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CJDBCSource dialog
class DataSource : public CObject
{
public:
	string dsnName;
	string fullDriverName;
	string url;
	string userName;
	string password;
	string driverName;
	string host;
	string port;
	string dbname;
};

const string fileName = "\\config\\jdbcdatasources.properties";
const int sz = 5000; // Buffer size;

CJDBCSource::CJDBCSource(CWnd* pParent /*=NULL*/)
	: CDialog(CJDBCSource::IDD, pParent)
{
	//{{AFX_DATA_INIT(CJDBCSource)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	dsnList = new CObList();
}

CJDBCSource::~CJDBCSource()
{
	if(dsnList != NULL)
	{
		POSITION pos;
		for( pos = dsnList->GetHeadPosition(); pos != NULL; )
		{
			DataSource* dsn = (DataSource*)dsnList->GetNext(pos) ;
			delete dsn;
		}
		delete dsnList;
		dsnList = NULL;
	}
}

void CJDBCSource::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CJDBCSource)
	DDX_Control(pDX, IDC_JDBC_LIST, m_lstDataSource);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CJDBCSource, CDialog)
	//{{AFX_MSG_MAP(CJDBCSource)
	ON_LBN_DBLCLK(IDC_JDBC_LIST, OnDblclkJdbcList)
	ON_LBN_SELCHANGE(IDC_JDBC_LIST, OnSelchangeJdbcList)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CJDBCSource message handlers

BOOL CJDBCSource::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	((CButton*)GetDlgItem(IDOK))->EnableWindow(FALSE);
	m_lstDataSource.ResetContent();
	GetDataSourceList();
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CJDBCSource::GetDataSourceList()
{
	char dir[sz];
	GetCurrentDirectory( sz, dir);
	string dirPath = dir;
	dirPath += fileName;

	char buf[sz];
  
    ifstream in(dirPath.c_str()); // Read
    
	if(in != NULL)
	{
		int i = 1; // Line counter
		while(in.getline(buf, sz)) 
		{ 
			string str = buf;
			if(str.substr(0,1).compare("#") != 0)
			{
					ParseDataSource(str);
					i++;
			}
		}
	}
	else
	{
		AfxMessageBox("The datasource file could not be located by the application.Please make sure that the file jdbcdatasources.properties lies in the .\\config\\ directory. ");
		return;
	}
	in.close();
}

void CJDBCSource::OnOK() 
{
	// TODO: Add extra validation here
	OnSelchangeJdbcList();
	CDialog::OnOK();
}


void CJDBCSource::ParseDataSource(string line)
{
	string datasource,fulldrivername,url,userName,password,driverName,host,port,dbname;
	ReplaceChars(line,"\\");
	int j = line.find("=");
	if(j != string::npos)
	{
		datasource = line.substr(0,j);
		line = line.substr(j+1);
	}
	else
		return;

	j = line.find(",");
	if( j != string::npos)
	{
		fulldrivername = line.substr(0,j);
		line = line.substr(j+1);
	}
	else
		return;

	j = line.find(",");
	if( j != string::npos)
	{
		url = line.substr(0,j);
		line = line.substr(j+1);
	}
	else
		return;

	j = line.find(",");
	if( j != string::npos)
	{
		userName = line.substr(0,j);
		line = line.substr(j+1);
	}
	else
		return;

	j = line.find(",");
	if( j != string::npos)
	{
		password = line.substr(0,j);
		line = line.substr(j+1);
	}
	else
		return;

	j = line.find(",");
	if( j != string::npos)
	{
		driverName = line.substr(0,j);
		line = line.substr(j+1);
	}
	else
		return;

	j = line.find(",");
	if( j != string::npos)
	{
		host = line.substr(0,j);
		line = line.substr(j+1);
	}
	else
		return;

	j = line.find(",");
	if( j != string::npos)
	{
		port = line.substr(0,j);
		line = line.substr(j+1);
	}
	else
		return;
	dbname = line;

	DataSource* dsn = new DataSource();
	dsn->dsnName = datasource;
	dsn->fullDriverName = fulldrivername;
	dsn->url = url;
	dsn->userName = userName;
	dsn->password = password;
	dsn->driverName = driverName;
	dsn->host = host;
	dsn->port = port;
	dsn->dbname = dbname;
	dsnList->AddTail((CObject*)dsn);
	if(pDSNList->Find(datasource.c_str()) == NULL)
		m_lstDataSource.AddString(datasource.c_str());
}

void CJDBCSource::OnDblclkJdbcList() 
{
	// TODO: Add your control notification handler code here
	OnOK();	
}

void CJDBCSource::OnSelchangeJdbcList() 
{
	// TODO: Add your control notification handler code here
	CString strSelVal;
	int nIndex = m_lstDataSource.GetCurSel();
	if(nIndex == LB_ERR)
		return;
	m_lstDataSource.GetText(nIndex,strSelVal);
	//Get Details
	POSITION pos;
	for( pos = dsnList->GetHeadPosition(); pos != NULL; )
	{
		DataSource* dsn = (DataSource*)dsnList->GetNext(pos) ;
		string str = dsn->dsnName;
		if(str.c_str() == strSelVal)
		{
			strDSNName = (dsn->dsnName).c_str();
			strPassword = (dsn->password).c_str();
			strUserName = (dsn->userName).c_str();
			((CButton*)GetDlgItem(IDOK))->EnableWindow(TRUE);
		}
	}
}

void CJDBCSource::ReplaceChars(string& modifyMe, string findMe)
{
	int i = modifyMe.find(findMe, 0);
	if(i != string::npos)
	{
		modifyMe = modifyMe.erase(i,1);
		ReplaceChars(modifyMe,findMe);
	}
}