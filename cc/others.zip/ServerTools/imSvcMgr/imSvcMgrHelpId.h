
#if!defined _IMSVCMGRHELP_H_
#define _IMSVCMGRHELP_H_

/* Topic mapping file converted from imsvcmgr */
/* Converted by eHelp Corporation's Help-to-Source */

#define HTML_HELP_FILENAME	_T(".\\servicemanager.chm")

#define VIEW_LOG_FILE     										0X29
#define UNREGISTERING_A_SERVER     								0X10
#define CONFIGURING_THE_DIRECTORY_SYNCHRONIZATION_SERVICE		0X33
#define CLUSTER_SERVER_NAME     								0X13
#define IF_YOUR_FILE_SERVER_IS_NOVELL_NETWARE				    0X27
#define ABOUT_COMMAND  											0X22
#define ENABLE_IMPERSONATION_AND_PASSWORD 						0X17
#define FINDING_WORKSITE_SERVERS   								0X20
#define UNDERSTANDING_THE_TABLE_VIEW   							0X3
#define CONFIGURING_WORKSITE_SERVER_SERVICE_PROPERTIES 			0X1C
#define DIRECTORY_SERVICE_SYNCHRONIZATION_SERVICE_PROPERTIES   	0X34
#define SETTING_STARTUP_PROPERTIES 								0X11
#define RULES_ENGINE_SERVICE_PROPERTIES_SETUP  					0X9
#define TREE_FRAME 												0XF
#define USING_THE_TOOLBAR  										0X4
#define IF_YOUR_FILE_SERVER_IS_WINDOWS_NT     					0X28
#define SHARED_CM_CACHE   										0X31
#define TO_REGISTER_A_SERVER   									0XE
#define REFRESH_FREQUENCY  										0X2E
#define DS_SYNCHRONIZATION_ATTRIBUTE_MAP   						0X38
#define EMAIL_DOMAIN   											0X15
#define ROWS_PER_CACHE_TABLE   									0X2F
#define UNDERSTANDING_DATABASE_PROPERTIES  						0X16
#define STARTING_AND_STOPPING_A_SERVICE   						0X1E
#define CONFIGURING_THE_RULES_ENGINE_SERVICE   					0X7
#define OVERVIEW   												0X1
#define COMMUNICATIONS_SERVER_SERVICE_PROPERTIES_SETUP 			0X18
#define SERVER_CONNECTION_PROPERTIES   							0XB
#define SERVICE_PORT_AND_FILE_PORT 								0X32
#define ACCEPT_WINDOWS_AUTHENTICATION_TRUSTED_LOGON  			0X2D
#define DS_SYNCHRONIZATION_ROOT_CONTEXT   						0X36
#define REGISTERING_SERVERS    									0XD
#define WORKSITE_SEARCH_SERVERS_STATUS_BOX 						0X25
#define PRELOAD_CACHE  											0X30
#define CACHE_FILESERVER_PATH  									0X14
#define CONNECTING_SERVICES_AND_DATABASES  						0X12
#define FILE_SERVER_CONNECTIONS_DIALOG_BOX 						0X26
#define CONFIGURING_THE_COMMUNICATIONS_SERVER_SERVICE  			0X19
#define DS_SYNCHRONIZATION_CONNECTION_PROPERTIES   				0X35
#define DIRECTORY_SERVICE_CONNECTIONS  							0X37
#define ODBC_SOURCE(S)_DIALOG_BOX  								0X21
#define CONFIGURING_INDEXER_CONNECTION_PROPERTIES				0X3A
#define WORKSITE_SERVER_DATABASE_ADVANCED_PROPERTIES			0X3B
#define CONFIGURING_RULES_ENGINE_DATABASE_PROPERTIES			0X3C
#define CONFIGURING_COMMUNICATIONS_SERVER_DATABASE_PROPERTIES	0X3D

//Help ID for the DIALOG used in dwData value in WinHelp

#define HIDD_ABOUTBOX                           0x20064
#define HIDD_SVCMGR_FORM                        0x20065
#define HIDD_PROPPAGE1                          0x20068
#define HIDD_PROPPAGE2                          0x20069
#define HIDD_FIND_SERVERS                       0x20085
#define HIDD_STARTING_SERVICE                   0x20086
#define HIDD_DATABASE_SETUP                     0x20087
#define HIDD_DMS_PROPERTIES                     0x2008A
#define HIDD_DMS_STARTUP                        0x2008B
#define HIDD_DB_PROPERTIES                      0x20090
#define HIDD_IDX_DB_PROPERTIES                  0x20091
#define HIDD_WKDRE_DB_PROPERTIES                0x20091
#define HIDD_SELECT_ODBC                        0x20092
#define HIDD_IDX_PROPERTIES                     0x20093
#define HIDD_IDXMGR_PROPERTIES                  0x2009B
#define HIDD_IDXSEARCH_PROPERTIES               0x2009C
#define HIDD_CMS_PROPERTIES                     0x20106
#define HIDD_CMS_DB_PROP                        0x20107
#define HIDD_DIALOG_RULES_MGR                   0x2010E
#define HIDD_SELECT_JDBC                        0x20111
#define HIDD_KMINDEXER_PROPERTIES               0x20112
#define HIDD_WKDRE                              0x20113
#define HIDD_DIALOG1                            0x20114
#define HIDD_WKATINDXR                          0x20115
#define HIDD_EMS_DB_PROP2                       0x2011D
#define HIDD_EMSSERVICEPROP                     0x2011E
#define HIDD_FILECACHE_SCHEDULE                 0x2011F
#define HIDD_DS_ATTRIBUTEMAP                    0x20127
#define HIDD_DS_NODE                            0x20128
#define HIDD_DS_CONNECTIONS                     0x20129
#define HIDD_DS_CONNECTION                      0x2012A
#define HIDD_DS_SCHEDULE                        0x2012B
#define HIDD_IDXSEARCH_VERITY                   0x2012D
#define HIDD_IDXSEARCH_VELOCITY                 0x2012E
#define HIDD_DIALOG_ADVANCED                    0x20130
#define HIDD_DB_PROPERTIES_ADV_SERV             0x2054F
#define HIDD_SERVER_PROPERTIES                  0x2054F
#define HIDD_SELECT_SERVER                      0x217F3
#define HIDD_SERVICE_ABOUT                      0x217FC

#endif // _IMSVCMGRHELP_H_