// DSConnections.cpp : implementation file
//

#include "stdafx.h"
#include "imsvcmgr.h"
#include "DSConnections.h"
#include "DSConnection.h"
#include "DSSchedule.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif



/////////////////////////////////////////////////////////////////////////////
// DSConnections dialog


DSConnections::DSConnections(CWnd* pParent /*=NULL*/)
	: CDialog(DSConnections::IDD, pParent), m_pSyncSvc_Remote( NULL ), m_pSyncSvc_Local( NULL ), m_strServer( _T( "" ) )
{
	//{{AFX_DATA_INIT(DSConnections)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

DSConnections::~DSConnections( void )
{
	// cleanup
	if( m_pSyncSvc_Local != NULL )
		delete m_pSyncSvc_Local;
}

void DSConnections::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(DSConnections)
	DDX_Control(pDX, IDC_BUTTON_CLEAR, m_btnClear);
	DDX_Control(pDX, IDOK, m_btnOk);
	DDX_Control(pDX, IDHELP, m_btnHelp);
	DDX_Control(pDX, IDC_LIST_CONNECTIONS, m_list);
	DDX_Control(pDX, IDC_BUTTON_EDIT, m_btnEdit);
	DDX_Control(pDX, IDC_BUTTON_DELETE, m_btnDelete);
	DDX_Control(pDX, IDC_BUTTON_COPY, m_btnCopy);
	DDX_Control(pDX, IDC_BUTTON_ADD, m_btnAdd);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(DSConnections, CDialog)
	//{{AFX_MSG_MAP(DSConnections)
	ON_NOTIFY(NM_DBLCLK, IDC_LIST_CONNECTIONS, OnDblclkListConnections)
	ON_BN_CLICKED(IDC_BUTTON_EDIT, OnButtonEdit)
	ON_BN_CLICKED(IDC_BUTTON_DELETE, OnButtonDelete)
	ON_BN_CLICKED(IDC_BUTTON_COPY, OnButtonCopy)
	ON_BN_CLICKED(IDC_BUTTON_ADD, OnButtonAdd)
	ON_NOTIFY(NM_CLICK, IDC_LIST_CONNECTIONS, OnClickListConnections)
	ON_WM_SIZE()
	ON_BN_CLICKED(IDC_BUTTON_CLEAR, OnButtonClear)
	ON_WM_CLOSE()
	ON_WM_HELPINFO()
	ON_BN_CLICKED(IDHELP, OnHelp)
	//}}AFX_MSG_MAP
	ON_WM_GETMINMAXINFO( )
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// DSConnections message handlers

BOOL DSConnections::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	InitListControl( );
	
	AddAllConnectionsToList();
	EnableButtons( FALSE );

	CString strCaption;
	strCaption.Format( _T( "Directory Service Connections on %s" ), m_strServer );
	SetWindowText( strCaption );

	CRect rc;
	GetClientRect( rc );
	DoSize( rc.Width( ), rc.Height( ) );

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void DSConnections::ApplyChanges()
{
	try
	{
		if( ( m_pSyncSvc_Local != NULL ) && ( m_pSyncSvc_Remote != NULL ) )
		{		
			m_pSyncSvc_Remote->DeleteFromRegistry( );

			AssignRemoteToLocal( );

			// update registry
			m_pSyncSvc_Remote->StoreInRegistry( );
		}
	}
	catch(IM::Exception &)
	{
	}
}

void DSConnections::OnOK() 
{
	
	CDialog::OnOK();
}

void DSConnections::AssignRemoteToLocal_AttributeMapsOnly( void )
{
	try
	{
		// assume pointers are valid

		m_pSyncSvc_Remote->Close( );

		// maybe all other registry maps need to be closed too?

		// update registry -- this removes all attribute maps from registry
		m_pSyncSvc_Remote->DeleteFromRegistry_AttributeMapsOnly( );
		m_pSyncSvc_Remote->RemoveAllAttributeMaps( );

		{
			IM::CDSSyncSvc::ATTRIBUTEMAPLIST::const_iterator iterEnd = m_pSyncSvc_Local->m_AttributeMapList.end( );
			for( IM::CDSSyncSvc::ATTRIBUTEMAPLIST::const_iterator iter = m_pSyncSvc_Local->m_AttributeMapList.begin( ); iter != iterEnd; iter++ )
			{
				IM::CDSSyncSvc_AttributeMap* pAttributeMap_Local = *iter;
				if( pAttributeMap_Local != NULL )
				{
					m_pSyncSvc_Remote->AddAttributeMap(
						pAttributeMap_Local->m_strMapName.Get( ).c_str( ),
						pAttributeMap_Local->m_strOUName.Get( ).c_str( ),
						pAttributeMap_Local->m_strUserName.Get( ).c_str( ),
						pAttributeMap_Local->m_strUserId.Get( ).c_str( ),
						pAttributeMap_Local->m_strUserEmail.Get( ).c_str( ),
						pAttributeMap_Local->m_strUserFax.Get( ).c_str( ),
						pAttributeMap_Local->m_strUserTelephone.Get( ).c_str( ),
						pAttributeMap_Local->m_strUserLocation.Get( ).c_str( ),
						pAttributeMap_Local->m_strUserEnabled.Get( ).c_str( ),
						pAttributeMap_Local->m_strGroupName.Get( ).c_str( ),
						pAttributeMap_Local->m_strGroupId.Get( ).c_str( ),
						pAttributeMap_Local->m_strGroupMember.Get( ).c_str( ),
						pAttributeMap_Local->m_strK1SyncId.Get( ).c_str( )
						);
				}
			}
		}

		// update registry
		m_pSyncSvc_Remote->StoreInRegistry_AttributeMapsOnly( );

		// Refresh both local in-memory object to what is actually in the registry
		m_pSyncSvc_Local->LoadFromRegistry_AttributeMapsOnly( );
	}
	catch(IM::Exception &)
	{
	}
}

void DSConnections::AssignRemoteToLocal( void )
{
	// assume pointers are valid

	m_pSyncSvc_Remote->Close( );

	// maybe all other registry maps need to be closed too?

	m_pSyncSvc_Remote->Clear( );

	{
		IM::CDSSyncSvc::CONNECTIONLIST::const_iterator iterEnd = m_pSyncSvc_Local->m_ConnectionList.end( );
		for( IM::CDSSyncSvc::CONNECTIONLIST::const_iterator iter = m_pSyncSvc_Local->m_ConnectionList.begin( ); iter != iterEnd; iter++ )
		{
			IM::CDSSyncSvc_Connection* pConnection_Local = *iter;
			if( pConnection_Local != NULL )
			{
				m_pSyncSvc_Remote->AddConnection(
					pConnection_Local->m_strName.Get( ).c_str( ),
					pConnection_Local->m_strNode.Get( ).c_str( ),
					pConnection_Local->m_strAttributeMapName.Get( ).c_str( ),
					pConnection_Local->m_strFilter.Get( ).c_str( ),
					pConnection_Local->m_DMSParameters.m_strDms.Get( ).c_str( ),
					pConnection_Local->m_DMSParameters.m_strLibrary.Get( ).c_str( ),
					pConnection_Local->m_DMSParameters.m_strUserId.Get( ).c_str( ),
					pConnection_Local->m_DMSParameters.m_strPassword.Get( ).c_str( ),
					pConnection_Local->m_DMSParameters.m_lTcpipPort.Get( ),
					pConnection_Local->m_DMSParameters.m_lLoginType.Get(),
					pConnection_Local->m_DMSParameters.m_strServerURL.Get().c_str(),
					pConnection_Local->m_DSParameters.m_strServerName.Get( ).c_str( ),
					pConnection_Local->m_DSParameters.m_strUserId.Get( ).c_str( ),
					pConnection_Local->m_DSParameters.m_strPassword.Get( ).c_str( ),
					pConnection_Local->m_DMSParameters.m_strDefaultPassword.Get( ).c_str( ),
					pConnection_Local->m_DMSParameters.m_bDefaultPasswordNeverExpires.Get( ),
					pConnection_Local->m_DMSParameters.m_bDefaultPasswordMustBeChanged.Get( ),
					pConnection_Local->m_DSParameters.m_lServiceType.Get( ),
					pConnection_Local->m_DSParameters.m_lTcpipPort.Get( ),
					pConnection_Local->m_DSParameters.m_strContext.Get( ).c_str( ),
					pConnection_Local->m_strExternalDNList.Get( ).c_str( ),
					pConnection_Local->m_DSParameters.m_strTreeID.Get( ).c_str( )

					);
			}
		}
	}

	{
		IM::CDSSyncSvc::ATTRIBUTEMAPLIST::const_iterator iterEnd = m_pSyncSvc_Local->m_AttributeMapList.end( );
		for( IM::CDSSyncSvc::ATTRIBUTEMAPLIST::const_iterator iter = m_pSyncSvc_Local->m_AttributeMapList.begin( ); iter != iterEnd; iter++ )
		{
			IM::CDSSyncSvc_AttributeMap* pAttributeMap_Local = *iter;
			if( pAttributeMap_Local != NULL )
			{
				m_pSyncSvc_Remote->AddAttributeMap(
					pAttributeMap_Local->m_strMapName.Get( ).c_str( ),
					pAttributeMap_Local->m_strOUName.Get( ).c_str( ),
					pAttributeMap_Local->m_strUserName.Get( ).c_str( ),
					pAttributeMap_Local->m_strUserId.Get( ).c_str( ),
					pAttributeMap_Local->m_strUserEmail.Get( ).c_str( ),
					pAttributeMap_Local->m_strUserFax.Get( ).c_str( ),
					pAttributeMap_Local->m_strUserTelephone.Get( ).c_str( ),
					pAttributeMap_Local->m_strUserLocation.Get( ).c_str( ),
					pAttributeMap_Local->m_strUserEnabled.Get( ).c_str( ),
					pAttributeMap_Local->m_strGroupName.Get( ).c_str( ),
					pAttributeMap_Local->m_strGroupId.Get( ).c_str( ),
					pAttributeMap_Local->m_strGroupMember.Get( ).c_str( ),
					pAttributeMap_Local->m_strK1SyncId.Get( ).c_str( )
					);
			}
		}
	}
}

void DSConnections::OnDblclkListConnections(NMHDR* pNMHDR, LRESULT* pResult) 
{
	OnButtonEdit( );
	
	*pResult = 0;
}
void DSConnections::UpdateConnection(IM::CDSSyncSvc_Connection* pConnection_Local, IM::CDSSyncSvc_Connection* pConnection)
{
	pConnection_Local->m_strName.Set(pConnection->m_strName.Get( ).c_str( ));
	pConnection_Local->m_strNode.Set( pConnection->m_strNode.Get( ).c_str( ));
	pConnection_Local->m_strAttributeMapName.Set(pConnection->m_strAttributeMapName.Get( ).c_str( ));
	pConnection_Local->m_strFilter.Set(pConnection->m_strFilter.Get( ).c_str( ));
	pConnection_Local->m_DMSParameters.m_strDms.Set(pConnection->m_DMSParameters.m_strDms.Get( ).c_str( ));
	pConnection_Local->m_DMSParameters.m_strLibrary.Set(pConnection->m_DMSParameters.m_strLibrary.Get( ).c_str( ));
	pConnection_Local->m_DMSParameters.m_strUserId.Set( pConnection->m_DMSParameters.m_strUserId.Get( ).c_str( ));
	pConnection_Local->m_DMSParameters.m_strPassword.Set( pConnection->m_DMSParameters.m_strPassword.Get( ).c_str( ));
	pConnection_Local->m_DMSParameters.m_lTcpipPort.Set( pConnection->m_DMSParameters.m_lTcpipPort.Get( ));
	pConnection_Local->m_DMSParameters.m_lLoginType.Set(pConnection->m_DMSParameters.m_lLoginType.Get());
	pConnection_Local->m_DMSParameters.m_strServerURL.Set(pConnection->m_DMSParameters.m_strServerURL.Get().c_str());
	pConnection_Local->m_DSParameters.m_strServerName.Set( pConnection->m_DSParameters.m_strServerName.Get( ).c_str( ));
	pConnection_Local->m_DSParameters.m_strUserId.Set( pConnection->m_DSParameters.m_strUserId.Get( ).c_str( ));
	pConnection_Local->m_DSParameters.m_strPassword.Set( pConnection->m_DSParameters.m_strPassword.Get( ).c_str( ));
	pConnection_Local->m_DMSParameters.m_strDefaultPassword.Set( pConnection->m_DMSParameters.m_strDefaultPassword.Get( ).c_str( ));
	pConnection_Local->m_DMSParameters.m_bDefaultPasswordNeverExpires.Set(pConnection->m_DMSParameters.m_bDefaultPasswordNeverExpires.Get( ));
	pConnection_Local->m_DMSParameters.m_bDefaultPasswordMustBeChanged.Set( pConnection->m_DMSParameters.m_bDefaultPasswordMustBeChanged.Get( ));
	pConnection_Local->m_DSParameters.m_lServiceType.Set(pConnection->m_DSParameters.m_lServiceType.Get( ));
	pConnection_Local->m_DSParameters.m_lTcpipPort.Set(pConnection->m_DSParameters.m_lTcpipPort.Get( ));
	pConnection_Local->m_DSParameters.m_strContext.Set( pConnection->m_DSParameters.m_strContext.Get( ).c_str( ));
	pConnection_Local->m_strExternalDNList.Set( pConnection->m_strExternalDNList.Get( ).c_str( ));
	pConnection_Local->m_DSParameters.m_strTreeID.Set( pConnection->m_DSParameters.m_strTreeID.Get( ).c_str( ));			
	pConnection_Local->m_DSParameters.m_lEnableSSL.Set(pConnection->m_DSParameters.m_lEnableSSL.Get());
}
void DSConnections::OnButtonEdit() 
{
	// m_list is single-select only
	int nSelected = m_list.GetSelectionMark();
	CString strSeletedText = m_list.GetItemText(nSelected, 0) ;
	if(strSeletedText != "") 
	{
		IM::CDSSyncSvc* pSyncSvc_Temp = new IM::CDSSyncSvc(m_strServer);	
		IM::CDSSyncSvc* pSyncSvc_Local = new IM::CDSSyncSvc(m_strServer);
		pSyncSvc_Local->LoadFromRegistry();	
		if( pSyncSvc_Local != NULL )
		{
			IM::CDSSyncSvc_Connection* pConnection_Before = new IM::CDSSyncSvc_Connection( pSyncSvc_Local->GetComputerName( ).c_str( ), pSyncSvc_Local->GetDesiredHive( ), pSyncSvc_Local->GetBaseKeyPath( ).c_str( ) );
			IM::CDSSyncSvc_Connection* pConnection_After = new IM::CDSSyncSvc_Connection( pSyncSvc_Local->GetComputerName( ).c_str( ), pSyncSvc_Local->GetDesiredHive( ), pSyncSvc_Local->GetBaseKeyPath( ).c_str( ) );
			IM::CDSSyncSvc_Connection* pConnection = pSyncSvc_Local->FindConnection(strSeletedText);	
			
			UpdateConnection(pConnection_Before,pConnection);
		
			if( ( pConnection != NULL ) && ( pSyncSvc_Local != NULL ) )
			{
				DSConnection dlg( this );
				dlg.m_strServer = m_strServer;
				dlg.m_Mode = DSConnection::Edit;
				dlg.SetRegistryObjects( pSyncSvc_Local, pConnection );
				if( dlg.DoModal( ) == IDOK )
				{			
					UpdateRegistryPaths( pConnection_Before );
					pSyncSvc_Temp->AddConnection( pConnection_Before);
					pSyncSvc_Temp->DeleteFromRegistry();
					pSyncSvc_Temp->Clear();					
					
					UpdateConnection(pConnection_After,pConnection);		
					UpdateRegistryPaths( pConnection_After );
					pConnection_After->StoreInRegistry();					
				}
			}
			AddAllConnectionsToList(); 
		}
		delete pSyncSvc_Temp;
		delete pSyncSvc_Local;
	}
	
	m_list.SetFocus();
	POSITION pos = m_list.GetFirstSelectedItemPosition( );
	if( pos == NULL )
		EnableButtons( FALSE );
	else
		EnableButtons( TRUE );
}

void DSConnections::OnButtonDelete() 
{
	if( AfxMessageBox( _T( "Do you want to delete this connection?" ), MB_YESNO ) != IDYES )
		return;

	// m_list is single-select only
	int nSelected = m_list.GetSelectionMark();
	CString strSeletedText = m_list.GetItemText(nSelected, 0);

	if(strSeletedText != "")
	{
		IM::CDSSyncSvc* pSyncSvc_Temp = new IM::CDSSyncSvc(m_strServer);	
		IM::CDSSyncSvc* pSyncSvc_Local = new IM::CDSSyncSvc(m_strServer);
		pSyncSvc_Local->LoadFromRegistry();
		
		if( pSyncSvc_Local !=NULL)
		{
			IM::CDSSyncSvc_Connection* pConnection_Local = new IM::CDSSyncSvc_Connection( pSyncSvc_Local->GetComputerName( ).c_str( ), pSyncSvc_Local->GetDesiredHive( ), pSyncSvc_Local->GetBaseKeyPath( ).c_str( ) );
			IM::CDSSyncSvc_Connection* pConnection = pSyncSvc_Local->FindConnection(strSeletedText);
			
			UpdateConnection( pConnection_Local,pConnection);
			UpdateRegistryPaths( pConnection_Local );
			pSyncSvc_Temp->AddConnection( pConnection_Local);
			pSyncSvc_Temp->DeleteFromRegistry();
			
			AddAllConnectionsToList(); 
		}
		delete pSyncSvc_Temp;
		delete pSyncSvc_Local;		
	}
		
	m_list.SetFocus();
	POSITION pos = m_list.GetFirstSelectedItemPosition( );
	if( pos == NULL )
		EnableButtons( FALSE );
	else
		EnableButtons( TRUE );	
}

CString GetBasePath( LPCTSTR szFullPath )
{
	CString strOld = szFullPath;
	int iLengthOld = strOld.GetLength( );

	CString strNew = _T( "" );
	int iPos = iLengthOld - 1;
	while( strOld.GetAt( iPos ) != _T( '\\' ) )
		iPos--;

	strNew = strOld.Left( iPos );
	return strNew;
}

bool DSConnections::ConnectionNameExists( CString strName )
{
	IM::CDSSyncSvc* pSyncSvc_Local = new IM::CDSSyncSvc(m_strServer);
	pSyncSvc_Local->LoadFromRegistry();
	bool retval = false;

	if(pSyncSvc_Local !=NULL)
	{
	IM::CDSSyncSvc::CONNECTIONLIST::const_iterator clIter;
		for( clIter = pSyncSvc_Local->m_ConnectionList.begin(); clIter != pSyncSvc_Local->m_ConnectionList.end(); clIter++ )
	{
		IM::CDSSyncSvc_Connection* pConn = *clIter;
		CString strTemp = pConn->m_strName.Get( ).c_str( );
		if( strTemp.CompareNoCase( strName ) == 0 )
		{
			retval = true;
			break;
		}
	}
	}
	delete pSyncSvc_Local;
	return retval;
}

CString DSConnections::GetNextCopyName( IM::CDSSyncSvc_Connection *pCurrentConnection )
{
	CString strToCopy = pCurrentConnection->m_strName.Get( ).c_str( );

	CString strNewName;
	strNewName.Format( _T( "Copy of %s" ), strToCopy );

	int i = 2;
	while( ConnectionNameExists( strNewName ) )
	{
		strNewName.Format( _T( "Copy (%i) of %s" ), i++, strToCopy );
	}

	return strNewName;
}

void DSConnections::OnButtonCopy() 
{
	// m_list is single-select only
	int nSelected = m_list.GetSelectionMark();
	CString strSelectedText = m_list.GetItemText(nSelected, 0);
	if(strSelectedText != "")
	{
		IM::CDSSyncSvc* pSyncSvc_Temp = new IM::CDSSyncSvc(m_strServer);
		IM::CDSSyncSvc* pSyncSvc_Local = new IM::CDSSyncSvc(m_strServer);
		pSyncSvc_Local->LoadFromRegistry();

		if( pSyncSvc_Local !=NULL)
		{
			IM::CDSSyncSvc_Connection* pConnection_Local = new IM::CDSSyncSvc_Connection( pSyncSvc_Local->GetComputerName( ).c_str( ), pSyncSvc_Local->GetDesiredHive( ), pSyncSvc_Local->GetBaseKeyPath( ).c_str( ) );
			IM::CDSSyncSvc_Connection* pConnection = pSyncSvc_Local->FindConnection(strSelectedText);
			
			UpdateConnection(pConnection_Local,pConnection); 
			CString strNewName = GetNextCopyName( pConnection_Local );			
			pConnection_Local->m_strName.Set(( LPCTSTR ) strNewName);
			UpdateRegistryPaths( pConnection_Local );
			pConnection_Local->StoreInRegistry();			
			AddConnectionToList(pConnection_Local); 
		}
		delete pSyncSvc_Temp;
		delete pSyncSvc_Local;
	}

	m_list.SetFocus();
	POSITION pos = m_list.GetFirstSelectedItemPosition( );
	if( pos == NULL )
		EnableButtons( FALSE );
	else
		EnableButtons( TRUE );
}

void DSConnections::UpdateRegistryPaths( IM::CDSSyncSvc_Connection *pConnection )
{
	if( pConnection != NULL )
	{
		// hard-coded value from Registry/ServiceEx.cpp
		// #define KEY_DSSYNCSVC_CONNECTIONS		_T( "\\Connections" )
		_bstr_t newPath = m_pSyncSvc_Local->GetBaseKeyPath( ).c_str( );
		newPath +=  _T( "\\Connections\\" );
		newPath += pConnection->m_strName.Get( ).c_str( );
		pConnection->SetPath( newPath );

		// hard-coded value from Registry/ServiceEx.cpp
		//#define KEY_DSSYNCSVC_CONNECTION_DSPARAMETERS			_T( "\\DS Parameters" )
		_bstr_t newPathDS = newPath;
		newPathDS += _T( "\\DS Parameters" );
		pConnection->m_DSParameters.SetPath( newPathDS );

		// hard-coded value from Registry/ServiceEx.cpp
		//#define KEY_DSSYNCSVC_CONNECTION_DMSPARAMETERS			_T( "\\DMS Parameters" )
		_bstr_t newPathDMS = newPath;
		newPathDMS += _T( "\\DMS Parameters" );
		pConnection->m_DMSParameters.SetPath( newPathDMS );
	}
}

void DSConnections::OnButtonAdd() 
{
	IM::CDSSyncSvc* pSyncSvc_Temp = new IM::CDSSyncSvc(m_strServer);
	IM::CDSSyncSvc* pSyncSvc_Local = new IM::CDSSyncSvc(m_strServer);
	pSyncSvc_Local->LoadFromRegistry();
	if( pSyncSvc_Local != NULL )
	{
		IM::CDSSyncSvc_Connection* pConnection_Local = new IM::CDSSyncSvc_Connection( pSyncSvc_Local->GetComputerName( ).c_str( ), pSyncSvc_Local->GetDesiredHive( ), pSyncSvc_Local->GetBaseKeyPath( ).c_str( ) );

		pConnection_Local->m_strName.Set( _T( "" ) );
		pConnection_Local->m_strNode.Set( _T( "" ) );
		pConnection_Local->m_strAttributeMapName.Set( _T( "" ) );

		pConnection_Local->m_DMSParameters.m_strDms.Set( _T( "" ) );
		pConnection_Local->m_DMSParameters.m_strLibrary.Set( _T( "" ) );
		pConnection_Local->m_DMSParameters.m_strUserId.Set( _T( "" ) );
		pConnection_Local->m_DMSParameters.m_strPassword.Set( _T( "" ) );
		pConnection_Local->m_DMSParameters.m_strServerURL.Set(_T(""));
		pConnection_Local->m_DMSParameters.m_lTcpipPort.Set( 0 );
		pConnection_Local->m_DMSParameters.m_lLoginType.Set(0);
		pConnection_Local->m_DMSParameters.m_strDefaultPassword.Set( _T( "" ) );
		pConnection_Local->m_DMSParameters.m_bDefaultPasswordNeverExpires.Set( false );
		pConnection_Local->m_DMSParameters.m_bDefaultPasswordMustBeChanged.Set( true );

		pConnection_Local->m_DSParameters.m_strServerName.Set( _T( "" ) );
		pConnection_Local->m_DSParameters.m_strUserId.Set( _T( "" ) );
		pConnection_Local->m_DSParameters.m_strPassword.Set( _T( "" ) );
		pConnection_Local->m_DSParameters.m_lServiceType.Set( 0 );
		pConnection_Local->m_DSParameters.m_lTcpipPort.Set( 389 );
		pConnection_Local->m_DSParameters.m_strContext.Set( _T( "" ) );
		pConnection_Local->m_strExternalDNList.Set( _T( "" ) );
		pConnection_Local->m_DSParameters.m_strTreeID.Set( _T( "" ) );


		DSConnection dlg( this );
		dlg.m_strServer = m_strServer;
		dlg.m_Mode = DSConnection::Add;
		dlg.SetRegistryObjects( pSyncSvc_Local, pConnection_Local );
		if( dlg.DoModal( ) == IDOK )
		{
			UpdateRegistryPaths( pConnection_Local );
			pConnection_Local->StoreInRegistry();			
			AddConnectionToList( pConnection_Local);
		}
		else
		{
			delete pConnection_Local;
		}
		delete pSyncSvc_Temp;
		delete pSyncSvc_Local;		
	}

	m_list.SetFocus();
	POSITION pos = m_list.GetFirstSelectedItemPosition( );
	if( pos == NULL )
		EnableButtons( FALSE );
	else
		EnableButtons( TRUE );
}

void DSConnections::SetRegistryObject( IM::CDSSyncSvc* pSyncSvc )
{
	if( pSyncSvc != NULL )
	{
		m_pSyncSvc_Remote = pSyncSvc;

		if( m_pSyncSvc_Local != NULL )
			delete m_pSyncSvc_Local;

		m_pSyncSvc_Local = new IM::CDSSyncSvc( *m_pSyncSvc_Remote );
		//m_pSyncSvc_Local = new IM::CDSSyncSvc( m_pSyncSvc_Remote->GetComputerName( ).c_str( ) );

		/*
		{
			IM::CDSSyncSvc::CONNECTIONLIST::const_iterator iterEnd = m_pSyncSvc_Remote->m_ConnectionList.end( );
			for( IM::CDSSyncSvc::CONNECTIONLIST::const_iterator iter = m_pSyncSvc_Remote->m_ConnectionList.begin( ); iter != iterEnd; iter++ )
			{
				IM::CDSSyncSvc_Connection* pConnection = *iter;
				if( pConnection != NULL )
				{
					IM::CDSSyncSvc_Connection* pConnection_Local = new IM::CDSSyncSvc_Connection( pConnection->GetComputerName( ).c_str( ), pConnection->GetDesiredHive( ), pConnection->GetBaseKeyPath( ).c_str( ) );

					pConnection_Local->m_strName.Set( pConnection->m_strName.Get( ).c_str( ) );
					pConnection_Local->m_strNode.Set( pConnection->m_strNode.Get( ).c_str( ) ); 
					pConnection_Local->m_strAttributeMapName.Set( pConnection->m_strAttributeMapName.Get( ).c_str( ) );

					pConnection_Local->m_DMSParameters.m_strDms.Set( pConnection->m_DMSParameters.m_strDms.Get( ).c_str( ) );
					pConnection_Local->m_DMSParameters.m_strLibrary.Set( pConnection->m_DMSParameters.m_strLibrary.Get( ).c_str( ) );
					pConnection_Local->m_DMSParameters.m_strUserId.Set( pConnection->m_DMSParameters.m_strUserId.Get( ).c_str( ) );
					pConnection_Local->m_DMSParameters.m_strPassword.Set( pConnection->m_DMSParameters.m_strPassword.Get( ).c_str( ) );
					pConnection_Local->m_DMSParameters.m_lTcpipPort.Set( pConnection->m_DMSParameters.m_lTcpipPort.Get( ) );
					pConnection_Local->m_DMSParameters.m_strDefaultPassword.Set( pConnection->m_DMSParameters.m_strDefaultPassword.Get( ).c_str( ) );
					pConnection_Local->m_DMSParameters.m_bDefaultPasswordNeverExpires.Set( pConnection->m_DMSParameters.m_bDefaultPasswordNeverExpires.Get( ) );
					pConnection_Local->m_DMSParameters.m_bDefaultPasswordMustBeChanged.Set( pConnection->m_DMSParameters.m_bDefaultPasswordMustBeChanged.Get( ) );

					pConnection_Local->m_DSParameters.m_strServerName.Set( pConnection->m_DSParameters.m_strServerName.Get( ).c_str( ) );
					pConnection_Local->m_DSParameters.m_strUserId.Set( pConnection->m_DSParameters.m_strUserId.Get( ).c_str( ) );
					pConnection_Local->m_DSParameters.m_strPassword.Set( pConnection->m_DSParameters.m_strPassword.Get( ).c_str( ) );
					pConnection_Local->m_DSParameters.m_lServiceType.Set( pConnection->m_DSParameters.m_lServiceType.Get( ) );
					pConnection_Local->m_DSParameters.m_lTcpipPort.Set( pConnection->m_DSParameters.m_lTcpipPort.Get( ) );
					pConnection_Local->m_DSParameters.m_strContext.Set( pConnection->m_DSParameters.m_strContext.Get( ).c_str( ) );

					m_pSyncSvc_Local->AddConnection( pConnection_Local );
				}
			}
		}

		{
			IM::CDSSyncSvc::ATTRIBUTEMAPLIST::const_iterator iterEnd = m_pSyncSvc_Remote->m_AttributeMapList.end( );
			for( IM::CDSSyncSvc::ATTRIBUTEMAPLIST::const_iterator iter = m_pSyncSvc_Remote->m_AttributeMapList.begin( ); iter != iterEnd; iter++ )
			{
				IM::CDSSyncSvc_AttributeMap* pAttributeMap = *iter;
				if( pAttributeMap != NULL )
				{
					IM::CDSSyncSvc_AttributeMap* pAttributeMap_Local = new IM::CDSSyncSvc_AttributeMap( pAttributeMap->GetComputerName( ).c_str( ), pAttributeMap->GetDesiredHive( ), pAttributeMap->GetBaseKeyPath( ).c_str( ) );

					pAttributeMap_Local->m_strMapName.Set( pAttributeMap->m_strMapName.Get( ).c_str( ) );
					pAttributeMap_Local->m_strOUName.Set( pAttributeMap->m_strOUName.Get( ).c_str( ) );
					pAttributeMap_Local->m_strUserName.Set( pAttributeMap->m_strUserName.Get( ).c_str( ) );
					pAttributeMap_Local->m_strUserId.Set( pAttributeMap->m_strUserId.Get( ).c_str( ) );
					pAttributeMap_Local->m_strUserEmail.Set( pAttributeMap->m_strUserEmail.Get( ).c_str( ) );
					pAttributeMap_Local->m_strUserFax.Set( pAttributeMap->m_strUserFax.Get( ).c_str( ) );
					pAttributeMap_Local->m_strUserTelephone.Set( pAttributeMap->m_strUserTelephone.Get( ).c_str( ) );
					pAttributeMap_Local->m_strUserLocation.Set( pAttributeMap->m_strUserLocation.Get( ).c_str( ) );
					pAttributeMap_Local->m_strUserEnabled.Set( pAttributeMap->m_strUserEnabled.Get( ).c_str( ) );
					pAttributeMap_Local->m_strGroupName.Set( pAttributeMap->m_strGroupName.Get( ).c_str( ) );
					pAttributeMap_Local->m_strGroupId.Set( pAttributeMap->m_strGroupId.Get( ).c_str( ) );
					pAttributeMap_Local->m_strGroupMember.Set( pAttributeMap->m_strGroupMember.Get( ).c_str( ) );
					pAttributeMap_Local->m_strK1SyncId.Set( pAttributeMap->m_strK1SyncId.Get( ).c_str( ) );

					m_pSyncSvc_Local->AddAttributeMap( pAttributeMap_Local );
				}
			}
		}
		*/
	}
}

void DSConnections::InitListControl( void )
{
	CRect rcList;
	m_list.GetClientRect( rcList );

	int iListWidth = rcList.Width( );
	int iScrollThumbWidth = ::GetSystemMetrics( SM_CXHTHUMB );

	CString strWidthTest = _T( "descending" );
	int iStrWidth = m_list.GetStringWidth( strWidthTest );

	// factor the border width into the string width
	iStrWidth += 12 * ::GetSystemMetrics( SM_CXBORDER );

	m_list.InsertColumn( 1, _T( "Name" ), LVCFMT_LEFT, iStrWidth + iScrollThumbWidth, 1 );
	m_list.InsertColumn( 2, _T( "Library" ), LVCFMT_LEFT, iStrWidth + iScrollThumbWidth, 2 );	
	m_list.InsertColumn( 3, _T( "CN" ), LVCFMT_LEFT, iListWidth - 2*( iScrollThumbWidth + iStrWidth ), 3 );	
 
	DWORD dwStyle =  (DWORD) m_list.SendMessage( LVM_GETEXTENDEDLISTVIEWSTYLE, 0, 0 );
	dwStyle |=  LVS_EX_FULLROWSELECT;
	m_list.SendMessage( LVM_SETEXTENDEDLISTVIEWSTYLE, 0, dwStyle );
}

void DSConnections::AddConnectionToList( IM::CDSSyncSvc_Connection* pConnection )
{
	LV_ITEM lvItem;
	lvItem.mask = LVIF_TEXT;

	// add name in the first column
	lvItem.pszText = ( LPTSTR ) ( LPCTSTR ) pConnection->m_strName.Get( ).c_str( );
	lvItem.iItem = m_list.GetItemCount( );
	lvItem.iSubItem = 0;
	int iPos = m_list.InsertItem( &lvItem );
	m_list.SetItemData( iPos, ( DWORD ) pConnection );	// use pointer as data

	// add library as a "subitem" in the 2nd column
	lvItem.iSubItem = 1;
	lvItem.pszText = ( LPTSTR ) ( LPCTSTR ) pConnection->m_DMSParameters.m_strLibrary.Get( ).c_str( );
	lvItem.iItem = iPos;
	m_list.SetItem( &lvItem );

	// add CN as a "subitem" in the 3rd column

	// TODO: Need to pull just the CN value out of the full DN

	lvItem.iSubItem = 2;
	if( pConnection->m_DSParameters.m_lServiceType.Get( ) == IM::CDSSyncSvc_DSParameters::NT )
		lvItem.pszText = ( LPTSTR ) ( LPCTSTR ) pConnection->m_DSParameters.m_strServerName.Get( ).c_str( );
	else
		lvItem.pszText = ( LPTSTR ) ( LPCTSTR ) pConnection->m_strNode.Get( ).c_str( );
	lvItem.iItem = iPos;
	m_list.SetItem( &lvItem );
}

void DSConnections::AddAllConnectionsToList()
{
	IM::CDSSyncSvc* pSyncSvc_Local = new IM::CDSSyncSvc(m_strServer);
	pSyncSvc_Local->LoadFromRegistry();
	
	if( pSyncSvc_Local != NULL )
	{
		m_list.DeleteAllItems( );

		for( IM::CDSSyncSvc::CONNECTIONLIST::const_iterator iter = pSyncSvc_Local->m_ConnectionList.begin( ); iter != pSyncSvc_Local->m_ConnectionList.end( ); iter++ )
		{
			IM::CDSSyncSvc_Connection* pConnection = *iter;
			CString connectionName = pConnection->m_strName.Get( ).c_str();
			if(( pConnection != NULL ) && (connectionName != ""))
			{
				AddConnectionToList( pConnection );
			}
		}
	}
	delete pSyncSvc_Local;
	
}
void DSConnections::AddConnectionsFromRegistryObject( void )
{
	if( m_pSyncSvc_Local != NULL )
	{
		m_list.DeleteAllItems( );

		for( IM::CDSSyncSvc::CONNECTIONLIST::const_iterator iter = m_pSyncSvc_Local->m_ConnectionList.begin( ); iter != m_pSyncSvc_Local->m_ConnectionList.end( ); iter++ )
		{
			IM::CDSSyncSvc_Connection* pConnection = *iter;
			if( pConnection != NULL )
			{
				AddConnectionToList( pConnection );
			}
		}
	}
}

void DSConnections::OnHelp() 
{	
	::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, 55);
}

void DSConnections::EnableButtons( const BOOL bEnable )
{
	m_btnEdit.EnableWindow( bEnable );
	m_btnDelete.EnableWindow( bEnable );
	m_btnCopy.EnableWindow( bEnable );
	m_btnAdd.EnableWindow( TRUE );
	m_btnClear.EnableWindow( TRUE );
}


void DSConnections::OnClickListConnections(NMHDR* pNMHDR, LRESULT* pResult) 
{
	POSITION pos = m_list.GetFirstSelectedItemPosition( );
	if( pos == NULL )
		EnableButtons( FALSE );
	else
		EnableButtons( TRUE );

	*pResult = 0;
}

int Round( double x )
{
	return ( x-(int)x >= 0.5 ) ? 1+(int)x : int(x);
}

void DSConnections::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);

	if( !IsWindow( m_btnHelp.m_hWnd ) )
		return;

	DoSize( cx, cy );	
}

void DSConnections::DoSize( int cx, int cy )
{
	CRect rcList;
	CRect rcBtnOk;
	CRect rcBtnHelp;
	CRect rcBtnAdd;
	CRect rcBtnEdit;
	CRect rcBtnCopy;
	CRect rcBtnDelete;
	CRect rcBtnClear;

	m_list.GetWindowRect( rcList );
	ScreenToClient( rcList );

	m_btnOk.GetWindowRect( rcBtnOk );
	ScreenToClient( rcBtnOk );

	m_btnHelp.GetWindowRect( rcBtnHelp );
	ScreenToClient( rcBtnHelp );

	m_btnAdd.GetWindowRect( rcBtnAdd );
	ScreenToClient( rcBtnAdd );

	m_btnEdit.GetWindowRect( rcBtnEdit );
	ScreenToClient( rcBtnEdit );

	m_btnCopy.GetWindowRect( rcBtnCopy );
	ScreenToClient( rcBtnCopy );

	m_btnDelete.GetWindowRect( rcBtnDelete );
	ScreenToClient( rcBtnDelete );

	m_btnClear.GetWindowRect( rcBtnClear );
	ScreenToClient( rcBtnClear );

	int iListWidth = cx - 2*rcList.left - rcBtnOk.Width( );
	int iListHeight = cy - rcList.top - rcBtnAdd.Height( ) - 10;
	m_list.MoveWindow( rcList.left, rcList.top, iListWidth, iListHeight );

	int iLeftX = cx - rcBtnOk.Width( ) - 5;
	m_btnOk.MoveWindow( iLeftX, 0, rcBtnOk.Width( ), rcBtnOk.Height( ) );
	m_btnHelp.MoveWindow( iLeftX, rcBtnOk.Height( ) + 5, rcBtnHelp.Width( ), rcBtnHelp.Height( ) );

	int iBottomY = cy - rcBtnAdd.Height( ) - 5;
	m_btnAdd.MoveWindow( rcBtnAdd.left, iBottomY, rcBtnAdd.Width( ), rcBtnAdd.Height( ) );
	m_btnEdit.MoveWindow( rcBtnEdit.left, iBottomY, rcBtnEdit.Width( ), rcBtnEdit.Height( ) );
	m_btnCopy.MoveWindow( rcBtnCopy.left, iBottomY, rcBtnCopy.Width( ), rcBtnCopy.Height( ) );
	m_btnDelete.MoveWindow( rcBtnDelete.left, iBottomY, rcBtnDelete.Width( ), rcBtnDelete.Height( ) );
	m_btnClear.MoveWindow( rcBtnClear.left, iBottomY, rcBtnClear.Width( ), rcBtnClear.Height( ) );
}

void DSConnections::OnGetMinMaxInfo( MINMAXINFO FAR* lpMMI )
{
	if( lpMMI != NULL )
	{
		lpMMI->ptMinTrackSize.x = 350;
		lpMMI->ptMinTrackSize.y = 150;
	}
}


void DSConnections::OnButtonClear() 
{
	if( AfxMessageBox( _T( "Do you want to clear all connections?" ), MB_YESNO ) != IDYES )
		return;

	IM::CDSSyncSvc* pSyncSvc_Temp = new IM::CDSSyncSvc(m_strServer);			
	IM::CDSSyncSvc* pSyncSvc_Local = new IM::CDSSyncSvc(m_strServer);
	pSyncSvc_Local->LoadFromRegistry();
	
	if(pSyncSvc_Local!= NULL)
	{		
		IM::CDSSyncSvc_Connection* pConnection_Local;
	
		for( IM::CDSSyncSvc::CONNECTIONLIST::const_iterator iter = pSyncSvc_Local->m_ConnectionList.begin( ); iter != pSyncSvc_Local->m_ConnectionList.end( ); iter++ )
		{
			pConnection_Local = new IM::CDSSyncSvc_Connection( pSyncSvc_Local->GetComputerName( ).c_str( ), pSyncSvc_Local->GetDesiredHive( ), pSyncSvc_Local->GetBaseKeyPath( ).c_str( ) );

			IM::CDSSyncSvc_Connection* pConnection = *iter;
			if( pConnection != NULL )
			{	
				UpdateConnection( pConnection_Local,pConnection);
				UpdateRegistryPaths( pConnection_Local );
				pSyncSvc_Temp->AddConnection( pConnection_Local);
			}
		}
		pSyncSvc_Temp->DeleteFromRegistry();
	}
	delete pSyncSvc_Temp;
	delete pSyncSvc_Local;

	m_list.DeleteAllItems();
	m_list.SetFocus();
	POSITION pos = m_list.GetFirstSelectedItemPosition( );
	if( pos == NULL )
		EnableButtons( FALSE );
	else
		EnableButtons( TRUE );
}

void DSConnections::OnClose() 
{

	CDialog::OnClose();	
}

BOOL DSConnections::OnHelpInfo(HELPINFO* pHelpInfo) 
{
	// TODO: Add your message handler code here and/or call default
	
	return CDialog::OnHelpInfo(pHelpInfo);
}


