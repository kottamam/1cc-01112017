// CMSServiceProperties.cpp : implementation file
//

#include "stdafx.h"
#include "imsvcmgr.h"
#include "CMSServiceProperties.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCMSServiceProperties dialog
const int CHECKED_YES	=1;
const int CHECKED_NO	=0;


CCMSServiceProperties::CCMSServiceProperties(CWnd* pParent /*=NULL*/)
	: CDialog(CCMSServiceProperties::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCMSServiceProperties)
	m_strEditCluster = _T("");
	m_strTempFileName = _T("");
	m_lFilePort = 0;
	m_lSvcPort = 0;
	//}}AFX_DATA_INIT
}


void CCMSServiceProperties::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCMSServiceProperties)
	DDX_Text(pDX, IDC_EDIT_CLUSTER_NAME, m_strEditCluster);
	DDX_Text(pDX, IDC_EDIT_TEMP_FILES, m_strTempFileName);
	DDX_Text(pDX, IDC_CMS_FILE_PORT, m_lFilePort);
	DDX_Text(pDX, IDC_CMS_SERVICE_PORT, m_lSvcPort);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCMSServiceProperties, CDialog)
	//{{AFX_MSG_MAP(CCMSServiceProperties)
	ON_BN_CLICKED(IDC_CMS_GIVEN_FILE_PORT, OnGivenFilePort)
	ON_BN_CLICKED(IDC_CMS_GIVEN_SERV_PORT, OnGivenServPort)
	ON_EN_CHANGE(IDC_CMS_SERVICE_PORT, OnChange)
	ON_EN_CHANGE(IDC_CMS_FILE_PORT, OnChange)
	ON_EN_CHANGE(IDC_EDIT_TEMP_FILES, OnChange)
	ON_EN_CHANGE(IDC_EDIT_CLUSTER_NAME, OnChange)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCMSServiceProperties message handlers

BOOL CCMSServiceProperties::OnInitDialog() 
{
	CDialog::OnInitDialog();	
	m_pService->LoadFromRegistry();

	m_strEditCluster	= m_pService->m_strClusterName.Get().c_str();
	m_strTempFileName	= m_pService->m_strFileManagerTempDirectory.Get().c_str();
	m_lFilePort			= m_pService->m_lFilePort.Get();
	m_lSvcPort			= m_pService->m_lServicePort.Get();
	
	UpdateData(FALSE);
	
	((CButton*)GetDlgItem(IDC_CMS_GIVEN_SERV_PORT))->SetCheck(CHECKED_NO);
	((CButton*)GetDlgItem(IDC_CMS_GIVEN_FILE_PORT))->SetCheck(CHECKED_NO);
	((CEdit*)GetDlgItem(IDC_CMS_SERVICE_PORT))->EnableWindow(FALSE);
	((CEdit*)GetDlgItem(IDC_CMS_FILE_PORT))->EnableWindow(FALSE);

	IM::NrString aCaption = BuildCaption(IDS_PROP_110, m_pService->m_strServiceDisplayName.c_str(), m_pService->m_strComputerName.c_str());
	SetWindowText(aCaption.c_str());
	GetDlgItem(IDOK)->EnableWindow(FALSE);
	SetDefID(IDCANCEL);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CCMSServiceProperties::OnGivenFilePort() 
{
	if(((CButton*)GetDlgItem(IDC_CMS_GIVEN_FILE_PORT))->GetCheck() == CHECKED_YES)
	{
		((CEdit*)GetDlgItem(IDC_CMS_FILE_PORT))->EnableWindow(TRUE);
	}
	else
		((CEdit*)GetDlgItem(IDC_CMS_FILE_PORT))->EnableWindow(FALSE);
}

void CCMSServiceProperties::OnGivenServPort() 
{
	if(((CButton*)GetDlgItem(IDC_CMS_GIVEN_SERV_PORT))->GetCheck() == CHECKED_YES)
	{
		((CEdit*)GetDlgItem(IDC_CMS_SERVICE_PORT))->EnableWindow(TRUE);
	}
	else
		((CEdit*)GetDlgItem(IDC_CMS_SERVICE_PORT))->EnableWindow(FALSE);
}

void CCMSServiceProperties::OnOK() 
{
	UpdateData(TRUE);
	
	m_pService->m_strClusterName.Set(m_strEditCluster); 
	if(m_lSvcPort < 0)
	{
		if(((CButton*)GetDlgItem(IDC_CMS_GIVEN_FILE_PORT))->GetCheck() == CHECKED_YES)
		{
			Report(REP_WARN, IDS_DMSPROP_250);
			return;	
		}
		else
			m_pService->m_lServicePort.Set(0); 
	}
	else
	{
		m_pService->m_lServicePort.Set(m_lSvcPort); 
	}
	if(m_lFilePort < 0 )
	{
		if(((CButton*)GetDlgItem(IDC_CMS_GIVEN_FILE_PORT))->GetCheck() == CHECKED_YES)
		{
			Report(REP_WARN, IDS_DMSPROP_251);
			return;
		}
		else
			m_pService->m_lFilePort.Set(0);
	}
	else
	{
		m_pService->m_lFilePort.Set(m_lFilePort);
	}
	
	
	m_pService->m_strFileManagerTempDirectory.Set(m_strTempFileName);
	
	m_pService->m_lVerifyLevel.Set(1);
	m_pService->StoreInRegistry();

	CDialog::OnOK();
}

void CCMSServiceProperties::OnChange() 
{
	GetDlgItem(IDOK)->EnableWindow(TRUE);
	SetDefID(IDOK);
}
