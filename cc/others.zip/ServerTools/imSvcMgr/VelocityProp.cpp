// VelocityProp.cpp : implementation file
//

#include "stdafx.h"
#include "imsvcmgr.h"
#include "VelocityProp.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// VelocityProp dialog

VelocityProp::VelocityProp(IM::DmsDatabaseEntry	*pEntry_, CWnd* pParent)
	: CDialog(VelocityProp::IDD, pParent)
{
	//{{AFX_DATA_INIT(VelocityProp)
	m_pEntry = pEntry_;

	m_strServer = _T("");
	m_strSource = _T("");

	m_strRepUser = _T("");
	m_strRepPassword = _T("");

	m_bHTTPS = FALSE;
	m_strHTTPDomain = _T("");
	m_strHTTPUser = _T("");
	m_strHTTPPassword = _T("");
	//}}AFX_DATA_INIT
}

void VelocityProp::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(VelocityProp)
	DDX_Text(pDX, IDC_SERVER, m_strServer);
	DDX_Text(pDX, IDC_SOURCE, m_strSource);
	DDX_Text(pDX, IDC_REP_USER, m_strRepUser);
	DDX_Text(pDX, IDC_REP_PASSWORD, m_strRepPassword);
	DDX_Check(pDX, IDC_HTTP_ENABLESECURITY, m_bHTTPS);
	DDX_Text(pDX, IDC_HTTP_DOMAIN, m_strHTTPDomain);
	DDX_Text(pDX, IDC_HTTP_USER, m_strHTTPUser);
	DDX_Text(pDX, IDC_HTTP_PASSWORD, m_strHTTPPassword);
	DDX_Control(pDX, IDC_PRODUCT, m_cboIdxProduct);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(VelocityProp, CDialog)
	//{{AFX_MSG_MAP(VelocityProp)
	ON_EN_CHANGE(IDC_CLUSTER_NAME, OnChange)
	ON_EN_CHANGE(IDC_SERVER, OnChange)
	ON_EN_CHANGE(IDC_SOURCE, OnChange)
	ON_EN_CHANGE(IDC_REP_USER, OnChange)
	ON_EN_CHANGE(IDC_REP_PASSWORD, OnChange)
	ON_BN_CLICKED(IDC_HTTP_ENABLESECURITY, OnChange)
	ON_EN_CHANGE(IDC_HTTP_DOMAIN, OnChange)
	ON_EN_CHANGE(IDC_HTTP_USER, OnChange)
	ON_EN_CHANGE(IDC_HTTP_PASSWORD, OnChange)
	ON_BN_CLICKED(IDHELP, OnHelp)
	ON_CBN_SELCHANGE(IDC_PRODUCT, OnChange)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// VelocityProp message handlers

BOOL VelocityProp::OnInitDialog()
{
	CDialog::OnInitDialog();

	//
	// Get Velocity configuration information for this database and display
	//
	if (m_pEntry == NULL)
	{
	    Report(REP_WARN, IDS_DBPROP_115);
	    SendMessage(WM_CLOSE);
	    return TRUE;
	}

	m_strServer = m_pEntry->m_strIndexSourceServer.Get().c_str();
	m_strSource = m_pEntry->m_strIndexSource.Get().c_str();
	m_strRepUser = m_pEntry->m_strIndexRepUser.Get().c_str();
	m_strRepPassword = m_pEntry->m_strIndexRepPassword.Get().c_str();
	m_bHTTPS = m_pEntry->m_bIndexHTTPS.Get();
	m_strHTTPDomain = m_pEntry->m_strIndexHTTPDomain.Get().c_str();
	m_strHTTPUser = m_pEntry->m_strIndexHTTPUser.Get().c_str();
	m_strHTTPPassword = m_pEntry->m_strIndexHTTPPassword.Get().c_str();
	//Added today
	m_strProduct = m_pEntry->m_strIndexProduct.Get().c_str();
	
	m_cboIdxProduct.AddString(_T("UniversalSearch"));
	m_cboIdxProduct.AddString(_T("IUS"));
	//
	// Allow OK button only after a change
	//
	GetDlgItem(IDC_SERVER)->SetWindowText(m_strServer);
	GetDlgItem(IDC_SOURCE)->SetWindowText(m_strSource);
	GetDlgItem(IDC_REP_USER)->SetWindowText(m_strRepUser);
	GetDlgItem(IDC_REP_PASSWORD)->SetWindowText(m_strRepPassword);
	((CButton*)GetDlgItem(IDC_HTTP_ENABLESECURITY))->SetCheck(m_bHTTPS);
	GetDlgItem(IDC_HTTP_DOMAIN)->SetWindowText(m_strHTTPDomain);
	GetDlgItem(IDC_HTTP_USER)->SetWindowText(m_strHTTPUser);
	GetDlgItem(IDC_HTTP_PASSWORD)->SetWindowText(m_strHTTPPassword);
	
	if((m_strProduct.CompareNoCase(_T("UniversalSearch")) == 0) ||(m_strProduct.IsEmpty()))
	{
		//set the combo selection to universalsearch
		m_cboIdxProduct.SetCurSel(0);
	}
	//otherwise set to IUS
	else
	{
		m_cboIdxProduct.SetCurSel(1);
	}

	GetDlgItem(IDOK)->EnableWindow(false);
	SetDefID(IDCANCEL);

	return(TRUE);
}

#define FHASH _T("/")
#define BHASH _T("\\")
#define COLON _T(":")

void VelocityProp::OnOK()
{
	GetDlgItem(IDC_SERVER)->GetWindowText(m_strServer);
	GetDlgItem(IDC_SOURCE)->GetWindowText(m_strSource);
	GetDlgItem(IDC_REP_USER)->GetWindowText(m_strRepUser);
	GetDlgItem(IDC_REP_PASSWORD)->GetWindowText(m_strRepPassword);
	m_bHTTPS = ((CButton*)GetDlgItem(IDC_HTTP_ENABLESECURITY))->GetCheck();
	GetDlgItem(IDC_HTTP_DOMAIN)->GetWindowText(m_strHTTPDomain);
	GetDlgItem(IDC_HTTP_USER)->GetWindowText(m_strHTTPUser);
	GetDlgItem(IDC_HTTP_PASSWORD)->GetWindowText(m_strHTTPPassword);
	//Added today
	int selProduct = m_cboIdxProduct.GetCurSel();
	if(selProduct == 0)
		m_strProduct = "UniversalSearch";
	if(selProduct == 1)
		m_strProduct = "IUS";

	m_pEntry->m_strIndexSourceServer.Set(m_strServer);
	m_pEntry->m_strIndexSource.Set(m_strSource);
	m_pEntry->m_strIndexRepUser.Set(m_strRepUser);
	m_pEntry->m_strIndexRepPassword.Set(m_strRepPassword);
	m_pEntry->m_bIndexHTTPS.Set(m_bHTTPS ? true : false);
	m_pEntry->m_strIndexHTTPDomain.Set(m_strHTTPDomain);
	m_pEntry->m_strIndexHTTPUser.Set(m_strHTTPUser);
	m_pEntry->m_strIndexHTTPPassword.Set(m_strHTTPPassword);
	//Added today
	m_pEntry->m_strIndexProduct.Set(m_strProduct);

	IM::NrString strServerUserPwd(_T(""));

	strServerUserPwd += m_strHTTPDomain.GetBuffer(m_strHTTPDomain.GetLength());
	strServerUserPwd += BHASH;
	strServerUserPwd += m_strHTTPUser.GetBuffer(m_strHTTPUser.GetLength());
	strServerUserPwd += COLON;
	strServerUserPwd += m_strHTTPPassword.GetBuffer(m_strHTTPPassword.GetLength());

	m_pEntry->m_strIndexServerUserPwd.Set(strServerUserPwd.c_str());

	CDialog::OnOK();
}

void VelocityProp::OnChange()
{
	CString strServer;
	CString strSource;
	CString strRepUser;
	CString strRepPassword;

	GetDlgItem(IDC_SERVER)->GetWindowText(strServer);
	GetDlgItem(IDC_SOURCE)->GetWindowText(strSource);
	GetDlgItem(IDC_REP_USER)->GetWindowText(strRepUser);
	GetDlgItem(IDC_REP_PASSWORD)->GetWindowText(strRepPassword);

	if(strServer.IsEmpty() || strSource.IsEmpty() || strRepUser.IsEmpty() || strRepPassword.IsEmpty())
	{
		GetDlgItem(IDOK)->EnableWindow(false);
		SetDefID(IDCANCEL);
	}
	else
	{
		GetDlgItem(IDOK)->EnableWindow(true);
		SetDefID(IDOK);
	}
}

void VelocityProp::OnHelp() 
{	
	::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, CONFIGURING_INDEXER_CONNECTION_PROPERTIES);
}