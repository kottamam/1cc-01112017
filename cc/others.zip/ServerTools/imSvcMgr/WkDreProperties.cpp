// WkDreProperties.cpp : implementation file
//

#include "stdafx.h"
#include "imsvcmgr.h"
#include "WkDreProperties.h"
#include <Report\Report.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// WkDreProperties dialog


WkDreProperties::WkDreProperties(CWnd* pParent /*=NULL*/)
	: CDialog(WkDreProperties::IDD, pParent),
	m_strDreIniFilePath(_T("")),
	m_bWsSpecifyServicePort(FALSE),
	m_bWkEnable(FALSE),
	m_strWsServicePort(_T("1080")),
	m_strIndexPort(_T("1084")),
	m_strQueryPort(_T("1083")),
	m_strWorkSite(_T(""))

{
	//{{AFX_DATA_INIT(WkDreProperties)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void WkDreProperties::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(WkDreProperties)
	DDX_Check(pDX, IDC_WKDRE_CHECK_SERVICEPORT, m_bWsSpecifyServicePort);
	DDX_Check(pDX, IDC_WKDRE_CHECK_ENABLESECURITY, m_bWkEnable);
	DDX_Text(pDX, IDC_WKDRE_EDIT_SERVER, m_strWorkSite);
	DDX_Text(pDX, IDC_WKDRE_EDIT_SERVICEPORT, m_strWsServicePort);
	DDX_Text(pDX, IDC_WKDRE_EDIT_INDEXPORT, m_strIndexPort);
	DDX_Text(pDX, IDC_WKDRE_EDIT_QUERYPORT, m_strQueryPort);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(WkDreProperties, CDialog)
	//{{AFX_MSG_MAP(WkDreProperties)
	ON_EN_CHANGE(IDC_WKDRE_EDIT_SERVER, OnChange)
	ON_BN_CLICKED(IDC_WKDRE_CHECK_ENABLESECURITY, OnCheckEnableSecurity)
	ON_BN_CLICKED(IDC_WKDRE_CHECK_SERVICEPORT, OnCheckServicePort)
	ON_BN_CLICKED(IDC_WKDRE_BUTTON_VIEWLOG, OnWkdreButtonViewlog)
	ON_EN_CHANGE(IDC_WKDRE_EDIT_SERVICEPORT, OnChange)
	ON_EN_CHANGE(IDC_WKDRE_EDIT_INDEXPORT, OnChange)
	ON_EN_CHANGE(IDC_WKDRE_EDIT_QUERYPORT, OnChange)
	ON_BN_CLICKED(IDHELP, OnHelp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// WkDreProperties message handlers
BOOL WkDreProperties::OnInitDialog() 
{
	// load values from registry
	m_pService->LoadFromRegistry();

	m_strDreIniFilePath = m_pService->m_strDreIniFilePath.Get().c_str();
	m_bWkEnable = m_pService->m_bWkEnable.Get();
	m_bWsSpecifyServicePort = m_pService->m_bWsSpecifyServicePort.Get();
	char szWsServicePort[64];
	sprintf(szWsServicePort, "%d", m_pService->m_lWsServicePort.Get());
	m_strWsServicePort = szWsServicePort;
	m_strWorkSite = m_pService->m_strWorkSite.Get().c_str();

	char szInt[11];
	ltoa(m_pService->m_lDreIndexPort.Get(), szInt, 10);
	m_strIndexPort = szInt;
	ltoa(m_pService->m_lDreQueryPort.Get(), szInt, 10);
	m_strQueryPort = szInt;

	// initialize window
	GetDlgItem(IDOK)->EnableWindow(0);
	SetDefID(IDCANCEL);

	if (m_bWkEnable)
	{
		GetDlgItem(IDC_WKDRE_EDIT_SERVER)->EnableWindow(TRUE);
		GetDlgItem(IDC_WKDRE_CHECK_SERVICEPORT)->EnableWindow(TRUE);
		if (m_bWsSpecifyServicePort)
		{
			GetDlgItem(IDC_WKDRE_EDIT_SERVICEPORT)->EnableWindow(TRUE);
		}
		else
		{
			GetDlgItem(IDC_WKDRE_EDIT_SERVICEPORT)->SetWindowText(_T(""));
			GetDlgItem(IDC_WKDRE_EDIT_SERVICEPORT)->EnableWindow(FALSE);
			m_strWsServicePort = _T("");
		}

		GetDlgItem(IDC_WKDRE_BUTTON_VIEWLOG)->EnableWindow(TRUE);
	}
	else
	{
		GetDlgItem(IDC_WKDRE_EDIT_SERVER)->EnableWindow(FALSE);
		GetDlgItem(IDC_WKDRE_CHECK_SERVICEPORT)->EnableWindow(FALSE);
		GetDlgItem(IDC_WKDRE_EDIT_SERVICEPORT)->EnableWindow(FALSE);
		GetDlgItem(IDC_WKDRE_BUTTON_VIEWLOG)->EnableWindow(FALSE);
	}

	CDialog::OnInitDialog();	

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void WkDreProperties::OnOK()
{
	UpdateData();

	// store values in registry
	m_pService->m_bWkEnable.Set((((CButton*)GetDlgItem(IDC_WKDRE_CHECK_ENABLESECURITY))->GetCheck() == 1));
	m_pService->m_bWsSpecifyServicePort.Set((((CButton*)GetDlgItem(IDC_WKDRE_CHECK_SERVICEPORT))->GetCheck() == 1));
	m_pService->m_lWsServicePort.Set(_ttol(m_strWsServicePort));
	m_pService->m_strWorkSite.Set(m_strWorkSite);
	m_pService->m_lDreIndexPort.Set(_ttol(m_strIndexPort));
	m_pService->m_lDreQueryPort.Set(_ttol(m_strQueryPort));

	try
	{
		m_pService->StoreInRegistry();
	}
	catch (IM::Exception &)
	{
	}

	CDialog::OnOK();
}


void WkDreProperties::OnChange() 
{
	GetDlgItem(IDOK)->EnableWindow();
	SetDefID(IDOK);
}

void WkDreProperties::OnCheckEnableSecurity() 
{
	OnChange();
	if (((CButton*)GetDlgItem(IDC_WKDRE_CHECK_ENABLESECURITY))->GetCheck() == 1)
	{
		GetDlgItem(IDC_WKDRE_EDIT_SERVER)->EnableWindow(TRUE);
		GetDlgItem(IDC_WKDRE_CHECK_SERVICEPORT)->EnableWindow(TRUE);

		if (((CButton*)GetDlgItem(IDC_WKDRE_CHECK_SERVICEPORT))->GetCheck() == 1)
		{
			GetDlgItem(IDC_WKDRE_EDIT_SERVICEPORT)->EnableWindow(TRUE);
		}
		else
		{
			GetDlgItem(IDC_WKDRE_EDIT_SERVICEPORT)->SetWindowText(_T(""));
			GetDlgItem(IDC_WKDRE_EDIT_SERVICEPORT)->EnableWindow(FALSE);
			m_strWsServicePort = _T("");
		}

		GetDlgItem(IDC_WKDRE_BUTTON_VIEWLOG)->EnableWindow(TRUE);
	}
	else
	{
		GetDlgItem(IDC_WKDRE_EDIT_SERVER)->EnableWindow(FALSE);
		GetDlgItem(IDC_WKDRE_CHECK_SERVICEPORT)->EnableWindow(FALSE);
		GetDlgItem(IDC_WKDRE_EDIT_SERVICEPORT)->EnableWindow(FALSE);
		GetDlgItem(IDC_WKDRE_BUTTON_VIEWLOG)->EnableWindow(FALSE);
	}
}

void WkDreProperties::OnCheckServicePort() 
{
	OnChange();
	if (((CButton*)GetDlgItem(IDC_WKDRE_CHECK_SERVICEPORT))->GetCheck() == 1)
	{
		GetDlgItem(IDC_WKDRE_EDIT_SERVICEPORT)->EnableWindow(TRUE);
	}
	else
	{
		GetDlgItem(IDC_WKDRE_EDIT_SERVICEPORT)->SetWindowText(_T(""));
		GetDlgItem(IDC_WKDRE_EDIT_SERVICEPORT)->EnableWindow(FALSE);
		m_strWsServicePort = _T("");
	}
}

void WkDreProperties::OnWkdreButtonViewlog()
{
	const TCHAR	*szLogFile = m_pService->m_strLogPath.Get().c_str();

	STARTUPINFO	startUpInfo;
	PROCESS_INFORMATION	procInfo;
	IM::NrString commandLine;
	
	commandLine = _T("\"");
	commandLine += _T(".\\imLogView.exe ");
	GetStartupInfo(&startUpInfo);
	startUpInfo.wShowWindow = SW_SHOW;
	commandLine += m_pService->m_strLogPath.Get().c_str();

	//	Startup the log viewer application and pass it the file name
	if(::CreateProcess(_T(".\\imLogView.exe"), (_TCHAR *) commandLine.c_str(), 0, 0, TRUE, DETACHED_PROCESS, 0,0, &startUpInfo, &procInfo) == FALSE)
	{
		LastErrorString		errorString;

		Report(REP_WARN, IDS_MAIN_141, errorString.c_str());
		return;
	}
	::CloseHandle(procInfo.hProcess);
	::CloseHandle(procInfo.hThread);
}

void WkDreProperties::OnHelp() 
{	
	::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, 17);
}
