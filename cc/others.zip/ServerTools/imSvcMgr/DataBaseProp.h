#if !defined(AFX_DATABASEPROP_H__F6C40D65_DE09_11D2_8C54_00C04F68F9B3__INCLUDED_)
#define AFX_DATABASEPROP_H__F6C40D65_DE09_11D2_8C54_00C04F68F9B3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DataBaseProp.h : header file
//

//class DmsDatabaseList;

/////////////////////////////////////////////////////////////////////////////
// DataBaseProp dialog

class DataBaseProp : public CDialog
{
// Construction
public:
	DataBaseProp(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(DataBaseProp)
	enum { IDD = IDD_DB_PROPERTIES };
	CSpinButtonCtrl	m_spinDMSMaxRow;
	CSpinButtonCtrl	m_spinIdxConnection;
	CButton			m_ctlVerityConnection;
	CSpinButtonCtrl	m_SpinConnectionCount;
	CButton			m_UseDatabase;
	CButton			m_WebContent;
	CButton			m_Hidden;
	CButton			m_OdbcBrowse;
	CEdit			m_OdbcName;
	CString			m_DatabaseValue;
	CString			m_LogonID;
	CString			m_Password;
	CString			m_ConnectionCount;
	BOOL			m_Connections;
	int				m_nConnection;
	CComboBox		m_cboIdxSearch;
	CButton			m_btnConfigure;
	BOOL			m_bEnableCacheFile;
	CString			m_DigitalSafeURL;
	CString			m_DigitalSafeMailFrom;
	CString			m_DigitalSafeRcptTo;
	CString			m_DigitalSafeDomainName;
	CString			m_DigitalSafeSSLKeyFile;
	CString			m_DigitalSafeSSLKeyFilePassword;
	CString			m_DigitalSafeSSLCACert;
	CString			m_DigitalSafeSSLCAPath;
	//}}AFX_DATA
	IM::DatabaseEntryList	*m_pDatabaseList;
	IM::DmsDatabaseEntry	*m_pEntry;
	bool					m_bAllowPrimary;
	bool					m_bAllowWebContent;
    bool					m_bAddMode;
	CString					m_SavedOdbcName;
	long					m_lLocale;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(DataBaseProp)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(DataBaseProp)
	virtual BOOL OnInitDialog();
	afx_msg void OnOdbcBrowse();
	afx_msg void Changed();
	virtual void OnOK();
	afx_msg void OnHelp();
	afx_msg void OnEnableCacheFileserver();
	afx_msg void OnSelchangeComboIdxSearch();
	afx_msg void OnConfigure();
	afx_msg void OnAdvanced();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	bool needPrimaryDatabase();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DATABASEPROP_H__F6C40D65_DE09_11D2_8C54_00C04F68F9B3__INCLUDED_)

