#if !defined(AFX_DSNode2_H__9223C9BF_4E3D_47C7_9247_3CD4B414C248__INCLUDED_)
#define AFX_DSNode2_H__9223C9BF_4E3D_47C7_9247_3CD4B414C248__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DSNode2.h : header file
//

#include <registry/registry.h>


/////////////////////////////////////////////////////////////////////////////
// DSNode2 dialog

class DSNode2 : public CDialog
{
// Construction
public:
	DSNode2(CWnd* pParent = NULL);   // standard constructor
	virtual ~DSNode2( void );

	void SetRegistryObjects( IM::CDSSyncSvc* pSyncSvc, IM::CDSSyncSvc_Connection* pConnection );
	CString m_strServer;
	CString m_strNode;

// Dialog Data
	//{{AFX_DATA(DSNode2)
	enum { IDD = IDD_DS_NODE };
	CEdit	m_edtContainer;
	CEdit	m_edtSelectedDn;
	CListBox	m_lstContainer;
	CListCtrl	m_lstObjects;
	CButton	m_btnCancel;
	CButton	m_btnHelp;
	CButton	m_btnOk;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(DSNode2)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	IM::CDSSyncSvc* m_pSyncSvc_Local;
	IM::CDSSyncSvc_Connection* m_pConnection_Local;
	IM::CDSSyncSvc_AttributeMap* m_pAttributeMap_Local;

	// DS-related methods
	void LdapLogin( void );
	void LdapLogout( void );

	// DS-related members
	DSOM::CDSGeneric* m_pDSGeneric;
	_bstr_t m_strCurrentDn;
	DSOM::CDSDnMap m_ContainerDnMap;
	DSOM::CDSDnMap m_ObjectDnMap;

	// dlg methods
	void InitObjectsList( void );
	void EnableControls( const BOOL bEnable );
	void DoRefresh( void );
	void RefreshContainerList( void );
	void AddObjectToList( DSOM::CDSOrgUnit* pOrgUnit );

	// Generated message map functions
	//{{AFX_MSG(DSNode2)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnHelp();
	virtual void OnCancel();
	afx_msg void OnClickListObjects(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSelchangeListContainer();
	afx_msg void OnButtonLogin();
	afx_msg void OnButtonLogout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DSNode2_H__9223C9BF_4E3D_47C7_9247_3CD4B414C248__INCLUDED_)
