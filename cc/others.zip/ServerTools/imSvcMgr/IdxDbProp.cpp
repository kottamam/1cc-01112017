// IdxDbProp.cpp : implementation file
//

#include "stdafx.h"
#include "imSvcMgr.h"
#include "IdxDbProp.h"
#include "SelectODBC.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// IdxDbProp dialog


IdxDbProp::IdxDbProp(CWnd* pParent /*=NULL*/)
	: CDialog(IdxDbProp::IDD, pParent)
{
	//{{AFX_DATA_INIT(IdxDbProp)
	m_DatabaseValue = _T("");
	m_LogonID = _T("");
	m_Password = _T("");
	//}}AFX_DATA_INIT
}


void IdxDbProp::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(IdxDbProp)
	DDX_Control(pDX, IDC_BROWSE_IDX_DB, m_OdbcBrowse);
	DDX_Control(pDX, IDC_IDX_DB_NAME, m_OdbcName);
	DDX_Text(pDX, IDC_IDX_DB_NAME, m_DatabaseValue);
	DDX_Text(pDX, IDC_IDX_LOGONID, m_LogonID);
	DDX_Text(pDX, IDC_IDX_PASSWORD, m_Password);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(IdxDbProp, CDialog)
	//{{AFX_MSG_MAP(IdxDbProp)
	ON_BN_CLICKED(IDC_BROWSE_IDX_DB, OnBrowseIdxDb)
	ON_EN_CHANGE(IDC_IDX_LOGONID, OnChangeIdxLogonid)
	ON_EN_CHANGE(IDC_IDX_PASSWORD, OnChangeIdxPassword)
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDHELP, OnHelp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// IdxDbProp message handlers

void IdxDbProp::OnBrowseIdxDb() 
{
	SelectODBC aSelectODBCdlg;
	aSelectODBCdlg.m_pDatabaseList = m_pDatabaseList;

	if (aSelectODBCdlg.DoModal() == IDOK)
	{
		m_OdbcName.SetWindowText(aSelectODBCdlg.odbcSourceName.c_str());
		GetDlgItem(IDOK)->EnableWindow(true);
		SetDefID(IDOK);
	}
}

BOOL IdxDbProp::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	IM::DmsDatabaseEntry *pEntry;

	// if MODIFY
	if (m_DatabaseValue != "")
    {
    	m_OdbcName.EnableWindow(false);
        m_OdbcBrowse.EnableWindow(false);

		// Get repository information for this database and display
		pEntry = (IM::DmsDatabaseEntry *) m_pDatabaseList->Get((LPCTSTR)m_DatabaseValue);

		if (pEntry == NULL)
	    {
	    	Report(REP_WARN, IDS_DBPROP_115);
	        SendMessage(WM_CLOSE);
	        return TRUE;
	    }

		m_LogonID = pEntry->m_strLogonID.Get().c_str();
		m_Password = pEntry->m_strPassword.Get().c_str();
    }
    else	// else ADD
    {
		m_OdbcName.EnableWindow();
        m_OdbcBrowse.EnableWindow();
		m_OdbcName.SetWindowText(_T(""));
		m_LogonID = _T("");
        m_Password = _T("");
		m_OdbcName.SetFocus();
	}

	// Allow OK button only after a change
	GetDlgItem(IDC_IDX_LOGONID)->SetWindowText(m_LogonID);
	GetDlgItem(IDC_IDX_PASSWORD)->SetWindowText(m_Password);
	GetDlgItem(IDOK)->EnableWindow(false);
	SetDefID(IDCANCEL);
	return 0;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void IdxDbProp::OnOK() 
{
	GetDlgItem(IDC_IDX_LOGONID)->GetWindowText(m_LogonID);
	GetDlgItem(IDC_IDX_PASSWORD)->GetWindowText(m_Password);
	GetDlgItem(IDC_IDX_DB_NAME)->GetWindowText(m_DatabaseValue);
	m_SavedOdbcName = m_DatabaseValue;

	IM::DatabaseEntry *pEntry = m_pDatabaseList->NewEntry(m_DatabaseValue);
	pEntry->m_strLogonID.Set(m_LogonID);
	pEntry->m_strPassword.Set(m_Password);

	try
	{
		m_pDatabaseList->Add(pEntry);
	}
	catch (IM::Exception &)
	{
		Report(REP_WARN, IDS_DBPROP_117);
		delete pEntry;
		return;
	}
	
	CDialog::OnOK();
}

void IdxDbProp::OnChangeIdxLogonid() 
{
	GetDlgItem(IDOK)->EnableWindow();
	SetDefID(IDOK);
}

void IdxDbProp::OnChangeIdxPassword() 
{
	GetDlgItem(IDOK)->EnableWindow();
	SetDefID(IDOK);
}

void IdxDbProp::OnClose() 
{
	CDialog::OnClose();
}

void IdxDbProp::OnHelp() 
{
	::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, CONFIGURING_RULES_ENGINE_DATABASE_PROPERTIES);		
}
