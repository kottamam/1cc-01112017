// IdolIndexerProp.h: interface for the IdolIndexerProp class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IDOLINDEXERPROP_H__56EB1411_5907_4B06_B17D_4A7465B6D6F1__INCLUDED_)
#define AFX_IDOLINDEXERPROP_H__56EB1411_5907_4B06_B17D_4A7465B6D6F1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "resource.h" 
class IdolIndexerProp : public CDialog  
{
public:
	IdolIndexerProp(IM::DmsDatabaseEntry *pEntry_,CString &StrSavedODBCName, CWnd* pParent = NULL);
	virtual ~IdolIndexerProp();
		// Dialog Data
	//{{AFX_DATA(IdolIndexerProp)
	enum { IDD = IDD_IDX_IDOL };
	CString			m_SavedODBCName;
	CString			m_HostName;
	CString			m_PortNo;
	CString			m_RepositoryName;
	CString			m_Key1;
	CString			m_Key2;
	CString			m_Key3;
	CString			m_Key4;

	//}}AFX_DATA
	
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(IdolIndexerProp)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

	IM::DmsDatabaseEntry	*m_pEntry;

protected:

	// Generated message map functions
	//{{AFX_MSG(IdolIndexerProp)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	void OnChange();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};


#endif // !defined(AFX_IDOLINDEXERPROP_H__56EB1411_5907_4B06_B17D_4A7465B6D6F1__INCLUDED_)
