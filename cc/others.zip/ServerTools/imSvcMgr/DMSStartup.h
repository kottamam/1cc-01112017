#if !defined(AFX_DMSSTARTUP_H__6855DC89_DB1E_11D2_8C50_00C04F68F9B3__INCLUDED_)
#define AFX_DMSSTARTUP_H__6855DC89_DB1E_11D2_8C50_00C04F68F9B3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DMSStartup.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// DMSStartup dialog

class DMSStartup : public CDialog
{
// Construction
public:
	DMSStartup(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(DMSStartup)
	enum { IDD = IDD_DMS_STARTUP };
	CEdit	Password2;
	CEdit	Password1;
	CEdit	LogonID;
	//}}AFX_DATA
	IM::ServiceConfiguration		*m_pService;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(DMSStartup)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(DMSStartup)
	virtual BOOL OnInitDialog();
	afx_msg void OnCancelMode();
	afx_msg void OnAutoStartup();
	afx_msg void OnManualStartup();
	virtual void OnOK();
	afx_msg void OnChangeEdit1();
	afx_msg void OnChangeEdit6();
	afx_msg void OnChangeEdit5();
	afx_msg void OnHelp();
	afx_msg void OnLocalSys();
	afx_msg void OnLogon();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	IM::NrString		m_strLogonID;
	IM::NrString		m_strPassword;
	bool				m_bAutoStartup;
	bool                isLocalService;
	bool                isAutomatic;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DMSSTARTUP_H__6855DC89_DB1E_11D2_8C50_00C04F68F9B3__INCLUDED_)
