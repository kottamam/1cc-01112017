#include <stdafx.h>
#include <imSvcMgr.h>
#include "IDXSearchServiceProp.h"
#include <stl/NrString.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CIDXSearchServiceProp dialog


CIDXSearchServiceProp::CIDXSearchServiceProp(CWnd* pParent /*=NULL*/)
	: CDialog(CIDXSearchServiceProp::IDD, pParent)
{
	//{{AFX_DATA_INIT(CIDXSearchServiceProp)
	m_ClusterName = _T("");
	m_GivenServPort = FALSE;
	m_ServicePort = _T("");
	//}}AFX_DATA_INIT
}


void CIDXSearchServiceProp::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CIDXSearchServiceProp)
	DDX_Text(pDX, IDC_CLUSTER_NAME, m_ClusterName);
	DDX_Check(pDX, IDC_GIVEN_SERV_PORT, m_GivenServPort);
	DDX_Text(pDX, IDC_SERVICE_PORT, m_ServicePort);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CIDXSearchServiceProp, CDialog)
	//{{AFX_MSG_MAP(CIDXSearchServiceProp)
	ON_EN_CHANGE(IDC_CLUSTER_NAME, OnChange)
	ON_EN_CHANGE(IDC_SERVICE_PORT, OnChange)
	ON_BN_CLICKED(IDC_GIVEN_SERV_PORT, OnChange)
	ON_BN_CLICKED(IDHELP, OnHelp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CIDXSearchServiceProp message handlers

BOOL CIDXSearchServiceProp::OnInitDialog() 
{
	m_pService->LoadFromRegistry();
	m_ClusterName = m_pService->m_strClusterName.Get().c_str();

	m_GivenServPort = m_pService->m_bGivenServicePort.Get();
	CString aString;

	if (true == m_pService->m_bGivenServicePort.Get() ){
		_itot(m_pService->m_lServicePort.Get(), (_TCHAR*)(LPCSTR)aString.GetBuffer(10), 10);
		aString.ReleaseBuffer();
		IM::NrString servicePort(aString);
		GetDlgItem(IDC_SERVICE_PORT)->EnableWindow();
		m_ServicePort = servicePort.c_str();
	}
	else{
		GetDlgItem(IDC_SERVICE_PORT)->EnableWindow(0);
		m_ServicePort = "";
	}

	GetDlgItem(IDOK)->EnableWindow(0);
	SetDefID(IDCANCEL);
	CDialog::OnInitDialog();	

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CIDXSearchServiceProp::OnOK() 
{
	UpdateData();

	GetDlgItem(IDC_CLUSTER_NAME)->GetWindowText(m_ClusterName);
	m_ClusterName.TrimLeft();
	m_ClusterName.TrimRight();	
	GetDlgItem(IDC_CLUSTER_NAME)->SetWindowText(m_ClusterName);
	m_pService->m_strClusterName.Set(m_ClusterName);
	m_pService->m_bGivenServicePort.Set((((CButton*)GetDlgItem(IDC_GIVEN_SERV_PORT))->GetCheck() == 1));

	GetDlgItem(IDC_SERVICE_PORT)->GetWindowText(m_ServicePort);
	m_ServicePort.TrimLeft();
	m_ServicePort.TrimRight();
	GetDlgItem(IDC_SERVICE_PORT)->SetWindowText(m_ServicePort);

	if (m_ServicePort.IsEmpty()){
		if ( true == m_pService->m_bGivenServicePort.Get() ){
			Report(REP_WARN, IDS_DMSPROP_250);
			return;
		}
		else m_pService->m_lServicePort.Set(0L);
	}
	else m_pService->m_lServicePort.Set(_ttol(m_ServicePort));

	try
	{
		m_pService->StoreInRegistry();
	}
	catch (IM::Exception &)
	{
	}

	CDialog::OnOK();
}

void CIDXSearchServiceProp::OnChange() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	GetDlgItem(IDOK)->EnableWindow();
	SetDefID(IDOK);

	if (((CButton*)GetDlgItem(IDC_GIVEN_SERV_PORT))->GetCheck())
		GetDlgItem(IDC_SERVICE_PORT)->EnableWindow();
	else
		GetDlgItem(IDC_SERVICE_PORT)->EnableWindow(0);	
}

void CIDXSearchServiceProp::OnHelp() 
{
	::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, 6);		
}

