#if !defined(AFX_HEADERCTRLEX_H__49311BA2_F96C_11D1_BDCE_006097D2DD26__INCLUDED_)
#define AFX_HEADERCTRLEX_H__49311BA2_F96C_11D1_BDCE_006097D2DD26__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// HeaderCtrlEx.h : header file
//

#include "DbViewHeaderCtrl.h"
#include <afxtempl.h>

typedef CMap<int,int,int,int> MapImageIndex;
/////////////////////////////////////////////////////////////////////////////
// CHeaderCtrlEx window

class CHeaderCtrlEx : public CDbViewHeaderCtrl
{
// Construction
public:
	CHeaderCtrlEx();

// Attributes
public:
	void SetItemImage( int nItem, int nImage );
	CImageList* SetImageList( CImageList* pImageList );
	int	 GetItemImage( int nItem );
	void DrawItem( LPDRAWITEMSTRUCT lpDrawItemStruct );

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHeaderCtrlEx)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CHeaderCtrlEx(); 

	// Generated message map functions
protected:
	BOOL IsDragAllowed( CPoint point );	
	BOOL m_bAllowDrag;
	CImageList	*m_pImageList;	
	MapImageIndex m_mapImageIndex;

	//{{AFX_MSG(CHeaderCtrlEx)
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg LRESULT OnNcHitTest(CPoint point);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HEADERCTRLEX_H__49311BA2_F96C_11D1_BDCE_006097D2DD26__INCLUDED_)
