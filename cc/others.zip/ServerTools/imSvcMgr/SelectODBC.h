#if !defined(AFX_SELECTODBC_H__E5B662F7_DE2A_11D2_8C54_00C04F68F9B3__INCLUDED_)
#define AFX_SELECTODBC_H__E5B662F7_DE2A_11D2_8C54_00C04F68F9B3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SelectODBC.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// SelectODBC dialog

class SelectODBC : public CDialog
{
// Construction
public:
	SelectODBC(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(SelectODBC)
	enum { IDD = IDD_SELECT_ODBC };
	CListBox	m_OdbcList;
	//}}AFX_DATA
	IM::NrString			odbcSourceName;
	IM::DatabaseEntryList	*m_pDatabaseList;


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(SelectODBC)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(SelectODBC)
	virtual BOOL OnInitDialog();
	afx_msg void OnCancelMode();
	afx_msg void OnSelchangeOdbcList();
	afx_msg void OnDblclkOdbcList();
	virtual void OnOK();
	afx_msg void OnChelp();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SELECTODBC_H__E5B662F7_DE2A_11D2_8C54_00C04F68F9B3__INCLUDED_)
