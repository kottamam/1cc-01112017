#if !defined(AFX_DSSCHEDULE_H__DEFC3EE4_ECEB_4C76_9FD9_B52E89B7DDD4__INCLUDED_)
#define AFX_DSSCHEDULE_H__DEFC3EE4_ECEB_4C76_9FD9_B52E89B7DDD4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DSSchedule.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// DSSchedule dialog

class DSSchedule : public CDialog
{
// Construction
public:
	DSSchedule(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(DSSchedule)
	enum { IDD = IDD_DS_SCHEDULE };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	BOOL	m_abMatrix[7][12];
	IM::CDSSyncSvc	*m_pService;
	CString m_strServer;


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(DSSchedule)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(DSSchedule)
	virtual void OnOK();
	virtual void OnCancel();
	virtual BOOL OnInitDialog();
	afx_msg void OnScheduleRb();
	afx_msg void OnContinuousRb();
	afx_msg void OnHelp();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	void
		EnableScheduleMatrix();

	void
		DisableScheduleMatrix();

	bool
		IdIsChild(int id);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DSSCHEDULE_H__DEFC3EE4_ECEB_4C76_9FD9_B52E89B7DDD4__INCLUDED_)
