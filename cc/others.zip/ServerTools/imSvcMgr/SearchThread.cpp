#include "stdafx.h"
#include "imSvcMgr.h"
#include "SearchThread.h"
#include "DomainInfo.h"

extern DomainInfoMgr	gDomainInfoMgr;

SearchServers::SearchServers()
{
	hDoneEvent = CreateEvent(
									NULL,    // no security attributes
									TRUE,    // manual reset event
									FALSE,   // not-signalled
									NULL);   // no name

	InitializeCriticalSection(&csLock);
}

SearchServers::~SearchServers()
{
	WorkerList::iterator iter;
	DWORD dwExitCode;

	for (iter = workerList.begin(); iter != workerList.end(); ++iter)
	{
		GetExitCodeThread(iter->get()->hThread, &dwExitCode);

		// let it die by itself
		while (dwExitCode == STILL_ACTIVE)
		{
			Sleep(1000);
			GetExitCodeThread(iter->get()->hThread, &dwExitCode);
		}

	}

	CloseHandle(hDoneEvent);
	DeleteCriticalSection(&csLock);
}



void
SearchServers::startSearch()
{
	if (gDomainInfoMgr.bInitialized != true)
	{
		bGotAllInfo = false;
		SetEvent(hDoneEvent);
		return;
	}

	SearchWorker *pWorker = new SearchWorker();

	ResetEvent(hDoneEvent);
	bGotAllInfo = false;

	lock();
	serverFoundList.clear();
	unlock();

	pWorker->parent = this;

	lock();
	workerList.push_front(pWorker);
	unlock();
}

void SearchServers::stopSearch()
{
	WorkerList::iterator it = workerList.begin(); 

	lock();
	while (it != workerList.end())
	{
		DWORD			dwExitCode;
		SearchWorker	*pWorker = it->get();

		SetEvent(pWorker->hWorkerStopEvent);

		// if a thread has stopped then perform cleanup
		if (pWorker->hThread == NULL)
		{
			workerList.erase(it);
			delete pWorker;
			it = workerList.begin();
			continue;
		}

		// attempt to get exit code and close handle
		GetExitCodeThread(pWorker->hThread, &dwExitCode);

		// remove the worker from the list
		if (dwExitCode != STILL_ACTIVE)
		{
			workerList.erase(it);
			delete pWorker;
			it = workerList.begin();
			continue;
		}

		++it;
	}
	unlock();
}

bool
SearchServers::doneSearch()
{
	if (WaitForSingleObject(hDoneEvent, 0) == WAIT_TIMEOUT)
		return false;
	return true;
}

bool
SearchServers::gotAllInfo()
{
	return bGotAllInfo;
}


bool
SearchServers::getServerInfo(ServerInfo& serverInfo)
{
	lock();
	{
		if (serverFoundList.empty())
		{
			unlock();
			return false;
		}

		ServerInfoPointer info = serverFoundList.front();
		serverInfo.domainName = info->domainName;
		serverInfo.serverName = info->serverName;
		serverFoundList.pop_front();
	}
	unlock();

	return true;
}


void
SearchServers::addServerInfo(const IM::NrString& domainName, const IM::NrString& serverName)
{
	lock();
	{
		ServerInfo	*info = new ServerInfo;
		info->domainName = domainName;
		info->serverName = serverName;
		serverFoundList.push_front(info);
	}
	unlock();
}


SearchWorker::SearchWorker()
{
	DWORD	threadID;

	//
	//	Start the worker thread for processing
	//	file transfer requests
	//

	hWorkerStopEvent = CreateEvent( NULL, TRUE, FALSE, NULL);	// same as found event
	hThread = CreateThread(0, 0,
					(LPTHREAD_START_ROUTINE) SearchWorker::WorkerThread, (LPVOID *) this, 0, &threadID);

	if (hThread == NULL)
	{
		Report(REP_WARN, IDS_SEARCH_170);
	}
}

SearchWorker::~SearchWorker()
{
	CloseHandle(hWorkerStopEvent);
}


//
//	Check if server is up and allows SCM queries
//


bool
SearchWorker::allowsConnection(const IM::NrString& szServerName)
{
	SC_HANDLE	hSCM;

	if ((hSCM = OpenSCManager(szServerName.c_str(), NULL, SC_MANAGER_ALL_ACCESS)) == NULL)
	{
		return false;
	}

	CloseServiceHandle(hSCM);
	return true;
}



void
SearchWorker::WorkerThread(SearchWorker *pWorker_)
{
	//
	//	get the list of domains and get all the servers in each of the domains
	//

	bool						bGotAllInfo = true;
	NetResourceList				list;
	NetResourceList::iterator	iter;

	gDomainInfoMgr.getDomainNameList(list);

	for (iter = list.begin(); iter != list.end(); ++iter)
	{
		IM::NrCiString		strDomainName((*iter).name);

		// out of here for stop request
		if (WaitForSingleObject(pWorker_->hWorkerStopEvent, 0) == WAIT_OBJECT_0)
			break;

		if ((*iter).bContainer == true)
		{
			ServerNameList	serverList;
			bool			bGotDomainInfo;
			ServerNameList::iterator j;

			gDomainInfoMgr.getServersInDomain(strDomainName, serverList, bGotDomainInfo);


			if (bGotDomainInfo == false)
				bGotAllInfo = false;


			for (j = serverList.begin(); j != serverList.end(); ++j)
			{

				if (pWorker_->allowsConnection((*j).c_str()) == true)
				{
					pWorker_->parent->addServerInfo(strDomainName, (*j).c_str());
				}
			}
		}
		else	// assume that name is of a stand alone server
		{
			// out of here for stop request
			if (WaitForSingleObject(pWorker_->hWorkerStopEvent, 0) == WAIT_OBJECT_0)
				return;

			if (pWorker_->allowsConnection(strDomainName) == true)
			{
				// out of here for stop request
				if (WaitForSingleObject(pWorker_->hWorkerStopEvent, 0) == WAIT_OBJECT_0)
					break;

				pWorker_->parent->addServerInfo(strDomainName, strDomainName);
			}
		}
	}

	pWorker_->parent->bGotAllInfo = bGotAllInfo;
	SetEvent(pWorker_->parent->hDoneEvent);
}
