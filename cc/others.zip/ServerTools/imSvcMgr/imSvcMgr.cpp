// imSvcMgr.cpp : Defines the class behaviors for the application.
//

#include <stdafx.h>

#include <imSvcMgr.h>
#include <Report\Report.h>

#include "MainFrm.h"
#include "IpFrame.h"
#include "imSvcMgrDoc.h"
#include "imSvcMgrView.h"
#include "SearchThread.h"
#include "DomainInfo.h"
#include "LookupManager.h"
#include "StatLink.h"
//


#include "DSConnections.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#pragma comment (lib, "version.lib")

LookupManager	*gpLookupMgr;
DomainInfoMgr	gDomainInfoMgr;
SearchServers	gSearchServers;

static void	EventHandlerInit();
static void	EventHandlerDone();


/////////////////////////////////////////////////////////////////////////////
// CSvcMgrApp

BEGIN_MESSAGE_MAP(CSvcMgrApp, CWinApp)
	//{{AFX_MSG_MAP(CSvcMgrApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	//}}AFX_MSG_MAP
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
	// Standard print setup command
	ON_COMMAND(ID_FILE_PRINT_SETUP, CWinApp::OnFilePrintSetup)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSvcMgrApp construction

CSvcMgrApp::CSvcMgrApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CSvcMgrApp object

CSvcMgrApp theApp;

// This identifier was generated to be statistically unique for your app.
// You may change it if you prefer to choose a specific identifier.

// {04E9AC7A-D7EB-11D2-8C4D-00C04F68F9B3}
static const CLSID clsid =
{ 0x4e9ac7a, 0xd7eb, 0x11d2, { 0x8c, 0x4d, 0x0, 0xc0, 0x4f, 0x68, 0xf9, 0xb3 } };

/////////////////////////////////////////////////////////////////////////////
// CSvcMgrApp initialization

BOOL CSvcMgrApp::InitInstance()
{
	try
	{
		// Initialize OLE libraries
		if (!AfxOleInit())
		{
			AfxMessageBox(IDP_OLE_INIT_FAILED);
			return FALSE;
		}

		AfxEnableControlContainer();
		AfxInitRichEdit();

		// Standard initialization
		// If you are not using these features and wish to reduce the size
		//  of your final executable, you should remove from the following
		//  the specific initialization routines you do not need.

	#ifdef _AFXDLL
		Enable3dControls();			// Call this when using MFC in a shared DLL
	#else
		Enable3dControlsStatic();	// Call this when linking to MFC statically
	#endif

		// Change the registry key under which our settings are stored.
		// TODO: You should modify this string to be something appropriate
		// such as the name of your company or organization.
		//SetRegistryKey(_T("Local AppWizard-Generated Applications"));		

		LoadStdProfileSettings();  // Load standard INI file options (including MRU)

		// Register the application's document templates.  Document templates
		//  serve as the connection between documents, frame windows and views.

		MyDocTemplate* pDocTemplate;
		pDocTemplate = new MyDocTemplate(
			IDR_MAINFRAME,
			RUNTIME_CLASS(CSvcMgrDoc),
			RUNTIME_CLASS(CMainFrame),       // main SDI frame window
			RUNTIME_CLASS(CSvcMgrView));
		pDocTemplate->SetContainerInfo(IDR_CNTR_INPLACE);
		pDocTemplate->SetServerInfo(
			IDR_SVC_EMBEDDED, IDR_SVC_INPLACE,
			RUNTIME_CLASS(CInPlaceFrame));
		AddDocTemplate(pDocTemplate);

		// Connect the COleTemplateServer to the document template.
		//  The COleTemplateServer creates new documents on behalf
		//  of requesting OLE containers by using information
		//  specified in the document template.
		m_server.ConnectTemplate(clsid, pDocTemplate, TRUE);
			// Note: SDI applications register server objects only if /Embedding
			//   or /Automation is present on the command line.

		// Parse command line for standard shell commands, DDE, file open
		CCommandLineInfo cmdInfo;
		ParseCommandLine(cmdInfo);

		// Check to see if launched as OLE server
		if (cmdInfo.m_bRunEmbedded || cmdInfo.m_bRunAutomated)
		{
			// Register all OLE server (factories) as running.  This enables the
			//  OLE libraries to create objects from other applications.
			COleTemplateServer::RegisterAll();

			// Application was run with /Embedding or /Automation.  Don't show the
			//  main window in this case.
			return TRUE;
		}

		// When a server application is launched stand-alone, it is a good idea
		//  to update the system registry in case it has been damaged.
		m_server.UpdateRegistry(OAT_INPLACE_SERVER);
		COleObjectFactory::UpdateRegistryAll();

		// Dispatch commands specified on the command line
		if (!ProcessShellCommand(cmdInfo))
			return FALSE;

		TCHAR szBuff[512]; 
		GetModuleFileName(0, szBuff, 512); 
		CString currDir = szBuff;
		int index = currDir.ReverseFind ('\\');
		currDir = currDir.Mid (0, index+1);
		SetCurrentDirectory(currDir);

		gpLookupMgr = new LookupManager;
		EventHandlerInit();
		gDomainInfoMgr.StartWork();

		free((void*)m_pszHelpFilePath);
		m_pszHelpFilePath = _tcsdup(HTML_HELP_FILENAME);

		// The one and only window has been initialized, so show and update it.
		((CMainFrame*)m_pMainWnd)->SetAndShowWindow();
		m_pMainWnd->UpdateWindow();
		return TRUE;
	}
	catch (...)
	{
		return false;
	}
}

BOOL CSvcMgrApp::ExitInstance()
{
	gSearchServers.stopSearch();
	gDomainInfoMgr.StopWork();

	// if threads continue to be active then simply exit the process
	if (gSearchServers.IsStopped() != true)
		ExitProcess(0);

	if (gDomainInfoMgr.IsStopped() != true)
		ExitProcess(0);

	delete gpLookupMgr;
	EventHandlerDone();
	return(CWinApp::ExitInstance());
}
 
unsigned short	msgFlag[] =
{
	MB_OK | MB_ICONINFORMATION,
	MB_OK | MB_ICONINFORMATION,
	MB_OK | MB_ICONEXCLAMATION,
	MB_OK | MB_ICONSTOP,
};

void Report(const WORD code, const _TCHAR *szFormat, ...)
{
	static bool active = 0;

	try
	{
		if (active)
			return;
		else
			active = 1;

		va_list			ap;
		_TCHAR			szMessage[1024];
		IM::NrString		strTitle = BuildCaption(IDS_SVCMGR_120);

		// print msg
		va_start(ap, szFormat);
		_vstprintf(szMessage, szFormat, ap);
		va_end(ap);
		AfxMessageBox(szMessage);
		active = 0;
	}
	catch(...)
	{
		active = 0;
	}
}

void Report(const WORD code, UINT uStringID, ...)
{
	static bool active = 0;
		
	try
	{
		if (active)
			return;
		else
			active = 1;

		va_list			ap;
		CString			szResourceString;
		_TCHAR			*szMessage = NULL;
		IM::NrString		strTitle = BuildCaption(IDS_SVCMGR_120);

		// load the string; if not successful then return
		if (szResourceString.LoadString(uStringID) == 0)
		{
			active = 0;
			return;
		}

		va_start(ap, uStringID);

		::FormatMessage (	FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_STRING,
								szResourceString,
								0,
								MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
								(LPTSTR) &szMessage,
								0,
								&ap);
		if (szMessage == NULL)
		{
			active = 0;
			return;
		}

		va_end(ap);
		AfxMessageBox(szMessage);
		LocalFree(szMessage);
		active = 0;
	}
	catch(...)
	{
		active = 0;
	}
}


IM::NrString BuildCaption(UINT uStringID, ...)
{
	va_list			ap;
	CString			szResourceString;
	_TCHAR			*szMessage = NULL;
	IM::NrString	string;

	// load the string; if not successful then return
	if (szResourceString.LoadString(uStringID) == 0)
		return string;

	va_start(ap, uStringID);

	FormatMessage (	FORMAT_MESSAGE_FROM_STRING | FORMAT_MESSAGE_ALLOCATE_BUFFER,
							szResourceString,
							0,
							MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
							(LPTSTR) &szMessage,
							0,
							&ap);
	if (szMessage == NULL)
		return string;

	va_end(ap);

	string = szMessage;

	LocalFree(szMessage);
	return string;
}




static HMODULE hModule = NULL;
static void	EventHandler(WORD categoryID, const DWORD eventID, va_list arglist);

static void EventHandlerInit()
{
	try
	{
		if ((hModule = LoadLibraryEx(_T("EventMsg.dll"), NULL, LOAD_LIBRARY_AS_DATAFILE)) == NULL)
		{
			Report(REP_WARN, IDS_SVCMGR_121);
			return;
		}
	}
	catch (...)
	{
		return;
	}

	NRSetEventHandler(EventHandler);
}

static void EventHandlerDone()
{
	if (hModule != NULL)
		FreeLibrary(hModule);
}


static void EventHandler(WORD categoryID, const DWORD eventID, va_list arglist)
{
	_TCHAR			*szMessage = NULL;
	_TCHAR			*szCategory = NULL;
	_TCHAR			*newline = _T("\x0d\x0a");
	_TCHAR			*ptr;
 	_TCHAR			*newLinePtr;

	DWORD dw = FormatMessage (	FORMAT_MESSAGE_FROM_HMODULE | FORMAT_MESSAGE_ALLOCATE_BUFFER ,
							hModule,
							categoryID,
							MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
							(LPTSTR) &szCategory,
							0,
							NULL);
	
	dw = FormatMessage (	FORMAT_MESSAGE_FROM_HMODULE | FORMAT_MESSAGE_ALLOCATE_BUFFER ,
							hModule,
							eventID,
							MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
							(LPTSTR) &szMessage,
							0,
							&arglist);
	
	// trim trailing new-lines
	if (szCategory != NULL)
	{
		newLinePtr = szCategory + _tcslen(szCategory) - 2;
		if (_tcscmp(newLinePtr, newline) == 0)
			*newLinePtr = '\0';
	}

	if (szMessage != NULL)
	{
		newLinePtr = szMessage + _tcslen(szMessage) - 2;
		if (_tcscmp(newLinePtr, newline) == 0)
			*newLinePtr = '\0';
	}

	// remove extra backslah at end of line for display
	if ((ptr = szMessage) != NULL)
	{
		while (*ptr != '\0')
		{
			if (*ptr == '\\' && *(ptr + 1) == '\x0d')
				*ptr = ' ';
			++ptr;
		}
	}

	if (szMessage != NULL)
	{
		::MessageBox(NULL,
					szMessage,
					szCategory,
					msgFlag[EVT_SEVERITY(eventID)]);
	}


	if (szCategory != NULL)
		LocalFree(szCategory);
	if (szMessage != NULL)
		LocalFree(szMessage);


	return;

}


#include <Service\ntsecapi.h>

#ifndef STATUS_SUCCESS
#define STATUS_SUCCESS                  ((NTSTATUS)0x00000000L)
#define STATUS_OBJECT_NAME_NOT_FOUND    ((NTSTATUS)0xC0000034L)
#define STATUS_INVALID_SID              ((NTSTATUS)0xC0000078L)
#endif
 

bool GetPrimaryDomainName(IM::NrString& domain)
{
	LSA_HANDLE					hPolicyHandle;
	LSA_OBJECT_ATTRIBUTES		objectAttributes;
	PPOLICY_PRIMARY_DOMAIN_INFO	primaryDomain;

	domain = _T("");

	//
	// Attempt to open the policy
	// 
	memset(&objectAttributes, 0, sizeof(objectAttributes));
	if (LsaOpenPolicy(	NULL,
						&objectAttributes,
						POLICY_VIEW_LOCAL_INFORMATION,
						&hPolicyHandle) != STATUS_SUCCESS)
		return false;

	if (LsaQueryInformationPolicy( 
						hPolicyHandle,
						PolicyPrimaryDomainInformation,
						(LPVOID *) &primaryDomain) != STATUS_SUCCESS)
		return false;

	domain = primaryDomain->Name.Buffer;
	return true;
}


/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CStaticLink	m_wndNRTLink;	 // web link
	//{{AFX_MSG(CAboutDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

// App command to run the dialog
void CSvcMgrApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

struct LANGANDCODEPAGE
{
	WORD wLanguage;
	WORD wCodePage;
};

BOOL CAboutDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	DWORD hInfoHandle;
    int dataSize = GetFileVersionInfoSize(_T("imSvcMgr.exe"), &hInfoHandle);
	void *pInfoData;
	void *pVersion;
	unsigned int sizeVersion;

	pInfoData = new byte[dataSize];
	GetFileVersionInfo(_T("imSvcMgr.exe"), hInfoHandle,dataSize,pInfoData) ;

	if((VerQueryValue(pInfoData, _T("\\"), &pVersion, &sizeVersion) && sizeVersion) != 0)
	{    
		CString fileVersion;	
		VS_FIXEDFILEINFO  *fInfo = (VS_FIXEDFILEINFO*)pVersion;	

					
		fileVersion.Format(_T("WorkSite Service Manager %d.%d.%d.%d"), HIWORD(fInfo->dwFileVersionMS) ,LOWORD(fInfo->dwFileVersionMS), HIWORD(fInfo->dwFileVersionLS), LOWORD(fInfo->dwFileVersionLS));
		SetDlgItemText(IDC_STATIC_FILEVERSION,fileVersion);
	}

	LANGANDCODEPAGE *lpTranslate = nullptr;
	uint32_t sizeTranslate = 0;
	TCHAR subBlock[64] = { 0 };
	if (VerQueryValue(pInfoData, _T("\\VarFileInfo\\Translation"), reinterpret_cast<LPVOID*>(&lpTranslate), &sizeTranslate) && sizeTranslate != 0)
	{
		for (int i = 0; i < sizeTranslate / sizeof(LANGANDCODEPAGE); i++)
		{
			_sntprintf_s(subBlock, sizeof(subBlock), _T("\\StringFileInfo\\%.4x%.4x\\LegalCopyright"), lpTranslate[i].wLanguage, lpTranslate[i].wCodePage);

		}
		void *pLegalCopyright = nullptr;
		uint32_t sizeLegalCopy = 0;
		if (VerQueryValue(pInfoData, subBlock, &pLegalCopyright, &sizeLegalCopy))
		{
			if (sizeLegalCopy != 0)
				SetDlgItemText(IDC_NRT_WEBLINK, reinterpret_cast<TCHAR*>(pLegalCopyright));
		}
	}
	delete [] pInfoData;
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
