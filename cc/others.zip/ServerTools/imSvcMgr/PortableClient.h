// PortableClient.h : main header file for the PORTABLECLIENT application
//

#if !defined(AFX_PORTABLECLIENT_H__2C7D6E69_B0B4_11D2_8312_00A0C932328D__INCLUDED_)
#define AFX_PORTABLECLIENT_H__2C7D6E69_B0B4_11D2_8312_00A0C932328D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CPortableClientApp:
// See PortableClient.cpp for the implementation of this class
//


class CPortableClientApp : public CWinApp
{
public:
	CPortableClientApp();
	HINSTANCE m_hSccDll;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPortableClientApp)
	public:
	virtual BOOL InitInstance();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL
	long m_PurgeDays;
	int ExitInstance();
	void BuildDefaultMenus();
	// Server object for document creation
	//{{AFX_MSG(CPortableClientApp)
	afx_msg void OnAppAbout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PORTABLECLIENT_H__2C7D6E69_B0B4_11D2_8312_00A0C932328D__INCLUDED_)
