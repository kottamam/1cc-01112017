// RulesManagerProp.cpp : implementation file
//

#include "stdafx.h"
#include "imsvcmgr.h"
#include "RulesManagerProp.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRulesManagerProp dialog


CRulesManagerProp::CRulesManagerProp(CWnd* pParent /*=NULL*/)
	: CDialog(CRulesManagerProp::IDD, pParent)
{
	//{{AFX_DATA_INIT(CRulesManagerProp)
	m_lProcessInt = 60;
	m_smtpServer = _T("");
	//}}AFX_DATA_INIT
}


void CRulesManagerProp::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRulesManagerProp)
	DDX_Control(pDX, IDC_SPIN_RULE_MGR, m_ctrlSpinRule);
	DDX_Text(pDX, IDC_EDIT_PROCESS_INT, m_lProcessInt);
	DDX_Text(pDX, IDC_EDIT_SMTP_SERVER, m_smtpServer);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRulesManagerProp, CDialog)
	//{{AFX_MSG_MAP(CRulesManagerProp)
	ON_EN_CHANGE(IDC_EDIT_PROCESS_INT, OnChangeEditProcessInt)
	ON_EN_CHANGE(IDC_EDIT_SMTP_SERVER, OnChangeEditSmtpServer)
	ON_BN_CLICKED(IDHELP, OnHelp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRulesManagerProp message handlers

BOOL CRulesManagerProp::OnInitDialog() 
{
	CDialog::OnInitDialog();
	m_pService->LoadFromRegistry();
	// Service contains Process Interval in seconds; conver into minutes
	m_lProcessInt = (m_pService->m_lProcessInterval.Get()) / 60;
	m_smtpServer = m_pService->m_strSmtpServer.Get().c_str();
	UpdateData(FALSE);
	//((CEdit*)GetDlgItem(IDC_EDIT_PROCESS_INT))->SetWindowText(m_lProcessInt);
	m_ctrlSpinRule.SetBuddy(((CEdit*)GetDlgItem(IDC_EDIT_PROCESS_INT)));
	m_ctrlSpinRule.SetRange(1,60);
	GetDlgItem(IDOK)->EnableWindow(FALSE);
	SetDefID(IDCANCEL);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CRulesManagerProp::OnOK() 
{
	UpdateData(TRUE);
	m_pService->m_lProcessInterval.Set(m_lProcessInt * 60);
	m_pService->m_strSmtpServer.Set(m_smtpServer);

	try
	{
		m_pService->StoreInRegistry();
	}
	catch (IM::Exception &)
	{
	}

	CDialog::OnOK();
}

void CRulesManagerProp::OnChangeEditProcessInt() 
{
	GetDlgItem(IDOK)->EnableWindow(TRUE);
	SetDefID(IDOK);
}

void CRulesManagerProp::OnChangeEditSmtpServer() 
{
	GetDlgItem(IDOK)->EnableWindow(TRUE);
	SetDefID(IDOK);
}

void CRulesManagerProp::OnHelp() 
{
	::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, 7);
}

