// DMSServiceProp.cpp : implementation file
//

#include <stdafx.h>

#include <imSvcMgr.h>
#include <DMSServiceProp.h>
#include <stl/NrString.h>
#include <crypt/crypt.h>
#include <HostedDMConfig.h>
#include <SEVConfig.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define ENCRYPT_KEY			_T("iManage Service")

/////////////////////////////////////////////////////////////////////////////
// DMSServiceProp dialog


DMSServiceProp::DMSServiceProp(CWnd* pParent /*=NULL*/)
	: CDialog(DMSServiceProp::IDD, (CWnd*)pParent)
	, m_strSecureFileServerPath(_T(""))
{
	//{{AFX_DATA_INIT(DMSServiceProp)
	m_CacheFreq = _T("");
	m_CacheRows = _T("");
	m_ClusterName = _T("");
	m_FilePort = _T("");
	m_GivenFilePort = FALSE;
	m_GivenServPort = FALSE;
	m_PreloadCache = FALSE;
	m_ServicePort = _T("");
	m_SharedCMDB = _T("");
	m_Shared12Cache = FALSE;
	m_bImpersonation = FALSE;
	m_TrustedLogon = FALSE;
	m_strFileServerPath = _T("");
	m_strEmailDomain = _T("");
	m_bSEVenabled = FALSE;
	m_strWFMServerAddress = _T("");
	m_bWFMenabled = FALSE;
	m_bEASenabled = FALSE;
	m_strEASServerAddress = _T("");
	m_strEASUserName = _T("");
	m_strEASPassword = _T("");
	m_bHostedEnabled = FALSE;
	m_strIpv6MulticastAddress = _T("");
	m_strHPCAServerAddress = _T("");
	//}}AFX_DATA_INIT
}


void DMSServiceProp::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(DMSServiceProp)
	DDX_Control(pDX, IDC_SPIN_CACHE_ROWS, m_SpinCacheRows);
	DDX_Control(pDX, IDC_SPIN_CACHE_FREQ, m_SpinCacheFreq);
	DDX_Text(pDX, IDC_CACHE_FREQ, m_CacheFreq);
	DDX_Text(pDX, IDC_CACHE_ROWS, m_CacheRows);
	DDX_Text(pDX, IDC_CLUSTER_NAME, m_ClusterName);
	DDX_Text(pDX, IDC_FILE_PORT, m_FilePort);
	DDX_Check(pDX, IDC_GIVEN_FILE_PORT, m_GivenFilePort);
	DDX_Check(pDX, IDC_GIVEN_SERV_PORT, m_GivenServPort);
	DDX_Check(pDX, IDC_PRELOAD_CACHE_DATA, m_PreloadCache);
	DDX_Text(pDX, IDC_SERVICE_PORT, m_ServicePort);
	DDX_Text(pDX, IDC_SHARED_CMDB, m_SharedCMDB); 
	DDX_Check(pDX, IDC_SHARED12_CACHE, m_Shared12Cache);
	DDX_Check(pDX, IDC_IMPERSONATION_ENABLE, m_bImpersonation);
	DDX_Check(pDX, IDC_TRUSTED_LOGON, m_TrustedLogon);
	DDX_Text(pDX, IDC_CACHE_FILESERVER, m_strFileServerPath);
	DDX_Text(pDX, IDC_EMAILDOMAIN, m_strEmailDomain);
	DDX_Check(pDX, IDC_WFM_ENABLED, m_bWFMenabled);
	DDX_Text(pDX, IDC_WFM_SERVERADDRESS, m_strWFMServerAddress);
	DDX_Check(pDX, IDC_VAULT_ENABLED, m_bSEVenabled);
	DDX_Check(pDX, IDC_EAS_ENABLED, m_bEASenabled);	
	DDX_Text(pDX, IDC_EAS_SERVERADDRESS, m_strEASServerAddress);
	DDX_Text(pDX, IDC_EAS_USERNAME, m_strEASUserName);
	DDX_Text(pDX, IDC_EAS_PASSWORD, m_strEASPassword);
	DDX_Check(pDX, IDC_HOSTED_ENABLED, m_bHostedEnabled);
	//}}AFX_DATA_MAP
	DDX_Text(pDX, IDC_SECURE_CACHE_FILESERVER, m_strSecureFileServerPath);
	DDX_Text(pDX,IDC_IPV6MULTICASTADDRESS, m_strIpv6MulticastAddress);
	DDX_Text(pDX, IDC_HPCA_SERVERADDRESS, m_strHPCAServerAddress);
}


BEGIN_MESSAGE_MAP(DMSServiceProp, CDialog) 
	//{{AFX_MSG_MAP(DMSServiceProp)
	ON_EN_CHANGE(IDC_CLUSTER_NAME, OnChangeClusterName)
	ON_BN_CLICKED(IDC_TRUSTED_LOGON, OnTrustedLogon)
	ON_EN_CHANGE(IDC_CACHE_FREQ, OnChangeCacheFreq)
	ON_EN_CHANGE(IDC_CACHE_ROWS, OnChangeCacheRows)
	ON_BN_CLICKED(IDC_PRELOAD_CACHE_DATA, OnPreloadCacheData)
	ON_BN_CLICKED(IDC_SHARED12_CACHE, OnShared12Cache)
	ON_BN_CLICKED(IDC_IMPERSONATION_ENABLE, OnImpersonation)
	ON_EN_CHANGE(IDC_SHARED_CMDB, OnChangeSharedCmdb)
	ON_BN_CLICKED(IDC_GIVEN_SERV_PORT, OnGivenServPort)
	ON_EN_CHANGE(IDC_SERVICE_PORT, OnChangeServicePort)
	ON_BN_CLICKED(IDC_GIVEN_FILE_PORT, OnGivenFilePort)
	ON_EN_CHANGE(IDC_FILE_PORT, OnChangeFilePort) 
	ON_BN_CLICKED(IDHELP, OnHelp)
	ON_EN_CHANGE(IDC_IMPERSONATION_PASSWORD, OnChangeImpersonationPassword)
	ON_BN_CLICKED(IDC_CACHE_FILESERVERBTN, OnCacheFileserverBtn)
	ON_EN_CHANGE(IDC_CACHE_FILESERVER, OnChangeCacheFileserver)
	ON_EN_CHANGE(IDC_EMAILDOMAIN, OnChangeEmaildomain)
	ON_BN_CLICKED(IDC_WFM_ENABLED, OnWFMenabled)
	ON_EN_CHANGE(IDC_WFM_SERVERADDRESS, OnWFMServerAddress)
	ON_BN_CLICKED(IDC_VAULT_ENABLED, OnSEVenabled)
	ON_BN_CLICKED(IDC_VAULT_CONFIGURE, &DMSServiceProp::OnBnClickedVaultConfigure)
	ON_BN_CLICKED(IDC_EAS_ENABLED, OnEASenabled)
	ON_EN_CHANGE(IDC_EAS_SERVERADDRESS, OnEASServerAddress)
	ON_EN_CHANGE(IDC_EAS_USERNAME, OnEASUserName)
	ON_EN_CHANGE(IDC_EAS_PASSWORD, OnEASPassword)
	ON_BN_CLICKED(IDC_RADIO_SYSTEM_DATES, OnSystemDates)
	ON_BN_CLICKED(IDC_RADIO_FILE_DATES, OnFileDates)
	ON_BN_CLICKED(IDC_HOSTED_ENABLED, OnHostedDMenabled)	
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_SECURE_CACHE_FILESERVERBTN, &DMSServiceProp::OnSecureCacheFileserverBtn)
	ON_EN_CHANGE(IDC_SECURE_CACHE_FILESERVER, &DMSServiceProp::OnChangeSecureCacheFileServer)
	ON_BN_CLICKED(IDC_HOSTED_CONFIGURE, &DMSServiceProp::OnBnClickedHostedConfigure)	
	ON_EN_CHANGE(IDC_IPV6MULTICASTADDRESS, &DMSServiceProp::OnChangeIpv6multicastaddress)
	ON_BN_CLICKED(IDC_HPCA_ENABLED, &DMSServiceProp::OnBnClickedHpcaEnabled)
END_MESSAGE_MAP()



BOOL DMSServiceProp::OnInitDialog() 
{
	m_pService->LoadFromRegistry();
	CString aString;
	_itot(100, (_TCHAR*)(LPCSTR)aString.GetBuffer(10), 10);
	aString.ReleaseBuffer();

	_itot(m_pService->m_lThreadCount.Get(), (_TCHAR*)(LPCSTR)aString.GetBuffer(10), 10);
	aString.ReleaseBuffer();
	IM::NrString threadCount(aString);

	//m_Threads = threadCount.c_str();
	m_ClusterName = m_pService->m_strClusterName.Get().c_str();
	m_TrustedLogon = m_pService->m_bTrustedLogon.Get();

	_itot(m_pService->m_lCacheUpdateFrequency.Get(), (_TCHAR*)(LPCSTR)aString.GetBuffer(10), 10);
	aString.ReleaseBuffer();
	IM::NrString cacheFreq(aString);
	_itot(m_pService->m_lCacheRowCount.Get(), (_TCHAR*)(LPCSTR)aString.GetBuffer(10), 10);
	aString.ReleaseBuffer();
	IM::NrString cacheRows(aString);
	m_CacheRows	= cacheRows.c_str();
	m_CacheFreq	= cacheFreq.c_str();
	m_PreloadCache = m_pService->m_bPreloadCache.Get();
	m_Shared12Cache = m_pService->m_bSharedCMCache.Get();
	m_bImpersonation = m_pService->m_bImpersonationEnabled.Get();
	m_bWFMenabled = m_pService->m_bWFMEnabled.Get();
	m_strWFMServerAddress = m_pService->m_strWFMServerAddress.Get().c_str();
	m_bSEVenabled = m_pService->m_bSevEnabled.Get();
	m_bEASenabled = m_pService->m_bEasEnabled.Get();	
	m_strEASServerAddress = m_pService->m_strEasServerAddress.Get().c_str();
	m_strEASUserName = m_pService->m_strEasAdminUserId.Get().c_str();
	m_strEASPassword = m_pService->m_strEasAdminPassword.Get().c_str();
	if (m_bWFMenabled)
	{
		GetDlgItem(IDC_WFM_SERVERADDRESS)->EnableWindow(TRUE);
		((CButton*)GetDlgItem(IDC_WFM_ENABLED))->SetCheck(1);

	}
	else
	{
		GetDlgItem(IDC_WFM_SERVERADDRESS)->EnableWindow(false);
		((CButton*)GetDlgItem(IDC_WFM_ENABLED))->SetCheck(0);
	}
	
	if (m_bSEVenabled)
	{
		GetDlgItem(IDC_VAULT_CONFIGURE)->EnableWindow(TRUE);
		((CButton*)GetDlgItem(IDC_VAULT_ENABLED))->SetCheck(1);

	}
	else
	{
		GetDlgItem(IDC_VAULT_CONFIGURE)->EnableWindow(FALSE);
		((CButton*)GetDlgItem(IDC_VAULT_ENABLED))->SetCheck(0);
	}

	if (m_bEASenabled)
	{
		GetDlgItem(IDC_EAS_SERVERADDRESS)->EnableWindow(TRUE);
		GetDlgItem(IDC_EAS_USERNAME)->EnableWindow(TRUE);
		GetDlgItem(IDC_EAS_PASSWORD)->EnableWindow(TRUE);
		((CButton*)GetDlgItem(IDC_EAS_ENABLED))->SetCheck(1);

	}
	else
	{
		GetDlgItem(IDC_EAS_SERVERADDRESS)->EnableWindow(FALSE);
		GetDlgItem(IDC_EAS_USERNAME)->EnableWindow(FALSE);
		GetDlgItem(IDC_EAS_PASSWORD)->EnableWindow(FALSE);
		((CButton*)GetDlgItem(IDC_EAS_ENABLED))->SetCheck(0);
	}

	m_strHPCAServerAddress = m_pService->m_strAcaServerEndPoint.Get().c_str();
	if(m_pService->m_bAcaEnabled.Get())
	{
		GetDlgItem(IDC_HPCA_SERVERADDRESS)->EnableWindow(TRUE);
		((CButton *)GetDlgItem(IDC_HPCA_ENABLED))->SetCheck(1);
	}
	else
	{
		GetDlgItem(IDC_HPCA_SERVERADDRESS)->EnableWindow(FALSE);
		((CButton *)GetDlgItem(IDC_HPCA_ENABLED))->SetCheck(0);
	}

	m_bHostedEnabled = m_pService->m_bHostedDMEnabled.Get();

	if (m_bHostedEnabled)
	{
		GetDlgItem(IDC_HOSTED_CONFIGURE)->EnableWindow(TRUE);
		((CButton*)GetDlgItem(IDC_HOSTED_ENABLED))->SetCheck(1);
	}
	else
	{
		GetDlgItem(IDC_HOSTED_CONFIGURE)->EnableWindow(FALSE);
		((CButton*)GetDlgItem(IDC_HOSTED_ENABLED))->SetCheck(0);
	}

	if(m_bImpersonation)
	{
		GetDlgItem(IDC_IMPERSONATION_PASSWORD)->EnableWindow(TRUE);
		m_strPassword = m_pService->m_strImpersonationPassword.Get().c_str();
		GetDlgItem(IDC_IMPERSONATION_PASSWORD)->SetWindowText(m_strPassword);
	}
	else
		GetDlgItem(IDC_IMPERSONATION_PASSWORD)->EnableWindow(FALSE);
	
	m_SharedCMDB = m_pService->m_strCMDatabase.Get().c_str();

	if (m_PreloadCache && m_Shared12Cache)
	{
		GetDlgItem(IDC_SHARED_CMDB)->EnableWindow(TRUE);
		GetDlgItem(IDC_SHARED12_CACHE)->EnableWindow(TRUE);
	}
	else
	{
		if (m_PreloadCache)
		{
			GetDlgItem(IDC_SHARED12_CACHE)->EnableWindow(TRUE);
		}
		else
		{
			GetDlgItem(IDC_SHARED12_CACHE)->EnableWindow(FALSE);
		}
		GetDlgItem(IDC_SHARED_CMDB)->EnableWindow(FALSE);
	}

	m_GivenServPort = m_pService->m_bGivenServicePort.Get();

	if (m_pService->m_bGivenServicePort.Get() == true)
	{
		_itot(m_pService->m_lServicePort.Get(), (_TCHAR*)(LPCSTR)aString.GetBuffer(10), 10);
		aString.ReleaseBuffer();
		IM::NrString servicePort(aString);
		GetDlgItem(IDC_SERVICE_PORT)->EnableWindow(TRUE);
		m_ServicePort = servicePort.c_str();
	}
	else
	{
		GetDlgItem(IDC_SERVICE_PORT)->EnableWindow(FALSE);
		m_ServicePort = "";
	}

	m_GivenFilePort = m_pService->m_bGivenFilePort.Get();

	if (m_pService->m_bGivenFilePort.Get() == true)
	{
		_itot(m_pService->m_lFilePort.Get(), (_TCHAR*)(LPCSTR)aString.GetBuffer(10), 10);
		aString.ReleaseBuffer();
		IM::NrString filePort(aString);
		GetDlgItem(IDC_FILE_PORT)->EnableWindow(TRUE);
		m_FilePort = filePort.c_str();
	}
	else
	{
		GetDlgItem(IDC_FILE_PORT)->EnableWindow(FALSE);
		m_FilePort = "";
	}

	//
	// Get Cache Fileserver Key here!!!
	//
	IM::NrCiString strAdvancedServer(_T(""));
	IM::Registry	dbReg(NULL, HKEY_LOCAL_MACHINE, TEXT("Software\\Interwoven\\WorkSite\\imDmsSvc"));
	if (dbReg.Open(NULL, KEY_READ))
	{
		dbReg.GetStringValue(TEXT("Advanced Server"), strAdvancedServer);
	}
	bool bAdvancedServer = strAdvancedServer == _T("Y") ? true : false;

	if(bAdvancedServer)
	{
		GetDlgItem(IDC_CACHE_FILESERVERBTN)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_CACHE_FILESERVER)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_FILESERVERPATH_STATIC)->ShowWindow(SW_SHOW);

		GetDlgItem(IDC_CACHE_FILESERVERBTN)->EnableWindow(bAdvancedServer);
		GetDlgItem(IDC_CACHE_FILESERVER)->EnableWindow(bAdvancedServer);
		GetDlgItem(IDC_FILESERVERPATH_STATIC)->EnableWindow(bAdvancedServer);

		m_strFileServerPath = m_pService->m_strDocCacheFilePath.Get().c_str();

		GetDlgItem(IDC_SECURE_CACHE_FILESERVERBTN)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_SECURE_CACHE_FILESERVER)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_SECUREFILESERVERPATH_STATIC)->ShowWindow(SW_SHOW);

		GetDlgItem(IDC_SECURE_CACHE_FILESERVERBTN)->EnableWindow(bAdvancedServer);
		GetDlgItem(IDC_SECURE_CACHE_FILESERVER)->EnableWindow(bAdvancedServer);
		GetDlgItem(IDC_SECUREFILESERVERPATH_STATIC)->EnableWindow(bAdvancedServer);

		m_strSecureFileServerPath = m_pService->m_strSecureDocCacheFilePath.Get().c_str();
	}
	else
	{
		GetDlgItem(IDC_CACHE_FILESERVERBTN)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_CACHE_FILESERVER)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_FILESERVERPATH_STATIC)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_SECURE_CACHE_FILESERVERBTN)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_SECURE_CACHE_FILESERVER)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_SECUREFILESERVERPATH_STATIC)->ShowWindow(SW_HIDE);
	}

	m_strEmailDomain = m_pService->m_strEmailDomain.Get().c_str();

	IM::NrString aCaption = BuildCaption(IDS_PROP_110, m_pService->m_strServiceDisplayName.c_str(), m_pService->m_strComputerName.c_str());
	SetWindowText(aCaption.c_str());

	GetDlgItem(IDOK)->EnableWindow(FALSE);
	SetDefID(IDCANCEL);

	m_strIpv6MulticastAddress = m_pService->m_strIpv6MulticastAddress.Get().c_str();

	CDialog::OnInitDialog();

	m_SpinCacheFreq.SetRange(0, 10000);
	m_SpinCacheFreq.SetBuddy(GetDlgItem(IDC_CACHE_FREQ));
	m_SpinCacheRows.SetRange(0, 10000);
	m_SpinCacheRows.SetBuddy(GetDlgItem(IDC_CACHE_ROWS));

	if (m_pService->m_bUseSystemDates.Get() == true)
	{
		CButton* aButton = (CButton*)GetDlgItem(IDC_RADIO_SYSTEM_DATES);

		if (aButton)
			aButton->SetCheck(true);		
	}
	else
	{
		CButton* aButton = (CButton*)GetDlgItem(IDC_RADIO_FILE_DATES);

		if (aButton)
			aButton->SetCheck(true);
	}

	
	return 0;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void DMSServiceProp :: OnSEVenabled()
{
	if (((CButton*)GetDlgItem(IDC_VAULT_ENABLED))->GetCheck() == 1)
	{
		GetDlgItem(IDC_VAULT_CONFIGURE)->EnableWindow(TRUE);
		m_bSEVenabled = TRUE;
	}
	else
	{
		GetDlgItem(IDC_VAULT_CONFIGURE)->EnableWindow(FALSE);
		m_bSEVenabled = FALSE;
	}
	Changed();
}

void DMSServiceProp :: OnServerAddress()
{
	Changed();
}

void DMSServiceProp :: OnEASenabled()
{
	if (((CButton*)GetDlgItem(IDC_EAS_ENABLED))->GetCheck() == 1)
	{
		GetDlgItem(IDC_EAS_SERVERADDRESS)->EnableWindow(TRUE);
		GetDlgItem(IDC_EAS_USERNAME)->EnableWindow(TRUE);
		GetDlgItem(IDC_EAS_PASSWORD)->EnableWindow(TRUE);		
	}
	else
	{
		GetDlgItem(IDC_EAS_SERVERADDRESS)->EnableWindow(FALSE);
		GetDlgItem(IDC_EAS_USERNAME)->EnableWindow(FALSE);
		GetDlgItem(IDC_EAS_PASSWORD)->EnableWindow(FALSE);
	}

	Changed();
}

void DMSServiceProp :: OnHostedDMenabled()
{
	if (((CButton*)GetDlgItem(IDC_HOSTED_ENABLED))->GetCheck() == 1)
	{
		GetDlgItem(IDC_HOSTED_CONFIGURE)->EnableWindow(TRUE);	
		m_bHostedEnabled = TRUE;
	}
	else
	{
		GetDlgItem(IDC_HOSTED_CONFIGURE)->EnableWindow(FALSE);
		m_bHostedEnabled = FALSE;
	}
	Changed();
}

void DMSServiceProp :: OnEASServerAddress()
{
	Changed();
}

void DMSServiceProp :: OnEASUserName()
{
	Changed();
}

void DMSServiceProp :: OnEASPassword()
{
	Changed();
}

void DMSServiceProp :: OnWFMenabled()
{
	if (((CButton*)GetDlgItem(IDC_WFM_ENABLED))->GetCheck() == 1)
	{
		GetDlgItem(IDC_WFM_SERVERADDRESS)->EnableWindow(TRUE);
	}
	else
	{
		GetDlgItem(IDC_WFM_SERVERADDRESS)->EnableWindow(FALSE);	
	}

	Changed();
}

void DMSServiceProp :: OnWFMServerAddress()
{
	Changed();
}

void DMSServiceProp::OnOK() 
{
	bool sevEnabled = false;
	bool easEnabled = false;
	bool wfmEnabled = false;
	bool HpcaEnabled = false;

	if (((CButton*)GetDlgItem(IDC_VAULT_ENABLED))->GetCheck() == 1)
	{
		sevEnabled = true;
	}

	if (((CButton*)GetDlgItem(IDC_EAS_ENABLED))->GetCheck() == 1)
	{
		easEnabled = true;
		GetDlgItem(IDC_EAS_SERVERADDRESS)->GetWindowText(m_strEASServerAddress);
		GetDlgItem(IDC_EAS_USERNAME)->GetWindowText(m_strEASUserName);
		GetDlgItem(IDC_EAS_PASSWORD)->GetWindowText(m_strEASPassword);

		m_strEASServerAddress.TrimLeft();
		m_strEASServerAddress.TrimRight();
		if (m_strEASServerAddress.IsEmpty())
		{
			CString errStr;
			errStr.LoadString(IDS_STRING61454);
			MessageBox(errStr, _T("Error"), MB_OK);
			GetDlgItem(IDC_EAS_SERVERADDRESS)->SetFocus();
			return;
		}

		m_strEASUserName.TrimLeft();
		m_strEASUserName.TrimRight();
		if (m_strEASUserName.IsEmpty())
		{
			CString errStr;
			errStr.LoadString(IDS_STRING61455);
			MessageBox(errStr, _T("Error"), MB_OK);
			GetDlgItem(IDC_EAS_USERNAME)->SetFocus();
			return;
		}
		
		m_strEASPassword.TrimLeft();
		m_strEASPassword.TrimRight();
		if (m_strEASPassword.IsEmpty())
		{
			CString errStr;
			errStr.LoadString(IDS_STRING61456);
			MessageBox(errStr, _T("Error"), MB_OK);
			GetDlgItem(IDC_EAS_PASSWORD)->SetFocus();
			return;
		}
	}
	else
	{
		m_strEASServerAddress	= _T("");
		m_strEASUserName		= _T("");
		m_strEASPassword		= _T("");
	}

	if (((CButton*)GetDlgItem(IDC_WFM_ENABLED))->GetCheck() == 1)
	{
		wfmEnabled = true;
		GetDlgItem(IDC_WFM_SERVERADDRESS)->GetWindowText(m_strWFMServerAddress);
		m_strWFMServerAddress.TrimLeft();
		m_strWFMServerAddress.TrimRight();
		if (m_strWFMServerAddress.IsEmpty())
		{
			CString errStr;
			errStr.LoadString(IDS_STRING362);
			MessageBox(errStr, _T("Error"), MB_OK);
			GetDlgItem(IDC_WFM_SERVERADDRESS)->SetFocus();
			return;
		}
	}
	else
	{
		m_strWFMServerAddress = _T("");
	}

	if (((CButton*)GetDlgItem(IDC_HPCA_ENABLED))->GetCheck() == 1)
	{
		HpcaEnabled = true;
		GetDlgItem(IDC_HPCA_SERVERADDRESS)->GetWindowText(m_strHPCAServerAddress);

		m_strHPCAServerAddress.TrimLeft();
		m_strHPCAServerAddress.TrimRight();
		if (m_strHPCAServerAddress.IsEmpty())
		{
			CString errStr;
			errStr.LoadString(IDS_STRING_HPCA_ERROR);
			MessageBox(errStr, _T("Error"), MB_OK);
			GetDlgItem(IDC_HPCA_SERVERADDRESS)->SetFocus();
			return;
		}
	}
	else
	{
		m_strHPCAServerAddress = _T("");
	}

	m_pService->m_bWFMEnabled.Set(wfmEnabled? true: false);
	m_pService->m_strWFMServerAddress.Set(m_strWFMServerAddress);
	
	m_pService->m_bSevEnabled.Set(sevEnabled? true: false);

	m_pService->m_bEasEnabled.Set(easEnabled? true: false);
	m_pService->m_strEasServerAddress.Set(m_strEASServerAddress);	
	m_pService->m_strEasAdminUserId.Set(m_strEASUserName);
	m_pService->m_strEasAdminPassword.Set(m_strEASPassword);
	m_pService->m_strEasAdminPassword.SetEncryptFlag(true);

	m_pService->m_bAcaEnabled.Set(HpcaEnabled ? true: false);
	m_pService->m_strAcaServerEndPoint.Set(m_strHPCAServerAddress);

	m_pService->m_bHostedDMEnabled.Set(m_bHostedEnabled? true: false);

	m_pService->m_bPreloadCache.Set((((CButton*)GetDlgItem(IDC_PRELOAD_CACHE_DATA))->GetCheck() == 1));

	GetDlgItem(IDC_CLUSTER_NAME)->GetWindowText(m_ClusterName);
	m_pService->m_strClusterName.Set(m_ClusterName);

	m_pService->m_bTrustedLogon.Set((((CButton*)GetDlgItem(IDC_TRUSTED_LOGON))->GetCheck() == 1));

	m_pService->m_bImpersonationEnabled.Set((((CButton*)GetDlgItem(IDC_IMPERSONATION_ENABLE))->GetCheck() == 1));

	if(m_pService->m_bImpersonationEnabled.Get())
	{

		GetDlgItem(IDC_IMPERSONATION_PASSWORD)->GetWindowText(m_strPassword);
		if(m_strPassword.GetLength() < 6)
		{
			CString errStr;
			errStr.LoadString(IDS_STR_ERR_PASSWORD_LENGTH);
			MessageBox(errStr, _T("Error"), MB_OK);
			GetDlgItem(IDC_IMPERSONATION_PASSWORD)->SetFocus();
			return;
		}

		m_pService->m_strImpersonationPassword.Set(m_strPassword);
	}

	GetDlgItem(IDC_CACHE_FREQ)->GetWindowText(m_CacheFreq);
	m_pService->m_lCacheUpdateFrequency.Set(_ttoi(m_CacheFreq));

	GetDlgItem(IDC_CACHE_ROWS)->GetWindowText(m_CacheRows);
	m_pService->m_lCacheRowCount.Set(_ttoi(m_CacheRows));

	m_pService->m_bPreloadCache.Set((((CButton*)GetDlgItem(IDC_PRELOAD_CACHE_DATA))->GetCheck() == 1));
	m_pService->m_bSharedCMCache.Set((((CButton*)GetDlgItem(IDC_SHARED12_CACHE))->GetCheck() == 1));

	GetDlgItem(IDC_SHARED_CMDB)->GetWindowText(m_SharedCMDB);
	m_pService->m_strCMDatabase.Set(m_SharedCMDB);
	m_pService->m_bGivenServicePort.Set((((CButton*)GetDlgItem(IDC_GIVEN_SERV_PORT))->GetCheck() == 1));
	m_pService->m_bGivenFilePort.Set((((CButton*)GetDlgItem(IDC_GIVEN_FILE_PORT))->GetCheck() == 1));

	GetDlgItem(IDC_SERVICE_PORT)->GetWindowText(m_ServicePort);
	GetDlgItem(IDC_FILE_PORT)->GetWindowText(m_FilePort);

	if (m_ServicePort == "")
	{
		if (m_pService->m_bGivenServicePort.Get() == true)
		{
			Report(REP_WARN, IDS_DMSPROP_250);
			return;
		}
		else
			m_pService->m_lServicePort.Set(0);
	}
	else
		m_pService->m_lServicePort.Set(_ttoi(m_ServicePort));

	if (m_FilePort == "")
	{
		if (m_pService->m_bGivenFilePort.Get() == true)
		{
			Report(REP_WARN, IDS_DMSPROP_251);
			return;
		}
		else
			m_pService->m_lFilePort.Set(0);
	}
	else
		m_pService->m_lFilePort.Set(_ttoi(m_FilePort));

	GetDlgItemText(IDC_CACHE_FILESERVER, m_strFileServerPath);
	m_pService->m_strDocCacheFilePath.Set(m_strFileServerPath);
	if (m_strFileServerPath.IsEmpty())
		m_pService->m_bDocCacheEnabled.Set(FALSE);
	else
	{
		m_pService->m_bDocCacheEnabled.Set(TRUE);

		GetDlgItemText(IDC_SECURE_CACHE_FILESERVER, m_strSecureFileServerPath);		
		if (m_strSecureFileServerPath.IsEmpty())
		{
			CString errStr;
			errStr.LoadString(IDS_STRING_SECURECACHE);
			MessageBox(errStr, _T("Error"), MB_OK);
			GetDlgItem(IDC_SECURE_CACHE_FILESERVER)->SetFocus();
			return;
		}
		m_pService->m_strSecureDocCacheFilePath.Set(m_strSecureFileServerPath);
	}
	
	GetDlgItemText(IDC_EMAILDOMAIN, m_strEmailDomain);
	m_pService->m_strEmailDomain.Set(m_strEmailDomain);

	CButton* aButton = (CButton*)GetDlgItem(IDC_RADIO_SYSTEM_DATES);

	if (aButton->GetCheck() == TRUE)
	{
			m_pService->m_bUseSystemDates.Set(TRUE);
	}
	else
	{
		m_pService->m_bUseSystemDates.Set(FALSE);
	}

	GetDlgItemText(IDC_IPV6MULTICASTADDRESS, m_strIpv6MulticastAddress);
	m_pService->m_strIpv6MulticastAddress.Set(m_strIpv6MulticastAddress);

	m_pService->StoreInRegistry();
	CDialog::OnOK();
}

void DMSServiceProp::Changed() 
{
	if (!GetDlgItem(IDOK) || !::IsWindow(GetDlgItem(IDOK)->m_hWnd))
		return;

	GetDlgItem(IDOK)->EnableWindow(TRUE);
	SetDefID(IDOK);

	if (((CButton*)GetDlgItem(IDC_PRELOAD_CACHE_DATA))->GetCheck())
	{
		GetDlgItem(IDC_SHARED12_CACHE)->EnableWindow(TRUE);
		if (((CButton*)GetDlgItem(IDC_SHARED12_CACHE))->GetCheck())
		{
			GetDlgItem(IDC_SHARED_CMDB)->EnableWindow(TRUE);
		}
		else
		{
			GetDlgItem(IDC_SHARED_CMDB)->EnableWindow(FALSE);
		}
	}
	else
	{
		((CButton*)GetDlgItem(IDC_SHARED12_CACHE))->SetCheck(0);
		GetDlgItem(IDC_SHARED12_CACHE)->EnableWindow(FALSE);
		GetDlgItem(IDC_SHARED_CMDB)->EnableWindow(FALSE);
	}

	if (((CButton*)GetDlgItem(IDC_GIVEN_SERV_PORT))->GetCheck())
		GetDlgItem(IDC_SERVICE_PORT)->EnableWindow(TRUE);
	else
		GetDlgItem(IDC_SERVICE_PORT)->EnableWindow(FALSE);

	if (((CButton*)GetDlgItem(IDC_GIVEN_FILE_PORT))->GetCheck())
		GetDlgItem(IDC_FILE_PORT)->EnableWindow(TRUE);
	else
		GetDlgItem(IDC_FILE_PORT)->EnableWindow(FALSE);

}

void DMSServiceProp::OnChangeThreads() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	Changed();
}

void DMSServiceProp::OnChangeImpersonationPassword()
{
	Changed();
}

void DMSServiceProp::OnChangeClusterName() 
{
	Changed();
}

void DMSServiceProp::OnTrustedLogon() 
{
	Changed();
}

void DMSServiceProp::OnChangeCacheFreq() 
{
	Changed();
}

void DMSServiceProp::OnChangeCacheRows() 
{
	Changed();
}

void DMSServiceProp::OnPreloadCacheData() 
{
	Changed();
}

void DMSServiceProp::OnShared12Cache() 
{
	Changed();
}

void DMSServiceProp::OnImpersonation() 
{
	if (((CButton*)GetDlgItem(IDC_IMPERSONATION_ENABLE))->GetCheck())
		GetDlgItem(IDC_IMPERSONATION_PASSWORD)->EnableWindow(TRUE);
	else
	{
		GetDlgItem(IDC_IMPERSONATION_PASSWORD)->SetWindowText(NULL);
		GetDlgItem(IDC_IMPERSONATION_PASSWORD)->EnableWindow(FALSE);
	}
}

void DMSServiceProp::OnChangeSharedCmdb() 
{
	Changed();
}

void DMSServiceProp::OnGivenServPort() 
{
	Changed();
}

void DMSServiceProp::OnChangeServicePort() 
{
	Changed();
}

void DMSServiceProp::OnGivenFilePort() 
{
	Changed();
}

void DMSServiceProp::OnChangeFilePort() 
{
	Changed();
}

void DMSServiceProp::OnHelp() 
{
	::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, 28);
}

void DMSServiceProp::OnCacheFileserverBtn() 
{
	HRESULT hr			= S_OK;
	DWORD	dwFlags		= OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT;
	
	TCHAR	szFolder[MAX_PATH];
	TCHAR	szPath[MAX_PATH + MAX_PATH];
	
	BROWSEINFO		stBrowse = {0};
	LPITEMIDLIST	pItemIdList = NULL;
	
	hr = CoInitialize(NULL);
	if (FAILED(hr))
	{
		MessageBox(_T("CoInitialize failed."), MB_OK);
		return;
	}
	
	szFolder[0] = 0;
	szPath[0]	= 0;
	stBrowse.hwndOwner = m_hWnd;
	stBrowse.pszDisplayName = szFolder;
	stBrowse.ulFlags = BIF_USENEWUI  | BIF_EDITBOX;
	stBrowse.lpfn = NULL; // No Callback fn
	stBrowse.lParam = 0;

	pItemIdList = SHBrowseForFolder(&stBrowse);
	if (pItemIdList)
	{
		SHGetPathFromIDList(pItemIdList, szPath);   // Make sure it is a path
		m_strFileServerPath = szPath;
		SetDlgItemText(IDC_CACHE_FILESERVER, m_strFileServerPath);
		// Need to free this memory using IMalloc::Free
		//Free(pItemIdList);
	}
	
	CoUninitialize();
}

void DMSServiceProp::OnChangeCacheFileserver() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	Changed();
}

void DMSServiceProp::OnChangeEmaildomain() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	Changed();
}

void DMSServiceProp::OnSystemDates() 
{
	GetDlgItem(IDOK)->EnableWindow(true);
	SetDefID(IDOK);
}

void DMSServiceProp::OnFileDates() 
{
	GetDlgItem(IDOK)->EnableWindow(true);
	SetDefID(IDOK);
}

void DMSServiceProp::OnBnClickedHostedConfigure()
{
	HostedDMConfig hDmConfigDlg (m_pService, this);
	if (hDmConfigDlg.DoModal() == IDOK)
		Changed();
}

void DMSServiceProp::OnBnClickedVaultConfigure()
{
	SEVConfig hSEVConfigDlg (m_pService, this);
	if (hSEVConfigDlg.DoModal() == IDOK)
		Changed();
}

void DMSServiceProp::OnSecureCacheFileserverBtn()
{
	HRESULT hr			= S_OK;
	DWORD	dwFlags		= OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT;
	
	TCHAR	szFolder[MAX_PATH];
	TCHAR	szPath[MAX_PATH + MAX_PATH];
	
	BROWSEINFO		stBrowse = {0};
	LPITEMIDLIST	pItemIdList = NULL;
	
	hr = CoInitialize(NULL);
	if (FAILED(hr))
	{
		MessageBox(_T("CoInitialize failed."), MB_OK);
		return;
	}
	
	szFolder[0] = 0;
	szPath[0]	= 0;
	stBrowse.hwndOwner = m_hWnd;
	stBrowse.pszDisplayName = szFolder;
	stBrowse.ulFlags = BIF_USENEWUI  | BIF_EDITBOX;
	stBrowse.lpfn = NULL; // No Callback fn
	stBrowse.lParam = 0;

	pItemIdList = SHBrowseForFolder(&stBrowse);
	if (pItemIdList)
	{
		SHGetPathFromIDList(pItemIdList, szPath);   // Make sure it is a path
		m_strSecureFileServerPath = szPath;
		SetDlgItemText(IDC_SECURE_CACHE_FILESERVER, m_strSecureFileServerPath);
		// Need to free this memory using IMalloc::Free
		//Free(pItemIdList);
	}
	
	CoUninitialize();
}

void DMSServiceProp::OnChangeSecureCacheFileServer()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	Changed();
}

void DMSServiceProp::OnChangeIpv6multicastaddress()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.

	// TODO:  Add your control notification handler code here

	Changed();
}
void DMSServiceProp::OnBnClickedVaultEnabled2()
{
	// TODO: Add your control notification handler code here
}

void DMSServiceProp::OnBnClickedWfmEnabled()
{
	// TODO: Add your control notification handler code here
}
void DMSServiceProp::OnBnClickedHpcaEnabled()
{
	if (((CButton*)GetDlgItem(IDC_HPCA_ENABLED))->GetCheck() == 1)
	{
		GetDlgItem(IDC_HPCA_SERVERADDRESS)->EnableWindow(TRUE);
	}
	else
	{
		GetDlgItem(IDC_HPCA_SERVERADDRESS)->EnableWindow(FALSE);
	}

	Changed();
}
