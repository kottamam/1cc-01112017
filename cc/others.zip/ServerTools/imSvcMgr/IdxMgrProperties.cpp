// IdxMgrProperties.cpp : implementation file
//

#include "stdafx.h"
#include "imSvcMgr.h"
#include "IdxMgrProperties.h"
#include <stl/NrString.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// IdxMgrProperties dialog


IdxMgrProperties::IdxMgrProperties(CWnd* pParent /*=NULL*/)
	: CDialog(IdxMgrProperties::IDD, pParent)
{
	//{{AFX_DATA_INIT(IdxMgrProperties)
	m_BlockSize = _T("");
	//}}AFX_DATA_INIT
	
	int matrix[7][12] = {
	{	IDCMGR_CB000, IDCMGR_CB001, IDCMGR_CB002, IDCMGR_CB003, IDCMGR_CB004, IDCMGR_CB005, IDCMGR_CB006, IDCMGR_CB007, IDCMGR_CB008, IDCMGR_CB009, IDCMGR_CB010, IDCMGR_CB011	},
	{	IDCMGR_CB100, IDCMGR_CB101, IDCMGR_CB102, IDCMGR_CB103, IDCMGR_CB104, IDCMGR_CB105, IDCMGR_CB106, IDCMGR_CB107, IDCMGR_CB108, IDCMGR_CB109, IDCMGR_CB110, IDCMGR_CB111	},
	{	IDCMGR_CB200, IDCMGR_CB201, IDCMGR_CB202, IDCMGR_CB203, IDCMGR_CB204, IDCMGR_CB205, IDCMGR_CB206, IDCMGR_CB207, IDCMGR_CB208, IDCMGR_CB209, IDCMGR_CB210, IDCMGR_CB211	},
	{	IDCMGR_CB300, IDCMGR_CB301, IDCMGR_CB302, IDCMGR_CB303, IDCMGR_CB304, IDCMGR_CB305, IDCMGR_CB306, IDCMGR_CB307, IDCMGR_CB308, IDCMGR_CB309, IDCMGR_CB310, IDCMGR_CB311	},
	{	IDCMGR_CB400, IDCMGR_CB401, IDCMGR_CB402, IDCMGR_CB403, IDCMGR_CB404, IDCMGR_CB405, IDCMGR_CB406, IDCMGR_CB407, IDCMGR_CB408, IDCMGR_CB409, IDCMGR_CB410, IDCMGR_CB411	},
	{	IDCMGR_CB500, IDCMGR_CB501, IDCMGR_CB502, IDCMGR_CB503, IDCMGR_CB504, IDCMGR_CB505, IDCMGR_CB506, IDCMGR_CB507, IDCMGR_CB508, IDCMGR_CB509, IDCMGR_CB510, IDCMGR_CB511	},
	{	IDCMGR_CB600, IDCMGR_CB601, IDCMGR_CB602, IDCMGR_CB603, IDCMGR_CB604, IDCMGR_CB605, IDCMGR_CB606, IDCMGR_CB607, IDCMGR_CB608, IDCMGR_CB609, IDCMGR_CB610, IDCMGR_CB611	},
	};

    for (int i = 0; i < 7; i++)
    {
    	for (int j = 0; j < 12; j++)
        	cbMatrix[i][j] = matrix[i][j];
    }
}

bool IdxMgrProperties::IdIsChild(int id)
{
	for (int i = 0; i < 7; i++)
    {
    	for (int j = 0; j < 12; j++)
        	if (id == cbMatrix[i][j])
				return(true);
    }

	return(false);
}

void IdxMgrProperties::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(IdxMgrProperties)
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(IdxMgrProperties, CDialog)
	//{{AFX_MSG_MAP(IdxMgrProperties)
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDCMGR_SCHEDULE_RB, OnScheduleRb)
	ON_BN_CLICKED(IDCMGR_CONTINUOUS_RB, OnContinuousRb)
	ON_BN_CLICKED(IDHELP, OnHelp)
	//}}AFX_MSG_MAP 
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// IdxMgrProperties message handlers

BOOL IdxMgrProperties::OnInitDialog() 
{
	CDialog::OnInitDialog();

	m_pService->LoadFromRegistry();

    if (m_pService->m_strRunMode.Get().compare(_T("C")) == 0)
    {
		((CButton*)GetDlgItem(IDCMGR_CONTINUOUS_RB))->SetCheck(1);
		DisableScheduleMatrix();
    }
    else
    {
		((CButton*)GetDlgItem(IDCMGR_SCHEDULE_RB))->SetCheck(1);
        EnableScheduleMatrix();
    }

    for (int i = 0; i < 7; i++)
    {
    	for (int j = 0; j < 12; j++)
        {
        	if (m_pService->m_bScheduleTable[i][j].Get() == true)
            	((CButton*)GetDlgItem(cbMatrix[i][j]))->SetCheck(1);
        }
    }

	IM::NrString aCaption = BuildCaption(IDS_PROP_110, m_pService->m_strServiceDisplayName.c_str(), m_pService->m_strComputerName.c_str());
	SetWindowText(aCaption.c_str());
	GetDlgItem(IDOK)->EnableWindow(0);
	SetDefID(IDCANCEL);
	return 0;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void IdxMgrProperties::EnableScheduleMatrix()
{
    for (int i = 0; i < 7; i++)
    {
    	for (int j = 0; j < 12; j++)
        	GetDlgItem(cbMatrix[i][j])->EnableWindow();
    }
}

void IdxMgrProperties::DisableScheduleMatrix()
{
    for (int i = 0; i < 7; i++)
    {
    	for (int j = 0; j < 12; j++)
        	GetDlgItem(cbMatrix[i][j])->EnableWindow(0);
    }
}

void IdxMgrProperties::OnOK() 
{
	if(((CButton*)GetDlgItem(IDCMGR_SCHEDULE_RB))->GetCheck() == 1)
	{
		bool bScheduled = false;

		for (int i = 0; i < 7; i++)
		{
			for (int j = 0; j < 12; j++)
			{
				if (((CButton*)GetDlgItem(cbMatrix[i][j]))->GetCheck() == 1)
				{
					bScheduled = true;
					break;
				}
			}
		}

		if (bScheduled == false)
		{
    		Report(REP_WARN, IDS_IDXPROP_260);
			return;
		}
	}
	CButton* aScheduleButton = (CButton*)GetDlgItem(IDCMGR_SCHEDULE_RB);
	m_pService->m_strRunMode.Set((aScheduleButton->GetCheck() == 1) ?  _T("S") : _T("C"));

	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j < 12; j++)
		{
			m_pService->m_bScheduleTable[i][j].Set(((CButton*)GetDlgItem(cbMatrix[i][j]))->GetCheck() == 1);
		}
	}

	try
	{
		m_pService->StoreInRegistry();
	}
	catch (IM::Exception &)
	{
	}
	CDialog::OnOK();
}

void IdxMgrProperties::OnClose() 
{
	// if scheduled run then verify that there is at least one scheduled quantum
	if(((CButton*)GetDlgItem(IDCMGR_SCHEDULE_RB))->GetCheck() == 0)
		return;

	bool bScheduled = false;

	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j < 12; j++)
		{
			if (((CButton*)GetDlgItem(cbMatrix[i][j]))->GetCheck() == 1)
			{
				bScheduled = true;
				break;
			}
		}
	}

	if (bScheduled == false)
    	Report(REP_WARN, IDS_IDXPROP_260);
	
	CDialog::OnClose();
}

void IdxMgrProperties::OnScheduleRb() 
{
	Changed();
	CButton* aScheduleButton = (CButton*)GetDlgItem(IDCMGR_SCHEDULE_RB);

    if (aScheduleButton->GetCheck() == 1)
    	EnableScheduleMatrix();
    else
    	DisableScheduleMatrix();
}

void IdxMgrProperties::OnContinuousRb() 
{
	Changed();

	CButton* aScheduleButton = (CButton*)GetDlgItem(IDCMGR_SCHEDULE_RB);
    
    if (aScheduleButton->GetCheck() == 1)
    	EnableScheduleMatrix();
    else
    	DisableScheduleMatrix();
}


BOOL IdxMgrProperties::OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo) 
{
	if (IdIsChild(nID))
		Changed();

	return CDialog::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);
}

void IdxMgrProperties::Changed()
{
	GetDlgItem(IDOK)->EnableWindow(true);
	SetDefID(IDOK);
}

void IdxMgrProperties::OnCancel() 
{
	// if scheduled run then verify that there is at least one scheduled quantum
	if(((CButton*)GetDlgItem(IDCMGR_SCHEDULE_RB))->GetCheck() == 0)
	{
		CDialog::OnCancel();
		return;
	}

	bool bScheduled = false;

	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j < 12; j++)
		{
			if (((CButton*)GetDlgItem(cbMatrix[i][j]))->GetCheck() == 1)
			{
				bScheduled = true;
				break;
			}
		}
	}

	if (bScheduled == false)
    	Report(REP_WARN, IDS_IDXPROP_260);
	else
		CDialog::OnCancel();
}

void IdxMgrProperties::OnHelp() 
{
	::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, 29);
}
