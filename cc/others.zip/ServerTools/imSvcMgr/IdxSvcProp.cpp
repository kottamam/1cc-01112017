// IdxSvcProp.cpp : implementation file
//

#include "stdafx.h"
#include "imsvcmgr.h"
#include "IdxSvcProp.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CIdxSvcProp dialog


CIdxSvcProp::CIdxSvcProp(CWnd* pParent /*=NULL*/)
	: CDialog(CIdxSvcProp::IDD, pParent)
{
	//{{AFX_DATA_INIT(CIdxSvcProp)	
	m_strDXMLPath = _T("");
	//}}AFX_DATA_INIT
}


void CIdxSvcProp::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CIdxSvcProp)	
	DDX_Text(pDX, IDC_EDIT_DXMLPATH, m_strDXMLPath);	
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CIdxSvcProp, CDialog)
	//{{AFX_MSG_MAP(CIdxSvcProp)
	ON_EN_CHANGE(IDC_EDIT_DXMLPATH, OnChangeEditDXMLPath)
	ON_BN_CLICKED(IDC_BUTTON_BROWSE, OnBrowse)
	//ON_BN_CLICKED(IDHELP, OnHelp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CIdxSvcProp message handlers

BOOL CIdxSvcProp::OnInitDialog() 
{
	CDialog::OnInitDialog();
	m_pService->LoadFromRegistry();	
	m_strDXMLPath = m_pService->m_strDeploymentXML.Get().c_str();	
	UpdateData(FALSE);
	GetDlgItem(IDOK)->EnableWindow(FALSE);
	IM::NrString aCaption = BuildCaption(IDS_PROP_110, m_pService->m_strServiceDisplayName.c_str(), m_pService->m_strComputerName.c_str());
	SetWindowText(aCaption.c_str());
	SetDefID(IDCANCEL);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CIdxSvcProp::OnOK() 
{
	UpdateData(TRUE);	
	m_pService->m_strDeploymentXML.Set(m_strDXMLPath);
	m_pService->StoreInRegistry();
	CDialog::OnOK();
}

void CIdxSvcProp::OnChangeEditDXMLPath() 
{
	GetDlgItem(IDOK)->EnableWindow(TRUE);
	SetDefID(IDOK);
}

void CIdxSvcProp::OnBrowse() 
{
		CFileDialog aFileDialog(
					TRUE,
					_T("xml"),
					NULL,
					OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_HIDEREADONLY,
					_T("XML Files (*.xml)|*.xml||")
	);
	
	if (aFileDialog.DoModal() != IDOK)
		return;

	m_strDXMLPath = aFileDialog.GetPathName() ;
	UpdateData(0);
	OnChangeEditDXMLPath();
}

//void CIdxSvcProp::OnHelp() 
//{
	//WinHelp(7, HELP_CONTEXT);
//#ifdef WSNT_VS2008
//	HtmlHelp(/*NULL, HTML_HELP_FILENAME,*/ HH_HELP_CONTEXT, 7);
//#else
//	HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, 7);
//#endif
//}

