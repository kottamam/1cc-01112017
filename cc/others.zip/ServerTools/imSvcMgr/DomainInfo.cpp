#include <stdafx.h>

#include <imSvcMgr.h>
#include <DomainInfo.h>

void
CopyNetResource(NETRESOURCE *dest, NETRESOURCE *src)
{
	*dest = *src;

	// now copy all the strings
	if (dest->lpLocalName != NULL)
	{
		dest->lpLocalName = new _TCHAR[_tcslen(src->lpLocalName) + 1];
		_tcscpy(dest->lpLocalName, src->lpLocalName);
	}
	if (dest->lpRemoteName != NULL)
	{
		dest->lpRemoteName = new _TCHAR[_tcslen(src->lpRemoteName) + 1];
		_tcscpy(dest->lpRemoteName, src->lpRemoteName);
	}
	if (dest->lpComment != NULL)
	{
		dest->lpComment = new _TCHAR[_tcslen(src->lpComment) + 1];
		_tcscpy(dest->lpComment, src->lpComment);
	}
	if (dest->lpProvider != NULL)
	{
		dest->lpProvider = new _TCHAR[_tcslen(src->lpProvider) + 1];
		_tcscpy(dest->lpProvider, src->lpProvider);
	}
}




DomainInfoWorker::DomainInfoWorker(DomainInfoMgr *mgr, DomainInfo *domain)
{
	DWORD		threadID;

	this->domain = domain;
	this->mgr = mgr;

	bDoneWork = false;

	hThread = CreateThread(0, 0,
					(LPTHREAD_START_ROUTINE) DomainInfoWorker::workerThread, (LPVOID *) this, 0, &threadID);
}



DomainInfoWorker::~DomainInfoWorker()
{
	DWORD		dwExitCode;

	GetExitCodeThread(hThread, &dwExitCode);
	while (dwExitCode == STILL_ACTIVE)
	{
		Sleep(100);
		GetExitCodeThread(hThread, &dwExitCode);
	}
	CloseHandle(hThread);
}



void
DomainInfoWorker::workerThread(DomainInfoWorker *worker)
{
	DomainInfo	*domainInfo = worker->domain;

	HANDLE		enumHandle;
	NETRESOURCE	resource[1000];
	DWORD		numEntries = 100;
	DWORD		arraySize = sizeof(resource);
	NETRESOURCE	*domainResource = &domainInfo->netResource;

	if (domainResource == NULL || (domainResource->dwUsage & RESOURCEUSAGE_CONTAINER) == 0)
	{
		domainInfo->bGotInfo = true;
		return;
	}

	// if we are unable to get information about the domain then done
	if (WNetOpenEnum(RESOURCE_GLOBALNET, RESOURCETYPE_ANY, RESOURCEUSAGE_CONTAINER, domainResource, &enumHandle) != NO_ERROR)
	{
		domainInfo->bGotInfo = true;
		return;
	}

	while (WNetEnumResource(enumHandle, &numEntries, (void*) resource, &arraySize) == NO_ERROR)
	{
		for (int j = 0; j < (int) numEntries; j++)
		{
			domainInfo->lock();
			domainInfo->serverList.push_front(&resource[j].lpRemoteName[2]);
			domainInfo->unlock();
		}

		numEntries = 100;
		arraySize = sizeof(resource);
	}

	WNetCloseEnum(enumHandle);

	domainInfo->bGotInfo = true;
	worker->bDoneWork = true;
}



DomainInfoMgr::DomainInfoMgr()
{
	hStopEvent = CreateEvent( NULL, TRUE, FALSE, NULL);
	InitializeCriticalSection(&csLock);

	bInitialized = false;
	bIsStopped = true;
	hThread = NULL;
}



DomainInfoMgr::~DomainInfoMgr()
{
	DWORD		dwExitCode;

	SetEvent(hStopEvent);

	// zap manager thread
	GetExitCodeThread(hThread, &dwExitCode);
	while (dwExitCode == STILL_ACTIVE)
	{
		Sleep(1000);
		GetExitCodeThread(hThread, &dwExitCode);
	}

	// zap workers
	{
		WorkerList::iterator		it;

		for (it = workerList.begin(); it != workerList.end(); it++)
		{
			DomainInfoWorker	*pWorker = it->get();
			delete pWorker;
		}
	}

	// destroy domain information
	{
		DomainList::iterator		it;

		for (it = domainList.begin(); it != domainList.end(); it++)
		{
			DomainInfo	*pDomainInfo = it->get();
			delete pDomainInfo;
		}
	}


	CloseHandle(hStopEvent);
	DeleteCriticalSection(&csLock);
}


void
DomainInfoMgr::workerCleanup()
{
	lock();
	WorkerList::iterator it = workerList.begin();

	while (it != workerList.end())
	{
		DomainInfoWorker	*pWorker = it->get();

		if (pWorker->bDoneWork == true)
		{
			workerList.erase(it);
			delete pWorker;
			it = workerList.begin();
		}
		else
		{
			++it;
		}
	}
	unlock();
}


void
DomainInfoMgr::StartWork()
{
	DWORD threadID;

	bIsStopped = false;

	//
	//	Start the manager thread
	//

	hThread = CreateThread(0, 0,
					(LPTHREAD_START_ROUTINE) DomainInfoMgr::managerThread, (LPVOID *) this, 0, &threadID);

	if (hThread == NULL)
	{
		Report(REP_WARN, IDS_DOMAIN_240);
	}
}




void
DomainInfoMgr::managerThread(DomainInfoMgr *mgr)
{
	HANDLE		enumHandle;
	NETRESOURCE	resourceArray[100];
	DWORD		numEntries = 10;
	DWORD		arraySize = sizeof(resourceArray);


	//
	//	Locate the Microsoft Network Resource
	//

	// locate the Microsoft Networks Resource node
	if (WNetOpenEnum(RESOURCE_GLOBALNET, RESOURCETYPE_ANY, RESOURCEUSAGE_CONTAINER, NULL, &enumHandle) != NO_ERROR)
	{
		Report(REP_WARN, IDS_DOMAIN_241);
		return;
	}

	// exit from thread if stop event has been fired
	if (WaitForSingleObject(mgr->hStopEvent, 0) == WAIT_OBJECT_0)
	{
		mgr->bIsStopped = true;
		return;
	}

	while (WNetEnumResource(enumHandle, &numEntries, (void*) resourceArray, &arraySize) == NO_ERROR)
	{
		// exit from thread if stop event has been fired
		if (WaitForSingleObject(mgr->hStopEvent, 0) == WAIT_OBJECT_0)
		{
			mgr->bIsStopped = true;
			return;
		}

		for (int i = 0; i < (int) numEntries; i++)
		{
			if (_tcsstr(resourceArray[i].lpProvider, _T("Microsoft Windows Network")) == NULL)
				continue;

			mgr->microsoftResource = resourceArray[i];
			break;
		}

		numEntries = 10;
		arraySize = sizeof(resourceArray);
	}
	WNetCloseEnum(enumHandle);


	//
	//	Locate domains in the Microsoft Network and add them to the domainList
	//

	if (WNetOpenEnum(RESOURCE_GLOBALNET, RESOURCETYPE_ANY, RESOURCEUSAGE_CONTAINER, &mgr->microsoftResource, &enumHandle) != NO_ERROR)
	{
		Report(REP_WARN, IDS_DOMAIN_242);
		return;
	}

	// exit from thread if stop event has been fired
	if (WaitForSingleObject(mgr->hStopEvent, 0) == WAIT_OBJECT_0)
	{
		mgr->bIsStopped = true;
		return;
	}


	numEntries = 10;
	arraySize = sizeof(resourceArray);
	while (WNetEnumResource(enumHandle, &numEntries, (void*) resourceArray, &arraySize) == NO_ERROR)
	{
		// exit from thread if stop event has been fired
		if (WaitForSingleObject(mgr->hStopEvent, 0) == WAIT_OBJECT_0)
			
		{
			mgr->bIsStopped = true;
			return;
		}

		for (int i = 0; i < (int) numEntries; i++)
		{
			DomainInfo *domainInfo = new DomainInfo();

			domainInfo->name = resourceArray[i].lpRemoteName;
			CopyNetResource(&domainInfo->netResource, &resourceArray[i]);

			mgr->lock();
			mgr->domainList.push_front(IM::STLPointer<DomainInfo>(domainInfo));
			mgr->unlock();
		}

		numEntries = 10;
		arraySize = sizeof(resourceArray);
	}
	WNetCloseEnum(enumHandle);

	//
	//	Domain information is loaded.
	//
	mgr->bInitialized = true;

	//
	//	Create worker threads to look up the servers in each of the domains
	//

	mgr->lock();

	
	DomainList::iterator iter;

	for (iter = mgr->domainList.begin(); iter != mgr->domainList.end(); ++iter)
	{
		DomainInfoWorker *pWorker = new DomainInfoWorker(mgr, iter->get());
		mgr->workerList.push_front(IM::STLPointer<DomainInfoWorker>(pWorker));
	}
	
	mgr->unlock();

	//
	//	Cleanup worker threads;  exit after all worker threads have completed
	//	work

	while (1)
	{
		long		ret;

		ret = WaitForSingleObject(mgr->hStopEvent, 10 * 1000);
		switch (ret)
		{
		case WAIT_TIMEOUT:
			// get rid of any workers that are done with work
			mgr->workerCleanup();

            // if no workers left then done
			if (mgr->workerList.empty())
				return;

			break;

		default:
			{
				mgr->bIsStopped = true;
				return;
			}
		}
	}
}


void
DomainInfoMgr::getDomainNameList(NetResourceList &list)
{
	if (bInitialized == false)
		return;

	lock();
	DomainList::iterator iter;

	for (iter = domainList.begin(); iter != domainList.end(); ++iter)
	{
		NetResource	netResource;

		netResource.name = iter->get()->name;
		netResource.bContainer = (iter->get()->netResource.dwUsage & RESOURCEUSAGE_CONTAINER) != 0;
		netResource.bGotInfo = iter->get()->bGotInfo;

		list.push_front(netResource);
	}

	unlock();
	return;
}


void
DomainInfoMgr::getServersInDomain(const IM::NrCiString domainName, ServerNameList &list, bool &bGotAll)
{
	if (bInitialized == false)
		return;

	bGotAll = false;
	lock();

	DomainList::iterator iter;

	for (iter = domainList.begin(); iter != domainList.end(); ++iter)
	{
		if (iter->get()->name == domainName)
			break;
	}

	unlock();

	if (iter == domainList.end())
		return;

	iter->get()->lock();

	list = iter->get()->serverList;

	iter->get()->unlock();
	bGotAll = iter->get()->bGotInfo;
	return;
}
