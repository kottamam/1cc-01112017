#if !defined(AFX_SELECTSERVER_H__F894590D_D8A3_11D2_8C4D_00C04F68F9B3__INCLUDED_)
#define AFX_SELECTSERVER_H__F894590D_D8A3_11D2_8C4D_00C04F68F9B3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SelectServer.h : header file
//

#include <afxtempl.h>

class NetResource;

struct TreeNode
{
public:
	NetResource	*Data;
	HTREEITEM m_TreeItem;
};

/////////////////////////////////////////////////////////////////////////////
// SelectServer dialog

class SelectServer : public CDialog
{
// Construction
public:
	SelectServer(CWnd* pParent = NULL);   // standard constructor
	~SelectServer();

// Dialog Data
	//{{AFX_DATA(SelectServer)
	enum { IDD = IDD_SELECT_SERVER };
	CTreeCtrl m_TreeCtrl;
	IM::NrString m_Server;
	//}}AFX_DATA
	TreeNode m_Selected;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(SelectServer)
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(SelectServer)
	virtual BOOL OnInitDialog();
	afx_msg void OnDblclkSelectServerTree(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSelchangedSelectServerTree(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnChangeEditServer();
	afx_msg void OnHelp();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
	bool bDomainListInitialized;
	void loadDomains();
	void loadServers(bool bWarn);
	CList<TreeNode, TreeNode&> m_ParentNodes;
	void Changed();
	bool ParentIsPresent(HTREEITEM anItem);
private:
	CImageList m_domainImagelist;
	CImageList m_svrImagelist;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SELECTSERVER_H__F894590D_D8A3_11D2_8C4D_00C04F68F9B3__INCLUDED_)
