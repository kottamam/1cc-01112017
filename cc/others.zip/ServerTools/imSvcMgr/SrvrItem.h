// SrvrItem.h : interface of the CSvcMgrSrvrItem class
//

#if !defined(AFX_SRVRITEM_H__2F07760E_D7EC_11D2_8C4D_00C04F68F9B3__INCLUDED_)
#define AFX_SRVRITEM_H__2F07760E_D7EC_11D2_8C4D_00C04F68F9B3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CSvcMgrSrvrItem : public COleServerItem
{
	DECLARE_DYNAMIC(CSvcMgrSrvrItem)

// Constructors
public:
	CSvcMgrSrvrItem(CSvcMgrDoc* pContainerDoc);

// Attributes
	CSvcMgrDoc* GetDocument() const
		{ return (CSvcMgrDoc*)COleServerItem::GetDocument(); }

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSvcMgrSrvrItem)
	public:
	virtual BOOL OnDraw(CDC* pDC, CSize& rSize);
	virtual BOOL OnGetExtent(DVASPECT dwDrawAspect, CSize& rSize);
	//}}AFX_VIRTUAL

// Implementation
public:
	~CSvcMgrSrvrItem();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	virtual void Serialize(CArchive& ar);   // overridden for document i/o
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SRVRITEM_H__2F07760E_D7EC_11D2_8C4D_00C04F68F9B3__INCLUDED_)
