// ServiceAbout.cpp : implementation file
//

#include "stdafx.h"
#include "imSvcMgr.h"
#include "ServiceAbout.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// ServiceAbout dialog


ServiceAbout::ServiceAbout(CWnd* pParent /*=NULL*/)
	: CDialog(ServiceAbout::IDD, (CWnd*)pParent)
{
	//{{AFX_DATA_INIT(ServiceAbout)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void ServiceAbout::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(ServiceAbout)
	DDX_Control(pDX, IDC_EDIT_COMMENTS, m_Comments);
	//}}AFX_DATA_MAP 
}


BEGIN_MESSAGE_MAP(ServiceAbout, CDialog)
	//{{AFX_MSG_MAP(ServiceAbout)
	ON_WM_CANCELMODE()
	ON_EN_CHANGE(IDC_EDIT_COMMENTS, OnChangeEditComments)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// ServiceAbout message handlers

BOOL ServiceAbout::OnInitDialog() 
{
	CDialog::OnInitDialog();

	m_pService->LoadFromRegistry();
	IM::NrString aCaption = BuildCaption(IDS_SVCABOUT_190, m_pService->m_strServiceDisplayName.c_str(), m_pService->m_strComputerName.c_str());
	SetWindowText(aCaption.c_str());
	m_Comments.SetWindowText(m_pService->m_strComments.Get().c_str());
	GetDlgItem(IDOK)->EnableWindow(false);
	SetDefID(IDCANCEL);
	GetDlgItem(IDC_ABOUT_TEXT)->SetWindowText(m_pService->m_strVersion.Get().c_str());
	m_Comments.SetFocus();
	
	return 0;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void ServiceAbout::OnCancelMode() 
{
	CDialog::OnCancelMode();
}

void ServiceAbout::OnChangeEditComments() 
{
	GetDlgItem(IDOK)->EnableWindow(true);
	SetDefID(IDOK);
}

void ServiceAbout::OnOK() 
{
	CString aString;
	m_Comments.GetWindowText(aString);
	m_pService->m_strComments.Set(aString);

	try
	{
		m_pService->StoreInRegistry();
	}
	catch (IM::Exception &)
	{
	}
	
	CDialog::OnOK();
}
