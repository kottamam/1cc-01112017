#if !defined(AFX_IDXSVCPROP_H__3AB92DA4_0EEA_11D4_8BE2_00C04F0935D0__INCLUDED_)
#define AFX_IDXSVCPROP_H__3AB92DA4_0EEA_11D4_8BE2_00C04F0935D0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// IdxSvcProp.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CIdxSvcProp dialog

class CIdxSvcProp : public CDialog
{
// Construction
public:
	CIdxSvcProp(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CIdxSvcProp)
	enum { IDD = IDD_IDXSVC_PROPERTIES };
	CString	m_strDXMLPath;
	//}}AFX_DATA

	IM::IDXSVCConfiguration	*m_pService;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIdxSvcProp)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CIdxSvcProp)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnChangeEditDXMLPath();	
	//afx_msg void OnHelp();
	afx_msg void OnBrowse();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_IDXSVCPROP_H__3AB92DA4_0EEA_11D4_8BE2_00C04F0935D0__INCLUDED_)

