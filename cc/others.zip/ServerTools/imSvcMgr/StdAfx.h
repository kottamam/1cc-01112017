// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__2F077605_D7EC_11D2_8C4D_00C04F68F9B3__INCLUDED_)
#define AFX_STDAFX_H__2F077605_D7EC_11D2_8C4D_00C04F68F9B3__INCLUDED_

// For building with VS2008 and stlPort51
#ifdef WSNT_VS2008	//	********************* VS2008 ******************************************************************************
#include <WSNT_VS2008.h>
#endif	// WSNT_VS2008	********************* VS2008 ******************************************************************************


#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <afxole.h>         // MFC OLE classes
#include <afxodlgs.h>       // MFC OLE dialog classes
#include <afxdisp.h>        // MFC Automation classes
#include <Htmlhelp.h>		// HTML Help file
//#import "iwADFS.tlb" raw_interfaces_only named_guids
#ifndef _AFX_NO_DB_SUPPORT
#include <afxdb.h>			// MFC ODBC database classes
#endif // _AFX_NO_DB_SUPPORT

#ifndef _AFX_NO_DAO_SUPPORT
#include <afxdao.h>			// MFC DAO database classes
#endif // _AFX_NO_DAO_SUPPORT

#include <afxdtctl.h>		// MFC support for Internet Explorer 4 Common Controls
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			// MFC support for Windows Common Controls
#endif // _AFX_NO_AFXCMN_SUPPORT

#pragma warning ( disable : 4786 )

// COM/ATL includes
#include <comdef.h>
#include <comutil.h>
#include <tchar.h>
#include <assert.h>

// STL includes
#include <vector>
#include <map>
#include <list>
#include <queue>
#include <deque>
#include <stack>
#include <set>
#include <algorithm>
#include <functional>

// LDAP library includes
#include <imLdap/imLdap.h>

#include "imSvcMgrHelpId.h"
#include <afxcontrolbars.h>


//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__2F077605_D7EC_11D2_8C4D_00C04F68F9B3__INCLUDED_)
