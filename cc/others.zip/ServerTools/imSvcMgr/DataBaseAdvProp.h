#if !defined(AFX_DATABASEADVPROP_H__C5E2C1E7_F8EF_47CF_B288_3F9DAC0C1788__INCLUDED_)
#define AFX_DATABASEADVPROP_H__C5E2C1E7_F8EF_47CF_B288_3F9DAC0C1788__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DataBaseAdvProp.h : header file
//
//// Madhava - 
// This class can used for Prevent flat space filing and Undeclare the document grace period.
/////////////////////////////////////////////////////////////////////////////
// DataBaseAdvProp dialog

class DataBaseAdvProp : public CDialog
{
// Construction
public:
	DataBaseAdvProp(IM::DmsDatabaseEntry	*pEntry, CWnd* pParent = NULL);   // standard constructor

	~DataBaseAdvProp();

// Dialog Data
	//{{AFX_DATA(DataBaseAdvProp)
	enum { IDD = IDD_DIALOG_ADVANCED };
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(DataBaseAdvProp)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

private:
	IM::DmsDatabaseEntry	*m_pEntry;
	CButton *m_prv_flat_space_cbox_ptr;
	CEdit m_editGracePeriod;
	CSpinButtonCtrl	m_ctrlSpinGracePeriod;
	//CEdit m_editLocale;
	CButton m_rdoNoGracePeriod;
	CButton m_rdoInfiniteGracePeriod;
	CButton m_rdoSpeicifyGracePeriod;

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(DataBaseAdvProp)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnHelp();
	afx_msg void OnNoGracePeriod();
	afx_msg void OnInfiniteGracePeriod();
	afx_msg void OnSpecifyGracePeriod();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DATABASEADVPROP_H__C5E2C1E7_F8EF_47CF_B288_3F9DAC0C1788__INCLUDED_)
