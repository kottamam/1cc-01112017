// SelectODBC.cpp : implementation file
//

#include "stdafx.h"
#include "imSvcMgr.h"
#include "SelectODBC.h"
#include <stl/NrString.h>
#include <regstr.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

using namespace IM;

/////////////////////////////////////////////////////////////////////////////
// SelectODBC dialog


SelectODBC::SelectODBC(CWnd* pParent /*=NULL*/)
	: CDialog(SelectODBC::IDD, pParent)
{
	//{{AFX_DATA_INIT(SelectODBC)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

void SelectODBC::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(SelectODBC)
	DDX_Control(pDX, IDC_ODBC_LIST, m_OdbcList);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(SelectODBC, CDialog)
	//{{AFX_MSG_MAP(SelectODBC)
	ON_WM_CANCELMODE()
	ON_LBN_SELCHANGE(IDC_ODBC_LIST, OnSelchangeOdbcList)
	ON_LBN_DBLCLK(IDC_ODBC_LIST, OnDblclkOdbcList)
	ON_BN_CLICKED(IDCHELP, OnChelp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// SelectODBC message handlers

BOOL SelectODBC::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	NrString	strComputerName(m_pDatabaseList->m_strComputerName);
	NrString	strName;
	DWORD		dwValueType;
	TCHAR		szValueBuffer[REGSTR_MAX_VALUE_LENGTH];
	long		lValueBufferSize = sizeof(szValueBuffer);

	memset(szValueBuffer, 0, lValueBufferSize);

	IM::Registry	odbcReg(strComputerName.c_str(), HKEY_LOCAL_MACHINE, KEY_ODBC_SRC_PATH);

	odbcSourceName = _T("");
	m_OdbcList.ResetContent();

	if (odbcReg.Open(NULL, KEY_READ) != true)
	{
		Report(REP_WARN, IDS_ODBC_160);
		return TRUE;
	}

	while (odbcReg.EnumerateName(strName, dwValueType, szValueBuffer, lValueBufferSize) == true)
	{
		// add only those ODBC source names that are not in the repository list
		if (m_pDatabaseList->Get(strName.c_str()) == NULL)
			m_OdbcList.AddString(strName.c_str());
	}

	IM::NrString aCaption = BuildCaption(IDS_ODBC_161, strComputerName.c_str());
	SetWindowText(aCaption.c_str());
	m_OdbcList.SetFocus();
	return 0;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void SelectODBC::OnCancelMode() 
{
	CDialog::OnCancelMode();
	
	// TODO: Add your message handler code here
}

void SelectODBC::OnSelchangeOdbcList() 
{
	int index;

	if ((index = m_OdbcList.GetCurSel()) == LB_ERR)
		return;

	CString aString;

	m_OdbcList.GetText(index, aString);
	odbcSourceName = aString;
}

void SelectODBC::OnDblclkOdbcList() 
{
	OnSelchangeOdbcList();
	OnOK();
}

void SelectODBC::OnOK() 
{
	// TODO: Add extra validation here
	
	CDialog::OnOK();
}

void SelectODBC::OnChelp() 
{
	::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, 33);
}
