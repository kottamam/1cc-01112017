#if !defined(__LinkSiteServerProp_H__)
#define __LinkSiteServerProp_H__

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// LinkSiteServerProp.h : header file
//

//class DmsDatabaseList;

/////////////////////////////////////////////////////////////////////////////
// LinkSiteServerProp dialog

class LinkSiteServerProp : public CDialog
{
// Construction
public:
	LinkSiteServerProp(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(LinkSiteServerProp)
	enum { IDD = IDD_LINKSITESERVER_PROPERTIES };
	CSpinButtonCtrl	m_SpinConnectionCount;
	CString	m_DatabaseValue;
	CString	m_LogonID;
	CString	m_Password;
	CString	m_ConnectionCount;
	BOOL	m_Connections;
	int		m_nConnectionType;

	CString	m_strServerName;
	CString	m_strServerSSOUrl;
	CString	m_strServerBaseUrl;
	CString	m_strProxyUrl;
	CString m_strFolderNameFormat;
	CString m_strServerSFUrl;
	CString m_strCompEmailDomains;
	CString m_strSecureSentFolderName;
	CString m_strPrivKeyFileName;
	CString m_strPrivKeyFilePWD;
	BOOL    m_bTrustedLogin;
	BOOL	m_bIsAuthenticatedProxy;
	CString	m_strProxyUserName;
	CString	m_strProxyPassword;

	//BOOL	m_bSpecifyServicePort;
	//CString	m_strServicePort;
	//BOOL	m_bSpecifyFilePort;
	//CString	m_strFilePort;
	//}}AFX_DATA
	IM::DatabaseEntryList	*m_pDatabaseList;
	IM::DmsDatabaseEntry	*m_pEntry;
    bool					m_bAddMode;
	CString					m_SavedOdbcName;
	long					m_lLocale;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(LinkSiteServerProp)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(LinkSiteServerProp)
	virtual BOOL OnInitDialog();
	afx_msg void Changed();
	afx_msg void TrustedLoginChanged();
	afx_msg void AuthProxyChanged();
	virtual void OnOK();
	afx_msg void OnHelp();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	bool needPrimaryDatabase();

public:
	afx_msg void OnBnClickedkeyFileBrowse();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(__ServerProp_H__)
