// FileServerPropertySheet.h : header file
//
// This class defines custom modal property sheet 
// FileServerPropSheet.
 
#ifndef __FILESERVERPROPERTYSHEET_H__
#define __FILESERVERPROPERTYSHEET_H__

#include "fileserverpropertypage1.h"

class CNewSrvMgrDoc;
class FileServerConnectionInfo;

/////////////////////////////////////////////////////////////////////////////
// FileServerPropSheet

class FileServerPropSheet : public CPropertySheet
{
	DECLARE_DYNAMIC(FileServerPropSheet)

// Construction
public:
	FileServerPropSheet(CWnd* pWndParent = NULL);
	virtual ~FileServerPropSheet();

// Attributes
	FileServerPropertyPage m_Page1;
	FileServerPropertyPage2 m_Page2;
//	FileServerConnectionInfo *fsinfo;
	IM::FileServerConfiguration		*m_pFileServerConfiguration;

// Operations

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(FileServerPropSheet)
public:
protected:
	//}}AFX_VIRTUAL
	void OnHelp();

// Implementation

// Generated message map functions
protected:
	//{{AFX_MSG(FileServerPropSheet)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

#endif	// __FILESERVERPROPERTYSHEET_H__
