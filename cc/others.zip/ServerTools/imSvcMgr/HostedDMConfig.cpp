// HostedDMConfig.cpp : implementation file
//

#include "stdafx.h"
#include "imSvcMgr.h"
#include "HostedDMConfig.h"

// fowards
UINT DomainNamesThread_HostedDM( LPVOID pVoid );

BOOL isDlgClosed_HostedDM = FALSE;

HANDLE hDomainNames_HostedDM = NULL;

// HostedDMConfig dialog

IMPLEMENT_DYNAMIC(HostedDMConfig, CDialog)

HostedDMConfig::HostedDMConfig(IM::DmsServiceConfiguration	*pService, CWnd* pParent /*=NULL*/)
:CDialog(HostedDMConfig::IDD, pParent),
m_pService(pService)
{

}

HostedDMConfig::~HostedDMConfig()
{
}

void HostedDMConfig::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_COMBO_DS_SERVER_TYPE_HOSTED_DM, m_cboDSServerType);
	DDX_Control(pDX, IDC_EDIT_DS_SERVER_NAME_HOSTED_DM, m_edtDsServer);
	DDX_Control(pDX, IDC_COMBO_NTDOMAIN_HOSTED_DM, m_cboNtDomain);

}


BEGIN_MESSAGE_MAP(HostedDMConfig, CDialog)
	ON_BN_CLICKED(IDC_HOSTED_SSLKEY_BROWSE, &HostedDMConfig::OnBnClickedHostedSslkeyBrowse)
	ON_BN_CLICKED(IDOK, &HostedDMConfig::OnBnClickedOk)
	ON_BN_CLICKED(IDCANCEL, &HostedDMConfig::OnBnClickedCancel)
	ON_BN_CLICKED(IDC_HOSTED_SSLCA_BROWSE, &HostedDMConfig::OnBnClickedHostedSslcaBrowse)
	ON_BN_CLICKED(IDC_CHECK_SSL, OnSSLEenabled)
	ON_CBN_SELCHANGE(IDC_COMBO_DS_SERVER_TYPE_HOSTED_DM, OnSelchangeComboDsServerType)
	ON_CBN_EDITCHANGE(IDC_COMBO_NTDOMAIN_HOSTED_DM, OnEditchangeComboNtDomain)
END_MESSAGE_MAP()

BOOL HostedDMConfig::OnInitDialog() 
{
	CDialog::OnInitDialog();
	if (m_pService == NULL)
		return 0;

	TCHAR szBuffer[256];

	hDomainNames_HostedDM = CreateEvent( NULL, FALSE, FALSE, NULL );
	isDlgClosed_HostedDM = FALSE;
	AfxBeginThread( DomainNamesThread_HostedDM, ( LPVOID ) this );

	memset(szBuffer, 0, sizeof(szBuffer));
	_ltot(m_pService->m_lHostedServicePort.Get(), szBuffer, 10);
	SetDlgItemText(IDC_HOSTED_SERVICE_PORT, szBuffer);

	memset(szBuffer, 0, sizeof(szBuffer));
	_ltot(m_pService->m_lHostedFilePort.Get(), szBuffer, 10);
	SetDlgItemText(IDC_HOSTED_FILE_PORT, szBuffer);

	memset(szBuffer, 0, sizeof(szBuffer));
	_ltot(m_pService->m_lHostedSessionTimeOut.Get(), szBuffer, 10);
	SetDlgItemText(IDC_HOSTED_SESSION_TIMEOUT, szBuffer);

	SetDlgItemText(IDC_HOSTED_SSL_KEYFILE, m_pService->m_strHostedSSLKeyFilePath.Get().c_str());
	SetDlgItemText(IDC_HOSTED_SSL_KEYFILEPWD, m_pService->m_strHostedSSLKeyFilePassword.Get().c_str());
	SetDlgItemText(IDC_HOSTED_SSL_CAFILE, m_pService->m_strHostedSSLCACertPath.Get().c_str());

	m_cboDSServerType.SetCurSel (m_pService->m_lHostedTrustedLoginType.Get ());

	if (m_pService->m_bHostedSSLEnabled.Get() == false)
	{
		((CButton*)GetDlgItem(IDC_CHECK_SSL))->SetCheck(0);
		GetDlgItem(IDC_HOSTED_SSL_KEYFILE)->EnableWindow(FALSE);
		GetDlgItem(IDC_HOSTED_SSL_KEYFILEPWD)->EnableWindow(FALSE);
		GetDlgItem(IDC_HOSTED_SSL_CAFILE)->EnableWindow(FALSE);
		GetDlgItem(IDC_HOSTED_SSLKEY_BROWSE)->EnableWindow(FALSE);
		GetDlgItem(IDC_HOSTED_SSLCA_BROWSE)->EnableWindow(FALSE);
		m_cboDSServerType.EnableWindow (FALSE);
	}
	else
	{
		((CButton*)GetDlgItem(IDC_CHECK_SSL))->SetCheck(1);
	}
	
	int iServerType = m_cboDSServerType.GetCurSel( );

	if( iServerType == 1 )
	{
		int ret = m_cboNtDomain.SelectString( -1, m_pService->m_strHostedTrustedLoginServer.Get ().c_str( ) );
		if( ret == CB_ERR )
		{
			m_cboNtDomain.SetWindowText( m_pService->m_strHostedTrustedLoginServer.Get( ).c_str( ) );
		}
	}
	else
	{
		m_edtDsServer.SetWindowText( m_pService->m_strHostedTrustedLoginServer.Get( ).c_str( ) );
	}

	bool bADS = iServerType == 0;
	bool bNT = iServerType == 1;
	m_edtDsServer.ShowWindow( !bNT ? SW_SHOW : SW_HIDE );
	m_cboNtDomain.ShowWindow( !bNT ? SW_HIDE : SW_SHOW );
	m_edtDsServer.UpdateWindow( );
	m_cboNtDomain.UpdateWindow( );

	return 0;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

// HostedDMConfig message handlers

void HostedDMConfig::OnBnClickedHostedSslkeyBrowse()
{	
	TCHAR szFilters[]= _T("Pem Files (*.pem)|*.pem|All Files (*.*)|*.*||");
	
	CFileDialog aFileDialog(TRUE, _T("pem"), _T("*.pem"),
		OFN_FILEMUSTEXIST | OFN_HIDEREADONLY, szFilters);

	if (aFileDialog.DoModal() != IDOK)
		return;

	SetDlgItemText(IDC_HOSTED_SSL_KEYFILE, aFileDialog.GetPathName());	
}

void HostedDMConfig::OnBnClickedOk()
{
	CString aString = _T("");
	GetDlgItemText(IDC_HOSTED_SERVICE_PORT, aString);
	m_pService->m_lHostedServicePort.Set(_ttol((LPCTSTR)aString));

	aString = _T("");
	GetDlgItemText(IDC_HOSTED_FILE_PORT, aString);
	m_pService->m_lHostedFilePort.Set(_ttol((LPCTSTR)aString));

	aString = _T("");
	GetDlgItemText(IDC_HOSTED_SESSION_TIMEOUT, aString);
	m_pService->m_lHostedSessionTimeOut.Set(_ttol((LPCTSTR)aString));

	if (((CButton*)GetDlgItem(IDC_CHECK_SSL))->GetCheck() == 1)
	{
		m_pService->m_bHostedSSLEnabled.Set(true);

		aString = _T("");
		GetDlgItemText(IDC_HOSTED_SSL_KEYFILE, aString);
		m_pService->m_strHostedSSLKeyFilePath.Set((LPCTSTR)aString);

		aString = _T("");
		GetDlgItemText(IDC_HOSTED_SSL_KEYFILEPWD, aString);
		m_pService->m_strHostedSSLKeyFilePassword.Set((LPCTSTR)aString);

		aString = _T("");
		GetDlgItemText(IDC_HOSTED_SSL_CAFILE, aString);
		m_pService->m_strHostedSSLCACertPath.Set((LPCTSTR)aString);
	}
	else
	{
		m_pService->m_bHostedSSLEnabled.Set(false);
	}

	long lServerType = m_cboDSServerType.GetCurSel ();
	m_pService->m_lHostedTrustedLoginType.Set (lServerType);
	CString cServerName;

	if( lServerType == 1 )
	{
		m_cboNtDomain.GetWindowText(cServerName );
	}
	else
	{
		m_edtDsServer.GetWindowText( cServerName );
	}
	m_pService->m_strHostedTrustedLoginServer.Set ((LPCTSTR)cServerName);

	if( hDomainNames_HostedDM != NULL )
	{
		isDlgClosed_HostedDM = TRUE;
		CloseHandle( hDomainNames_HostedDM );
	}
	
	OnOK();
}

void HostedDMConfig::OnBnClickedCancel()
{
	if( hDomainNames_HostedDM != NULL )
	{
		isDlgClosed_HostedDM = TRUE;
		CloseHandle( hDomainNames_HostedDM );
	}

	OnCancel();
}


void HostedDMConfig::OnChange()
{
	//TODO: 
}

void HostedDMConfig::OnBnClickedHostedSslcaBrowse()
{
	TCHAR szFilters[]= _T("Pem Files (*.pem)|*.pem|All Files (*.*)|*.*||");
	
	CFileDialog aFileDialog(TRUE, _T("pem"), _T("*.pem"),
		OFN_FILEMUSTEXIST | OFN_HIDEREADONLY, szFilters);

	if (aFileDialog.DoModal() != IDOK)
		return;

	SetDlgItemText(IDC_HOSTED_SSL_CAFILE, aFileDialog.GetPathName());	
}

void HostedDMConfig::OnSSLEenabled()
{
	if (((CButton*)GetDlgItem(IDC_CHECK_SSL))->GetCheck() == 1)
	{
		GetDlgItem(IDC_HOSTED_SSL_KEYFILE)->EnableWindow(TRUE);
		GetDlgItem(IDC_HOSTED_SSL_KEYFILEPWD)->EnableWindow(TRUE);
		GetDlgItem(IDC_HOSTED_SSL_CAFILE)->EnableWindow(TRUE);
		GetDlgItem(IDC_HOSTED_SSLKEY_BROWSE)->EnableWindow(TRUE);
		GetDlgItem(IDC_HOSTED_SSLCA_BROWSE)->EnableWindow(TRUE);
		m_cboDSServerType.EnableWindow (TRUE);
	}
	else
	{
		GetDlgItem(IDC_HOSTED_SSL_KEYFILE)->EnableWindow(FALSE);
		GetDlgItem(IDC_HOSTED_SSL_KEYFILEPWD)->EnableWindow(FALSE);
		GetDlgItem(IDC_HOSTED_SSL_CAFILE)->EnableWindow(FALSE);
		GetDlgItem(IDC_HOSTED_SSLKEY_BROWSE)->EnableWindow(FALSE);
		GetDlgItem(IDC_HOSTED_SSLCA_BROWSE)->EnableWindow(FALSE);
		m_cboDSServerType.EnableWindow (FALSE);
	}
}
void HostedDMConfig::OnSelchangeComboDsServerType() 
{
	long lDSServiceType = m_cboDSServerType.GetCurSel( );
	if( lDSServiceType == 1 )
	{
		m_edtDsServer.ShowWindow (FALSE);
		m_cboNtDomain.ShowWindow (TRUE);

		DSOM::CNT nt;

		int iCurSel = m_cboNtDomain.GetCurSel();
		if( iCurSel == -1 )
		{
			CString strDomain = _T( "" );
			m_cboNtDomain.GetWindowText( strDomain );
			if( strDomain.GetLength() == 0 )
			{
				_bstr_t strCurrentDomain = _T( "" );
				nt.getCurrentDomain( strCurrentDomain );
				int ret = m_cboNtDomain.SelectString( -1, strCurrentDomain );
				if( ret == CB_ERR )
				{
					m_cboNtDomain.SetWindowText( ( LPCTSTR ) strCurrentDomain );
				}
			}
		}
	}
	else
	{
		m_edtDsServer.ShowWindow (TRUE);
		m_cboNtDomain.ShowWindow (FALSE);

	}
}
void HostedDMConfig::OnEditchangeComboNtDomain() 
{
	bool  bEnableOKButton = false;
	CString strDSServer;
	long lDSServiceType = m_cboDSServerType.GetCurSel( );

	if( lDSServiceType == 1 )
	{
		// the NT domain is the "DS Server"
		int iCurSel = m_cboNtDomain.GetCurSel( );
		if( iCurSel == -1 )
		{
			
			m_cboNtDomain.GetWindowText( strDSServer );
			
		}
		else
		{
			m_cboNtDomain.GetLBText( iCurSel, strDSServer );

			if( strDSServer == _T( "Loading domains..." ) )
				bEnableOKButton = false;
		}
	}
}
UINT DomainNamesThread_HostedDM( LPVOID pVoid )
{
	HostedDMConfig* pConnection = reinterpret_cast< HostedDMConfig* >( pVoid );
	if( pConnection != NULL )
	{
		CString strDomain = _T( "" );
		pConnection->m_cboNtDomain.GetWindowText( strDomain );

		CString strLoadingMsg = _T( "Loading domains..." );
		//pConnection->m_cboNtDomain.ResetContent( );
		pConnection->m_cboNtDomain.AddString( strLoadingMsg );
		//pConnection->m_cboNtDomain.SelectString( -1, strLoadingMsg );

		DSOM::CNT nt;
		ObjectContainers::CUniqueBstrVector vDomainNames; 
		nt.getDomainNames( vDomainNames );

		if (isDlgClosed_HostedDM)
		{
			return 0;
		}

		pConnection->m_vDomainNames = vDomainNames;

		pConnection->m_cboNtDomain.ResetContent( );

		for( ObjectContainers::CUniqueBstrVector::Const_Iterator iter = pConnection->m_vDomainNames.Begin( ); iter != pConnection->m_vDomainNames.End( ); iter++ )
		{
			if (isDlgClosed_HostedDM)
			{
				return 0;
			}
			_bstr_t strDomain = *iter;
			pConnection->m_cboNtDomain.AddString( strDomain );
		}

		if( strDomain.GetLength() == 0 )
		{
			_bstr_t strCurrentDomain = _T( "" );
			nt.getCurrentDomain( strCurrentDomain );

			pConnection->m_cboNtDomain.SelectString( -1, strCurrentDomain );
		}
		else
			pConnection->m_cboNtDomain.SetWindowText( strDomain );

		SetEvent( hDomainNames_HostedDM );
	}

	return 0;
}



