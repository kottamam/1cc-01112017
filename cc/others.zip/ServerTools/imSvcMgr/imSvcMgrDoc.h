// imSvcMgrDoc.h : interface of the CSvcMgrDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_SVCMGRDOC_H__2F077609_D7EC_11D2_8C4D_00C04F68F9B3__INCLUDED_)
#define AFX_SVCMGRDOC_H__2F077609_D7EC_11D2_8C4D_00C04F68F9B3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

typedef IM::STLPointer<IM::ServiceConfiguration>	ServicePointer;
typedef imstd::list<ServicePointer>					ServiceList;

class CSvcMgrSrvrItem;

using namespace IM;

class CSvcMgrDoc : public COleServerDoc
{
protected: // create from serialization only
	CSvcMgrDoc();
	DECLARE_DYNCREATE(CSvcMgrDoc)
// Attributes
public:
	CSvcMgrSrvrItem* GetEmbeddedItem()
		{ return (CSvcMgrSrvrItem*)COleServerDoc::GetEmbeddedItem(); }

	bool	AddService(ServiceConfiguration *pService_, CImageList* pImageList_);
	bool addServer(const IM::NrString& serverName, bool verbose = true);
	bool isServerInList(const IM::NrString& serverName);

// Operations
	ServiceConfiguration	*GetSelectedService()									{ return(m_pSelectedService); }
	void					SetSelectedService(ServiceConfiguration *pService_)		{ m_pSelectedService = pService_; }
	ServiceList				&GetServiceList()										{ return(m_serviceList); }

public:
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSvcMgrDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	protected:
	virtual COleServerItem* OnGetEmbeddedItem();
	//}}AFX_VIRTUAL

	afx_msg void OnRegisterServer( );
	afx_msg void OnFindServers( );
	afx_msg void OnUnregisterServer( );
	afx_msg void OnStartService( );
	afx_msg void OnStopService( );
	afx_msg void OnViewLog( );
	afx_msg void OnDatabasesSetup( );
	afx_msg void OnFileServerSetup( );
	afx_msg void OnServiceProperties( );
	afx_msg void OnStartupProperties( );
	afx_msg void OnServiceAbout( );

	afx_msg void OnUpdateEditLinksMenu( CCmdUI* pCmdUI );
	afx_msg void OnUpdateObjectVerbMenu( CCmdUI* pCmdUI );

// Implementation
public:
	virtual ~CSvcMgrDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CSvcMgrDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	// Generated OLE dispatch map functions
	//{{AFX_DISPATCH(CSvcMgrDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DISPATCH
	ServiceList					m_serviceList;				// individual iManage service information
	IM::ServiceConfiguration	*m_pSelectedService;		// currently selected service in ListView

	DECLARE_DISPATCH_MAP()
	DECLARE_INTERFACE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SVCMGRDOC_H__2F077609_D7EC_11D2_8C4D_00C04F68F9B3__INCLUDED_)
