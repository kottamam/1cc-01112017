// LinkSiteServerProp.cpp : implementation file 
//

#include <stdafx.h>

#include <imSvcMgr.h>
#include <LinkSiteServerProp.h>

#define IMANAGE_SHARE_US_URL _T("https://www.imanageshare.com")
#define IMANAGE_SHARE_UK_URL _T("https://www.imanageshare.co.uk")
#define IMANAGE_SHARE_ASIA_URL _T("https://www.imanageshare-asia.com")

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif    

/////////////////////////////////////////////////////////////////////////////
// LinkSiteServerProp dialog


LinkSiteServerProp::LinkSiteServerProp(CWnd* pParent /*=NULL*/)
	: CDialog(LinkSiteServerProp::IDD, pParent)
{
	//{{AFX_DATA_INIT(LinkSiteServerProp)
	m_LogonID = _T("");
	m_Password = _T("");

	m_ConnectionCount = _T("");
	m_Connections = FALSE;
	m_bTrustedLogin = FALSE;

	//m_bSpecifyServicePort = false;
	//m_strServicePort = _T("");

	//m_bSpecifyFilePort = false;
	//m_strFilePort = _T("");

	m_nConnectionType = 0;

	m_pEntry = NULL;
	//}}AFX_DATA_INIT
}


void LinkSiteServerProp::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(LinkSiteServerProp)
	//DDX_Text(pDX, IDC_SERVER, m_strServerSSOUrl);
	//DDX_Text(pDX, IDC_SERVER2, m_strServerBaseUrl);
	DDX_Text(pDX, IDC_SERVER3, m_strProxyUrl);
	DDX_Text(pDX, IDC_SERVER4, m_strServerName);
	DDX_Text(pDX, IDC_SERVER5, m_strFolderNameFormat);
	//DDX_Text(pDX, IDC_SERVER_SF_URL, m_strServerSFUrl);
	DDX_Text(pDX, IDC_EMAIL_DOMAINS, m_strCompEmailDomains);
	DDX_Text(pDX, IDC_SERVER7, m_strSecureSentFolderName);

	DDX_Text(pDX, IDC_LOGONID, m_LogonID);
	DDX_Text(pDX, IDC_PASSWORD, m_Password);

	DDX_Check(pDX, IDC_CONNECTIONS, m_Connections);
	DDX_Control(pDX, IDC_SPIN_CONNECTION_COUNT, m_SpinConnectionCount);
	DDX_Text(pDX, IDC_CONNECT_COUNT_EDIT, m_ConnectionCount);

	DDX_Check(pDX, IDC_CHECK_TRUSTEDLOGIN, m_bTrustedLogin);

	DDX_Check(pDX, IDC_CHECK_AUTHPROXY, m_bIsAuthenticatedProxy);


	//DDX_Check(pDX, IDC_GIVEN_SERV_PORT, m_bSpecifyServicePort);
	//DDX_Text(pDX, IDC_SERVICE_PORT, m_strServicePort);

	//DDX_Check(pDX, IDC_GIVEN_FILE_PORT, m_bSpecifyFilePort);
	//DDX_Text(pDX, IDC_FILE_PORT, m_strFilePort);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(LinkSiteServerProp, CDialog)
	//{{AFX_MSG_MAP(LinkSiteServerProp)
	ON_BN_CLICKED(IDC_KEYFILE_BROWSE, &LinkSiteServerProp::OnBnClickedkeyFileBrowse)

	//ON_EN_CHANGE(IDC_SERVER, Changed)
	//ON_EN_CHANGE(IDC_SERVER2, Changed)
	ON_EN_CHANGE(IDC_SERVER3, Changed)
	ON_EN_CHANGE(IDC_SERVER4, Changed)
	ON_EN_CHANGE(IDC_SERVER5, Changed)
	//ON_EN_CHANGE(IDC_SERVER_SF_URL, Changed)
	ON_EN_CHANGE(IDC_EMAIL_DOMAINS, Changed)
	ON_EN_CHANGE(IDC_SERVER7, Changed)


	ON_EN_CHANGE(IDC_LOGONID, Changed)
	ON_EN_CHANGE(IDC_PASSWORD, Changed)

	ON_BN_CLICKED(IDC_CONNECTIONS, Changed)
	ON_EN_CHANGE(IDC_CONNECT_COUNT_EDIT, Changed)

	ON_EN_CHANGE(IDC_KEYFILEPATH, Changed)
	ON_EN_CHANGE(IDC_PASSWORD2, Changed)

	ON_BN_CLICKED(IDC_CHECK_TRUSTEDLOGIN, TrustedLoginChanged)
	ON_BN_CLICKED(IDC_CHECK_AUTHPROXY, AuthProxyChanged)
	ON_EN_CHANGE(IDC_EDIT_PROXY_USERNAME, Changed)
	ON_EN_CHANGE(IDC_EDIT_PROXY_PSWD, Changed)

	/*ON_BN_CLICKED(IDC_GIVEN_SERV_PORT, Changed)
	ON_EN_CHANGE(IDC_SERVICE_PORT, Changed)

	ON_BN_CLICKED(IDC_GIVEN_FILE_PORT, Changed)
	ON_EN_CHANGE(IDC_FILE_PORT, Changed)*/

	ON_BN_CLICKED(IDHELP, OnHelp)
	//}}AFX_MSG_MAP
//	ON_BN_CLICKED(IDC_RADIO_US_SHARE, &LinkSiteServerProp::OnBnClickedRadioUsShare)
//	ON_BN_CLICKED(IDC_RADIO_UK_SHARE, &LinkSiteServerProp::OnBnClickedRadioUkShare)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// LinkSiteServerProp message handlers
 
BOOL LinkSiteServerProp::OnInitDialog()  
{
	UpdateData(0);
 
	// if MODIFY
	if (m_DatabaseValue.IsEmpty() == FALSE)
	{
		m_bAddMode = true;

		// Get repository information for this database and display
		m_pEntry = (IM::DmsDatabaseEntry *) m_pDatabaseList->Get((LPCTSTR)m_DatabaseValue);

		if(m_pEntry == NULL)
		{
	    	Report(REP_WARN, IDS_DBPROP_115);
			SendMessage(WM_CLOSE);
			return TRUE;
		}
		else if(m_pEntry->m_lConnectionType.Get() != IM::DatabaseEntry::HpFlow )
		{
	    	Report(REP_WARN, IDS_DBPROP_115);
			SendMessage(WM_CLOSE);
			return TRUE;
		}

		m_strServerName = m_DatabaseValue;
		GetDlgItem(IDC_SERVER4)->EnableWindow(false);

		((CButton*)GetDlgItem(IDC_CONNECTIONS))->SetCheck(1);

		m_nConnectionType = IM::DatabaseEntry::HpFlow ;

		// enable the database connection info
		GetDlgItem(IDC_LOGONID)->EnableWindow(true);
		GetDlgItem(IDC_PASSWORD)->EnableWindow(true);

		m_LogonID = m_pEntry->m_strLogonID.Get().c_str();
		m_Password = m_pEntry->m_strPassword.Get().c_str();

		m_strServerSSOUrl = m_pEntry->m_strSSOUrl .Get ().c_str ();
		m_strServerBaseUrl = m_pEntry->m_strBaseUrl .Get ().c_str ();
		m_strProxyUrl = m_pEntry->m_strProxyServer .Get ().c_str ();
		m_strFolderNameFormat = m_pEntry->m_strFolderNameFormat .Get ().c_str ();
		m_strServerSFUrl = m_pEntry->m_strSFUrl.Get().c_str();
		m_strCompEmailDomains = m_pEntry->m_strCompanyEmailDomains.Get().c_str();
		m_strSecureSentFolderName = m_pEntry->m_strSecureSentFolderName.Get().c_str();
		m_bIsAuthenticatedProxy = m_pEntry->m_bAuthenticatedProxy.Get();
		m_strProxyUserName = m_pEntry->m_strProxyUserName.Get().c_str();
		m_strProxyPassword = m_pEntry->m_strProxyPassword.Get().c_str();

		if (m_pEntry->m_bAsManyConnectionsAsThreads.Get() == true)
		{
			GetDlgItem(IDC_CONNECT_COUNT_EDIT)->EnableWindow(false);
			GetDlgItem(IDC_SPIN_CONNECTION_COUNT)->EnableWindow(false);
		}
		else
		{
			CString aString;
			_itot(m_pEntry->m_lConnectionCount.Get(), (_TCHAR*)(LPCSTR)aString.GetBuffer(10), 10);
			aString.ReleaseBuffer();
			m_ConnectionCount = aString;

			GetDlgItem(IDC_CONNECT_COUNT_EDIT)->EnableWindow(true);
			GetDlgItem(IDC_SPIN_CONNECTION_COUNT)->EnableWindow(true);
		}

		((CButton*)GetDlgItem(IDC_CONNECTIONS))->SetCheck(m_pEntry->m_bAsManyConnectionsAsThreads.Get());
        m_Connections = m_pEntry->m_bAsManyConnectionsAsThreads.Get();

		SetDlgItemText(IDC_KEYFILEPATH, m_pEntry->m_strHpFlowKeyFilePath .Get().c_str());
		SetDlgItemText(IDC_PASSWORD2, m_pEntry->m_strHpFlowKeyFilePWD .Get().c_str());
		m_bTrustedLogin = m_pEntry->m_bLSTrustedLogin.Get() ? TRUE : FALSE;

		//if ( (m_pEntry->m_strHpFlowKeyFilePath.Get().length () != 0 ) && ( m_pEntry->m_strHpFlowKeyFilePWD .Get().length () != 0 ) )
		if(m_bTrustedLogin == TRUE)
		{
			//m_bTrustedLogin = TRUE;
			((CButton*)GetDlgItem(IDC_CHECK_TRUSTEDLOGIN))->SetCheck(1);
		}
		else
		{
			m_bTrustedLogin = FALSE;
			((CButton*)GetDlgItem(IDC_CHECK_TRUSTEDLOGIN))->SetCheck(0);

			GetDlgItem(IDC_KEYFILEPATH)->EnableWindow(false);
			GetDlgItem(IDC_PASSWORD2)->EnableWindow(false);
			GetDlgItem(IDC_KEYFILE_BROWSE)->EnableWindow(false);
		}

		SetDlgItemText(IDC_EDIT_PROXY_USERNAME, m_pEntry->m_strProxyUserName.Get().c_str());
		SetDlgItemText(IDC_EDIT_PROXY_PSWD, m_pEntry->m_strProxyPassword.Get().c_str());
		m_bIsAuthenticatedProxy = m_pEntry->m_bAuthenticatedProxy.Get() ? TRUE : FALSE;

		if(m_bIsAuthenticatedProxy == TRUE)
			((CButton*)GetDlgItem(IDC_CHECK_AUTHPROXY))->SetCheck(1);
		else
		{
			((CButton*)GetDlgItem(IDC_CHECK_AUTHPROXY))->SetCheck(0);
			GetDlgItem(IDC_EDIT_PROXY_USERNAME)->EnableWindow(false);
			GetDlgItem(IDC_EDIT_PROXY_PSWD)->EnableWindow(false);
		}
		
		if (m_strServerSSOUrl == IMANAGE_SHARE_US_URL)
		{
			CButton* aButton = (CButton*)GetDlgItem(IDC_RADIO_US_SHARE);
			if (aButton)
				aButton->SetCheck(true);
		}
		else if (m_strServerSSOUrl == IMANAGE_SHARE_UK_URL)
		{
			CButton* aButton = (CButton*)GetDlgItem(IDC_RADIO_UK_SHARE);
			if (aButton)
				aButton->SetCheck(true);
		}
		else if (m_strServerSSOUrl == IMANAGE_SHARE_ASIA_URL)
		{
			CButton* aButton = (CButton*)GetDlgItem(IDC_RADIO_ASIA_SHARE);
			if (aButton)
				aButton->SetCheck(true);
		}
		else // default to US share always
		{
			CButton* aButton = (CButton*)GetDlgItem(IDC_RADIO_US_SHARE);
			if (aButton)
				aButton->SetCheck(true);
		}
	}
	else	// else ADD
	{
		m_bAddMode = false;

		m_Connections = true;
		m_ConnectionCount = _T("0");
		GetDlgItem(IDC_CONNECT_COUNT_EDIT)->EnableWindow(false);

		CButton* aButton = (CButton*)GetDlgItem(IDC_RADIO_US_SHARE);
		if (aButton)
			aButton->SetCheck(true);

		// disable the proxy server connection info
		//GetDlgItem(IDC_SERVER)->EnableWindow(true);    // SSO URL
		//GetDlgItem(IDC_SERVER2)->EnableWindow(true);   // Base URL
		GetDlgItem(IDC_SERVER3)->EnableWindow(true);   // Proxy URL
		GetDlgItem(IDC_SERVER4)->EnableWindow(true);  // Cluster/Server Name
		GetDlgItem(IDC_SERVER5)->EnableWindow(true);  // Folder Name Format
		//GetDlgItem(IDC_SERVER_SF_URL)->EnableWindow(true); //Storefront URL
		GetDlgItem(IDC_EMAIL_DOMAINS)->EnableWindow(true); //Company Email Domains
		GetDlgItem(IDC_SERVER7)->EnableWindow(true); //Secure Sent Folder Name

		GetDlgItem(IDC_LOGONID)->EnableWindow(true);
		GetDlgItem(IDC_PASSWORD)->EnableWindow(true);

		m_bTrustedLogin = FALSE;
		((CButton*)GetDlgItem(IDC_CHECK_TRUSTEDLOGIN))->SetCheck(0);
		GetDlgItem(IDC_KEYFILEPATH)->EnableWindow(false);
		GetDlgItem(IDC_PASSWORD2)->EnableWindow(false);
		GetDlgItem(IDC_KEYFILE_BROWSE)->EnableWindow(false);

		m_bIsAuthenticatedProxy = FALSE;
		((CButton*)GetDlgItem(IDC_CHECK_AUTHPROXY))->SetCheck(0);
		GetDlgItem(IDC_EDIT_PROXY_USERNAME)->EnableWindow(false);
		GetDlgItem(IDC_EDIT_PROXY_PSWD)->EnableWindow(false);
		

		m_strFolderNameFormat = "%C1ALIAS%-%C2ALIAS%.%C2DESCR%";
		m_strSecureSentFolderName = "Secure Sent Links";

	}

	


	// Allow OK button only after a change
	GetDlgItem(IDOK)->EnableWindow(false);

	SetDefID(IDCANCEL);

	m_SpinConnectionCount.SetRange(0, 100);
	m_SpinConnectionCount.SetBuddy(GetDlgItem(IDC_CONNECT_COUNT_EDIT));

	CDialog::OnInitDialog();

	return(0);
}

void LinkSiteServerProp::Changed() 
{
	if (!GetDlgItem(IDOK) || !::IsWindow(GetDlgItem(IDOK)->m_hWnd))
	{
		return;
	}

	/*BOOL bSpecifyServerPort = ((CButton*) GetDlgItem(IDC_GIVEN_SERV_PORT))->GetCheck();
	if (bSpecifyServerPort)
	{
		GetDlgItem(IDC_SERVICE_PORT)->EnableWindow(true);
	}
	else
	{
		GetDlgItem(IDC_SERVICE_PORT)->EnableWindow(false);
	}*/

	/*BOOL bSpecifyFilePort = ((CButton*) GetDlgItem(IDC_GIVEN_FILE_PORT))->GetCheck();
	if (bSpecifyFilePort)
	{
		GetDlgItem(IDC_FILE_PORT)->EnableWindow(true);
	}
	else
	{
		GetDlgItem(IDC_FILE_PORT)->EnableWindow(false);
	}*/

	// If "Specify Service Port" is set and the port field is empty, disable OK button.
	/*CString strServicePort;
	GetDlgItem(IDC_SERVICE_PORT)->GetWindowText(strServicePort);
	strServicePort.TrimLeft();
	strServicePort.TrimRight();
	if ((bSpecifyServerPort) && (strServicePort.IsEmpty()))
	{
		GetDlgItem(IDOK)->EnableWindow(false);
		SetDefID(IDCANCEL);
		return;
	}*/

	// If "Specify File Port" is set and the port field is empty, disable OK button.
	/*CString strFilePort;
	GetDlgItem(IDC_FILE_PORT)->GetWindowText(strFilePort);
	strFilePort.TrimLeft();
	strFilePort.TrimRight();
	if ((bSpecifyFilePort) && (strFilePort.IsEmpty()))
	{
		GetDlgItem(IDOK)->EnableWindow(false);
		SetDefID(IDCANCEL);
		return;
	}*/

	/*CString strServer;
	GetDlgItem(IDC_SERVER)->GetWindowText(strServer);
	strServer.TrimLeft();
	strServer.TrimRight();
	if (strServer.IsEmpty())
	{
		GetDlgItem(IDOK)->EnableWindow(false);
		SetDefID(IDCANCEL);
		return;
	}

	CString strServer2;
	GetDlgItem(IDC_SERVER2)->GetWindowText(strServer2);
	strServer2.TrimLeft();
	strServer2.TrimRight();
	if (strServer2.IsEmpty())
	{
		GetDlgItem(IDOK)->EnableWindow(false);
		SetDefID(IDCANCEL);
		return;
	}

	CString strServer3;
	GetDlgItem(IDC_SERVER3)->GetWindowText(strServer3);
	strServer3.TrimLeft();
	strServer3.TrimRight();
	if (strServer3.IsEmpty())
	{
		GetDlgItem(IDOK)->EnableWindow(false);
		SetDefID(IDCANCEL);
		return;
	}*/

	CString strServer4;
	GetDlgItem(IDC_SERVER4)->GetWindowText(strServer4);
	strServer4.TrimLeft();
	strServer4.TrimRight();
	if (strServer4.IsEmpty())
	{
		GetDlgItem(IDOK)->EnableWindow(false);
		SetDefID(IDCANCEL);
		return;
	}

	if (((CButton*)GetDlgItem(IDC_CONNECTIONS))->GetCheck() == 1)
	{
		GetDlgItem(IDC_CONNECT_COUNT_EDIT)->EnableWindow(0);
		GetDlgItem(IDC_SPIN_CONNECTION_COUNT)->EnableWindow(0);

		m_ConnectionCount = _T("0");
	}
	else
	{
		GetDlgItem(IDC_CONNECT_COUNT_EDIT)->EnableWindow();
		GetDlgItem(IDC_SPIN_CONNECTION_COUNT)->EnableWindow();
	}

	GetDlgItem(IDOK)->EnableWindow(true);

	SetDefID(IDOK);	
}

void LinkSiteServerProp::OnOK() 
{
	CString strServicePort;
	CString strFilePort;
	long lServicePort = 0;
	long lFilePort = 0;

	m_nConnectionType = IM::DatabaseEntry::HpFlow ;

	//GetDlgItem(IDC_SERVER)->GetWindowText(m_strServerSSOUrl);
	//GetDlgItem(IDC_SERVER2)->GetWindowText(m_strServerBaseUrl);
	//GetDlgItem(IDC_SERVER_SF_URL)->GetWindowText(m_strServerSFUrl);
	GetDlgItem(IDC_SERVER3)->GetWindowText(m_strProxyUrl);
	GetDlgItem(IDC_SERVER4)->GetWindowText(m_strServerName);
	GetDlgItem(IDC_SERVER5)->GetWindowText(m_strFolderNameFormat);
	GetDlgItem(IDC_EMAIL_DOMAINS)->GetWindowText(m_strCompEmailDomains);
	GetDlgItem(IDC_SERVER7)->GetWindowText(m_strSecureSentFolderName);
	GetDlgItem(IDC_KEYFILEPATH)->GetWindowText(m_strPrivKeyFileName);
	GetDlgItem(IDC_PASSWORD2)->GetWindowText(m_strPrivKeyFilePWD);
	if (((CButton*)GetDlgItem(IDC_CHECK_TRUSTEDLOGIN))->GetCheck() == TRUE)
	{
		if(!m_strPrivKeyFileName.GetLength () || !m_strPrivKeyFilePWD.GetLength () )
		{
			MessageBox(_T("Trusted Login is enabled, Please make sure Private Key File Path and Password are filled !"), _T("Error"), MB_OK);
			return;
		}

	}
	
	m_SavedOdbcName = m_strServerName;

	if (!m_bAddMode)
	{
		m_pEntry = (IM::DmsDatabaseEntry *) m_pDatabaseList->NewEntry(m_SavedOdbcName);
	}
	else
	{
		m_pEntry->m_strDatabase.Set(m_SavedOdbcName);
	}

	CButton* aButton = (CButton*)GetDlgItem(IDC_RADIO_US_SHARE);
	int hostnameSelection = 0;

	if (aButton->GetCheck() == FALSE)
	{
		aButton = (CButton*)GetDlgItem(IDC_RADIO_UK_SHARE);

		if (aButton->GetCheck() == TRUE)
		{
			hostnameSelection = 1;
		}
		else
		{
			hostnameSelection = 2;
		}
	}

	vector<CString> hostnameTokens{ IMANAGE_SHARE_US_URL, IMANAGE_SHARE_UK_URL, IMANAGE_SHARE_ASIA_URL };
	CString strServer;
	if (hostnameSelection < hostnameTokens.size())
	{
		strServer = hostnameTokens.at(hostnameSelection);
	}

	GetDlgItem(IDC_CONNECT_COUNT_EDIT)->GetWindowText(m_ConnectionCount);

	m_pEntry->m_strSSOUrl.Set (strServer);
	m_pEntry->m_strBaseUrl .Set (strServer + _T("/api/v2"));
	m_pEntry->m_strSFUrl.Set(strServer);
	m_pEntry->m_strProxyServer.Set (m_strProxyUrl);
	m_pEntry->m_strFolderNameFormat.Set (m_strFolderNameFormat);
	m_pEntry->m_strCompanyEmailDomains.Set(m_strCompEmailDomains);
	m_pEntry->m_strSecureSentFolderName.Set(m_strSecureSentFolderName);
	m_pEntry->m_strHpFlowKeyFilePath.Set(m_strPrivKeyFileName);
	m_pEntry->m_strHpFlowKeyFilePWD.Set (m_strPrivKeyFilePWD);
	m_pEntry->m_bLSTrustedLogin .Set (m_bTrustedLogin == TRUE ? true: false);

	m_pEntry->m_lConnectionType.Set(m_nConnectionType);

	GetDlgItem(IDC_LOGONID)->GetWindowText(m_LogonID);
	m_pEntry->m_strLogonID.Set(m_LogonID);

	GetDlgItem(IDC_PASSWORD)->GetWindowText(m_Password);
	m_pEntry->m_strPassword.Set(m_Password);

	m_pEntry->m_bAsManyConnectionsAsThreads.Set((((CButton*)GetDlgItem(IDC_CONNECTIONS))->GetCheck() == 1));
	m_pEntry->m_lConnectionCount.Set(_ttoi(m_ConnectionCount));

	m_pEntry->m_bAuthenticatedProxy.Set(m_bIsAuthenticatedProxy == TRUE ? true:false);

	GetDlgItem(IDC_EDIT_PROXY_USERNAME)->GetWindowText(m_strProxyUserName);
	m_pEntry->m_strProxyUserName.Set(m_strProxyUserName);

	GetDlgItem(IDC_EDIT_PROXY_PSWD)->GetWindowText(m_strProxyPassword);
	m_pEntry->m_strProxyPassword.Set(m_strProxyPassword);

	try
	{
		if (!m_bAddMode)
		{
			m_pDatabaseList->Add(m_pEntry);
		}
			m_pEntry->StoreInRegistry();
	}
	catch (IM::Exception &)
	{
		Report(REP_WARN, IDS_DBPROP_117);
		return;
	}
	
	CDialog::OnOK();
}

void LinkSiteServerProp::OnHelp() 
{
	::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, 11);
}

void LinkSiteServerProp::OnBnClickedkeyFileBrowse()
{	
	TCHAR szFilters[]= _T("Pem Files (*.pem)|*.pem|All Files (*.*)|*.*||");
	
	CFileDialog aFileDialog(TRUE, _T("pem"), _T("*.pem"),
		OFN_FILEMUSTEXIST | OFN_HIDEREADONLY, szFilters);

	if (aFileDialog.DoModal() != IDOK)
		return;

	SetDlgItemText(IDC_KEYFILEPATH, aFileDialog.GetPathName());	
}
void LinkSiteServerProp::TrustedLoginChanged() 
{
	
	if (((CButton*)GetDlgItem(IDC_CHECK_TRUSTEDLOGIN))->GetCheck() == TRUE)
	{
		m_bTrustedLogin = TRUE; 
		GetDlgItem(IDC_KEYFILEPATH)->EnableWindow(true);
		GetDlgItem(IDC_PASSWORD2)->EnableWindow(true);
		GetDlgItem(IDC_KEYFILE_BROWSE)->EnableWindow(true);
	}
	else
	{
		m_bTrustedLogin = FALSE;
		SetDlgItemText(IDC_KEYFILEPATH, _T(""));
		SetDlgItemText(IDC_PASSWORD2, _T(""));

		GetDlgItem(IDC_KEYFILEPATH)->EnableWindow(false);
		GetDlgItem(IDC_PASSWORD2)->EnableWindow(false);
		GetDlgItem(IDC_KEYFILE_BROWSE)->EnableWindow(false);
	}
}

void LinkSiteServerProp::AuthProxyChanged() 
{
	if (((CButton*)GetDlgItem(IDC_CHECK_AUTHPROXY))->GetCheck() == TRUE)
	{
		m_bIsAuthenticatedProxy = TRUE; 
		GetDlgItem(IDC_EDIT_PROXY_USERNAME)->EnableWindow(true);
		GetDlgItem(IDC_EDIT_PROXY_PSWD)->EnableWindow(true);
	}
	else
	{
		m_bIsAuthenticatedProxy = FALSE;
		SetDlgItemText(IDC_EDIT_PROXY_USERNAME, _T(""));
		SetDlgItemText(IDC_EDIT_PROXY_PSWD, _T(""));

		GetDlgItem(IDC_EDIT_PROXY_USERNAME)->EnableWindow(false);
		GetDlgItem(IDC_EDIT_PROXY_PSWD)->EnableWindow(false);
	}
}
