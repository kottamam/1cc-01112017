#if !defined(AFX_EMSDATABASEPROP2_H__0485C101_FBC4_48AF_BC3A_F52A085415DE__INCLUDED_)
#define AFX_EMSDATABASEPROP2_H__0485C101_FBC4_48AF_BC3A_F52A085415DE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// EMSDatabaseProp2.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// EMSDatabaseProp2 dialog

class EMSDatabaseProp2 : public CDialog
{
// Construction
public:
	EMSDatabaseProp2(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(EMSDatabaseProp2)
	enum { IDD = IDD_EMS_DB_PROP2 };
	CString	m_DatabaseName;
	CButton	m_EnablePort;
	CString	m_Password;
	long	m_Port;
	CString	m_ServerName;
	CString	m_Username;
	//}}AFX_DATA
	IM::EMSServiceConfiguration *m_pServiceConfiguration;
	CString						m_SavedDatabaseName;
	long						m_lSavedMaxFolderList;


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(EMSDatabaseProp2)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(EMSDatabaseProp2)
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnHelp();
	afx_msg void OnChange();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EMSDATABASEPROP2_H__0485C101_FBC4_48AF_BC3A_F52A085415DE__INCLUDED_)
