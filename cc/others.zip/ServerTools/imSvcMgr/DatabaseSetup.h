#if !defined(AFX_DATABASESETUP_H__6E1FFE42_DB0E_11D2_8C50_00C04F68F9B3__INCLUDED_)
#define AFX_DATABASESETUP_H__6E1FFE42_DB0E_11D2_8C50_00C04F68F9B3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DatabaseSetup.h : header file
//
#include "registry\EMailSvcConfiguration.h"
#include "registry\LNEMailSvcConfiguration.h"
//class DatabaseList;

/////////////////////////////////////////////////////////////////////////////
// DatabaseSetup dialog

class DatabaseSetup : public CDialog
{
// Construction
public:
	DatabaseSetup(CSvcMgrDoc* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(DatabaseSetup)
	enum { IDD = IDD_DATABASE_SETUP };
	CButton		m_DeleteButton;
	CButton		m_ModifyButton;
	CButton		m_AddDBButton;
	CButton		m_AddLinkSiteDBButton;
	CButton		m_AddServerButton;
	CListBox	m_DatabaseList;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(DatabaseSetup)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	bool needPrimaryDatabase();
	bool NeedWebContentDatabase();

	// Generated message map functions
	//{{AFX_MSG(DatabaseSetup)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangeList2();
	afx_msg void OnAddDBButton();
	afx_msg void OnAddLinkSiteDBButton();
	afx_msg void OnAddServerButton();
	afx_msg void OnModifyDatabase();
	afx_msg void OnClose();
	afx_msg void OnDeleteDatabase();
	virtual void OnCancel();
	afx_msg void OnHelp();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	IM::DatabaseEntryList		*m_pDatabaseList;
	IM::EMSServiceConfiguration	*m_pServiceConfiguration;
	IM::EMailSvcConfiguration	*m_pEOLConfiguration;

	IM::LNEMailSvcConfiguration	*m_pLNConfiguration ;
	bool						m_bHavePrimary;

public:		// User declarations
	IM::NrString serverName;
	IM::NrString strDisplayName;
	long serviceType;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DATABASESETUP_H__6E1FFE42_DB0E_11D2_8C50_00C04F68F9B3__INCLUDED_)
