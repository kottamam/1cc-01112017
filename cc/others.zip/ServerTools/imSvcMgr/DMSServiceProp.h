#if !defined(AFX_DMSSERVICEPROP_H__88563377_DB15_11D2_8C50_00C04F68F9B3__INCLUDED_)
#define AFX_DMSSERVICEPROP_H__88563377_DB15_11D2_8C50_00C04F68F9B3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DMSServiceProp.h : header file
//

class DocService;

/////////////////////////////////////////////////////////////////////////////
// DMSServiceProp dialog

class DMSServiceProp : public CDialog
{
// Construction
public:
	DMSServiceProp(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(DMSServiceProp)
	enum { IDD = IDD_DMS_PROPERTIES };
	CSpinButtonCtrl	m_SpinCacheRows;
	CSpinButtonCtrl	m_SpinCacheFreq;
	CString	m_CacheFreq;
	CString	m_CacheRows;
	CString	m_ClusterName;
	CString	m_FilePort;
	BOOL	m_GivenFilePort;
	BOOL	m_GivenServPort;
	BOOL	m_PreloadCache;
	CString	m_ServicePort;
	CString	m_SharedCMDB;
	BOOL	m_Shared12Cache;
	BOOL	m_bImpersonation;
	CString	m_strPassword;
	BOOL	m_TrustedLogon;
	CString	m_strFileServerPath;
	CString	m_strEmailDomain;
	CString m_strWFMServerAddress;
	BOOL	m_bWFMenabled;
	BOOL	m_bSEVenabled;
	BOOL	m_bEASenabled;
	CString m_strEASServerAddress;
	CString m_strEASUserName;
	CString m_strEASPassword;	
	BOOL	m_bHostedEnabled;
	CString	m_strIpv6MulticastAddress;
	CString	m_strHPCAServerAddress;
	//}}AFX_DATA
	IM::DmsServiceConfiguration	*m_pService;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(DMSServiceProp)
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(DMSServiceProp)
	virtual void OnOK();
	afx_msg void OnChangeThreads();
	afx_msg void OnChangeClusterName();
	afx_msg void OnTrustedLogon();
	afx_msg void OnChangeCacheFreq();
	afx_msg void OnChangeCacheRows();
	afx_msg void OnPreloadCacheData();
	afx_msg void OnShared12Cache();
	afx_msg void OnImpersonation();
	afx_msg void OnChangeSharedCmdb();
	afx_msg void OnGivenServPort();
	afx_msg void OnChangeServicePort();
	afx_msg void OnGivenFilePort();
	afx_msg void OnChangeFilePort();
	afx_msg void OnHelp();
	afx_msg void OnChangeImpersonationPassword();
	afx_msg void OnCacheFileserverBtn();
	afx_msg void OnChangeCacheFileserver();
	afx_msg void OnChangeEmaildomain();
	afx_msg void OnWFMenabled();
	afx_msg void OnWFMServerAddress();
	afx_msg void OnSEVenabled();
	afx_msg void OnServerAddress();
	afx_msg void OnEASenabled();
	afx_msg void OnEASServerAddress();
	afx_msg void OnEASUserName();
	afx_msg void OnEASPassword();
	afx_msg void OnSystemDates();
	afx_msg void OnFileDates();
	afx_msg void OnHostedDMenabled();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	void Changed();
public:
	afx_msg void OnBnClickedVaultEnabled2();
	afx_msg void OnBnClickedWfmEnabled();

public:
	afx_msg void OnBnClickedHostedConfigure();
	afx_msg void OnBnClickedVaultConfigure();
	CString m_strSecureFileServerPath;
	afx_msg void OnSecureCacheFileserverBtn();
	afx_msg void OnChangeSecureCacheFileServer();
	afx_msg void OnChangeIpv6multicastaddress();
	afx_msg void OnBnClickedHpcaEnabled();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DMSSERVICEPROP_H__88563377_DB15_11D2_8C50_00C04F68F9B3__INCLUDED_)

