// WkAtIndxrProperties.cpp : implementation file
//

#include "stdafx.h"
#include "imsvcmgr.h"
#include "WkAtIndxrProperties.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// WkAtIndxrProperties dialog

WkAtIndxrProperties::WkAtIndxrProperties(CWnd* pParent /*=NULL*/)
	: CDialog(WkAtIndxrProperties::IDD, pParent),
	m_strDreHost(_T("")),
	m_strIndexPort(_T("")),
	m_strQueryPort(_T(""))
{
}

BOOL WkAtIndxrProperties::OnInitDialog() 
{
	GetDlgItem(IDOK)->EnableWindow(0);
	SetDefID(IDCANCEL);

	m_pService->LoadFromRegistry();

	m_strDreHost = m_pService->m_strDreHost.Get().c_str();

	char szInt[11];
	ltoa(m_pService->m_lDreIndexPort.Get(), szInt, 10);
	m_strIndexPort = szInt;

	ltoa(m_pService->m_lDreQueryPort.Get(), szInt, 10);
	m_strQueryPort = szInt;

	CDialog::OnInitDialog();

	return TRUE;
}

BEGIN_MESSAGE_MAP(WkAtIndxrProperties, CDialog)
	//{{AFX_MSG_MAP(WkDreProperties)
	ON_EN_CHANGE(IDC_WKATINDXR_EDIT_DRE, OnChange)
	ON_EN_CHANGE(IDC_WKATINDXR_EDIT_INDEXPORT, OnChange)
	ON_EN_CHANGE(IDC_WKATINDXR_EDIT_QUERYPORT, OnChange)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

void WkAtIndxrProperties::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(WkAtIndxrProperties)
	DDX_Text(pDX, IDC_WKATINDXR_EDIT_DRE, m_strDreHost);
	DDX_Text(pDX, IDC_WKATINDXR_EDIT_INDEXPORT, m_strIndexPort);
	DDX_Text(pDX, IDC_WKATINDXR_EDIT_QUERYPORT, m_strQueryPort);
	//}}AFX_DATA_MAP
}

void WkAtIndxrProperties::OnOK()
{
	UpdateData();

	// store values in registry
	m_pService->m_strDreHost.Set(m_strDreHost);
	m_pService->m_lDreIndexPort.Set(_ttol(m_strIndexPort));
	m_pService->m_lDreQueryPort.Set(_ttol(m_strQueryPort));

	try
	{
		m_pService->StoreInRegistry();
	}
	catch (IM::Exception &)
	{
	}

	CDialog::OnOK();
}

void WkAtIndxrProperties::OnChange() 
{
	GetDlgItem(IDOK)->EnableWindow();
	SetDefID(IDOK);
}

void WkAtIndxrProperties::OnHelp() 
{
	::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, 17);
}

/////////////////////////////////////////////////////////////////////////////
// WkAtIndxrProperties message handlers
