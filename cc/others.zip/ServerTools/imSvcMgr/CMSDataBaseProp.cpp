// CMSDataBaseProp.cpp : implementation file
//

#include "stdafx.h"
#include "imsvcmgr.h"
#include "CMSDataBaseProp.h"
#include "JDBCSource.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCMSDataBaseProp dialog


CCMSDataBaseProp::CCMSDataBaseProp(CWnd* pParent /*=NULL*/)
	: CDialog(CCMSDataBaseProp::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCMSDataBaseProp)
	m_strCMSDBName = _T("");
	m_strCMSDBPassword = _T("");
	m_nCMSConnCount = 1;
	m_strCMSDBLoginID = _T("");
	//}}AFX_DATA_INIT
}


void CCMSDataBaseProp::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCMSDataBaseProp)
	DDX_Text(pDX, IDC_CMS_ODBC_NAME, m_strCMSDBName);
	DDX_Text(pDX, IDC_CMS_PASSWORD, m_strCMSDBPassword);
	DDX_Text(pDX, IDC_CMS_CONNECT_COUNT_EDIT, m_nCMSConnCount);
	DDX_Text(pDX, IDC_CMS_LOGONID, m_strCMSDBLoginID);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCMSDataBaseProp, CDialog)
	//{{AFX_MSG_MAP(CCMSDataBaseProp)
	ON_BN_CLICKED(IDC_CMS_ODBC_BROWSE, OnCmsOdbcBrowse)
	ON_EN_CHANGE(IDC_CMS_ODBC_NAME, OnChange)
	ON_EN_CHANGE(IDC_CMS_LOGONID, OnChange)
	ON_EN_CHANGE(IDC_CMS_PASSWORD, OnChange)
	ON_EN_CHANGE(IDC_CMS_CONNECT_COUNT_EDIT, OnChange)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCMSDataBaseProp message handlers

BOOL CCMSDataBaseProp::OnInitDialog() 
{
	CDialog::OnInitDialog();
	IM::CmsDatabaseEntry *pEntry;     
 
	// if MODIFY
	UpdateData(true);
	if (!m_strPassedDBName.IsEmpty())
    {
	    m_bAddMode = false;
		m_strCMSDBName  = m_strPassedDBName;
    	GetDlgItem(IDC_CMS_ODBC_NAME)->EnableWindow(false);
        GetDlgItem(IDC_CMS_ODBC_BROWSE)->EnableWindow(false);

		// Get repository information for this database and display
		pEntry = (IM::CmsDatabaseEntry *) m_pDatabaseList->Get((LPCTSTR)m_strCMSDBName);

		if (pEntry == NULL)
	    {
	    	Report(REP_WARN, IDS_DBPROP_115);
	        SendMessage(WM_CLOSE);
	        return TRUE;
	    }
		m_strCMSDBLoginID = pEntry->m_strLogonID.Get().c_str();
		m_strCMSDBPassword = pEntry->m_strPassword.Get().c_str();
		m_nCMSConnCount = pEntry->m_lConnectionCount.Get();
	}
    else	// else ADD
    {
	    m_bAddMode = true;
        GetDlgItem(IDC_CMS_ODBC_NAME)->EnableWindow();
        GetDlgItem(IDC_CMS_ODBC_BROWSE)->EnableWindow();
        GetDlgItem(IDC_CMS_ODBC_NAME)->SetWindowText(_T(""));
		m_strCMSDBLoginID = _T("");
        m_strCMSDBPassword = _T("");
		m_nCMSConnCount = 1;
	}
	UpdateData(false);
	// Allow OK button only after a change
	GetDlgItem(IDOK)->EnableWindow(false);
	SetDefID(IDCANCEL);	

	((CSpinButtonCtrl*)GetDlgItem(IDC_CMS_SPIN_CONN_COUNT))->SetBuddy((CEdit*)GetDlgItem(IDC_CMS_CONNECT_COUNT_EDIT));
	((CSpinButtonCtrl*)GetDlgItem(IDC_CMS_SPIN_CONN_COUNT))->SetRange(1,100);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CCMSDataBaseProp::OnCmsOdbcBrowse() 
{
	CJDBCSource pdlg;
	pdlg.pDSNList = this->pDSNList;
	if (pdlg.DoModal() == IDOK)
	{
		((CEdit*)GetDlgItem(IDC_CMS_ODBC_NAME))->SetWindowText(pdlg.strDSNName);
		((CEdit*)GetDlgItem(IDC_CMS_LOGONID))->SetWindowText(pdlg.strUserName);
		((CEdit*)GetDlgItem(IDC_CMS_PASSWORD))->SetWindowText(pdlg.strPassword);
		GetDlgItem(IDOK)->EnableWindow(true);
		SetDefID(IDOK);
	}	
}


void CCMSDataBaseProp::OnOK() 
{
	UpdateData(true);
	IM::CmsDatabaseEntry *pEntry = (IM::CmsDatabaseEntry *) m_pDatabaseList->NewEntry(m_strCMSDBName);
	pEntry->m_strLogonID.Set(m_strCMSDBLoginID);
	pEntry->m_strPassword.Set(m_strCMSDBPassword);
	pEntry->m_lConnectionCount.Set(m_nCMSConnCount);
	try
	{
		m_pDatabaseList->Add(pEntry);
	}
	catch (IM::Exception &)
	{
		Report(REP_WARN, IDS_DBPROP_117);
		delete pEntry;
		return;
	}	
	CDialog::OnOK();
}

void CCMSDataBaseProp::OnChange() 
{
	UpdateData(true);
	if (!m_strCMSDBName.IsEmpty())
    {
		GetDlgItem(IDOK)->EnableWindow(true);
		SetDefID(IDOK);	
	}	
}

