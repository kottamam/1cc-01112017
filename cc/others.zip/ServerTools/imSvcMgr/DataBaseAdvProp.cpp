// DataBaseAdvProp.cpp : implementation file
//
// Madhava - 
// This class can used for Prevent flat space filing and Undeclare the document grace period.

#include "stdafx.h"
#include "imsvcmgr.h"
#include "DataBaseAdvProp.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

bool IsNumeric (const CString & str);

/////////////////////////////////////////////////////////////////////////////
// DataBaseAdvProp dialog


DataBaseAdvProp::DataBaseAdvProp(IM::DmsDatabaseEntry	*pEntry, CWnd* pParent /*=NULL*/)
	: CDialog(DataBaseAdvProp::IDD, pParent),
	m_pEntry (pEntry),
	m_prv_flat_space_cbox_ptr (NULL)
{
	//{{AFX_DATA_INIT(DataBaseAdvProp)
	//}}AFX_DATA_INIT
}


void DataBaseAdvProp::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(DataBaseAdvProp)
	//}}AFX_DATA_MAP
	DDX_Control(pDX, IDC_SPIN_GRACE_PERIOD, m_ctrlSpinGracePeriod);
	DDX_Control(pDX, IDC_EDIT_GRACE_DAYS, m_editGracePeriod);
	//DDX_Control(pDX, IDC_EDIT_LOCALE, m_editLocale);
	DDX_Control(pDX, IDC_RADIO_NO_GRACEPERIOD, m_rdoNoGracePeriod);
	DDX_Control(pDX, IDC_RADIO_INFINITE_GRACEPERIOD, m_rdoInfiniteGracePeriod);
	DDX_Control(pDX, IDC_RADIO_SPECIFY_GRACEPERIOD, m_rdoSpeicifyGracePeriod);	
}


BEGIN_MESSAGE_MAP(DataBaseAdvProp, CDialog)
	//{{AFX_MSG_MAP(DataBaseAdvProp)
	ON_BN_CLICKED(IDHELP, OnHelp)
	ON_BN_CLICKED(IDC_RADIO_NO_GRACEPERIOD, OnNoGracePeriod)
	ON_BN_CLICKED(IDC_RADIO_INFINITE_GRACEPERIOD, OnInfiniteGracePeriod)
	ON_BN_CLICKED(IDC_RADIO_SPECIFY_GRACEPERIOD, OnSpecifyGracePeriod)	
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// DataBaseAdvProp message handlers

BOOL DataBaseAdvProp::OnInitDialog() 
{
	CDialog::OnInitDialog();	
	
	m_editGracePeriod.SetLimitText(10);	
	
	m_ctrlSpinGracePeriod.SetBuddy(((CEdit*)GetDlgItem(IDC_EDIT_GRACE_DAYS)));
	m_ctrlSpinGracePeriod.SetRange32(1,LONG_MAX);

	m_prv_flat_space_cbox_ptr =  (CButton *) (GetDlgItem (IDC_CHECK_PRV_FLAT_SPACE));

	m_prv_flat_space_cbox_ptr->SetFocus();

	if (m_pEntry->m_bAllowFlatSpaceDocuments.Get())
		m_prv_flat_space_cbox_ptr->SetCheck(BST_UNCHECKED);
	else
		m_prv_flat_space_cbox_ptr->SetCheck(BST_CHECKED);
	
	//Grace period to undeclared record.
	m_editGracePeriod.EnableWindow(FALSE);
	m_ctrlSpinGracePeriod.EnableWindow(FALSE);
	long lGraceDays = m_pEntry->m_lUndeclareRecord.Get();	
	lGraceDays = (lGraceDays==0xffffffff)?-1:lGraceDays;

	if(lGraceDays == -1)
	{
		m_rdoInfiniteGracePeriod.SetCheck(1); 
	}
	else if(lGraceDays == 0)
	{
		m_rdoNoGracePeriod.SetCheck(1); 
	}
	else if((lGraceDays >= 1)&&(lGraceDays <= LONG_MAX))
	{
		CString strGraceDays;
		m_rdoSpeicifyGracePeriod.SetCheck(1);
		m_editGracePeriod.EnableWindow(TRUE);
		m_ctrlSpinGracePeriod.EnableWindow(TRUE);
		
		strGraceDays.Format (_T("%ld"), lGraceDays);
		m_editGracePeriod.SetWindowText(strGraceDays);	
	}
	else
	{
		m_rdoNoGracePeriod.SetCheck(1); 
	}
	
	
	//Locale.	
	long llocale = m_pEntry->m_lLocale.Get();
	CString strLocale;
	strLocale.Format (_T("%ld"), llocale);
	//m_editLocale.SetWindowText(strLocale);	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void DataBaseAdvProp::OnOK() 
{
	CString strGraceDays;
	CString strLocale;

	if (m_prv_flat_space_cbox_ptr->GetCheck() == BST_CHECKED)
		m_pEntry->m_bAllowFlatSpaceDocuments.Set (false);
	else
		m_pEntry->m_bAllowFlatSpaceDocuments.Set (true);
	
	//Grace period to undeclared record.
	if(m_rdoInfiniteGracePeriod.GetCheck() == 1)  
	{
		m_pEntry->m_lUndeclareRecord.Set((long)-1);
	}
	else if(m_rdoNoGracePeriod.GetCheck() == 1)  
	{
		m_pEntry->m_lUndeclareRecord.Set((long)0);
	}
	else if(m_rdoSpeicifyGracePeriod.GetCheck() == 1) 
	{
		m_editGracePeriod.GetWindowText(strGraceDays);
		strGraceDays.TrimLeft();
		strGraceDays.TrimRight();
		
		_int64 ldays = _ttoi64(strGraceDays);

		if( IsNumeric (strGraceDays) && ldays >= 1 && ldays <= LONG_MAX )
		{
			m_pEntry->m_lUndeclareRecord.Set((long)ldays);		
		}
		else
		{
			CString strError;
			strError.Format(IDS_ERRORGRACE);
			AfxMessageBox(strError);		
			m_editGracePeriod.SetFocus();
			m_editGracePeriod.SetSel(0, -1);
			return;
		}
	}
	

	//Locale
	/*m_editLocale.GetWindowText(strLocale);
	strLocale.TrimLeft();
	strLocale.TrimRight();

	if (strLocale.IsEmpty())
	{
		strLocale = "1033";
	}

	if (IsNumeric (strLocale))
	{
		m_pEntry->m_lLocale.Set(_ttol(strLocale));
	}
	else
	{
		AfxMessageBox(_T("Please enter a valid locale ID."));
		m_editLocale.SetFocus();
		m_editLocale.SetSel(0, -1);
		return;
	}*/

	CDialog::OnOK();
}

void DataBaseAdvProp::OnHelp() 
{
	::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, 59);
}

DataBaseAdvProp::~DataBaseAdvProp()
{
	
}

bool IsNumeric (const CString & str)
{
	if (str.IsEmpty ())
	{
		return true;
	}

	for (int count = 0; count < str.GetLength(); count++)
	{
		if (!isdigit(str.GetAt(count)))
		{
			return (false);
		}
	}

	return true;
}

void DataBaseAdvProp::OnNoGracePeriod() 
{
	m_editGracePeriod.EnableWindow(FALSE);
	m_ctrlSpinGracePeriod.EnableWindow(FALSE);
	GetDlgItem(IDOK)->EnableWindow(true);
	SetDefID(IDOK);
}

void DataBaseAdvProp::OnInfiniteGracePeriod() 
{
	m_editGracePeriod.EnableWindow(FALSE);
	m_ctrlSpinGracePeriod.EnableWindow(FALSE);
	GetDlgItem(IDOK)->EnableWindow(true);
	SetDefID(IDOK);
}

void DataBaseAdvProp::OnSpecifyGracePeriod() 
{
	m_editGracePeriod.EnableWindow(TRUE);
	m_ctrlSpinGracePeriod.EnableWindow(TRUE);
	GetDlgItem(IDOK)->EnableWindow(true);
	SetDefID(IDOK);
}


