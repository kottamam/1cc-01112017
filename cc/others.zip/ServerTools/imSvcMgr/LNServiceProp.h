#pragma once


// CLNServiceProp dialog
#include "resource.h"
#include "registry\LNEMailSvcConfiguration.h"
#include "afxwin.h"

class CLNServiceProp : public CDialog
{
	DECLARE_DYNAMIC(CLNServiceProp)

	IM::LNEMailSvcConfiguration *m_pService;
	CString						m_SavedDomain;

public:
	CLNServiceProp(CWnd* pParent = NULL);   // standard constructor
	virtual ~CLNServiceProp();

// Dialog Data
	enum { IDD = IDD_LNSERVICE_PROP };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

protected:
	// Generated message map functions
	//{{AFX_MSG(EmsServiceProp)
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnHelp();
	afx_msg void OnBnClickedEmsDropdirbtn();
	afx_msg void OnBnClickedEmsBadmailbtn();
	afx_msg void OnBnClickedEmsTargetpathBtn();
	virtual BOOL OnInitDialog();

	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

public:
	CString m_sClass;
	CString m_sSubClass;
	CString m_sDocType;
	//CString m_sClusterName;
	//UINT m_nFMAPort;
	CButton m_SendFileAgent;
	CString m_Domain;
	CString m_Directory;
	CString m_strBadMailDir;
	CString m_strTargetPath;
	CString m_strServerName;
	UINT m_nPortNo;
	CString m_strUserName;
	CString m_strPasswd;
	CString m_strFromAddress;
	CString m_strToAddress;
	CString m_strMessageBody;
	UINT m_lBounceTime;

private:
	void EnableSendAndFileCtrls(BOOL bEnable /*= TRUE*/);
	void GetDirectory(CString &csPath);
public:
	afx_msg void OnBnClickedCheckSendfileAgent();
};
