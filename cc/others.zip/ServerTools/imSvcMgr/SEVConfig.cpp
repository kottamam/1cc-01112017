#include "StdAfx.h"
#include "imSvcMgr.h"
#include "SEVConfig.h"

BOOL isDlgClosed_SEVConfig = FALSE;
IMPLEMENT_DYNAMIC(SEVConfig, CDialog)

SEVConfig::SEVConfig(IM::DmsServiceConfiguration* pService, CWnd* pParent)
:CDialog(SEVConfig::IDD, pParent), m_pService(pService)
{

}

SEVConfig::~SEVConfig()
{

}

void SEVConfig::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(SEVConfig, CDialog)
	ON_BN_CLICKED(IDOK, &SEVConfig::OnBnClickedOk)
	ON_BN_CLICKED(IDCANCEL, &SEVConfig::OnBnClickedCancel)
	ON_BN_CLICKED(IDC_CHECK_NOTES, OnNotesEnabled)
	ON_BN_CLICKED(IDC_SEV_NOTES_ID_BROWSE, &SEVConfig::OnBnClickedNotesIDPathBrowse)
	ON_BN_CLICKED(IDC_SEV_NOTES_TEMPLATE_BROWSE, &SEVConfig::OnBnClickedNotesTemplatePathBrowse)
	ON_BN_CLICKED(IDC_SEV_NOTES_TEMP_DB_BROWSE, &SEVConfig::OnBnClickedNotesTempDBPathBrowse)
END_MESSAGE_MAP()

BOOL SEVConfig::OnInitDialog() 
{
	CDialog::OnInitDialog();
	if (m_pService == NULL)
		return 0;

	SetDlgItemText(IDC_SEV_SERVERADDRESS, m_pService->m_strSevServerAddress.Get().c_str());
	SetDlgItemText(IDC_SEV_NOTES_ID_PATH, m_pService->m_strSevNotesIdPath.Get().c_str());
	SetDlgItemText(IDC_SEV_NOTES_ID_PASSWORD, m_pService->m_strSevNotesIdPassword.Get().c_str());
	SetDlgItemText(IDC_SEV_NOTES_TEMPLATE_PATH, m_pService->m_strSevNotesTemplatePath.Get().c_str());
	SetDlgItemText(IDC_SEV_NOTES_TEMP_DB_PATH, m_pService->m_strSevNotesTempDBPath.Get().c_str());

	if (m_pService->m_bSevNotesEnabled.Get() == false)
	{
		((CButton*)GetDlgItem(IDC_CHECK_NOTES))->SetCheck(0);
		GetDlgItem(IDC_SEV_NOTES_ID_PATH)->EnableWindow(FALSE);
		GetDlgItem(IDC_SEV_NOTES_ID_BROWSE)->EnableWindow(FALSE);
		GetDlgItem(IDC_SEV_NOTES_ID_PASSWORD)->EnableWindow(FALSE);
		GetDlgItem(IDC_SEV_NOTES_TEMPLATE_PATH)->EnableWindow(FALSE);
		GetDlgItem(IDC_SEV_NOTES_TEMPLATE_BROWSE)->EnableWindow(FALSE);
		GetDlgItem(IDC_SEV_NOTES_TEMP_DB_PATH)->EnableWindow(FALSE);
		GetDlgItem(IDC_SEV_NOTES_TEMP_DB_BROWSE)->EnableWindow(FALSE);
	}
	else
	{
		((CButton*)GetDlgItem(IDC_CHECK_NOTES))->SetCheck(1);
	}
	
	return 0;
}

void SEVConfig::OnBnClickedNotesIDPathBrowse()
{	
	TCHAR szFilters[]= _T("ID Files (*.id)|*.id|All Files (*.*)|*.*||");
	
	CFileDialog aFileDialog(TRUE, _T("id"), _T("*.id"),
		OFN_FILEMUSTEXIST | OFN_HIDEREADONLY, szFilters);

	if (aFileDialog.DoModal() != IDOK)
		return;

	SetDlgItemText(IDC_SEV_NOTES_ID_PATH, aFileDialog.GetPathName());	
}

void SEVConfig::OnBnClickedNotesTemplatePathBrowse()
{	
	TCHAR szFilters[]= _T("NTF Files (*.ntf)|*.ntf|All Files (*.*)|*.*||");
	
	CFileDialog aFileDialog(TRUE, _T("ntf"), _T("*.ntf"),
		OFN_FILEMUSTEXIST | OFN_HIDEREADONLY, szFilters);

	if (aFileDialog.DoModal() != IDOK)
		return;

	SetDlgItemText(IDC_SEV_NOTES_TEMPLATE_PATH, aFileDialog.GetPathName());	
}

void SEVConfig::OnBnClickedNotesTempDBPathBrowse()
{	
	TCHAR szFilters[]= _T("NSF Files (*.nsf)|*.nsf|All Files (*.*)|*.*||");
	
	CFileDialog aFileDialog(TRUE, _T("nsf"), _T("*.nsf"), OFN_HIDEREADONLY, szFilters);

	if (aFileDialog.DoModal() != IDOK)
		return;

	SetDlgItemText(IDC_SEV_NOTES_TEMP_DB_PATH, aFileDialog.GetPathName());	
}

void SEVConfig::OnBnClickedOk()
{
	CString aString = _T("");
	GetDlgItemText(IDC_SEV_SERVERADDRESS, aString);
	m_pService->m_strSevServerAddress.Set((LPCTSTR)aString);

	if (((CButton*)GetDlgItem(IDC_CHECK_NOTES))->GetCheck() == 1)
	{
		m_pService->m_bSevNotesEnabled.Set(true);

		aString = _T("");
		GetDlgItemText(IDC_SEV_NOTES_ID_PATH, aString);
		m_pService->m_strSevNotesIdPath.Set((LPCTSTR)aString);

		aString = _T("");
		GetDlgItemText(IDC_SEV_NOTES_ID_PASSWORD, aString);
		m_pService->m_strSevNotesIdPassword.Set((LPCTSTR)aString);

		aString = _T("");
		GetDlgItemText(IDC_SEV_NOTES_TEMPLATE_PATH, aString);
		m_pService->m_strSevNotesTemplatePath.Set((LPCTSTR)aString);

		aString = _T("");
		GetDlgItemText(IDC_SEV_NOTES_TEMP_DB_PATH, aString);
		m_pService->m_strSevNotesTempDBPath.Set((LPCTSTR)aString);
	}
	else
	{
		m_pService->m_bSevNotesEnabled.Set(false);
	}
	
	OnOK();
}

void SEVConfig::OnBnClickedCancel()
{
	OnCancel();
}


void SEVConfig::OnChange()
{

}

void SEVConfig::OnNotesEnabled()
{
	if (((CButton*)GetDlgItem(IDC_CHECK_NOTES))->GetCheck() == 1)
	{
		GetDlgItem(IDC_SEV_NOTES_ID_PATH)->EnableWindow(TRUE);
		GetDlgItem(IDC_SEV_NOTES_ID_BROWSE)->EnableWindow(TRUE);
		GetDlgItem(IDC_SEV_NOTES_ID_PASSWORD)->EnableWindow(TRUE);
		GetDlgItem(IDC_SEV_NOTES_TEMPLATE_PATH)->EnableWindow(TRUE);
		GetDlgItem(IDC_SEV_NOTES_TEMPLATE_BROWSE)->EnableWindow(TRUE);
		GetDlgItem(IDC_SEV_NOTES_TEMP_DB_PATH)->EnableWindow(TRUE);
		GetDlgItem(IDC_SEV_NOTES_TEMP_DB_BROWSE)->EnableWindow(TRUE);
	}
	else
	{
		GetDlgItem(IDC_SEV_NOTES_ID_PATH)->EnableWindow(FALSE);
		GetDlgItem(IDC_SEV_NOTES_ID_BROWSE)->EnableWindow(FALSE);
		GetDlgItem(IDC_SEV_NOTES_ID_PASSWORD)->EnableWindow(FALSE);
		GetDlgItem(IDC_SEV_NOTES_TEMPLATE_PATH)->EnableWindow(FALSE);
		GetDlgItem(IDC_SEV_NOTES_TEMPLATE_BROWSE)->EnableWindow(FALSE);
		GetDlgItem(IDC_SEV_NOTES_TEMP_DB_PATH)->EnableWindow(FALSE);
		GetDlgItem(IDC_SEV_NOTES_TEMP_DB_BROWSE)->EnableWindow(FALSE);
	}
}