// VerityProp.cpp : implementation file
//

#include "stdafx.h"
#include "imsvcmgr.h"
#include "VerityProp.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// VerityProp dialog


VerityProp::VerityProp(IM::DmsDatabaseEntry	*pEntry_, CWnd* pParent /*=NULL*/)
	: CDialog(VerityProp::IDD, pParent)
{
	//{{AFX_DATA_INIT(VerityProp)
	m_pEntry = pEntry_;

	m_strServer = _T("");

	m_bSpecifyServicePort = false;
	m_strServicePort = _T("");
	//}}AFX_DATA_INIT
}


void VerityProp::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(VerityProp)
	DDX_Text(pDX, IDC_SERVER, m_strServer);
	DDX_Check(pDX, IDC_SPECIFY_SERVICE_PORT, m_bSpecifyServicePort);
	DDX_Text(pDX, IDC_SERVICE_PORT, m_strServicePort);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(VerityProp, CDialog)
	//{{AFX_MSG_MAP(VerityProp)
	ON_EN_CHANGE(IDC_SERVER, OnChange)
	ON_BN_CLICKED(IDC_SPECIFY_SERVICE_PORT, OnChange)
	ON_EN_CHANGE(IDC_SERVICE_PORT, OnChange)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// VerityProp message handlers

BOOL VerityProp::OnInitDialog()
{
	CDialog::OnInitDialog();

	//
	// Get Velocity configuration information for this database and display
	//
	if (m_pEntry == NULL)
	{
	    Report(REP_WARN, IDS_DBPROP_115);
	    SendMessage(WM_CLOSE);
	    return TRUE;
	}

	m_strServer = m_pEntry->m_strIndexServer.Get().c_str();
	m_bSpecifyServicePort = m_pEntry->m_bIndexServerGivenPort.Get();
	CString aString;
	m_strServicePort = _itot(m_pEntry->m_lIndexServerPort.Get(), (_TCHAR*)(LPCSTR)aString.GetBuffer(10), 10);

	GetDlgItem(IDC_SERVER)->SetWindowText(m_strServer);
	((CButton*) GetDlgItem(IDC_SPECIFY_SERVICE_PORT))->SetCheck(m_bSpecifyServicePort);
	GetDlgItem(IDC_SERVICE_PORT)->EnableWindow(m_bSpecifyServicePort);

	if (m_bSpecifyServicePort)
	{
		GetDlgItem(IDC_SERVICE_PORT)->SetWindowText(m_strServicePort);
	}
	else
	{
		GetDlgItem(IDC_SERVICE_PORT)->SetWindowText(_T(""));
	}

	GetDlgItem(IDOK)->EnableWindow(false);
	SetDefID(IDCANCEL);

	return(TRUE);
}

void VerityProp::OnOK()
{
	GetDlgItem(IDC_SERVER)->GetWindowText(m_strServer);
	m_bSpecifyServicePort = ((CButton*)GetDlgItem(IDC_SPECIFY_SERVICE_PORT))->GetCheck();
	GetDlgItem(IDC_SERVICE_PORT)->GetWindowText(m_strServicePort);
	long lIndexPort = _ttoi(m_strServicePort);

	m_pEntry->m_strIndexServer.Set(m_strServer);
	m_pEntry->m_bIndexServerGivenPort.Set(m_bSpecifyServicePort ? true : false);
	m_pEntry->m_lIndexServerPort.Set(lIndexPort);

	CDialog::OnOK();
}

void VerityProp::OnChange()
{
	bool bEnableOK = true;

	CString strServer;
	GetDlgItem(IDC_SERVER)->GetWindowText(strServer);
	strServer.TrimLeft();
	strServer.TrimRight();

	if (strServer.IsEmpty())
	{
		bEnableOK = false;
	}

	//
	// If "Specify Service Port" is set and the port field is empty, disable OK button.
	//
	BOOL bSpecifyServicePort = ((CButton*)GetDlgItem(IDC_SPECIFY_SERVICE_PORT))->GetCheck();
	CString strIDXPort;
	GetDlgItem(IDC_SERVICE_PORT)->GetWindowText(strIDXPort);

	strIDXPort.TrimLeft();
	strIDXPort.TrimRight();

	if (bSpecifyServicePort)
	{
		GetDlgItem(IDC_SERVICE_PORT)->EnableWindow(true);
	}
	else
	{
		GetDlgItem(IDC_SERVICE_PORT)->EnableWindow(false);
	}

	if (bSpecifyServicePort && strIDXPort.IsEmpty())
	{
		bEnableOK = false;
	}


	if(bEnableOK)
	{
		GetDlgItem(IDOK)->EnableWindow(true);
		SetDefID(IDOK);
	}
	else
	{
		GetDlgItem(IDOK)->EnableWindow(false);
		SetDefID(IDCANCEL);
	}
}
