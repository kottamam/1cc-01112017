#pragma once

#include "stdafx.h"
#include "imsvcmgr.h"

namespace DSLocal
{

class CDSSyncSvc_AttributeMap
{
public:
	// default constructor
	CDSSyncSvc_AttributeMap( void );

	// copy constructor
	CDSSyncSvc_AttributeMap( const CDSSyncSvc_AttributeMap& DSSyncSvc_AttributeMap );

	// destructor
	virtual ~CDSSyncSvc_AttributeMap( void );

	// equality operator
	bool operator ==( const CDSSyncSvc_AttributeMap& DSSyncSvc_AttributeMap ) const;

	// assignment operator
	CDSSyncSvc_AttributeMap& operator =( const CDSSyncSvc_AttributeMap& DSSyncSvc_AttributeMap );

	// data members
	CString m_strMapName;
	CString m_strOUName;
	CString m_strUserName;
	CString m_strUserId;
	CString m_strUserEmail;
	CString m_strUserFax;
	CString m_strUserTelephone;
	CString m_strUserLocation;
	CString m_strGroupName;
	CString m_strGroupId;
	CString m_strGroupMember;
	CString m_strK1SyncId;
};




class CDSSyncSvc_DSParameters
{
public:
	// default constructor
	CDSSyncSvc_DSParameters( void );

	// copy constructor
	CDSSyncSvc_DSParameters( const CDSSyncSvc_DSParameters& DSSyncSvc_DSParameters );

	// destructor
	virtual ~CDSSyncSvc_DSParameters( void );

	// equality operator
	bool operator ==( const CDSSyncSvc_DSParameters& DSSyncSvc_DSParameters ) const;

	// assignment operator
	CDSSyncSvc_DSParameters& operator =( const CDSSyncSvc_DSParameters& DSSyncSvc_DSParameters );

	// data members
	CString m_strServerName;
	CString m_strUserId;
	CString m_strPassword;
	long m_lServiceType;
	long m_lTcpipPort;
};




class CDSSyncSvc_DMSParameters
{
public:
	// default constructor
	CDSSyncSvc_DMSParameters( void );

	// copy constructor
	CDSSyncSvc_DMSParameters( const CDSSyncSvc_DMSParameters& DSSyncSvc_DMSParameters );

	// destructor
	virtual ~CDSSyncSvc_DMSParameters( void );

	// equality operator
	bool operator ==( const CDSSyncSvc_DMSParameters& DSSyncSvc_DMSParameters ) const;

	// assignment operator
	CDSSyncSvc_DMSParameters& operator =( const CDSSyncSvc_DMSParameters& DSSyncSvc_DMSParameters );

	// data members
	CString m_strDms;
	CString m_strLibrary;
	CString m_strUserId;
	CString m_strPassword;
};




class CDSSyncSvc_Connection
{
public:
	// default constructor
	CDSSyncSvc_Connection( void );

	// copy constructor
	CDSSyncSvc_Connection( const CDSSyncSvc_Connection& DSSyncSvc_Connection );

	// destructor
	virtual ~CDSSyncSvc_Connection( void );

	// equality operator
	bool operator ==( const CDSSyncSvc_Connection& DSSyncSvc_Connection ) const;

	// assignment operator
	CDSSyncSvc_Connection& operator =( const CDSSyncSvc_Connection& DSSyncSvc_Connection );

	// data members
	CString m_strName;
	CString m_strNode;
	CString m_strAttributeMapName;

	// subkeys
	CDSSyncSvc_DSParameters m_DSParameters;
	CDSSyncSvc_DMSParameters m_DMSParameters;
};







class CDSSyncSvc
{
public:
	// typedefs
	typedef imstd::list< CDSSyncSvc_AttributeMap* > ATTRIBUTEMAPLIST;
	typedef imstd::list< CDSSyncSvc_Connection* > CONNECTIONLIST;

	// default constructor
	CDSSyncSvc( void );

	// copy constructor
	CDSSyncSvc( const CDSSyncSvc& DSSyncSvc );

	// destructor
	virtual ~CDSSyncSvc( void );

	// equality operator
	bool operator ==( const CDSSyncSvc& DSSyncSvc ) const;

	// assignment operator
	CDSSyncSvc& operator =( const CDSSyncSvc& DSSyncSvc );

	// list operations
	void Clear( void );
	void RemoveAllAttributeMaps( void );
	void RemoveAllConnections( void );
	void AddAttributeMap(
		LPCTSTR szMapName, LPCTSTR szOUName, LPCTSTR szUserName, LPCTSTR szUserId, 
		LPCTSTR szUserEmail, LPCTSTR szUserFax, LPCTSTR szUserTelephone, LPCTSTR szUserLocation,
		LPCTSTR szGroupName, LPCTSTR szGroupId, LPCTSTR szGroupMember,
		LPCTSTR szK1SyncId
		);
	void AddConnection( 
		LPCTSTR szConnectionName, LPCTSTR szNode, LPCTSTR szAttributeMapName,
		LPCTSTR szDmsServer, LPCTSTR szDmsLibrary, LPCTSTR szDmsUserId, LPCTSTR szDmsPassword,
		LPCTSTR szDSServer, LPCTSTR szDSUserId, LPCTSTR szDSPassword,
		long lDSServiceType, long lDSTcpipPort
		);
	void AddAttributeMap( CDSSyncSvc_AttributeMap* pAttributeMap );
	void AddConnection( CDSSyncSvc_Connection* pConnection );
	void RemoveConnection( LPCTSTR szConnectionName );
	void RemoveAttributeMap( LPCTSTR szMapName );
	bool ConnectionExists( LPCTSTR szConnectionName ) const;
	bool AttributeMapExists( LPCTSTR szMapName ) const;
	CDSSyncSvc_Connection* FindConnection( LPCTSTR szConnectionName );
	CDSSyncSvc_AttributeMap* FindAttributeMap( LPCTSTR szMapName );

	// subkeys
	ATTRIBUTEMAPLIST m_AttributeMapList;
	CONNECTIONLIST m_ConnectionList;
};

} // namespace DSLocal
