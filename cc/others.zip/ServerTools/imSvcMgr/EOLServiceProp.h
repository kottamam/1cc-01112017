#if !defined(AFX_EOLSERVICEPROP_H__7BFA18D3_BE1E_4445_9682_C8364CA6C3D7__INCLUDED_)
#define AFX_EOLSERVICEPROP_H__7BFA18D3_BE1E_4445_9682_C8364CA6C3D7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // 

#include "resource.h"
#include "registry\EMailSvcConfiguration.h"
class CEOLServiceProp :	public CDialog
{
public:	
	CEOLServiceProp(CWnd* pParent = NULL);   // standard constructor
	
	// Dialog Data
	//{{AFX_DATA(EmsServiceProp)
	enum { IDD = IDD_EOLSERVICEPROP };
	CString m_sClass;
	CString m_sSubClass;
	CString m_sDocType;
	CString m_sExAdminSmtpAddress;
	CString m_sExAdminPassword;
	CString	m_sExSvcPort;
	CString m_sClusterName;
	UINT	m_nFMAPort;
	CButton	m_SendFileAgent;
	CButton m_EmailConfig;
	CButton m_MailboxSync;
	CString	m_Domain;
	CString	m_Directory;		// Drop Directory
	CString	m_strBadMailDir;	// Bad Mail Directory
	CString	m_strTargetPath;	// Temp Directory
	CString	m_strServerName;
	UINT	m_nPortNo;
	CString	m_strUserName;
	CString	m_strPasswd;
	CString	m_strFromAddress;
	CString	m_strToAddress;
	CString	m_strMessageBody;
	UINT	m_lBounceTime;
	//}}AFX_DATA

	IM::EMailSvcConfiguration	*m_pService;
	CString						m_SavedDomain;

	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(EmsServiceProp)
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

protected:
	// Generated message map functions
	//{{AFX_MSG(EmsServiceProp)
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnHelp();
	virtual BOOL OnInitDialog();
	afx_msg void OnChange();
	afx_msg void OnEmsDropdirButton();
	afx_msg void OnEmsBadMailButton();
	afx_msg void OnTargetpathBtn();
	afx_msg void OnChangeEmailConfig();
	virtual void OnAdvancedBtnClicked();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

public:
	void GetDirectory(CString &csPath);
	void EnableSendAndFileCtrls(BOOL bEnable = TRUE);
	void EnableEFSCtrls(BOOL bEnable = TRUE);
	
	
	afx_msg void OnBnClickedCheckMailboxSync();
};

#endif