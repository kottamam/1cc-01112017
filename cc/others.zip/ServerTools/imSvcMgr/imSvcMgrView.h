// imSvcMgrView.h : interface of the CSvcMgrView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_SVCMGRVIEW_H__2F07760B_D7EC_11D2_8C4D_00C04F68F9B3__INCLUDED_)
#define AFX_SVCMGRVIEW_H__2F07760B_D7EC_11D2_8C4D_00C04F68F9B3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "imSvcMgrDoc.h"
#include <Afxcview.h>
#include "DbViewHeaderCtrl.h"

class CSvcMgrCntrItem;
class CSvcMgrDoc;

class CSvcMgrView : public CListView 
{
protected: // create from serialization only
	CSvcMgrView();
	DECLARE_DYNCREATE(CSvcMgrView)

	ServiceConfiguration *GetSelectedService() { return(GetDocument()->GetSelectedService()); }
	void		SetSelectedService(ServiceConfiguration* pService_)	{ GetDocument()->SetSelectedService(pService_); }

	UINT_PTR m_TimerID;
	CDbViewHeaderCtrl m_headerctrl;
	int _bSortAscending;
	int _nSortedColumn;
	BOOL SortTextItems (int nCol, BOOL bAscending, int low = 0, int high = -1);
	//int _nSortedColumn;
public:
	//{{AFX_DATA(CSvcMgrView)
	enum { IDD = IDD_SVCMGR_FORM };
	//}}AFX_DATA

// Attributes
public:
	CSvcMgrDoc* GetDocument();
	// m_pSelection holds the selection to the current CSvcMgrCntrItem.
	// For many applications, such a member variable isn't adequate to
	//  represent a selection, such as a multiple selection or a selection
	//  of objects that are not CSvcMgrCntrItem objects.  This selection
	//  mechanism is provided just to help you get started.

	// TODO: replace this selection mechanism with one appropriate to your app.
	CSvcMgrCntrItem* m_pSelection;

// Operations
public:
	void RegisterServer();
	void Find_Servers();
	void StartService();
	void StopService();
	void DataBaseSetup();
	void FileServerSetup();
	void ServiceProperties();
	void StartupProperties();
	void Service_About();
	void UnregisterServer();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSvcMgrView)
public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnPrint(CDC* pDC, CPrintInfo* pInfo);
	virtual BOOL IsSelected(const CObject* pDocItem) const;// Container support
	//}}AFX_VIRTUAL

// Implementation
public:
	void OnProperties();
	virtual ~CSvcMgrView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

// Generated message map functions
protected:
	//{{AFX_MSG(CSvcMgrView)
	afx_msg void OnDestroy();
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnInsertObject();
	afx_msg void OnCancelEditCntr();
	afx_msg void OnCancelEditSvc();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnClickServerList(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnClick(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnColumnclick(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	void UpdateDisplay();
	afx_msg void OnUpdateDisplay(CCmdUI* pCmdUI);
	afx_msg void OnUpdateViewLog(CCmdUI* pCmdUI);
	afx_msg void OnUpdateStart(CCmdUI* pCmdUI);
	afx_msg void OnUpdateStop(CCmdUI* pCmdUI);
	afx_msg void OnUpdateDisplayFileServer(CCmdUI* pCmdUI);
	afx_msg void OnUpdateDisplaySvcProperties(CCmdUI* pCmdUI);
	afx_msg void OnUpdateDisplayDbSetup(CCmdUI* pCmdUI);
};

#ifndef _DEBUG  // debug version in SvcMgrView.cpp
inline CSvcMgrDoc* CSvcMgrView::GetDocument()
   { return (CSvcMgrDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SVCMGRVIEW_H__2F07760B_D7EC_11D2_8C4D_00C04F68F9B3__INCLUDED_)
