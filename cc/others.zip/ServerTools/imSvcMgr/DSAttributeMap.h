#if !defined(AFX_DSATTRIBUTEMAP_H__B3A52A67_1FE5_405C_A327_A9D8D564E0C6__INCLUDED_)
#define AFX_DSATTRIBUTEMAP_H__B3A52A67_1FE5_405C_A327_A9D8D564E0C6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DSAttributeMap.h : header file
//


namespace DSLocal
{
	class CDSSyncSvc_AttributeMap;
	class CDSSyncSvc_DSParameters;
	class CDSSyncSvc_DMSParameters;
	class CDSSyncSvc_Connection;
	class CDSSyncSvc;
}



/////////////////////////////////////////////////////////////////////////////
// DSAttributeMap dialog

class DSAttributeMap : public CDialog
{
// Construction
public:
	DSAttributeMap(CWnd* pParent = NULL);   // standard constructor
	virtual ~DSAttributeMap( void );		// destructor

	void SetRegistryObjects( IM::CDSSyncSvc* pSyncSvc, IM::CDSSyncSvc_AttributeMap* m_pAttributeMap );
	CString m_strServer;

	typedef enum tagMode
	{
		Edit = 0,
		Add = 1,
	} Mode;

	Mode m_Mode;

	CStringList m_OtherMapNames;


// Dialog Data
	//{{AFX_DATA(DSAttributeMap)
	enum { IDD = IDD_DS_ATTRIBUTEMAP };
	CEdit	m_edtNameDesc;
	CComboBox	m_cboUserTelephone;
	CComboBox	m_cboUserName;
	CComboBox	m_cboUserLocation;
	CComboBox	m_cboUserId;
	CComboBox	m_cboUserFax;
	CComboBox	m_cboUserEmail;
	CComboBox	m_cboUserEnabled;
	CComboBox	m_cboOuName;
	CComboBox	m_cboGroupName;
	CComboBox	m_cboGroupMembers;
	CComboBox	m_cboGroupId;
	CComboBox	m_cboK1SyncId;
	CButton	m_btnCancel;
	CButton	m_btnHelp;
	CButton	m_btnOk;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(DSAttributeMap)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	IM::CDSSyncSvc* m_pSyncSvc_Local;
	IM::CDSSyncSvc_AttributeMap* m_pAttributeMap_Local;

	void UpdateFromAttributeMap( void );
	void PopulateDropDowns( void );

	// Generated message map functions
	//{{AFX_MSG(DSAttributeMap)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnHelp();
	virtual void OnCancel();
	afx_msg void OnButtonADSDefaults();
	afx_msg void OnButtonSunONEDefaults();
	afx_msg void OnChangeGlobal();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DSATTRIBUTEMAP_H__B3A52A67_1FE5_405C_A327_A9D8D564E0C6__INCLUDED_)
