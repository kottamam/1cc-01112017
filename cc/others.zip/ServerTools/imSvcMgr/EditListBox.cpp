// EListBox.cpp : implementation file
//

#include "stdafx.h"
#include "EditListBox.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEListBox

CEditListBox::CEditListBox()
: m_pEdit (NULL)
{		
}

CEditListBox::~CEditListBox()
{
	if (m_pEdit)
	{
		delete m_pEdit;
		m_pEdit = NULL;
	}
}


BEGIN_MESSAGE_MAP(CEditListBox, CListBox)
	//{{AFX_MSG_MAP(CEListBox)
	ON_WM_LBUTTONDBLCLK()
	ON_WM_LBUTTONUP()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEListBox message handlers

void CEditListBox::InitEdit(CPoint point)
{
	// Gets current selection
	BOOL bOutside;
	int ret = ItemFromPoint (point, bOutside);
	int Index = LB_ERR;

	if (TRUE == bOutside)
	{
		int _is_previous_empty = 0;
		if (ret != 65535)
		{
			CString preText;
			GetText (ret, preText);
			_is_previous_empty = preText.IsEmpty();
		}
		else
		{
			ret = -1;
		}

		if (_is_previous_empty == 0)
		{
			Index = ret+1;
			InsertString (Index, _T(""));
			SetCurSel (Index);
		}		
	}
	else
	{
		Index = GetCurSel();
	}
	
	if (Index != LB_ERR)	// If there is a valid selection
	{
		// Gets item rectangle
		CRect Rect;
		GetItemRect(Index, Rect);
		// Creats an edit box around the item	

		m_pEdit = new CEdit;
		m_pEdit->Create(WS_VISIBLE | WS_CHILD | ES_LEFT | ES_AUTOHSCROLL | ES_NOHIDESEL, 
			Rect, this,WM_USER + Index);		

		m_pEdit->SetFont(GetFont());		
		
		CString Text;
		GetText(Index, Text);
		m_pEdit->SetWindowText(Text);
		m_pEdit->SetSel(0, Text.GetLength());		
		m_pEdit->SetFocus();		
	}
}

int CEditListBox::EndEdit()
{
	if (m_pEdit)		// If editing is on
	{
		// Copies edit box text to item
		CString Text;
		m_pEdit->GetWindowText(Text);
		int Index = m_pEdit->GetDlgCtrlID() - WM_USER;
		// Changing of string is effectively deleting current atring
		// And adding the modified string
		DeleteString(Index);
		InsertString(Index, Text);
		// Deletes the edit box and points pointer to NULL
		delete m_pEdit;
		m_pEdit = NULL;
		return Index;
	}
	return -1;
}

void CEditListBox::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default	
	InitEdit(point);
	//CListBox::OnLButtonDblClk(nFlags, point);	
}


BOOL CEditListBox::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class

	if(pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_RETURN)
	{
		
		int _index = EndEdit();
		if (_index != LB_ERR)
		{
			SetCurSel (_index);
		}
		return TRUE;
	}	
	
	return CListBox::PreTranslateMessage(pMsg);
}

void CEditListBox::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
		// Gets current selection
	BOOL bOutside;
	int ret = ItemFromPoint (point, bOutside);
	if (TRUE == bOutside)
	{
		int _index = EndEdit();
		if (_index != LB_ERR)
		{
			SetCurSel (_index);
		}
	}

	CListBox::OnLButtonUp(nFlags, point);
}
