// EmsServiceProp.cpp : implementation file
//

#include "stdafx.h"
#include "imsvcmgr.h"
#include "EmsServiceProp.h"

namespace MAPI
{
	#include <mapiutil.h>
	#include <imessage.h>
}

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// EmsServiceProp dialog

EmsServiceProp::EmsServiceProp(CWnd* pParent /*=NULL*/)
	: CDialog(EmsServiceProp::IDD, pParent)
{
	//{{AFX_DATA_INIT(EmsServiceProp)
	m_Class = _T("");
	m_Directory = _T("");
	m_Domain = _T("");
	m_Type = _T("");
	m_lBounceTime = 0;
	m_strFromAddress = _T("");
	m_strMessageBody = _T("");
	m_nPortNo = 0;
	m_strServerName = _T("");
	m_strToAddress = _T("");
	m_strUserName = _T("");
	m_strPasswd = _T("");
	m_strTargetPath = _T("");
	m_strSubClass = _T("");
	//}}AFX_DATA_INIT
}


void EmsServiceProp::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(EmsServiceProp)
	DDX_Control(pDX, IDC_EMS_OUTLOOKPROFILE, m_cbOutlookProfile);
	DDX_Text(pDX, IDC_EMS_CLASS, m_Class);
	DDX_Text(pDX, IDC_EMS_DIRECTORY, m_Directory);
	DDX_Text(pDX, IDC_EMS_DOMAIN, m_Domain);
	DDX_Text(pDX, IDC_EMS_TYPE, m_Type);
	DDX_Text(pDX, IDC_EMS_BOUNCETIME, m_lBounceTime);
	DDX_Text(pDX, IDC_EMS_BADMAILDIR, m_strBadMailDir);
	DDX_Text(pDX, IDC_EMS_FROMADDRESS, m_strFromAddress);
	DDX_Text(pDX, IDC_EMS_MSGBODY, m_strMessageBody);
	DDX_Text(pDX, IDC_EMS_PORTNO, m_nPortNo);
	DDX_Text(pDX, IDC_EMS_SERVERNAME, m_strServerName);
	DDX_Text(pDX, IDC_EMS_TOADDRESS, m_strToAddress);
	DDX_Text(pDX, IDC_EMS_USERNAME, m_strUserName);
	DDX_Text(pDX, IDC_EMS_PASSWORD, m_strPasswd);
	DDX_Text(pDX, IDC_EMS_TARGETPATH, m_strTargetPath);
	DDX_Text(pDX, IDC_EMS_SUBCLASS, m_strSubClass);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(EmsServiceProp, CDialog)
	//{{AFX_MSG_MAP(EmsServiceProp)
	ON_BN_CLICKED(IDHELP, OnHelp)
	ON_BN_CLICKED(IDC_EMS_DROPDIRBTN, OnEmsDropdirButton)
	ON_BN_CLICKED(IDC_EMS_BADMAILBTN, OnEmsBadMailButton)
	ON_BN_CLICKED(IDOK, OnOK)
	ON_BN_CLICKED(IDCANCEL, OnCancel)
	ON_BN_CLICKED(IDC_EMS_TARGETPATH_BTN, OnTargetpathBtn)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// EmsServiceProp message handlers

BOOL EmsServiceProp::OnInitDialog() 
{
	HRESULT        hr;

	static SizedSPropTagArray(2, sptCols) = {2, PR_PROFILE_NAME, PR_DEFAULT_PROFILE};
	MAPI::SRestriction	sres;
	MAPI::SPropValue	spvDefaultProfile;
	MAPI::LPSRowSet		pRow = NULL;
	MAPI::LPPROFADMIN	lpProfAdmin = NULL;
	CString			lpDisplayName = _T("");
	int				nDefaultProfile = 0;
	TCHAR			szProfile[] = _T("Interwoven_WCS");

	UpdateData(0);
	
	m_pService->LoadFromRegistry();

	m_Class		= m_pService->m_strClass.Get().c_str();
	m_Type		= m_pService->m_strType.Get().c_str();
	m_strSubClass = m_pService->m_strSubClass.Get().c_str();

	if (!m_pService->m_DomainNames.empty())
		m_Domain = m_pService->m_DomainNames.begin()->c_str();

	m_Directory		= m_pService->m_strDropDirectory.Get().c_str();
	m_strBadMailDir	= m_pService->m_strBadDirectory.Get().c_str();
	m_strTargetPath = m_pService->m_strTargetDirectory.Get().c_str();
	m_OutlookProfileName = m_pService->m_strOutlookProfile.Get().c_str();

	//Load Outlook Profiles here...
	CComboBox *pcbOutlookProfile;

	pcbOutlookProfile = (CComboBox *)GetDlgItem(IDC_EMS_OUTLOOKPROFILE);

	if (m_Type.CompareNoCase(_T("NOTES"))) 
	{
		// Get a IProfAdmin Interface.
		hr = CoInitialize(NULL);
		hr = MAPI::MAPIInitialize(NULL);
		hr = MAPIAdminProfiles(0, &lpProfAdmin);
		if (SUCCEEDED(hr))
		{
			hr = lpProfAdmin->CreateProfile((LPTSTR)UnicodeToAnsi(szProfile).c_str(),     // Name of new profile.
				NULL,          // Password for profile.
				NULL,          // Handle to parent window.
				NULL);        // Flags.
			if (hr != S_OK && hr != MAPI_E_NO_ACCESS)
			{
				CString csError;
				csError.Format(_T("CreateProfile failed to create Outlook Profile, hr = 0x%x"), hr);
				MessageBox(csError, _T("Error"), MB_OK);
			}

			MAPI::LPMAPITABLE    lpProfileTable = NULL;

			// Get the Table of Profiles
			hr = lpProfAdmin->GetProfileTable(0, &lpProfileTable);
			if (SUCCEEDED(hr))
			{
				ULONG	lCount = 0;

				sres.rt = RES_PROPERTY;
				sres.res.resProperty.relop = RELOP_EQ;
				sres.res.resProperty.ulPropTag = PR_DEFAULT_PROFILE;
				sres.res.resProperty.lpProp = &spvDefaultProfile;

				lpProfileTable->GetRowCount(0, &lCount);
				hr = lpProfileTable->QueryRows(lCount, 0, &pRow);
				if (SUCCEEDED(hr) && pRow)
				{
					UINT	i;
					for (i = 0; i < pRow->cRows; i++)
					{
						if (PROP_TYPE(pRow->aRow[i].lpProps[0].ulPropTag) == PT_STRING8)
						{
#ifdef _UNICODE
							lpDisplayName = AnsiToUnicode(pRow->aRow[i].lpProps[0].Value.lpszA).c_str();
#else
							lpDisplayName = pRow->aRow[i].lpProps[0].Value.lpszA;
#endif
							pcbOutlookProfile->AddString(lpDisplayName);
						}
						else if (PROP_TYPE(pRow->aRow[i].lpProps[0].ulPropTag) == PT_UNICODE)
						{
#ifdef _UNICODE
							lpDisplayName = pRow->aRow[i].lpProps[0].Value.lpszW;
#else
							lpDisplayName = UnicodeToAnsi(pRow->aRow[i].lpProps[0].Value.lpszW).c_str();
#endif
							pcbOutlookProfile->AddString(lpDisplayName);					
						}					

						if (pRow->aRow[i].lpProps[1].Value.b)
							nDefaultProfile = i;
					}
					FreeProws(pRow);
				}

				lpProfileTable->Release();
			}
		}
		else
		{
			//		CString csError;
			//		csError.Format(_T("MAPIAdminProfiles failed with hr = 0x%x"), hr);
			//		MessageBox(csError, _T("Error"), MB_OK);

			pcbOutlookProfile->EnableWindow(FALSE);

		}
		MAPI::MAPIUninitialize();
		CoUninitialize();
	}
	else
	{
		pcbOutlookProfile->EnableWindow(FALSE);
	}
	  
	if (nDefaultProfile != -1)
		pcbOutlookProfile->SetCurSel(nDefaultProfile);
	if (!m_OutlookProfileName.IsEmpty())
	{
		if (pcbOutlookProfile->FindStringExact(-1, m_OutlookProfileName) == CB_ERR)
			pcbOutlookProfile->AddString(m_OutlookProfileName);
		pcbOutlookProfile->SelectString(0, m_OutlookProfileName);
	}



	m_strFromAddress = m_pService->m_strSMTPFromAddress.Get().c_str();
	m_strToAddress	= m_pService->m_strSMTPReplyAddress.Get().c_str();
	m_strMessageBody = m_pService->m_strSMTPCustomText.Get().c_str();
	m_lBounceTime = m_pService->m_lMinutesToBounce.Get();

	m_strServerName	= m_pService->m_strSMTPServerName.Get().c_str();
	m_strUserName	= m_pService->m_strSMTPUserName.Get().c_str();
	m_strPasswd		= m_pService->m_strSMTPPassword.Get().c_str();
	m_nPortNo		= m_pService->m_lSMTPServerPort.Get();
	
	
	IM::NrString aCaption = BuildCaption(IDS_PROP_110, m_pService->m_strServiceDisplayName.c_str(), m_pService->m_strComputerName.c_str());
	SetWindowText(aCaption.c_str());

	UpdateData(0);

	CDialog::OnInitDialog();

	m_SavedDomain = m_Domain;

	return 0;
}


void EmsServiceProp::OnOK() 
{
	long lBounce = GetDlgItemInt(IDC_EMS_BOUNCETIME);
	if (lBounce < 30 || lBounce > 1440)
	{
		// Load this string from the string table?
		MessageBox(_T("Value for \"Bounce Mail Time\" has to be between 30 and 1440."), _T("Error"), MB_OK);
		GetDlgItem(IDC_EMS_BOUNCETIME)->SetFocus();
		return;
	}

	// Read all the values from the dialog
	GetDlgItemText(IDC_EMS_CLASS, m_Class);
	GetDlgItemText(IDC_EMS_SUBCLASS, m_strSubClass);
	GetDlgItemText(IDC_EMS_TYPE, m_Type);
	

	GetDlgItemText(IDC_EMS_DOMAIN, m_Domain);
	GetDlgItemText(IDC_EMS_DIRECTORY, m_Directory);
	//GetDlgItemText(IDC_EMS_DROPDIR, m_Directory);
	GetDlgItemText(IDC_EMS_BADMAILDIR, m_strBadMailDir);
	GetDlgItemText(IDC_EMS_TARGETPATH, m_strTargetPath);
	
	CComboBox *pcbOutlookProfile;
	pcbOutlookProfile = (CComboBox *)GetDlgItem(IDC_EMS_OUTLOOKPROFILE);
	int nIndex = pcbOutlookProfile->GetCurSel();
	if (nIndex != CB_ERR)
		pcbOutlookProfile->GetLBText(nIndex, m_OutlookProfileName);


	//GetDlgItemText(IDC_EMS_OUTLOOK_PROFILE, m_OutlookProfileName);
	//GetDlgItemText(IDC_EMS_OUTLOOK_PASSWORD, m_OutlookPassword);
	
	
	GetDlgItemText(IDC_EMS_FROMADDRESS, m_strFromAddress);
	GetDlgItemText(IDC_EMS_TOADDRESS, m_strToAddress);
	GetDlgItemText(IDC_EMS_MSGBODY, m_strMessageBody);
	m_lBounceTime = GetDlgItemInt(IDC_EMS_BOUNCETIME);

	
	GetDlgItemText(IDC_EMS_SERVERNAME, m_strServerName);
	GetDlgItemText(IDC_EMS_USERNAME, m_strUserName);
	GetDlgItemText(IDC_EMS_PASSWORD, m_strPasswd);
	m_nPortNo = GetDlgItemInt(IDC_EMS_PORTNO);


	m_Class.TrimLeft();
	m_Class.TrimRight();
	m_strSubClass.TrimRight();
	m_strSubClass.TrimLeft();
	m_Type.TrimLeft();
	m_Type.TrimRight();

	m_Domain.TrimLeft();
	m_Domain.TrimRight();
	m_Directory.TrimLeft();
	m_Directory.TrimRight();
	m_strBadMailDir.TrimLeft();
	m_strBadMailDir.TrimRight();
	m_strTargetPath.TrimLeft();
	m_strTargetPath.TrimRight();
	
	//m_OutlookProfileName.TrimLeft();
	//m_OutlookProfileName.TrimRight();
	//m_OutlookPassword.TrimLeft();
	//m_OutlookPassword.TrimRight();

	m_strFromAddress.TrimLeft();
	m_strFromAddress.TrimRight();
	m_strToAddress.TrimLeft();
	m_strToAddress.TrimRight();
	
	m_strServerName.TrimLeft();
	m_strServerName.TrimRight();
	m_strUserName.TrimLeft();
	m_strUserName.TrimRight();

	// validate the values
	if (m_Class.IsEmpty() || m_Type.IsEmpty() ||
		m_Domain.IsEmpty() || m_Directory.IsEmpty() || m_strBadMailDir.IsEmpty() ||
		m_strTargetPath.IsEmpty() ||
		m_strFromAddress.IsEmpty() || m_strToAddress.IsEmpty() ||
		m_strServerName.IsEmpty() || m_strUserName.IsEmpty()
	   )
	{
		MessageBox(_T("Please make sure that all values are filled correctly!"), _T("Error"), MB_OK);
		return;
	}

	// Store all the values into the registry
	m_pService->m_strClass.Set(m_Class);
	m_pService->m_strSubClass.Set(m_strSubClass);
	m_pService->m_strType.Set(m_Type);
	

	if (m_Domain != m_SavedDomain)
	{
		IM::NrString strSavedDomain = m_SavedDomain;
		m_pService->RemoveDomainFromRegistry(strSavedDomain);
		IM::NrString strDomain = m_Domain;
		m_pService->AddDomainToRegistry(strDomain);
	}
	m_pService->m_strDropDirectory.Set(m_Directory);
	m_pService->m_strBadDirectory.Set(m_strBadMailDir);
	m_pService->m_strTargetDirectory.Set(m_strTargetPath);
	m_pService->m_strOutlookProfile.Set(m_OutlookProfileName);

	m_pService->m_strSMTPFromAddress.Set(m_strFromAddress);
	m_pService->m_strSMTPReplyAddress.Set(m_strToAddress);
	m_pService->m_strSMTPCustomText.Set(m_strMessageBody);
	m_pService->m_lMinutesToBounce.Set(m_lBounceTime);

	m_pService->m_strSMTPServerName.Set(m_strServerName);
	m_pService->m_strSMTPUserName.Set(m_strUserName);
	m_pService->m_strSMTPPassword.Set(m_strPasswd);
	m_pService->m_lSMTPServerPort.Set(m_nPortNo);
	

	try
	{
		m_pService->StoreInRegistry();
	}
	catch(IM::Exception &)
	{
	}

	CDialog::OnOK();
}

void EmsServiceProp::OnCancel() 
{	
	CDialog::OnCancel();
}

void EmsServiceProp::OnHelp() 
{
	::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, 25);
}

void EmsServiceProp::OnEmsDropdirButton() 
{
	GetDirectory(m_Directory);
	SetDlgItemText(IDC_EMS_DIRECTORY, m_Directory);
}

void EmsServiceProp::OnEmsBadMailButton() 
{
	GetDirectory(m_strBadMailDir);
	SetDlgItemText(IDC_EMS_BADMAILDIR, m_strBadMailDir);
}

void EmsServiceProp::GetDirectory(CString &csPath)
{
	HRESULT hr			= S_OK;
	DWORD	dwFlags		= OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT;
	TCHAR	szFolder[MAX_PATH];
	TCHAR	szPath[MAX_PATH + MAX_PATH];
	
	BROWSEINFO		stBrowse = {0};
	LPITEMIDLIST	pItemIdList = NULL;
	


	//CoInitializeEx(NULL, COINIT_APARTMENTTHREADED);
	hr = CoInitialize(NULL);
	szFolder[0] = 0;
	szPath[0]	= 0;
	stBrowse.hwndOwner = m_hWnd;
	stBrowse.pszDisplayName = szFolder;
	stBrowse.ulFlags = BIF_USENEWUI  | BIF_EDITBOX;
	stBrowse.lpfn = NULL; // No Callback fn
	stBrowse.lParam = 0;

	pItemIdList = SHBrowseForFolder(&stBrowse);
	if (pItemIdList)
	{
		SHGetPathFromIDList(pItemIdList, szPath);   // Make sure it is a path
		csPath = szPath;
		// Need to free this memory using IMalloc::Free
		//Free(pItemIdList);
	}
	
	CoUninitialize();
}

void EmsServiceProp::OnTargetpathBtn() 
{
	GetDirectory(m_strTargetPath);
	SetDlgItemText(IDC_EMS_TARGETPATH, m_strTargetPath);
}

