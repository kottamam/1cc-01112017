#if !defined(AFX_KMINDEXERPROPERTIES_H__F8EDF3DA_2875_40C0_87E1_20F039A367AF__INCLUDED_)
#define AFX_KMINDEXERPROPERTIES_H__F8EDF3DA_2875_40C0_87E1_20F039A367AF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// KMIndexerProperties.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// KMIndexerProperties dialog

class KMIndexerProperties : public CDialog
{
// Construction
public:
	KMIndexerProperties(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(KMIndexerProperties)
	enum { IDD = IDD_KMINDEXER_PROPERTIES };

	BOOL	m_bUseLocalServer;
	CString m_strDre;
	long	m_lIndexPort;
	long	m_lQueryPort;

	CString	m_strWorkSiteServer;

	BOOL	m_abMatrix[7][12];

	//}}AFX_DATA

	IM::WkIndxrServiceConfiguration	*m_pService;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(KMIndexerProperties)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	BOOL OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo);
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(KMIndexerProperties)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnChange();
	afx_msg void OnScheduleRb();
	afx_msg void OnContinuousRb();
	afx_msg void OnHelp();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	void
		EnableScheduleMatrix();

	void
		DisableScheduleMatrix();

	bool
		IdIsChild(int id);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_KMINDEXERPROPERTIES_H__F8EDF3DA_2875_40C0_87E1_20F039A367AF__INCLUDED_)
