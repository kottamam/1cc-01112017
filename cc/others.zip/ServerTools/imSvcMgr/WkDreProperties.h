#if !defined(AFX_WKDREPROPERTIES_H__781958E5_1FDF_4508_9963_DFF9B24C1C8C__INCLUDED_)
#define AFX_WKDREPROPERTIES_H__781958E5_1FDF_4508_9963_DFF9B24C1C8C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// WkDreProperties.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// WkDreProperties dialog

class WkDreProperties : public CDialog
{
// Construction
public:
	WkDreProperties(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(WkDreProperties)
	enum { IDD = IDD_WKDRE };

	CString m_strDreIniFilePath;
	BOOL	m_bWkEnable;
	CString m_strWorkSite;
	BOOL	m_bWsSpecifyServicePort;
	CString m_strWsServicePort;
	CString m_strIndexPort;
	CString m_strQueryPort;

	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(WkDreProperties)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(WkDreProperties)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnChange();
	afx_msg void OnCheckEnableSecurity();
	afx_msg void OnCheckServicePort();
	afx_msg void OnWkdreButtonViewlog();
	afx_msg void OnHelp();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

public:
	IM::WkDreServiceConfiguration	*m_pService;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WKDREPROPERTIES_H__781958E5_1FDF_4508_9963_DFF9B24C1C8C__INCLUDED_)
