// StartingService.cpp : implementation file
//

#include "stdafx.h"
#include "imSvcMgr.h"
#include <Report\Report.h>

#include "StartingService.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// StartingService dialog


StartingService::StartingService(CWnd* pParent /*=NULL*/)
	: CDialog(StartingService::IDD, (CWnd*)pParent)
{
	//{{AFX_DATA_INIT(StartingService)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

StartingService::~StartingService()
{
//	KillTimer(m_TimerID);
}

void StartingService::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(StartingService)
	DDX_Control(pDX, IDC_PROGRESS1, m_StartStopProgress);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(StartingService, CDialog)
	//{{AFX_MSG_MAP(StartingService)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// StartingService message handlers

BOOL StartingService::OnInitDialog() 
{
	CDialog::OnInitDialog();

	if (startType == ST_START)
	{
		IM::NrString aCaption = BuildCaption(IDS_START_202, m_pService->m_strServiceDisplayName.c_str(), m_pService->m_strComputerName.c_str());
		SetWindowText(aCaption.c_str());

		if (m_pService->StartService() != TRUE)
		{
			LastErrorString	eString;

			startType = ST_EXIT;
			Report(REP_WARN, IDS_START_203, m_pService->m_strServiceDisplayName.c_str(), eString.c_str());
		}
	}
	else
    {
		IM::NrString aCaption = BuildCaption(IDS_START_204, m_pService->m_strServiceDisplayName.c_str(), m_pService->m_strComputerName.c_str());
		SetWindowText(aCaption.c_str());

		if (m_pService->StopService() != TRUE)
		{
			startType = ST_EXIT;
			Report(REP_WARN, IDS_START_205, m_pService->m_strServiceDisplayName.c_str());
		}
    }

	m_StartStopProgress.SetStep(1);
	m_StartStopProgress.SetPos(0);
	m_TimerID = SetTimer(2000, 100, NULL); 
	return 0;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void StartingService::OnTimer(UINT_PTR nIDEvent) 
{
	m_StartStopProgress.StepIt();

	if (startType == ST_EXIT)
	{
		SendMessage(WM_CLOSE);
		return;
	}


	// allow the service some time to process the request
	if (m_StartStopProgress.GetPos() <= 30)
		return;


	if ((startType == ST_START && m_pService->IsRunning() == TRUE) ||
		(startType == ST_STOP && m_pService->IsStopped() == TRUE))
	{
		SendMessage(WM_CLOSE);
		return;
	}


	if (m_StartStopProgress.GetPos() >= 100)
    {
    	if (startType == ST_START)
			Report(REP_WARN, IDS_START_200);
        else
			Report(REP_WARN, IDS_START_201);

		SendMessage(WM_CLOSE);
    }
	
	CDialog::OnTimer(nIDEvent);
}
