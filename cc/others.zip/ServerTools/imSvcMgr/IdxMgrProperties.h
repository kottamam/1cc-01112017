#ifndef IDXMGR_PROPERTIES_H
#define IDXMGR_PROPERTIES_H

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// IdxMgrProperties.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// IdxMgrProperties dialog

class IdxMgrProperties : public CDialog
{
// Construction
public:
	IdxMgrProperties(CWnd* pParent = NULL);   // standard constructor
	IM::IdxMgrServiceConfiguration		*m_pService;

// Dialog Data
	//{{AFX_DATA(IdxMgrProperties)
	enum { IDD = IDD_IDXMGR_PROPERTIES };
	CSpinButtonCtrl	m_SpinBlockSize;
	CString	m_BlockSize;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(IdxMgrProperties)
public:
	virtual BOOL OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo);
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(IdxMgrProperties)
	virtual int OnInitDialog();
	virtual void OnOK();
	afx_msg void OnClose();
	afx_msg void OnScheduleRb();
	afx_msg void OnContinuousRb();
	virtual void OnCancel();
	afx_msg void OnHelp();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	void Changed();

	int	 cbMatrix[7][12];
	int	 CB000;
	int	 CB001;
	int	 CB002;
	int	 CB003;
	int	 CB004;
	int	 CB005;
	int	 CB006;
	int	 CB007;
	int	 CB008;
	int	 CB009;
	int	 CB010;
	int	 CB011;
		
	int	 CB100;
	int	 CB101;
	int	 CB102;
	int	 CB103;
	int	 CB104;
	int	 CB105;
	int	 CB106;
	int	 CB107;
	int	 CB108;
	int	 CB109;
	int	 CB110;
	int	 CB111;
		
	int	 CB200;
	int	 CB201;
	int	 CB202;
	int	 CB203;
	int	 CB204;
	int	 CB205;
	int	 CB206;
	int	 CB207;
	int	 CB208;
	int	 CB209;
	int	 CB210;
	int	 CB211;
		
	int	 CB300;
	int	 CB301;
	int	 CB302;
	int	 CB303;
	int	 CB304;
	int	 CB305;
	int	 CB306;
	int	 CB307;
	int	 CB308;
	int	 CB309;
	int	 CB310;
	int	 CB311;
		
	int	 CB400;
	int	 CB401;
	int	 CB402;
	int	 CB403;
	int	 CB404;
	int	 CB405;
	int	 CB406;
	int	 CB407;
	int	 CB408;
	int	 CB409;
	int	 CB410;
	int	 CB411;
		
	int	 CB500;
	int	 CB501;
	int	 CB502;
	int	 CB503;
	int	 CB504;
	int	 CB505;
	int	 CB506;
	int	 CB507;
	int	 CB508;
	int	 CB509;
	int	 CB510;
	int	 CB511;
		
	int	 CB600;
	int	 CB601;
	int	 CB602;
	int	 CB603;
	int	 CB604;
	int	 CB605;
	int	 CB606;
	int	 CB607;
	int	 CB608;
	int	 CB609;
	int	 CB610;
	int	 CB611;

	void EnableScheduleMatrix();
	void DisableScheduleMatrix();
	bool IdIsChild(int id);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // IDXMGR_PROPERTIES_H
