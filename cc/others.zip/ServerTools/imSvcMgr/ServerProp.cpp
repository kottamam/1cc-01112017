// ServerProp.cpp : implementation file 
//

#include <stdafx.h>

#include <imSvcMgr.h>
#include <ServerProp.h>
 
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif    

/////////////////////////////////////////////////////////////////////////////
// ServerProp dialog


ServerProp::ServerProp(CWnd* pParent /*=NULL*/)
	: CDialog(ServerProp::IDD, pParent)
{
	//{{AFX_DATA_INIT(ServerProp)
	m_LogonID = _T("");
	m_Password = _T("");

	m_ConnectionCount = _T("");
	m_Connections = FALSE;

	m_bSpecifyServicePort = false;
	m_strServicePort = _T("");

	m_bSpecifyFilePort = false;
	m_strFilePort = _T("");

	m_nConnectionType = 0;

	m_pEntry = NULL;
	//}}AFX_DATA_INIT
}


void ServerProp::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(ServerProp)
	DDX_Text(pDX, IDC_SERVER, m_strServer);

	DDX_Text(pDX, IDC_LOGONID, m_LogonID);
	DDX_Text(pDX, IDC_PASSWORD, m_Password);

	DDX_Check(pDX, IDC_CONNECTIONS, m_Connections);
	DDX_Control(pDX, IDC_SPIN_CONNECTION_COUNT, m_SpinConnectionCount);
	DDX_Text(pDX, IDC_CONNECT_COUNT_EDIT, m_ConnectionCount);

	DDX_Check(pDX, IDC_GIVEN_SERV_PORT, m_bSpecifyServicePort);
	DDX_Text(pDX, IDC_SERVICE_PORT, m_strServicePort);

	DDX_Check(pDX, IDC_GIVEN_FILE_PORT, m_bSpecifyFilePort);
	DDX_Text(pDX, IDC_FILE_PORT, m_strFilePort);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(ServerProp, CDialog)
	//{{AFX_MSG_MAP(ServerProp)
	ON_EN_CHANGE(IDC_SERVER, Changed)

	ON_EN_CHANGE(IDC_LOGONID, Changed)
	ON_EN_CHANGE(IDC_PASSWORD, Changed)

	ON_BN_CLICKED(IDC_CONNECTIONS, Changed)
	ON_EN_CHANGE(IDC_CONNECT_COUNT_EDIT, Changed)

	ON_BN_CLICKED(IDC_GIVEN_SERV_PORT, Changed)
	ON_EN_CHANGE(IDC_SERVICE_PORT, Changed)

	ON_BN_CLICKED(IDC_GIVEN_FILE_PORT, Changed)
	ON_EN_CHANGE(IDC_FILE_PORT, Changed)

	ON_BN_CLICKED(IDHELP, OnHelp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// ServerProp message handlers
 
BOOL ServerProp::OnInitDialog()  
{
	UpdateData(0);
 
	// if MODIFY
	if (m_DatabaseValue.IsEmpty() == FALSE)
	{
		m_bAddMode = true;

		// Get repository information for this database and display
		m_pEntry = (IM::DmsDatabaseEntry *) m_pDatabaseList->Get((LPCTSTR)m_DatabaseValue);

		if(m_pEntry == NULL)
		{
	    	Report(REP_WARN, IDS_DBPROP_115);
			SendMessage(WM_CLOSE);
			return TRUE;
		}
		else if(m_pEntry->m_lConnectionType.Get() != IM::DatabaseEntry::DMSProxy)
		{
	    	Report(REP_WARN, IDS_DBPROP_115);
			SendMessage(WM_CLOSE);
			return TRUE;
		}

		m_strServer = m_DatabaseValue;
		GetDlgItem(IDC_SERVER)->EnableWindow(false);

		((CButton*)GetDlgItem(IDC_CONNECTIONS))->SetCheck(1);

		m_nConnectionType = IM::DatabaseEntry::DMSProxy;

		// enable the database connection info
		GetDlgItem(IDC_LOGONID)->EnableWindow(true);
		GetDlgItem(IDC_PASSWORD)->EnableWindow(true);

		m_LogonID = m_pEntry->m_strLogonID.Get().c_str();
		m_Password = m_pEntry->m_strPassword.Get().c_str();

		if (m_pEntry->m_bAsManyConnectionsAsThreads.Get() == true)
		{
			GetDlgItem(IDC_CONNECT_COUNT_EDIT)->EnableWindow(false);
			GetDlgItem(IDC_SPIN_CONNECTION_COUNT)->EnableWindow(false);
		}
		else
		{
			CString aString;
			_itot(m_pEntry->m_lConnectionCount.Get(), (_TCHAR*)(LPCSTR)aString.GetBuffer(10), 10);
			aString.ReleaseBuffer();
			m_ConnectionCount = aString;

			GetDlgItem(IDC_CONNECT_COUNT_EDIT)->EnableWindow(true);
			GetDlgItem(IDC_SPIN_CONNECTION_COUNT)->EnableWindow(true);
		}

		((CButton*)GetDlgItem(IDC_CONNECTIONS))->SetCheck(m_pEntry->m_bAsManyConnectionsAsThreads.Get());
        m_Connections = m_pEntry->m_bAsManyConnectionsAsThreads.Get();

		m_bSpecifyServicePort = m_pEntry->m_bGivenProxyServicePort.Get();
		((CButton*) GetDlgItem(IDC_GIVEN_SERV_PORT))->SetCheck(m_bSpecifyServicePort);
		if (m_bSpecifyServicePort)
		{
			CString aString;
			m_strServicePort = _itot(m_pEntry->m_lProxyServicePort.Get(), (_TCHAR*)(LPCSTR)aString.GetBuffer(10), 10);
			GetDlgItem(IDC_SERVICE_PORT)->SetWindowText(m_strServicePort);
		}
		else
		{
			GetDlgItem(IDC_SERVICE_PORT)->EnableWindow(false);
		}

		m_bSpecifyFilePort = m_pEntry->m_bGivenProxyFilePort.Get();
		((CButton*) GetDlgItem(IDC_GIVEN_FILE_PORT))->SetCheck(m_bSpecifyFilePort);
		if (m_bSpecifyFilePort)
		{
			CString aString;
			m_strFilePort = _itot(m_pEntry->m_lProxyFilePort.Get(), (_TCHAR*)(LPCSTR)aString.GetBuffer(10), 10);
			GetDlgItem(IDC_FILE_PORT)->SetWindowText(m_strFilePort);
		}
		else
		{
			GetDlgItem(IDC_FILE_PORT)->EnableWindow(false);
		}
	}
	else	// else ADD
	{
		m_bAddMode = false;

		m_Connections = true;
		m_ConnectionCount = _T("0");
		GetDlgItem(IDC_CONNECT_COUNT_EDIT)->EnableWindow(false);

		// disable the proxy server connection info
		GetDlgItem(IDC_SERVER)->EnableWindow(true);
		GetDlgItem(IDC_LOGONID)->EnableWindow(true);
		GetDlgItem(IDC_PASSWORD)->EnableWindow(true);
		GetDlgItem(IDC_GIVEN_SERV_PORT)->EnableWindow(true);
		GetDlgItem(IDC_SERVICE_PORT)->EnableWindow(0);
		GetDlgItem(IDC_GIVEN_FILE_PORT)->EnableWindow(true);
		GetDlgItem(IDC_FILE_PORT)->EnableWindow(0);
	}

	// Allow OK button only after a change
	GetDlgItem(IDOK)->EnableWindow(false);

	SetDefID(IDCANCEL);

	m_SpinConnectionCount.SetRange(0, 100);
	m_SpinConnectionCount.SetBuddy(GetDlgItem(IDC_CONNECT_COUNT_EDIT));

	CDialog::OnInitDialog();

	return(0);
}

void ServerProp::Changed() 
{
	if (!GetDlgItem(IDOK) || !::IsWindow(GetDlgItem(IDOK)->m_hWnd))
	{
		return;
	}

	BOOL bSpecifyServerPort = ((CButton*) GetDlgItem(IDC_GIVEN_SERV_PORT))->GetCheck();
	if (bSpecifyServerPort)
	{
		GetDlgItem(IDC_SERVICE_PORT)->EnableWindow(true);
	}
	else
	{
		GetDlgItem(IDC_SERVICE_PORT)->EnableWindow(false);
	}

	BOOL bSpecifyFilePort = ((CButton*) GetDlgItem(IDC_GIVEN_FILE_PORT))->GetCheck();
	if (bSpecifyFilePort)
	{
		GetDlgItem(IDC_FILE_PORT)->EnableWindow(true);
	}
	else
	{
		GetDlgItem(IDC_FILE_PORT)->EnableWindow(false);
	}

	// If "Specify Service Port" is set and the port field is empty, disable OK button.
	CString strServicePort;
	GetDlgItem(IDC_SERVICE_PORT)->GetWindowText(strServicePort);
	strServicePort.TrimLeft();
	strServicePort.TrimRight();
	if ((bSpecifyServerPort) && (strServicePort.IsEmpty()))
	{
		GetDlgItem(IDOK)->EnableWindow(false);
		SetDefID(IDCANCEL);
		return;
	}

	// If "Specify File Port" is set and the port field is empty, disable OK button.
	CString strFilePort;
	GetDlgItem(IDC_FILE_PORT)->GetWindowText(strFilePort);
	strFilePort.TrimLeft();
	strFilePort.TrimRight();
	if ((bSpecifyFilePort) && (strFilePort.IsEmpty()))
	{
		GetDlgItem(IDOK)->EnableWindow(false);
		SetDefID(IDCANCEL);
		return;
	}

	CString strServer;
	GetDlgItem(IDC_SERVER)->GetWindowText(strServer);
	strServer.TrimLeft();
	strServer.TrimRight();
	if (strServer.IsEmpty())
	{
		GetDlgItem(IDOK)->EnableWindow(false);
		SetDefID(IDCANCEL);
		return;
	}

	if (((CButton*)GetDlgItem(IDC_CONNECTIONS))->GetCheck() == 1)
	{
		GetDlgItem(IDC_CONNECT_COUNT_EDIT)->EnableWindow(0);
		GetDlgItem(IDC_SPIN_CONNECTION_COUNT)->EnableWindow(0);

		m_ConnectionCount = _T("0");
	}
	else
	{
		GetDlgItem(IDC_CONNECT_COUNT_EDIT)->EnableWindow();
		GetDlgItem(IDC_SPIN_CONNECTION_COUNT)->EnableWindow();
	}

	GetDlgItem(IDOK)->EnableWindow(true);

	SetDefID(IDOK);	
}

void ServerProp::OnOK() 
{
	CString strServicePort;
	CString strFilePort;
	long lServicePort = 0;
	long lFilePort = 0;

	m_nConnectionType = IM::DatabaseEntry::DMSProxy;

	GetDlgItem(IDC_SERVER)->GetWindowText(m_strServer);
	m_SavedOdbcName = m_strServer;

	GetDlgItem(IDC_CONNECT_COUNT_EDIT)->GetWindowText(m_ConnectionCount);

	if (!m_bAddMode)
	{
		m_pEntry = (IM::DmsDatabaseEntry *) m_pDatabaseList->NewEntry(m_SavedOdbcName);
	}
	else
	{
		m_pEntry->m_strDatabase.Set(m_SavedOdbcName);
	}

	m_pEntry->m_lConnectionType.Set(m_nConnectionType);

	GetDlgItem(IDC_LOGONID)->GetWindowText(m_LogonID);
	m_pEntry->m_strLogonID.Set(m_LogonID);

	GetDlgItem(IDC_PASSWORD)->GetWindowText(m_Password);
	m_pEntry->m_strPassword.Set(m_Password);

	m_pEntry->m_bGivenProxyServicePort.Set((((CButton*)GetDlgItem(IDC_GIVEN_SERV_PORT))->GetCheck() == 1));

	GetDlgItem(IDC_SERVICE_PORT)->GetWindowText(strServicePort);
	lServicePort = _ttoi(strServicePort);
	m_pEntry->m_lProxyServicePort.Set(lServicePort);

	m_pEntry->m_bGivenProxyFilePort.Set((((CButton*)GetDlgItem(IDC_GIVEN_FILE_PORT))->GetCheck() == 1));

	GetDlgItem(IDC_FILE_PORT)->GetWindowText(strFilePort);
	lFilePort = _ttoi(strFilePort);
	m_pEntry->m_lProxyFilePort.Set(lFilePort);

	m_pEntry->m_bAsManyConnectionsAsThreads.Set((((CButton*)GetDlgItem(IDC_CONNECTIONS))->GetCheck() == 1));
	m_pEntry->m_lConnectionCount.Set(_ttoi(m_ConnectionCount));

	try
	{
		if (!m_bAddMode)
		{
			m_pDatabaseList->Add(m_pEntry);
		}
		m_pEntry->StoreInRegistry();
	}
	catch (IM::Exception &)
	{
		Report(REP_WARN, IDS_DBPROP_117);
		return;
	}
	
	CDialog::OnOK();
}

void ServerProp::OnHelp() 
{
	::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, 11);
}

