// imSvcMgr.h : main header file for the SVCMGR application
//

#if !defined(AFX_SVCMGR_H__2F077602_D7EC_11D2_8C4D_00C04F68F9B3__INCLUDED_)
#define AFX_SVCMGR_H__2F077602_D7EC_11D2_8C4D_00C04F68F9B3__INCLUDED_

class CSvcMgrDoc;

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include <winsvc.h>
//#include <Service/ServiceMain.h>
#include <stl/NrString.h>

//#include <service/database.h>
//#include <service/FileServer.h>
#include <Registry\Registry.h>

#include "resource.h"       // main symbols
#include <code/message.h>




/////////////////////////////////////////////////////////////////////////////
// CSvcMgrApp:
// See SvcMgr.cpp for the implementation of this class
//

class MyDocTemplate : public CSingleDocTemplate
{
public:

	MyDocTemplate(UINT nIDResource, CRuntimeClass* pDocClass, CRuntimeClass* pFrameClass, CRuntimeClass* pViewClass) :
		 CSingleDocTemplate(nIDResource, pDocClass, pFrameClass, pViewClass) {}

		 virtual void SetDefaultTitle( CDocument* pDocument ) {}
};

class CSvcMgrApp : public CWinApp
{
public:
	CSvcMgrApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSvcMgrApp)
	virtual BOOL InitInstance();
	virtual int ExitInstance( );
	//}}AFX_VIRTUAL

// Implementation
	COleTemplateServer m_server;
		// Server object for document creation
	//{{AFX_MSG(CSvcMgrApp)
	afx_msg void OnAppAbout();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};


#define		SVC_DMS				0
#define		SVC_IDXMGR			1
#define		SVC_IDXSCH			2
#define		SVC_RULE			3
#define		SVC_FMA				4
#define		SVC_WKIDX			5
#define		SVC_WKATIDX			6
#define		SVC_WKDRE			7
#define		SVC_DSSYNC			8
#define		SVC_EMS				9
#define		SVC_CIFS			10
#define		SVC_IDX				11
#define		SVC_EFS				12
#define		SVC_PRINTREND		13
#define		SVC_EOL				14
#define		SVC_LN				15

#define KEY_NRSCONF_PATH		_T("software\\Interwoven\\WorkSite\\imSvcMgr")

#define		REP_DEBUG			0
#define		REP_INFO			1
#define		REP_WARN			2
#define		REP_ERROR			3

void Report(const WORD code, UINT uStringID, ...);
IM::NrString	BuildCaption(UINT uStringID, ...);
bool GetPrimaryDomainName(IM::NrString& domain);

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NEWSRVMGR_H__2F077602_D7EC_11D2_8C4D_00C04F68F9B3__INCLUDED_)
