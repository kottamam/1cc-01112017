#if !defined(AFX_CMSDATABASEPROP_H__3AB92DA3_0EEA_11D4_8BE2_00C04F0935D0__INCLUDED_)
#define AFX_CMSDATABASEPROP_H__3AB92DA3_0EEA_11D4_8BE2_00C04F0935D0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CMSDataBaseProp.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCMSDataBaseProp dialog

class CCMSDataBaseProp : public CDialog
{
// Construction
public:
	CCMSDataBaseProp(CWnd* pParent = NULL);   // standard constructor
	CString m_strPassedDBName;
// Dialog Data
	//{{AFX_DATA(CCMSDataBaseProp)
	enum { IDD = IDD_CMS_DB_PROP };
	CString	m_strCMSDBName;
	CString	m_strCMSDBPassword;
	int		m_nCMSConnCount;
	CString	m_strCMSDBLoginID;
	//}}AFX_DATA
	IM::DatabaseEntryList	*m_pDatabaseList;
	bool					m_bAllowPrimary;
    bool					m_bAddMode;
	CStringList* pDSNList;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCMSDataBaseProp)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CCMSDataBaseProp)
	virtual BOOL OnInitDialog();
	afx_msg void OnCmsOdbcBrowse();
	virtual void OnOK();
	afx_msg void OnChange();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CMSDATABASEPROP_H__3AB92DA3_0EEA_11D4_8BE2_00C04F0935D0__INCLUDED_)
