// DMSStartup.cpp : implementation file
//

#include <stdafx.h>

#include <imSvcMgr.h>
#include <DMSStartup.h>


#ifdef _DEBUG 
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

using namespace IM;

/////////////////////////////////////////////////////////////////////////////
// DMSStartup dialog


DMSStartup::DMSStartup(CWnd* pParent /*=NULL*/)
	: CDialog(DMSStartup::IDD, (CWnd*)pParent)
{
	//{{AFX_DATA_INIT(DMSStartup)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void DMSStartup::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(DMSStartup)
	DDX_Control(pDX, IDC_EDIT5, Password2);
	DDX_Control(pDX, IDC_EDIT6, Password1);
	DDX_Control(pDX, IDC_EDIT1, LogonID);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(DMSStartup, CDialog)
	//{{AFX_MSG_MAP(DMSStartup)
	ON_WM_CANCELMODE()
	ON_BN_CLICKED(IDC_AUTO_STARTUP, OnAutoStartup)
	ON_BN_CLICKED(IDC_MANUAL_STARTUP, OnManualStartup)
	ON_EN_CHANGE(IDC_EDIT1, OnChangeEdit1)
	ON_EN_CHANGE(IDC_EDIT6, OnChangeEdit6)
	ON_EN_CHANGE(IDC_EDIT5, OnChangeEdit5)
	ON_BN_CLICKED(IDHELP, OnHelp)
	ON_BN_CLICKED(IDC_LOCAL, OnLocalSys)
	ON_BN_CLICKED(IDC_LOGON, OnLogon)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// DMSStartup message handlers

BOOL DMSStartup::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_pService->GetServiceConfiguration(m_strLogonID, m_strPassword, m_bAutoStartup);
	if (m_pService->m_strLogonID.Get().c_str()[0] == '\0')
	{
		((CButton*)GetDlgItem(IDC_LOGON))->SetCheck(0);
		((CButton*)GetDlgItem(IDC_LOCAL))->SetCheck(1);
		GetDlgItem(IDC_EDIT1)->EnableWindow(false);
		GetDlgItem(IDC_EDIT5)->EnableWindow(false);
		GetDlgItem(IDC_EDIT6)->EnableWindow(false);
		isLocalService = true;

	}
	else
	{
		((CButton*)GetDlgItem(IDC_LOGON))->SetCheck(1);
		((CButton*)GetDlgItem(IDC_LOCAL))->SetCheck(0);
		LogonID.SetWindowText(m_strLogonID.c_str());
		Password1.SetWindowText(m_strPassword.c_str());
		Password2.SetWindowText(m_strPassword.c_str());
		isLocalService = false;
	}

	if (m_bAutoStartup == true)
	{
		CButton* aButton = (CButton*)GetDlgItem(IDC_AUTO_STARTUP);

		if (aButton)
			aButton->SetCheck(true);
		isAutomatic = true;
	}
	else
	{
		CButton* aButton = (CButton*)GetDlgItem(IDC_MANUAL_STARTUP);

		if (aButton)
			aButton->SetCheck(true);

		isAutomatic = false;
	}

	LogonID.SetFocus();
	IM::NrString aCaption = BuildCaption(IDS_STARTUP_210, m_pService->m_strServiceDisplayName.c_str(), m_pService->m_strComputerName.c_str());
	SetWindowText(aCaption.c_str());
	CString aLogonID;
	LogonID.GetWindowText(aLogonID);


	// if LocalSystem is being used then lookup the current user information and display it
	if (aLogonID == "LocalSystem" || aLogonID == "")
	{
//		m_pService->InitUserInfo();
//		LogonID.SetWindowText(m_pService->m_strDomainName.c_str());
//		LogonID.SetWindowText(aLogonID + "\\");
//		LogonID.SetWindowText(aLogonID + m_pService->m_strLogonID.Get().c_str());
		((CButton*)GetDlgItem(IDC_LOGON))->SetCheck(0);
		((CButton*)GetDlgItem(IDC_LOCAL))->SetCheck(1);
		LogonID.SetWindowText(_T(""));
		Password1.SetWindowText(_T(""));
		Password2.SetWindowText(_T(""));
	}

	GetDlgItem(IDOK)->EnableWindow(false);
	SetDefID(IDCANCEL);
	return 0;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void DMSStartup::OnCancelMode() 
{
	CDialog::OnCancelMode();
	
	// TODO: Add your message handler code here
	
}

void DMSStartup::OnAutoStartup() 
{
	GetDlgItem(IDOK)->EnableWindow(true);
	SetDefID(IDOK);
}

void DMSStartup::OnManualStartup() 
{
	GetDlgItem(IDOK)->EnableWindow(true);
	SetDefID(IDOK);
}

void DMSStartup::OnOK() 
{
	// do field validation
	CString aLogonID;
	LogonID.GetWindowText(aLogonID);
	CString aPassword1;
	Password1.GetWindowText(aPassword1);
	CString aPassword2;
	Password2.GetWindowText(aPassword2);
	bool localSys = false;
	bool automatic = false;
	bool userCredentials = false;
	if	(((CButton*)GetDlgItem(IDC_LOCAL))->GetCheck() == 1)
	{
		// It is a local system Account
		m_strPassword = m_strLogonID = aLogonID = _T("");
		m_pService->m_strPassword.Set(aLogonID);
		m_pService->m_strLogonID.Set(aLogonID);
		localSys = true;
	}
	else
	{
		// Logon Id & Password are supposed to be there.
		if (aLogonID == _T(""))
		{
			Report(REP_WARN, IDS_STARTUP_211, m_pService->m_strServiceDisplayName.c_str());
			return;
		}
		if (aPassword1 != aPassword2)
		{
			Report(REP_WARN, IDS_STARTUP_212);
			return;
		}

		m_strPassword = aPassword1;
		m_strLogonID = aLogonID;
		userCredentials = true;
	}

	CButton* aButton = (CButton*)GetDlgItem(IDC_AUTO_STARTUP);

	if (aButton->GetCheck() == TRUE)
	{
			m_bAutoStartup = TRUE;
			automatic = true;
	}
	else
	{
		m_bAutoStartup = FALSE;
	}
	
/*	if (!localSys)
	{
		CWaitCursor	wait;
		CString aUserName, aDomainName;
		int i = aLogonID.Find(_T('\\'));
		aDomainName = aLogonID.Left(i);
		aUserName = aLogonID.Mid(++i);
		_TCHAR psnuType[2048], lpszDomain[2048], UserSID[1024];
	    DWORD dwDomainLength = 250, dwSIDBufSize = 1024;     
		if (!LookupAccountName(m_pService->serverName.c_str(), aUserName, UserSID, &dwSIDBufSize,
							(wchar_t*)lpszDomain, &dwDomainLength, (PSID_NAME_USE)psnuType)) 
		{
			Report(REP_WARN, IDS_STARTUP_216, m_pService->serviceDisplayName.c_str());
			return;
		}
	}*/
	if ((localSys != isLocalService) || (automatic != isAutomatic)||(userCredentials == true))
	{
		isAutomatic = automatic;
		if (m_pService->SetServiceConfiguration(m_strLogonID.c_str(), m_strPassword.c_str(), m_bAutoStartup) != true)
		{
			Report(REP_WARN, IDS_MAIN_144, m_pService->m_strServiceDisplayName.c_str());
		}
		isLocalService = localSys;
	}

	CDialog::OnOK();
}

void DMSStartup::OnChangeEdit1() 
{
	GetDlgItem(IDOK)->EnableWindow(true);
	SetDefID(IDOK);
}

void DMSStartup::OnChangeEdit6() 
{
	GetDlgItem(IDOK)->EnableWindow(true);
	SetDefID(IDOK);
}

void DMSStartup::OnChangeEdit5() 
{
	GetDlgItem(IDOK)->EnableWindow(true);
	SetDefID(IDOK);
}

void DMSStartup::OnLocalSys()
{
	((CButton*)GetDlgItem(IDC_LOGON))->SetCheck(0);
	GetDlgItem(IDC_EDIT1)->EnableWindow(false);
	GetDlgItem(IDC_EDIT6)->EnableWindow(false);
	GetDlgItem(IDC_EDIT5)->EnableWindow(false);
	LogonID.SetWindowText(_T(""));
	Password1.SetWindowText(_T(""));
	Password2.SetWindowText(_T(""));
	GetDlgItem(IDOK)->EnableWindow(true);
	SetDefID(IDOK);

}

void DMSStartup :: OnLogon()
{
	((CButton*)GetDlgItem(IDC_LOCAL))->SetCheck(0);
	GetDlgItem(IDC_EDIT1)->EnableWindow(true);
	GetDlgItem(IDC_EDIT6)->EnableWindow(true);
	GetDlgItem(IDC_EDIT5)->EnableWindow(true);
	GetDlgItem(IDOK)->EnableWindow(true);
	SetDefID(IDOK);
}

void DMSStartup::OnHelp() 
{
	::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, 17);
}
