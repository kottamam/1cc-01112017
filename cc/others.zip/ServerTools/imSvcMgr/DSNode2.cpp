// DSNode2.cpp : implementation file
//

#include "stdafx.h"
#include "imsvcmgr.h"
#include "DSNode2.h"
#include "DSConnection.h"
#include "DSAttributeMap.h"
#include <winldap.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


extern CString GetComputerName( void );

/////////////////////////////////////////////////////////////////////////////
// DSNode2 dialog


DSNode2::DSNode2(CWnd* pParent /*=NULL*/)
	: CDialog(DSNode2::IDD, pParent), m_pDSGeneric( NULL ), m_strCurrentDn( _T( "" ) ), 
	m_pSyncSvc_Local( NULL ), m_pConnection_Local( NULL ), m_pAttributeMap_Local( NULL ), m_strNode( _T( "" ) ), m_strServer( _T( "" ) )
{
	//{{AFX_DATA_INIT(DSNode2)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

DSNode2::~DSNode2( void )
{
}


void DSNode2::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(DSNode2)
	DDX_Control(pDX, IDC_EDIT_CONTAINER, m_edtContainer);
	DDX_Control(pDX, IDC_EDIT_SELECTED_DN, m_edtSelectedDn);
	DDX_Control(pDX, IDC_LIST_CONTAINER, m_lstContainer);
	DDX_Control(pDX, IDC_LIST_OBJECTS, m_lstObjects);
	DDX_Control(pDX, IDCANCEL, m_btnCancel);
	DDX_Control(pDX, IDHELP, m_btnHelp);
	DDX_Control(pDX, IDOK, m_btnOk);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(DSNode2, CDialog)
	//{{AFX_MSG_MAP(DSNode2)
	ON_BN_CLICKED(IDHELP, OnHelp)
	ON_NOTIFY(NM_CLICK, IDC_LIST_OBJECTS, OnClickListObjects)
	ON_LBN_SELCHANGE(IDC_LIST_CONTAINER, OnSelchangeListContainer)
	ON_BN_CLICKED(IDC_BUTTON_LOGIN, OnButtonLogin)
	ON_BN_CLICKED(IDC_BUTTON_LOGOUT, OnButtonLogout)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// DSNode2 message handlers

BOOL DSNode2::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	CString strCaption;
	strCaption.Format( _T( "DS Synchronization Root Context on %s" ), m_strServer );
	SetWindowText( strCaption );

	InitObjectsList( );
	EnableControls( FALSE );

	OnButtonLogin();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void DSNode2::EnableControls( const BOOL bEnable )
{
	m_edtContainer.EnableWindow( bEnable );
	m_lstContainer.EnableWindow( bEnable );
	m_lstObjects.EnableWindow( bEnable );
	m_edtSelectedDn.EnableWindow( bEnable );
	m_btnOk.EnableWindow( bEnable );
}

void DSNode2::OnOK() 
{
	LdapLogout( );

	m_edtSelectedDn.GetWindowText( m_strNode );
	
	CDialog::OnOK();
}

void DSNode2::OnHelp() 
{
	::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, 54);
}

void DSNode2::OnCancel() 
{
	// TODO: Add extra cleanup here
	LdapLogout( );
	
	CDialog::OnCancel();
}

void DSNode2::SetRegistryObjects( IM::CDSSyncSvc* pSyncSvc, IM::CDSSyncSvc_Connection* pConnection )
{
	if( ( pSyncSvc != NULL ) && ( pConnection != NULL ) )
	{
		m_pSyncSvc_Local = pSyncSvc;
		m_pConnection_Local = pConnection;

		// look up attribute map
		m_pAttributeMap_Local = m_pSyncSvc_Local->FindAttributeMap( pConnection->m_strAttributeMapName.Get( ).c_str( ) );
	}
}

void DSNode2::OnButtonLogin() 
{
	LdapLogin( );

	if( m_pDSGeneric != NULL )
	{
		OnSelchangeListContainer( );
		EnableControls( TRUE );
	}
}

void DSNode2::OnButtonLogout() 
{
	LdapLogout( );

	EnableControls( FALSE );

	// clear list box and control
	m_lstContainer.ResetContent( );
	m_lstObjects.DeleteAllItems( );
	m_edtContainer.SetWindowText( _T( "" ) );

	m_strCurrentDn = _T( "" );

	if( m_pDSGeneric != NULL )
		m_pDSGeneric = NULL;

	// clear DN maps
	m_ContainerDnMap.Clear( );
	m_ObjectDnMap.Clear( );
}

/*
CString GetComputerName( void )
{
	TCHAR szBuffer[ 128 ];
	memset( szBuffer, 0, 128 * sizeof( TCHAR ) );
	DWORD dwSize = 128;
	if( GetComputerName( szBuffer, &dwSize ) )
		return szBuffer;
	else
		return _T( "" );
}
*/

void DSNode2::LdapLogin() 
{
	if( ( m_pSyncSvc_Local == NULL ) || ( m_pConnection_Local == NULL ) )
		return;

	IM::CDSSyncSvc_DSParameters::LDAPTYPE ldapType = ( IM::CDSSyncSvc_DSParameters::LDAPTYPE ) m_pConnection_Local->m_DSParameters.m_lServiceType.Get( );
	switch( ldapType )
	{
	case IM::CDSSyncSvc_DSParameters::Microsoft:
	case IM::CDSSyncSvc_DSParameters::Sun:
		m_pDSGeneric = new DSOM::CDSSyncInterface( m_pSyncSvc_Local, m_pConnection_Local, m_pAttributeMap_Local );
		break;
	case IM::CDSSyncSvc_DSParameters::Novell:
		m_pDSGeneric = new DSOM::CNDSSyncInterface( m_pConnection_Local, m_pAttributeMap_Local );
		break;
	}


	_bstr_t strErrMsg = _T( "" );
	int iRet = DSOM_SUCCESS;
	try
	{
		iRet = m_pDSGeneric->Login( );
	}

	catch( DSOM::CBaseException& e )
	{
		strErrMsg = e.GetErrorString();
		iRet = DSOM_FAILURE;
	}
	catch(imstd::exception e)
	{
		strErrMsg = e.what();
		iRet = DSOM_FAILURE;
	}
	catch(long lErrorCode)
	{
		lErrorCode;
		iRet = DSOM_FAILURE;
	}
	catch( ... )
	{
		iRet = DSOM_FAILURE;
	}

	if( iRet != DSOM_SUCCESS )
	{
		if( strErrMsg.length() > 0 )
		{
			_bstr_t msg = _T( "Login failed. " );
			msg += strErrMsg;
			AfxMessageBox( strErrMsg );
		}
		else
			AfxMessageBox( _T( "Login Failed." ) );

		LdapLogout();
		CDialog::OnCancel();
	}
	else
	{
		m_strCurrentDn = ( LPCTSTR ) m_pConnection_Local->m_strNode.Get( ).c_str( );

		if( ( m_strCurrentDn.length() == 0 ) && ( ldapType != IM::CDSSyncSvc_DSParameters::Novell ) )
		{
			DSOM::CDSSyncInterface* base = dynamic_cast< DSOM::CDSSyncInterface* >( m_pDSGeneric );
			m_strCurrentDn = _T( "" );
			if( base->GetDSInterface()->GetDefaultNamingContext( m_strCurrentDn ) == DSOM_SUCCESS )
				m_pConnection_Local->m_strNode.Set( ( LPCTSTR ) m_strCurrentDn );
		}
	}
}


void DSNode2::LdapLogout( void )
{
	if( m_pDSGeneric != NULL )
	{
		m_pDSGeneric->Logout( );

		delete m_pDSGeneric;
		m_pDSGeneric = NULL;
	}

	m_strCurrentDn = _T( "" );
}

void DSNode2::OnSelchangeListContainer() 
{
	if( m_pDSGeneric == NULL )
		return;

	BeginWaitCursor( );

	CString strSel;
	int nPos = m_lstContainer.GetCurSel( );
	if( nPos != LB_ERR )
	{
		m_lstContainer.GetText( nPos, strSel );
		m_strCurrentDn = ( LPCTSTR ) m_ContainerDnMap.GetDn((DWORD) m_lstContainer.GetItemData( nPos ) );
	}
	else
		m_strCurrentDn = ( LPCTSTR ) m_pConnection_Local->m_strNode.Get( ).c_str( );

	// refresh both lists
	DoRefresh( );

	EndWaitCursor( );
}

void DSNode2::DoRefresh( void ) 
{
	DSOM::CJediContext jc( "DSNode2", "DoRefresh" );

	_bstr_t strErrMsg = _T( "" );
	try
	{
		RefreshContainerList( );
	}

	catch( DSOM::CBaseException& e )
	{
		strErrMsg = e.GetErrorString();
	}
	catch(imstd::exception e)
	{
		strErrMsg = e.what();
	}
	catch(long lErrorCode)
	{
		lErrorCode;
	}
	catch( ... )
	{
	}

	EndWaitCursor( );

	if( strErrMsg.length() > 0 )
	{
		_bstr_t msg = _T( "Error refreshing container list. " );
		msg += strErrMsg;
		AfxMessageBox( strErrMsg );
	}
}

void DSNode2::RefreshContainerList( void )
{
	DSOM::CJediContext jc( "DSNode2", "RefreshContainerList" );
	BeginWaitCursor( );

	if( ( m_strCurrentDn.length( ) == 0 ) || ( m_pDSGeneric == NULL ) )
		return;

	// clear existing lists/maps
	m_ObjectDnMap.Clear( );
	m_lstObjects.DeleteAllItems( );

	m_ContainerDnMap.Clear( );
	m_lstContainer.ResetContent( );
	m_edtContainer.SetWindowText( ( LPCTSTR ) m_strCurrentDn );
	m_edtSelectedDn.SetWindowText( ( LPCTSTR ) m_strCurrentDn );

	// add ".." to container list control for parent unless this is the root
	bool isRoot = false;
	DWORD dwIsRoot = m_pDSGeneric->IsRootDn( m_strCurrentDn, isRoot );

	// temp debug for NT-20076
	if( dwIsRoot != DSOM_SUCCESS )
		return;

	if( !isRoot )
	{
		static const TCHAR szDotDot[] = _T( ".." );

		_bstr_t strParentDN = _T( "" );
		if( m_pDSGeneric->GetParentDn( m_strCurrentDn, strParentDN ) == DSOM_SUCCESS )
		{
			int iPos = m_lstContainer.AddString( szDotDot );
			m_lstContainer.SetItemData( iPos, m_ContainerDnMap.AddDn( strParentDN ) );
		}
	}
	else	// this is the root
	{
		
		// obviously this is only for Active Directory
		// since this is the root
		// add a special [..] for the root domain, if one exists (one won't exist if this is the forest root)
		// and add special "OU" items for any child domains

		// Commented out to fix NT-20076
		// This feature is buggy and should be removed
		// It was put in years ago but no one ever asked for it
		//
		/*
		DSOM::CDSSyncInterface* base = dynamic_cast< DSOM::CDSSyncInterface* >( m_pDSGeneric );
		if( base != NULL )
		{
			DSOM::CADSInterface *pADSInterface = dynamic_cast< DSOM::CADSInterface* >( base->GetDSInterface() );
			if( pADSInterface != NULL )
			{
				_bstr_t strRootDN = DSOM::CDSInterface::ComputeDomainNameFromDN( m_strCurrentDn );

				static DSOM::CFORESTTRUSTMAP forestTrusts;
				if( pADSInterface->GetForestTrusts( forestTrusts ) != DSOM_SUCCESS )
					return;

				DSOM::CForestTrust* pForestTrust = NULL;
				if( DSOM::CForestTrusts::FindCaseInsenstive( forestTrusts, strRootDN, pForestTrust ) != DSOM_SUCCESS )
					return;

				if( pForestTrust != NULL )
				{
					if( !pForestTrust->IsForestRoot() )
					{
						_bstr_t strParentDN = _T( "" );
						if( pForestTrust->GetParentDN( forestTrusts, strParentDN ) != DSOM_SUCCESS )
							return;

						DSOM::CForestTrust* pForestTrust = forestTrusts[ strParentDN ];
						if( pForestTrust != NULL )
						{
							_bstr_t display = pForestTrust->NetbiosName();

							if( display.length() > 0 )
							{
								if( pForestTrust->IsForestRoot() )
									display += L" [Forest Root]";
								else if( pForestTrust->IsTopLevelDomain() )
									display += L" [Root Domain]";
								else
									display += L" [Parent]";

								int iPos = m_lstContainer.AddString( display );
								m_lstContainer.SetItemData( iPos, m_ContainerDnMap.AddDn( pForestTrust->DN() ) );
							}
						}
					}

					DSOM::BSTRVEC children;
					if( pForestTrust->GetChildrenDNs( forestTrusts, children ) != DSOM_SUCCESS )
						return;

					for( DSOM::BSTRVEC::const_iterator iter = children.begin(); iter != children.end(); iter++ )
					{
						_bstr_t childDN = *iter;

						DSOM::CForestTrust* pForestTrust = forestTrusts[ childDN ];
						if( pForestTrust != NULL )
						{
							_bstr_t display = pForestTrust->NetbiosName();

							if( display.length() > 0 )
							{
								if( pForestTrust->IsTopLevelDomain() )
									display += L" [Root Domain]";
								else
									display += L" [Child]";

								int iPos = m_lstContainer.AddString( display );
								m_lstContainer.SetItemData( iPos, m_ContainerDnMap.AddDn( pForestTrust->DN() ) );
							}
						}
					}
				}
			}
		}
		*/
	}
	

	// add entries to container list control for child org units
	DSOM::CDSORGUNITLIST OrgUnitList;
	if( m_pDSGeneric->GetOUsInContainer( m_strCurrentDn, OrgUnitList ) == DSOM_SUCCESS )
	{
		for( DSOM::CDSORGUNITLIST::Const_Iterator iter = OrgUnitList.Begin( ); iter != OrgUnitList.End( ); iter++ )
		{
			DSOM::CDSOrgUnit* pTempOrgUnit = *iter;
			if( pTempOrgUnit != NULL )
			{
				int iPos = m_lstContainer.AddString( ( LPCTSTR ) pTempOrgUnit->GetName( ) );
				m_lstContainer.SetItemData( iPos, m_ContainerDnMap.AddDn( ( LPCTSTR ) pTempOrgUnit->GetDn( ) ) );

				if( _tcsicmp( m_strCurrentDn, ( LPCTSTR ) pTempOrgUnit->GetDn( ) ) != 0 )
					AddObjectToList( pTempOrgUnit );
			}
		}
	}

	EndWaitCursor( );
}


void DSNode2::AddObjectToList( DSOM::CDSOrgUnit* pOrgUnit )
{
	LV_ITEM lvItem;
	lvItem.mask = LVIF_TEXT;

	if( pOrgUnit != NULL )
	{
		// add name in the first column
		lvItem.pszText = ( LPTSTR ) ( LPCTSTR ) pOrgUnit->GetName( );
		lvItem.iItem = m_lstObjects.GetItemCount( );
		lvItem.iSubItem = 0;
		int iPos = m_lstObjects.InsertItem( &lvItem );
		m_lstObjects.SetItemData( iPos, m_ObjectDnMap.AddDn( ( LPCTSTR ) pOrgUnit->GetDn( ) ) );

		// add DN as a "subitem" in the 2nd column
		lvItem.iSubItem = 1;
		lvItem.pszText = ( LPTSTR ) ( LPCTSTR ) pOrgUnit->GetDn( );
		lvItem.iItem = iPos;
		m_lstObjects.SetItem( &lvItem );
	}
}

void DSNode2::InitObjectsList( void )
{
	CRect rcObjects;
	m_lstObjects.GetClientRect( rcObjects );

	int iObjectsWidth = rcObjects.Width( );
	int iScrollThumbWidth = ::GetSystemMetrics( SM_CXHTHUMB );

	CString strWidthTest = _T( "descending" );
	int iStrWidth = m_lstObjects.GetStringWidth( strWidthTest );

	// factor the border width into the string width
	iStrWidth += 12 * ::GetSystemMetrics( SM_CXBORDER );

	CString strId, strName;
	strId = _T( "Name" );
	strName = _T( "Distinguished Name" );

	m_lstObjects.InsertColumn( 1, strId, LVCFMT_LEFT, iStrWidth + iScrollThumbWidth, 1 );
	m_lstObjects.InsertColumn( 2, strName, LVCFMT_LEFT, iObjectsWidth - iScrollThumbWidth - iStrWidth, 2 );	

	LRESULT dwStyle =  m_lstObjects.SendMessage( LVM_GETEXTENDEDLISTVIEWSTYLE, 0, 0 );
	dwStyle |=  LVS_EX_FULLROWSELECT;
	m_lstObjects.SendMessage( LVM_SETEXTENDEDLISTVIEWSTYLE, 0, dwStyle );
}

void DSNode2::OnClickListObjects(NMHDR* pNMHDR, LRESULT* pResult) 
{
	CString strDn = _T( "" );

	POSITION pos = m_lstObjects.GetFirstSelectedItemPosition( );
	while( pos != NULL )
	{
		int iItem = m_lstObjects.GetNextSelectedItem( pos );
		DWORD dwData = (DWORD) m_lstObjects.GetItemData( iItem );
		strDn += (TCHAR*)m_ObjectDnMap.GetDn( dwData );

		if( pos != NULL )
			strDn += _T( ";" );
	}

	m_edtSelectedDn.SetWindowText( strDn );

	*pResult = 0;
}


