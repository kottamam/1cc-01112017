#pragma once


// HostedDMConfig dialog

class HostedDMConfig : public CDialog
{
	DECLARE_DYNAMIC(HostedDMConfig)

public:
	HostedDMConfig(IM::DmsServiceConfiguration	*pService, CWnd* pParent = NULL);   // standard constructor
	virtual ~HostedDMConfig();

// Dialog Data
	enum { IDD = IDD_HOSTED_DM };
	CComboBox	m_cboDSServerType;
	CComboBox	m_cboNtDomain;
	CEdit	m_edtDsServer;

	ObjectContainers::CUniqueBstrVector m_vDomainNames;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();
	void OnChange();
	afx_msg void OnSSLEenabled();

	DECLARE_MESSAGE_MAP()
public:	
	afx_msg void OnBnClickedHostedSslkeyBrowse();
	IM::DmsServiceConfiguration	*m_pService;
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedCancel();
	afx_msg void OnBnClickedHostedSslcaBrowse();
	afx_msg void OnSelchangeComboDsServerType();
	afx_msg void OnEditchangeComboNtDomain();


};
