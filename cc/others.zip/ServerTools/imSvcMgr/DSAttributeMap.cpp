// DSAttributeMap.cpp : implementation file
//

#include "stdafx.h"
#include "imsvcmgr.h"
#include "DSAttributeMap.h"

/*
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
*/

/////////////////////////////////////////////////////////////////////////////
// DSAttributeMap dialog


DSAttributeMap::DSAttributeMap(CWnd* pParent /*=NULL*/)
	: CDialog(DSAttributeMap::IDD, pParent), m_pSyncSvc_Local( NULL ), m_pAttributeMap_Local( NULL ), m_Mode( Add ), m_strServer( _T( "" ) )
{
	//{{AFX_DATA_INIT(DSAttributeMap)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

DSAttributeMap::~DSAttributeMap( void )
{
}


void DSAttributeMap::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(DSAttributeMap)
	DDX_Control(pDX, IDC_EDIT_NAMEDESC, m_edtNameDesc);
	DDX_Control(pDX, IDC_COMBO_USER_TELEPHONE, m_cboUserTelephone);
	DDX_Control(pDX, IDC_COMBO_USER_NAME, m_cboUserName);
	DDX_Control(pDX, IDC_COMBO_USER_LOCATION, m_cboUserLocation);
	DDX_Control(pDX, IDC_COMBO_USER_ID, m_cboUserId);
	DDX_Control(pDX, IDC_COMBO_USER_FAX, m_cboUserFax);
	DDX_Control(pDX, IDC_COMBO_USER_EMAIL, m_cboUserEmail);
	DDX_Control(pDX, IDC_COMBO_USER_ENABLED, m_cboUserEnabled);
	DDX_Control(pDX, IDC_COMBO_OU_NAME, m_cboOuName);
	DDX_Control(pDX, IDC_COMBO_GROUP_NAME, m_cboGroupName);
	DDX_Control(pDX, IDC_COMBO_GROUP_MEMBERS, m_cboGroupMembers);
	DDX_Control(pDX, IDC_COMBO_GROUP_ID, m_cboGroupId);
	DDX_Control(pDX, IDC_COMBO_K1SYNCID, m_cboK1SyncId);
	DDX_Control(pDX, IDCANCEL, m_btnCancel);
	DDX_Control(pDX, IDHELP, m_btnHelp);
	DDX_Control(pDX, IDOK, m_btnOk);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(DSAttributeMap, CDialog)
	//{{AFX_MSG_MAP(DSAttributeMap)
	ON_BN_CLICKED(IDHELP, OnHelp)
	ON_BN_CLICKED(IDC_BUTTON_ADS_DEFAULTS, OnButtonADSDefaults)
	ON_BN_CLICKED(IDC_BUTTON_SUNONE_DEFAULTS, OnButtonSunONEDefaults)
	ON_EN_CHANGE(IDC_EDIT_NAMEDESC, OnChangeGlobal)
	ON_CBN_EDITCHANGE(IDC_COMBO_K1SYNCID, OnChangeGlobal)
	ON_CBN_SELCHANGE(IDC_COMBO_K1SYNCID, OnChangeGlobal)
	ON_CBN_EDITCHANGE(IDC_COMBO_GROUP_ID, OnChangeGlobal)
	ON_CBN_SELCHANGE(IDC_COMBO_GROUP_ID, OnChangeGlobal)
	ON_CBN_EDITCHANGE(IDC_COMBO_GROUP_NAME, OnChangeGlobal)
	ON_CBN_SELCHANGE(IDC_COMBO_GROUP_NAME, OnChangeGlobal)
	ON_CBN_EDITCHANGE(IDC_COMBO_GROUP_MEMBERS, OnChangeGlobal)
	ON_CBN_SELCHANGE(IDC_COMBO_GROUP_MEMBERS, OnChangeGlobal)
	ON_CBN_EDITCHANGE(IDC_COMBO_OU_NAME, OnChangeGlobal)
	ON_CBN_SELCHANGE(IDC_COMBO_OU_NAME, OnChangeGlobal)
	ON_CBN_EDITCHANGE(IDC_COMBO_USER_ID, OnChangeGlobal)
	ON_CBN_SELCHANGE(IDC_COMBO_USER_ID, OnChangeGlobal)
	ON_CBN_EDITCHANGE(IDC_COMBO_USER_NAME, OnChangeGlobal)
	ON_CBN_SELCHANGE(IDC_COMBO_USER_NAME, OnChangeGlobal)
	ON_CBN_EDITCHANGE(IDC_COMBO_USER_LOCATION, OnChangeGlobal)
	ON_CBN_SELCHANGE(IDC_COMBO_USER_LOCATION, OnChangeGlobal)
	ON_CBN_EDITCHANGE(IDC_COMBO_USER_TELEPHONE, OnChangeGlobal)
	ON_CBN_SELCHANGE(IDC_COMBO_USER_TELEPHONE, OnChangeGlobal)
	ON_CBN_EDITCHANGE(IDC_COMBO_USER_FAX, OnChangeGlobal)
	ON_CBN_SELCHANGE(IDC_COMBO_USER_FAX, OnChangeGlobal)
	ON_CBN_EDITCHANGE(IDC_COMBO_USER_EMAIL, OnChangeGlobal)
	ON_CBN_SELCHANGE(IDC_COMBO_USER_EMAIL, OnChangeGlobal)
	ON_CBN_EDITCHANGE(IDC_COMBO_USER_ENABLED, OnChangeGlobal)
	ON_CBN_SELCHANGE(IDC_COMBO_USER_ENABLED, OnChangeGlobal)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// DSAttributeMap message handlers

BOOL DSAttributeMap::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	CString strCaption;
	strCaption.Format( _T( "DS Synchronization Attribute Map on %s" ), m_strServer );
	SetWindowText( strCaption );

	PopulateDropDowns( );
	UpdateFromAttributeMap( );
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}


void DSAttributeMap::SetRegistryObjects( IM::CDSSyncSvc* pSyncSvc, IM::CDSSyncSvc_AttributeMap* m_pAttributeMap )
{
	if( ( pSyncSvc != NULL ) && ( m_pAttributeMap != NULL ) )
	{
		m_pSyncSvc_Local = pSyncSvc;
		m_pAttributeMap_Local = m_pAttributeMap;
	}
}


void DSAttributeMap::OnOK() 
{
	if( ( m_pSyncSvc_Local == NULL ) || ( m_pAttributeMap_Local == NULL ) )
		return;

	// validate
	CString strMapName;
	m_edtNameDesc.GetWindowText( strMapName );

	CString strK1SyncId;
	m_cboK1SyncId.GetWindowText( strK1SyncId );

	CString strOuName;
	m_cboOuName.GetWindowText( strOuName );

	CString strUserName;
	m_cboUserName.GetWindowText( strUserName );

	CString strUserId;
	m_cboUserId.GetWindowText( strUserId );

	CString strUserEmail;
	m_cboUserEmail.GetWindowText( strUserEmail );

	CString strUserEnabled;
	m_cboUserEnabled.GetWindowText( strUserEnabled );

	CString strUserFax;
	m_cboUserFax.GetWindowText( strUserFax );

	CString strUserLocation;
	m_cboUserLocation.GetWindowText( strUserLocation );

	CString strUserTelephone;
	m_cboUserTelephone.GetWindowText( strUserTelephone );

	CString strGroupName;
	m_cboGroupName.GetWindowText( strGroupName );

	CString strGroupId;
	m_cboGroupId.GetWindowText( strGroupId );

	CString strGroupMembers;
	m_cboGroupMembers.GetWindowText( strGroupMembers );

	// update attribute map object
	m_pAttributeMap_Local->m_strMapName.Set( ( LPCTSTR ) strMapName );
	m_pAttributeMap_Local->m_strK1SyncId.Set( ( LPCTSTR ) strK1SyncId );
	m_pAttributeMap_Local->m_strOUName.Set( ( LPCTSTR ) strOuName );
	m_pAttributeMap_Local->m_strUserName.Set( ( LPCTSTR ) strUserName );
	m_pAttributeMap_Local->m_strUserId.Set( ( LPCTSTR ) strUserId );
	m_pAttributeMap_Local->m_strUserEmail.Set( ( LPCTSTR ) strUserEmail );
	m_pAttributeMap_Local->m_strUserEnabled.Set( ( LPCTSTR ) strUserEnabled );
	m_pAttributeMap_Local->m_strUserFax.Set( ( LPCTSTR ) strUserFax );
	m_pAttributeMap_Local->m_strUserLocation.Set( ( LPCTSTR ) strUserLocation );
	m_pAttributeMap_Local->m_strUserTelephone.Set( ( LPCTSTR ) strUserTelephone );
	m_pAttributeMap_Local->m_strGroupName.Set( ( LPCTSTR ) strGroupName );
	m_pAttributeMap_Local->m_strGroupId.Set( ( LPCTSTR ) strGroupId );
	m_pAttributeMap_Local->m_strGroupMember.Set( ( LPCTSTR ) strGroupMembers );
	
	CDialog::OnOK();
}

void DSAttributeMap::OnHelp() 
{
	::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, 56);
}

void DSAttributeMap::OnCancel() 
{
	// TODO: Add extra cleanup here
	
	CDialog::OnCancel();
}

void DSAttributeMap::UpdateFromAttributeMap( void )
{
	if( m_pAttributeMap_Local != NULL )
	{
		m_OtherMapNames.RemoveAll();

		CString strName = m_pAttributeMap_Local->m_strMapName.Get( ).c_str( );

		IM::CDSSyncSvc::ATTRIBUTEMAPLIST::const_iterator clIter;
		for( clIter = m_pSyncSvc_Local->m_AttributeMapList.begin(); clIter != m_pSyncSvc_Local->m_AttributeMapList.end(); clIter++ )
		{
			IM::CDSSyncSvc_AttributeMap* pMap = *clIter;
			if( pMap != m_pAttributeMap_Local )
				m_OtherMapNames.AddTail( pMap->m_strMapName.Get( ).c_str( ) );
		}

		m_edtNameDesc.SetWindowText( m_pAttributeMap_Local->m_strMapName.Get( ).c_str( ) );
		m_cboK1SyncId.SetWindowText( m_pAttributeMap_Local->m_strK1SyncId.Get( ).c_str( ) );
		m_cboOuName.SetWindowText( m_pAttributeMap_Local->m_strOUName.Get( ).c_str( ) );
		m_cboUserName.SetWindowText( m_pAttributeMap_Local->m_strUserName.Get( ).c_str( ) );
		m_cboUserId.SetWindowText( m_pAttributeMap_Local->m_strUserId.Get( ).c_str( ) );
		m_cboUserEmail.SetWindowText( m_pAttributeMap_Local->m_strUserEmail.Get( ).c_str( ) );
		m_cboUserEnabled.SetWindowText( m_pAttributeMap_Local->m_strUserEnabled.Get( ).c_str( ) );
		m_cboUserFax.SetWindowText( m_pAttributeMap_Local->m_strUserFax.Get( ).c_str( ) );
		m_cboUserLocation.SetWindowText( m_pAttributeMap_Local->m_strUserLocation.Get( ).c_str( ) );
		m_cboUserTelephone.SetWindowText( m_pAttributeMap_Local->m_strUserTelephone.Get( ).c_str( ) );
		m_cboGroupName.SetWindowText( m_pAttributeMap_Local->m_strGroupName.Get( ).c_str( ) );
		m_cboGroupId.SetWindowText( m_pAttributeMap_Local->m_strGroupId.Get( ).c_str( ) );
		m_cboGroupMembers.SetWindowText( m_pAttributeMap_Local->m_strGroupMember.Get( ).c_str( ) );
	}
}

void DSAttributeMap::PopulateDropDowns( void )
{
	m_cboK1SyncId.AddString( _T( "K1SyncId" ) );
	m_cboK1SyncId.AddString( _T( "objectGUID" ) );

	m_cboOuName.AddString( _T( "ou" ) );
	m_cboOuName.AddString( _T( "name" ) );
	m_cboOuName.AddString( _T( "cn" ) );

	m_cboUserName.AddString( _T( "cn" ) );
	m_cboUserName.AddString( _T( "displayName" ) );
	m_cboUserName.AddString( _T( "givenName" ) );
	m_cboUserName.AddString( _T( "name" ) );
	m_cboUserName.AddString( _T( "sn" ) );
	m_cboUserName.AddString( _T( "userPrincipalName" ) );

	m_cboUserId.AddString( _T( "uid" ) );
	m_cboUserId.AddString( _T( "sAMAccountName" ) );

	m_cboUserEmail.AddString( _T( "mail" ) );

	m_cboUserEnabled.AddString( _T( "userAccountControl" ) );

	m_cboUserFax.AddString( _T( "facsimileTelephoneNumber" ) );

	m_cboUserLocation.AddString( _T( "l" ) );
	m_cboUserLocation.AddString( _T( "physicalDeliveryOfficeName" ) );

	m_cboUserTelephone.AddString( _T( "telephoneNumber" ) );

	m_cboGroupName.AddString( _T( "cn" ) );
	m_cboGroupName.AddString( _T( "name" ) );

	m_cboGroupId.AddString( _T( "uid" ) );
	m_cboGroupId.AddString( _T( "cn" ) );
	m_cboGroupId.AddString( _T( "sAMAccountName" ) );

	m_cboGroupMembers.AddString( _T( "member" ) );
	m_cboGroupMembers.AddString( _T( "uniqueMember" ) );
}



void DSAttributeMap::OnButtonADSDefaults() 
{
	m_cboK1SyncId.SelectString( -1, _T( "objectGUID" ) );
	m_cboOuName.SelectString( -1, _T( "name" ) );
	m_cboUserName.SelectString( -1, _T( "name" ) );
	m_cboUserId.SelectString( -1, _T( "sAMAccountName" ) );
	m_cboUserEmail.SelectString( -1, _T( "mail" ) );
	m_cboUserEnabled.SelectString( -1, _T( "userAccountControl" ) );
	m_cboUserFax.SelectString( -1, _T( "facsimileTelephoneNumber" ) );
	//m_cboUserLocation.SelectString( -1, _T( "l" ) );
	m_cboUserLocation.SelectString( -1, _T( "physicalDeliveryOfficeName" ) );
	m_cboUserTelephone.SelectString( -1, _T( "telephoneNumber" ) );
	m_cboGroupName.SelectString( -1, _T( "name" ) );
	m_cboGroupId.SelectString( -1, _T( "sAMAccountName" ) );
	m_cboGroupMembers.SelectString( -1, _T( "member" ) );

	OnChangeGlobal();
}

void DSAttributeMap::OnButtonSunONEDefaults() 
{
	m_cboK1SyncId.SelectString( -1, _T( "K1SyncId" ) );
	m_cboOuName.SelectString( -1, _T( "ou" ) );
	m_cboUserName.SelectString( -1, _T( "displayName" ) );
	m_cboUserId.SelectString( -1, _T( "uid" ) );
	m_cboUserEmail.SelectString( -1, _T( "mail" ) );
	m_cboUserFax.SelectString( -1, _T( "facsimileTelephoneNumber" ) );
	m_cboUserLocation.SelectString( -1, _T( "l" ) );
	m_cboUserTelephone.SelectString( -1, _T( "telephoneNumber" ) );
	m_cboGroupName.SelectString( -1, _T( "cn" ) );
	m_cboGroupId.SelectString( -1, _T( "cn" ) );
	m_cboGroupMembers.SelectString( -1, _T( "uniqueMember" ) );

	OnChangeGlobal();
}

void DSAttributeMap::OnChangeGlobal() 
{
	if( ( m_pSyncSvc_Local == NULL ) || ( m_pAttributeMap_Local == NULL ) )
		return;

	bool bEnableOKButton = true;

	// validate
	CString strMapName;
	m_edtNameDesc.GetWindowText( strMapName );
	if( strMapName.GetLength( ) == 0 )
	{
		bEnableOKButton = false;
	}

	if( m_Mode == Add )
	{
		if( m_pSyncSvc_Local->AttributeMapExists( strMapName ) )
		{
			bEnableOKButton = false;
		}
	}
	else if( m_Mode == Edit )
	{
		// if any other attribute map has this name
		// besides this one (before editing)
		// then don't allow

		POSITION pos = m_OtherMapNames.Find( strMapName );
		if( pos != NULL )
			bEnableOKButton = false;
	}

	CString strK1SyncId;
	m_cboK1SyncId.GetWindowText( strK1SyncId );
	if( strK1SyncId.GetLength( ) == 0 )
	{
		bEnableOKButton = false;
	}

	CString strOuName;
	m_cboOuName.GetWindowText( strOuName );
	if( strOuName.GetLength( ) == 0 )
	{
		bEnableOKButton = false;
	}

	CString strUserName;
	m_cboUserName.GetWindowText( strUserName );
	if( strUserName.GetLength( ) == 0 )
	{
		bEnableOKButton = false;
	}

	CString strUserId;
	m_cboUserId.GetWindowText( strUserId );
	if( strUserId.GetLength( ) == 0 )
	{
		bEnableOKButton = false;
	}

	CString strUserEmail;
	m_cboUserEmail.GetWindowText( strUserEmail );
	/*if( strUserEmail.GetLength( ) == 0 )
	{
		bEnableOKButton = false;
	}*/

	CString strUserFax;
	m_cboUserFax.GetWindowText( strUserFax );
	/*if( strUserFax.GetLength( ) == 0 )
	{
		bEnableOKButton = false;
	}*/

	CString strUserLocation;
	m_cboUserLocation.GetWindowText( strUserLocation );
	/*if( strUserLocation.GetLength( ) == 0 )
	{
		bEnableOKButton = false;
	}*/

	CString strUserTelephone;
	m_cboUserTelephone.GetWindowText( strUserTelephone );
	/*if( strUserTelephone.GetLength( ) == 0 )
	{
		bEnableOKButton = false;
	}*/

	CString strGroupName;
	m_cboGroupName.GetWindowText( strGroupName );
	if( strGroupName.GetLength( ) == 0 )
	{
		bEnableOKButton = false;
	}

	CString strGroupId;
	m_cboGroupId.GetWindowText( strGroupId );
	if( strGroupId.GetLength( ) == 0 )
	{
		bEnableOKButton = false;
	}

	CString strGroupMembers;
	m_cboGroupMembers.GetWindowText( strGroupMembers );
	if( strGroupMembers.GetLength( ) == 0 )
	{
		bEnableOKButton = false;
	}

	m_btnOk.EnableWindow( bEnableOKButton ? TRUE : FALSE );

}
