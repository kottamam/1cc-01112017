// IdolIndexerProp.cpp: implementation of the IdolIndexerProp class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "IdolIndexerProp.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

IdolIndexerProp::IdolIndexerProp(IM::DmsDatabaseEntry	*pEntry_,CString &StrSavedODBCName, CWnd* pParent)
	: CDialog(IdolIndexerProp::IDD, pParent)
{
	//{{AFX_DATA_INIT(VelocityProp)
	m_SavedODBCName = StrSavedODBCName;
	m_pEntry = pEntry_;

	m_HostName = _T("");
	m_RepositoryName = _T("");

	m_PortNo = _T("");
	m_Key1 = _T("");
	m_Key2 = _T("");
	m_Key3 = _T("");
	m_Key4 = _T("");
	//}}AFX_DATA_INIT

}

IdolIndexerProp::~IdolIndexerProp()
{

}

void IdolIndexerProp::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
		//{{AFX_DATA_MAP(IdolIndexerProp)
	DDX_Text(pDX, IDC_HOST, m_HostName);
	DDX_Text(pDX, IDC_PORT, m_PortNo);
	DDX_Text(pDX, IDC_REPOSITORY, m_RepositoryName);
	DDX_Text(pDX, IDC_KEY1, m_Key1);
	DDX_Text(pDX, IDC_KEY2, m_Key2);
	DDX_Text(pDX, IDC_KEY3, m_Key3);
	DDX_Text(pDX, IDC_KEY4, m_Key4);
	//}}AFX_DATA_MAP

}

BEGIN_MESSAGE_MAP(IdolIndexerProp, CDialog)
	//{{AFX_MSG_MAP(IdolIndexerProp)
	ON_BN_CLICKED(IDOK, OnOK)
	ON_EN_CHANGE(IDC_HOST, OnChange)
	ON_EN_CHANGE(IDC_PORT, OnChange)
	ON_EN_CHANGE(IDC_REPOSITORY, OnChange)
	ON_EN_CHANGE(IDC_KEY1, OnChange)
	ON_EN_CHANGE(IDC_KEY2, OnChange)
	ON_BN_CLICKED(IDC_KEY3, OnChange)
	ON_EN_CHANGE(IDC_KEY4, OnChange)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BOOL IdolIndexerProp::OnInitDialog()
{
	CDialog::OnInitDialog();

	//
	// Get Velocity configuration information for this database and display
	//
	if (m_pEntry == NULL)
	{
//	    Report(REP_WARN, IDS_DBPROP_115);
	    SendMessage(WM_CLOSE);
	    return TRUE;
	}
	
	CString aString;
	m_HostName = m_pEntry->m_strIndexServer.Get().c_str();
	m_PortNo = _itot(m_pEntry->m_lIndexServerPort.Get(), (_TCHAR*)(LPCSTR)aString.GetBuffer(10), 10);

	CString strRepositoryName;
	strRepositoryName = _T("Worksite_");
	strRepositoryName.Append (m_SavedODBCName);

	if (_tcscmp(_T("Worksite_V4"),m_pEntry->m_strRepositoryName.Get().c_str() ) == 0)
	{
		m_RepositoryName = strRepositoryName;
	}
	else
	{
		m_RepositoryName = m_pEntry->m_strRepositoryName.Get ().c_str ();

	}

	m_Key1 = _itot(m_pEntry->m_lSecurityKey1.Get(), (_TCHAR*)(LPCSTR)aString.GetBuffer(10), 10);
	m_Key2 = _itot(m_pEntry->m_lSecurityKey2.Get(), (_TCHAR*)(LPCSTR)aString.GetBuffer(10), 10);
	m_Key3 = _itot(m_pEntry->m_lSecurityKey3.Get(), (_TCHAR*)(LPCSTR)aString.GetBuffer(10), 10);
	m_Key4 = _itot(m_pEntry->m_lSecurityKey4.Get(), (_TCHAR*)(LPCSTR)aString.GetBuffer(10), 10);


	//
	// Allow OK button only after a change
	//
	GetDlgItem(IDC_HOST)->SetWindowText(m_HostName);
	GetDlgItem(IDC_PORT)->SetWindowText(m_PortNo);
	GetDlgItem(IDC_REPOSITORY)->SetWindowText(m_RepositoryName);
	GetDlgItem(IDC_KEY1)->SetWindowText(m_Key1);
	GetDlgItem(IDC_KEY2)->SetWindowText(m_Key2);
	GetDlgItem(IDC_KEY3)->SetWindowText(m_Key3);
	GetDlgItem(IDC_KEY4)->SetWindowText(m_Key4);

	GetDlgItem(IDOK)->EnableWindow(false);

	return(TRUE);
}

void IdolIndexerProp::OnOK()
{
	
	GetDlgItem(IDC_HOST)->GetWindowText(m_HostName);
	GetDlgItem(IDC_PORT)->GetWindowText(m_PortNo);
	GetDlgItem(IDC_REPOSITORY)->GetWindowText(m_RepositoryName);
	GetDlgItem(IDC_KEY1)->GetWindowText(m_Key1);
	GetDlgItem(IDC_KEY2)->GetWindowText(m_Key2);
	GetDlgItem(IDC_KEY3)->GetWindowText(m_Key3);
	GetDlgItem(IDC_KEY4)->GetWindowText(m_Key4);

	
	m_pEntry->m_strIndexServer.Set(m_HostName);
	m_pEntry->m_lIndexServerPort.Set(_ttol(m_PortNo));
	m_pEntry->m_strRepositoryName.Set(m_RepositoryName);
	m_pEntry->m_lSecurityKey1.Set(_ttol(m_Key1));
	m_pEntry->m_lSecurityKey2.Set(_ttol(m_Key2));
	m_pEntry->m_lSecurityKey3.Set(_ttol(m_Key3));
	m_pEntry->m_lSecurityKey4.Set(_ttol(m_Key4));

	CDialog::OnOK();
}

void IdolIndexerProp::OnChange()
{
	CString strHost;
	GetDlgItem(IDC_HOST)->GetWindowText(strHost);
	if(strHost.IsEmpty())
		GetDlgItem(IDOK)->EnableWindow(false);
	else
		GetDlgItem(IDOK)->EnableWindow(true);
}
