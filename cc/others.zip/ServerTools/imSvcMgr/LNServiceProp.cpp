// LNServiceProp.cpp : implementation file
//

#include "stdafx.h"
#include "imSvcMgr.h"
#include "LNServiceProp.h"


// CLNServiceProp dialog

IMPLEMENT_DYNAMIC(CLNServiceProp, CDialog)

CLNServiceProp::CLNServiceProp(CWnd* pParent /*=NULL*/)
	: CDialog(CLNServiceProp::IDD, pParent)
	, m_sClass(_T(""))
	, m_sSubClass(_T(""))
	, m_sDocType(_T(""))
	//, m_sClusterName(_T(""))
	//, m_nFMAPort(0)
	, m_Domain(_T(""))
	, m_Directory(_T(""))
	, m_strBadMailDir(_T(""))
	, m_strTargetPath(_T(""))
	, m_strServerName(_T(""))
	, m_nPortNo(0)
	, m_strUserName(_T(""))
	, m_strPasswd(_T(""))
	, m_strFromAddress(_T(""))
	, m_strToAddress(_T(""))
	, m_strMessageBody(_T(""))
	, m_lBounceTime(0)
{

}

CLNServiceProp::~CLNServiceProp()
{
}

void CLNServiceProp::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_CLASS, m_sClass);
	DDX_Text(pDX, IDC_EDIT_SUBCLASS, m_sSubClass);
	DDX_Text(pDX, IDC_EDIT_DOCTYPE, m_sDocType);
	//DDX_Text(pDX, IDC_EDIT_CLUSTER_NAME, m_sClusterName);
	//DDX_Text(pDX, IDC_EDIT_FMA_PORT, m_nFMAPort);
	DDX_Control(pDX, IDC_CHECK_SENDFILE_AGENT, m_SendFileAgent);
	DDX_Text(pDX, IDC_EMS_DOMAIN, m_Domain);
	DDX_Text(pDX, IDC_EMS_DIRECTORY, m_Directory);
	DDX_Text(pDX, IDC_EMS_BADMAILDIR, m_strBadMailDir);
	DDX_Text(pDX, IDC_EMS_TARGETPATH, m_strTargetPath);
	DDX_Text(pDX, IDC_EMS_SERVERNAME, m_strServerName);
	DDX_Text(pDX, IDC_EMS_PORTNO, m_nPortNo);
	DDX_Text(pDX, IDC_EMS_USERNAME, m_strUserName);
	DDX_Text(pDX, IDC_EMS_PASSWORD, m_strPasswd);
	DDX_Text(pDX, IDC_EMS_FROMADDRESS, m_strFromAddress);
	DDX_Text(pDX, IDC_EMS_TOADDRESS, m_strToAddress);
	DDX_Text(pDX, IDC_EMS_MSGBODY, m_strMessageBody);
	DDX_Text(pDX, IDC_EMS_BOUNCETIME, m_lBounceTime);
}


BEGIN_MESSAGE_MAP(CLNServiceProp, CDialog)
	//{{AFX_MSG_MAP(CLNServiceProp)
	ON_BN_CLICKED(IDHELP, OnHelp)
	ON_BN_CLICKED(IDOK, OnOK)
	ON_BN_CLICKED(IDCANCEL, OnCancel)
	ON_BN_CLICKED(IDC_EMS_DROPDIRBTN, OnBnClickedEmsDropdirbtn)
	ON_BN_CLICKED(IDC_EMS_BADMAILBTN, OnBnClickedEmsBadmailbtn)
	ON_BN_CLICKED(IDC_EMS_TARGETPATH_BTN, OnBnClickedEmsTargetpathBtn)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_CHECK_SENDFILE_AGENT, &CLNServiceProp::OnBnClickedCheckSendfileAgent)
END_MESSAGE_MAP()


// CLNServiceProp message handlers

BOOL CLNServiceProp::OnInitDialog() 
{
	UpdateData(0);	
	m_pService->LoadFromRegistry();

	m_sClass				= m_pService->m_strClass.Get().c_str();
	m_sSubClass				= m_pService->m_strSubClass.Get().c_str();
	m_sDocType				= m_pService->m_strDocType.Get().c_str();
	//m_sClusterName			= m_pService->m_strClusterName.Get().c_str();
	//m_nFMAPort				= m_pService->m_nFmaPort.Get();

	m_SendFileAgent.SetCheck(m_pService->m_bEnableSendAndFileAgent.Get());
	EnableSendAndFileCtrls(TRUE);//m_pService->m_bEnableSendAndFileAgent.Get());
	
	if (!m_pService->m_DomainNames.empty())
		m_Domain = m_pService->m_DomainNames.begin()->c_str();
	m_SavedDomain = m_Domain;

	m_Directory				= m_pService->m_strDropDirectory.Get().c_str();
	m_strBadMailDir			= m_pService->m_strBadDirectory.Get().c_str();
	m_strTargetPath			= m_pService->m_strTargetDirectory.Get().c_str();
	m_strServerName			= m_pService->m_strSMTPServerName.Get().c_str();
	m_nPortNo				= m_pService->m_lSMTPServerPort.Get();
	m_strUserName			= m_pService->m_strSMTPUserName.Get().c_str();
	m_strPasswd				= m_pService->m_strSMTPPassword.Get().c_str();
	m_strFromAddress		= m_pService->m_strSMTPFromAddress.Get().c_str();
	m_strToAddress			= m_pService->m_strSMTPReplyAddress.Get().c_str();
	m_strMessageBody		= m_pService->m_strSMTPCustomText.Get().c_str();
	m_lBounceTime			= m_pService->m_lMinutesToBounce.Get();

	IM::NrString aCaption = BuildCaption(IDS_PROP_110, m_pService->m_strServiceDisplayName.c_str(), m_pService->m_strComputerName.c_str());
	SetWindowText(aCaption.c_str());

	UpdateData(0);
	return CDialog::OnInitDialog();
}

void CLNServiceProp::OnCancel() 
{	
	CDialog::OnCancel();
}

void CLNServiceProp::OnHelp()
{
	::HtmlHelp(NULL, HTML_HELP_FILENAME, HH_HELP_CONTEXT, 25);
}


void CLNServiceProp::OnOK()
{
	UpdateData();

	if (m_sClass.Trim().IsEmpty() || m_sDocType.Trim().IsEmpty())
	{
		MessageBox(_T("Please make sure that all values are filled correctly!"), _T("Error"), MB_OK|MB_ICONERROR);
		return;
	}

	if ((0 != ((CButton*)GetDlgItem(IDC_CHECK_SENDFILE_AGENT))->GetCheck()) &&
		(	m_Domain.Trim().IsEmpty()			||	m_Directory.Trim().IsEmpty()		|| 
			m_strBadMailDir.Trim().IsEmpty()	||	m_strTargetPath.Trim().IsEmpty()	||
			m_strFromAddress.Trim().IsEmpty()	||	m_strToAddress.Trim().IsEmpty()		||
			m_strServerName.Trim().IsEmpty()	||	m_strUserName.Trim().IsEmpty()))
	{
		MessageBox(_T("Please make sure that all values are filled correctly!"), _T("Error"), MB_OK|MB_ICONERROR);
		return;
	}

	if (m_Domain != m_SavedDomain)
	{
		IM::NrString strSavedDomain = m_SavedDomain;
		m_pService->RemoveDomainFromRegistry(strSavedDomain);
		IM::NrString strDomain = m_Domain;
		m_pService->AddDomainToRegistry(strDomain);
	}

	m_pService->m_strClass.Set(m_sClass);
	m_pService->m_strSubClass.Set(m_sSubClass.Trim());
	m_pService->m_strDocType.Set(m_sDocType);
	//m_pService->m_strClusterName.Set(m_sClusterName.Trim());
	//m_pService->m_nFmaPort.Set(m_nFMAPort);

	//Now WCS for Notes has this enabled by default. (This is the only feature now, no Server side filing).
	m_pService->m_bEnableSendAndFileAgent.Set(true);//0 != ((CButton*)GetDlgItem(IDC_CHECK_SENDFILE_AGENT))->GetCheck());
	m_pService->m_strDropDirectory.Set(m_Directory);
	m_pService->m_strBadDirectory.Set(m_strBadMailDir);
	m_pService->m_strTargetDirectory.Set(m_strTargetPath);

	m_pService->m_strSMTPServerName.Set(m_strServerName);
	m_pService->m_lSMTPServerPort.Set(m_nPortNo);
	m_pService->m_strSMTPUserName.Set(m_strUserName);
	m_pService->m_strSMTPPassword.Set(m_strPasswd);
	m_pService->m_strSMTPFromAddress.Set(m_strFromAddress);
	m_pService->m_strSMTPReplyAddress.Set(m_strToAddress);
	m_pService->m_strSMTPCustomText.Set(m_strMessageBody);

	if (m_lBounceTime < 30 || m_lBounceTime > 1440)
	{
		CString sBounceError; sBounceError.LoadStringW(IDS_STRING_BOUNCE_TIME_ERROR);
		MessageBox(sBounceError, _T("Error"), MB_OK|MB_ICONERROR);
		GetDlgItem(IDC_EMS_BOUNCETIME)->SetFocus();
		return;
	}
	m_pService->m_lMinutesToBounce.Set(m_lBounceTime);

	try{ m_pService->StoreInRegistry();	}
	catch(IM::Exception &) { }

	CDialog::OnOK();
}

void CLNServiceProp::EnableSendAndFileCtrls(BOOL bEnable /*= TRUE*/)
{
	GetDlgItem(IDC_EMS_DOMAIN)->EnableWindow(bEnable);
	GetDlgItem(IDC_EMS_DIRECTORY)->EnableWindow(bEnable);
	GetDlgItem(IDC_EMS_DROPDIRBTN)->EnableWindow(bEnable);
	GetDlgItem(IDC_EMS_BADMAILDIR)->EnableWindow(bEnable);
	GetDlgItem(IDC_EMS_BADMAILBTN)->EnableWindow(bEnable);
	GetDlgItem(IDC_EMS_TARGETPATH)->EnableWindow(bEnable);
	GetDlgItem(IDC_EMS_TARGETPATH_BTN)->EnableWindow(bEnable);
	GetDlgItem(IDC_EMS_SERVERNAME)->EnableWindow(bEnable);
	GetDlgItem(IDC_EMS_PORTNO)->EnableWindow(bEnable);
	GetDlgItem(IDC_EMS_USERNAME)->EnableWindow(bEnable);
	GetDlgItem(IDC_EMS_PASSWORD)->EnableWindow(bEnable);
	GetDlgItem(IDC_EMS_FROMADDRESS)->EnableWindow(bEnable);
	GetDlgItem(IDC_EMS_TOADDRESS)->EnableWindow(bEnable);
	GetDlgItem(IDC_EMS_MSGBODY)->EnableWindow(bEnable);
	GetDlgItem(IDC_EMS_BOUNCETIME)->EnableWindow(bEnable);
}
void CLNServiceProp::OnBnClickedEmsDropdirbtn()
{
	GetDirectory(m_Directory);
	SetDlgItemText(IDC_EMS_DIRECTORY, m_Directory);
}

void CLNServiceProp::OnBnClickedEmsBadmailbtn()
{
	GetDirectory(m_strBadMailDir);
	SetDlgItemText(IDC_EMS_BADMAILDIR, m_strBadMailDir);
}

void CLNServiceProp::OnBnClickedEmsTargetpathBtn()
{
	GetDirectory(m_strTargetPath);
	SetDlgItemText(IDC_EMS_TARGETPATH, m_strTargetPath);
}

void CLNServiceProp::GetDirectory(CString &csPath)
{
	HRESULT hr			= S_OK;
	DWORD	dwFlags		= OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT;
	TCHAR	szFolder[MAX_PATH];
	TCHAR	szPath[MAX_PATH + MAX_PATH];
	
	BROWSEINFO		stBrowse = {0};
	LPITEMIDLIST	pItemIdList = NULL;

	//CoInitializeEx(NULL, COINIT_APARTMENTTHREADED);
	hr = CoInitialize(NULL);
	szFolder[0] = 0;
	szPath[0]	= 0;
	stBrowse.hwndOwner = m_hWnd;
	stBrowse.pszDisplayName = szFolder;
	stBrowse.ulFlags = BIF_USENEWUI  | BIF_EDITBOX;
	stBrowse.lpfn = NULL; // No Callback fn
	stBrowse.lParam = 0;

	pItemIdList = SHBrowseForFolder(&stBrowse);
	if (pItemIdList)
	{
		SHGetPathFromIDList(pItemIdList, szPath);   // Make sure it is a path
		csPath = szPath;
		// Need to free this memory using IMalloc::Free
		//Free(pItemIdList);
	}
	
	CoUninitialize();
}

void CLNServiceProp::OnBnClickedCheckSendfileAgent()
{
	EnableSendAndFileCtrls(((CButton*)GetDlgItem(IDC_CHECK_SENDFILE_AGENT))->GetCheck() != 0);
}
