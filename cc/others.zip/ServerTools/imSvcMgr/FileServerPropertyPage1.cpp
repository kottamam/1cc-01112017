// FileServerPropertyPage1.cpp : implementation file
//

#include "stdafx.h"

#include "resource.h"
#include "imSvcMgr.h"
#include "FileServerPropertySheet.h"
#include "FileServerPropertyPage1.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(FileServerPropertyPage, CPropertyPage)
IMPLEMENT_DYNCREATE(FileServerPropertyPage2, CPropertyPage)


/////////////////////////////////////////////////////////////////////////////
// FileServerPropertyPage property page

FileServerPropertyPage::FileServerPropertyPage() : CPropertyPage(FileServerPropertyPage::IDD)
{
	//{{AFX_DATA_INIT(FileServerPropertyPage)
	m_Context = _T("");
	m_LogonIdEdit = _T("");
	m_PasswordEdit = _T("");
	//}}AFX_DATA_INIT
}

FileServerPropertyPage::~FileServerPropertyPage()
{
}

void FileServerPropertyPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(FileServerPropertyPage)
	DDX_Text(pDX, IDC_CONTEXT_EDIT, m_Context);
	DDX_Text(pDX, IDC_LOGONID_EDIT, m_LogonIdEdit);
	DDX_Text(pDX, IDC_PASSWORD_EDIT, m_PasswordEdit);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(FileServerPropertyPage, CPropertyPage)
	//{{AFX_MSG_MAP(FileServerPropertyPage)
	ON_EN_CHANGE(IDC_CONTEXT_EDIT, OnChangeContextEdit)
	ON_EN_CHANGE(IDC_LOGONID_EDIT, OnChangeLogonidEdit)
	ON_EN_CHANGE(IDC_PASSWORD_EDIT, OnChangePasswordEdit)
	ON_BN_CLICKED(IDC_BINDERY, OnBindery)
	ON_BN_CLICKED(IDC_NDS, OnNds)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// FileServerPropertyPage2 property page

FileServerPropertyPage2::FileServerPropertyPage2() : CPropertyPage(FileServerPropertyPage2::IDD)
{
	//{{AFX_DATA_INIT(FileServerPropertyPage2)
	m_NTLogonID = _T("");
	m_NTPassword = _T("");
	//}}AFX_DATA_INIT
}

FileServerPropertyPage2::~FileServerPropertyPage2()
{
}

void FileServerPropertyPage2::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(FileServerPropertyPage2)
	DDX_Text(pDX, IDC_NT_LOGONID, m_NTLogonID);
	DDX_Text(pDX, IDC_NT_PASSWORD, m_NTPassword);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(FileServerPropertyPage2, CPropertyPage)
	//{{AFX_MSG_MAP(FileServerPropertyPage2)
	ON_EN_CHANGE(IDC_NT_LOGONID, OnChangeNtLogonid)
	ON_EN_CHANGE(IDC_NT_PASSWORD, OnChangeNtPassword)
	ON_BN_CLICKED(IDC_NT_SERVICE_LOGON_ONLY, OnNtServiceLogonOnly)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BOOL FileServerPropertyPage::OnInitDialog() 
{
	FileServerPropSheet* aParent = (FileServerPropSheet*)GetParent();
	aParent->m_pFileServerConfiguration->LoadFromRegistry();

	m_Context = aParent->m_pFileServerConfiguration->m_strNwUserContext.Get().c_str();
	m_LogonIdEdit = aParent->m_pFileServerConfiguration->m_strNwLogonID.Get().c_str();
	m_PasswordEdit = aParent->m_pFileServerConfiguration->m_strNwPassword.Get().c_str();

	if (aParent->m_pFileServerConfiguration->m_bIsBinderyConnection.Get() == true)
	{
		((CButton*)GetDlgItem(IDC_NDS))->SetCheck(0);
		((CButton*)GetDlgItem(IDC_BINDERY))->SetCheck(1);
		GetDlgItem(IDC_CONTEXT_EDIT)->EnableWindow(0);
		GetDlgItem(IDC_LOGONID_EDIT)->SetFocus();
	}
	else
	{
		((CButton*)GetDlgItem(IDC_BINDERY))->SetCheck(0);
		((CButton*)GetDlgItem(IDC_NDS))->SetCheck(1);
		GetDlgItem(IDC_CONTEXT_EDIT)->EnableWindow();
		GetDlgItem(IDC_CONTEXT_EDIT)->SetFocus();
	}

//***	((CButton*)GetDlgItem(IDC_FILE_LEVEL_SEC))->SetCheck(aParent->fsinfo->bApplyFileSecurity);

	// Allow OK button only after a change
	aParent->GetDlgItem(IDOK)->EnableWindow(0);
	SetDefID(IDCANCEL);
	CPropertyPage::OnInitDialog();
	return 0;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL FileServerPropertyPage2::OnInitDialog() 
{
	FileServerPropSheet* aParent = (FileServerPropSheet*)GetParent();
	aParent->m_pFileServerConfiguration->LoadFromRegistry();
	m_NTLogonID = aParent->m_pFileServerConfiguration->m_strNtLogonID.Get().c_str();
	m_NTPassword = aParent->m_pFileServerConfiguration->m_strNtPassword.Get().c_str();
	
	((CButton*)GetDlgItem(IDC_NT_SERVICE_LOGON_ONLY))->SetCheck(aParent->m_pFileServerConfiguration->m_bUseServiceAccount.Get());

	if (aParent->m_pFileServerConfiguration->m_bUseServiceAccount.Get() == true)
	{
		GetDlgItem(IDC_NT_LOGONID)->EnableWindow(0);
		GetDlgItem(IDC_NT_PASSWORD)->EnableWindow(0);
	}
	else
	{
		GetDlgItem(IDC_NT_LOGONID)->EnableWindow();
		GetDlgItem(IDC_NT_PASSWORD)->EnableWindow();
	}
	
	CPropertyPage::OnInitDialog();
	return 0;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void FileServerPropertyPage::Changed()
{
	FileServerPropSheet* aParent = (FileServerPropSheet*)GetParent();
	aParent->GetDlgItem(IDOK)->EnableWindow();
	SetDefID(IDOK);

/*
	if (aParent->fsinfo->bUseServiceAccount == true)
	{
		GetDlgItem(IDC_LOGONID_EDIT)->EnableWindow();
		GetDlgItem(IDC_PASSWORD_EDIT)->EnableWindow();
	}
	else
	{
		GetDlgItem(IDC_LOGONID_EDIT)->EnableWindow(0);
		GetDlgItem(IDC_PASSWORD_EDIT)->EnableWindow(0);
	}
*/
	if (((CButton*)GetDlgItem(IDC_NDS))->GetCheck() == 1)
	{
		GetDlgItem(IDC_CONTEXT_EDIT)->EnableWindow();
	}
	else
	{
		GetDlgItem(IDC_CONTEXT_EDIT)->EnableWindow(0);
	}
}


void FileServerPropertyPage::OnChangeContextEdit() 
{
	Changed();	
}

void FileServerPropertyPage::OnChangeLogonidEdit() 
{
	Changed();	
}

void FileServerPropertyPage::OnChangePasswordEdit() 
{
	Changed();	
}


void FileServerPropertyPage::OnBindery() 
{
	Changed();	
}

void FileServerPropertyPage::OnNds() 
{
	Changed();	
}

void FileServerPropertyPage2::Changed()
{
	FileServerPropSheet* aParent = (FileServerPropSheet*)GetParent();
	aParent->GetDlgItem(IDOK)->EnableWindow();
	SetDefID(IDOK);

	if (((CButton*)GetDlgItem(IDC_NT_SERVICE_LOGON_ONLY))->GetCheck() == 1)
	{
		GetDlgItem(IDC_NT_LOGONID)->EnableWindow(0);
		GetDlgItem(IDC_NT_PASSWORD)->EnableWindow(0);
	}
	else
	{
		GetDlgItem(IDC_NT_LOGONID)->EnableWindow();
		GetDlgItem(IDC_NT_PASSWORD)->EnableWindow();
	}
}

void FileServerPropertyPage2::OnChangeNtLogonid() 
{
	Changed();	
}

void FileServerPropertyPage2::OnChangeNtPassword() 
{
	Changed();	
}

void FileServerPropertyPage2::OnNtServiceLogonOnly() 
{
	Changed();	
}

void FileServerPropertyPage::OnOK() 
{
	GetDlgItem(IDC_CONTEXT_EDIT)->GetWindowText(m_Context);
	GetDlgItem(IDC_LOGONID_EDIT)->GetWindowText(m_LogonIdEdit);
	GetDlgItem(IDC_PASSWORD_EDIT)->GetWindowText(m_PasswordEdit);

	FileServerPropSheet* aParent = (FileServerPropSheet*)GetParent();
	aParent->m_pFileServerConfiguration->m_bIsBinderyConnection.Set((((CButton*)GetDlgItem(IDC_BINDERY))->GetCheck() == 1));
	aParent->m_pFileServerConfiguration->m_strNwUserContext.Set(m_Context);
	aParent->m_pFileServerConfiguration->m_strNwLogonID.Set(m_LogonIdEdit);
	aParent->m_pFileServerConfiguration->m_strNwPassword.Set(m_PasswordEdit);

/***
	if (((CButton*)GetDlgItem(IDC_FILE_LEVEL_SEC))->GetCheck() == 1)
		aParent->fsinfo->bApplyFileSecurity = true;
	else
		aParent->fsinfo->bApplyFileSecurity = false;
***/
	try
	{
		aParent->m_pFileServerConfiguration->StoreInRegistry();
	}
	catch(IM::Exception &)
	{
	}

	CPropertyPage::OnOK();
}

void FileServerPropertyPage2::OnOK() 
{
	GetDlgItem(IDC_NT_LOGONID)->GetWindowText(m_NTLogonID);
	GetDlgItem(IDC_NT_PASSWORD)->GetWindowText(m_NTPassword);
	FileServerPropSheet* aParent = (FileServerPropSheet*)GetParent();

	if (((CButton*)GetDlgItem(IDC_NT_SERVICE_LOGON_ONLY))->GetCheck() == 1)
		aParent->m_pFileServerConfiguration->m_bUseServiceAccount.Set(true);
	else
		aParent->m_pFileServerConfiguration->m_bUseServiceAccount.Set(false);

	aParent->m_pFileServerConfiguration->m_strNtLogonID.Set(m_NTLogonID);
	aParent->m_pFileServerConfiguration->m_strNtPassword.Set(m_NTPassword);

	try
	{
		aParent->m_pFileServerConfiguration->StoreInRegistry();
	}
	catch (IM::Exception &)
	{
	}
	CPropertyPage::OnOK();
}
