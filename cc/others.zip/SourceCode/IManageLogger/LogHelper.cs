#region references
using System;
using System.Reflection;
#endregion

namespace IManageLogger
{
    #region XML::DOC
    /// <summary>
    /// Log Helper contains methods to publish exceptions
    /// </summary>
    #endregion
    public sealed class LogHelper
    {
        #region private data

        private static log4net.ILog log;
        private static string versionDetails = string.Empty;

        #endregion

        private LogHelper() { }

        /// <summary>
        /// Sets static data that is included in logging details created by <see cref="PublishException" />.
        /// </summary>
        /// <param name="versionDetails"></param>
        public static void SetExceptionLoggingDetails(string versionDetails)
        {
            LogHelper.versionDetails = versionDetails;
        }

        #region public methods

        /// <summary>
        /// Log the message
        /// </summary>
        /// <param name="declaringtype"></param>
        /// <param name="message"></param>
        public static void Log(System.Type declaringtype, object message)
        {

            log = log4net.LogManager.GetLogger(declaringtype);
            lock (log)
            {
                log.Info(message);

            }
        }

        /// <summary>
        /// Logs a message using the Debug method.
        /// </summary>
        /// <param name="declaringType"></param>
        /// <param name="message"></param>
        public static void Debug(System.Type declaringType, string message)
        {
            log = log4net.LogManager.GetLogger(declaringType);
            lock (log)
            {
                log.Debug(message);


            }
        }

        /// <summary>
        /// Logs a message using the Error method.
        /// </summary>
        /// <param name="declaringType"></param>
        /// <param name="message"></param>
        public static void Error(System.Type declaringType, string message)
        {
            log = log4net.LogManager.GetLogger(declaringType);
            lock (log)
            {
                log.Error(message);
            }
        }

        #region XML::DOC
        /// <summary>
        /// Publishes the exception based on the configuration file settings (app.config)
        /// takes a declaring type, type of exception
        /// </summary>
        /// <param name="declaringtype">Declaring Type which is throwing the exception</param>
        /// <param name="logType">The type of exception</param>
        /// <param name="exception">exception object</param>
        /// <param name="message">additional message</param>
        #endregion
        public static void PublishException(System.Type declaringtype, ExceptionType logType, System.Exception exception, object message)
        {
            log = log4net.LogManager.GetLogger(declaringtype);
            string exceptionString = string.Empty;
            if (message != null)
            {
                exceptionString = message.ToString();
            }
            string exceptionStack = string.Empty;
            if (null != exception)
            {
                exceptionString = exception.ToString();
                exceptionStack = ExceptionHelper.GetCompleteStackTrace(exception);
            }

            lock (log)
            {
                switch (logType)
                {
                    case ExceptionType.Fatal:
                        log.Fatal(string.Format("{0}{1}{2}{1}Stack trace:{1}{3}", versionDetails, Environment.NewLine, exceptionString, exceptionStack));
                        break;
                    case ExceptionType.Errors:
                        log.Error(string.Format("{0}{1}{2}{1}Stack trace:{1}{3}", versionDetails, Environment.NewLine, exceptionString, exceptionStack));
                        break;
                    case ExceptionType.Warnings:
                        log.Warn(string.Format("{0}{1}{2}{1}Stack trace:{1}{3}", versionDetails, Environment.NewLine, exceptionString, exceptionStack));
                        break;
                    case ExceptionType.Information:
                        log.Info(string.Format("{0}{1}{2}{1}Stack trace:{1}{3}", versionDetails, Environment.NewLine, exceptionString, exceptionStack));
                        break;
                }
            }
        }

        /// <summary>
        /// This function is to log one or more entities(objects where we want values from inside)
        /// You can pass a message to it as well
        /// </summary>
        /// <param name="declaringtype"></param>
        /// <param name="logType"></param>
        /// <param name="message"></param>
        /// <param name="objValues"></param>
        public static void LogEntities(System.Type declaringtype, ExceptionType logType, string message, object[] objValues)
        {
            try
            {
                string strFullLogMessage = string.Empty;
                if (message != null && message.Length > 0)
                    strFullLogMessage += message;


                if (objValues != null)
                {
                    foreach (object objValue in objValues)
                    {
                        strFullLogMessage += " ";
                        Type t = objValue.GetType();
                        System.Reflection.PropertyInfo[] propertyInfos = t.GetProperties();
                        strFullLogMessage += t.Name;
                        strFullLogMessage += "=";
                        foreach (System.Reflection.PropertyInfo info in propertyInfos)
                        {

                            PropertyInfo pInfo = t.GetProperty(info.Name);
                            if (pInfo != null)
                            {
                                object val = null;
                                try
                                {
                                    val = pInfo.GetValue(objValue, null);
                                }
                                catch (Exception ex)
                                {

                                    continue;
                                }

                                string strLogEntry = info.Name + ":";
                                string strV = string.Empty;
                                if (val == null)
                                    strV = "null";
                                else
                                    strV = val.ToString();
                                strLogEntry += strV;
                                strFullLogMessage += strLogEntry;
                                strFullLogMessage += ",";
                            }
                        }
                        char[] chVal = { ',' };
                        strFullLogMessage = strFullLogMessage.TrimEnd(chVal);
                    }

                }
                lock (log)
                {
                    switch (logType)
                    {
                        case ExceptionType.Fatal:
                            log.Fatal(strFullLogMessage);
                            break;
                        case ExceptionType.Errors:
                            log.Error(strFullLogMessage);
                            break;
                        case ExceptionType.Warnings:
                            log.Warn(strFullLogMessage);
                            break;
                        case ExceptionType.Information:
                            log.Info(strFullLogMessage);
                            break;
                    }
                }
            }
            catch (Exception ex)
            {

            }

        }

        /// <summary>
        /// This function is to log char arrays without entities in it.
        /// You can also pass a message to it
        /// </summary>
        /// <param name="declaringtype"></param>
        /// <param name="logType"></param>
        /// <param name="message"></param>
        /// <param name="charValues"></param>
        public static void LogCharArray(System.Type declaringtype, ExceptionType logType, string message, char[] charValues)
        {
            try
            {
                string strFullLogMessage = string.Empty;
                if (message != null && message.Length > 0)
                    strFullLogMessage += message;


                if (charValues != null)
                {
                    foreach (object charValue in charValues)
                    {
                        strFullLogMessage += charValue;
                        strFullLogMessage += ",";
                    }

                    char[] chVal = { ',' };
                    strFullLogMessage = strFullLogMessage.TrimEnd(chVal);


                }
                lock (log)
                {
                    switch (logType)
                    {
                        case ExceptionType.Fatal:
                            log.Fatal(strFullLogMessage);
                            break;
                        case ExceptionType.Errors:
                            log.Error(strFullLogMessage);
                            break;
                        case ExceptionType.Warnings:
                            log.Warn(strFullLogMessage);
                            break;
                        case ExceptionType.Information:
                            log.Info(strFullLogMessage);
                            break;
                    }
                }
            }
            catch (Exception ex)
            {

            }

        }

        /// <summary>
        /// This function is to log functions with string arrays as parameters without entitie being present.
        /// You can give a message to it as well.
        /// </summary>
        /// <param name="declaringtype"></param>
        /// <param name="logType"></param>
        /// <param name="message"></param>
        /// <param name="stringValues"></param>
        public static void LogStringArray(System.Type declaringtype, ExceptionType logType, string message, string[] stringValues)
        {
            try
            {
                string strFullLogMessage = string.Empty;
                if (message != null && message.Length > 0)
                    strFullLogMessage += message;


                if (stringValues != null)
                {

                    foreach (object strValue in stringValues)
                    {

                        strFullLogMessage += strValue;
                        strFullLogMessage += ",";

                    }

                    char[] chVal = { ',' };
                    strFullLogMessage = strFullLogMessage.TrimEnd(chVal);


                }
                lock (log)
                {
                    switch (logType)
                    {
                        case ExceptionType.Fatal:
                            log.Fatal(strFullLogMessage);
                            break;
                        case ExceptionType.Errors:
                            log.Error(strFullLogMessage);
                            break;
                        case ExceptionType.Warnings:
                            log.Warn(strFullLogMessage);
                            break;
                        case ExceptionType.Information:
                            log.Info(strFullLogMessage);
                            break;
                    }
                }
            }
            catch (Exception ex)
            {

            }

        }

        /// <summary>
        /// This function is to log  full parameter list of a function given at once as a string array of values
        /// You can give a message to it as well.Adds the parameter name to the log as well.
        /// String Array needs to be in same order as function parameter order
        /// </summary>
        /// <param name="declaringtype"></param>
        /// <param name="logType"></param>
        /// <param name="message"></param>
        /// <param name="stringValues"></param>
        public static void LogMultipleParameters(System.Type declaringtype, ExceptionType logType, string message, string[] strParams)
        {
            try
            {
                string strFullLogMessage = string.Empty;
                if (message != null && message.Length > 0)
                {
                    strFullLogMessage += message;
                    strFullLogMessage += " ";
                }

                System.Diagnostics.StackTrace st = new System.Diagnostics.StackTrace();
                MethodBase basemethod = st.GetFrame(1).GetMethod();
                ParameterInfo[] pmInfos = basemethod.GetParameters();
                if (strParams != null)
                {

                    for (int i = 0; i < strParams.Length; i++)
                    {
                        strFullLogMessage += pmInfos[i].Name;
                        strFullLogMessage += ":";
                        strFullLogMessage += strParams[i];
                        strFullLogMessage += ",";

                    }

                    char[] chVal = { ',' };
                    strFullLogMessage = strFullLogMessage.TrimEnd(chVal);


                }
                lock (log)
                {
                    switch (logType)
                    {
                        case ExceptionType.Fatal:
                            log.Fatal(strFullLogMessage);
                            break;
                        case ExceptionType.Errors:
                            log.Error(strFullLogMessage);
                            break;
                        case ExceptionType.Warnings:
                            log.Warn(strFullLogMessage);
                            break;
                        case ExceptionType.Information:
                            log.Info(strFullLogMessage);
                            break;
                    }
                }
            }
            catch (Exception ex)
            {

            }

        }
        /// <summary>
        /// This function is to log  functions with parameters of single string array and multiple entities 
        /// You can give a message to it as well.Logs the string array first
        /// So add the name of parameter to message at the end so that it looks neat
        /// </summary>
        /// <param name="declaringtype"></param>
        /// <param name="logType"></param>
        /// <param name="message"></param>
        /// <param name="stringValues"></param>
        public static void LogEntitiesStringArray(System.Type declaringtype, ExceptionType logType, string message, object[] objValues, string[] stringValues)
        {
            try
            {
                string strFullLogMessage = string.Empty;
                if (message != null && message.Length > 0)
                    strFullLogMessage += message;
                if (stringValues != null)
                {
                    foreach (object strValue in stringValues)
                    {
                        strFullLogMessage += strValue;
                        strFullLogMessage += ",";
                    }

                    char[] chVal = { ',' };
                    strFullLogMessage = strFullLogMessage.TrimEnd(chVal);
                    strFullLogMessage += " ";

                }
                if (objValues != null)
                {
                    foreach (object objValue in objValues)
                    {
                        strFullLogMessage += " ";
                        Type t = objValue.GetType();
                        System.Reflection.PropertyInfo[] propertyInfos = t.GetProperties();
                        strFullLogMessage += t.Name;
                        strFullLogMessage += "=";
                        foreach (System.Reflection.PropertyInfo info in propertyInfos)
                        {

                            PropertyInfo pInfo = t.GetProperty(info.Name);
                            if (pInfo != null)
                            {
                                object val = null;
                                try
                                {
                                    val = pInfo.GetValue(objValue, null);
                                }
                                catch (Exception ex)
                                {
                                    //Can add publish exception but unneceesary logging
                                    continue;
                                }

                                string strLogEntry = info.Name + ":";
                                string strV = string.Empty;
                                if (val == null)
                                    strV = "null";
                                else
                                    strV = val.ToString();
                                strLogEntry += strV;
                                strFullLogMessage += strLogEntry;
                                strFullLogMessage += ",";
                            }
                        }
                        char[] chVal = { ',' };
                        strFullLogMessage = strFullLogMessage.TrimEnd(chVal);
                    }

                }


                lock (log)
                {
                    switch (logType)
                    {
                        case ExceptionType.Fatal:
                            log.Fatal(strFullLogMessage);
                            break;
                        case ExceptionType.Errors:
                            log.Error(strFullLogMessage);
                            break;
                        case ExceptionType.Warnings:
                            log.Warn(strFullLogMessage);
                            break;
                        case ExceptionType.Information:
                            log.Info(strFullLogMessage);
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                //  LogHelper.PublishException(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, ExceptionType.Errors, ex, "");
            }

        }

        #endregion


    }



    #region XML::DOC
    /// <summary>
    /// Exception Types
    /// </summary>
    #endregion
    public enum ExceptionType : int
    {
        /// <summary>Fatal</summary>
        Fatal = 1,
        /// <summary>Errors</summary>
        Errors,
        /// <summary>Warnings</summary>
        Warnings,
        /// <summary>Information</summary>
        Information,
    }
}
