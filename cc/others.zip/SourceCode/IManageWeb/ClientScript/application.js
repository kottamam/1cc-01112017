/* File Input */
$(document).on('change', '.btn-file :file', function() {
	  var input = $(this),
		  numFiles = input.get(0).files ? input.get(0).files.length : 1,
		  label = input.val().replace(/\\/g, '/').replace(/.*\//, '');
	  input.trigger('fileselect', [numFiles, label]);
	});
	$(document).ready( function() {
		$('.btn-file :file').on('fileselect', function(event, numFiles, label) {
			var input = $(this).parents('.input-group').find(':text'),
				log = numFiles > 1 ? numFiles + ' files selected' : label;
			if( input.length ) {
				input.val(log);
			} else {
				if( log ) alert(log);
			}
		});
	});
/* ToolTip */	
$(function () {
	  $('[data-toggle="tooltip"]').tooltip()
})


function refreshFabIcons() {
    var elem = document.querySelector('md-fab-speed-dial');
    if (!elem) return;
	
    var items = elem.querySelectorAll('.md-fab-action-item')

    var itemsTemp = [];
    angular.forEach(items, function (item, index) {
        if (item.getElementsByTagName('*').length > 0) {
            itemsTemp.push(item);
        }
    });

    items = itemsTemp;

    var triggerElement = elem.querySelector('md-fab-trigger');


    var variablesElement = elem.querySelector('.md-css-variables');

    // Setup JS variables based on our CSS variables
    var startZIndex = parseInt(window.getComputedStyle(variablesElement).zIndex);


    angular.forEach(items, function (item, index) {
        var styles = item.style;

        styles.transform = styles.webkitTransform = '';
        styles.transitionDelay = '';
        styles.opacity = 1;

        // Make the items closest to the trigger have the highest z-index
        styles.zIndex = (items.length - index) + startZIndex;
    });
    triggerElement.style.zIndex = (items.length + 1) + startZIndex;

    angular.forEach(items, function (item, index) {
        var newPosition, axis;
        var styles = item.style;

        var triggerItemHeightOffset = (triggerElement.clientHeight - item.clientHeight) / 2;
        var triggerItemWidthOffset = (triggerElement.clientWidth - item.clientWidth) / 2;


        newPosition = -(item.scrollHeight * (index + 1) + triggerItemHeightOffset);
        axis = 'Y';

        var newTranslate = 'translate' + axis + '(' + newPosition + 'px)';

        styles.transform = styles.webkitTransform = newTranslate;
    });

    $('td').filter(function () {

        if ($(this).text().trim().length == 0) {

            $(this).html('&nbsp;');
        }

    });

}
	

 
/* Begin Footer */
function Footer(){
	document.write("<footer> <div class='container'> <div class='row'> <div class='col-sm-12 col-md-12 col-lg-12'> <div class='dotline-top'> <div class='footer-logo'><img src='images/footer-logo.jpg'></div><div class='footer-copy'> <p>Copyright © 2012 <span class='default-c'>GroupRevMax</span> | All rights reserved</p></div><div class='clearfix'></div></div></div></div></div></footer>"
	);
	}	
$(document).ready(function()
	{
		if($.isFunction($.fn.multiSelect))
		{
			$(".multi-select").multiSelect();
		}

	

		
		$(document).click(function (e) {
		    if (!$(e.target).parents('div.showp')[0]) {
		        $('div.showp').toggleClass('showp hidep');
		    }
		    if ($(e.target).attr('id') != 'btnShowMetadataMenuList' && !$(e.target).parents('#btnShowMetadataMenuList')[0]) {
		        $('#metadataCustomMenu').removeClass('open');
		    }
		   
		});
		
			// Form Wizard
		if($.isFunction($.fn.bootstrapWizard))
		{
			$(".form-wizard").each(function(i, el)
			{
				var $this = $(el),
					$tabs = $this.find('> .tabs > li'),
					$progress = $this.find(".progress-indicator"),
					_index = $this.find('> ul > li.active').index();

				// Validation
				var checkFormWizardValidaion = function(tab, navigation, index)
					{
			  			if($this.hasClass('validate'))
			  			{
							var $valid = $this.valid();

							if( ! $valid)
							{
								$this.data('validator').focusInvalid();
								return false;
							}
						}

				  		return true;
					};

				// Setup Progress
				if(_index > 0)
				{
					$progress.css({width: _index/$tabs.length * 100 + '%'});
					$tabs.removeClass('completed').slice(0, _index).addClass('completed');
				}

				$this.bootstrapWizard({
					tabClass: "",
			  		onTabShow: function($tab, $navigation, index)
			  		{
			  			var pct = $tabs.eq(index).position().left / $tabs.parent().width() * 100;

			  			$tabs.removeClass('completed').slice(0, index).addClass('completed');
			  			$progress.css({width: pct + '%'});
			  		},

			  		onNext: checkFormWizardValidaion,
			  		onTabClick: checkFormWizardValidaion
			  	});

			  	$this.data('bootstrapWizard').show( _index );

			  	$this.find('.pager a').on('click', function(ev)
			  	{
				  	ev.preventDefault();
			  	});
			});
		}
	}
	);


