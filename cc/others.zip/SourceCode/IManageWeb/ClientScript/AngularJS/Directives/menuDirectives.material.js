﻿
(function () {
    'use strict';
angular.module('common.directives')
  .directive('navigationToggle', ['$timeout', function ($timeout) {
      return {
          scope: {
              section: '='
          },
          templateUrl: appBaseURL + 'Views/NgTemplates/DirectiveTemplates/Navigation-toggle.html',
          link: function (scope, element) {
              var controller = element.parent().controller();

              scope.isOpen = function () {
                  return controller.isOpen(scope.section);
              };
              scope.toggle = function () {
                  controller.toggleOpen(scope.section);
              };

              var parentNode = element[0].parentNode.parentNode.parentNode;
              if (parentNode.classList.contains('parent-list-item')) {
                  var heading = parentNode.querySelector('h2');
                  element[0].firstChild.setAttribute('aria-describedby', heading.id);
              }

              element.on('click', function (event) {
                  scope.$parent.vm.isSideNavOpen = true;
              });
          }
      };
  }]);
})();

(function () {
    'use strict';

    angular.module('common.directives')
      .directive('navigationMenu', function () {
          return {
              scope: {
                  section: '='
              },
              templateUrl: appBaseURL + 'Views/NgTemplates/DirectiveTemplates/Navigation-menu.html',
              link: function ($scope, $element) {
                  var controller = $element.parent().controller();

                  $scope.isActive = function () {
                      return controller.isCurrentSection($scope.section);
                  };

                  $scope.focusSection = function () {
                      // set flag to be used later when
                      // $locationChangeSuccess calls openPage()
                      controller.autoFocusContent = true;
                  };
                  $element.on('click', function (event) {
                      $scope.$parent.$parent.$parent.vm.isSideNavOpen = true;
                      $element.parent().scope().$apply(function () {
                          controller.headerNavigationMenu = $scope.section.childMenus;
                          controller.setActiveSection($scope.section);
                          if ($($element).children('.md-button').hasClass('big-icon')) {
                              controller.toggleOpen(null);
                          }
                      });
                      event.stopPropagation();
                });
              }
          };
      })
})();

(function () {
    'use strict';

    angular.module('common.directives')
      .directive('navigationToggleMenu', ['$timeout', '$filter', function ($timeout, $filter) {
          return {
              scope: {
                  section: '='
              },
              templateUrl: appBaseURL + 'Views/NgTemplates/DirectiveTemplates/Navigation-toggle-menu.html',
              link: function (scope, element) {
                  var controller = element.parent().controller();

                  scope.isOpen = function () {
                      return controller.isOpen(scope.section);
                  };
                  scope.toggle = function () {
                      controller.toggleOpen(scope.section);
                  };

                  scope.isActive = function () {
                      return controller.isCurrentSection(scope.section);
                  };

                  var parentNode = element[0].parentNode.parentNode.parentNode;
                  if (parentNode.classList.contains('parent-list-item')) {
                      var heading = parentNode.querySelector('h2');
                      element[0].firstChild.setAttribute('aria-describedby', heading.id);
                  }

                  element.on('click', function () {
                      scope.$parent.vm.isSideNavOpen = true;
                      element.parent().scope().$apply(function () {
                          var tabMenus = $filter('filter')(scope.section.childMenus, { AppsType: 'tab' });
                          controller.headerNavigationMenu = tabMenus;
                          controller.setActiveSection(scope.section);
                      });
                  });
              }
          };
      }]);
})();

(function () {
    'use strict';

    angular.module('common.directives')
      .directive('navigationLink', function () {
          return {
              scope: {
                  section: '='
              },
              templateUrl: appBaseURL + 'Views/NgTemplates/DirectiveTemplates/Navigation-link.html',
              link: function ($scope, $element) {
                  var controller = $element.parent().controller();

                  $scope.isActive = function () {
                      return controller.isCurrentSection($scope.section);
                  };

                  $scope.focusSection = function () {
                      // set flag to be used later when
                      // $locationChangeSuccess calls openPage()
                      controller.autoFocusContent = true;
                  };
                  $element.on('click', function (event) {
                      $scope.$parent.vm.isSideNavOpen = true;
                      $element.parent().scope().$apply(function () {
                          $scope.$parent.vm.selectedApp.CurrentTab = $scope.section.AppsName;
                          controller.headerNavigationMenu = $scope.section.childMenus;
                          controller.setActiveSection($scope.section);
                          if ($($element).children('.md-button').hasClass('big-icon')) {
                              controller.toggleOpen(null);
                          }
                      });
                      event.stopPropagation();
                  });
              }
          };
      })
})();
