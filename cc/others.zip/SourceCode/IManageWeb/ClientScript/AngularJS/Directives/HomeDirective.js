﻿app.directive('appsIcon', function () {
    return {
        restrict: 'E',
        scope: {
            appInfo: '=info'
        },
        templateUrl: function (elem, attr) {
            return NgTemplatesUrl;
        }
    };
});

app.directive('whenScrolled', function () {
    return {
        restrict: "A",
        link: function (scope, element, attr) {
            $(element).bind('scroll', function () {
                var scrollHeight = (($(this).scrollTop() + $(this).innerHeight()) / $(this)[0].scrollHeight) * 100.0;
                if (scrollHeight >= 75) {
                    scope.ScrollCounter = true;
                    scope.$apply(attr.whenScrolled);
                }
            })
        }
    }
});

app.directive("onDatatableScroll", function ($timeout) {
    return {
        restrict: "A",
        link: function (scope, element, attrs) {
            scope.$watch(attrs.onDatatableRenderComplete, function () {
                $timeout(function () {
                    $('.dataTables_scrollBody').on('scroll', function () {
                        if ($(this).scrollTop() > scope.tableSettings.scrollTop) {
                            scope.tableSettings.scrollTop = $(this).scrollTop();
                            scope.tableSettings.scrollBarTop = $('.dataTables_scroll div.slimScrollDiv div.slimScrollBar').position().top + 'px';
                        }
                        var scrollHeight = (($(this).scrollTop() + $(this).innerHeight()) / $(this)[0].scrollHeight) * 100.0;
                        if (scrollHeight >= 75) {
                            scope.$apply(attrs.onDatatableScroll);
                        }
                    });
                });
            });
        }
    }
});

app.directive("onSelectPickerRenderComplete", function ($timeout) {
    return {
        restrict: "A",
        require: '?ngModel',
        link: function (scope, element, attrs, ngModel) {
            scope.$watch(attrs.onSelectPickerRenderComplete, function () {
                $timeout(function () {
                    $('#cbo-db-selection').selectpicker('refresh');
                    $('[data-id="cbo-db-selection"]').siblings('div').find('ul > li:has("span.text:empty")').remove();
                });
            });
        }
    }
});

app.directive("onDatatableRenderComplete", function ($timeout) {
    return {
        restrict: "A",
        link: function (scope, element, attrs) {
            scope.$watch(attrs.onDatatableRenderComplete, function () {
                $timeout(function () {
                    var modifierTop = 0;
                    //$('#idDataTable').dataTable().resize();
                    //$('#idDataTableTypeappSetup').dataTable().resize();
                    //$('#idDataTableType').dataTable().resize();
                    //$('tbody tr').hover(function () {
                    //    scope.appsVar.selectedRecordId = $(this).find("td:nth-child(1)").text().trim();
                    //    modifierTop = $(this).find("td:nth-child(1)").position().top + 115;
                    //    var right = $(this).find("td:nth-child(2)").position().left - 25;
                    //    if (attrs.rowModifierId) {
                    //        $('#' + attrs.rowModifierId).removeClass('hide');
                    //        $('#' + attrs.rowModifierId).show();
                    //        $('#' + attrs.rowModifierId).css('position', 'absolute');
                    //        $('#' + attrs.rowModifierId).css('top', modifierTop);
                    //        $('#' + attrs.rowModifierId).css('left', right);
                    //    } else {
                    //        $('#row_modifier').show();
                    //        $('#row_modifier').css('top', modifierTop);
                    //        $('#row_modifier').css('left', right);
                    //    }
                    //}, function () {
                    //    if (attrs.rowModifierId) {
                    //        $('#' + attrs.rowModifierId).hide();
                    //        $('#' + attrs.rowModifierId).mouseenter(function () {
                    //            $('#' + attrs.rowModifierId).show();
                    //        }).mouseleave(function () {
                    //            $('#' + attrs.rowModifierId).hide();
                    //        });
                    //    } else {
                    //        $('#row_modifier').hide();
                    //        $('#row_modifier').mouseenter(function () {
                    //            $('#row_modifier').show();
                    //        }).mouseleave(function () {
                    //            $('#row_modifier').hide();
                    //        });
                    //    }
                    //});

                    //$('.dataTables_scrollBody').slimScroll({
                    //    height: '297px',
                    //    allowPageScroll: true,
                    //    wheelStep: 20,
                    //    alwaysVisible: true,
                    //    railVisible: true,
                    //    size: '8px'
                    //});
                    //$('.dataTables_scrollBody').scrollTop(scope.tableSettings.scrollTop);
                    //$('.dataTables_scroll div.slimScrollDiv div.slimScrollBar').css({ top: scope.tableSettings.scrollBarTop });
                });
            });
        }
    }
});

app.directive("onStaticTableRenderComplete", function ($timeout) {
    return {
        restrict: "A",
        link: function (scope, element, attrs) {
            scope.$watch(attrs.onStaticTableRenderComplete, function () {
                $timeout(function () {
                    var modifierTop = 0;
                    element.hover(function () {
                        scope.appsVar.selectedRecordId = $(this).find("td:nth-child(1)").text().trim();
                        modifierTop = $(this).offset().top - ($(this).height() / 2);
                        var right = $(this).find("td:nth-child(2)").position().left - 15;
                        if (attrs.rowModifierId) {
                            $('#' + attrs.rowModifierId).removeClass('hide');
                            $('#' + attrs.rowModifierId).show();
                            $('#' + attrs.rowModifierId).css('position', 'absolute');
                            $('#' + attrs.rowModifierId).css('top', modifierTop);
                            $('#' + attrs.rowModifierId).css('left', right);
                        }
                    }, function () {
                        if (attrs.rowModifierId) {
                            $('#' + attrs.rowModifierId).hide();
                            $('#' + attrs.rowModifierId).mouseenter(function () {
                                $('#' + attrs.rowModifierId).show();
                            }).mouseleave(function () {
                                $('#' + attrs.rowModifierId).hide();
                            });
                        }
                    });
                });
            });
        }
    }
});

app.directive("onDbListRenderComplete", function ($timeout) {
    return {
        restrict: "A",
        require: '?ngModel',
        link: function (scope, element, attrs, ngModel) {
            scope.$watch(attrs.onDbListRenderComplete, function () {
                $timeout(function () {
                    element.selectpicker('refresh');
                    element.click();
                    element.siblings('div').find('ul > li:has("span.text:empty")').remove();
                });
            });
        }
    }
});

app.directive('selectPickerRender', function ($timeout) {
    return {
        restrict: 'C',
        link: function ($scope, elem, attrs) {
            elem.ready(function () {
                $timeout(function () {
                    elem.selectpicker();
                    elem.selectpicker('refresh');
                    elem.siblings('div').find('ul > li:has("span.text:empty")').remove();
                    elem.remove('click');
                    elem.on('click', function () {
                        elem.selectpicker('refresh');
                        elem.siblings('div').find('ul > li:has("span.text:empty")').remove();
                    });
                });
            })
        }
    }
});

app.directive('onEditClick', function () {
    return {
        restrict: 'A',
        link: function ($scope, elem, attrs) {
            elem.ready(function () {
                elem.unbind('click');
                elem.click(function (eve, cntrl) {
                    openEditForm();
                });

            })
        }
    }
});

app.directive('metadataSelectPicker', ['ManagementService', '$timeout', '$location', '$rootScope', '$filter', function (ManagementService, $timeout, $location, $rootScope, $filter) {
    return {
        restrict: 'E',
        replace: true,
        templateUrl: 'Views/NgTemplates/DirectiveTemplates/MetaDataSelectPicker.html',
        /*controller: function($scope){
            $scope.$watch(function () { return $scope.appsVar.CaptionsList }, function (newValue, oldValue) {
                $scope.metaDataList = $filter('filter')($scope.appsVar.CaptionsList, { isMetaItem: true });
                $scope.selectedMetaData = 'CUSTOM1';
                $timeout(function () {
                    $('#metaDataSelectPicker>.sel_allcustom_name>.selectpicker').selectpicker()
                    $('#metaDataSelectPicker>.sel_allcustom_name>.selectpicker').selectpicker('refresh');
                    $('#metaDataSelectPicker>.sel_allcustom_name>.selectpicker').siblings('div').find('ul > li:has("span.text:empty")').remove();
                    $('#metaDataSelectPicker>.sel_allcustom_name>.selectpicker').remove('change');
                    $('#metaDataSelectPicker>.sel_allcustom_name>.selectpicker').on('change', function () {
                        $('#metaDataSelectPicker>.sel_allcustom_name>.selectpicker').selectpicker('refresh');
                        $timeout(function () {
                            if ($scope.selectedMetaData == 'CLASS') {
                                $location.path('/class');
                                $scope.selectedApp.CurrentSubTab = 'CLASS';
                            } else {
                                $location.path('/metadata');
                                var selectedMetaDataItem = $filter('filter')($scope.metaDataList, { MetaDataItem: $scope.selectedMetaData });
                                $scope.selectedApp.CurrentSubTab = selectedMetaDataItem[0].DisplayText;
                                $timeout(function () {
                                    $rootScope.$broadcast('metaDataComboChanged');
                                });
                            }
                        });
                    });
                });
            }, true);
        },*/
        link: function (scope, elem, attr) {
            var promise = ManagementService.getCaptions(scope.selectedLibrary);
            promise.then(function (response) {
                if (response.data.rows[0].cell[0].length > 0) {
                    scope.appsVar.CaptionsList = response.data.rows[0].cell[0];
                    scope.metaDataList = $filter('filter')(scope.appsVar.CaptionsList, { isMetaItem: true, ParentMetaItem: "" });
                    scope.selectedMetaData = 'CUSTOM1';
                    var selectedMetaDataItem = $filter('filter')(scope.metaDataList, { MetaDataItem: scope.selectedMetaData });
                    scope.selectedApp.CurrentSubTab = selectedMetaDataItem[0].DisplayText;
                    $timeout(function () {
                        $('#metaDataSelectPicker>.sel_allcustom_name>.selectpicker').selectpicker()
                        $('#metaDataSelectPicker>.sel_allcustom_name>.selectpicker').selectpicker('refresh');
                        $('#metaDataSelectPicker>.sel_allcustom_name>.selectpicker').siblings('div').find('ul > li:has("span.text:empty")').remove();
                        $('#metaDataSelectPicker>.sel_allcustom_name>.selectpicker').remove('change');
                        $('#metaDataSelectPicker>.sel_allcustom_name>.selectpicker').on('change', function () {
                            $('#metaDataSelectPicker>.sel_allcustom_name>.selectpicker').selectpicker('refresh');
                            $timeout(function () {
                                if (scope.selectedMetaData == 'CLASS') {
                                    $location.path('/class');
                                    scope.selectedApp.CurrentSubTab = 'CLASS';
                                } else {
                                    $location.path('/metadata');
                                    var selectedMetaDataItem = $filter('filter')(scope.metaDataList, { MetaDataItem: scope.selectedMetaData });
                                    scope.selectedApp.CurrentSubTab = selectedMetaDataItem[0].DisplayText;
                                    $timeout(function () {
                                        $rootScope.$broadcast('metaDataComboChanged');
                                    });
                                }
                            });
                        });
                    });
                }
            }, function () {
                console.log('Data fetching failed.');
            });
        }
    }
}]);

app.directive('toogleAddClassNavTab', function () {
    return {
        restrict: 'A',
        link: function (scope, elem, attr) {
            elem.on('click', function () {
                $("#addClassModelBody>.nav-tabs>li").removeClass("active in");
                $("#addClassModelBody>.tab-content>.tab-pane").removeClass("active in");
                elem.parent().addClass("active in");

                if (attr.rel == 'defaults_tab') {
                    $('#defaults_tab').addClass("active in");
                } else {
                    $('#req_field_tab').addClass("active in");
                }
            })
        }
    };
});

app.directive('toogleAddRoleNavTab', function () {
    return {
        restrict: 'A',
        link: function (scope, elem, attr) {
            elem.on('click', function () {
                $("#addClassModelBody>.nav-tabs>li").removeClass("active in");
                $("#addClassModelBody>.tab-content>.tab-pane").removeClass("active in");
                elem.parent().addClass("active in");

                if (attr.rel == 'defaults_tab') {
                    $('#defaults_tab').addClass("active in");
                } else {
                    $('#req_field_tab').addClass("active in");
                }
            })
        }
    };
});

app.directive('numericSpinner', function () {
    return {
        restrict: 'E',
        scope: {
            dirModel: '='
        },
        controller: function ($scope) {
            $scope.numericup = function () {
                $scope.dirModel = parseInt($scope.dirModel) + 1;
            };
            $scope.numericdown = function () {
                $scope.dirModel = parseInt($scope.dirModel) - 1;
            };
            return $scope;
        },
        templateUrl: 'Views/NgTemplates/DirectiveTemplates/NumericSpinner.html'
    }
});

app.directive("onSecTemplatePermissionTableRender", function ($timeout) {
    return {
        restrict: "A",
        link: function (scope, element, attrs) {
            scope.$watch(attrs.onSecTemplatePermissionTableRender, function (arg) {
                $timeout(function () {
                    angular.forEach(arg, function (argItem) {
                        $('#' + argItem.PermissionDDLId).selectpicker();
                        $('#' + argItem.PermissionDDLId).selectpicker('val', argItem.AccessRight);
                    });
                });
            });
        }
    }
});

app.directive('rowModifier', function () {
    return {
        restrict: 'E',
        scope: {
            onEdit: '&onEdit',
            onDelete: '&?'
        },
        replace: true,
        templateUrl: 'Views/NgTemplates/DirectiveTemplates/RowModifier.html',
        link: function (scope, element, attrs) {
            //if (attrs.onDelete) {
            //    $('#delete-icon').css('display', 'inline');
            //} else {
            //    $('#delete-icon').css('display', 'none');
            //}
        }
    }
});

app.directive('tablePagination', function () {
    return {
        restrict: 'E',
        scope: {
            onPrevClick: '&onPrev',
            onNextClick: '&onNext',
            isPrevDisabled: '=isPrevDisabled',
            isNextDisabled: '=isNextDisabled'
        },
        replace: true,
        templateUrl: 'Views/NgTemplates/DirectiveTemplates/TablePagination.html'
    }
});

app.directive('toogleAddRolesNavTab', function () {
    return {
        restrict: 'A',
        link: function (scope, elem, attr) {
            elem.on('click', function () {

                $(".collapse").collapse('hide');
                $("#" + attr.rel).collapse('toggle');
                $(".panel-title i.indicator").removeClass("icon-arrow-down").addClass("icon-arrow-top");
                elem.parent().find("i.indicator").toggleClass("icon-arrow-down icon-arrow-top");

            })
        }
    };
});

app.directive('toogleAddRolesPriTab', function () {
    return {
        restrict: 'A',
        link: function (scope, elem, attr) {
            elem.on('click', function () {
                $("#collapseOne div div ul.nav-tabs li").removeClass("active");
                $("#collapseOne div div div div").removeClass("active");
                elem.parent().addClass("active");
                $('#' + attr.rel).addClass("active");

            })
        }
    };
});

app.directive('capitalize', function () {
    return {
        require: 'ngModel',
        link: function (scope, element, attrs, modelCtrl) {
            var capitalize = function (inputValue) {
                if (inputValue == undefined) inputValue = '';
                var capitalized = inputValue.toUpperCase();
                if (capitalized !== inputValue) {
                    modelCtrl.$setViewValue(capitalized);
                    modelCtrl.$render();
                }
                return capitalized;
            }
            modelCtrl.$parsers.push(capitalize);
            capitalize(scope[attrs.ngModel]);  // capitalize initial value
        }
    };
});

app.directive('sortableColumn', function ($templateRequest, $compile) {
    return {
        restrict: 'C',
        //scope: {
        //    onPrevClick: '&onPrev',
        //    onNextClick: '&onNext',
        //    isPrevDisabled: '=isPrevDisabled',
        //    isNextDisabled: '=isNextDisabled'
        //},
        scope: {
            isAssending: '=?',
            onSorting: '&?'
        },
        controller: function ($scope, $element, $rootScope) {

            $scope.sortColumn = function () {
                if ($scope.$parent.appsVar.sortField == $($element[0]).attr('sort-value')) {
                    $scope.isAssending = !$scope.isAssending;
                } else {
                    $scope.isAssending = true;
                }

                $($element[0]).siblings('th').removeClass('sorted-column');
                $($element[0]).addClass('sorted-column');
                $scope.$parent.appsVar.sortField = $($element[0]).attr('sort-value');
                console.log('sorting...with column ' + $scope.$parent.appsVar.sortField);
                if ($scope.onSorting) {
                    $scope.onSorting();
                } else {
                    $rootScope.$broadcast('onTableSorting', $($element[0]).attr('sort-value'));
                }
            }

        },
        //scope: true,
        link: function (scope, element, attrs) {
            if (scope.isAssending == undefined) {
                scope.isAssending = true;
            }
            $templateRequest("Views/NgTemplates/DirectiveTemplates/TableSortButton.html").then(function (html) {
                element.append($compile(html)(scope));
            });
        }
    }
});

app.directive('filterColumn', function ($templateRequest, $compile, $timeout) {
    return {
        restrict: 'C',
        scope: {
            FilterText: '=?',
            onFiltering: '=?',
            FIlterType: '=?',
            checkboxFilter: '=?'
        },
        controller: function ($scope, $element, $rootScope) {
            $scope.FIlterType = $($element[0]).attr('filter-type');
            $scope.FilterClass = $($element[0]).attr('filter-class');
            $scope.onFiltering = $($element[0]).attr('filter-sub');
            $scope.checkboxFilter = {};
            $scope.checkboxFilter.Yes = false;
            $scope.checkboxFilter.No = false;
            $scope.checkboxFilter.FilterText = '';
            $scope.checkboxFilter.FilterKey = $($element[0]).attr('filter-key');


            var searchTimeout;
            var isClearSearch = false;
            $scope.$watch(function () { return $scope.checkboxFilter.FilterText }, function (newVal, oldVal) {
                if (isClearSearch) {
                    isClearSearch = false;
                } else {
                    if (oldVal != newVal) {
                        if (searchTimeout) $timeout.cancel(searchTimeout);

                        searchTimeout = $timeout(function () {
                            if ($scope.onFiltering) {
                                $rootScope.$broadcast('onsubTableFiltering', $scope.checkboxFilter.FilterText, $($element[0]).attr('filter-key'), $scope.onFiltering);
                            } else {
                                $rootScope.$broadcast('onTableFiltering', $scope.checkboxFilter.FilterText, $($element[0]).attr('filter-key'));
                            }
                        }, 2000);
                    }
                }
            }, true);
            $scope.applyFilter = function ($mdOpenMenu, event) {


                $mdOpenMenu(event);
            }

            $scope.FilterTextIconClick = function () {
                if (searchTimeout) $timeout.cancel(searchTimeout);
                $scope.checkboxFilter.FilterText = '';
                if ($scope.onFiltering) {
                    $rootScope.$broadcast('onsubTableFiltering', $scope.checkboxFilter.FilterText, $($element[0]).attr('filter-key'), $scope.onFiltering);
                } else {
                    $rootScope.$broadcast('onTableFiltering', $scope.checkboxFilter.FilterText, $($element[0]).attr('filter-key'));
                }
                isClearSearch = true;
            }

            $scope.applyCheckBox = function (scope) {
                if ($scope.checkboxFilter.Yes && $scope.checkboxFilter.No)
                    $scope.checkboxFilter.FilterText = '';
                else if ($scope.checkboxFilter.Yes && !$scope.checkboxFilter.No)
                    $scope.checkboxFilter.FilterText = 'Y';
                else if ($scope.checkboxFilter.No && !$scope.checkboxFilter.Yes)
                    $scope.checkboxFilter.FilterText = 'N';
                else $scope.checkboxFilter.FilterText = '';
            }
        },
        link: function (scope, element, attrs) {
            $templateRequest("Views/NgTemplates/DirectiveTemplates/FilterInput.html").then(function (html) {
                element.append($compile(html)(scope));
            });
        }
    }
});

app.directive('contextMenu', function ($templateRequest, $compile, $timeout) {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            element.on("contextmenu", function (e) {
                e.preventDefault(); // default context menu is disabled lScope
                //if (attrs.ngClick) {
                //$timeout(function () {
                //element.click();
                if (element.children().find('md-checkbox').attr('checked') != 'checked')
                    element.children().find('md-checkbox').click();

                //  The customized context menu is defined in the main controller. To function the ng-click functions the, contextmenu HTML should be compiled.
                $templateRequest("Views/NgTemplates/DirectiveTemplates/ContextMenu.html").then(function (html) {
                    element.append($compile(html)(scope));
                    // The location of the context menu is defined on the click position and the click position is catched by the right click event.
                    //scope.$parent.appsVar.rightClickMenuID = scope.$$watchers[scope.$$watchersCount - 1].last;
                    $('.context-menu-container').css("left", e.clientX);
                    $('.context-menu-container').css("top", e.clientY);
                });
                //});
                //}
            });
        }
    }
});

app.directive('popOver', function ($http) {
    return {
        restrict: 'C',
        link: function (scope, element, attr) {
            element.tooltip();
            element.bind('mouseover', function (e) {
                $http.get("test").success(function (data) {
                    attr.$set('originalTitle', scope.appsVar.tooltipValue);
                    element.tooltip('show');
                });
            });
        }
    }
});

app.directive('changeValue', function () {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            scope.$watch(attrs.ngModel, function (v) {
                if (v == null || v == '')
                    //$(element[0]).siblings('md-icon').first().hide();
                    $(element[0]).siblings('md-icon').children().first().hide();
                else
                    //$(element[0]).siblings('md-icon').first().show();
                    $(element[0]).siblings('md-icon').children().first().show();
            });
        }
    };
});

//passwordCharView
(function () {
    app.directive('passwordCharView', function ($timeout) {
        return {
            restrict: 'A',
            require: 'ngModel',
            scope: {
                modelValue: '=',
                ngModel: '='
            },
            link: function (scope, element, attr) {
                var lastCaretPosition = 0;
                $(element).attr('autocomplete', 'off');
                $timeout(function () {
                    scope.$apply(function () {
                        $(element).val('');
                        scope.modelValue = '';
                    });
                });
                var searchTimeout;
                element.bind("cut copy paste", function (event) {
                    event.preventDefault();
                });
                element.bind("focus", function (event) {
                    if (scope.modelValue == undefined || scope.modelValue.length != $(element).val().length) {
                        $(element).val('');
                        scope.modelValue = '';
                    }
                })
                element.bind("keypress", function (event) {
                    lastCaretPosition = $(element).caret().begin + 1;
                    if (event.which >= 32 && event.which <= 126) {
                        $(element).attr('type', 'text');
                        if (searchTimeout) {
                            $timeout.cancel(searchTimeout);
                            var str = '';
                            for (var i = 0, len = $(element).val().length; i < len; i++) {
                                str += '\u25CF';
                            }
                            scope.$apply(function () {
                                scope.ngModel = str;
                            });
                            if ($(element).caret().begin == $(element).caret().end)
                                $(element).caret(lastCaretPosition - 1);
                        }
                        if ($(element).val() == undefined) {
                            $(element).val('');
                        }
                        if (scope.modelValue == undefined) scope.modelValue = '';

                        if ($(element).val().length == $(element).caret().begin) {
                            $(element).val($(element).val() + String.fromCharCode(event.charCode));
                            scope.modelValue += String.fromCharCode(event.charCode);
                        } else {
                            scope.modelValue = scope.modelValue.substring(0, $(element).caret().begin) + String.fromCharCode(event.charCode) + scope.modelValue.substring($(element).caret().end, scope.modelValue.length);
                            var newVal = $(element).val().substring(0, $(element).caret().begin) + String.fromCharCode(event.charCode) + $(element).val().substring($(element).caret().end, $(element).val().length);
                            $(element).val(newVal);
                        }
                        $(element).caret(lastCaretPosition);
                        event.preventDefault();

                        searchTimeout = $timeout(function () {
                            var str = '';
                            for (var i = 0, len = $(element).val().length; i < len; i++) {
                                str += '\u25CF';
                            }
                            scope.$apply(function () {
                                scope.ngModel = str;
                            });
                            $(element).caret(lastCaretPosition);
                        }, 1000);
                    } else if (event.which == 8) {
                        if ($(element).val().length == $(element).caret().begin) {
                            scope.modelValue = scope.modelValue.slice(0, -1);
                        } else {
                            scope.modelValue = scope.modelValue.substring(0, $(element).caret().begin) + scope.modelValue.substring($(element).caret().end, scope.modelValue.length);
                        }
                    } else if (event.which == 0) {
                        if ($(element).val().length == $(element).caret().begin) {
                        } else if ($(element).caret().begin == $(element).caret().end) {
                            scope.modelValue = scope.modelValue.substring(0, $(element).caret().begin) + scope.modelValue.substring($(element).caret().end + 1, scope.modelValue.length);
                        } else {
                            scope.modelValue = scope.modelValue.substring(0, $(element).caret().begin) + scope.modelValue.substring($(element).caret().end, scope.modelValue.length);
                        }
                    }
                });
            }
        }
    });
})();

//tableFilter
(function () {
    app.directive('tableFilter', function ($templateRequest, $compile, $rootScope, $window, $timeout, $log) {
        return {
            restrict: 'E',
            scope: {
                isFilterShowing: '=',
                onFilter: '&'
            },
            link: function (scope, element, attr) {
                $templateRequest("Views/NgTemplates/DirectiveTemplates/TableFilter.html").then(function (html) {
                    var elem = $('table > thead > tr')
                    element.children().find(elem).append($compile(html)(scope));
                });
                $templateRequest("Views/NgTemplates/DirectiveTemplates/FilterClearFields.html").then(function (html) {
                    var elem = $('table > tbody > tr.filter-row > td:last-child')
                    element.children().find(elem).append($compile(html)(scope));
                });
            },
            controller: function ($scope, $element) {
                $scope.filterClicked = function () {
                    $scope.isFilterShowing = !$scope.isFilterShowing;
                };

                $scope.onMouseLeave = function () {
                    if ($window.navigator.userAgent.indexOf('Chrome') > 0) {
                        $('table-filter>table.md-table').css('overflow', 'auto');
                        $timeout(function () {
                            $('table-filter>table.md-table').css('overflow', 'hidden');
                        });
                    }
                };

                $scope.clearFilter = function () {
                    var combobox_elements = [].slice.call($element[0].querySelectorAll('.filter-combo-container'), 0);
                    var combobox_controllers = combobox_elements.map(function (el) {
                        return angular.element(el).scope();
                    });
                    combobox_controllers.forEach(function (scope) {
                        scope.clearFilter()
                    });

                    var textbox_elements = [].slice.call($element[0].querySelectorAll('.filterTextbox'), 0);
                    var textbox_controllers = textbox_elements.map(function (el) {
                        return angular.element(el).scope();
                    });
                    textbox_controllers.forEach(function (scope) {
                        scope.clearFilter()
                    });
                };

                $scope.onFilter = $scope.onFilter();
                this.performFilter = function (filterText, filterKey) {
                    $scope.onFilter(filterText, filterKey);
                }
            }
        }
    });
})();

//tableWrapper
(function () {
    app.directive('tableWrapper', function () {
        return {
            restrict: 'E',
            transclude: true,
            templateUrl: 'Views/NgTemplates/DirectiveTemplates/TableWrapper.html'
        }
    });
})();

//filterTextbox
(function () {
    app.directive('filterTextbox', function ($timeout, $log) {
        return {
            restrict: 'E',
            require: ['^tableFilter'],
            scope: true,
            templateUrl: 'Views/NgTemplates/DirectiveTemplates/FilterTextbox.html',
            link: function (scope, element, attr, ctrl) {
                scope.filterText = '';
                var tableFilterCtrl = ctrl[0];
                if (!attr.filterKey) {
                    $log.error('Filter key attribute is missing.');
                }
                scope.showEditField = true;
                scope.onEditFieldLeave = function () {
                    if (scope.filterText != '' && scope.filterText != undefined)
                        scope.showEditField = false;
                }

                scope.onDisplayFieldClicked = function () {
                    scope.showEditField = true;
                    $timeout(function () {
                        element.children()[0].focus()
                    });
                }

                scope.onDisplayCloseClicked = function () {
                    scope.showEditField = true;
                    scope.filterText = '';
                    tableFilterCtrl.performFilter(scope.filter.selected, attr.filterKey);
                }
                //var searchTimeout;
                scope.$watch(function () { return scope.filterText }, function (newVal, oldVal) {
                    if (oldVal != newVal) {
                        tableFilterCtrl.performFilter(scope.filterText, attr.filterKey);
                    }
                }, true);
            },
            controller: function ($scope) {
                $scope.clearFilter = function () {
                    $scope.showEditField = true;
                    $scope.filterText = '';
                }
            }
        }
    });
})();

//filterCombobox
(function () {
    app.directive('filterCombobox', function ($timeout, $log) {
        return {
            restrict: 'E',
            require: ['^tableFilter'],
            scope: true,
            templateUrl: 'Views/NgTemplates/DirectiveTemplates/FilterCombobox.html',
            link: function (scope, element, attr, ctrl) {
                var tableFilterCtrl = ctrl[0];
                scope.filter = {
                    selected: ''
                }
                if (!attr.filterKey) {
                    $log.error('Filter key attribute is missing.');
                }
                scope.showEditField = true;
                scope.elementName = attr.filterKey;
                scope.onEditFieldChange = function () {
                    if (scope.filter.selected != '' && scope.filter.selected != undefined)
                        scope.showEditField = false;
                }

                scope.onDisplayFieldClicked = function () {
                    scope.showEditField = true;
                }

                scope.onDisplayCloseClicked = function ($event) {
                    scope.showEditField = true;
                    scope.filter.selected = '';
                    tableFilterCtrl.performFilter(scope.filter.selected, attr.filterKey);
                    $event.stopPropagation();
                }

                var searchTimeout;
                scope.$watch(function () { return scope.filter.selected }, function (newVal, oldVal) {
                    if (oldVal != newVal) {
                        tableFilterCtrl.performFilter(scope.filter.selected, attr.filterKey);
                    }
                }, true);
            },
            controller: function ($scope) {
                $scope.clearFilter = function () {
                    $scope.showEditField = true;
                    $scope.filter.selected = '';
                }
            }
        }
    });
})();