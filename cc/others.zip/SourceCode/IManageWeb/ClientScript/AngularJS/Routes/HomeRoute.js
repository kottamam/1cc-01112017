﻿(function () {   

    // Declare app level module which depends on filters, and services
     app.config(['$stateProvider', '$urlRouterProvider', '$logProvider',
        function ($stateProvider, $urlRouterProvider) {

            $urlRouterProvider.otherwise("/");

            $stateProvider
            .state('home', {
                url: '/',
                templateUrl: appBaseURL + 'Views/NgTemplates/Home.html',
                controller: 'HomeController as vm'
            })
            .state('home.home-content', {
                url: 'home',
                views: {
                    'content@home': {
                        templateUrl: appBaseURL + 'Views/NgTemplates/DummyTable.html'
                    }
                }
            })
            .state('home.user', {
                url: 'user_details',

                views: {
                    'content@home': {
                        templateUrl: appBaseURL + 'Views/NgTemplates/UserTable.html',
                        controller: 'UserController'
                    }

                }
            })
            .state('home.group', {
                url: 'group_details',
                views: {
                    'content@home': {
                        templateUrl: appBaseURL + 'Views/NgTemplates/GroupTable.html',
                        controller: 'GroupController'
                    }
                }
            })
            .state('home.roles', {
                url: 'role_details',
                views: {
                    'content@home': {
                        templateUrl: appBaseURL + 'Views/NgTemplates/RolesTable.html',
                        controller: 'RolesController'
                    }
                }
            })
            .state('home.documents-active', {
                url: 'documents/active',
                views: {
                    'content@home': {
                        templateUrl: appBaseURL + 'Views/NgTemplates/DummyTable.html'
                    }
                }
            })
            .state('home.documents-archive', {
                url: 'documents/archive',
                views: {
                    'content@home': {
                        templateUrl: appBaseURL + 'Views/NgTemplates/DummyTable.html'
                    }
                }
            })
            .state('home.documents-trash', {
                url: 'documents/trash',
                views: {
                    'content@home': {
                        templateUrl: appBaseURL + 'Views/NgTemplates/DummyTable.html'
                    }
                }
            })
            .state('home.workspaces-active', {
                url: 'workspaces/active',
                views: {
                    'content@home': {
                        templateUrl: appBaseURL + 'Views/NgTemplates/DummyTable.html'
                    }
                }
            })
            .state('home.workspaces-archive', {
                url: 'workspaces/archive',
                views: {
                    'content@home': {
                        templateUrl: appBaseURL + 'Views/NgTemplates/DummyTable.html'
                    }
                }
            })
            .state('home.workspaces-trash', {
                url: 'workspaces/trash',
                views: {
                    'content@home': {
                        templateUrl: appBaseURL + 'Views/NgTemplates/DummyTable.html'
                    }
                }
            })
            .state('home.class', {
                url: 'class_details',
                views: {
                    'content@home': {
                        templateUrl: appBaseURL + 'Views/NgTemplates/ClassTable.html',
                        controller: 'ClassController'
                    }
                }
            })
            .state('home.type', {
                url: 'type_details',
                views: {
                    'content@home': {
                        templateUrl: appBaseURL + 'Views/NgTemplates/DummyTable.html'
                    }
                }
            })
            .state('home.app', {
                url: 'app_details',
                views: {
                    'content@home': {
                        templateUrl: appBaseURL + 'Views/NgTemplates/DummyTable.html'
                    }
                }
            })
            .state('home.metadata', {
                url: 'meta_details',
                views: {
                    'content@home': {
                        templateUrl: appBaseURL + 'Views/NgTemplates/MetaDataTable.html',
                        controller: 'MetaDataController'
                    }
                }
            })
            .state('home.server-options', {
                url: 'server_options',
                views: {
                    'content@home': {
                        templateUrl: appBaseURL + 'Views/NgTemplates/DummyTable.html'
                    }
                }
            })
            .state('home.database-options', {
                url: 'database_options',
                views: {
                    'content@home': {
                        templateUrl: appBaseURL + 'Views/NgTemplates/DummyTable.html'
                    }
                }
            })
            .state('home.adfs-setup', {
                url: 'adfs_setup',
                views: {
                    'content@home': {
                        templateUrl: appBaseURL + 'Views/NgTemplates/DummyTable.html'
                    }
                }
            })
            .state('home.templates', {
                url: 'templates',
                views: {
                    'content@home': {
                        templateUrl: appBaseURL + 'Views/NgTemplates/DummyTable.html'
                    }
                }
            })
            .state('home.dashboard', {
                url: 'dashboard',
                views: {
                    'content@home': {
                        templateUrl: appBaseURL + 'Views/NgTemplates/DummyTable.html'
                    }
                }
            })
            .state('home.ad-sync', {
                url: 'ad_sync',
                views: {
                    'content@home': {
                        templateUrl: appBaseURL + 'Views/NgTemplates/DummyTable.html'
                    }
                }
            })
            .state('home.bulk-import-jobs', {
                url: 'bulk_import_jobs',
                views: {
                    'content@home': {
                        templateUrl: appBaseURL + 'Views/NgTemplates/DummyTable.html'
                    }
                }
            })
            .state('home.workspace-generation', {
                url: 'workspace_generation',
                views: {
                    'content@home': {
                        templateUrl: appBaseURL + 'Views/NgTemplates/DummyTable.html'
                    }
                }
            })
            .state('home.servers', {
                url: 'servers',
                views: {
                    'content@home': {
                        templateUrl: appBaseURL + 'Views/NgTemplates/DummyTable.html'
                    }
                }
            })
            .state('home.indexers', {
                url: 'indexers',
                views: {
                    'content@home': {
                        templateUrl: appBaseURL + 'Views/NgTemplates/DummyTable.html'
                    }
                }
            })
            .state('home.jobs', {
                url: 'jobs',
                views: {
                    'content@home': {
                        templateUrl: appBaseURL + 'Views/NgTemplates/DummyTable.html'
                    }
                }
            })
            .state('home.tba', {
                url: 'to_be_determined',
                views: {
                    'content@home': {
                        templateUrl: appBaseURL + 'Views/NgTemplates/DummyTable.html'
                    }
                }
            })
            .state('home.standard-reports', {
                url: 'standard_reports',
                views: {
                    'content@home': {
                        templateUrl: appBaseURL + 'Views/NgTemplates/DummyTable.html'
                    }
                }
            })
            .state('home.custom-reports', {
                url: 'custom_reports',
                views: {
                    'content@home': {
                        templateUrl: appBaseURL + 'Views/NgTemplates/DummyTable.html'
                    }
                }
            })
            .state('home.configure-reports', {
                url: 'configure_reports',
                views: {
                    'content@home': {
                        templateUrl: appBaseURL + 'Views/NgTemplates/DummyTable.html'
                    }
                }
            })
            .state('home.report-builder', {
                url: 'report_builder',
                views: {
                    'content@home': {
                        templateUrl: appBaseURL + 'Views/NgTemplates/DummyTable.html'
                    }
                }
            })
            .state('home.management', {
                url: 'management',
                abstract: true
            })
        }]);

})();
