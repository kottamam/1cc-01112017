(function () {

    'use strict';

    // Declare app level module which depends on filters, and services
    angular.module('iManageApp')
      .config(['$stateProvider', '$urlRouterProvider', '$logProvider',
        function ($stateProvider, $urlRouterProvider) {

            $urlRouterProvider.otherwise("/");

            $stateProvider
              .state('home', {
                  url: '/',
                  templateUrl: appBaseURL + 'Views/NgTemplates/Home.html',
                  controller: 'HomeController as vm'
              })
              .state('home.user', {
                  url: 'user_details',

                  views: {

                      'content@home': {
                          templateUrl: appBaseURL + 'Views/NgTemplates/UserTable.html',
                          controller: 'UserController'
                      }/*,
                      'header@home.user': {
                          templateUrl: appBaseURL + 'Views/NgTemplates/DirectiveTemplates/TableHeader.html',
                          controller: 'UserController'
                      }*/

                  }
              })                
              .state('home.group', {
                  url: 'group_details',
                  views: {

                      'content@home': {
                          templateUrl: appBaseURL + 'Views/NgTemplates/GroupTable.html',
                          controller: 'GroupController'
                      }
                  }
              })
                .state('home.roles', {
                    url: 'role_details',
                    views: {

                        'content@home': {
                            templateUrl: appBaseURL + 'Views/NgTemplates/RolesTable.html',
                            controller: 'RolesController'
                        }
                    }
                })
              .state('home.management', {
                  url: 'management',
                  abstract: true
              })
        }]);

})();