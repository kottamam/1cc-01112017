﻿app.controller("SearchListController", SearchListController);
SearchListController.$inject = ['$scope', '$rootScope', '$filter', 'UserService', 'DocTypeService', 'MetaDataService', 'ClassService', 'SecurityTemplateService', 'homeFactory', '$mdDialog', '$mdMedia', '$timeout'];

function SearchListController($scope, $rootScope, $filter, UserService, DocTypeService, MetaDataService, ClassService, SecurityTemplateService, homeFactory, $mdDialog, $mdMedia, $timeout) {

    $scope.SearchFormObject = {
        SearchText: '',
        SearchTimeout: null,
        IsMetaDataVisible: false,
        IsSearchTextFound: false,
        SelectedParentItem: null,
        RequestModel: homeFactory.requestModelInstance(),
        TableItemList: [],
        SelectedItemList: []
    };

    $scope.TablePagination = {
        order: 'TemplateName',
        limit: $scope.SearchFormObject.RequestModel.pageLength,
        page: $scope.SearchFormObject.RequestModel.pagenumber,
        totalCount: 0
    };

    $scope.$on('OpenSearchList_Click', function (event, args) {
        setInitialValues();

        $scope.SearchFormObject.SelectedParentItem = args;
        getSecurityTemplateList();



        //if (args.CaptionType == 'users') {
        //    getUserList();
        //}
        //else if (args.CaptionType == 'types') {
        //    dbListOffset = 0;
        //    getDocTypeList();
        //}
        //else if (args.CaptionType == 'classes') {
        //    getClassList();
        //}
        //else if (args.CaptionType == 'subclasses') {
        //    getSubClassList();
        //}
        //else if (args.CaptionType == 'SecurityTemplate') {
        //    NextPageCursor = '';
        //    isEnableMultiSelection = true;
        //    PreviousPageCursorList = [];
        //    getSecurityTemplateList();
        //}
        //else if (args.CaptionType.startsWith('custom')) {
        //    $scope.SearchFormObject.IsMetaDataVisible = true;
        //    getMetaDataList();
        //}
    });

    function setInitialValues() {

        $scope.SearchFormObject.SearchText = '';
        $scope.SearchFormObject.SearchTimeout = null;
        $scope.SearchFormObject.SelectedParentItem = null;
        $scope.SearchFormObject.IsSearchTextFound = false;
        $scope.SearchFormObject.IsMetaDataVisible = false;
        $scope.SearchFormObject.TableItemList = [];
        $scope.SearchFormObject.SelectedItemList = [];
        
        $scope.SearchFormObject.RequestModel.libraryName = $scope.selectedLibrary;
        $scope.SearchFormObject.RequestModel.pagenumber = 1;
        $scope.SearchFormObject.RequestModel.pageLength = 10;
        $scope.SearchFormObject.RequestModel.isTotal = true;

    }

    $scope.OKButton_Click = function () {

        //if ($scope.SearchFormObject.SelectedItemList && $scope.SearchFormObject.SelectedItemList.length > 0) {

        //    if (!$scope.SearchFormObject.SelectedParentItem.IsEnableMutiSelection && $scope.SearchFormObject.SelectedItemList.length > 1) {
        //        $scope.SearchFormObject.SelectedItemList = $scope.SearchFormObject.SelectedItemList.slice(0, 1);
        //    }

        // angular.forEach($scope.SearchFormObject.SelectedItemList, function (listItem) {

        //if ($scope.SelectedParentItem.CaptionType == 'users') {
        //    selectedResult += listItem.UserId + ', ';
        //}
        //else if ($scope.SelectedParentItem.CaptionType == 'types') {
        //    selectedResult += listItem.TAlias + ', ';
        //}
        //else if ($scope.SelectedParentItem.CaptionType == 'classes') {
        //    selectedResult += listItem.Alias + ', ';
        //}
        //else if ($scope.SelectedParentItem.CaptionType == 'subclasses') {
        //    selectedResult += listItem.Alias + ', ';
        //}
        //else if ($scope.SelectedParentItem.CaptionType == 'SecurityTemplate') {
        //    
        //}
        //else if ($scope.SelectedParentItem.CaptionType.startsWith('custom')) {
        //    selectedResult += listItem.Alias + ', ';
        //}
        //selectedResult += listItem.TemplateName + ', ';
        //});

        //if (selectedResult.trim().length > 0) {
        //    selectedResult = selectedResult.substring(0, selectedResult.trim().length - 1);
        //}
        //}
        $scope.$emit('SearchTableRow_Selected', $scope.SearchFormObject.SelectedItemList);
        setInitialValues();
    }

    $scope.CloseSearchListDialog = function () {
        setInitialValues();
        $scope.$emit('SearchTableRow_Cancelled');
    }

    $scope.Search_Click = function () {
        if ($scope.SearchFormObject.SearchTimeout) $timeout.cancel($scope.SearchFormObject.SearchTimeout);

        getSecurityTemplateList();
    }

    $scope.ClearSearch_Click = function () {
        if ($scope.SearchFormObject.SearchTimeout) $timeout.cancel($scope.SearchFormObject.SearchTimeout);

        $scope.SearchFormObject.SearchText = '';
        getSecurityTemplateList();
    }

    $scope.$watch(function () { return $scope.SearchFormObject.SearchText }, function (val) {
        if ($scope.SearchFormObject.SearchText.length > 0) {
            $scope.SearchFormObject.IsSearchTextFound = true;
        }
        if ($scope.SearchFormObject.SearchTimeout) $timeout.cancel($scope.SearchFormObject.SearchTimeout);

        $scope.SearchFormObject.SearchTimeout = $timeout(function () {
            if ($scope.SearchFormObject.IsSearchTextFound) {
                $scope.Search_Click();
            }
        }, 2000);
    }, true);

    //function getUserList() {
    //    if ($scope.selectedApp.NoAppsPermission.trim().length > 0) return;
    //    if (!$scope.selectedLibrary || $scope.selectedLibrary.trim().length == 0) return;

    //    requestModel.libraryName = $scope.selectedLibrary;
    //    requestModel.pagenumber = dbListOffset;
    //    requestModel.pageLength = tableRowLimit;
    //    requestModel.isTotal = isRetriveTotalItemCount;
    //    requestModel.searchText = $scope.SearchFormObject.SearchText;

    //    $scope.IsLoading = true;
    //    $scope.SearchFormObject.isPrevDisable = false;
    //    $scope.SearchFormObject.isNextDisable = false;

    //    var promise = UserService.getUsers(requestModel, $scope.SearchFormObject.IsSelectinternalUsersOnly)
    //    promise.then(function (response) {
    //        $scope.appsVar.initialLoading = false;
    //        $scope.SearchFormObject.UserModelList = [];
    //        if (response.data.rows && response.data.rows.length > 0 && response.data.rows[0].cell && response.data.rows[0].cell.length > 0) {
    //            $scope.SearchFormObject.isPrevDisable = dbListOffset <= 1;
    //            $scope.SearchFormObject.isNextDisable = dbListOffset * tableRowLimit >= response.data.total;
    //            $scope.SearchFormObject.UserModelList = response.data.rows[0].cell[0];
    //        }
    //        $scope.IsLoading = false;
    //    }, function () {
    //        $scope.IsLoading = false;
    //        $scope.SearchFormObject.UserModelList = [];
    //        $scope.showAlertMessage('Failed to fetch Users.');
    //    });
    //}

    //function getDocTypeList() {
    //    if ($scope.selectedApp.NoAppsPermission.trim().length > 0) return;
    //    if (!$scope.selectedLibrary || $scope.selectedLibrary.trim().length == 0) return;

    //    $scope.SearchFormObject.isPrevDisable = false;
    //    $scope.SearchFormObject.isNextDisable = false;
    //    $scope.IsLoading = true;

    //    var promise = DocTypeService.getDocTypes($scope.selectedLibrary, dbListOffset, tableRowLimit, isRetriveTotalItemCount, $scope.SearchFormObject.SearchText);
    //    promise.then(function (response) {
    //        $scope.SearchFormObject.DocTypeModelList = [];
    //        if (response.data.rows && response.data.rows.length > 0 && response.data.rows[0].cell && response.data.rows[0].cell.length > 0) {
    //            $scope.SearchFormObject.DocTypeModelList = response.data.rows[0].cell[0];
    //            $scope.SearchFormObject.isPrevDisable = dbListOffset <= 0;
    //            $scope.SearchFormObject.isNextDisable = ((dbListOffset + tableRowLimit) >= response.data.rows[0].cell[1]);
    //        }
    //        $scope.IsLoading = false;
    //    }, function () {
    //        $scope.SearchFormObject.DocTypeModelList = [];
    //        $scope.IsLoading = false;
    //        $scope.showAlertMessage('Failed to fetch Types.');
    //    });
    //}

    //function getMetaDataList() {
    //    if (!$scope.selectedLibrary || $scope.selectedLibrary.length == 0) return;

    //    requestModel.libraryName = $scope.selectedLibrary;
    //    requestModel.pagenumber = dbListOffset;
    //    requestModel.pageLength = tableRowLimit;
    //    requestModel.isTotal = isRetriveTotalItemCount;
    //    requestModel.searchText = $scope.SearchFormObject.SearchText;

    //    $scope.SearchFormObject.isPrevDisable = false;
    //    $scope.SearchFormObject.isNextDisable = false;
    //    $scope.IsLoading = true;

    //    lstMetadata = MetaDataService.getMetaDataList(requestModel, $scope.SelectedParentItem.Profile);
    //    lstMetadata.then(function (response) {
    //        $scope.appsVar.initialLoading = false;
    //        $scope.SearchFormObject.MetaDataModelList = [];
    //        if (response.data.rows && response.data.rows.length > 0 && response.data.rows[0].cell && response.data.rows[0].cell.length > 0) {
    //            $scope.SearchFormObject.isPrevDisable = dbListOffset <= 1;
    //            $scope.SearchFormObject.isNextDisable = dbListOffset * tableRowLimit >= response.data.total;
    //            $scope.SearchFormObject.MetaDataModelList = response.data.rows[0].cell[0];
    //        }
    //        $scope.IsLoading = false;
    //    }, function () {
    //        $scope.SearchFormObject.MetaDataModelList = [];
    //        $scope.IsLoading = false;
    //        $scope.showAlertMessage('Failed to fetch Meta data.');
    //    });
    //}

    //function getClassList() {
    //    requestModel.libraryName = $scope.selectedLibrary;
    //    requestModel.pagenumber = dbListOffset;
    //    requestModel.pageLength = tableRowLimit;
    //    requestModel.isTotal = isRetriveTotalItemCount;
    //    requestModel.searchText = $scope.SearchFormObject.SearchText;

    //    $scope.IsLoading = true;
    //    $scope.SearchFormObject.isPrevDisable = false;
    //    $scope.SearchFormObject.isNextDisable = false;

    //    var promiseClass = ClassService.getClasses(requestModel);
    //    promiseClass.then(function (response) {
    //        $scope.SearchFormObject.ClassModelList = [];
    //        $scope.appsVar.initialLoading = false;

    //        if (response.data.rows && response.data.rows.length > 0 && response.data.rows[0].cell && response.data.rows[0].cell.length > 0) {
    //            $scope.SearchFormObject.isPrevDisable = dbListOffset <= 1;
    //            $scope.SearchFormObject.isNextDisable = dbListOffset * tableRowLimit >= response.data.total;
    //            $scope.SearchFormObject.ClassModelList = response.data.rows[0].cell[0];
    //        }
    //        $scope.IsLoading = false;
    //    }, function () {
    //        $scope.SearchFormObject.ClassModelList = [];
    //        $scope.IsLoading = false;
    //        $scope.showAlertMessage('Failed to fetch Classes.');
    //    });
    //};

    //function getSubClassList() {
    //    requestModel.libraryName = $scope.selectedLibrary;
    //    requestModel.pagenumber = dbListOffset;
    //    requestModel.pageLength = tableRowLimit;
    //    requestModel.isTotal = isRetriveTotalItemCount;
    //    requestModel.searchText = '';

    //    $scope.IsLoading = true;
    //    $scope.isPrevDisable = false;
    //    $scope.isNextDisable = false;
    //    var promise = ClassService.getSubClasses(requestModel, "");
    //    promise.then(function (response) {
    //        $scope.SearchFormObject.SubClassModelList = [];
    //        $scope.appsVar.initialLoading = false;

    //        if (response.data.rows && response.data.rows.length > 0 && response.data.rows[0].cell && response.data.rows[0].cell.length > 0) {
    //            $scope.SearchFormObject.isPrevDisable = dbListOffset <= 1;
    //            $scope.SearchFormObject.isNextDisable = dbListOffset * tableRowLimit >= response.data.total;
    //            $scope.SearchFormObject.SubClassModelList = response.data.rows[0].cell[0];
    //        }
    //        $scope.IsLoading = false;
    //    }, function () {
    //        $scope.SearchFormObject.SubClassModelList = [];
    //        $scope.IsLoading = false;
    //        $scope.showAlertMessage('Failed to fetch Classes.');
    //    });
    //}

    function getSecurityTemplateList() {
        $scope.SearchFormObject.RequestModel.searchText = $scope.SearchFormObject.SearchText.trim();

        var TemplateList = SecurityTemplateService.getServiceList($scope.SearchFormObject.RequestModel);
        TemplateList.then(function (response) {
            if (response.data && response.data.rows && response.data.rows.length > 0 && response.data.rows[0].cell && response.data.rows[0].cell.length > 0) {
                $scope.SearchFormObject.TableItemList = response.data.rows[0].cell[0];
                $scope.TablePagination.totalCount = response.data.total;
            }
            $scope.IsLoading = false;
        }, function () {
            $scope.IsLoading = false;
            $scope.showAlertMessage('Failed to fetch security template fetching.');
        });
    }

    $scope.onPaginate = function (page, limit) {
        $scope.SearchFormObject.RequestModel.pagenumber = page;
        $scope.SearchFormObject.RequestModel.pageLength = limit;
        getSecurityTemplateList();
    };
}