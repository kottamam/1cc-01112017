﻿app.controller("UserController", UserController);
UserController.$inject = ['$scope', '$rootScope', '$filter', '$timeout', '$log', '$mdDialog', '$mdMedia', 'UserService', 'userFactory', 'homeFactory', 'GroupService', 'HomeService', 'DatabaseService', 'securityTemplateFactory', 'SecurityTemplateService', '$http'];

function UserController($scope, $rootScope, $filter, $timeout, $log, $mdDialog, $mdMedia, UserService, userFactory, homeFactory, GroupService, HomeService, DatabaseService, securityTemplateFactory, SecurityTemplateService, $http) {
    $scope.PageEvents.Edit = 'undefined';
	$scope.PageEvents.AssignGroup = 'undefined';
	//$scope.tableParams = new ngTableParams({
	//	noPager: true
	//	//page: 1,            // show first page
	//	//                    count: 10,          // count per page
	//	//                    filter: {
	//	//                        //name: 'M'       // initial filter
	//	//                    },
	//	//                    sorting: {
	//	//                        //name: 'asc'     // initial sorting
	//	//                    }
	//}, {
	//	//total: data.length, // length of data					counts: [],
	//	getData: function ($defer, params) {
	//		$defer.resolve($scope.UserList);
	//	}
	//});

	$scope.PrefferedDB = {
		IsSearchTextFound: false,
		SearchText: ''
	};
	$scope.selectGroup = {
		IsSearchTextFound: false,
		SearchText: ''
	};

	$scope.AddRemoveGroups = {
		IsSearchTextFound: false,
		SearchText: ''
	};

	$scope.AddUserModel = {
	    PasswordValue: '',
        ConfirmPasswordValue: ''
	}

	$scope.SelAll = { checked: false };
	$scope.AddUserSelectedTab = 0;

	//$scope.SearchFormObject = {
	//    SearchText: '',
	//    SearchTimeout: null,
	//    IsMetaDataVisible: false,
	//    IsSearchTextFound: false,
	//    SelectedParentItem: null,
	//    RequestModel: homeFactory.requestModelInstance(),
	//    TableItemList: [],
	//    SelectedItemList: []
	//};

	//$scope.TablePagination = {
	//    order: 'GroupName',
	//    limit: $scope.SearchFormObject.RequestModel.pageLength,
	//    page: $scope.SearchFormObject.RequestModel.pagenumber,
	//    totalCount: 0
	//};

	//$scope.onPaginate = function (page, limit) {
	//    $scope.SearchFormObject.RequestModel.pagenumber = page;
	//    $scope.SearchFormObject.RequestModel.pageLength = limit;
	//    getAllGroupList();
	//};

	$scope.PageEvents.ResetPasswordclicked = function () {
		if ($("#contextmenunode"))
			$("#contextmenunode").remove();
		$scope.ValidateUsers = $scope.selected;// $filter('filter')($scope.UserList, { Selected: true });
		$scope.posting = false;
		if (typeof $scope.ValidateUsers !== 'undefined' && $scope.ValidateUsers.length > 0) {
			$scope.ShowWarning = false;
			$scope.validation.ConfirmPassword = '';
			$scope.AddUserModel.PasswordValue = '';
			$scope.validation.showMessage = false;
			$scope.user = userFactory.userInitailValues();
			var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
			$mdDialog.show({
				// controller: UserController,
				controller: DialogController,
				scope: $scope,        // use parent scope in template
				preserveScope: true,  // do not forget this if use parent scope
				templateUrl: 'Views/NgTemplates/ResetPassword.html',
				parent: angular.element(document.body),
				//targetEvent: event,
				clickOutsideToClose: true,
				fullscreen: useFullScreen
			})
			.then(function (answer) {
				$scope.status = 'You said the information was "' + answer + '".';
			}, function () {
				$scope.status = 'You cancelled the dialog.';
			});
			$scope.$watch(function () {
				return $mdMedia('xs') || $mdMedia('sm');
			}, function (wantsFullScreen) {
				$scope.customFullscreen = (wantsFullScreen === true);
			});
		}
		else {
			$scope.showAlertMessage('Select a User first.');
			return false;
		}

	};

	var ContextMenuVariables = {
		LockUnlock: {
			Label: 'Lock',
			Icon: 'img/icons/lock_outline_blue.svg',
			onClick: angular.noop
		}
	}

	$scope.ContextMenuFunctions = {
		Add: function () { $scope.PageEvents.Add(); },
		Edit: function () { editFunction(); },
		Delete: undefined,
		ResetPassword: function () { $scope.PageEvents.ResetPasswordclicked(); },
		AssignToGroup: function () { AssignGroupFunction(); },
		ViewUser: function () { viewFunction(); },
		Properties: function () { PropertiesFunction(); },
		EditUserContent: function () { EditUserContentFunction(); },
		ViewUserAccount: function () { ViewUserAccountFunction(); },
		ViewUserAccountHistory: function () { ViewUserAccountHistoryFunction(); },
		LockAccount: function () {
			var selectedUsers = $scope.selected; //$filter('filter')($scope.UserList, { Selected: true });
			var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
			var confirm = $mdDialog.confirm()
				.title('Lock Accounts')
				.textContent('Are you sure to lock selected account(s)?')
				.ariaLabel('Lock Accounts')
				.ok('Proceed')
				.cancel('Cancel');

			$mdDialog.show(confirm).then(function () {
			    var promise = UserService.LockUnlockUser($scope.vm.selectedLibrary, selectedUsers, false);
				promise.then(function (response) {
					if (response.data.length > 0) {
						userInitalize();
					}
				}, function () {
					//$scope.status = 'You decided to keep your debt.';
				});
			});
		},
		UnlockAccount: function () {
			var selectedUsers = $scope.selected;//= $filter('filter')($scope.UserList, { Selected: true });
			var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
			var confirm = $mdDialog.confirm()
				.title('Unlock Accounts')
				.textContent('Are you sure to unlock selected account(s)?')
				.ariaLabel('Unlock Accounts')
				.ok('Proceed')
				.cancel('Cancel');

			$mdDialog.show(confirm).then(function () {
			    var promise = UserService.LockUnlockUser($scope.vm.selectedLibrary, selectedUsers, true);
				promise.then(function (response) {
				    if (response.data.Status) {
						userInitalize();
					}
				}, function () {
					//$scope.status = 'You decided to keep your debt.';
				});
			});
		},
		AssignSecurityTemplate: function () {
		    var selectedUserList = $scope.selected;//= $filter('filter')($scope.UserList, { Selected: true });
		    GetSecurityTemplates();
			if (typeof selectedUserList !== 'undefined' && selectedUserList.length > 0) {
				$scope.AssignSecurityTemplateObject.showDialog(selectedUserList[0].UserId, selectedUserList[0].SecurityTemplate);
			}
		}
	}

	function setContextMenuObject() {

		var selectedUsers = $scope.selected;//= $filter('filter')($scope.UserList, { Selected: true });
		if (selectedUsers !== undefined && selectedUsers.length > 0) {
			if (selectedUsers.length == 1) {
				if (selectedUsers[0].IsAllowLogon) {
					ContextMenuVariables.LockUnlock.Label = 'Lock Account';
					ContextMenuVariables.LockUnlock.Icon = 'img/icons/lock_outline_blue.svg';
					ContextMenuVariables.LockUnlock.onClick = $scope.ContextMenuFunctions.LockAccount;
					$scope.PageEvents.LockAccount = $scope.ContextMenuFunctions.LockAccount;
					$scope.PageEvents.UnlockAccount = 'undefined';
				} else {
					ContextMenuVariables.LockUnlock.Label = 'Unlock Account';
					ContextMenuVariables.LockUnlock.Icon = 'img/icons/lock_open_blue.svg';
					ContextMenuVariables.LockUnlock.onClick = $scope.ContextMenuFunctions.UnlockAccount;
					$scope.PageEvents.LockAccount = 'undefined';
					$scope.PageEvents.UnlockAccount = $scope.ContextMenuFunctions.UnlockAccount;
				}
			} else {
				ContextMenuVariables.LockUnlock.Label = '';
				ContextMenuVariables.LockUnlock.onClick = 'undefined';
				$scope.PageEvents.LockAccount = 'undefined';
				$scope.PageEvents.UnlockAccount = 'undefined';
				var unlockedUsersInSelectedList = $filter('filter')(selectedUsers, { IsAllowLogon: true });
				if (unlockedUsersInSelectedList.length == selectedUsers.length) {
					ContextMenuVariables.LockUnlock.Label = 'Lock Account';
					ContextMenuVariables.LockUnlock.Icon = 'img/icons/lock_outline_blue.svg';
					ContextMenuVariables.LockUnlock.onClick = $scope.ContextMenuFunctions.LockAccount;
					$scope.PageEvents.LockAccount = $scope.ContextMenuFunctions.LockAccount;
					$scope.PageEvents.UnlockAccount = 'undefined';
				} else {
					var lockedUsersInSelectedList = $filter('filter')(selectedUsers, { IsAllowLogon: false });
					if (lockedUsersInSelectedList.length == selectedUsers.length) {
						ContextMenuVariables.LockUnlock.Label = 'Unlock Account';
						ContextMenuVariables.LockUnlock.Icon = 'img/icons/lock_open_blue.svg';
						ContextMenuVariables.LockUnlock.onClick = $scope.ContextMenuFunctions.UnlockAccount;
						$scope.PageEvents.LockAccount = 'undefined';
						$scope.PageEvents.UnlockAccount = $scope.ContextMenuFunctions.UnlockAccount;
					}
				}
			}
		} else {
			ContextMenuVariables.LockUnlock.Label = '';
			ContextMenuVariables.LockUnlock.onClick = 'undefined';
			$scope.PageEvents.LockAccount = 'undefined';
			$scope.PageEvents.UnlockAccount = 'undefined';
		}

		$scope.menuList = [
			{
				Label: 'Edit',
				Icon: 'img/icons/edit.svg',
				onClick: $scope.ContextMenuFunctions.Edit,
				Enable: $scope.selected.length == 1 //angular.isFunction($scope.ContextMenuFunctions.Edit)
			},
			//{
			//	Label: 'Delete',
			//	Icon: 'img/icons/delete.svg',
			//	onClick: $scope.ContextMenuFunctions.Delete,
			//	Enable: $scope.selected.length == 1 // angular.isFunction($scope.ContextMenuFunctions.Delete)
			//},
			 
			 {
				 Label: 'Add/Remove Groups',
				 Icon: 'img/icons/group_blue.svg',
				 onClick: $scope.ContextMenuFunctions.AssignToGroup,
				 Enable: $scope.selected.length == 1 // angular.isFunction($scope.ContextMenuFunctions.AssignToGroup)
			 },
			  //{
			  //    Label: 'View General User',
			  //    Icon: 'img/icons/view_blue.svg',
			  //    onClick: $scope.ContextMenuFunctions.ViewUser,
			  //    Enable: $scope.selected.length == 1 // angular.isFunction($scope.ContextMenuFunctions.ViewUser)
			  //},
			   {
				   Label: 'Properties',
				   Icon: 'img/icons/view_blue.svg',
				   onClick: $scope.ContextMenuFunctions.Properties,
				   Enable: $scope.selected.length == 1 // angular.isFunction($scope.ContextMenuFunctions.ViewUserContent)
			   },
				{
					Label: 'Edit User Content',
					Icon: 'img/icons/edit.svg',
					onClick: $scope.ContextMenuFunctions.EditUserContent,
					Enable: $scope.selected.length == 1 // angular.isFunction($scope.ContextMenuFunctions.EditUserContent)
				},
				  //{
				  //    Label: 'View User Account',
				  //    Icon: 'img/icons/view_blue.svg',
				  //    onClick: $scope.ContextMenuFunctions.ViewUserAccount,
				  //    Enable: $scope.selected.length == 1 // angular.isFunction($scope.ContextMenuFunctions.ViewUserAccount)
				  //},
				  //   {
				  //       Label: 'View Account History',
				  //       Icon: 'img/icons/userAccountHistory_blue.svg',
				  //       onClick: $scope.ContextMenuFunctions.ViewUserAccountHistory,
				  //       Enable: $scope.selected.length == 1 // angular.isFunction($scope.ContextMenuFunctions.ViewUserAccountHistory)
				  //   },
			 
			{
				Label: 'Reset Password',
				Icon: 'img/icons/key_blue.svg',
				onClick: $scope.ContextMenuFunctions.ResetPassword,
				Enable: $scope.selected.length > 0 // angular.isFunction($scope.ContextMenuFunctions.ResetPassword)
			},
		{
			Label: 'Assign Security Template',
			Icon: 'img/icons/view_blue.svg',
			onClick: $scope.ContextMenuFunctions.AssignSecurityTemplate,
			Enable: $scope.selected.length == 1 //
		}
			,
			{
			    Label: ContextMenuVariables.LockUnlock.Label,
			    Icon: ContextMenuVariables.LockUnlock.Icon,
			    onClick: ContextMenuVariables.LockUnlock.onClick,
			    Enable: $scope.selected.length > 0 && ContextMenuVariables.LockUnlock.Label!=''
			}
		];
	}

	var AssignGroupFunction = function () {
		$scope.IsShowErrorMessage = false;
		$scope.GroupCheckedFInal = [];
		$scope.AddRemoveGroups.SearchText = '';
		goffset = 1;
		getAllGroupList();
		$scope.ValidateAddRemoveGroups = $scope.selected;//= $filter('filter')($scope.UserList, { Selected: true });
		if (typeof $scope.ValidateAddRemoveGroups != 'undefined' && $scope.ValidateAddRemoveGroups.length > 0) {
			angular.copy($scope.ValidateAddRemoveGroups[0], $scope.user);
			var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
			$mdDialog.show({
				controller: DialogController,
				scope: $scope,        // use parent scope in template
				preserveScope: true,
				templateUrl: 'Views/NgTemplates/AddRemoveGroups.html',
				parent: angular.element(document.body),
				clickOutsideToClose: true,
				fullscreen: useFullScreen
			})
			.then(function (answer) {
				$scope.status = 'You said the information was "' + answer + '".';
			}, function () {
				$scope.status = 'You cancelled the dialog.';
			});
			$scope.$watch(function () {
				return $mdMedia('xs') || $mdMedia('sm');
			}, function (wantsFullScreen) {
				$scope.customFullscreen = (wantsFullScreen === true);
			});
			return true;
		}
		else {
			$scope.showAlertMessage('Select a User first.');
			return false;
		}
	}


	var EditUserContentFunction = function () {
		$scope.ShowWarning = false;
		$scope.PageEvents.UserAction = 'Edit User Content';
		$scope.DisableViewUserContent = false;
		$scope.ShowSaveButton = false;
		$scope.posting = false;
		$scope.ValidateUsers = $scope.selected;//= $filter('filter')($scope.UserList, { Selected: true });
		if (typeof $scope.ValidateUsers !== 'undefined' && $scope.ValidateUsers.length > 0) {
			getDatabaseByUser($scope.ValidateUsers[0].UserId, $scope.ValidateUsers[0].Password);
			FillUserScope($scope.ValidateUsers[0]);
			var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
			$mdDialog.show({
				controller: DialogController,
				scope: $scope,        // use parent scope in template
				preserveScope: true,
				templateUrl: 'Views/NgTemplates/ViewUserContent.html',//ViewUserContent
				parent: angular.element(document.body),
				clickOutsideToClose: true,
				fullscreen: useFullScreen
			})
			.then(function (answer) {
				$scope.status = 'You said the information was "' + answer + '".';
			}, function () {
				$scope.status = 'You cancelled the dialog.';
			});
			$scope.$watch(function () {
				return $mdMedia('xs') || $mdMedia('sm');
			}, function (wantsFullScreen) {
				$scope.customFullscreen = (wantsFullScreen === true);
			});
		}
		else {
			$scope.showAlertMessage('Select user to edit.');
		}
	}


	var ViewUserAccountHistoryFunction = function () {
		$scope.ShowWarning = false;
		$scope.PageEvents.UserAction = 'View User Account History';
		$scope.ValidateUsers = $scope.selected;//= $filter('filter')($scope.UserList, { Selected: true });
		if (typeof $scope.ValidateUsers !== 'undefined' && $scope.ValidateUsers.length > 0) {
			FillUserScope($scope.ValidateUsers[0]);
			var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
			$mdDialog.show({
				controller: DialogController,
				scope: $scope,        // use parent scope in template
				preserveScope: true,
				templateUrl: 'Views/NgTemplates/ViewUserAccountHistory.html',
				parent: angular.element(document.body),
				clickOutsideToClose: true,
				fullscreen: useFullScreen
			})
			.then(function (answer) {
				$scope.status = 'You said the information was "' + answer + '".';
			}, function () {
				$scope.status = 'You cancelled the dialog.';
			});
			$scope.$watch(function () {
				return $mdMedia('xs') || $mdMedia('sm');
			}, function (wantsFullScreen) {
				$scope.customFullscreen = (wantsFullScreen === true);
			});
		}
		else {
			$scope.showAlertMessage('Select user to edit.');
		}
	}


	var ViewUserAccountFunction = function () {
		$scope.ShowWarning = false;
		$scope.PageEvents.UserAction = 'View User Account';
		$scope.ValidateUsers = $scope.selected;//= $filter('filter')($scope.UserList, { Selected: true });
		if (typeof $scope.ValidateUsers !== 'undefined' && $scope.ValidateUsers.length > 0) {
			FillUserScope($scope.ValidateUsers[0]);
			var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
			$mdDialog.show({
				controller: DialogController,
				scope: $scope,        // use parent scope in template
				preserveScope: true,
				templateUrl: 'Views/NgTemplates/ViewUserAccount.html',
				parent: angular.element(document.body),
				clickOutsideToClose: true,
				fullscreen: useFullScreen
			})
			.then(function (answer) {
				$scope.status = 'You said the information was "' + answer + '".';
			}, function () {
				$scope.status = 'You cancelled the dialog.';
			});
			$scope.$watch(function () {
				return $mdMedia('xs') || $mdMedia('sm');
			}, function (wantsFullScreen) {
				$scope.customFullscreen = (wantsFullScreen === true);
			});
		}
		else {
			$scope.showAlertMessage('Select user to edit.');
		}
	}

	var PropertiesFunction = function () {
		$scope.ShowWarning = false;
		$scope.PageEvents.UserAction = 'View User Content';
		$scope.DisableViewUserContent = true;
		$scope.ShowSaveButton = false;
		$scope.ValidateUsers = $scope.selected;//= $filter('filter')($scope.UserList, { Selected: true });
		if (typeof $scope.ValidateUsers !== 'undefined' && $scope.ValidateUsers.length > 0) {
			getDatabaseByUser($scope.ValidateUsers[0].UserId, $scope.ValidateUsers[0].Password);
			FillUserScope($scope.ValidateUsers[0]);
			var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
			$mdDialog.show({
				controller: DialogController,
				scope: $scope,        // use parent scope in template
				preserveScope: true,
				templateUrl: 'Views/NgTemplates/ViewUser.html',
				parent: angular.element(document.body),
				clickOutsideToClose: true,
				fullscreen: useFullScreen
			})
			.then(function (answer) {
				$scope.status = 'You said the information was "' + answer + '".';
			}, function () {
				$scope.status = 'You cancelled the dialog.';
			});
			$scope.$watch(function () {
				return $mdMedia('xs') || $mdMedia('sm');
			}, function (wantsFullScreen) {
				$scope.customFullscreen = (wantsFullScreen === true);
			});
		}
		else {
			$scope.showAlertMessage('Select user to edit.');
		}
	}

	var viewFunction = function () {
		$scope.ShowWarning = false;
		$scope.PageEvents.UserAction = 'View';
		$scope.DisableSaveButton = true;
		$scope.ValidateUsers = $scope.selected;//= $filter('filter')($scope.UserList, { Selected: true });
		if (typeof $scope.ValidateUsers !== 'undefined' && $scope.ValidateUsers.length > 0) {
			FillUserScope($scope.ValidateUsers[0]);
			var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
			$mdDialog.show({
				controller: DialogController,
				scope: $scope,        // use parent scope in template
				preserveScope: true,
				templateUrl: 'Views/NgTemplates/EditUser.html',
				parent: angular.element(document.body),
				//targetEvent: event,
				clickOutsideToClose: true,
				fullscreen: useFullScreen
			})
			.then(function (answer) {
				$scope.status = 'You said the information was "' + answer + '".';
			}, function () {
				$scope.status = 'You cancelled the dialog.';
			});
			$scope.$watch(function () {
				return $mdMedia('xs') || $mdMedia('sm');
			}, function (wantsFullScreen) {
				$scope.customFullscreen = (wantsFullScreen === true);
			});
		}
		else {
			$scope.showAlertMessage('Select user to edit.');
		}
	}

	var editFunction = function (event) {
	    $scope.posting = false;
		$scope.ShowWarning = false;
		$scope.DisableSaveButton = false;
		$scope.PageEvents.UserAction = 'Edit';
		$scope.ValidateUsers = $scope.selected;//= $filter('filter')($scope.UserList, { Selected: true });
		if (typeof $scope.ValidateUsers !== 'undefined' && $scope.ValidateUsers.length > 0) {
			FillUserScope($scope.ValidateUsers[0]);
			var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
			$mdDialog.show({
				controller: DialogController,
				scope: $scope,        // use parent scope in template
				preserveScope: true,
				templateUrl: 'Views/NgTemplates/EditUser.html',
				parent: angular.element(document.body),
				targetEvent: event,
				clickOutsideToClose: true,
				fullscreen: useFullScreen
			})
			.then(function (answer) {
				$scope.status = 'You said the information was "' + answer + '".';
			}, function () {
				$scope.status = 'You cancelled the dialog.';
			});
			$scope.$watch(function () {
				return $mdMedia('xs') || $mdMedia('sm');
			}, function (wantsFullScreen) {
				$scope.customFullscreen = (wantsFullScreen === true);
			});
		}
		else {
			$scope.showAlertMessage('Select user to edit.');
		}
	}


	$scope.haveMoreRows = true;
	$scope.loading = true;
	$scope.lastSelectedLibrary = '';
	$scope.appsVar.SearchText = '';
	$scope.dtInstance = {};
	$scope.appsVar.selectedRecordId = '';
	$scope.ShowWarning = false;
	$scope.ErrorMessage = '';
	$scope.changePswrd = false;

	$scope.PreviousPageCursorList = [];
	$scope.CurrentPageCursor = '';
	$scope.NextPageCursor = '';
	$scope.PreviousPageCursor = '';
	$scope.PrefferedDB.SearchText = '';
	//$scope.SelectedgroupList = [];
	$scope.selectedChipGroups = [];
	var selectedDB = '';
	var requestModel = homeFactory.requestModelInstance();



	var Pdoffset = 1;
	var sgoffset = 1;
	var offset = 1;
	var goffset = 1;
	var limit = 10;
	var glimit = 12;
	var total = true;
	var PrefferedDBSearchTimeout;
	var SelectGroupSearchTimeout;
	var SelectAddRemoveGroupsSearchTimeout;    
	var FilterSearchTimeout;

	$scope.user = userFactory.userInitailValues();
	$scope.validation = userFactory.validations();
	//$scope.dtColumnDefs = datatableSettingsFactory.dtUserTableColumns;
	//$scope.tableSettings = datatableSettingsFactory.tableSettings();

	var grequestModel = homeFactory.requestModelInstance();
	var gsrequestModel = homeFactory.requestModelInstance();
	var pdbrequestModel = homeFactory.requestModelInstance();

	$scope.$on('onClearAllClicked', function () {
	    requestModel.filters = [];
	    getUsers();
	})

	$scope.$on('onUserAppSelected', function () {
		getUsers();
	})

	$scope.$on('InitializeTabContents', function () {
		userInitalize();
	})

	 

	function getUsers() {
		$scope.selected = [];
		requestModel.libraryName = $scope.vm.selectedLibrary;
		requestModel.isTotal = total;
		requestModel.searchText = $scope.appsVar.SearchText;
		if ($scope.vm.selectedApp.NoAppsPermission.trim().length > 0) return;
		if (!$scope.vm.selectedLibrary || $scope.vm.selectedLibrary.trim().length == 0) return;

		$scope.SortOrder = false;
		$scope.loading = true;
		$scope.lastSelectedLibrary = $scope.vm.selectedLibrary;
		//var promise = UserService.getUsers($scope.selectedLibrary, offset, limit, total, $scope.appsVar.SearchText, false);
		var promise = UserService.getUsers(requestModel, false)
		promise.then(function (response) {
			$scope.appsVar.initialLoading = false;

			if (response.data.rows.length > 0 && response.data.rows[0].cell.length > 0) {
				//$scope.isPrevDisable = offset <= 1;
				//$scope.isNextDisable = offset * limit >= response.data.total;
				$scope.query.totalCount = response.data.total;
				$scope.UserList = response.data.rows[0].cell[0];

				//$scope.loading = false;
				//$('#card-more-button').attr('disabled', 'disabled');
			}
			//}
			$scope.vm.selectedApp.ResponseCount = $scope.UserList.length;
			//$scope.loading = false;
			$timeout(function () {
				$('td').filter(function () {
					if (!$(this).hasClass("md-checkbox-cell")) {
						if ($(this).text().trim().length == 0) {

							$(this).html('&nbsp;');
						}
					}

				});
			});
		}, function () {
			alert('Data fetching failed.');
		});
		$scope.ScrollCounter = false;
	}

	$scope.loadMoreOnScrollEnd = function () {
		if ($scope.haveMoreRows) {
			getUsers();
			$scope.ScrollCounter = false;
		}
	};

	$scope.SelectCurrentRow = function (userModel, $event) {
		//   clearPanelData();
		if ($event.ctrlKey) {
			userModel.Selected ? userModel.Selected = false : userModel.Selected = true;
			$scope.PageEvents.Edit = 'undefined';
			$scope.PageEvents.ViewGeneralUser = 'undefined';
			$scope.PageEvents.AssignGroup = 'undefined';
			//$timeout(function () {
			//	refreshFabIcons();
			//});
		}
		else {
			this.getAllSelectedRows(userModel);
			$scope.PageEvents.Edit = editFunction;
			$scope.PageEvents.ViewGeneralUser = viewFunction;
			$scope.PageEvents.AssignGroup = AssignGroupFunction;
			//$timeout(function () {
			//	refreshFabIcons();
			//});
		}
		setContextMenuObject();
		//var selectedUserList = $scope.selected; //= $filter('filter')($scope.UserList, { Selected: true });
		//if (selectedUserList.length == 0) {           
		//	$('#card-more-button').attr('disabled', 'disabled');
		//} else {
		//	$('#card-more-button').removeAttr('disabled');          
		//}
	};

	//(function ($) {
	//	$(document).ready(function () {
	//		$('#card-more-button').attr('disabled', 'disabled');
	//	});
	//})(jQuery);


	$scope.getAllSelectedRows = function (userModel) {
		var selectedUserList = $scope.selected;//= $filter('filter')($scope.UserList, { Selected: true });
		angular.forEach(selectedUserList, function (tempItemModel) {
			tempItemModel.Selected = false; //set them all to false
		});
		userModel.Selected = true; //set the clicked one to true

		/*
		if ($('#tabbed').hasClass('tabbeddisplay')) {
			if ($('#btnTabBindData').hasClass('button-transform') == false) {
				viewAdminPanel(userModel);
				viewHelpDeskPanel(userModel);
			}
		}
		else if ($('#accordian').hasClass('tabbeddisplay')) {
			if ($('#btnAccordianBindData').hasClass('button-transform') == false) {
				viewAdminPanel(userModel);
				viewHelpDeskPanel(userModel);
			}
		}*/
	};



	function userInitalize() {

		$scope.lastSelectedLibrary = '';
		$scope.UserList = [];
		$scope.loading = true;
		$scope.haveMoreRows = true;
		//clearPanelData();
		requestModel.pagenumber = 1;
		$scope.query.page = 1;
		$scope.query.totalCount = 0;

		getUsers();
		//$scope.fillDBinUserList();
	}

	function FillUserScope(selectedUser) {
		$scope.user.UserId = selectedUser.UserId;
		$scope.user.FullName = selectedUser.FullName;
		$scope.user.Location = selectedUser.Location
		$scope.user.Phone = selectedUser.Phone;
		$scope.user.Ext = selectedUser.Ext;
		$scope.user.Fax = selectedUser.Fax;
		$scope.user.Email = selectedUser.Email == null ? '' : selectedUser.Email;
		$scope.user.IsExternalUser = selectedUser.IsExternalUser;
		$scope.user.Password = '';
		$scope.user.UserMustChangePassword = selectedUser.UserMustChangePassword;
		$scope.user.PasswordNeverExpires = selectedUser.PasswordNeverExpires;
		$scope.user.IsAllowLogon = selectedUser.IsAllowLogon;
		$scope.user.PreferredDatabase = selectedUser.PreferredDatabase;
		$scope.user.FileServer = selectedUser.FileServer;
		$scope.user.SecuredDocServer = selectedUser.SecuredDocServer;
		$scope.user.UserNos = selectedUser.UserNos;
		$scope.user.UserNum = selectedUser.UserNum;
		$scope.user.UserIdEx = selectedUser.UserIdEx;
		$scope.user.PasswordChangeDate = selectedUser.PasswordChangeDate;
	}

	$scope.addUser = function () {
	    $scope.posting = false;
	    $scope.validation.showMessage = true;
	    $scope.ShowWarning = false;
	    if ($scope.userForm.UserId.$invalid || $scope.user.Password == '' || $scope.validation.ConfirmPassword != $scope.user.Password || $scope.userForm.Email.$invalid) {
	        if ($scope.userForm.UserId.$invalid || $scope.userForm.Email.$invalid) {
	            $scope.AddUserSelectedTab = 0;
	        } else {
	            $scope.AddUserSelectedTab = 1;
	        }

	        return;
	    } else {
	        $scope.posting = true;
	        var promise = UserService.addUser($scope.user, $scope.vm.selectedLibrary, $scope.selectedChipGroups);
	        promise.then(function (response) {
	            $scope.posting = false;
	            if (response && response.data && response.data.Status) {
	                $mdDialog.hide();
	                $scope.ShowWarning = false;
	                $scope.showValidation = false;
	                //$scope.SelectedgroupList = [];
	                $scope.selectedChipGroups = [];
	                getUsers();
	                $scope.user = userFactory.userInitailValues();
	                $scope.validation = userFactory.validations();

	                $scope.AddUserModel.PasswordValue = '';
	                $scope.AddUserModel.ConfirmPasswordValue = '';
	            }
	            else {
	                $scope.ShowWarning = true;
	                $scope.ErrorMessage = response.data.Message;
	            }
	        }, function () {
	            $scope.posting = false;
	        });
	    }
	}

	$scope.cancelAddUserDialoge = function () {
		$scope.user = userFactory.userInitailValues();
		$scope.validation = userFactory.validations();
		$scope.ShowWarning = false;
		$scope.showValidation = false;
		$('#Add_Virtual_User').modal('hide');
	}

	$scope.$on('Search_Click', function (event, args) {
		userInitalize();
	});

	$rootScope.$on('onUserBulkDeleteClick', function () {
		$scope.Users = [];
		UserBulkDeleteClick();
	})

	function UserBulkDeleteClick() {
		$scope.Users = $filter('filter')($scope.UserList, { selected: true });
		var getUser = UserService.DeleteUser($scope.Users);
		getUser.then(function (response) {
			if (response.data == "success") {
				$scope.appsVar.selectedRecordId = '';
				userInitalize();
				$scope.showAlertMessage("Selected user(s) deleted successfully.");
			} else {
				$scope.showAlertMessage('Failed to delete selected user(s).');
			}
		}, function () {
			$scope.showAlertMessage('Failed to delete selected user(s).');
		});
	}

	$scope.singleDeleteConfirmMessageClick = function () {
		$scope.showSingleUserDeleteConfirmMessage('Are you sure to delete ' + $scope.appsVar.selectedRecordId + '?');
	};

	$scope.singleDeleteClick = function () {
		var s = $scope.appsVar.selectedRecordId;
		var getUser = UserService.DeleteUser(s);

		getUser.then(function (response) {
			if (response.data == "success") {
				$scope.appsVar.selectedRecordId = '';
				userInitalize();
				$scope.showAlertMessage("Selected user(s) deleted successfully.");
			} else {
				$scope.showAlertMessage('Failed to delete selected user(s).');
			}
		}, function () {
			$scope.showAlertMessage('Failed to delete selected user(s).');
		});

	};

	$rootScope.$on('onUserValidateBulkDeleteClick', function () {
		$scope.ValidateUsers = [];
		UserValidateBulkDeleteClick();
	})

	function UserValidateBulkDeleteClick(btnTemp) {
		$scope.ValidateUsers = $scope.selected;//= $filter('filter')($scope.UserList, { selected: true });
		if (typeof $scope.ValidateUsers !== 'undefined' && $scope.ValidateUsers.length > 0) {

			$scope.showConfirmMessage('Are you sure to delete selected user(s)?');
			return true;
		}
		else {
			$scope.showAlertMessage('Select user(s) to delete.');
			return false;
		}
	}

	$scope.editUser = function () {
	    $scope.validation.showMessage = true;
	    $scope.posting = false;

		if (($scope.user.Email != '' && !validateEmail($scope.user.Email))) {
			return;
		}
		$scope.posting = true;
		$scope.DisableSaveButton = true;

		var promise = UserService.editUser($scope.user, $scope.vm.selectedLibrary);
		promise.then(function (response) {
		    $scope.posting = false;
		    $scope.DisableSaveButton = false;
			if (response && response.data && response.data.Status) {
				$mdDialog.hide();
				getUsers();
				$scope.showValidation = false;

				//ResetUserModel();
				$scope.user = userFactory.userInitailValues();
				$scope.validation = userFactory.validations();
				$scope.ShowWarning = false;
			}
			else {
				$scope.ShowWarning = true;
				$scope.ErrorMessage = response.data.Message;
			}
		}, function () {
		    $scope.posting = false;
		    $scope.DisableSaveButton = false;
		});
	}

	function validateEmail(emailAddress) {
		var EMAIL_REGEXP = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$/;
		if (!EMAIL_REGEXP.test(emailAddress)) {
			return false;
		}
		return true;
	}

	$scope.isChangePswrd = function () {
		$scope.changePswrd = ($scope.changePswrd) ? false : true;
		return $scope.changePswrd;
	};

	$scope.showSingleUserDeleteConfirmMessage = function (message) {
		$("#Singleconfirm_popup").find('#singleconfirmMsgText').text(message);
		$("#Singleconfirm_popup").modal();
	}

	$scope.$on('Refresh_Click', function () {
		userInitalize();
	});

	$scope.singleEditClick = function (event) {
		$scope.ShowWarning = false;
		$scope.ValidateUsers = $scope.selected;//= $filter('filter')($scope.UserList, { UserId: $scope.appsVar.selectedRecordId });
		if (typeof $scope.ValidateUsers !== 'undefined' && $scope.ValidateUsers.length > 0) {
			FillUserScope($scope.ValidateUsers[0]);
			//$("#Edit_User").modal();UserController
			var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
			$mdDialog.show({
				//controller: DialogController,
				controller: DialogController,
				scope: $scope,        // use parent scope in template
				preserveScope: true,
				templateUrl: 'Views/NgTemplates/EditUser.html',
				parent: angular.element(document.body),
				targetEvent: event,
				clickOutsideToClose: true,
				fullscreen: useFullScreen,
				// scope: this.$new()
			})
			.then(function (answer) {
				$scope.status = 'You said the information was "' + answer + '".';
			}, function () {
				$scope.status = 'You cancelled the dialog.';
			});
			$scope.$watch(function () {
				return $mdMedia('xs') || $mdMedia('sm');
			}, function (wantsFullScreen) {
				$scope.customFullscreen = (wantsFullScreen === true);
			});
		}

	}

	$scope.$on('UserGroupAddRemoveMenu_Click', function () {
		var filterGroupList = $scope.selected;//= $filter('filter')($scope.UserList, { selected: true }, true);
		if (typeof filterGroupList != 'undefined' && filterGroupList.length > 0) {
			$scope.$broadcast('UserAddRemoveGroupButton_Click', filterGroupList[0].UserId);
		}
		else {
			$scope.showAlertMessage('Select user to add / remove groups.');
		}
	});

	$scope.PageEvents.Add = function () {
	    $scope.selectedChipGroups = [];
		gsrequestModel = homeFactory.requestModelInstance();
		$scope.GroupTableAddPagination = {
			order: 'name',
			limit: gsrequestModel.pageLength,
			page: gsrequestModel.pagenumber,
			totalCount: 0
		};
		$scope.AddUserModel.PasswordValue = '';
		$scope.AddUserModel.ConfirmPasswordValue = '';
		$scope.ShowWarning = false;
		$scope.validation.ConfirmPassword = '';
		$scope.validation.showMessage = false;
		$scope.posting = false;
		$scope.user = userFactory.userInitailValues();
		getAllGroupList();
		var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
		$mdDialog.show({
			// controller: UserController,
			controller: DialogController,
			scope: $scope,        // use parent scope in template
			preserveScope: true,  // do not forget this if use parent scope
			templateUrl: 'Views/NgTemplates/AddUser.html',
			parent: angular.element(document.body),
			clickOutsideToClose: true,
			fullscreen: useFullScreen,
			escapeToClose: false
		})
		.then(function (answer) {
			$scope.status = 'You said the information was "' + answer + '".';
		}, function () {
			$scope.status = 'You cancelled the dialog.';
		});
		$scope.$watch(function () {
			return $mdMedia('xs') || $mdMedia('sm');
		}, function (wantsFullScreen) {
			$scope.customFullscreen = (wantsFullScreen === true);
		});
	}


	$scope.hide = function () {
		$mdDialog.hide();
	};

	$scope.cancel = function () {
		$mdDialog.cancel();
	};

	$scope.answer = function () {
		$mdDialog.hide();
	};

	function DialogController($scope, $mdDialog) {
		$scope.hide = function () {
			$mdDialog.hide();
		};
		$scope.cancel = function () {
			$mdDialog.cancel();
		};
		$scope.answer = function () {
			$mdDialog.hide();
		    //$scope.SelectedgroupList = [];
			$scope.selectedChipGroups = [];
		};
	}

	$scope.onTableFilter = function (value, key) {


	    if (requestModel.filters.length > 0) {
	        requestModel.filters = jQuery.grep(requestModel.filters, function (filterItem) {
	            return filterItem.FilterKey !== key;
	        });
	    }


	    var filterValueList = [];
	    filterValueList[0] = value;

	    var filterItem = { 'FilterKey': key, 'FilterValues': filterValueList };
	    requestModel.filters.push(filterItem);

	    requestModel.pagenumber = 1;
	    $scope.query.page = 1;
	    $scope.query.totalCount = 0;

	    if (FilterSearchTimeout) $timeout.cancel(FilterSearchTimeout);

	    FilterSearchTimeout = $timeout(function () {
	        getUsers();
	    }, 2000);
	};

	$scope.ResetPassword = function () {
	    $scope.posting = false;
		$scope.validation.showMessage = true;
		if ($scope.user.Password == '' || $scope.validation.ConfirmPassword != $scope.user.Password) {
			$scope.posting = false;
			return;
		}
		else {
		    $scope.posting = true;
			$scope.ResetPasswordUsers = $scope.selected;//= $filter('filter')($scope.UserList, { Selected: true });
			if ($scope.ResetPasswordUsers.length > 0) {
				angular.forEach($scope.ResetPasswordUsers, function (temp) {
					temp.Password = $scope.user.Password; //set them all to false
					temp.UserMustChangePassword = $scope.user.UserMustChangePassword;
					temp.PasswordNeverExpires = $scope.user.PasswordNeverExpires;
				});
				//$scope.user.UserId = $scope.appsVar.rightClickMenuID;
				var ResetPaswdUser = UserService.ResetPasswordUser($scope.ResetPasswordUsers, $scope.vm.selectedLibrary);

				ResetPaswdUser.then(function (response) {
					$scope.posting = false;
					if (response && response.data && response.data.Status) {
						$mdDialog.hide();
						$scope.ShowWarning = false;
					}
					else {
						$scope.ShowWarning = true;
						$scope.ErrorMessage = response.data.rows[0].cell[2];
					}
				}, function () {
				    $scope.posting = false;
				});
			}
			else {
				$mdDialog.show(
				 $mdDialog.alert()
					 .parent(angular.element(document.querySelector('#popupContainer')))
					 .clickOutsideToClose(true)
					 .title('Alert')
					 .textContent('Please select a User.')
					 .ariaLabel('Update info dialog')
					 .ok('OK')
					);
			}
		}
	}

	$scope.$on('onsubTableFiltering', function (event, value, key) {
		if (grequestModel.filters.length > 0) {
			grequestModel.filters = jQuery.grep(grequestModel.filters, function (filterItem) {
				return filterItem.FilterKey !== key;
			});
		}
		//if (value.length == 0) return;

		var filterValueList = [];
		filterValueList[0] = value;

		var filterItem = { 'FilterKey': key, 'FilterValues': filterValueList };
		grequestModel.filters.push(filterItem);
		goffset = 1;
		getAllGroupList();
	})


	$scope.GroupSearchText = '';
	function getAllGroupList() {
		grequestModel.libraryName = $scope.vm.selectedLibrary;
		//grequestModel.pageLength = limit;
		grequestModel.searchText = $scope.AddRemoveGroups.SearchText;
		//grequestModel.pagenumber = goffset;

		if (grequestModel.filters.length == 0) {
			var filterItem = { 'FilterKey': 'GroupEnabled', 'FilterValues': ['Y'] };
			grequestModel.filters.push(filterItem);
		}

		if (!$scope.vm.selectedLibrary || $scope.vm.selectedLibrary.trim().length == 0) return;
		$scope.lastSelectedLibrary = $scope.vm.selectedLibrary;		
		var Group = GroupService.getGroups(grequestModel);
		Group.then(function (response) {
			$scope.appsVar.initialLoading = false;
			if (response) {
			    if (response.data.Status) {			      
				    $scope.GroupDetails = response.data.rows[0].cell[0];
				    $scope.ModelChipGroups = $scope.GroupDetails;
				    //if ((grequestModel.pagenumber * grequestModel.pageLength) < response.data.total) {
				    //    //var r = $('<input type="button" value="more"/>');
				    //    //$("ul li:last-child").append(r);
				    //    $("md-virtual-repeat-container ul").append('<li><input type="button" value="more" ng-click="moreClicked()"/></li>');
				    //}
				    //return deferred.Group;
					$scope.GroupTablePagination.totalCount = response.data.total;
					$scope.loading = false;
					var groupschecklist = [];
					angular.forEach($scope.GroupDetails, function (item) {
						groupschecklist.push(item.GroupName);
					});

					var promiseOne = GroupService.GetSelectedGroupsOfUsers($scope.vm.selectedLibrary, $scope.user.UserId, groupschecklist)
					promiseOne.then(function (response) {
						$scope.GroupInUserList = response.data.rows[0].cell[0];
						if ($scope.GroupCheckedFInal != null && $scope.GroupCheckedFInal.length > 0) {
							angular.forEach($scope.GroupCheckedFInal, function (GroupCheckedModel) {
								var filterGroupList = $filter('filter')($scope.GroupDetails, { GroupName: GroupCheckedModel.GroupName }, true);
								if (typeof filterGroupList != 'undefined' && filterGroupList.length > 0) {
									filterGroupList[0].Checked = true;
								}
							});
						}

						if ($scope.GroupInUserList != null && $scope.GroupInUserList.length > 0) {
							angular.forEach($scope.GroupInUserList, function (GroupCheckedModel) {
								var filterGroupList = $filter('filter')($scope.GroupDetails, { GroupName: GroupCheckedModel.GroupName }, true);
								if (typeof filterGroupList != 'undefined' && filterGroupList.length > 0) {
									filterGroupList[0].Checked = true;
								}
							});
						}

						if ($scope.GroupRemovedFInal != null && $scope.GroupRemovedFInal.length > 0) {
							angular.forEach($scope.GroupRemovedFInal, function (GroupCheckedModel) {
								var filterGroupList = $filter('filter')($scope.GroupDetails, { GroupName: GroupCheckedModel.GroupName }, true);
								if (typeof filterGroupList != 'undefined' && filterGroupList.length > 0) {
									filterGroupList[0].Checked = false;
								}
							});
						}

						if ($scope.CheckedGroupSelection) {//IsExternalUser
						    var groupsCheckedList = [];
						    var CheckedExternalList = [];
						    if ($scope.External) {
						        if ($scope.GroupCheckedFInal.length>0){
						            angular.forEach($scope.GroupCheckedFInal, function (item) {
						                if (item.GroupIsExternal)
						                CheckedExternalList.push(item);
						        });
						        var start = (grequestModel.pagenumber - 1) * grequestModel.pageLength;
						        for (i = start; i < (grequestModel.pageLength * grequestModel.pagenumber) ; i++) {
						            if (CheckedExternalList[i] != undefined)
						                groupsCheckedList.push(CheckedExternalList[i]);
						        }
						        $scope.GroupDetails = groupsCheckedList;
						        $scope.GroupTablePagination.totalCount = CheckedExternalList.length;
						        }
						        else {
						            $scope.GroupDetails = '';
						        }
						    }
						    else {
						        var start = (grequestModel.pagenumber - 1) * grequestModel.pageLength;
						        for (i = start; i < (grequestModel.pageLength * grequestModel.pagenumber) ; i++) {
						            if ($scope.GroupCheckedFInal[i]!=undefined)
						            groupsCheckedList.push($scope.GroupCheckedFInal[i]);
						        }
						        $scope.GroupDetails = groupsCheckedList;
						        $scope.GroupTablePagination.totalCount = $scope.GroupCheckedFInal.length;
						    }						    
						}

					}, function () {
						alert('Data fetching failed.');
					});




				}
			}
			$scope.vm.selectedApp.ResponseCount = $scope.GroupDetails.length;

		}, function () {
			alert('Data fetching failed.');
		});

	}

	function getAllGroupsInUser() {
	    if (!$scope.vm.selectedLibrary || $scope.vm.selectedLibrary.trim().length == 0) return;
	    $scope.lastSelectedLibrary = $scope.vm.selectedLibrary;
	    var promise = GroupService.getAllGroupsInUser($scope.vm.selectedLibrary, $scope.user.UserId)
		promise.then(function (response) {
			if (response.data.rows.length > 0 && response.data.rows[0].cell.length > 0) {
				$scope.GroupInUserList = response.data.rows[0].cell[0];
			}

		}, function () {
			alert('Data fetching failed.');
		});

	}

	$scope.PageEvents.AssignGroup = function (row) {
		$scope.IsShowErrorMessage = false;
		$scope.GroupCheckedFInal = [];
		$scope.GroupTablePagination = {
		    order: 'name',
		    limit: grequestModel.pageLength,
		    page: grequestModel.pagenumber,
		    totalCount: 0
		};
		getAllGroupList();
		if (row) {
			var UserId = $scope.appsVar.selectedRecordId;
			$scope.ValidateAddRemoveGroups = $filter('filter')($scope.UserList, { UserId: UserId });
		}
		else {
			$scope.ValidateAddRemoveGroups = $scope.selected; //= $filter('filter')($scope.UserList, { Selected: true });
		}
		if (typeof $scope.ValidateAddRemoveGroups != 'undefined' && $scope.ValidateAddRemoveGroups.length > 0) {
			angular.copy($scope.ValidateAddRemoveGroups[0], $scope.user);
			setTimeout(function () {
				getAllGroupsInUser();
				$scope.GroupCheckedFInal = [];
			}, 100);
			var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
			$mdDialog.show({
				controller: DialogController,
				scope: $scope,        // use parent scope in template
				preserveScope: true,
				templateUrl: 'Views/NgTemplates/AddRemoveGroups.html',
				parent: angular.element(document.body),
				clickOutsideToClose: true,
				fullscreen: useFullScreen
			})
			.then(function (answer) {
				$scope.status = 'You said the information was "' + answer + '".';
			}, function () {
				$scope.status = 'You cancelled the dialog.';
			});
			$scope.$watch(function () {
				return $mdMedia('xs') || $mdMedia('sm');
			}, function (wantsFullScreen) {
				$scope.customFullscreen = (wantsFullScreen === true);
			});
			return true;
		}
		else {
			$scope.showAlertMessage('Select a User first.');
			return false;
		}
	}

	$scope.SelectCurrentGroup = function (GroupModel, $event) {
		$scope.GroupSelected(GroupModel, $event)
		if ($event.ctrlKey) {
			GroupModel.Selected ? GroupModel.Selected = false : GroupModel.Selected = true;
		}
		else {
			this.getAllSelectedGroups(GroupModel);
		}
	};

	$scope.getAllSelectedGroups = function (GroupModel) {
		var selectedGroupList = $filter('filter')($scope.GroupDetails, { Selected: true });
		angular.forEach(selectedGroupList, function (tempItemModel) {
			tempItemModel.Selected = false; //set them all to false
		});
		GroupModel.Selected = true; //set the clicked one to true
	};

	$scope.GroupCheckedFInal = [];
	$scope.GroupRemovedFInal = [];
	$scope.GroupSelected = function (GroupModel, $event) {
		var isDisabled = false;
		var filterGroupList = $filter('filter')($scope.GroupInUserList, { GroupName: GroupModel.GroupName }, true);
		if (typeof filterGroupList != 'undefined' && filterGroupList.length > 0) {
			isDisabled = true;
		}

		if ($event.ctrlKey) {
			GroupModel.Checked ? GroupModel.Checked = false : GroupModel.Checked = true;
		}
		else {
			this.getAllCheckedGroups(GroupModel);
		}

		if (isDisabled) {

			if (GroupModel.Checked) {
				$scope.GroupRemovedFInal = $.grep($scope.GroupRemovedFInal, function (item, index) {
					return item.GroupName != GroupModel.GroupName;
				});

			} else {
				var filterUserListpush = $filter('filter')($scope.GroupRemovedFInal, { GroupName: GroupModel.GroupName }, true);
				if (typeof filterUserListpush == 'undefined' || filterUserListpush.length == 0) {
					$scope.GroupRemovedFInal.push(GroupModel);
				}

			}

		}
		else {

			//if (GroupModel.Checked) {
			//    $scope.GroupCheckedFInal.push(GroupModel);
			//} else {
			//    var filterUserListpop = $filter('filter')($scope.GroupCheckedFInal, { GroupName: GroupModel.GroupName }, true);
			//    if (typeof filterUserListpop == 'undefined' || filterUserListpop.length == 0) {
			//        $scope.GroupCheckedFInal.pop(GroupModel);
			//    }

			//}



			if (GroupModel.Checked) {
				var filterUserListpush = $filter('filter')($scope.GroupCheckedFInal, { GroupName: GroupModel.GroupName }, true);
				if (typeof filterUserListpush == 'undefined' || filterUserListpush.length == 0) {
					$scope.GroupCheckedFInal.push(GroupModel);
				}
			} else {

				$scope.GroupCheckedFInal = $.grep($scope.GroupCheckedFInal, function (item, index) {
					return item.GroupName != GroupModel.GroupName;
				});



			}
		}
	};

	$scope.getAllCheckedGroups = function (GroupModel) {
		GroupModel.Checked = !GroupModel.Checked; //set the clicked one to true
	};

	$scope.isAlreadyAvilable = function (GroupName) {
		var resultText = false;
		var filterGroupList = $filter('filter')($scope.GroupInUserList, { GroupName: GroupName }, true);
		if (typeof filterGroupList != 'undefined' && filterGroupList.length > 0) {
			resultText = true;
			var selectedGroupList = $filter('filter')($scope.GroupDetails, { GroupName: GroupName }, true);
			angular.forEach(selectedGroupList, function (tempItemModel) {
				tempItemModel.Checked = true; //set them all to false
			});
		}
		return resultText;
	}

	$scope.onGroupSearch = function () {
		goffset = 1;
		getAllGroupList();
	}

	$scope.PreviousPageButton_gClick = function () {
		$scope.SelAll.checked = false;
		//$scope.CurrentPageCursor = '';
		//if ($scope.PreviousPageCursorList && $scope.PreviousPageCursorList.length > 0)
		//    $scope.CurrentPageCursor = $scope.PreviousPageCursorList.pop();
		goffset -= 1;
		getAllGroupList()
	}

	$scope.NextPageButton_gClick = function () {
		$scope.SelAll.checked = false;
		//$scope.PreviousPageCursorList.push($scope.CurrentPageCursor);
		//$scope.CurrentPageCursor = $scope.NextPageCursor;
		goffset += 1;
		getAllGroupList()
	}

	$scope.AddSelectedGroup = function () {
		//var NewGroupsInUser = [];
		//var selectedGroupList = $filter('filter')($scope.GroupDetails, { Checked: true });
		//angular.forEach(selectedGroupList, function (tempItemModel) {

		//    var filterGroupList = $filter('filter')($scope.GroupInUserList, { GroupName: tempItemModel.GroupName }, true);
		//    if (typeof filterGroupList == 'undefined' || filterGroupList.length == 0) {
		//        NewGroupsInUser.push(tempItemModel);
		//    }
		//});
	    //var promise = GroupService.AddGroupsToUser($scope.selectedLibrary, $scope.user.UserId, NewGroupsInUser);
	    $scope.posting = true;
		var promise = GroupService.AddUserGroup($scope.vm.selectedLibrary, $scope.user.UserId, $scope.GroupCheckedFInal, $scope.GroupRemovedFInal);
		promise.then(function (response) {
			if (response.data.rows.length > 0) {
				if (response.data.rows[0].cell.length > 0) {

					if (response.data.rows[0].cell[2] == 'Success') {
						getUsers();
						$scope.showValidation = false;
						setTimeout(function () {
							//$('#Add_Virtual_User').modal('hide');
							$mdDialog.hide();
							$scope.ShowWarning = false;
							$scope.posting = false;
						}, 1500);
					}
					else {
					    $scope.posting = false;
						$scope.IsShowErrorMessage = true;
					}
					$scope.ShowWarning = true;
					$scope.ErrorMessage = response.data.rows[0].cell[2];

				}

			}
			$scope.posting = false;

		}, function () {
		    $scope.posting = false;
		});
	}

	$scope.$on('$destroy', function () {
		$scope.PageEvents.Add = 'undefined';
		$scope.PageEvents.Edit = 'undefined';
		$scope.PageEvents.Save = 'undefined';
		$scope.PageEvents.Delete = 'undefined';
		$scope.PageEvents.CancelDialog = 'undefined';
		$scope.PageEvents.ShowSubclassList = 'undefined';
		$scope.PageEvents.AddRole = 'undefined';
		$scope.PageEvents.ResetPasswordclicked = 'undefined';
		$scope.PageEvents.ViewAssignUser = 'undefined';
		$scope.PageEvents.AssignUser = 'undefined';
		$scope.PageEvents.AssignGroup = 'undefined';
		$scope.PageEvents.LockAccount = 'undefined';
		$scope.PageEvents.UnlockAccount = 'undefined';
		$scope.PageEvents.ViewGeneralUser = 'undefined';
	});
	//$scope.FilterExternalClicked = function () {
	//    grequestModel.GroupIsExternal = !$scope.FilterExternal;
	//    getAllGroupList();
	//}


	function getSelectlGroupList() {
	    grequestModel.libraryName = $scope.vm.selectedLibrary;
		//   grequestModel.Cursor = $scope.CurrentPageCursor;
		grequestModel.pageLength = glimit;
		grequestModel.searchText = $scope.selectGroup.SearchText;
		grequestModel.pagenumber = sgoffset;


		if (!$scope.vm.selectedLibrary || $scope.vm.selectedLibrary.trim().length == 0) return;
		$scope.lastSelectedLibrary = $scope.vm.selectedLibrary;
		var Group = GroupService.getGroups(grequestModel);

		Group.then(function (response) {
			$scope.appsVar.initialLoading = false;
			if (response) {
				if (response.data.Status) {

					$scope.isPrefferedsg_PrevDisable = sgoffset <= 1;
					$scope.isPrefferedsg_NextDisable = sgoffset * limit >= response.data.total;
					$scope.GroupDetails = response.data.rows[0].cell[0];


					//angular.forEach($scope.SelectedgroupList, function (item) {
					//    var result = $filter('filter')($scope.GroupDetails, { GroupName: item.GroupName });
					//    if (result && result.length > 0) {
					//        result[0].Checked = true;
					//    }
					//});


					//$scope.NextPageCursor = response.data.cursor;
					//$scope.haveMoreRows = response.data.moreRowsFound;
					//if ($scope.CurrentPageCursor == '')
					//    $scope.isPrefferedsg_PrevDisable = true;
					//else
					//    $scope.isPrefferedsg_PrevDisable = false;
					//$scope.isPrefferedsg_NextDisable = !response.data.moreRowsFound;
					$scope.loading = false;

					if ($scope.GroupCheckedFInal != null && $scope.GroupCheckedFInal.length > 0) {
						angular.forEach($scope.GroupCheckedFInal, function (GroupCheckedModel) {
							var filterGroupList = $filter('filter')($scope.GroupDetails, { GroupName: GroupCheckedModel.GroupName }, true);
							if (typeof filterGroupList != 'undefined' && filterGroupList.length > 0) {
								filterGroupList[0].Checked = true;
							}
						});
					}
					else {
						if ($scope.GroupInUserList != null && $scope.GroupInUserList.length > 0) {
							angular.forEach($scope.GroupInUserList, function (GroupCheckedModel) {
								var filterGroupList = $filter('filter')($scope.GroupDetails, { GroupName: GroupCheckedModel.GroupName }, true);
								if (typeof filterGroupList != 'undefined' && filterGroupList.length > 0) {
									filterGroupList[0].Checked = true;
								}
							});
						}
					}


				}
			}
			$scope.vm.selectedApp.ResponseCount = $scope.GroupDetails.length;

		}, function () {
			alert('Data fetching failed.');
		});

	}
	$scope.SelectPrefferedDatabase = function () {
		$scope.fillDBinUserList();
		$('#popup-add-preferdDb').slideToggle();
	}
	$scope.ClosePrefferedDatabase = function () {


	}
	$scope.SelectGroups = function ($event) {
		if ($event != undefined) {
			//var code = $event.keyCode || $event.which;
			var code = $event.screenX;
			if (code <= 0) {
				$event.preventDefault();
				return false;
			}
			else {
				getSelectGroupUser();
				$('#popup-add-groups').slideToggle();
			}
		}
		else {
			getSelectGroupUser();
			$('#popup-add-groups').slideToggle();
		}
	}


	$scope.fillDBinUserList = function () {
	    pdbrequestModel.libraryName = $scope.vm.selectedLibrary;
		pdbrequestModel.searchText = $scope.PrefferedDB.SearchText;

		var promise = DatabaseService.getDatabase(pdbrequestModel);
		promise.then(function (response) {
			if (response.data.rows.length > 0 && response.data.rows[0].cell.length > 0) {
			    $scope.DBList = response.data.rows[0].cell[0];
			    $scope.PreferredDataBaseTablePagination.totalCount = response.data.total;
				$scope.isPrefferedDB_PrevDisable = Pdoffset <= 1;
				$scope.isPrefferedDB_NextDisable = Pdoffset * limit >= response.data.total;

				//if ($scope.CurrentPageCursor == '')
				//    $scope.isPrefferedDB_NextDisable = true;
				//else
				//    $scope.isPrefferedDB_PrevDisable = false;

			} else {
				$scope.DBList = [];
				$scope.isPrefferedDB_PrevDisable = true;
				$scope.isPrefferedDB_NextDisable = true;
			}
		}, function () {
			alert('Data fetching failed.');
			$scope.isPrefferedDB_PrevDisable = true;
			$scope.isPrefferedDB_NextDisable = true;
		});
	}
	$scope.SelectCurrentDB = function (DbModel, $event) {
		//this.getAllSelectedDB(DbModel);
		selectedDB = DbModel.DatabaseName;
	};

	//$scope.getAllSelectedDB = function (DbModel) {
	//    var selectedUserList = $filter('filter')($scope.DBList, { Selected: true });
	//    angular.forEach(selectedUserList, function (tempItemModel) {
	//        tempItemModel.Selected = false; //set them all to false
	//    });
	//    DbModel.Selected = true; //set the clicked one to true
	//    if (DbModel.Selected) {
	//        $scope.user.PreferredDatabase = DbModel.DatabaseName;

	//    }
	//};
	$scope.AddDataDatabase = function () {
		$('#popup-add-preferdDb').slideToggle();
		$scope.user.PreferredDatabase = selectedDB;
	}
	$scope.cancelGroupDialog = function () {
		$('#popup-add-groups').slideToggle();
		// $scope.SelectedgroupList = [];
	}
	$scope.checkGroups = function (groupModal) {

		if (groupModal.Checked) {
			var filterUserListpush = $filter('filter')($scope.SelectedgroupList, { GroupName: groupModal.GroupName }, true);
			if (typeof filterUserListpush == 'undefined' || filterUserListpush.length == 0) {
				$scope.SelectedgroupList.push(groupModal);
			}
		} else {

			$scope.SelectedgroupList = $.grep($scope.SelectedgroupList, function (item, index) {
				return item.GroupName != groupModal.GroupName;
			});

		}
	}


	$scope.$watch(function () { return $scope.PrefferedDB.SearchText }, function (val) {
		if ($scope.PrefferedDB.SearchText.length > 0) {
			$scope.PrefferedDB.IsSearchTextFound = true;
		}
		if (PrefferedDBSearchTimeout) $timeout.cancel(PrefferedDBSearchTimeout);

		PrefferedDBSearchTimeout = $timeout(function () {
			if ($scope.PrefferedDB.IsSearchTextFound) {
				$scope.fillDBinUserList();
			}
		}, 2000);
	}, true);
	$scope.PreviousPageButton_PdbClick = function () {
		Pdoffset = Pdoffset - 1;
		$scope.fillDBinUserList();
	}

	$scope.NextPageButton_PdbClick = function () {
		Pdoffset = Pdoffset + 1;
		$scope.fillDBinUserList();
	}
	$scope.SearchPrefferedDB = function () {
		if (PrefferedDBSearchTimeout) $timeout.cancel(PrefferedDBSearchTimeout);
		Pdoffset = 1;
		$scope.fillDBinUserList();
	};

	$scope.cancelpreferdb = function () {
		$('#popup-add-preferdDb').slideToggle();
	}

	$scope.AddGroupToUser = function () {
		var ComaSep = '';
		$scope.user.Groups = '';
		angular.forEach($scope.SelectedgroupList, function (Item) {

			ComaSep = ComaSep + Item.GroupName + ", ";
		});
		$scope.user.Groups = ComaSep.slice(0, -2);

		$('#popup-add-groups').slideToggle();

	}

	$scope.$watch(function () { return $scope.selectGroup.SearchText }, function (val) {
		if ($scope.selectGroup.SearchText.length > 0) {
			$scope.selectGroup.IsSearchTextFound = true;
		}
		if (SelectGroupSearchTimeout) $timeout.cancel(SelectGroupSearchTimeout);

		SelectGroupSearchTimeout = $timeout(function () {
			if ($scope.selectGroup.IsSearchTextFound) {
				getSelectlGroupList();
			}
		}, 2000);
	}, true);

	$scope.$watch(function () { return $scope.AddRemoveGroups.SearchText }, function (val) {
		if ($scope.AddRemoveGroups.SearchText.length > 0) {
			$scope.AddRemoveGroups.IsSearchTextFound = true;
		}
		if (SelectAddRemoveGroupsSearchTimeout) $timeout.cancel(SelectAddRemoveGroupsSearchTimeout);

		SelectAddRemoveGroupsSearchTimeout = $timeout(function () {
			if ($scope.AddRemoveGroups.IsSearchTextFound) {
				getAllGroupList();
			}
		}, 2000);
	}, true);

	$scope.PreviousPageButton_PdbClick = function () {
		offset = offset - 1;
		$scope.fillDBinUserList();
	}

	$scope.NextPageButton_PdbClick = function () {
		offset = offset + 1;
		$scope.fillDBinUserList();
	}
	$scope.SearchSelectGroups = function () {
		if (SelectGroupSearchTimeout) $timeout.cancel(SelectGroupSearchTimeout);
		offset = 1;
		getSelectlGroupList();
	};
	$scope.PreviousPageButton_sgClick = function () {
		sgoffset = sgoffset - 1;
		$scope.CurrentPageCursor = '';
		if ($scope.PreviousPageCursorList && $scope.PreviousPageCursorList.length > 0)
			$scope.CurrentPageCursor = $scope.PreviousPageCursorList.pop();
		getSelectGroupUser();

	}

	$scope.NextPageButton_sgClick = function () {
		sgoffset = sgoffset + 1
		$scope.PreviousPageCursorList.push($scope.CurrentPageCursor);
		$scope.CurrentPageCursor = $scope.NextPageCursor;
		getSelectGroupUser();
	}


	$scope.SelectAll = function () {
		angular.forEach($scope.GroupDetails, function (GroupModel) {

			var isDisabled = false;
			var filterGroupList = $filter('filter')($scope.GroupInUserList, { GroupName: GroupModel.GroupName }, true);
			if (typeof filterGroupList != 'undefined' && filterGroupList.length > 0) {
				isDisabled = true;
			}


			GroupModel.Checked = $scope.SelAll.checked;


			if (isDisabled) {

				if (GroupModel.Checked) {
					$scope.GroupRemovedFInal = $.grep($scope.GroupRemovedFInal, function (item, index) {
						return item.GroupName != GroupModel.GroupName;
					});

				} else {
					var filterUserListpush = $filter('filter')($scope.GroupRemovedFInal, { GroupName: GroupModel.GroupName }, true);
					if (typeof filterUserListpush == 'undefined' || filterUserListpush.length == 0) {
						$scope.GroupRemovedFInal.push(GroupModel);
					}

				}

			}
			else {
				if (GroupModel.Checked) {
					var filterUserListpush = $filter('filter')($scope.GroupCheckedFInal, { GroupName: GroupModel.GroupName }, true);
					if (typeof filterUserListpush == 'undefined' || filterUserListpush.length == 0) {
						$scope.GroupCheckedFInal.push(GroupModel);
					}
				} else {

					$scope.GroupCheckedFInal = $.grep($scope.GroupCheckedFInal, function (item, index) {
						return item.GroupName != GroupModel.GroupName;
					});



				}
			}


		});
	}

	$scope.ExternalChanged = function () {
		goffset = 1;
		if ($scope.External) {
			var filterItem = { 'FilterKey': 'GroupIsExternal', 'FilterValues': ['Y'] };
			grequestModel.filters.push(filterItem);
		}
		else {
			angular.forEach(grequestModel.filters, function (reqModel) {
				if (reqModel.FilterKey == 'GroupIsExternal') {
					grequestModel.filters.pop(reqModel);
				}
			});
		}
		getAllGroupList();
		//if ($scope.CheckedGroupSelection) {
		//    var groupsCheckedList = [];
		//    angular.forEach($scope.GroupDetails, function (item) {
		//        if (item.Checked)
		//            groupsCheckedList.push(item);
		//    });
		//    $scope.GroupDetails = groupsCheckedList;
		//}
	}

	$scope.CheckedGroupSelectionChanged = function () {
	    goffset = 1;	 
	    getAllGroupList();
	}

	$scope.editViewUserContent = function () {
	    $scope.validation.showMessage = true;
	    $scope.posting = true;

		var promise = UserService.editUser($scope.user, $scope.vm.selectedLibrary);
		//var promise = UserService.editUser($scope.user, $scope.selectedLibrary);
		promise.then(function (response) {
			$scope.posting = false;
			if (response && response.data && response.data.Status) {
				$mdDialog.hide();
				getUsers();
				$scope.showValidation = false;

				$scope.user = userFactory.userInitailValues();
				$scope.validation = userFactory.validations();
				$scope.ShowWarning = false;
			}
			else {
				$scope.ShowWarning = true;
				$scope.ErrorMessage = response.data.Message;
			}
		}, function () {
		    $scope.posting = false;
		});
	}

	function getDatabaseByUser(userID, Password) {
		//$scope.SelectDataBase = $filter('filter')($scope.UserList, { Selected: true });
		var promise = UserService.getDBLibrariesByUser(userID);
		promise.then(function (response) {
			if (response.data.length > 0) {
				$scope.DBLibrariesByUser = response.data;
				$scope.user.PreferredDatabase = $scope.DBLibrariesByUser[0].DatabaseName;
				//$scope.selectedLibrary = $scope.DBLibrariesByUser[0].DatabaseName;
			}
		});
	}
	function getSelectGroupUser() {
	    gsrequestModel.libraryName = $scope.vm.selectedLibrary;
		//   grequestModel.Cursor = $scope.CurrentPageCursor;
		//gsrequestModel.pageLength = glimit;
		gsrequestModel.searchText = $scope.selectGroup.SearchText;
		//gsrequestModel.pagenumber = sgoffset;



		if (!$scope.vm.selectedLibrary || $scope.vm.selectedLibrary.trim().length == 0) return;
		$scope.lastSelectedLibrary = $scope.vm.selectedLibrary;
		var Group = GroupService.getGroups(gsrequestModel);

		Group.then(function (response) {
			$scope.appsVar.initialLoading = false;
			if (response) {
				if (response.data.Status) {

					$scope.isPrefferedsg_PrevDisable = sgoffset <= 1;
					$scope.isPrefferedsg_NextDisable = sgoffset * limit >= response.data.total;
					$scope.GroupDetails = response.data.rows[0].cell[0];

					$scope.GroupTableAddPagination.totalCount=response.data.total;
					angular.forEach($scope.SelectedgroupList, function (item) {
						var result = $filter('filter')($scope.GroupDetails, { GroupName: item.GroupName });
						if (result && result.length > 0) {
							result[0].Checked = true;
						}
					});
					$scope.loading = false;
				}
			}
			$scope.vm.selectedApp.ResponseCount = $scope.GroupDetails.length;

		}, function () {
			alert('Data fetching failed.');
		});

	}

	$scope.ClearUserClick = function () {
		$scope.AddRemoveGroups.SearchText = '';
		$scope.PrefferedDB.SearchText = '';
		$scope.selectGroup.SearchText = '';
	}

	$scope.AssignSecurityTemplateObject = {
	    IsPosting: false,
	    IsShowErrorMsg: false,
	    IsShowSuccessMsg: false,
	    ErrorMessage: '',
	    OldTemplateName: '',
	    SelectedUserId: '',
	    TemplateModel: securityTemplateFactory.templateInitailValues(),

	    showDialog: function (userId, templateName) {
	        $scope.AssignSecurityTemplateObject.SelectedUserId = userId;
	        $scope.AssignSecurityTemplateObject.IsShowErrorMsg = false;
	        $scope.AssignSecurityTemplateObject.IsPosting = false;
	        $scope.AssignSecurityTemplateObject.IsShowSuccessMsg = false;
	        $scope.AssignSecurityTemplateObject.ErrorMessage = '';
	        $scope.AssignSecurityTemplateObject.OldTemplateName = templateName;
	        $scope.AssignSecurityTemplateObject.TemplateModel = securityTemplateFactory.templateInitailValues();
	        $scope.selectedSecurityChipGroups = [];

	        var dbReader = SecurityTemplateService.getUserTemplate($scope.vm.selectedLibrary, userId);
	        dbReader.then(function (response) {
	            if (response && response.data) {
	                $scope.AssignSecurityTemplateObject.OldTemplateName = response.data.TemplateName;
	                $scope.AssignSecurityTemplateObject.TemplateModel = response.data;
	                $scope.selectedSecurityItem = response.data.TemplateName;
	                //$scope.SearchFormObject.TableItemList = [];
	                //$scope.SearchFormObject.TableItemList = $scope.AssignSecurityTemplateObject.TemplateModel;
	            }
	        }, function () {

	        });

	        var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;

	        var dialogObject = {
	            controller: DialogController,
	            scope: $scope,
	            preserveScope: true,
	            templateUrl: 'Views/NgTemplates/AssignGroupSecurityTemplate.html',
	            parent: angular.element(document.body),
	            targetEvent: null,
	            clickOutsideToClose: true,
	            fullscreen: useFullScreen
	        };
	        $mdDialog.show(dialogObject)
			.then(function (answer) {
			    $scope.status = '';
			}, function () {
			    $scope.status = '';
			});
	        $scope.$watch(function () {
	            return $mdMedia('xs') || $mdMedia('sm');
	        }, function (wantsFullScreen) {
	            $scope.customFullscreen = (wantsFullScreen === true);
	        });
	    },

	    closeDialog: function () {
	        $mdDialog.cancel();
	        $scope.AssignSecurityTemplateObject.SelectedUserId = '';
	        $scope.AssignSecurityTemplateObject.IsShowErrorMsg = false;
	        $scope.AssignSecurityTemplateObject.IsPosting = false;
	        $scope.AssignSecurityTemplateObject.IsShowSuccessMsg = false;
	        $scope.AssignSecurityTemplateObject.ErrorMessage = '';
	        $scope.AssignSecurityTemplateObject.OldTemplateName = '';
	        $scope.AssignSecurityTemplateObject.TemplateModel = null;
	    },

	    openSearchList: function () {
	        var searchArg = { CaptionType: 'SecurityTemplate', DisplayText: 'Security Template' };
	        $rootScope.$broadcast('OpenSearchList_Click', searchArg);
	        $('#popup-add-search-list').slideToggle();
	    },

	    viewTemplateDetail: function (selectedSecurityTemplate) {
	        //$scope.AssignSecurityTemplateObject.TemplateName = selectedSecurityTemplate.TemplateName;
	        $scope.AssignSecurityTemplateObject.TemplateModel = selectedSecurityTemplate;

	    },
	    assignTemplate: function () {
	        $scope.AssignSecurityTemplateObject.IsPosting = true;
	        var dbWriter = UserService.AssignSecurity($scope.vm.selectedLibrary, $scope.AssignSecurityTemplateObject.SelectedUserId,
                $scope.AssignSecurityTemplateObject.OldTemplateName, $scope.AssignSecurityTemplateObject.TemplateModel.TemplateName);

	        dbWriter.then(function (response) {
	            if (response && response.data && response.data.Status) {
	                $scope.AssignSecurityTemplateObject.closeDialog();
	                $scope.AssignSecurityTemplateObject.IsShowSuccessMsg = false;
	            }
	            else {
	                $scope.AssignSecurityTemplateObject.ErrorMessage = response.data.Message && response.data.Message.trim().length > 0 ? response.data.Message : '';
	                $scope.AssignSecurityTemplateObject.IsShowErrorMsg = response.data.Message && response.data.Message.trim().length > 0;
	            }
	            $scope.AssignSecurityTemplateObject.IsPosting = false;

	        }, function () {

	        });
	    }
	};

	$scope.$on('SearchTableRow_Selected', function (event, args) {
		$('#popup-add-search-list').slideToggle();
		if (args && args.length > 0) {
			$scope.AssignSecurityTemplateObject.viewTemplateDetail(args[0]);
		}
	});

	$scope.$on('SearchTableRow_Cancelled', function (event, args) {
		$('#popup-add-search-list').slideToggle();
	});

	//new table intgration events
	$scope.selected = [];

	$scope.query = {
		order: 'name',
		limit: requestModel.pageLength,
		page: requestModel.pagenumber,
		totalCount: 0
	};

	$scope.onPaginate = function (page, limit) {
		requestModel.pagenumber = page;
		requestModel.pageLength = limit;

		getUsers();
		$scope.promise = $timeout(function () {

		}, 2000);
	};

	$scope.deSelect = function (item) {
		setContextMenuObject();
	};

	$scope.onSelect = function (item) {
		setContextMenuObject();
	};

	$scope.log = function (item) {

	};

	$scope.loadStuff = function () {
		$scope.promise = $timeout(function () {

		}, 2000);
	};

	$scope.onReorder = function (order) {

		console.log('Scope Order: ' + $scope.query.order);
		console.log('Order: ' + order);

		$scope.promise = $timeout(function () {

		}, 2000);
	};

	$scope.GroupTablePagination = {
	    order: 'name',
	    limit: grequestModel.pageLength,
	    page: 	grequestModel.pagenumber,
	    totalCount: 0
	};

	$scope.PreferredDataBaseTablePagination = {
	    order: 'DatabaseName',
	    limit: grequestModel.pageLength,
	    page: grequestModel.pagenumber,
	    totalCount: 0
	};
	 
 
 
	$scope.onPaginateGroupList = function (page, limit) {
	    grequestModel.pageLength = limit;
	    grequestModel.pagenumber = page;    
	    getAllGroupList();
	   
	};

	$scope.onDatabasePaginate = function (page, limit) {
	    grequestModel.pageLength = limit;
	    grequestModel.pagenumber = page;
	    $scope.fillDBinUserList();

	};

	$scope.GroupTableAddPagination = {
	    order: 'name',
	    limit: gsrequestModel.pageLength,
	    page: gsrequestModel.pagenumber,
	    totalCount: 0
	};


	$scope.onPaginateGroupAddList = function (page, limit) {
	    gsrequestModel.pageLength = limit;
	    gsrequestModel.pagenumber = page;
	    getSelectGroupUser();

	};
	

    $scope.selectedChipGroups = [];
    $scope.autocompleteDemoRequireMatch = true;
    $scope.selectedItem = null;
    $scope.searchText = null;
    $scope.querySearch = querySearch;
    $scope.ModelChipGroups = [];

    $scope.transformChip = transformChip;
    function transformChip(chip) {
        if (angular.isObject(chip)) {
            return chip;
        }
        return { GroupName: chip, GroupFullName: 'new' }
    }

    function querySearch(query) {       
        if (grequestModel.filters.length > 0) {
            grequestModel.filters = jQuery.grep(grequestModel.filters, function (filterItem) {
                return filterItem.FilterKey !== 'GroupName';
            });
        }
        var filterValueList = [];
        filterValueList[0] = query;

        var filterItem = { 'FilterKey': 'GroupName', 'FilterValues': filterValueList };
        grequestModel.filters.push(filterItem);
        grequestModel.pagenumber = 1;
        getAllGroupList(); 
        var results = $scope.ModelChipGroups;
        return results;  
    }

    $scope.$on('FilterClicked', function () {
        $scope.filtershow = !$scope.filtershow;
    });

    $scope.selectedSecurityChipGroups = [];
    $scope.autocompleteSecurityMatch = true;
    $scope.selectedSecurityItem = null;
    $scope.searchSecurityText = null;
    $scope.querySecuritySearch = querySecuritySearch;

    $scope.transformTemplateChip = transformChip;
    function transformChip(chip) {
        if (angular.isObject(chip)) {
            return chip;
        }
        return { TemplateName: chip, Description: 'new' }
    }

    function querySecuritySearch(query) {
        if ($scope.selectedSecurityChipGroups.length <= 0) {
            var results = $scope.SearchFormObject.TableItemList;
            return results;
        }
        else {
            var results = [];
            return results;
        }
    }

    function GetSecurityTemplates() {
        $scope.SearchFormObject = {
            RequestModel: homeFactory.requestModelInstance(),
            TableItemList: []
        };
        $scope.SearchFormObject.RequestModel.libraryName = $scope.selectedLibrary;
        $scope.SearchFormObject.RequestModel.pagenumber = 1;
        $scope.SearchFormObject.RequestModel.pageLength = 10;
        $scope.SearchFormObject.RequestModel.isTotal = true;
        var TemplateList = SecurityTemplateService.getServiceList($scope.SearchFormObject.RequestModel);
        TemplateList.then(function (response) {
            if (response.data && response.data.rows && response.data.rows.length > 0 && response.data.rows[0].cell && response.data.rows[0].cell.length > 0) {
                $scope.SearchFormObject.TableItemList = response.data.rows[0].cell[0];
                //$scope.TablePagination.totalCount = response.data.total;
            }
            $scope.IsLoading = false;
        }, function () {
            $scope.IsLoading = false;
            $scope.showAlertMessage('Failed to fetch security template fetching.');
        });
    }

};