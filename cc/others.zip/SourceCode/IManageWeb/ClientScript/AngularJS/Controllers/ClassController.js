﻿app.controller("ClassController", ClassController);
ClassController.$inject = ['$scope', '$timeout', 'ClassService', 'ManagementService', 'classFactory', '$filter', '$mdDialog', '$mdMedia', 'homeFactory'];

function ClassController($scope, $timeout, ClassService, ManagementService, classFactory, $filter, $mdDialog, $mdMedia, homeFactory) {

    var requestModel = homeFactory.requestModelInstance();
    var subRequestModel = homeFactory.requestModelInstance();
    var subClassListSearchTimeout;
    var isSubClassListSearchTextDirty = false;

    $scope.SelectedClassList = [];
    $scope.SubClassListSearchText = '';
    $scope.SubclassList = [];
    $scope.SelectedSubclassList = [];
    $scope.ClassList = [];
    $scope.ClassModel = classFactory.classInitailValues();
    $scope.SubClassModel = classFactory.classInitailValues();
    $scope.generalSettings = classFactory.generalSettings;
    $scope.validation = classFactory.validations();

    $scope.ClassListPagination = {
        limit: requestModel.pageLength,
        page: requestModel.pagenumber,
        totalCount: 0
    };

    $scope.SubClassListPagination = {
        limit: subRequestModel.pageLength,
        page: subRequestModel.pagenumber,
        totalCount: 0
    };

    $scope.ContextMenuFunctions = {
        Edit: function () { $scope.PageEvents.Edit(); },
        Delete: function () { $scope.PageEvents.Delete(); },
        DisplaySubClassList: function () { $scope.PageEvents.ShowSubclassList(); }
    };

    function setContextMenuObject() {
        $scope.menuList = [
            {
                Label: 'Edit',
                Icon: 'img/icons/edit.svg',
                onClick: $scope.ContextMenuFunctions.Edit,
                Enable: $scope.SelectedClassList.length == 1
            },
        {
            Label: 'Delete',
            Icon: 'img/icons/delete.svg',
            onClick: $scope.ContextMenuFunctions.Delete,
            Enable: $scope.SelectedClassList.length > 0
        },
         {
             Label: $scope.appsVar.tooltipValue,
             Icon: 'img/icons/class_blue.svg',
             onClick: $scope.ContextMenuFunctions.DisplaySubClassList,
             Enable: $scope.SelectedClassList.length == 1
         },
        ];
    };

    $scope.applyFilter = function (key, ctrlId) {
        var filterValue = $('#' + ctrlId).val().trim();

        if (requestModel.filters.length > 0) {
            requestModel.filters = jQuery.grep(requestModel.filters, function (filterItem) {
                return filterItem.FilterKey !== key;
            });
        }
        if (filterValue.length == 0) return;

        var filterValueList = [];
        filterValueList[0] = filterValue;

        var filterItem = { 'FilterKey': key, 'FilterValues': filterValueList };
        requestModel.filters.push(filterItem);

        fillClassList();
    };

    $scope.$on('onClearAllClicked', function () {
        requestModel.filters = [];
        fillClassList();
    })

    function fillClassList() {
        $scope.SelectedClassList = [];
        requestModel.libraryName = $scope.vm.selectedLibrary;
        requestModel.searchText = $scope.appsVar.SearchText;
        $scope.ClassList = [];
        $scope.ClassListPagination.totalCount = 0;      

        var promiseClass = ClassService.getClasses(requestModel);

        promiseClass.then(function (response) {
            $scope.appsVar.initialLoading = false;
            if (response.data && response.data.rows && response.data.rows.length > 0) {
                if (response.data.rows[0].cell && response.data.rows[0].cell.length > 0) {
                    $scope.ClassList = response.data.rows[0].cell[0];
                    $scope.ClassListPagination.totalCount = response.data.total;

                    var subClassDisplayText = $filter('filter')($scope.appsVar.CaptionsList, { MetaDataItem: 'SUBCLASS' });
                    if (typeof subClassDisplayText !== 'undefined' && subClassDisplayText.length > 0) {
                        $scope.appsVar.tooltipValue = subClassDisplayText[0].DisplayText;
                    }
                }
            }
        }, function () {
            alert('Data fetching failed.');
        });
    }


    $scope.$on('Refresh_Click', function () {
        fillClassList();
    });

    $scope.$on('Search_Click', function () {
        requestModel.pagenumber = 1;
        fillClassList();
    });

    $scope.$on('onTableSorting', function (object, sortFiled) {
        requestModel.pagenumber = 1;
        fillClassList();
    });

    $scope.SelectCurrentRow = function (classModel, $event) {
        if ($event.ctrlKey) {
            classModel.Selected ? classModel.Selected = false : classModel.Selected = true;
            $scope.PageEvents.Delete = ClassDeleteFunction;
            $scope.PageEvents.Edit = undefined;
        }
        else {
            this.getAllSelectedRows($scope.ClassList, classModel);
            $scope.PageEvents.Delete = ClassDeleteFunction;
            $scope.PageEvents.Edit = ClassEditFunction;
        }
        var selectedUserList = $scope.SelectedClassList;
        if (selectedUserList.length == 0) {
            $('#card-more-button').attr('disabled', 'disabled')
        } else {
            $('#card-more-button').removeAttr('disabled')
        }
    };

    (function ($) {
        $(document).ready(function () {
            $('#card-more-button').attr('disabled', 'disabled');
        });
    })(jQuery);

    function Initalize() {
        $scope.ClassListPagination.page = 1;
        requestModel.pagenumber = 1;
        requestModel.filters = [];
        fillClassList();
    }

    $scope.$on('onTableFiltering', function (event, value, key) {
        if (requestModel.filters.length > 0) {
            requestModel.filters = jQuery.grep(requestModel.filters, function (filterItem) {
                return filterItem.FilterKey !== key;
            });
        }
        var filterValueList = [];
        filterValueList[0] = value;

        var filterItem = { 'FilterKey': key, 'FilterValues': filterValueList };
        requestModel.filters.push(filterItem);

        $scope.ClassListPagination.page = 1;
        requestModel.pagenumber = 1;
        fillClassList();
    });


    Initalize();

    $scope.$on('$destroy', function () {
        $scope.PageEvents.Add = 'undefined';
        $scope.PageEvents.Edit = 'undefined';
        $scope.PageEvents.Save = 'undefined';
        $scope.PageEvents.Delete = 'undefined';
        $scope.PageEvents.CancelDialog = 'undefined';
        $scope.PageEvents.ShowSubclassList = 'undefined';
        $scope.PageEvents.AddRole = 'undefined';
        $scope.PageEvents.ResetPasswordclicked = 'undefined';
        $scope.PageEvents.ViewAssignUser = 'undefined';
        $scope.PageEvents.AssignUser = 'undefined';
        $scope.PageEvents.AssignGroup = 'undefined';
    });

    ///Class Add and Edit

    $scope.PageEvents.Add = function () {
        $scope.validation.showMessage = false;
        $scope.validation.showInformationMessage = false;
        $scope.ShowWarning = false;
        $scope.posting = false;
        $scope.PageEvents.UserAction = 'Add';
        $scope.ClassModel = classFactory.classInitailValues();
        $scope.generalSettings.PopupTitle = 'Add Class';

        var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
        $mdDialog.show({
            controller: DialogController,
            scope: $scope,
            preserveScope: true,
            templateUrl: 'Views/NgTemplates/AddClass.html',
            parent: angular.element(document.body),
            clickOutsideToClose: true,
            fullscreen: useFullScreen
        })
        .then(function (answer) {
            //$scope.status = 'You said the information was "' + answer + '".';
        }, function () {
            //$scope.status = 'You cancelled the dialog.';
        });
        $scope.$watch(function () {
            return $mdMedia('xs') || $mdMedia('sm');
        }, function (wantsFullScreen) {
            $scope.customFullscreen = (wantsFullScreen === true);
        });
    };

    $scope.PageEvents.Edit = function () {
        $scope.validation.showMessage = false;
        $scope.validation.showInformationMessage = false;
        $scope.ShowWarning = false;
        $scope.posting = false;
        $scope.ClassModel = classFactory.classInitailValues();
        if (!$scope.SelectedClassList || $scope.SelectedClassList.length == 0) return;

        $scope.PageEvents.UserAction = 'Edit';
        $scope.generalSettings.PopupTitle = 'Edit Class';
        $scope.ClassModel = classFactory.bindClassValues($scope.SelectedClassList[0]);

        var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
        $mdDialog.show({
            controller: DialogController,
            scope: $scope,
            preserveScope: true,
            templateUrl: 'Views/NgTemplates/AddClass.html',
            parent: angular.element(document.body),
            clickOutsideToClose: true,
            fullscreen: useFullScreen
        })
        .then(function (answer) {
            $scope.status = '';
        }, function () {
            $scope.status = '';
        });
        $scope.$watch(function () {
            return $mdMedia('xs') || $mdMedia('sm');
        }, function (wantsFullScreen) {
            $scope.customFullscreen = (wantsFullScreen === true);
        });
    };

    $scope.PageEvents.Save = function () {
        $scope.validation.showMessage = true;
        if ($scope.ClassModel.Description == '' || $scope.ClassModel.Description == undefined || $scope.ClassModel.Alias == '') {
            return;
        }
        $scope.posting = true;
        var requiredFieldsList = [];

        if ($scope.PageEvents.UserAction == 'Add') {
            var promiseAdd = ClassService.addClass($scope.vm.selectedLibrary, $scope.ClassModel, requiredFieldsList);
            promiseAdd.then(function (response) {
                $scope.validation.showMessage = false;
                $scope.posting = false;
                $scope.validation.showInformationMessage = false;
                $scope.ShowWarning = false;

                if (response && response.data && response.data.Status) {
                    $mdDialog.cancel();
                    $scope.ClassModel = classFactory.classInitailValues();
                    fillClassList();
                }
                else {
                    $scope.ShowWarning = true;
                    $scope.ErrorMessage = response.data.Message;
                }
            }, function () {
                alert('Error in updating record');
            });
        } else {
            var promiseAdd = ClassService.editClass($scope.vm.selectedLibrary, $scope.ClassModel, requiredFieldsList);
            promiseAdd.then(function (response) {
                $scope.validation.showMessage = false;
                $scope.validation.showInformationMessage = false;
                $scope.ShowWarning = false;
                $scope.posting = false;

                if (response && response.data && response.data.Status) {
                    $mdDialog.cancel();
                    $scope.ClassModel = classFactory.classInitailValues();
                    fillClassList();
                }
                else {
                    $scope.ShowWarning = true;
                    $scope.ErrorMessage = response.data.Message;
                }
            }, function () {
                alert('Error in updating record');
            });
        }
    };

    $scope.PageEvents.Delete = function (event) {

        if (!$scope.SelectedClassList || $scope.SelectedClassList.length == 0) {

            $mdDialog.show(
                       $mdDialog.alert()
                           .parent(angular.element(document.querySelector('#popupContainer')))
                           .clickOutsideToClose(true)
                           .title('Alert')
                           .textContent('Please select Class to delete.')
                           .ariaLabel('Delete info dialog')
                           .ok('OK')
                           .targetEvent(event)
                   );
            return;
        }

        var confirm = $mdDialog.confirm()
       .title('Delete Class')
       .textContent('Are you sure to delete selected Class(s)?')
       .ariaLabel('Delete Class')
       .targetEvent(event)
       .ok('Proceed')
       .cancel('Cancel');
        $mdDialog.show(confirm).then(function () {
            $mdDialog.show(
                $mdDialog.alert()
               .parent(angular.element(document.body))
               .clickOutsideToClose(true)
               .title('Delete Class')
               .textContent('You are deleting the selected Class(s).')
               .ariaLabel('Delete Class')
               .ok('OK')
               ).then(function () {
                   var promise = ClassService.deleteClass($scope.vm.selectedLibrary, $scope.SelectedClassList);
                   promise.then(function (response) {
                       if (response.data.length > 0) {
                           Initalize();
                       }
                   }, function () {
                       //$scope.status = 'You decided to keep your debt.';
                   });
               });
        });
    };

    $scope.onClassListPaginate = function (page, limit) {
        requestModel.pagenumber = page;
        requestModel.pageLength = limit;
        fillClassList();

        $scope.promise = $timeout(function () {
        }, 2000);
    };

    $scope.onSelectClassRow = function (item) {
        setContextMenuObject();
    };

    $scope.onDeselectClassRow = function (item) {
        setContextMenuObject();
    };

    $scope.loadStuff = function () {
        $scope.promise = $timeout(function () {
        }, 2000);
    };

    function DialogController($scope, $mdDialog) {
        $scope.hide = function () {
            $mdDialog.hide();
        };
        $scope.cancel = function () {
            $mdDialog.cancel();
        };
        $scope.answer = function () {
            $mdDialog.hide();
        };
    }

    $scope.PageEvents.CancelDialog = function () {
        $mdDialog.cancel();
    }


    function initilizeSubClassObject() {
        $scope.SubClassListSearchText = '';
        $scope.SubclassList = [];
        $scope.SelectedSubclassList = [];
        subRequestModel = homeFactory.requestModelInstance();

        $scope.SubClassListPagination.limit = subRequestModel.pageLength;
        $scope.SubClassListPagination.page = subRequestModel.pagenumber;
        $scope.SubClassListPagination.totalCount = 0;
        $scope.fillSubClassList();
    }

    $scope.PageEvents.ShowSubclassList = function () {
        if (typeof $scope.SelectedClassList === 'undefined' || $scope.SelectedClassList.length == 0) {
            return;
        }
        initilizeSubClassObject();
        var subClassDisplayText = $filter('filter')($scope.appsVar.CaptionsList, { MetaDataItem: 'SUBCLASS' });
        if (typeof subClassDisplayText !== 'undefined' && subClassDisplayText.length > 0) {
            $scope.appsVar.tooltipValue = subClassDisplayText[0].DisplayText;
        }

        var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
        $mdDialog.show({
            controller: DialogController,
            scope: $scope,
            preserveScope: true,
            templateUrl: 'Views/NgTemplates/SubclassList.html',
            parent: angular.element(document.body),
            clickOutsideToClose: true,
            fullscreen: useFullScreen
        })
        .then(function (answer) {
            $scope.status = '';
        }, function () {
            $scope.status = '';
        });
        $scope.$watch(function () {
            return $mdMedia('xs') || $mdMedia('sm');
        }, function (wantsFullScreen) {
            $scope.customFullscreen = (wantsFullScreen === true);
        });

    };

    $scope.fillSubClassList = function () {
        subRequestModel.libraryName = $scope.vm.selectedLibrary;
        subRequestModel.searchText = $scope.SubClassListSearchText;

        $scope.SubclassList = [];
        $scope.SelectedSubclassList = [];
        $scope.SubClassListPagination.totalCount = 0;

        var promise = ClassService.getSubClasses(subRequestModel, $scope.SelectedClassList[0].Alias);
        promise.then(function (response) {
            if (response && response.data && response.data.rows && response.data.rows.length > 0) {
                if (response.data.rows[0].cell && response.data.rows[0].cell.length > 0) {
                    $scope.SubclassList = response.data.rows[0].cell[0];
                    $scope.SubClassListPagination.totalCount = response.data.total;
                }
            }
        }, function () {
            alert('Data fetching failed.');
        });
    };


    $scope.onSubClassListPaginate = function (page, limit) {
        subRequestModel.pagenumber = page;
        subRequestModel.pageLength = limit;
        $scope.fillSubClassList();
    };

    $scope.onSelectSubClassRow = function (item) {
        //$scope.SelectedSubclassList
    };

    $scope.onDeselectSubClassRow = function (item) {
        //setContextMenuObject();
    };

    $scope.$watch(function () { return $scope.SubClassListSearchText }, function (val) {
        if ($scope.SubClassListSearchText.length > 0) {
            isSubClassListSearchTextDirty = true;
        }
        if (subClassListSearchTimeout) $timeout.cancel(subClassListSearchTimeout);

        subClassListSearchTimeout = $timeout(function () {
            if (isSubClassListSearchTextDirty) {
                $scope.SubClassList_SearchClick();
            }
        }, 2000);
    }, true);

    $scope.SubClassList_SearchClick = function () {
        if (subClassListSearchTimeout) $timeout.cancel(subClassListSearchTimeout);
        $scope.SubClassListPagination.page = 1;
        subRequestModel.pagenumber = 1;
        $scope.fillSubClassList();
    }

    $scope.ClearSubClassListSearch = function () {
        if (subClassListSearchTimeout) $timeout.cancel(subClassListSearchTimeout);
        $scope.SubClassListPagination.page = 1;
        subRequestModel.pagenumber = 1;
        initilizeSubClassObject();
    }

    $scope.SubClassConfirmMsg = {
        Header: '',
        Message: '',
        Show: function () {
            $('#popup-confirm-dialog-bg').slideToggle();
        },
        OK_Click: function () {
            $('#popup-confirm-dialog-bg').slideToggle();
            $scope.SubClassConfirmMsg.Header = '';
            $scope.SubClassConfirmMsg.Message = '';

            $scope.SubClassAlert.Header = 'Delete ' + $scope.appsVar.tooltipValue;
            $scope.SubClassAlert.Message = 'You are deleting the selected ' + $scope.appsVar.tooltipValue + '(s).';
            $scope.SubClassAlert.CallbackFunction = deleteSelectedSubClass;
            $scope.SubClassAlert.Show();
        },
        Cancel_Click: function () {
            $('#popup-confirm-dialog-bg').slideToggle();
            $scope.SubClassConfirmMsg.Header = '';
            $scope.SubClassConfirmMsg.Message = '';
        }
    };

    $scope.SubClassAlert = {
        Header: '',
        Message: '',
        CallbackFunction: null,
        Show: function () {
            $('#popup-alert-dialog-bg').slideToggle();
        },
        OK_Click: function () {
            $('#popup-alert-dialog-bg').slideToggle();
            $scope.SubClassAlert.Header = '';
            $scope.SubClassAlert.Message = '';

            if (CallbackFunction) {
                CallbackFunction();
                CallbackFunction = null;
            }
        }
    };

    $scope.AddSubClass = function () {
        $scope.validation.showMessage = false;
        $scope.validation.showInformationMessage = false;
        $scope.ShowWarning = false;
        $scope.posting = false;
        $scope.PageEvents.UserAction = 'Add';
        $scope.SubClassModel = classFactory.classInitailValues();
        $('#popup-add-sub-class-add').slideToggle();
    }

    $scope.CloseSubClass = function () {
        $('#popup-add-sub-class-add').slideToggle();
    }

    $scope.EditSubClass = function () {
        if (!$scope.SelectedSubclassList || $scope.SelectedSubclassList.length == 0) {
            $scope.SubClassAlert.Header = 'Edit ' + $scope.appsVar.tooltipValue;
            $scope.SubClassAlert.Message = 'Select ' + $scope.appsVar.tooltipValue + ' to edit.'
            $scope.SubClassAlert.Show();
            return;
        }
        $scope.validation.showMessage = false;
        $scope.validation.showInformationMessage = false;
        $scope.ShowWarning = false;
        $scope.posting = false;
        $scope.PageEvents.UserAction = 'Edit'
        $scope.SubClassModel = classFactory.classInitailValues();
        $scope.SubClassModel = $scope.SelectedSubclassList[0];
        $('#popup-add-sub-class-add').slideToggle();
    }

    $scope.SaveSubClass = function () {
        $scope.validation.showMessage = true;
        if ($scope.SubClassModel.Description == '' || $scope.SubClassModel.Description == undefined || $scope.SubClassModel.Alias == '') {
            return;
        }
        $scope.posting = true;
        var requiredFieldsList = [];

        $scope.SubClassModel.ParentClass = $scope.SelectedClassList[0].Alias;
        if ($scope.PageEvents.UserAction == 'Add') {
            var promiseAdd = ClassService.addSubClass($scope.vm.selectedLibrary, $scope.SubClassModel, requiredFieldsList, $scope.SelectedClassList[0].Alias);
            promiseAdd.then(function (response) {
                $scope.validation.showMessage = false;
                $scope.posting = false;
                $scope.validation.showInformationMessage = false;
                $scope.ShowWarning = false;

                if (response && response.data && response.data.Status) {
                    $('#popup-add-sub-class-add').slideToggle();
                    $scope.PageEvents.UserAction = ''
                    $scope.SubClassModel = classFactory.classInitailValues();
                    $scope.fillSubClassList();
                }
                else {
                    $scope.ShowWarning = true;
                    $scope.ErrorMessage = response.data.Message;
                }
            }, function () {
                alert('Error in updating record');
            });
        } else {
            var promiseAdd = ClassService.editSubClass($scope.vm.selectedLibrary, $scope.SubClassModel, requiredFieldsList, $scope.SelectedClassList[0].Alias);
            promiseAdd.then(function (response) {
                $scope.validation.showMessage = false;
                $scope.validation.showInformationMessage = false;
                $scope.ShowWarning = false;
                $scope.posting = false;

                if (response && response.data && response.data.Status) {
                    $('#popup-add-sub-class-add').slideToggle();
                    $scope.PageEvents.UserAction = ''
                    $scope.SubClassModel = classFactory.classInitailValues();
                    $scope.fillSubClassList();
                }
                else {
                    $scope.ShowWarning = true;
                    $scope.ErrorMessage = response.data.Message;
                }
            }, function () {
                alert('Error in updating record');
            });
        }
    }

    $scope.DeleteSubClass_Click = function () {
        if (!$scope.SelectedSubclassList || $scope.SelectedSubclassList.length == 0) {
            $scope.SubClassAlert.Header = 'Delete ' + $scope.appsVar.tooltipValue;
            $scope.SubClassAlert.Message = 'Select ' + $scope.appsVar.tooltipValue + ' to delete.'
            $scope.SubClassAlert.Show();
        }
        else {
            $scope.SubClassConfirmMsg.Header = 'Delete ' + $scope.appsVar.tooltipValue;
            $scope.SubClassConfirmMsg.Message = 'Are you sure to delete selected Class(s)?';
            $scope.SubClassConfirmMsg.Show();
        }
    };

    function deleteSelectedSubClass() {
        var promise = ClassService.deleteSubClass($scope.vm.selectedLibrary, $scope.SelectedSubclassList, $scope.SelectedClassList[0].Alias);
        promise.then(function (response) {
            if (response.data.length > 0) {
                $scope.fillSubClassList();
            }
        }, function () {

        });
    }

    $scope.$on('onsubTableFiltering', function (event, value, key) {
        if (subRequestModel.filters.length > 0) {
            subRequestModel.filters = jQuery.grep(subRequestModel.filters, function (filterItem) {
                return filterItem.FilterKey !== key;
            });
        }

        var filterValueList = [];
        filterValueList[0] = value;

        var filterItem = { 'FilterKey': key, 'FilterValues': filterValueList };
        subRequestModel.filters.push(filterItem);

        $scope.SubClassListPagination.page = 1;
        subRequestModel.pagenumber = 1;
        $scope.fillSubClassList();
    });

}