﻿app.controller("DatabaseController", DatabaseController);
DatabaseController.$inject = ['$scope', '$rootScope', 'DatabaseService', 'HomeService',   'databasesFactory', '$filter', '$timeout', 'homeFactory'];

function DatabaseController($scope, $rootScope, DatabaseService, HomeService,   databasesFactory, $filter, $timeout, homeFactory) {

    $scope.haveMoreRows = true;
    $scope.loading = true;
    $scope.showValidation = false;
    $scope.lastSelectedLibrary = '';
    $scope.PreviousPageCursorList = [];
    $scope.CurrentPageCursor = '';
    $scope.NextPageCursor = '';
    $scope.PreviousPageCursor = '';

    //$scope.dtColumnDefs = datatableSettingsFactory.dtDatabaseTableColumns;
    //$scope.tableSettings = datatableSettingsFactory.tableSettings();
    $scope.DatabaseModel = databasesFactory.databasesInitialValues();
    var requestModel = homeFactory.requestModelInstance();

    getDatabase();

    $rootScope.$on('onDatabaseTabClick', function () {
        Initalize();

    })

    $scope.loadMoreOnScrollEnd = function () {
        if ($scope.haveMoreRows) {
            getDatabase();

        }
    };

    $scope.PreviousPageButton_Click = function () {
        $scope.CurrentPageCursor = '';
        if ($scope.PreviousPageCursorList && $scope.PreviousPageCursorList.length > 0)
            $scope.CurrentPageCursor = $scope.PreviousPageCursorList.pop();

        getDatabase();
    }

    $scope.NextPageButton_Click = function () {
        $scope.PreviousPageCursorList.push($scope.CurrentPageCursor);
        $scope.CurrentPageCursor = $scope.NextPageCursor;
        getDatabase();
    }

    function Initalize() {
        $scope.loading = true;
        $scope.DatabaseList = [];
        $scope.haveMoreRows = true;
        $scope.isAdd = true;
        $scope.PreviousPageCursorList = [];
        $scope.CurrentPageCursor = '';
        $scope.NextPageCursor = '';
        $scope.PreviousPageCursor = '';
        getDatabase();
        getDBList();

    }

    function getDatabase() {
        if (!$scope.selectedLibrary || $scope.selectedLibrary.trim().length == 0) return;
        $scope.lastSelectedLibrary = $scope.selectedLibrary;
        requestModel.libraryName = $scope.selectedLibrary ;      
        requestModel.cursor = $scope.CurrentPageCursor;
        requestModel.pageLength = 10       ;
        requestModel.searchText = $scope.appsVar.SearchText;

        var DBlist = DatabaseService.getDatabase(requestModel);
        DBlist.then(function (response) {
            $scope.appsVar.initialLoading = false;
            if (response.data.rows.length > 0) {
                if (response.data.rows[0].cell.length > 0) {
                    //if (!$scope.DatabaseList || $scope.DatabaseList.length == 0) {


                    //}
                    //else {
                    //    for (itemCount = 0; itemCount < response.data.rows[0].cell[0].length; itemCount++) {
                    //        $scope.DatabaseList.push(response.data.rows[0].cell[0][itemCount]);
                    //    }
                    //}
                    $scope.tableSettings.scrollTop = 0;
                    $scope.tableSettings.scrollBarTop = 0;
                    $scope.DatabaseList = response.data.rows[0].cell[0];

                    $scope.NextPageCursor = response.data.cursor;
                    $scope.haveMoreRows = response.data.moreRowsFound;
                    $scope.loading = false;
                    $('#card-more-button').attr('disabled', 'disabled');
                }
            }
            $scope.vm.selectedApp.ResponseCount = $scope.DatabaseList.length;
            $scope.vm.selectedApp.CurrentTab = 'Databases';
          
        }, function () {
            $scope.showAlertMessage('Failed to fetch databases.');

        });
    }

    $scope.addDatabases = function () {
        $scope.posting = true;
        if ($scope.DatabaseModel.DatabaseName == '') {
            $scope.posting = false;
            $scope.showValidation = true;

            return;
        } else {
            $scope.showValidation = false;
        }

        //$scope.lastCursorValue = $scope.cursorValue;
        $scope.lastSelectedLibrary = $scope.selectedLibrary;
        var addDatabaseList = DatabaseService.addDatabases($scope.selectedLibrary, $scope.DatabaseModel);
        addDatabaseList.then(function (response) {
            if (response.data.rows.length > 0) {
                if (response.data.rows[0].cell.length > 0) {
                    if (response.data.rows[0].cell[2] == 'Success') {
                        getDatabase();
                        $scope.DatabaseModel = databasesFactory.databasesInitialValues();
                        $scope.showValidation = false;
                        setTimeout(function () {
                            $('#Add_Databases').modal('hide');
                            $scope.ShowWarning = false;
                        }, 1500);
                    }
                    $scope.ErrorMessage = response.data.rows[0].cell[2];
                    $scope.ShowWarning = true;
                }
            }
            $scope.posting = false;
        }, function () {

        });
    }

    $scope.select = function (item, $event) {
        if ($event.ctrlKey) {
            item.selected ? item.selected = false : item.selected = true;
        }
        else {
            this.getAllSelectedRows(item);
        }
        var selectedUserList = $filter('filter')($scope.DatabaseList, { selected: true });
        if (selectedUserList.length == 0) {
            $('#card-more-button').attr('disabled', 'disabled')
        } else {
            $('#card-more-button').removeAttr('disabled')
        }
    };

    $scope.getAllSelectedRows = function (item) {
        angular.forEach($scope.DatabaseList, function (p) {
            p.selected = false; //set them all to false
        });
        item.selected = true; //set the clicked one to true
    };

    (function ($) {
        $(document).ready(function () {
            $('#card-more-button').attr('disabled', 'disabled');
        });
    })(jQuery);

    $scope.$on('Search_Click', function (event, args) {

        $scope.lastSelectedLibrary = '';
        Initalize();
    });

    $scope.$on('Refresh_Click', function (event, args) {
        $scope.lastSelectedLibrary = '';
        Initalize();
    });

    getDBList();

    function getDBList() {
        var promise = HomeService.getDBLibraries();
        promise.then(function (response) {
            if (response.data.length > 0) {
                $scope.DBList = response.data;
                //$scope.DatabaseModel.Name = $scope.DBList[0].DatabaseName;
                //  $timeout(function () {
                $('#cbo-Database-selection').selectpicker('render');
                //$('#cbo-Database-selection').selectpicker('refresh');
                $('[data-id="cbo-Database-selection"]').on('click', function () {
                    $('#cbo-Database-selection').selectpicker('refresh');
                    $('[data-id="cbo-Database-selection"]').siblings('div').find('ul > li:has("span.text:empty")').remove();
                });
                //   });

            } else {

                // alert($scope.selectedApp.NoAppsPermission);
            }

        });
    }

    $scope.$on('onAddButton_Click', function (event, data) {
        //$rootScope.$on('onEditButton_Click', function (isCurrentRow) {
        //  getDBList();
        $scope.isAdd = true;
        $scope.DatabaseModel = databasesFactory.databasesInitialValues();
        $("#Add_Databases").modal();
    })
    //$scope.cancelAddDatabaseDialoge = function () {
    //    $scope.DatabaseModel = databasesFactory.databasesInitialValues();      
    //   $("#Add_Databases").modal('hide');
    //}
    //$scope.$on('onDatabsesEditButton_Click', function (event, data) {
    //    $scope.ValidateDatabases = $filter('filter')($scope.DatabaseList, { selected: true });
    //    if (typeof $scope.ValidateDatabases !== 'undefined' && $scope.ValidateDatabases.length > 0) {
    //        $scope.isAdd = false;

    //        angular.copy($scope.ValidateDatabases[0], $scope.DatabaseModel);
    //        $scope.DatabaseModel.DatabasesName = $scope.ValidateDatabases[0].DatabasesName;
    //        $("#Add_Databases").modal();
    //        $timeout(function () {
    //            $('#cbo-Database-selection').selectpicker('refresh');
    //        });
    //        return true;
    //    }
    //    else {
    //        $scope.showAlertMessage('Select Databses to edit.');
    //        return false;
    //    }
    //});
    $scope.EditDatabases = function () {
        $scope.posting = true;
        $scope.showValidation = true;
        var UpdateData = DatabaseService.editDatabases($scope.selectedLibrary, $scope.DatabaseModel);
        UpdateData.then(function (response) {

            if (response.data.rows.length > 0) {
                if (response.data.rows[0].cell.length > 0) {
                    if (response.data.rows[0].cell[2] == 'Success') {
                        getDatabase();
                        $scope.DatabaseModel = databasesFactory.databasesInitialValues();
                        $scope.showValidation = false;
                        setTimeout(function () {
                            $('#Add_Databases').modal('hide');
                            $scope.ShowWarning = false;
                        }, 1500);
                    }
                    $scope.ErrorMessage = response.data.rows[0].cell[2];
                    $scope.ShowWarning = true;
                }
            }
            $scope.posting = false;
        }, function () {
            alert('Error in updating record');
        });
    }
    //$scope.singleEditClick = function () {
    //    var databaseID = $scope.appsVar.selectedRecordId;
    //    $scope.isAdd = false;
    //    $scope.ValidateDatabases = $filter('filter')($scope.DatabaseList, { DatabaseName: databaseID });
    //    if (typeof $scope.ValidateDatabases !== 'undefined' && $scope.ValidateDatabases.length > 0) {
    //        angular.copy($scope.ValidateDatabases[0], $scope.DatabaseModel);
    //        $("#Add_Databases").modal();
    //        $timeout(function () {
    //            $('#cbo-Database-selection').selectpicker('refresh');
    //        });
    //        return true;
    //    }
    //    else {
    //        $scope.showAlertMessage('Select Databses to edit.');
    //        return false;
    //    }
    //}
    $scope.PageEvents.Add = function () {
        $scope.PageEvents.UserAction = 'Add';
        $('#Add_Databases').modal();
    };



    $scope.PageEvents.Edit = function (row) {
        $scope.PageEvents.UserAction = 'Edit';
        $scope.isAdd = false;
        $scope.ValidateDatabases = $filter('filter')($scope.DatabaseList, { selected: true });
        if (row) {
            var databaseID = $scope.appsVar.selectedRecordId;
            $scope.ValidateDatabases = $filter('filter')($scope.DatabaseList, { DatabaseName: databaseID });
        }
        if (typeof $scope.ValidateDatabases !== 'undefined' && $scope.ValidateDatabases.length > 0) {
            angular.copy($scope.ValidateDatabases[0], $scope.DatabaseModel);
            $("#Add_Databases").modal();
            $timeout(function () {
                $('#cbo-Database-selection').selectpicker('refresh');
            });
            return true;
        }
        else {
            $scope.showAlertMessage('Select Databses to edit.');
            return false;
        }
    }


    $scope.PageEvents.BindLabel = function (data) {
        if ($scope.PageEvents.UserAction == 'Add') {
            return 'Add'
        } else {
            return 'Save';
        }
    }

    $scope.PageEvents.Save = function () {
        if ($scope.PageEvents.UserAction == 'Add') {
            return $scope.addDatabases();
        } else {
            return $scope.EditDatabases();
        }
    }

    $scope.PageEvents.CancelDialog = function () {
        $scope.DatabaseModel = databasesFactory.databasesInitialValues();
        $scope.showValidation = false;
        $scope.ShowWarning = false;
        $('#Add_Databases').modal('hide');
    }

    $scope.$on('$destroy', function () {
        $scope.PageEvents.Add = 'undefined';
        $scope.PageEvents.Edit = 'undefined';
        $scope.PageEvents.Save = 'undefined';
        $scope.PageEvents.Delete = 'undefined';
        $scope.PageEvents.CancelDialog = 'undefined';
        $scope.PageEvents.ShowSubclassList = 'undefined';
        $scope.PageEvents.AddRole = 'undefined';
        $scope.PageEvents.ResetPasswordclicked = 'undefined';
        $scope.PageEvents.ViewAssignUser = 'undefined';
        $scope.PageEvents.AssignUser = 'undefined';
        $scope.PageEvents.AssignGroup = 'undefined';
    });
}