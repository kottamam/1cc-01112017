﻿app.controller("SecurityTemplateController", SecurityTemplateController);
SecurityTemplateController.$inject = ['$scope', '$rootScope', 'SecurityTemplateService', 'UserService', 'GroupService',   'securityTemplateFactory', '$filter', '$timeout'];


function SecurityTemplateController($scope, $rootScope, SecurityTemplateService, UserService, GroupService,   securityTemplateFactory, $filter, $timeout) {
    $scope.haveMoreRows = true;
    $scope.loading = true;
    $scope.showValidation = false;
    $scope.ShowWarning = false;
    $scope.ErrorMessage = '';
    $scope.appsVar.SearchText = '';
    $scope.lastSelectedLibrary = '';

    $scope.PreviousPageCursorList = [];
    $scope.CurrentPageCursor = '';
    $scope.NextPageCursor = '';
    $scope.PreviousPageCursor = '';
     
    //$scope.dtColumnDefs = datatableSettingsFactory.dtSecurityTemplateTableColumns;
    //$scope.tableSettings = datatableSettingsFactory.tableSettings();


    $scope.PreviousPageButton_Click = function () {
        $scope.CurrentPageCursor = '';
        if ($scope.PreviousPageCursorList && $scope.PreviousPageCursorList.length > 0)
            $scope.CurrentPageCursor = $scope.PreviousPageCursorList.pop();

        getSecurityTemplateList();
    }

    $scope.NextPageButton_Click = function () {
        $scope.PreviousPageCursorList.push($scope.CurrentPageCursor);
        $scope.CurrentPageCursor = $scope.NextPageCursor;
        getSecurityTemplateList();
    }


    getSecurityTemplateList();

    $rootScope.$on('onSecurityTemplateTabClick', function () {
        initalizeListForm();
    })

    $scope.$on('Search_Click', function (event, args) {
        $scope.lastSelectedLibrary = '';
        initalizeListForm();
    });

    $scope.$on('Refresh_Click', function (event, args) {
        $scope.lastSelectedLibrary = '';
        initalizeListForm();
    });

    $scope.loadMoreOnScrollEnd = function () {
        if ($scope.haveMoreRows) {
            getSecurityTemplateList();
        }
    };

    $scope.select = function (item, $event) {
        if ($event.ctrlKey) {
            item.selected ? item.selected = false : item.selected = true;
        }
        else {
            this.getAllSelectedRows(item);
        }
    };

    $scope.getAllSelectedRows = function (item) {
        angular.forEach($scope.SecurityTemplateList, function (p) {
            p.selected = false; //set them all to false
        });
        item.selected = true; //set the clicked one to true
    };

    function initalizeListForm() {
        $scope.loading = true;
        $scope.SecurityTemplateList = [];
        $scope.haveMoreRows = true;
        $scope.PreviousPageCursorList = [];
        $scope.CurrentPageCursor = '';
        $scope.NextPageCursor = '';
        $scope.PreviousPageCursor = '';
        getSecurityTemplateList();
    }

    function getSecurityTemplateList() {
        if (!$scope.selectedLibrary || $scope.selectedLibrary.trim().length == 0) return;

        $scope.lastSelectedLibrary = $scope.selectedLibrary;

        var TemplateList = SecurityTemplateService.getSecurityTemplateServiceList($scope.selectedLibrary, $scope.CurrentPageCursor, 10, $scope.appsVar.SearchText);
        TemplateList.then(function (response) {
            $scope.appsVar.initialLoading = false;
            if (response.data.rows.length > 0) {
                if (response.data.rows[0].cell.length > 0) {
                    $scope.tableSettings.scrollTop = 0;
                    $scope.tableSettings.scrollBarTop = 0;
                    $scope.SecurityTemplateList = response.data.rows[0].cell[0];

                    $scope.NextPageCursor = response.data.cursor;
                    $scope.haveMoreRows = response.data.moreRowsFound;
                    $scope.loading = false;
                }
            }
            $scope.vm.selectedApp.ResponseCount = $scope.SecurityTemplateList.length;
            $scope.vm.selectedApp.CurrentTab = 'Security Templates';
        }, function () {
            $scope.showAlertMessage('Failed to fetch security fetching.');
        });
    }



    /********************************************************************************************************************************************/

    $scope.IsEditMode = false;
    $scope.SelectedPermission = null;
    $scope.GroupDetailList = [];
    $scope.UserDetailList = [];

    var aciTreeAPI;
    var TreeAlreadyLoaded = false;
    var TreeSelectedItemList = [];
    

    $scope.PageEvents.Add = function () {
        $scope.PageEvents.UserAction = 'Add';
        $('#Add_Edit_Security_Templates').modal();
        openAndInitializationEditForm();
    };

    $scope.PageEvents.Edit = function (isSingleClick) {
        $scope.PageEvents.UserAction = 'Edit';
        $scope.IsEditMode = true;
        if (isSingleClick && $scope.appsVar.selectedRecordId.trim().length > 0) {
            viewSecurityTemplate($scope.appsVar.selectedRecordId);
        }
        else {
            var tempTemplateFilter = $filter('filter')($scope.SecurityTemplateList, { selected: true });
            if (typeof tempTemplateFilter !== 'undefined' && tempTemplateFilter.length > 0) {
                viewSecurityTemplate(tempTemplateFilter[0].TemplateName);
            }
            else {
                $scope.showAlertMessage('Select security template to edit.');
            }
        }
    }

    $scope.SearchGroupAndUserList_Click = function () {
        refreshUserGroupTree();
    }

    $scope.Cancel_Click = function () {
        closeTemplateEditForm(false);
    }

    $scope.AdvanceOptions_Click = function () {
        $('#collapse1').collapse('toggle');
    }

    //$scope.$on('Initalize_SecurityTemplates_EditForm', function (event, args) {
    //    openAndInitializationEditForm();
    //});

    function openAndInitializationEditForm() {
        $scope.SecurityTemplateModel = securityTemplateFactory.templateInitailValues();
        $scope.TemaplteValidation = securityTemplateFactory.validations();
        $scope.IsEditMode = false;
        $scope.SelectedPermission = null;
        $scope.GroupDetailList = [];
        $scope.UserDetailList = [];
        TreeAlreadyLoaded = false;
        TreeSelectedItemList = [];

        aciTreeAPI = $('#tree').aciTree('api');
        $('#tree').on('acitree', function (event, api, item, eventName, options) {

            var parentItem = null, parentItemId = '';
            var itemType = '';

            parentItem = api.parent(item);
            if (parentItem)
                parentItemId = api.getId(parentItem);

            if (parentItemId === 'User') {
                itemType = 'U';
            }
            else if (parentItemId === 'Group') {
                itemType = 'G';
            }

            if (eventName == 'selected') {
                if (itemType.trim().length > 0) {
                    TreeSelectedItemList.push({ ItemType: itemType, Id: api.getId(item) });
                }
            }
            else if (eventName == 'deselected') {
                if (itemType.trim().length > 0) {
                    if (TreeSelectedItemList.length > 0) {
                        TreeSelectedItemList = $.grep(TreeSelectedItemList, function (selectedItemTemp, index) {
                            return (selectedItemTemp.ItemType === itemType && selectedItemTemp.Id === api.getId(item));
                        }, true);
                    }
                }
            }
        });

        getAllGroupList();
        getAllUserList();

        $('.selectpicker').selectpicker();
    }

    function closeTemplateEditForm(blnRefreshList) {
        if (TreeAlreadyLoaded) {
            $('#tree').aciTree('api').destroy()
        }
        $('#collapse1').collapse('hide');
        $('#Add_Edit_Security_Templates').modal('hide');
        $scope.posting = false;
        if (blnRefreshList) initalizeListForm();

        $scope.SecurityTemplateModel = null;
        $scope.TemaplteValidation = null;
        $scope.ShowWarning = false;
        $scope.posting = false;
        $scope.ErrorMessage = '';
        $scope.IsEditMode = false;
        $scope.SelectedPermission = null;
        aciTreeAPI = null;
        TreeSelectedItemList = [];
        TreeAlreadyLoaded = false;
        $scope.GroupDetailList = null;
        $scope.UserDetailList = null;
    }

    function getAllGroupList() {
        if (!$scope.selectedLibrary || $scope.selectedLibrary.trim().length == 0) return;

        var groupList = GroupService.getAllGroupList($scope.selectedLibrary);
        groupList.then(function (response) {
            if (response.data.rows.length > 0) {
                if (response.data.rows[0].cell.length > 0) {
                    $scope.GroupDetailList = response.data.rows[0].cell[0];
                    refreshUserGroupTree();
                }
            }
        }, function () {
            $scope.showAlertMessage('Failed to fetch groups.');
        });
    }

    function getAllUserList() {

        var allUserList = UserService.getAllUserList($scope.selectedLibrary, '');
        allUserList.then(function (response) {
            if (response.data.rows.length > 0) {
                if (response.data.rows[0].cell.length > 0) {
                    $scope.UserDetailList = response.data.rows[0].cell[0];
                    refreshUserGroupTree();
                }
            }
        }, function () {

        });
    }

    function refreshUserGroupTree() {

        var treeNodeList = [];
        var tempBranchList = [];

        if (TreeAlreadyLoaded) {
            $('#tree').aciTree('api').destroy()
        }

        var currentSearchValue = $('#txtSearchGroupAndUser').val().trim();
        var searchResultFound = false;
        var tempArrayFilter;

        if ($scope.GroupDetailList) {
            angular.forEach($scope.GroupDetailList, function (groupModel) {
                searchResultFound = false;

                if ($scope.SecurityTemplateModel.PermissionList && $scope.SecurityTemplateModel.PermissionList.length > 0) {
                    tempArrayFilter = $.grep($scope.SecurityTemplateModel.PermissionList, function (filterTempItem, index) {
                        return (filterTempItem.UserOrGroup === 'G' && filterTempItem.Id === groupModel.GroupName);
                    });
                    searchResultFound = tempArrayFilter.length > 0;
                    tempArrayFilter = null;
                }
                if (!searchResultFound) {
                    if (currentSearchValue.trim().length == 0 || groupModel.GroupName.indexOf(currentSearchValue) >= 0)
                        tempBranchList.push({ id: groupModel.GroupName, icon: 'file', label: groupModel.GroupName });
                }

            });

        }
        if (tempBranchList.length > 0)
            treeNodeList.push({ id: 'Group', icon: 'folder', label: 'Group', inode: true, branch: tempBranchList });

        tempBranchList = [];
        if ($scope.UserDetailList) {
            angular.forEach($scope.UserDetailList, function (userModel) {

                searchResultFound = false;

                if ($scope.SecurityTemplateModel.PermissionList && $scope.SecurityTemplateModel.PermissionList.length > 0) {
                    tempArrayFilter = $.grep($scope.SecurityTemplateModel.PermissionList, function (filterTempItem, index) {
                        return (filterTempItem.UserOrGroup === 'U' && filterTempItem.Id === userModel.UserId);
                    });
                    searchResultFound = tempArrayFilter.length > 0;
                    tempArrayFilter = null;
                }
                if (!searchResultFound) {
                    if (currentSearchValue.trim().length == 0 || userModel.UserId.indexOf(currentSearchValue) >= 0)
                        tempBranchList.push({ id: userModel.UserId, icon: 'file', label: userModel.UserId });
                }
            });
        }
        if (tempBranchList.length > 0)
            treeNodeList.push({ id: 'User', icon: 'folder', label: 'User', inode: true, branch: tempBranchList });

        var options = {
            rootData: treeNodeList,
            radio: true,
            checkbox: true,
            selectable: true,           // selectable extension
            multiSelectable: true,     // selectable extension
            expand: TreeAlreadyLoaded,
            ajaxHook: function (item, settings) {
                alert("Can't load with AJAX because is not used here");
            },
        };
        $timeout(function () {
            $('#tree').aciTree(options);
            TreeAlreadyLoaded = true;
        }, (TreeAlreadyLoaded === true ? 1500 : 1));
    }

    $scope.ShowPermission_Click = function () {
        if (!TreeSelectedItemList || TreeSelectedItemList.length == 0)
            return;

        $('#select_permission_popup').collapse('toggle');
    }

    $scope.CancelPermission_Click = function () {
        $('#select_permission_popup').collapse('toggle');
        $scope.SelectedPermission = null;
    }

    $scope.SavePermission_Click = function () {
        var cboPermissionId = '';
        var cboSelectedPermission = $('#cbo-permission-selection').selectpicker('val');

        angular.forEach(TreeSelectedItemList, function (selecteItem) {

            var tempArrayFilter = $.grep($scope.SecurityTemplateModel.PermissionList, function (filterTempItem, index) {
                return (filterTempItem.UserOrGroup === selecteItem.ItemType && filterTempItem.Id === selecteItem.Id);
            });
            if (!tempArrayFilter || tempArrayFilter.length == 0) {

                cboPermissionId = 'cbo-permission-selected' + $scope.SecurityTemplateModel.PermissionList.length.toString();

                $scope.SecurityTemplateModel.PermissionList.push({
                    UserOrGroup: selecteItem.ItemType, Id: selecteItem.Id,
                    AccessRight: cboSelectedPermission, PermissionDDLId: cboPermissionId,
                    Selected: false
                });

                $('#' + cboPermissionId).selectpicker();
            }
        });
        refreshUserGroupTree();
        $scope.SelectedPermission = null;
        $('#select_permission_popup').collapse('toggle');


        //cboPermissionId = 'cbo-permission-selected' + $scope.SecurityTemplateModel.PermissionList.length.toString();

        //$scope.SecurityTemplateModel.PermissionList.push({
        //    UserOrGroup: 'U', Id: 'U2', AccessRight: 'Read', PermissionDDLId: cboPermissionId,
        //    Selected: false
        //});
        //$('#select_permission_popup').collapse('toggle');
        //$scope.SelectedPermission = null;
    }

    $scope.SelectRow = function (rowItem, $event) {
        angular.forEach($scope.SecurityTemplateModel.PermissionList, function (tempItem) {
            tempItem.Selected = false; //set them all to false
        });
        rowItem.Selected = true; //set the clicked one to true
    }

    $scope.OpenPermissionRemoveConfirm = function (rowItem, $event) {
        $('#permission_remove_confirm_popup').modal();
    }

    $scope.RemoveSelectedPermission = function (rowItem, $event) {
        $('#permission_remove_confirm_popup').modal('hide');
        var tempList = $.grep($scope.SecurityTemplateModel.PermissionList,
               function (permission, index) { return permission.Selected === true; },
               true);
        $scope.SecurityTemplateModel.PermissionList = [];
        $scope.SecurityTemplateModel.PermissionList = tempList;
        tempList = null;
        refreshUserGroupTree();
    }

    $scope.ClosePermissionRemoveConfirm = function (rowItem, $event) {
        $('#permission_remove_confirm_popup').modal('hide');
    }

    //$scope.$on('EditButton_Click', function (event, data) {
    //    var tempTemplateFilter = $filter('filter')($scope.SecurityTemplateList, { selected: true });
    //    if (typeof tempTemplateFilter !== 'undefined' && tempTemplateFilter.length > 0) {
    //        viewSecurityTemplate(tempTemplateFilter[0].TemplateName);
    //    }
    //    else {
    //        $scope.showAlertMessage('Select security template to edit.');
    //    }
    //});

    //$scope.singleEditClick = function () {
    //    if ($scope.appsVar.selectedRecordId.trim().length > 0)
    //        viewSecurityTemplate($scope.appsVar.selectedRecordId);
    //}

    function viewSecurityTemplate(templateName) {
        var templateModelReader = SecurityTemplateService.getByTemplateName($scope.selectedLibrary, templateName);
        templateModelReader.then(function (response) {
            $scope.SecurityTemplateModel = null;
            $scope.IsEditMode = false;

            if (response.data) {
                $('#Add_Edit_Security_Templates').modal();
                openAndInitializationEditForm();

                $scope.IsEditMode = true;
                $scope.SecurityTemplateModel = {
                    TemplateName: response.data.TemplateName,
                    Description: response.data.Description,
                    DefaultSecurity: response.data.DefaultSecurity,
                    PermissionList: response.data.PermissionList
                };
                $('#cbo-default-security-selection').selectpicker('val', $scope.SecurityTemplateModel.DefaultSecurity);
            }
            else {
                $scope.showAlertMessage('Failed to fetch security template.');
            }
        }, function () {
            $scope.showAlertMessage('Failed to fetch security template.');
        });
    }

    $scope.saveSecurityTemplate = function () {
        $scope.ShowWarning = false;
        $scope.posting = false;
        $scope.TemaplteValidation.showMessage = false;
        $scope.ErrorMessage = '';

        if (!$scope.SecurityTemplateModel) {
            $scope.ShowWarning = true;
            return;
        }
        if ($scope.SecurityTemplateModel.TemplateName.trim().length == 0) {
            $scope.SecurityTemplateModel.TemplateName = '';
            $scope.TemaplteValidation.showMessage = true;
            return;
        }

        $scope.posting = true;
        var tempModel = {
            TemplateName: $scope.SecurityTemplateModel.TemplateName,
            Description: $scope.SecurityTemplateModel.Description,
            DefaultSecurity: $('#cbo-default-security-selection').selectpicker('val'),
            PermissionList: $scope.SecurityTemplateModel.PermissionList
        };
        var resultReader = SecurityTemplateService.save($scope.selectedLibrary, tempModel, $scope.IsEditMode);
        resultReader.then(function (response) {
            var blnUpdated = false;
            blnUpdated = response.data && response.data === 'Success';

            if (blnUpdated) {
                $scope.ErrorMessage = 'Success';
                $scope.ShowWarning = true;
                $scope.IsEditMode = false;
                setTimeout(function () {
                    closeTemplateEditForm(true);
                }, 1500);
            }
            else {
                $scope.ErrorMessage = response.data;
                $scope.ShowWarning = true;
            }
        }, function () {
            $scope.ErrorMessage = 'Failed to save security template.';
            $scope.ShowWarning = true;
        });
    }

    $scope.PageEvents.BindLabel = function (data) {
        if ($scope.PageEvents.UserAction == 'Add') {
            return 'Add'
        } else {
            return 'Save';
        }
    }
}