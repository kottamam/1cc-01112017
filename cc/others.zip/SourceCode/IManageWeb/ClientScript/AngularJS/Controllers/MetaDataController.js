﻿app.controller("MetaDataController", MetaDataController);
MetaDataController.$inject = ['$scope', '$rootScope', 'MetaDataService',  'metaDataFactory', '$filter', '$timeout', '$mdDialog', '$mdMedia', 'ngTableParams', 'homeFactory'];

function MetaDataController($scope, $rootScope, MetaDataService,   metaDataFactory, $filter, $timeout, $mdDialog, $mdMedia, ngTableParams, homeFactory) {

    $scope.haveMoreRows = true;
    $scope.cursorValue = ''
    $scope.loading = true;
    $scope.showValidation = false;
    $scope.ShowWarning = false;
    $scope.ErrorMessage = '';
    $scope.SearchValue = null;
    $scope.appsVar.SearchText = '';
    $scope.PageEvents.isSubMetaData = false;
    $scope.lastSelectedLibrary = '';
    $scope.lastCursorValue = null;
    var offset = 1;
    var limit = 10;
    var total = true;
    var isSubserchTxtDirty = false;
    var suboffset = 1;
    var sublimit = 10;
    var subtotal = true;
    $scope.selected = [];
    $scope.subSelected = [];
    var requestModel = homeFactory.requestModelInstance();
    var subrequestModel = homeFactory.requestModelInstance();

    //$scope.dtColumnDefs = datatableSettingsFactory.dtMetaDataTableColumns; 
    //$scope.tableSettings = datatableSettingsFactory.tableSettings();
    $scope.MetaDataModel = metaDataFactory.meatDataInitialValues();

    $scope.tableParams = new ngTableParams({
        noPager: true
    }, {
        getData: function ($defer, params) {
            $defer.resolve($scope.MetaDataList);
        }
    });

   
    
    $scope.ContextMenuFunctions = {
        Edit: function () { $scope.PageEvents.Edit(false); },
        SubMetaDataList: function () { $scope.MetadataSubItem.Show(); }
    }
    function setContextMenuObject() {
        $scope.menuList = [
            {
                Label: 'Edit',
                Icon: 'img/icons/edit.svg',
                onClick: $scope.ContextMenuFunctions.Edit,
                Enable: $scope.selected.length == 1
            },
             {
                 Label: $scope.appsVar.tooltipValue,                 
                 Icon: 'img/icons/style_blue.svg',
                 onClick: $scope.ContextMenuFunctions.SubMetaDataList,
                 Enable: $scope.selected.length == 1 && ($scope.appsVar.selectedMetaData == "CUSTOM1" || $scope.appsVar.selectedMetaData == "CUSTOM29")
             }
        ];
    }

    //function setSubContextMenuObject() {
    //    $scope.menuList = [
    //        {
    //            Label: 'Edit',
    //            Icon: 'img/icons/edit.svg',
    //            onClick: $scope.ContextMenuFunctions.Edit,
    //            Enable: $scope.selected.length == 1
    //        }
    //    ];
    //}

    $scope.MetadataSubItem = {
        SearchText: '',
        Header: '',
        Message: '',
        Show: function () {
            $scope.ValidateSubButtonMetaData = $scope.selected;//= $filter('filter')($scope.MetaDataList, { selected: true });
            if (typeof $scope.ValidateSubButtonMetaData != 'undefined' && $scope.ValidateSubButtonMetaData.length > 0) {
                angular.copy($scope.ValidateSubButtonMetaData[0], $scope.MetaDataModel);
                $timeout(function () {
                    $scope.PageEvents.isSubMetaData = true;
                    switch ($scope.appsVar.selectedMetaData) {
                        case "CUSTOM1":
                            var selectedNextDisplayText = $filter('filter')($scope.metaDataList, { MetaDataItem: 'CUSTOM2' });
                            $scope.SubMetaDataDisplayName = selectedNextDisplayText[0].DisplayText;
                            break;
                        case "CUSTOM29":
                            var selectedNextDisplayText = $filter('filter')($scope.metaDataList, { MetaDataItem: 'CUSTOM30' });
                            $scope.SubMetaDataDisplayName = selectedNextDisplayText[0].DisplayText;
                            break;
                    }
                    subrequestModel.libraryName = $scope.selectedLibrary;
                    subrequestModel.pagenumber = 1;
                    subrequestModel.pageLength = 10;
                    subrequestModel.isTotal = true;
                    subrequestModel.searchText = $scope.MetadataSubItem.SearchText;
                    var subMetadata = MetaDataService.getSubMetaDataList(subrequestModel, $scope.vm.selectedApp.MetaDataItem, $scope.ValidateSubButtonMetaData[0].Alias);
                    subMetadata.then(function (response) {
                        $scope.appsVar.initialLoading = false;
                        if (response.data.rows != undefined) {
                            if (response.data.rows.length > 0) {
                                if (response.data.rows[0].cell.length > 0) {
                                    $scope.subMetaDataList = response.data.rows[0].cell[0];
                                    $scope.SubMetaDataTablePagination.totalCount = response.data.total;
                                    $scope.isSubPrevDisable = suboffset <= 1;
                                    $scope.isSubNextDisable = (suboffset * sublimit) >= response.data.total;

                                }
                                else {
                                    $scope.subMetaDataList = '';
                                }
                            }
                            else {
                                $scope.subMetaDataList = '';
                            }
                        }
                        else {
                            $scope.subMetaDataList = '';
                        }


                    }, function () {
                        alert('Data fetching failed.');
                    });
                    $scope.isSubPrevDisable = true;
                    //$("#Sub_MetaData").modal();
                    var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
                    var dialogObject = {
                        controller: DialogController,
                        scope: $scope,
                        preserveScope: true,
                        templateUrl: 'Views/NgTemplates/SubMetaDataTable.html',
                        parent: angular.element(document.body),
                        clickOutsideToClose: true,
                        fullscreen: useFullScreen
                    };
                    $mdDialog.show(dialogObject)
                    .then(function (answer) {
                        $scope.status = 'You said the information was "' + answer + '".';
                    }, function () {
                        $scope.status = 'You cancelled the dialog.';
                    });
                    $scope.$watch(function () {
                        return $mdMedia('xs') || $mdMedia('sm');
                    }, function (wantsFullScreen) {
                        $scope.customFullscreen = (wantsFullScreen === true);
                    });

                    return true;
                });
           
            }
            else {
                $scope.showAlertMessage('Select a Metadata to implement submetadata.');
                return false;
            }
        },
        onSearch: function () {
            $scope.ValidateSubButtonMetaData = $scope.selected;//= $filter('filter')($scope.MetaDataList, { selected: true });
            if (typeof $scope.ValidateSubButtonMetaData != 'undefined' && $scope.ValidateSubButtonMetaData.length > 0) {
                angular.copy($scope.ValidateSubButtonMetaData[0], $scope.MetaDataModel);
                $timeout(function () {
                    $scope.PageEvents.isSubMetaData = true;
                    switch ($scope.appsVar.selectedMetaData) {
                        case "CUSTOM1":
                            var selectedNextDisplayText = $filter('filter')($scope.metaDataList, { MetaDataItem: 'CUSTOM2' });
                            $scope.SubMetaDataDisplayName = selectedNextDisplayText[0].DisplayText;
                            break;
                        case "CUSTOM29":
                            var selectedNextDisplayText = $filter('filter')($scope.metaDataList, { MetaDataItem: 'CUSTOM30' });
                            $scope.SubMetaDataDisplayName = selectedNextDisplayText[0].DisplayText;
                            break;
                    }
                    subrequestModel.libraryName = $scope.selectedLibrary;
                    subrequestModel.pagenumber = 1;
                    subrequestModel.pageLength = 10;
                    subrequestModel.isTotal = true;
                    subrequestModel.searchText =  $scope.MetadataSubItem.SearchText;
                    var subMetadata = MetaDataService.getSubMetaDataList(subrequestModel, $scope.vm.selectedApp.MetaDataItem, $scope.ValidateSubButtonMetaData[0].Alias);
                    subMetadata.then(function (response) {
                        $scope.appsVar.initialLoading = false;
                        if (response.data.rows != undefined) {
                            if (response.data.rows.length > 0) {
                                if (response.data.rows[0].cell.length > 0) {
                                    $scope.subMetaDataList = response.data.rows[0].cell[0];
                                    $scope.isSubPrevDisable = suboffset <= 1;
                                    $scope.isSubNextDisable = (suboffset * sublimit) >= response.data.total;
                                }
                                else {
                                    $scope.subMetaDataList = '';
                                }
                            }
                            else {
                                $scope.subMetaDataList = '';
                            }
                        }
                        else {
                            $scope.subMetaDataList = '';
                        }


                    }, function () {
                        alert('Data fetching failed.');
                    });
                    $scope.isSubPrevDisable = true;
                    return true;
                });
               
            }
            else {
                $scope.showAlertMessage('Select a Metadata to implement submetadata.');
                return false;
            }
        },
        Add: function (event) {
            $scope.ShowWarning = false;
            $scope.validation.showMessage = false;
            $scope.MetaDataModel = metaDataFactory.meatDataInitialValues();
            $scope.PageEvents.UserAction = 'Add';
            $('#popup-add-sub-metadata').slideToggle();
        },
        Edit: function (row) {
            $scope.PageEvents.UserAction = 'Edit';
            $scope.MetaDataModel = metaDataFactory.meatDataInitialValues();
            $scope.ValidateMetaData = $scope.subSelected;//= $filter('filter')($scope.subMetaDataList, { selected: true });
            if (typeof $scope.ValidateMetaData != 'undefined' && $scope.ValidateMetaData.length > 0) {
                angular.copy($scope.ValidateMetaData[0], $scope.MetaDataModel);
                $('#popup-add-sub-metadata').slideToggle();
                //return true;
            }
            else {
                //$mdDialog.show(
                //        $mdDialog.alert()
                //            .parent(angular.element(document.querySelector('#popupContainer')))
                //            .clickOutsideToClose(true)
                //            .title('No ' + $scope.SubMetaDataDisplayName + ' selected.')
                //            .textContent('Please select one ' + $scope.SubMetaDataDisplayName + ' to edit.')
                //            .ariaLabel('Edit info dialog')
                //            .ok('OK')
                //            //.targetEvent(ev)
                //    ).then(function () { $scope.MetadataSubItem.Show() });
                this.Header = 'No ' + $scope.SubMetaDataDisplayName + ' selected.';
                this.Message = 'Please select one ' + $scope.SubMetaDataDisplayName + ' to edit.';
                $('#popup-alert-dialog-bg').slideToggle();
                //return false;
            }
        },
        Delete: function (ev) {
            $scope.MetaDataModel = metaDataFactory.meatDataInitialValues();
            var metaDataObject = $scope.subSelected[0];//= $filter('filter')($scope.subMetaDataList, { selected: true })[0];
            if (metaDataObject) {
                this.Header = 'Would you like to delete selected ' + $scope.SubMetaDataDisplayName + '?';
                this.Message = 'You are going to delete ' + metaDataObject.Alias + '. Do you want to proceed?';
                $('#popup-confirm-dialog-bg').slideToggle();
            } else {
                this.Header = 'No ' + $scope.SubMetaDataDisplayName + ' selected.';
                this.Message = 'Please select one ' + $scope.SubMetaDataDisplayName + ' to delete.';
                $('#popup-alert-dialog-bg').slideToggle();
            }
        },
        ProceedDelete: function () {
            var selectedMetaDataItems = $scope.subSelected[0];//= $filter('filter')($scope.subMetaDataList, { selected: true })[0];
            var promise = MetaDataService.deleteSubMetaData($scope.selectedLibrary, $scope.vm.selectedApp.MetaDataItem, selectedMetaDataItems.Alias, $scope.ValidateSubButtonMetaData[0].Alias);
            promise.then(function (response) {
                if (response.data.rows.length > 0 && response.data.rows[0].cell[0] == 'Success') {
                    $('#popup-confirm-dialog-bg').slideToggle();
                    $scope.MetadataSubItem.onSearch();
                }
            }, function () {
                $('#popup-confirm-dialog-bg').slideToggle();
            }
            );
        },
        CloseAddEditDialog: function () {
            $scope.MetaDataModel = metaDataFactory.meatDataInitialValues();
            $scope.validation.showMessage = false;
            $('#popup-add-sub-metadata').slideToggle();
            $scope.ShowWarning = false;
        },
        CloseAlertDialog: function () {
            $('#popup-alert-dialog-bg').slideToggle();
        },
        CloseDeleteDialog: function () {
            $('#popup-confirm-dialog-bg').slideToggle();
        }
    }

    $scope.PageEvents.ShowSubMetaDataList = $scope.MetadataSubItem.Show;

    var searchTimeout;
    $scope.$watch(function () { return $scope.MetadataSubItem.SearchText }, function (val) {
        if ($scope.MetadataSubItem.SearchText.length > 0) {
            isSubserchTxtDirty = true;
        }
        if (searchTimeout) $timeout.cancel(searchTimeout);

        searchTimeout = $timeout(function () {
            if (isSubserchTxtDirty) {
                $scope.MetadataSubItem.onSearch();
            }
        }, 2000);
    }, true);

    //getMetaDataList($scope.appsVar.selectedMetaData);

    $scope.$on('InitializeTabContents', function () {
        Initalize();
    });

    function Initalize() {
        offset = 1;     
        getMetaDataList($scope.appsVar.selectedMetaData);
    }

    $scope.loadMoreOnScrollEnd = function () {
        if ($scope.haveMoreRows) {
            getMetaDataList($scope.appsVar.selectedMetaData);
            $scope.ScrollCounter = false;
        }
    };

    $scope.$on('metaDataComboChanged', function () {
        if ($scope.appsVar.selectedMetaData == 'CUSTOM1' || $scope.appsVar.selectedMetaData == 'CUSTOM29')
        { $scope.PageEvents.ShowSubMetaDataList = $scope.MetadataSubItem.Show; } else { $scope.PageEvents.ShowSubMetaDataList = 'undefined'; }
        getMetaDataList($scope.appsVar.selectedMetaData);
    });

    $scope.$on('onClearAllClicked', function () {
        requestModel.filters = [];
        getMetaDataList($scope.appsVar.selectedMetaData);
    })

    function getMetaDataList(MetaType) {
        $scope.selected = [];
        $scope.vm.selectedApp.MetaDataItem = MetaType;
        if (!$scope.selectedLibrary || $scope.selectedLibrary.length == 0) return;
        //if ($scope.lastSelectedLibrary == $scope.selectedLibrary && $scope.lastCursorValue >= $scope.cursorValue) return;

        $scope.lastCursorValue = $scope.cursorValue;
        $scope.lastSelectedLibrary = $scope.selectedLibrary;


        requestModel.libraryName = $scope.selectedLibrary;
        //requestModel.pagenumber = offset;
        //requestModel.pageLength = limit;
        requestModel.isTotal = total;
        requestModel.searchText = $scope.appsVar.SearchText;
        requestModel.sortValue = requestModel.sortKey == $scope.appsVar.sortField ? 'DESC' : 'ASC';
        requestModel.sortKey = $scope.appsVar.sortField;       
        //var lstMetadata = MetaDataService.getMetaDataList($scope.selectedLibrary, $scope.cursorValue, 10, $scope.appsVar.SearchText, ComboType);
        //var lstMetadata = MetaDataService.getMetaDataList($scope.selectedLibrary, 1, 10, true, $scope.appsVar.SearchText, MetaType);
        lstMetadata = MetaDataService.getMetaDataList(requestModel, MetaType);
        lstMetadata.then(function (response) {
            $scope.appsVar.initialLoading = false;
            if (response.data.rows != undefined) {
                if (response.data.rows.length > 0) {
                    if (response.data.rows[0].cell.length > 0) {
                        //$scope.isPrevDisable = offset <= 1;
                        //$scope.isNextDisable = offset * limit >= 
                        $scope.query.totalCount = response.data.total;
                        $scope.MetaDataList = response.data.rows[0].cell[0];
                        if (MetaType == 'CUSTOM1' || MetaType == 'CUSTOM29') {
                            $timeout(function () {
                                switch (MetaType) {
                                    case "CUSTOM1":
                                        var selectedNextDisplayText = $filter('filter')($scope.metaDataList, { MetaDataItem: 'CUSTOM2' });
                                        $scope.appsVar.tooltipValue = selectedNextDisplayText[0].DisplayText;
                                        break;
                                    case "CUSTOM29":
                                        var selectedNextDisplayText = $filter('filter')($scope.metaDataList, { MetaDataItem: 'CUSTOM30' });
                                        $scope.appsVar.tooltipValue = selectedNextDisplayText[0].DisplayText;
                                        break;
                                }
                            });
                        }

                    }
                    else {
                        $scope.MetaDataList = '';
                    }
                }
                else {
                    $scope.MetaDataList = '';
                }
            }
            else {
                $scope.MetaDataList = '';
            }
           // $('#card-more-button').attr('disabled', 'disabled');
            $scope.vm.selectedApp.ResponseCount = $scope.MetaDataList.length;
            
        }, function () {
            alert('Data fetching failed.');
        });
      //  $('#card-more-button').attr('disabled', 'disabled');
    }

    $scope.select = function (item, $event) {
        if ($event.ctrlKey) {
            item.selected ? item.selected = false : item.selected = true;
        }
        else {
            this.getAllSelectedRows(item);
        }
        var selectedUserList = $scope.selected;//= $filter('filter')($scope.MetaDataList, { selected: true });
        if (selectedUserList.length == 0) {
            $('#card-more-button').attr('disabled', 'disabled')
        } else {
            $('#card-more-button').removeAttr('disabled')
        }
    };

    $scope.getAllSelectedRows = function (item) {
        angular.forEach($scope.MetaDataList, function (p) {
            p.selected = false; //set them all to false
        });
        item.selected = true; //set the clicked one to true
    };

    (function ($) {
        $(document).ready(function () {
            $('#card-more-button').attr('disabled', 'disabled');
        });
    })(jQuery);

    $scope.subselect = function (item, $event) {
        if ($event.ctrlKey) {
            item.selected ? item.selected = false : item.selected = true;
        }
        else {
            this.getAllSubSelectedRows(item);
        }
    };

    $scope.getAllSubSelectedRows = function (item) {
        angular.forEach($scope.subMetaDataList, function (p) {
            p.subSelected = false; //set them all to false
        });
        item.subSelected = true; //set the clicked one to true
    };

    $scope.cancelAddMetaData = function () {
        $scope.MetaDataModel = metaDataFactory.meatDataInitialValues();
        $scope.validation.showMessage = false;
        //$('#Add_Edit_MetaData').modal('hide');
        $mdDialog.hide();
        $scope.ShowWarning = false;
        //$('md-input-container input').removeClass('ng-untouched');
        //$('md-input-container input').addClass('ng-touched');
        //$('md-input-container').addClass('md-input-invalid');
        //$('#metadataAliasValidation .my-message').css('opacity', '1');
        //$('#metadataAliasValidation .my-message').css('margin-top', '0px');

        //$scope.metadataForm.metadataAlias.$setValidity("size", false);
    }

    $scope.AddMetaData = function () {
        $scope.posting = true;
        $scope.validation.showMessage = true;
        if ($scope.MetaDataModel.Alias == '' || $scope.metadataForm.$invalid) {
            $scope.posting = false;
            return;
        } else {
            $scope.lastCursorValue = $scope.cursorValue;
            $scope.lastSelectedLibrary = $scope.selectedLibrary;

            if ($scope.PageEvents.isSubMetaData) {
                var promise = MetaDataService.addMetaData($scope.MetaDataModel, $scope.selectedLibrary, $scope.vm.selectedApp.MetaDataItem, $scope.ValidateSubButtonMetaData[0].Alias);
                promise.then(function (response) {
                    //if (response.data == 'Success') {
                    //    $scope.validation.showMessage = false;
                    //    setTimeout(function () {
                    //        $('#Add_Edit_MetaData').modal('hide');
                    //        $scope.ShowWarning = false;
                    //        $scope.MetaDataModel = metaDataFactory.meatDataInitialValues();
                    //    }, 1500);
                    //}

                    if (response.data.rows.length > 0) {
                        if (response.data.rows[0].cell.length > 0) {
                            if (response.data.rows[0].cell[2] == 'Success') {
                                //getMetaDataList($scope.selectedMetaData);
                                $scope.showValidation = false;
                                //setTimeout(function () {
                                    //$('#Add_Edit_MetaData').modal('hide');
                                  //  $mdDialog.hide();
                                    $scope.ShowWarning = false;
                                    $('#popup-add-sub-metadata').slideToggle();
                                    $scope.MetaDataModel = metaDataFactory.meatDataInitialValues();
                               // }, 1500);
                            }
                            $scope.ErrorMessage = response.data.rows[0].cell[2];
                            $scope.ShowWarning = true;
                            getMetaDataSubList($scope.selectedLibrary, 1, 10, true, $scope.appsVar.SearchText, $scope.vm.selectedApp.MetaDataItem, $scope.ValidateSubButtonMetaData[0].Alias);


                        }
                    }

                    $scope.posting = false;

                }, function () {
                });
            }
            else {
                var promise = MetaDataService.addMetaData($scope.MetaDataModel, $scope.selectedLibrary, $scope.vm.selectedApp.MetaDataItem);
                promise.then(function (response) {
                    if (response.data.rows.length > 0) {
                        if (response.data.rows[0].cell.length > 0) {
                            if (response.data.rows[0].cell[2] == 'Success') {
                                getMetaDataList($scope.appsVar.selectedMetaData);
                                $scope.showValidation = false;
                               // setTimeout(function () {
                                    //$('#Add_Edit_MetaData').modal('hide');
                                    $mdDialog.hide();
                                    $scope.ShowWarning = false;
                                    $scope.MetaDataModel = metaDataFactory.meatDataInitialValues();
                               // }, 1500);
                            }
                            $scope.ErrorMessage = response.data.rows[0].cell[2];
                            $scope.ShowWarning = true;
                        }
                    }
                    $scope.posting = false;

                }, function () {
                });
            }


        }
    }

    $scope.SubMetaDataSearch = function (subSerach) {
        getMetaDataSubList($scope.selectedLibrary, 1, 10, true, subSerach, $scope.vm.selectedApp.MetaDataItem, $scope.ValidateSubButtonMetaData[0].Alias);
    }

    function getMetaDataSubList(SelectedLibrary, offset, Limit, Total, SearchText, selectedMetaDataItem, CurrentAlias) {
        $scope.subSelected = [];
        subrequestModel.libraryName = $scope.selectedLibrary;
        subrequestModel.pagenumber = offset;
        subrequestModel.pageLength = Limit;
        subrequestModel.isTotal = Total;
        subrequestModel.searchText = SearchText;
      /*  subrequestModel.sortValue = requestModel.sortKey == $scope.appsVar.sortField ? 'DESC' : 'ASC';
        subrequestModel.sortKey = $scope.appsVar.sortField;*/

        var subMetadata = MetaDataService.getSubMetaDataList(subrequestModel, selectedMetaDataItem, CurrentAlias);
        subMetadata.then(function (response) {
            $scope.appsVar.initialLoading = false;
            if (response.data.rows != undefined) {
                if (response.data.rows.length > 0) {
                    if (response.data.rows[0].cell.length > 0) {
                        $scope.isSubPrevDisable = suboffset <= 1;
                        $scope.isSubNextDisable = suboffset * sublimit >= response.data.total;
                        $scope.subMetaDataList = response.data.rows[0].cell[0];
                        $scope.SubMetaDataTablePagination.totalCount = response.data.total;
                    }
                    else {
                        $scope.subMetaDataList = '';
                    }
                }
                else {
                    $scope.subMetaDataList = '';
                }
            }
            else {
                $scope.subMetaDataList = '';
            }


        }, function () {
            alert('Data fetching failed.');
        });

    }

    $scope.EditMetaData = function () {
        $scope.posting = true;
        $scope.validation.showMessage = true;
        if ($scope.MetaDataModel.Alias == '') {
            $scope.posting = false;
            return;
        } else {
            if ($scope.PageEvents.isSubMetaData) {
                var UpdateData = MetaDataService.EditMetaData($scope.selectedLibrary, $scope.MetaDataModel, $scope.vm.selectedApp.MetaDataItem, $scope.ValidateSubButtonMetaData[0].Alias);
                //UpdateData.then(function (msg) {
                //    $scope.MetaDataModel = metaDataFactory.meatDataInitialValues();
                //    $scope.validation.showMessage = false;
                //    $scope.posting = false;
                //    $('#Add_Edit_MetaData').modal('toggle');
                //}, function () {
                //    alert('Error in updating record');
                //});
                UpdateData.then(function (response) {
                    if (response.data.rows.length > 0) {
                        if (response.data.rows[0].cell.length > 0) {
                            if (response.data.rows[0].cell[2] == 'Success') {
                                //getMetaDataList($scope.selectedMetaData);
                                $scope.showValidation = false;
                                setTimeout(function () {
                                    $scope.ShowWarning = false;
                                    $('#popup-add-sub-metadata').slideToggle();
                                    $scope.MetaDataModel = metaDataFactory.meatDataInitialValues();
                                    $scope.posting = false;
                                }, 1500);
                            }
                            $scope.ErrorMessage = response.data.rows[0].cell[2];
                            $scope.ShowWarning = true;
                        }
                    }
                    getMetaDataSubList($scope.selectedLibrary, 1, 10, true, $scope.appsVar.SearchText, $scope.vm.selectedApp.MetaDataItem, $scope.ValidateSubButtonMetaData[0].Alias);



                }, function () {
                });
            }
            else {
                var UpdateData = MetaDataService.EditMetaData($scope.selectedLibrary, $scope.MetaDataModel, $scope.vm.selectedApp.MetaDataItem);
                UpdateData.then(function (response) {
                    if (response.data.rows.length > 0) {
                        if (response.data.rows[0].cell.length > 0) {
                            if (response.data.rows[0].cell[2] == 'Success') {
                                getMetaDataList($scope.appsVar.selectedMetaData);
                                $scope.showValidation = false;
                                setTimeout(function () {
                                    //$('#Add_Edit_MetaData').modal('hide');
                                    $mdDialog.hide();
                                    $scope.ShowWarning = false;
                                    $scope.MetaDataModel = metaDataFactory.meatDataInitialValues();
                                    $scope.posting = false;
                                }, 1500);
                            }
                            $scope.ErrorMessage = response.data.rows[0].cell[2];
                            $scope.ShowWarning = true;
                        }
                    }


                }, function () {
                });
            }
        }
    }

    $scope.PageEvents.Add = function (event) {
        $scope.ShowWarning = false;
        $scope.validation.showMessage = false;
        $scope.MetaDataModel = metaDataFactory.meatDataInitialValues();
        $scope.PageEvents.UserAction = 'Add';
        //$('#Add_Edit_MetaData').modal();
        var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;

        var dialogObject = {
            // controller: UserController,
            controller: DialogController,
            scope: $scope,        // use parent scope in template
            preserveScope: true,  // do not forget this if use parent scope
            templateUrl: 'Views/NgTemplates/AddEditMetaData.html',
            parent: angular.element(document.body),
            targetEvent: event,
            clickOutsideToClose: true,
            fullscreen: useFullScreen
        };
        $mdDialog.show(dialogObject)
        .then(function (answer) {
            $scope.status = 'You said the information was "' + answer + '".';
        }, function () {
            $scope.status = 'You cancelled the dialog.';
        });
        $scope.$watch(function () {
            return $mdMedia('xs') || $mdMedia('sm');
        }, function (wantsFullScreen) {
            $scope.customFullscreen = (wantsFullScreen === true);
        });
    };

    $scope.PageEvents.Edit = function (row) {
        $scope.PageEvents.UserAction = 'Edit';
        if (row) {
            var MetaDataID = $scope.appsVar.selectedRecordId;
            $scope.ValidateMetaData = $filter('filter')($scope.MetaDataList, { Alias: MetaDataID });
        }
        else {
            $scope.ValidateMetaData = $scope.selected;//= $filter('filter')($scope.MetaDataList, { selected: true });
        }
        if (typeof $scope.ValidateMetaData != 'undefined' && $scope.ValidateMetaData.length > 0) {
            angular.copy($scope.ValidateMetaData[0], $scope.MetaDataModel);
            //$("#Add_Edit_MetaData").modal();
            var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
            $mdDialog.show({
                //controller: DialogController selectedRecordId,
                controller: DialogController,
                scope: $scope,        // use parent scope in template
                preserveScope: true,
                templateUrl: 'Views/NgTemplates/AddEditMetaData.html',
                parent: angular.element(document.body),
                //targetEvent: event,
                clickOutsideToClose: true,
                fullscreen: useFullScreen
            })
            .then(function (answer) {
                $scope.status = 'You said the information was "' + answer + '".';
            }, function () {
                $scope.status = 'You cancelled the dialog.';
            });
            $scope.$watch(function () {
                return $mdMedia('xs') || $mdMedia('sm');
            }, function (wantsFullScreen) {
                $scope.customFullscreen = (wantsFullScreen === true);
            });
            return true;
        }
        else {
            $scope.showAlertMessage('Select a MetaData to edit.');
            return false;
        }
    }

    $scope.PageEvents.BindLabel = function (data) {
        if ($scope.PageEvents.UserAction == 'Add') {
            return 'Add'
        } else {
            return 'Save';
        }
    }

    $scope.PageEvents.Save = function () {
        if ($scope.PageEvents.UserAction == 'Add') {
            return $scope.AddMetaData();
        } else {
            return $scope.EditMetaData();
        }
    }

    $scope.PageEvents.SubEdit = function (row) {
        $scope.PageEvents.UserAction = 'Edit';
        if (row) {
            var MetaDataID = $scope.appsVar.selectedRecordId;
            $scope.ValidateMetaData = $filter('filter')($scope.subMetaDataList, { Alias: MetaDataID });
        }
        else {
            $scope.ValidateMetaData = $scope.subSelected;//= $filter('filter')($scope.subMetaDataList, { selected: true });
        }
        if (typeof $scope.ValidateMetaData != 'undefined' && $scope.ValidateMetaData.length > 0) {
            angular.copy($scope.ValidateMetaData[0], $scope.MetaDataModel);
            //$("#Add_Edit_MetaData").modal();
            var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;

            var dialogObject = {
                // controller: UserController,
                controller: DialogController,
                scope: $scope,        // use parent scope in template
                preserveScope: true,  // do not forget this if use parent scope
                templateUrl: 'Views/NgTemplates/AddEditMetaData.html',
                parent: angular.element(document.body),
                //targetEvent: event,
                clickOutsideToClose: true,
                fullscreen: useFullScreen
            };
            $mdDialog.show(dialogObject)
            .then(function (answer) {
                $scope.status = 'You said the information was "' + answer + '".';
            }, function () {
                $scope.status = 'You cancelled the dialog.';
            });
            $scope.$watch(function () {
                return $mdMedia('xs') || $mdMedia('sm');
            }, function (wantsFullScreen) {
                $scope.customFullscreen = (wantsFullScreen === true);
            });
            return true;
        }
        else {
            $mdDialog.show(
                    $mdDialog.alert()
                        .parent(angular.element(document.querySelector('#popupContainer')))
                        .clickOutsideToClose(true)
                        .title('No ' + $scope.SubMetaDataDisplayName + ' selected.')
                        .textContent('Please select one ' + $scope.SubMetaDataDisplayName + ' to edit.')
                        .ariaLabel('Edit info dialog')
                        .ok('OK')
                        //.targetEvent(ev)
                ).then(function () { $scope.MetadataSubItem.Show() });
            return false;
        }
    }

    $scope.PageEvents.Delete = function (ev) {
        var MetaDataID = $scope.appsVar.selectedRecordId;
        var metaDataObject = $scope.selected[0];// = $filter('filter')($scope.MetaDataList, { selected: true })[0];
        //var metadataTitle = $filter('customLabel')($scope.appsVar.CaptionsList, $scope.appsVar.selectedMetaData );
        if (metaDataObject) {
            var confirm = $mdDialog.confirm()
            .title('Would you like to delete selected ' + $scope.appsVar.selectedMetaData + '?')
            .textContent('You are going to delete ' + metaDataObject.Alias + '. Do you want to proceed?')
            .ariaLabel('Delete Metadata')
            .targetEvent(ev)
            .ok('Proceed')
            .cancel('Cancel');
            $mdDialog.show(confirm).then(function () {
                var selectedMetaDataItems = $scope.selected[0];//= $filter('filter')($scope.MetaDataList, { selected: true })[0];
                var promise = MetaDataService.deleteMetaData($scope.selectedLibrary, $scope.appsVar.selectedMetaData, selectedMetaDataItems.Alias);

                promise.then(function (response) {
                    if (response.data.rows.length > 0 && response.data.rows[0].cell[0] == 'Success') {
                        offset = 1;
                        getMetaDataList($scope.appsVar.selectedMetaData);
                    }
                }, function () {
                    $scope.status = 'You decided to keep your debt.';
                });
            });
        } else {
            $mdDialog.show(
                $mdDialog.alert()
                    .parent(angular.element(document.querySelector('#popupContainer')))
                    .clickOutsideToClose(true)
                    .title('No ' + $scope.appsVar.selectedMetaData + ' selected.')
                    .textContent('Please select one ' + $scope.appsVar.selectedMetaData + ' to delete.')
                    .ariaLabel('Delete info dialog')
                    .ok('OK')
                    .targetEvent(ev)
            );
        }
    }

    $scope.$on('Search_Click', function () {
        offset = 1;
        requestModel.pagenumber = 1;
        $scope.query.page = 1;
        $scope.query.totalCount = 0;

        getMetaDataList($scope.appsVar.selectedMetaData);
    });

    $scope.$on('onMetaDataSubButtonClick', function () {
        $scope.MetadataSubItem.onSearch();
    });

    $scope.PageEvents.CancelDialog = function () {
        $scope.PageEvents.isSubMetaData = false;
        $scope.txtSubSearch = '';
        //$('#Sub_MetaData').modal('hide');
        $mdDialog.hide();
    }

    $scope.PageEvents.SubImportFile = function () {
        $('#Import_File_MetaData').modal();
    }

    $scope.validation = {
        showMessage: false
    }

    $scope.PrevClick = function () {
        offset = offset - 1;
        getMetaDataList($scope.appsVar.selectedMetaData);
    }

    $scope.NextClick = function () {
        offset = offset + 1;
        getMetaDataList($scope.appsVar.selectedMetaData);
    }

    $scope.SubPrevClick = function () {
        suboffset = suboffset - 1;
        getMetaDataSubList($scope.selectedLibrary, suboffset, sublimit, subtotal, $scope.appsVar.SearchText, $scope.vm.selectedApp.MetaDataItem, $scope.ValidateSubButtonMetaData[0].Alias);
    }

    $scope.SubNextClick = function () {
        suboffset = suboffset + 1;
        getMetaDataSubList($scope.selectedLibrary, suboffset, sublimit, subtotal, $scope.appsVar.SearchText, $scope.vm.selectedApp.MetaDataItem, $scope.ValidateSubButtonMetaData[0].Alias);
    }

    $scope.$on('Refresh_Click', function () {
        getMetaDataList($scope.appsVar.selectedMetaData);
    });

    $scope.$on('onTableSorting', function (object, sortFiled) {
        requestModel.pagenumber = 1;
        $scope.query.page = 1;
        $scope.query.totalCount = 0;
        getMetaDataList($scope.appsVar.selectedMetaData);
    });

    function DialogController($scope, $mdDialog) {
        $scope.hide = function () {
            $mdDialog.hide();
        };
        $scope.cancel = function () {
            $mdDialog.cancel();
        };
        $scope.answer = function () {
            $mdDialog.hide();
        };

        //$scope.addUser = function () {
        // //  $rootScope.$emit('addUseremit');
        //  $scope.addUser1();
        //};
    }

    $scope.$on('onTableFiltering', function (event, value, key) {


        if (requestModel.filters.length > 0) {
            requestModel.filters = jQuery.grep(requestModel.filters, function (filterItem) {
                return filterItem.FilterKey !== key;
            });
        }
       // if (value.length == 0) return;

        var filterValueList = [];
        filterValueList[0] = value;

        var filterItem = { 'FilterKey': key, 'FilterValues': filterValueList };
        requestModel.filters.push(filterItem);
        offset = 1;
        getMetaDataList($scope.appsVar.selectedMetaData);
    })

    $scope.$on('onsubTableFiltering', function (event, value, key) {


        if (subrequestModel.filters.length > 0) {
            subrequestModel.filters = jQuery.grep(subrequestModel.filters, function (filterItem) {
                return filterItem.FilterKey !== key;
            });
        }
       // if (value.length == 0) return;

        var filterValueList = [];
        filterValueList[0] = value;

        var filterItem = { 'FilterKey': key, 'FilterValues': filterValueList };
        subrequestModel.filters.push(filterItem);
        offset = 1;

        $scope.SubMetaDataTablePagination.page = 1;
        $scope.SubMetaDataTablePagination.totalCount = 0;
        
        getMetaDataSubList($scope.selectedLibrary, 1, 10, true, $scope.MetadataSubItem.SearchText, $scope.vm.selectedApp.MetaDataItem, $scope.ValidateSubButtonMetaData[0].Alias);
    });

    $scope.$on('$destroy', function () {
        $scope.PageEvents.Add = 'undefined';
        $scope.PageEvents.Edit = 'undefined';
        $scope.PageEvents.Save = 'undefined';
        $scope.PageEvents.Delete = 'undefined';
        $scope.PageEvents.CancelDialog = 'undefined';
        $scope.PageEvents.ShowSubclassList = 'undefined';
        $scope.PageEvents.ShowSubMetaDataList = 'undefined';        
        $scope.PageEvents.AddRole = 'undefined';
        $scope.PageEvents.ResetPasswordclicked = 'undefined';
        $scope.PageEvents.ViewAssignUser = 'undefined';
        $scope.PageEvents.AssignUser = 'undefined';
        $scope.PageEvents.AssignGroup = 'undefined';
    });

    $scope.ClearMetaDataClick = function () {
        $scope.MetadataSubItem.SearchText = '';
    }

    //new table intgration events


    $scope.query = {
        order: 'name',
        limit: requestModel.pageLength,
        page: requestModel.pagenumber,
        totalCount: 0
    };

    $scope.onPaginate = function (page, limit) {
        
        requestModel.pagenumber = page;
        requestModel.pageLength = limit;
        getMetaDataList($scope.appsVar.selectedMetaData);
        //$scope.promise = $timeout(function () {

        //}, 2000);
    };

    $scope.deSelect = function (item) {
        setContextMenuObject();
    };

    $scope.onSelect = function (item) {
        setContextMenuObject();
    };

    $scope.log = function (item) {

    };

    $scope.loadStuff = function () {
        $scope.promise = $timeout(function () {

        }, 2000);
    };

    $scope.onReorder = function (order) {

        console.log('Scope Order: ' + $scope.query.order);
        console.log('Order: ' + order);

        $scope.promise = $timeout(function () {

        }, 2000);
    };

    $scope.SubMetaDataTablePagination = {
        order: 'name',
        limit: subrequestModel.pageLength,
        page: subrequestModel.pagenumber,
        totalCount: 0
    };


    $scope.onSubMetaDataPaginate = function (page, limit) {
        subrequestModel.pageLength = limit;
        subrequestModel.pagenumber = page;
        getMetaDataSubList($scope.selectedLibrary, subrequestModel.pagenumber, subrequestModel.pageLength, true, $scope.MetadataSubItem.SearchText, $scope.vm.selectedApp.MetaDataItem, $scope.ValidateSubButtonMetaData[0].Alias);

    };

    $scope.SubMetaDatadeSelect = function (item) {
        //setSubContextMenuObject();
    };

    $scope.SubMetaDataonSelect = function (item) {
        //setSubContextMenuObject();
    };

};