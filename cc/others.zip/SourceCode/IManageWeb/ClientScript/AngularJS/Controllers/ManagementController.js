﻿app.controller("ManagementController", managementController);
managementController.$inject = ['$scope', '$rootScope', '$location', '$filter', '$timeout', 'ManagementService'];

function managementController($scope, $rootScope, $location, $filter, $timeout, ManagementService) {
    
    $scope.PageEvents = {
        UserAction: 'Not Defined',
        Add:undefined,
        Edit: undefined,
        Save: undefined,
        Delete: undefined,
        CancelDialog: undefined,
        ShowSubclassList: undefined,
        AddRole: undefined,
        ResetPasswordclicked:undefined,
        Enable: undefined,
        Disable: undefined,
        LockAccount: undefined,
        UnlockAccount: undefined
    }

   

    $scope.isFabOpen = false;

    //$timeout(function () {
    //    $scope.isFabOpen = true;
    //    $timeout(function () {
    //        $scope.isFabOpen = false;
    //    }, 2500);

    //}, 3000);

     function getUserPermission() {
        if (!$scope.selectedLibrary || $scope.selectedLibrary.trim().length == 0) return;

        var userPermission = ManagementService.getUserPermission($scope.selectedLibrary);
        $scope.appsVar.initialLoading = false;
        userPermission.then(function (response) {
            $scope.vm.selectedApp.NoAppsPermission = '';
            $scope.UserApps = response.data;
            //if ($scope.selectedApp.appType == typeof undefined)
            //      $scope.selectedApp.appType = 'UserGroups';
            var count = 0;
            angular.forEach($scope.UserApps, function (userApp) {
                //count += userApp.AppsTypeName == $scope.selectedApp.appType ? 1 : 0;
                count += 1;
            });
            if (count > 0) {
                $scope.vm.selectedApp.NoAppsPermission = '';
               
            }
            else {
                $scope.vm.selectedApp.CurrentTab = '';
                $scope.vm.selectedApp.NoAppsPermission = "You don't have permission to view any apps. Please contact administrator!!!";
                alert($scope.vm.selectedApp.NoAppsPermission);
            }
            $timeout(function () {
                $('#side-menu').metisMenu();

                if ($scope.vm.selectedApp.appType == '') {
                    $scope.vm.selectedApp.CurrentTab = '';
                    $scope.vm.selectedApp.appType = '';

                    $('#side-menu li:nth-child(2):first a:first').trigger("click");

                    $('#side-menu li:nth-child(2):first ul li:first').trigger("click");
                } else
                {
                   // $('#' + $scope.selectedApp.appType).parents('ul').parents('li').trigger("click");
                    $('#' + $scope.vm.selectedApp.appType).trigger("click");

                }


                $(".md-animations-waiting").each(function () {
                    $(this).removeClass('md-animations-waiting');
                    $(this).addClass('md-animations-ready');
                });
                
               
            });
        }, function () {
            alert('Data fetching failed.');
        });
    };

    $scope.$on('onLibrarySelected', function () {
        $scope.appsVar.SearchText = ''
        getUserPermission();
        getCaptins();
    })

  

    $scope.updateAppType = function (type) {
        $scope.vm.selectedApp.appType = type;
        if ($scope.vm.selectedApp.CurrentTab != '') {
            var count = 0;
            angular.forEach($scope.UserApps, function (userApp) {
                if (userApp.AppsID == $scope.vm.selectedApp.CurrentTab && userApp.AppsTypeName == type)
                {
                    count = 1;
                   
                }
            });
            if (count ==0) {
                $scope.vm.selectedApp.CurrentTab = '';

            }
        }
        $timeout(function () {
            if ($scope.vm.selectedApp.CurrentTab == '') {
               
                $('ul.tabs li:visible:first a:first').trigger("click");
                if ($('ul.tabs li:visible:first a:first').text() == " Metadata") {
                    $scope.Metachange('CUSTOM1');
                }
            } else
            {
                if ($('ul.tabs li:visible:first a:first').text() == " Metadata") {
                    // $scope.Metachange('CUSTOM1');
                    $('#' + $scope.appsVar.selectedMetaData).trigger("click");
                } else {
                    $('#' + $scope.vm.selectedApp.CurrentTab).trigger("click");
                }
            }
        });
       
     
    }
    $timeout(function () {
        $('#metaDataSelectPicker>.sel_allcustom_name>.selectpicker').selectpicker();
    });

    
    function getCaptins() {
        var promise = ManagementService.getCaptions($scope.selectedLibrary);
        promise.then(function (response) {
            $scope.appsVar.CaptionsList = [];
            if (response.data.rows != undefined) {
                if (response.data.rows.length > 0) {
                    if (response.data.rows[0].cell.length > 0) {
                      
                        $scope.appsVar.CaptionsList = response.data.rows[0].cell[0];
                        $scope.metaDataList = $filter('filter')($scope.appsVar.CaptionsList, { isMetaItem: true, ParentMetaItem: "" });                    
                        var selectedMetaDataItem = $filter('filter')($scope.metaDataList, { MetaDataItem: $scope.appsVar.selectedMetaData });
                        $scope.vm.selectedApp.CurrentSubTab = selectedMetaDataItem[0].DisplayText;
                        $timeout(function () {
                            $('#metaDataSelectPicker>.sel_allcustom_name>.selectpicker').selectpicker()
                            $('#metaDataSelectPicker>.sel_allcustom_name>.selectpicker').selectpicker('refresh');
                            $('#metaDataSelectPicker>.sel_allcustom_name>.selectpicker').siblings('div').find('ul > li:has("span.text:empty")').remove();
                            $('#metaDataSelectPicker>.sel_allcustom_name>.selectpicker').unbind('change');
                            $('#metaDataSelectPicker>.sel_allcustom_name>.selectpicker').bind('change', function () {
                                $('#metaDataSelectPicker>.sel_allcustom_name>.selectpicker').selectpicker('refresh');                              
                                $scope.appsVar.selectedMetaData = $('#combometadata').selectpicker('val');
                                if ($scope.appsVar.selectedMetaData == 'CLASS') {
                                    $timeout(function () {
                                        $location.path('/class');
                                    })

                                    $scope.vm.selectedApp.CurrentSubTab = 'CLASS';
                                    } else {
                                        $location.path('/metadata');
                                        var selectedMetaDataItem = $filter('filter')($scope.metaDataList, { MetaDataItem: $scope.appsVar.selectedMetaData });
                                        $scope.vm.selectedApp.CurrentSubTab = selectedMetaDataItem[0].DisplayText;
                                        $timeout(function () {
                                            $rootScope.$broadcast('metaDataComboChanged');
                                        });
                                    }                               
                            });
                        });
                    }
                }
            }
        });
    }


    $scope.Metachange = function (tabName) {
        $('#combometadata').parents('li').removeClass('open');
        $scope.appsVar.selectedMetaData = tabName;
        $rootScope.$broadcast('metaDataComboChanged');
      
    }

    $scope.getTabsDetails = function (tabName) {
        $scope.vm.selectedApp.CurrentTab = tabName;

        switch (tabName) {
            case 'Metadata':
                if ($location.path()!="/metadata")
                     $location.path("/metadata");
                $('#metadatacustom').dropdown();
                break;                 

        }


    }
    
    $scope.DeleteClick = function () {
        if ($scope.vm.selectedApp.CurrentTab == 'User') {
            $rootScope.$broadcast('onUserBulkDeleteClick');
        }
        else if ($scope.vm.selectedApp.CurrentTab == 'Group') {
            $rootScope.$broadcast('onGroupBulkDeleteClick');
        }
        else if ($scope.vm.selectedApp.CurrentTab == 'Types') {
            $rootScope.$broadcast('onDocTypeBulkDeleteClick');
        }
        else if ($scope.vm.selectedApp.CurrentTab == 'Roles') {
            $rootScope.$broadcast('onroleBulkDeleteClick');
        }
        else if ($scope.vm.selectedApp.CurrentTab == 'AppSetup') {
            $rootScope.$broadcast('onAppSetupBulkDeleteClick');
        }
    }

    $scope.ValidateBulkDeleteClick = function () {
        if ($scope.vm.selectedApp.CurrentTab == 'User') {
            $rootScope.$broadcast('onUserValidateBulkDeleteClick');
        }
        else if ($scope.vm.selectedApp.CurrentTab == 'Group') {
            $rootScope.$broadcast('onGroupValidateBulkDeleteClick');
        }
        else if ($scope.vm.selectedApp.CurrentTab == 'Types') {
            $rootScope.$broadcast('onTypesValidateBulkDeleteClick');
        }
        else if ($scope.vm.selectedApp.CurrentTab == 'Roles') {
            $rootScope.$broadcast('onRolesValidateBulkDeleteClick');
        }
        else if ($scope.vm.selectedApp.CurrentTab == 'AppSetup') {
            $rootScope.$broadcast('onAppSetupValidateBulkDeleteClick');
        }
    }

    $scope.showAlertMessage = function (message) {
        $("#alert_popup").find('#alertMsgText').text(message);
        $("#alert_popup").modal();
    }

    $scope.showConfirmMessage = function (message) {
        $("#confirm_popup").find('#confirmMsgText').text(message);
        $("#confirm_popup").modal();
    }

    $scope.RefreshClick = function () {
        $scope.$broadcast('Refresh_Click');
    }
    
    $scope.openSubMetaData = function () {
        if ($scope.vm.selectedApp.CurrentTab == 'Metadata') {
            $rootScope.$broadcast('onMetaDataSubButtonClick');

        }
    }

    $scope.AddClick = function (event) {
        $scope.$broadcast('AddButtonClick');
    }

    $scope.showMetadataMenuList = function () {
        $('#metadataCustomMenu').addClass('open');
    }

}