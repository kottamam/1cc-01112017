﻿app.controller("AppSetupController", AppSetupController);
AppSetupController.$inject = ['$scope', '$rootScope', 'AppSetupService',  '$filter'];

function AppSetupController($scope, $rootScope, AppSetupService,  $filter) {

    $scope.haveMoreRows = true;
    $scope.cursorValue = ''
    $scope.loading1 = true;
    $scope.searchValue = null;
    $scope.ShowWarning = false;
    $scope.appsVar.SearchText = '';
    $scope.tableLastRowIndex = 0;
    $scope.isAPrevDisable = true;
    $scope.isANextDisable = true;

    $scope.appsetup = {
        Name: '',
        Type: '',
        Location: '',
        Primary: false,
        DDE: false,
        IntegrationMode: '',
        DDEAppName: '',
        DDETopic: '',
        DDEOpen: '',
        DDEReadOpen: '',
        DDEPRint: '',
        DDEPrintandExitApp: '',
        TempType: ''
    }
    function ResetAppSetupModel() {
        $scope.appsetup.Name = '';
        $scope.appsetup.Type = '';
        $scope.appsetup.Location = '';
        $scope.appsetup.Primary = false;
        $scope.appsetup.DDE = false;
        $scope.appsetup.IntegrationMode = '';
        $scope.appsetup.DDEAppName = '';
        $scope.appsetup.DDETopic = '';
        $scope.appsetup.DDEOpen = '';
        $scope.appsetup.DDEReadOpen = '';
        $scope.appsetup.DDEPRint = '';
        $scope.appsetup.DDEPrintandExitApp = '';
    }

    //$scope.dtColumnDefs = datatableSettingsFactory.dtAppSetupTableColumns;
    //$scope.tableSettings = datatableSettingsFactory.tableSettings();

    //$scope.dtColumnDefstyp = datatableSettingsFactory.dtTypeTableColumns;
    //$scope.tableSettingstyp = datatableSettingsFactory.tableSettings();

  
    function appsetupInitalize() {
        $scope.loading = true;
        $scope.appsetup = null;
        $scope.tableLastRowIndex = 0;
        $scope.lastoffset_val = -1;
        if ($scope.selectedLibrary && $scope.selectedLibrary.trim().length > 0)
            getAppSetupList($scope.selectedLibrary, 0, 10, true);
    }

    if ($scope.selectedLibrary && $scope.selectedLibrary.trim().length > 0)
        getAppSetupList($scope.selectedLibrary, 0, 10, true);
    $rootScope.$on('onAppSetupTabClick', function () {
        $scope.tableLastRowIndex = 0;
        appsetupInitalize();
    })

    $scope.lastoffset_val = 0;
    $scope.lastCursorValue = null;

    $scope.loadMoreOnScrollEnd = function () {
        if ($scope.vm.selectedApp.TotalRowCount > $scope.tableLastRowIndex) {
            if ($scope.selectedLibrary && $scope.selectedLibrary.trim().length > 0)
                getAppSetupList($scope.selectedLibrary, $scope.tableLastRowIndex, 10, true);
        }
    };

    $scope.validation = {
        showMessage: false
    }
    
    $scope.APrevClick = function () {
        if (!$scope.isAPrevDisable) {
            $scope.tableLastRowIndex = $scope.tableLastRowIndex - 10;
            getAppSetupList($scope.selectedLibrary, $scope.tableLastRowIndex, 10, true, $scope.appsVar.SearchText);
        }
    }

    $scope.ANextClick = function () {
        if (!$scope.isANextDisable) {
            $scope.tableLastRowIndex = $scope.tableLastRowIndex + 10;
            getAppSetupList($scope.selectedLibrary, $scope.tableLastRowIndex, 10, true, $scope.appsVar.SearchText);
        }
    }

    function getAppSetupList(selectedLibrary, offset_val, limit_val, total_val) {
        if (!selectedLibrary || selectedLibrary.trim().length == 0) return;
        //if ($scope.lastSelectedLibrary == $scope.selectedLibrary && $scope.lastoffset_val >= offset_val) return;

      //  $scope.lastoffset_val = offset_val;
        $scope.lastSelectedLibrary = $scope.selectedLibrary;

        var lstAppSetup = AppSetupService.getAppSetupList(selectedLibrary, offset_val, limit_val, total_val, $scope.appsVar.SearchText);
        
        lstAppSetup.then(function (response) {
            $scope.appsVar.initialLoading = false;
            if (response.data.rows.length > 0) {
                if (response.data.rows[0].cell.length > 0) {
                    //if (!$scope.AppSetupList || $scope.AppSetupList.length == 0) {
                    //    $scope.tableSettings.scrollTop = 0;
                    //    $scope.tableSettings.scrollBarTop = 0;
                    //    $scope.AppSetupList = response.data.rows[0].cell[0];
                    //    $scope.loading1 = false;
                    //}
                    //else {
                    //    for (itemCount = 0; itemCount < response.data.rows[0].cell[0].length; itemCount++) {
                    //        $scope.AppSetupList.push(response.data.rows[0].cell[0][itemCount]);
                    //    }
                    //}
                    //$scope.tableLastRowIndex += 10;

                    if (offset_val <= 0) {
                        $scope.isAPrevDisable = true;
                    } else {
                        $scope.isAPrevDisable = false;
                    }
                    $scope.AppSetupList = response.data.rows[0].cell[0];
                    $scope.loading1 = false;
                    $scope.vm.selectedApp.TotalRowCount = response.data.rows[0].cell[1];
                    if ($scope.tableLastRowIndex + 10 >= $scope.vm.selectedApp.TotalRowCount) {
                        $scope.isANextDisable = true;
                    } else {
                        $scope.isANextDisable = false;
                    }
                    $('#card-more-button').attr('disabled', 'disabled');
                }
            }
            $scope.vm.selectedApp.ResponseCount = $scope.AppSetupList.length;
            $scope.vm.selectedApp.CurrentTab = 'App Setup';
         
        }, function () {
            alert('Data fetching failed.');
        });
    }

    $scope.select = function (item, $event) {
        if ($event.ctrlKey) {
            item.selected ? item.selected = false : item.selected = true;
        }
        else {
            this.getAllSelectedRows(item);
        }
        var selectedUserList = $filter('filter')($scope.AppSetupList, { selected: true });
        if (selectedUserList.length == 0) {
            $('#card-more-button').attr('disabled', 'disabled')
        } else {
            $('#card-more-button').removeAttr('disabled')
        }
    };

    $scope.getAllSelectedRows = function (item) {
        angular.forEach($scope.AppSetupList, function (p) {
            p.selected = false; //set them all to false
        });
        item.selected = true; //set the clicked one to true
    };

    (function ($) {
        $(document).ready(function () {
            $('#card-more-button').attr('disabled', 'disabled');
        });
    })(jQuery);

    $scope.$on('Search_Click', function (event, args) {
        $scope.haveMoreRows = true;
        $scope.cursorValue = ''
        $scope.loading1 = true;
        $scope.AppSetupList = [];
        $scope.lastCursorValue = null;
        $scope.lastSelectedLibrary = '';
        getAppSetupList($scope.selectedLibrary, 0, 10, true, $scope.appsVar.SearchText);
    });

    $scope.$on('Refresh_Click', function () {
        $scope.haveMoreRows = true;
        $scope.cursorValue = ''
        $scope.loading1 = true;
        $scope.AppSetupList = [];
        $scope.lastCursorValue = null;
        $scope.lastSelectedLibrary = '';
        getAppSetupList($scope.selectedLibrary, 0, 10, true);
        $scope.loading1 = false;
    });

    $scope.singleDeleteClick = function () {
        var s = $scope.appsVar.selectedRecordId;
        var getAppSetup = AppSetupService.DeleteAppSetup(s);

        getAppSetup.then(function (response) {
            if (response.data == "success") {
                $scope.appsVar.selectedRecordId = '';
                $scope.haveMoreRows = true;
                $scope.cursorValue = '';
                $scope.lastSelectedLibrary = '';
                getAppSetupList();
                $scope.showAlertMessage("Selected app setup(s) deleted successfully.");
            } else {
                $scope.showAlertMessage('Failed to delete selected app setup(s).');
            }
        }, function () {
            $scope.showAlertMessage('Failed to delete selected app setup(s).');
        });

    };

    $rootScope.$on('onAppSetupValidateBulkDeleteClick', function () {
        $scope.ValidateAppSetup = [];
        AppSetupValidateBulkDeleteClick();
    })

    function AppSetupValidateBulkDeleteClick() {
        $scope.ValidateAppSetup = $filter('filter')($scope.AppSetupList, { selected: true });
        if (typeof $scope.ValidateAppSetup !== 'undefined' && $scope.ValidateAppSetup.length > 0) {
            $scope.showConfirmMessage('Are you sure to delete selected app setup(s)?');
            return true;
        }
        else {
            $scope.showAlertMessage('Select app setup(s) to delete.');
            return false;
        }
    }

    $rootScope.$on('onAppSetupBulkDeleteClick', function () {
        $scope.Role = [];
        AppSetupBulkDeleteClick();
    })

    function AppSetupBulkDeleteClick() {
        $scope.AppSetup = $filter('filter')($scope.AppSetupList, { selected: true });
        var getAppSetup = AppSetupService.DeleteAppSetup($scope.AppSetup);

        getAppSetup.then(function (response) {
            if (response.data == "success") {
                $scope.appsVar.selectedRecordId = '';
                $scope.haveMoreRows = true;
                $scope.cursorValue = '';
                $scope.lastSelectedLibrary = '';
                getAppSetupList();
                $scope.showAlertMessage("Selected app setup(s) deleted successfully.");
            } else {
                $scope.showAlertMessage('Failed to delete selected app setup(s).');
            }
        }, function () {
            $scope.showAlertMessage('Failed to delete selected app setup(s).');
        });


    }

    $scope.singleAppSetupDeleteConfirmMessageClick = function () {
        $scope.showSingleAppSetupDeleteConfirmMessage('Are you sure to delete ' + $scope.appsVar.selectedRecordId + '?');
    };

    $scope.showSingleAppSetupDeleteConfirmMessage = function (message) {
        $("#singleAppSetupconfirm_popup").find('#singleAppSetupconfirmMsgText').text(message);
        $("#singleAppSetupconfirm_popup").modal();
    }

    //getTypes();
    //function getTypes() {
    //    var promise = AppSetupService.getTypesForCombobox($scope.selectedLibrary);
    //    promise.then(function (response) {
    //        if (response.data.rows.length > 0) {
    //            if (response.data.rows[0].cell.length > 0) {
    //                $scope.TypeComboBox = response.data.rows[0].cell[0];
    //                //$scope.selectedType = $scope.TypeComboBox[0].TAlias;
    //                //$scope.appsetup.Type = $scope.TypeComboBox[0].TAlias;
    //            }
    //        }
    //        else {
    //            alert("No Types");
    //        }
    //    });
    //};

    //$scope.$on('onAppSetupAddButton_Click', function (event, data) {
    //    $scope.validation.showMessage = false;
    //    ResetAppSetupModel();
    //    $("#Add_virtual_appSetup").modal();
    //    return true;
    //});

    //$scope.cancelAddAppSetupDialoge = function () {
    //    ResetAppSetupModel();
    //    $scope.validation.showMessage = false;
    //    $('#Add_virtual_appSetup').modal('hide');
    //    $scope.ShowWarning = false;
    //}

    $scope.addAppSetup = function () {
        $scope.posting = true;
        $scope.validation.showMessage = true;
        if ($scope.appsetup.Name == '' || $scope.appsetup.DDEAppName == '' || $scope.appsetup.DDETopic == '' || $scope.appsetup.Location == ''
            || $scope.appsetup.IntegrationMode == '' || $scope.appsetup.Type == '' || $scope.appsetup.Type == null) {
            $scope.posting = false;
            return;
        } else {
            var promise = AppSetupService.addAppSetup($scope.appsetup, $scope.selectedLibrary);
            promise.then(function (response) {
                if (response.data.rows.length > 0) {
                    if (response.data.rows[0].cell.length > 0) {

                        if (response.data.rows[0].cell[2] == 'Success') {
                            $scope.validation.showMessage = false;
                            setTimeout(function () {
                                $('#Add_virtual_appSetup').modal('hide');
                                $scope.ShowWarning = false;
                            }, 1500);                         

                        }
                        $scope.ErrorMessage = response.data.rows[0].cell[2];
                        $scope.ShowWarning = true;
                    }

                }
                $scope.posting = false;

            }, function () {
            });
        }
    }


    $scope.cancelEditAppSetup = function () {
        $scope.validation.showMessage = false;
        ResetAppSetupModel();
        $("#Edit_virtual_appSetup").modal('hide');
        $scope.ShowWarning = false;
    }

    $scope.$on('onAppSetupEditButton_Click', function () {
        $scope.AppSetupEdit = $filter('filter')($scope.AppSetupList, { selected: true });
        if (typeof $scope.AppSetupEdit !== 'undefined' && $scope.AppSetupEdit.length > 0) {
            angular.copy($scope.AppSetupEdit[0], $scope.appsetup);
            $("#Edit_virtual_appSetup").modal();
            return true;
        }
        else {
            $scope.showAlertMessage('Select a AppSetup to edit.');
            return false;
        }
    });

    $scope.EditAppSetup = function () {
        $scope.posting = true;
        $scope.validation.showMessage = true;
        if ($scope.appsetup.Name == '' || $scope.appsetup.DDEAppName == '' || $scope.appsetup.DDETopic == '' || $scope.appsetup.Location == ''
            || $scope.appsetup.IntegrationMode == '' || $scope.appsetup.Type == '' || $scope.appsetup.Type == null) {
            $scope.posting = false;
            return;
        } else {
            var UpdateData = AppSetupService.EditAppSetup($scope.selectedLibrary, $scope.appsetup);
            UpdateData.then(function (response) {
                if (response.data.rows.length > 0) {
                    if (response.data.rows[0].cell.length > 0) {

                        if (response.data.rows[0].cell[2] == 'Success') {
                            $scope.validation.showMessage = false;
                            ResetAppSetupModel();
                            $scope.posting = false;
                            setTimeout(function () {
                                $('#Add_virtual_appSetup').modal('hide');
                                $scope.ShowWarning = false;
                            }, 1500);
                        }
                        $scope.ErrorMessage = response.data.rows[0].cell[2];
                        $scope.ShowWarning = true;
                    }
                }
                $scope.posting = false;
            }, function () {
                alert('Error in updating record');
            });
        }
    }

    //$scope.singleUpdateClick = function () {
    //    var appSetupID = $scope.appsVar.selectedRecordId;
    //    $scope.AppSetupEdit = $filter('filter')($scope.AppSetupList, { Name: appSetupID });
    //    if (typeof $scope.AppSetupEdit !== 'undefined' && $scope.AppSetupEdit.length > 0) {
    //        angular.copy($scope.AppSetupEdit[0], $scope.appsetup);
    //        $("#Edit_virtual_appSetup").modal();
    //        return true;
    //    }
    //    else {
    //        $scope.showAlertMessage('Select a AppSetup to edit.');
    //        return false;
    //    }

    //}

    $scope.TypeSelectionClick = function () {
        $("#Select_Types_appSetup").modal();

        $scope.DocTypeRowIndex = 0;
        $scope.DocTypeTotalRowCount = 0;
        $scope.IsDocTypePrevButtonEnable = false;
        $scope.IsDocTypeNextButtonEnable = false;
        getDocTypes($scope.selectedLibrary, $scope.DocTypeRowIndex, 10, true);
    }

    $scope.onSelectTypeCancelClick = function () {
        $scope.txtTypeSearch = '';
        $("#Select_Types_appSetup").modal('hide');
    }

    $scope.onSelectTypeOkClick = function () {
        $scope.appsetup.Type = $scope.appsetup.TempType;
        $scope.txtTypeSearch = '';
        $("#Select_Types_appSetup").modal('hide');
    }


    $scope.PageEvents.Add = function () {
        $scope.PageEvents.UserAction = 'Add';
        $scope.validation.showMessage = false;
        ResetAppSetupModel();
        //getDocTypes($scope.selectedLibrary, 0, 100, true);
        $("#Add_virtual_appSetup").modal();
       
    };

    $scope.PageEvents.Edit = function (row) {
        $scope.PageEvents.UserAction = 'Edit';
        //getDocTypes($scope.selectedLibrary, 0, 100, true);
        $scope.AppSetupEdit = $filter('filter')($scope.AppSetupList, { selected: true });
        if (row) {
            var appSetupID = $scope.appsVar.selectedRecordId;
            $scope.AppSetupEdit = $filter('filter')($scope.AppSetupList, { Name: appSetupID });
        }
        if (typeof $scope.AppSetupEdit !== 'undefined' && $scope.AppSetupEdit.length > 0) {
            angular.copy($scope.AppSetupEdit[0], $scope.appsetup);
            $("#Add_virtual_appSetup").modal();
            return true;
        }
        else {
            $scope.showAlertMessage('Select App Setup to edit.');
            return false;
        }
    }


    $scope.PageEvents.BindLabel = function (data) {
        if ($scope.PageEvents.UserAction == 'Add') {
            return 'Add'
        } else {
            return 'Save';
        }
    }

    $scope.PageEvents.Save = function () {
        if ($scope.PageEvents.UserAction == 'Add') {
            return $scope.addAppSetup();
        } else {
            return $scope.EditAppSetup();
        }
    }

    $scope.PageEvents.CancelDialog = function () {
        ResetAppSetupModel();
        $scope.validation.showMessage = false;
        $scope.ShowWarning = false;
        $('#Add_virtual_appSetup').modal('hide');
    }

    $scope.selecttype = function (item, $event) {

        $scope.appsetup.TempType = item.TAlias;
        //this.getAllSelectedRows(item);
        if ($event.ctrlKey) {
            item.selected ? item.selected = false : item.selected = true;
        }
        else {
            this.getAllSelectedtypeRows(item);
        }
    };

    $scope.getAllSelectedtypeRows = function (item) {
        angular.forEach($scope.DocTypes, function (p) {
            p.selected = false; //set them all to false
        });
        item.selected = true; //set the clicked one to true
    };

    $scope.onTypeDbClick = function (item, $event) {
       
            $scope.appsetup.Type = item.TAlias;
            $("#Select_Types_appSetup").modal('hide');
       
    }

    $scope.DocTypeRowIndex = 0;
    $scope.DocTypeTotalRowCount = 0;
    $scope.IsDocTypePrevButtonEnable = false;
    $scope.IsDocTypeNextButtonEnable = false;
    
    $scope.DocTypePrev_Click = function () {
        $scope.DocTypeRowIndex -= 10;
        if ($scope.DocTypeRowIndex < 0) $scope.DocTypeRowIndex = 0;
        
        getDocTypes($scope.selectedLibrary, $scope.DocTypeRowIndex, 10, true);
    }

    $scope.DocTypeNext_Click = function () {
        $scope.DocTypeRowIndex += 10;
        getDocTypes($scope.selectedLibrary, $scope.DocTypeRowIndex, 10, true);
    }

    $scope.DocTypeSearch_Click = function () {
        $scope.DocTypeRowIndex = 0;
        getDocTypes($scope.selectedLibrary, $scope.DocTypeRowIndex, 10, true);
    }


    function getDocTypes(selectedLibrary, offset_val, limit_val, total_val) {
        if (!selectedLibrary || selectedLibrary.trim().length == 0) return;
        var searchText = '';

        searchText = $('#txtAppSetupDocTypeSearch').val().trim();
        var promise = AppSetupService.getDocTypes(selectedLibrary, offset_val, limit_val, total_val, searchText);
        promise.then(function (response) {
            $scope.DocTypeLoading = true;

            if (response.data.rows.length > 0) {
                if (response.data.rows[0].cell.length > 0) {
                    $scope.DocTypes = response.data.rows[0].cell[0];
                    $scope.DocTypeTotalRowCount = response.data.rows[0].cell[1];

                    $scope.IsDocTypeNextButtonEnable = $scope.DocTypeRowIndex + 10 < $scope.DocTypeTotalRowCount;
                    $scope.IsDocTypePrevButtonEnable = $scope.DocTypeRowIndex > 0;
                }
            }
            $scope.DocTypeLoading = false;
        }, function () {
            $scope.DocTypeLoading = false;
            alert('Data fetching failed.');
        });
    }

    $scope.$on('$destroy', function () {
        $scope.PageEvents.Add = 'undefined';
        $scope.PageEvents.Edit = 'undefined';
        $scope.PageEvents.Save = 'undefined';
        $scope.PageEvents.Delete = 'undefined';
        $scope.PageEvents.CancelDialog = 'undefined';
        $scope.PageEvents.ShowSubclassList = 'undefined';
        $scope.PageEvents.AddRole = 'undefined';
        $scope.PageEvents.ResetPasswordclicked = 'undefined';
        $scope.PageEvents.ViewAssignUser = 'undefined';
        $scope.PageEvents.AssignUser = 'undefined';
        $scope.PageEvents.AssignGroup = 'undefined';
    });

};