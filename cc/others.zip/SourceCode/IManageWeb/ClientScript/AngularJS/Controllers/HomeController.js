﻿app.controller("HomeController", homeController);
homeController.$inject = ['$scope', '$log', '$state', '$location', '$rootScope', 'ManagementService', '$timeout', 'HomeService', 'homeFactory', '$http', '$filter'];

function homeController($scope, $log, $state, $location, $rootScope, ManagementService, $timeout, HomeService, homeFactory, $http, $filter) {
    var vm = this;
    vm.applicationBaseURL = appBaseURL;

    //functions for menu-link and menu-toggle
    vm.isSideNavOpen = true;
    vm.isOpen = isOpen;
    vm.toggleOpen = toggleOpen;
    vm.setActiveSection = setActiveSection;
    vm.isCurrentSection = isCurrentSection;
    vm.headerNavigationMenu = {};
    vm.UserName = UserName;
    vm.selectedApp = homeFactory.selectedApp;
    vm.showmask = false;
    vm.filterhomevalue = [];
    vm.menu = {
        sections: {},
        //selectedSection: '',
        toggleSelectSection: function (section) {
            self.openedSection = (self.openedSection === section ? null : section);
        },
        isSectionSelected: function (section) {
            return self.openedSection === section;
        },
        setSelectedSection: function (section) {
            self.selectedSection = section;
            //vm.menu.selectedSection = section;
        },
        isSelectedSection: function (section) {
            return self.selectedSection === section;
            //return vm.menu.selectedSection.AppsID == section.AppsID;
        }, onTabLinkSelected: function (appsName) {
            $log.debug('Tab selected');
            $timeout(function () {
                //$rootScope.$broadcast('InitializeTabContents');
                vm.selectedApp.CurrentTab = appsName;
            });
        }, toggleSidebar: function () {
            $timeout(function () {
                if ($('md-sidenav').hasClass('md-closed')) {
                    $('md-sidenav').removeClass('md-closed');
                    vm.showmask = true;
                }
                else $('md-sidenav').addClass('md-closed');
            });
        },
        watchSection: (function () {
            //$scope.$watch(function () { return vm.menu.selectedSection }, function () {
            $scope.$watch(function () { return self.selectedSection }, function () {
                //vm.isSideNavOpen = true;
                if (self.selectedSection != undefined && vm.headerNavigationMenu) {
                    $state.go('home.' + vm.headerNavigationMenu[0].AppsTarget);
                    vm.selectedApp.CurrentTab = vm.headerNavigationMenu[0].AppsName;
                }
            });
        })()
    };

    $scope.$watch(function () { return vm.showmask }, function () {
        if (!vm.showmask) {
            $('md-sidenav').addClass('md-closed');
        }
    });

    vm.closeSideNav = function () {
        vm.isSideNavOpen = false;
    }

    var setMenuSections = function () {
        var userPermission = ManagementService.getUserPermission(vm.selectedLibrary);
        userPermission.then(function (response) {
            vm.selectedApp.NoAppsPermission = '';
            vm.menu.sections = response.data;
            if (vm.selectedApp.CurrentTab) {
            } else if (vm.menu.sections[1] && vm.menu.sections[1].childMenus) {
                //toggleOpen(vm.menu.sections[0]);
                vm.headerNavigationMenu = vm.menu.sections[1].childMenus;
                $timeout(function () {
                    $scope.$apply(function () {
                        vm.setActiveSection(vm.menu.sections[1]);
                        vm.selectedApp.CurrentTab = vm.menu.sections[1].childMenus[0].AppsName;
                    })
                })

            }
        });
    };

    function isOpen(section) {
        return vm.menu.isSectionSelected(section);
    }

    function toggleOpen(section) {
        vm.menu.toggleSelectSection(section);
    }

    $scope.PageEvents = [];
    function setActiveSection(section) {
        vm.menu.setSelectedSection(section);
        vm.showmask = false;
    }

    function isCurrentSection(section) {
        return vm.menu.isSelectedSection(section);
    }
    var isClearSearch = false;
    vm.search = {
        Show: false,
        onSearch: function () {
            if (searchTimeout) $timeout.cancel(searchTimeout);
            $scope.$broadcast('Search_Click');
            //vm.search.Show = !vm.search.Show;
        },
        clear: function () {
            if (searchTimeout) $timeout.cancel(searchTimeout);
            $scope.appsVar.SearchText = '';
            $scope.$broadcast('Search_Click');
            isClearSearch = true;
        }
    }

    $scope.$state = $state;
    $scope.appsVar = homeFactory.applicationVariables;
    $scope.ScrollCounter = false;
    $scope.animationUrl = appBaseURL + 'Images/loading.gif';
    var searchTimeout;
    $scope.$watch(function () { return $scope.appsVar.SearchText }, function (newVal, oldVal) {
        if (isClearSearch) {
            isClearSearch = false;
        } else {
            if (oldVal != newVal) {
                if (searchTimeout) $timeout.cancel(searchTimeout);

                searchTimeout = $timeout(function () {
                    $scope.$broadcast('Search_Click');
                }, 2000);
            }
        }
    }, true);

    $scope.searchAfterDelay = function () {
        if (scope.appsVar.SearchText.$dirty) {
            scope.$broadcast('Search_Click');
        }
    };

    (function getDBLibraries() {
        vm.selectedApp.NoAppsPermission = '';
		var promise = HomeService.getDBLibraries();
		promise.then(function (response) {
			if (response.data.length > 0) {
			    vm.DBLibraries = response.data;
			    $scope.selectedLibrary = vm.DBLibraries[0].DatabaseName;
			    vm.selectedLibrary = vm.DBLibraries[0].DatabaseName;
				setMenuSections();
	 		} else {
			    vm.selectedApp.CurrentTab = '';
			    vm.selectedApp.NoAppsPermission = "You don't have permission to view any apps. Please contact administrator!!!";
			    alert(vm.selectedApp.NoAppsPermission);
			}

		});
	})();

    $scope.$watch(function () { return vm.selectedLibrary }, function (newVal, oldVal) {
        $log.debug(oldVal + ' db changed to ' + newVal);
        if (newVal) {
            $log.info(oldVal + ' db changed to ' + newVal);
            setMenuSections();
            getCaptins();
            $rootScope.$broadcast('InitializeTabContents');
        }
    });

    vm.Logout = function () {
        window.location.href = appBaseURL + "Home/LogOut";
    }
    
	$scope.AddRemoveuserGroup_Click = function () {
	    $scope.$broadcast('UserGroupAddRemoveMenu_Click');
	}
	$(document).click(function (event) {
	    $('.context-menu-container').remove();
	});

	function getCaptins() {
	    var promise = ManagementService.getCaptions(vm.selectedLibrary);
	    promise.then(function (response) {
	        $scope.appsVar.CaptionsList = [];
	        if (response.data.rows != undefined) {
	            if (response.data.rows.length > 0) {
	                if (response.data.rows[0].cell.length > 0) {

	                    $scope.appsVar.CaptionsList = response.data.rows[0].cell[0];
	                    $scope.metaDataList = $filter('filter')($scope.appsVar.CaptionsList, { isMetaItem: true, ParentMetaItem: "" });
	                    var selectedMetaDataItem = $filter('filter')($scope.metaDataList, { MetaDataItem: $scope.appsVar.selectedMetaData });
	                    vm.selectedApp.CurrentSubTab = selectedMetaDataItem[0].DisplayText;
	                }
	            }
	        }
	    });
	}

	$scope.ClearClick = function () {
	    $scope.appsVar.SearchText = '';
	}

	$scope.showMetadataMenuList = function ($mdOpenMenu, event) {
	    $state.go('home.metadata');
	    $mdOpenMenu(event);
	}

	$scope.Metachange = function (tabName) {
	    $scope.appsVar.selectedMetaData = tabName;
	    $rootScope.$broadcast('InitializeTabContents');
	}

	$scope.filterIconClicked = function (filter) {
	    $scope.appsVar.filterAllValue = $.grep($scope.appsVar.filterAllValue, function (item, index) {
	        return item.FilterKey != filter.FilterKey;
	    });
	}

	$scope.ClearAllFilterClicked = function () {
	    $scope.appsVar.filterAllValue = [];
	    $rootScope.$broadcast('onClearAllClicked');
	};

    (function ($) {
        $(document).ready(function () {
            $('#app-navigation-menu > div').niceScroll({ horizrailenabled: false});
        });
    })(jQuery);
}