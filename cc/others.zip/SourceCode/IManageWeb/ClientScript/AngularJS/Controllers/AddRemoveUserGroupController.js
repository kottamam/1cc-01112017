﻿app.controller("AddRemoveUserGroupController", AddRemoveUserGroupController);
AddRemoveUserGroupController.$inject = ['$scope', '$rootScope', 'UserService', 'GroupService', '$filter'];

function AddRemoveUserGroupController($scope, $rootScope, UserService, GroupService, $filter) {

    $scope.NewGroupList = [];
    $scope.DeletedGroupList = [];
    $scope.IsShowErrorMessage = false;
    $scope.IsShowSuccessMessage = false;
    $scope.posting = false;
    $scope.SelectedUserID = '';
    $scope.ErrorMessage = '';
    //getGroupList();
    //getUserGroupList();

    $scope.$on('UserAddRemoveGroupButton_Click', function (e, a) {
        $scope.SelectedUserID = a;
        $('#chkSelectAllGroup').prop('checked', false);

        $scope.ErrorMessage = '';
        $scope.NewGroupList = [];
        $scope.DeletedGroupList = [];
        $scope.IsShowErrorMessage = false;
        $scope.IsShowSuccessMessage = false;
        $scope.posting = false;
        $scope.GroupDetailList = [];
        getGroupList();
        getUserGroupList();
        $("#Add_Remove_UserGroups").modal();
    });

    function getGroupList() {
        if (!$scope.selectedLibrary || $scope.selectedLibrary.trim().length == 0) return;

        var groupList = GroupService.getAllGroupList($scope.selectedLibrary);
        groupList.then(function (response) {
            if (response.data.rows.length > 0) {
                if (response.data.rows[0].cell.length > 0) {
                    $scope.GroupDetailList = response.data.rows[0].cell[0];
                }
            }
        }, function () {
            $scope.showAlertMessage('Failed to fetch groups.');
        });
    }

    function getUserGroupList() {
        if (!$scope.selectedLibrary || $scope.selectedLibrary.trim().length == 0) return;

        var userGroupList = GroupService.getUserGroupList($scope.selectedLibrary, $scope.SelectedUserID);
        userGroupList.then(function (response) {
            if (response.data != "" && response.data.rows.length > 0) {
                if (response.data.rows[0].cell.length > 0) {
                    $scope.UserGroupList = response.data.rows[0].cell[0];
                }
            }
        }, function () {
            $scope.showAlertMessage('Failed to fetch groups.');
        });

        //$scope.UserGroupList = [{ GroupName: 'ALL USERS' }, { GroupName: 'DNSADMINS' }, { GroupName: 'DOMAIN ADMINS' }, { GroupName: 'G10' }, { GroupName: 'IIS_WPG' }];

        //angular.forEach($scope.GroupDetailList, function (groupModel) {
        //    groupModel.IsSelected = false;

        //    var filterGroupList = $filter('filter')($scope.UserGroupList, { GroupName: groupModel.GroupName }, true);
        //    if (typeof filterGroupList != 'undefined' && filterGroupList.length > 0) {
        //        groupModel.IsSelected = true;
        //    }

        //});
    }

    $scope.isAlreadySelected = function (groupName) {
        var resultText = '';
        var filterGroupList = $filter('filter')($scope.UserGroupList, { GroupName: groupName }, true);
        if (typeof filterGroupList != 'undefined' && filterGroupList.length > 0) {
            resultText = 'checked';
        }
        return resultText;
    };


    $scope.onGroup_Click = function (ctrlName, groupName) {
        var isItemChecked = false;
        var itemAlreadySelected = false;

        var filterGroupList = $filter('filter')($scope.UserGroupList, { GroupName: groupName }, true);
        itemAlreadySelected = (typeof filterGroupList != 'undefined' && filterGroupList.length > 0);
        filterGroupList = null;

        isItemChecked = $('#' + ctrlName).is(':checked');
        if (isItemChecked) {
            if (!itemAlreadySelected) {
                $scope.NewGroupList.push({ GroupName: groupName });
            }
            else {
                filterGroupList = $filter('filter')($scope.DeletedGroupList, { GroupName: groupName }, true);
                if (typeof filterGroupList != 'undefined' && filterGroupList.length > 0)
                    $scope.DeletedGroupList.splice($scope.DeletedGroupList.indexOf(filterGroupList[0]), 1);
                filterGroupList = null;
            }
            //$('#chkSelectAllGroup').prop('checked', true);
            //angular.forEach($scope.GroupDetailList, function (groupModel) {
            //    if ($('#gn01' + groupModel.GroupName.replace(' ', '_')).is(':checked') == false) {
            //        $('#chkSelectAllGroup').prop('checked', false);
            //        return;
            //    }
            //});
        }
        else {
            $('#chkSelectAllGroup').prop('checked', false);
            if (itemAlreadySelected) {
                $scope.DeletedGroupList.push({ GroupName: groupName });
            }
            else {
                filterGroupList = $filter('filter')($scope.NewGroupList, { GroupName: groupName }, true);
                if (typeof filterGroupList != 'undefined' && filterGroupList.length > 0)
                    $scope.NewGroupList.splice($scope.NewGroupList.indexOf(filterGroupList[0]), 1);
                filterGroupList = null;
            }
        }
        //var checkedItemCount = 0;

        //if ($scope.GroupDetailList.length == checkedItemCount) {
        //    $('#chkSelectAllGroup').prop('checked', true);
        //}
        //else {
        //    $('#chkSelectAllGroup').prop('checked', false);
        //}
    };

    $scope.selectAllGroup = function () {
        if ($('#chkSelectAllGroup').is(':checked')) {
            $scope.NewGroupList = [];
            angular.forEach($scope.GroupDetailList, function (groupModel) {
                $('#gn01' + groupModel.GroupName.replace(' ', '_')).prop('checked', true);

                var filterGroupList = $filter('filter')($scope.UserGroupList, { GroupName: groupModel.GroupName }, true);
                var itemAlreadySelected = (typeof filterGroupList != 'undefined' && filterGroupList.length > 0);

                if (!itemAlreadySelected) {
                    $scope.NewGroupList.push({ GroupName: groupModel.GroupName });
                }

            });
            $scope.DeletedGroupList = [];
        }
        else {
            $scope.DeletedGroupList = [];
            angular.forEach($scope.GroupDetailList, function (groupModel) {
                $('#gn01' + groupModel.GroupName.replace(' ', '_')).prop('checked', false);

                var filterGroupList = $filter('filter')($scope.UserGroupList, { GroupName: groupModel.GroupName }, true);
                var itemAlreadySelected = (typeof filterGroupList != 'undefined' && filterGroupList.length > 0);

                if (itemAlreadySelected) {
                    $scope.DeletedGroupList.push({ GroupName: groupModel.GroupName });
                }

            });
            $scope.NewGroupList = [];
        }
    }

    $scope.unSelectAllGroup = function () {
        $scope.DeletedGroupList = [];
        angular.forEach($scope.GroupDetailList, function (groupModel) {
            $('#gn01' + groupModel.GroupName.replace(' ', '_')).prop('checked', false);

            var filterGroupList = $filter('filter')($scope.UserGroupList, { GroupName: groupModel.GroupName }, true);
            var itemAlreadySelected = (typeof filterGroupList != 'undefined' && filterGroupList.length > 0);

            if (itemAlreadySelected) {
                $scope.DeletedGroupList.push({ GroupName: groupModel.GroupName });
            }

        });
        $scope.NewGroupList = [];
    }

    $scope.save = function () {
        $scope.posting = true;
        $scope.IsShowErrorMessage = false;

        //if (($scope.NewGroupList == null || $scope.NewGroupList.length == 0) && ($scope.DeletedGroupList == null || $scope.DeletedGroupList.length == 0)) {
        //    $scope.IsShowErrorMessage = true;
        //    return;
        //}
        //if ($scope.DeletedGroupList == null || $scope.DeletedGroupList.length == 0) {
        //    $scope.IsShowErrorMessage = true;
        //    return;
        //}

        var saveGroupList = GroupService.AddRemoveUserGroup($scope.selectedLibrary, $scope.SelectedUserID, $scope.NewGroupList, $scope.DeletedGroupList);
        saveGroupList.then(function (response) {
            $scope.posting = false;
            if (response.data.rows.length > 0) {
                if (response.data.rows[0].cell.length > 0) {
                    if (response.data.rows[0].cell[0] == 'Success') {
                        $scope.IsShowSuccessMessage = true;
                        setTimeout(function () { $("#Add_Remove_UserGroups").modal('hide'); }, 1500);
                    }
                    else {
                        $scope.IsShowErrorMessage = true;
                    }
                }
            }
        }, function () {
            $scope.posting = false;
            $scope.showAlertMessage('Failed to fetch groups.');
        });
        
    }

    $scope.closePopup = function () {
        $scope.NewGroupList = [];
        $scope.DeletedGroupList = [];
        $scope.IsShowErrorMessage = false;
        $scope.IsShowSuccessMessage = false;
        $scope.posting = false;
        $scope.SelectedUserID = '';
        $("#Add_Remove_UserGroups").modal('hide');
    }
}