﻿app.controller("NavigationController", NavigationController);
NavigationController.$inject = ['$scope', 'homeFactory'];

function NavigationController($scope, homeFactory) {

    $scope.UserAreas = homeFactory.userArea;
    $scope.vm.selectedApp.appType = 'Management';

    $scope.updateAppType = function (type) {
        $scope.vm.selectedApp.appType = type;
    }

    $scope.resizeDatatable = function () {
        $('#idDataTable').dataTable().resize();
        $('#idDataTableTypeappSetup').dataTable().resize();
        $('#idDataTableType').dataTable().resize();
    }
};