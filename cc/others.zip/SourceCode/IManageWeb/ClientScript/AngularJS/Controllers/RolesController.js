﻿app.controller("RolesController", RolesController);
RolesController.$inject = ['$scope', '$rootScope', 'RolesService', '$filter', '$timeout', '$mdDialog', '$mdMedia',   'rolesFactory',   'homeFactory', 'UserService'];

function RolesController($scope, $rootScope, RolesService, $filter, $timeout, $mdDialog, $mdMedia,   rolesFactory,   homeFactory, UserService) {

    var roleListRequestModel = homeFactory.requestModelInstance();

    $scope.FormTitle = 'Role';
    $scope.loading = false;
    $scope.lastSelectedLibrary = '';
    $scope.RoleModelList = [];
    $scope.UserCheckedFinal = [];
    $scope.selected = [];

    //$scope.tableParamsRole = new ngTableParams({
    //    noPager: true
    //}, {
    //    getData: function ($defer, params) {
    //        $defer.resolve($scope.RoleModelList);
    //    }
    //});

    $scope.ContextMenuFunctions = {
        Edit: function () { $scope.PageEvents.Edit(); },
        Delete: function () { deleteRole(); },
        CopyRole: function () {
            var selectedRoleList = $scope.selected;//= $filter('filter')($scope.RoleModelList, { Selected: true });
            if (selectedRoleList && selectedRoleList.length > 0) {
                $scope.CopyRoleObject.showDialog(selectedRoleList[0].RoleName);
            }
        },
        AssignUsers: function () { $scope.PageEvents.AddRole(); },
        ViewRights: function () {
            $scope.ViewRoleRightObject.showDialog();
        }
    }
    function setContextMenuObject() {
        $scope.menuList = [
            {
                Label: 'Edit',
                Icon: 'img/icons/edit.svg',
                onClick: $scope.ContextMenuFunctions.Edit,
                Enable: $scope.selected.length == 1
            },
            {
                Label: 'Delete',
                Icon: 'img/icons/delete.svg',
                onClick: $scope.ContextMenuFunctions.Delete,
                Enable: $scope.selected.length > 0
            },
            {
                Label: 'Copy',
                Icon: 'icons/view_copy.svg',
                onClick: $scope.ContextMenuFunctions.CopyRole,
                Enable: $scope.selected.length == 1
            },
            {
                Label: 'Seperator'
            },
             {
                 Label: 'Add/Remove Members',
                 Icon: 'img/icons/group_blue.svg',
                 onClick: $scope.ContextMenuFunctions.AssignUsers,
                 Enable: $scope.selected.length == 1
             },
              {
                  Label: 'View Rights',
                  Icon: 'icons/view_copy.svg',
                  onClick: $scope.ContextMenuFunctions.ViewRights,
                  Enable: $scope.selected.length == 1
              }
        ];
    }
    $scope.$on('onTableFiltering', function (event, value, key) {
        var filterValueList = [];

        if (roleListRequestModel.filters.length > 0) {
            roleListRequestModel.filters = jQuery.grep(roleListRequestModel.filters, function (filterItem) {
                return filterItem.FilterKey !== key;
            });
        }
        filterValueList[0] = value;

        var filterItem = { 'FilterKey': key, 'FilterValues': filterValueList };
        roleListRequestModel.filters.push(filterItem);

        initializeRoleList();
    });

    

    $scope.PreviousPageButton_Click = function () {
        roleListRequestModel.pagenumber -= 1;
        getRoleList()
    }

    $scope.NextPageButton_Click = function () {
        roleListRequestModel.pagenumber += 1;
        getRoleList()
    }

    $scope.$on('onClearAllClicked', function () {
        roleListRequestModel.filters = [];
        getRoleList();
    })

    function getRoleList() {
        $scope.selected = [];
        if ($scope.vm.selectedApp.NoAppsPermission.trim().length > 0) return;
        if (!$scope.vm.selectedLibrary || $scope.vm.selectedLibrary.trim().length == 0) return;
        $scope.lastSelectedLibrary = $scope.vm.selectedLibrary;       
        $scope.RoleModelList = [];     

        var roleDbRequest = RolesService.getRoles(roleListRequestModel);
        roleDbRequest.then(function (response) {
            if (response.data && response.data.rows && response.data.rows.length > 0 && response.data.rows[0].cell && response.data.rows[0].cell.length > 0) {
                $scope.query.totalCount = response.data.total;
                $scope.RoleModelList = response.data.rows[0].cell[0];
                //$scope.loading = false;
                $timeout(function () {
                    $('td').filter(function () {
                        if (!$(this).hasClass("md-checkbox-cell")) {
                            if ($(this).text().trim().length == 0) {

                                $(this).html('&nbsp;');
                            }
                        }

                    });
                });
            }
        }, function () {
            alert('Data fetching failed.');
        });
    }

    $scope.SelectCurrentRow = function (roleModel, $event) {
        if ($event.ctrlKey) {
            roleModel.Selected ? roleModel.Selected = false : roleModel.Selected = true;
        }
        else {
            this.getAllSelectedRows(roleModel);
        }
        //var selectedUserList = $filter('filter')($scope.RoleModelList, { Selected: true });
        //if (selectedUserList.length == 0) {
        //    $('#card-more-button').attr('disabled', 'disabled')
        //} else {
        //    $('#card-more-button').removeAttr('disabled')
        //}
    };

    $scope.getAllSelectedRows = function (roleModel) {
        var selectedRoleList = $scope.selected;//= $filter('filter')($scope.RoleModelList, { Selected: true });
        angular.forEach(selectedRoleList, function (tempItemModel) {
            tempItemModel.Selected = false;
        });
        roleModel.Selected = true;
    };

    $scope.$on('Search_Click', function (event, args) {
        initializeRoleList();
    });

    $scope.$on('InitializeTabContents', function () {
        initializeRoleList();
    })

    function initializeRoleList() {
        $scope.loading = true;
        $scope.RoleModelList = [];

        roleListRequestModel.libraryName = $scope.vm.selectedLibrary;
        roleListRequestModel.searchText = $scope.appsVar.SearchText;
        roleListRequestModel.pagenumber = 1;
        roleListRequestModel.pageLength = 10;
        roleListRequestModel.isTotal = true;

        $scope.query.limit = 10;
        $scope.query.page = 1;
        $scope.query.totalCount = 0;

        getRoleList();
    }

    //initializeRoleList();


    //Add_Edit_Role
    var RoleViewModel = null;
    $scope.RolesModel = null;

    $scope.PageEvents.BindLabel = function (data) {
        if ($scope.PageEvents.UserAction == 'Add') {
            return 'Add'
        } else {
            return 'Save';
        }
    }

    $scope.PageEvents.CancelDialog = function () {
        $mdDialog.cancel();

        $scope.PageEvents.UserAction = '';
        $scope.FormTitle = '';
        RoleViewModel = null;
        $scope.RolesModel = rolesFactory.rolesInitialValues();
        $scope.ShowMemberUserOnly = false;
        $scope.showValidation = false;
        $scope.ShowWarning = false;
        $scope.posting = false;
        //$scope.UserInRoleList = [];
        //$scope.UserList
        //$scope.captionsSetList = [];
        $scope.PrivilageDetails = [];
        //$scope.UserCheckedFInal = [];
        //$scope.SelectedUserListForAddForm = [];
        //$('#Add_Edit_Role').modal('hide');
    }

    $scope.PageEvents.Add = function () {

        RoleViewModel = null;
        $scope.RolesModel = rolesFactory.rolesInitialValues();
        $scope.showValidation = false;
        $scope.ShowWarning = false;
        $scope.posting = false;
        $scope.PageEvents.UserAction = 'Add';
        fillPrivilages();

        var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;

        var dialogObject = {
            controller: DialogController,
            scope: $scope,
            preserveScope: true,
            templateUrl: 'Views/NgTemplates/RolesForm.html',
            parent: angular.element(document.body),
            targetEvent: null,
            clickOutsideToClose: true,
            fullscreen: useFullScreen
        };
        $mdDialog.show(dialogObject)
        .then(function (answer) {
            $scope.status = '';
        }, function () {
            $scope.status = '';
        });
        $scope.$watch(function () {
            return $mdMedia('xs') || $mdMedia('sm');
        }, function (wantsFullScreen) {
            $scope.customFullscreen = (wantsFullScreen === true);
        });
    };

    $scope.PageEvents.Edit = function () {
        var roleListTemp = $scope.selected;//= $filter('filter')($scope.RoleModelList, { Selected: true });
        if (typeof roleListTemp == 'undefined' || roleListTemp.length == 0) {
            $scope.showAlertMessage('Select role to edit.');
            return;
        }

        var roleModelService = RolesService.getRole($scope.vm.selectedLibrary, roleListTemp[0].RoleName);
        roleModelService.then(function (response) {

            RoleViewModel = null;
            if (response.data && response.data != '') {
                $scope.PageEvents.UserAction = 'Edit';
                $scope.FormTitle = 'Edit';

                RoleViewModel = response.data;

                $scope.RolesModel = rolesFactory.rolesInitialValues();
                $scope.RolesModel.RoleName = RoleViewModel.RoleName;
                $scope.RolesModel.Description = RoleViewModel.Description;

                $scope.ShowMemberUserOnly = false;
                $scope.showValidation = false;
                $scope.ShowWarning = false;
                $scope.posting = false;
                fillPrivilages();

                var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;

                var dialogObject = {
                    controller: DialogController,
                    scope: $scope,
                    preserveScope: true,
                    templateUrl: 'Views/NgTemplates/RolesForm.html',
                    parent: angular.element(document.body),
                    targetEvent: null,
                    clickOutsideToClose: true,
                    fullscreen: useFullScreen
                };
                $mdDialog.show(dialogObject)
                .then(function (answer) {
                    $scope.status = '';
                }, function () {
                    $scope.status = '';
                });
                $scope.$watch(function () {
                    return $mdMedia('xs') || $mdMedia('sm');
                }, function (wantsFullScreen) {
                    $scope.customFullscreen = (wantsFullScreen === true);
                });
            }

        }, function () {
            alert('Data fetching failed.');
        });
    }

    function deleteRole() {

        var selectedRoleList = $scope.selected;//= $filter('filter')($scope.RoleModelList, { Selected: true });

        if (typeof selectedRoleList !== 'undefined' && selectedRoleList.length > 0) {
            var confirm = $mdDialog.confirm()
           .title('Delete Role')
           .textContent('Are you sure to delete selected Role?')
           .ariaLabel('Delete Role')
          // .targetEvent(event)
           .ok('Proceed')
           .cancel('Cancel');
            $mdDialog.show(confirm).then(function () {

                $mdDialog.show(
              $mdDialog.alert()
                  .parent(angular.element(document.body))
                  .clickOutsideToClose(true)
                  .title('Delete Role')
                  .textContent('You are deleting the selected Role.')
                  .ariaLabel('Delete Role')
                  .ok('OK')
              ).then(function () {
                  var promise = RolesService.DeleteRole($scope.vm.selectedLibrary, selectedRoleList[0]);
                  promise.then(function (response) {
                      if (response.data.length > 0) {
                          getRoleList();
                      }
                  }, function () {
                      //$scope.status = 'You decided to keep your debt.';
                  });
              });
            });
        }
        else {
            $mdDialog.show(
                $mdDialog.alert()
                    .parent(angular.element(document.querySelector('#popupContainer')))
                    .clickOutsideToClose(true)
                    .title('Alert')
                    .textContent('Please select Role to delete.')
                    .ariaLabel('Delete info dialog')
                    .ok('OK')
                    .targetEvent(event)
            );
        }
    }

    function fillPrivilages() {
        $scope.PrivilageDetails = [
        { value: 'CO', Text: 'Import / Create', Selected: false, TagValue: 1 },
        { value: 'CO', Text: 'Checkout Documents', Selected: false, TagValue: 2 },
        { value: 'CO', Text: 'Unlock Documents', Selected: false, TagValue: 4 },
        { value: 'CO', Text: 'Delete', Selected: false, TagValue: 8 },
        { value: 'CO', Text: 'Allow Full Text Search', Selected: false, TagValue: 2048 },
        { value: 'CO', Text: 'Read Only', Selected: false, TagValue: 16 },
        { value: 'FO', Text: 'Create Public Folder', Selected: false, TagValue: 32 },
        { value: 'FO', Text: 'Create Public Searches', Selected: false, TagValue: 64 },
        { value: 'AO', Text: 'User Work Site import', Selected: false, TagValue: 1 },
        { value: 'AO', Text: 'User Work Site Monitor', Selected: false, TagValue: 2 },
        { value: 'AO', Text: 'User Work Site Administration', Selected: false, TagValue: 4 },
        { value: 'AO', Text: 'View Documents', Selected: false, TagValue: 8 },
        { value: 'WO', Text: 'Search Via Web', Selected: false, TagValue: 2 },
        { value: 'WO', Text: 'Create WorkSpaces', Selected: false, TagValue: 4 },
        { value: 'WO', Text: 'Create Public WorkSpacea', Selected: false, TagValue: 6 },
        { value: 'WO', Text: 'Create system WorkSpaces', Selected: false, TagValue: 64 },
        { value: 'WO', Text: 'Delete WorkSpaces', Selected: false, TagValue: 128 },
        ];

        var searchListTemp;
        if ($scope.PageEvents.UserAction == 'Add') {
            angular.forEach($scope.PrivilageDetails, function (PrivilegeType) {
                PrivilegeType.Selected = !(PrivilegeType.value == 'CO' && PrivilegeType.TagValue == 16);
            });
        }
        else if ($scope.PageEvents.UserAction == 'Edit' && RoleViewModel != null) {

            if (RoleViewModel.ContentAndFolderOperationList) {
                angular.forEach(RoleViewModel.ContentAndFolderOperationList, function (tempItem) {

                    searchListTemp = $filter('filter')($scope.PrivilageDetails, { value: 'CO', TagValue: tempItem });
                    if (searchListTemp && searchListTemp.length > 0) {
                        searchListTemp[0].Selected = true;
                        searchListTemp = null;
                    }
                    else {
                        searchListTemp = $filter('filter')($scope.PrivilageDetails, { value: 'FO', TagValue: tempItem });
                        if (searchListTemp && searchListTemp.length > 0) {
                            searchListTemp[0].Selected = true;
                            searchListTemp = null;
                        }
                    }
                });
            }

            if (RoleViewModel.AdministrativeOperationList) {
                angular.forEach(RoleViewModel.AdministrativeOperationList, function (tempItem) {
                    searchListTemp = $filter('filter')($scope.PrivilageDetails, { value: 'AO', TagValue: tempItem });
                    if (searchListTemp && searchListTemp.length > 0) {
                        searchListTemp[0].Selected = true;
                        searchListTemp = null;
                    }
                });
            }
            if (RoleViewModel.WebOperationsList) {
                angular.forEach(RoleViewModel.WebOperationsList, function (tempItem) {
                    searchListTemp = $filter('filter')($scope.PrivilageDetails, { value: 'WO', TagValue: tempItem });
                    if (searchListTemp && searchListTemp.length > 0) {
                        searchListTemp[0].Selected = true;
                        searchListTemp = null;
                    }
                });
            }
        }
    }

    $scope.PageEvents.Save = function () {
        $scope.posting = false;
        $scope.ShowWarning = false;
        $scope.showValidation = false;

        if ($scope.RolesModel.RoleName == '') {
            $scope.showValidation = true;
            return;
        }

        if ($scope.PageEvents.UserAction == 'Add') {
            return addRoles();
        } else {
            return editRole();
        }
    }


    function addRoles() {

        $scope.posting = true;
        setRoleViewModelToSave();
        //$scope.RolesModel.ProfileInfo = $scope.captionsSetList;
        var roleSave = RolesService.addRoles($scope.vm.selectedLibrary, RoleViewModel, null);

        roleSave.then(function (response) {
            if (response.data && response.data == 'Success') {
                $mdDialog.cancel();
                $scope.ShowWarning = false;
                getRoleList();
                $scope.RolesModel = rolesFactory.rolesInitialValues();
                $scope.showValidation = false;
               
                //getRoleList();
                //$scope.RolesModel = rolesFactory.rolesInitialValues();
                //$scope.showValidation = false;
                //setTimeout(function () {
                //    $scope.ShowWarning = false;
                //    $mdDialog.cancel();
                //}, 1500);
            }
            $scope.ErrorMessage = response.data;
            $scope.ShowWarning = true;
            $scope.posting = false;
        }, function () {
            $scope.ErrorMessage = 'Failed to create new Role.';
            $scope.ShowWarning = true;
            $scope.posting = false;
        });
    }

    function editRole() {

        $scope.posting = true;
        setRoleViewModelToSave();
        $scope.RolesModel.ProfileInfo = $scope.captionsSetList;
        var roleSave = RolesService.editRole($scope.vm.selectedLibrary, RoleViewModel, null, null);

        roleSave.then(function (response) {
            if (response.data && response.data == 'Success') {
                $mdDialog.cancel();
                getRoleList();
                $scope.RolesModel = rolesFactory.rolesInitialValues();
                $scope.showValidation = false;
                $scope.ShowWarning = false;
              

                 

                //getRoleList();
                //$scope.RolesModel = rolesFactory.rolesInitialValues();
                //$scope.showValidation = false;
                //setTimeout(function () {
                //    $scope.ShowWarning = false;
                //    $mdDialog.cancel();
                //}, 1500);
            }
            $scope.ErrorMessage = response.data;
            $scope.ShowWarning = true;
            $scope.posting = false;
        }, function () {
            $scope.ErrorMessage = 'Failed to create new Role.';
            $scope.ShowWarning = true;
            $scope.posting = false;
        });
    }

    function setRoleViewModelToSave() {

        RoleViewModel = rolesFactory.dbRoleModelInitialValues();

        RoleViewModel.RoleName = $scope.RolesModel.RoleName;
        RoleViewModel.Description = $scope.RolesModel.Description;
        RoleViewModel.IsExternal = $scope.RolesModel.RoleIsExternal;

        var searchListTemp = $filter('filter')($scope.PrivilageDetails, { Selected: true });

        angular.forEach(searchListTemp, function (PrivilegeType) {
            if (PrivilegeType.value == 'CO' || PrivilegeType.value == 'FO') {
                RoleViewModel.ContentAndFolderOperationList.push(PrivilegeType.TagValue);
            }
            else if (PrivilegeType.value == 'AO') {
                RoleViewModel.AdministrativeOperationList.push(PrivilegeType.TagValue);
            }
            else if (PrivilegeType.value == 'WO') {
                RoleViewModel.WebOperationsList.push(PrivilegeType.TagValue);
            }
        });
        searchListTemp = null;

        //angular.forEach($scope.captionsSetList, function (captionModel) {
        //    var roleProfileModel = rolesFactory.roleProfileModelInitialValues();

        //    roleProfileModel.RoleName = $scope.RolesModel.RoleName;
        //    roleProfileModel.ProfileId = captionModel.Profile;
        //    roleProfileModel.SearchValue = captionModel.SearchValue;
        //    roleProfileModel.SetValue = captionModel.SetValue;
        //    roleProfileModel.SearchAccess = captionModel.SearchAccess;
        //    roleProfileModel.SetAccess = captionModel.SetAccess;

        //    RoleViewModel.RoleProfileModelList.push(angular.copy(roleProfileModel));
        //    roleProfileModel = null;
        //});
    }

    function DialogController($scope, $mdDialog) {
        $scope.hide = function () {
            $mdDialog.hide();
        };
        $scope.cancel = function () {
            $mdDialog.cancel();
        };
        $scope.answer = function () {
            $scope.AddSelectedUser();
            $mdDialog.hide();
        };
    }

    (function ($) {
        $(document).ready(function () {
            $('#card-more-button').attr('disabled', 'disabled');
        });
    })(jQuery);

    $scope.$on('$destroy', function () {
        $scope.PageEvents.Add = 'undefined';
        $scope.PageEvents.Edit = 'undefined';
        $scope.PageEvents.Save = 'undefined';
        $scope.PageEvents.Delete = 'undefined';
        $scope.PageEvents.CancelDialog = 'undefined';
        $scope.PageEvents.ShowSubclassList = 'undefined';
        $scope.PageEvents.AddRole = 'undefined';
        $scope.PageEvents.ResetPasswordclicked = 'undefined';
    });

    $scope.CopyRoleObject = {
        FromRoleName: '',
        ToRoleName: '',
        IsShowErrorMsg: false,
        IsPosting: false,
        IsShowSuccessMsg: false,
        ErrorMessage: '',

        showDialog: function (fromRoleName) {

            $scope.CopyRoleObject.FromRoleName = fromRoleName;
            $scope.CopyRoleObject.ToRoleName = '';

            var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;

            var dialogObject = {
                controller: DialogController,
                scope: $scope,
                preserveScope: true,
                templateUrl: 'Views/NgTemplates/CopyRole.html',
                parent: angular.element(document.body),
                targetEvent: null,
                clickOutsideToClose: true,
                fullscreen: useFullScreen
            };
            $mdDialog.show(dialogObject)
            .then(function (answer) {
                $scope.status = '';
            }, function () {
                $scope.status = '';
            });
            $scope.$watch(function () {
                return $mdMedia('xs') || $mdMedia('sm');
            }, function (wantsFullScreen) {
                $scope.customFullscreen = (wantsFullScreen === true);
            });
        },

        closeDialog: function () {
            $mdDialog.cancel();
            $scope.CopyRoleObject.FromRoleName = '';
            $scope.CopyRoleObject.IsShowErrorMsg = false;
            $scope.CopyRoleObject.IsPosting = false;
            $scope.CopyRoleObject.IsShowSuccessMsg = false;
            $scope.CopyRoleObject.ErrorMessage = '';
            $scope.CopyRoleObject.ToRoleName = '';
        },

        copy: function () {
            $scope.CopyRoleObject.ErrorMessage = '';
            $scope.CopyRoleObject.IsShowErrorMsg = false;

            if ($scope.CopyRoleObject.ToRoleName.trim().length == 0) {
                return;
            }

            $scope.CopyRoleObject.IsPosting = true;
            var copyRolePromise = RolesService.copyRole($scope.vm.selectedLibrary, $scope.CopyRoleObject.FromRoleName, $scope.CopyRoleObject.ToRoleName);
            copyRolePromise.then(function (response) {
                if (response && response.data && response.data.Status) {

                    //if (response.data.Message && response.data.Message.trim().length > 0) {
                    //    $scope.CopyRoleObject.IsShowSuccessMsg = true;
                    //    $scope.CopyRoleObject.ErrorMessage = response.data.Message;
                    //}
                    //else {
                    //    $scope.CopyRoleObject.ErrorMessage = 'Role copied succesfully.';
                    //}
                    getRoleList();
                    $scope.CopyRoleObject.closeDialog();
                }
                else {
                    $scope.CopyRoleObject.ErrorMessage = response.data.Message && response.data.Message.trim().length > 0 ? response.data.Message : '';
                    $scope.CopyRoleObject.IsShowErrorMsg = response.data.Message && response.data.Message.trim().length > 0;
                }
                $scope.CopyRoleObject.IsPosting = false;

            }, function () {
                $scope.CopyRoleObject.IsPosting = false;
            });
        }
    };

    $scope.ViewRoleRightObject = {
        RoleViewModel: null,

        showDialog: function () {
            $scope.ViewRoleRightObject.RoleViewModel = null;
            var roleListTemp = $scope.selected;//= $filter('filter')($scope.RoleModelList, { Selected: true });
            if (typeof roleListTemp == 'undefined' || roleListTemp.length == 0) {
                $scope.showAlertMessage('Select role to view rights.');
                return;
            }

            var roleModelService = RolesService.getRole($scope.vm.selectedLibrary, roleListTemp[0].RoleName);
            roleModelService.then(function (response) {

                if (response.data && response.data != '') {
                    $scope.PageEvents.UserAction = 'Edit';
                    $scope.FormTitle = 'Edit';

                    RoleViewModel = response.data;

                    $scope.RolesModel = rolesFactory.rolesInitialValues();
                    $scope.RolesModel.RoleName = RoleViewModel.RoleName;
                    $scope.RolesModel.Description = RoleViewModel.Description;

                    fillPrivilages();

                    $scope.ViewRoleRightObject.RoleViewModel = response.data;

                    var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;

                    var dialogObject = {
                        controller: DialogController,
                        scope: $scope,
                        preserveScope: true,
                        templateUrl: 'Views/NgTemplates/ViewRoleRight.html',
                        parent: angular.element(document.body),
                        targetEvent: null,
                        clickOutsideToClose: true,
                        fullscreen: useFullScreen
                    };
                    $mdDialog.show(dialogObject)
                    .then(function (answer) {
                        $scope.status = '';
                    }, function () {
                        $scope.status = '';
                    });
                    $scope.$watch(function () {
                        return $mdMedia('xs') || $mdMedia('sm');
                    }, function (wantsFullScreen) {
                        $scope.customFullscreen = (wantsFullScreen === true);
                    });
                }

            }, function () {

            });
        },

        closeDialog: function () {
            $mdDialog.cancel();
            $scope.ViewRoleRightObject.RoleViewModel = null;
            $scope.PageEvents.UserAction = '';
            $scope.FormTitle = '';
            RoleViewModel = null;
            $scope.RolesModel = rolesFactory.rolesInitialValues();
            $scope.PrivilageDetails = [];
        },
    };


    $scope.UserInRoleList = [];
    $scope.UserList = [];
    $scope.UserSearchText = '';
    $scope.isuPrevDisable = false;
    $scope.isuNextDisable = false;
    
    var uoffset = 0;
    var userrolelimit = 10;
    var UsersInRoleCount = 0;
    var deletedMemberList = [];
    var urequestModel = homeFactory.requestModelInstance();

    $scope.PageEvents.AddRole = function (row) {
        $scope.UserCheckedFinal = [];
       
        deletedMemberList = [];
        uoffset = 0;
        userrolelimit = 10;
        $scope.TablePagination = {
            order: 'name',
            limit: userrolelimit,
            page: 1,
            totalCount: 0
        };
        $scope.RolesModel = rolesFactory.rolesInitialValues();
        $scope.ValidateRoles = $scope.selected;//= $filter('filter')($scope.RoleModelList, { Selected: true });

        if (typeof $scope.ValidateRoles != 'undefined' && $scope.ValidateRoles.length > 0) {
            urequestModel = homeFactory.requestModelInstance();
            angular.copy($scope.ValidateRoles[0], $scope.RolesModel);
            getAllUserList();

            var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
            $mdDialog.show({
                controller: DialogController,
                scope: $scope,
                preserveScope: true,
                templateUrl: 'Views/NgTemplates/AddRemoveRole.html',
                parent: angular.element(document.body),
                clickOutsideToClose: true,
                fullscreen: useFullScreen
            })
            .then(function (answer) {
                $scope.status = '';
            }, function () {
                $scope.status = '';
            });
            $scope.$watch(function () {
                return $mdMedia('xs') || $mdMedia('sm');
            }, function (wantsFullScreen) {
                $scope.customFullscreen = (wantsFullScreen === true);
            });
            return true;
        }
        else {
            $scope.showAlertMessage('Select Role to add / remove user(s).');
            return false;
        }
    };


    function getAllUserList() {

        if ($scope.vm.selectedApp.NoAppsPermission.trim().length > 0) return;
        if (!$scope.vm.selectedLibrary || $scope.vm.selectedLibrary.trim().length == 0) return;
        if (!$scope.RolesModel) return;
       

        urequestModel.libraryName = $scope.vm.selectedLibrary;
        urequestModel.pagenumber = uoffset;
        urequestModel.pageLength = userrolelimit;
        urequestModel.isTotal = true;
        urequestModel.searchText = $scope.UserSearchText;

        $scope.UserInRoleList = [];
        $scope.UserList = [];
        var promise1 = UserService.getAllUsersInRole(urequestModel, $scope.RolesModel.RoleName)
        promise1.then(function (response) {
            if (response.data.rows != undefined) {
                if (response.data.rows.length > 0 && response.data.rows[0].cell.length > 0) {
                    UsersInRoleCount = response.data.total;
                    $scope.isuPrevDisable = uoffset <= 0;
                    $scope.isuNextDisable = uoffset + userrolelimit >= response.data.total;
                    $scope.UserInRoleList = response.data.rows[0].cell[0];
                    angular.forEach($scope.UserInRoleList, function (userCheckedModel) {

                        userCheckedModel.Checked = true;

                    });
                }
            }

            angular.forEach($scope.UserInRoleList, function (userCheckedModel) {

                $scope.UserList.push(userCheckedModel);

            });
            if ($scope.UserList.length < userrolelimit) {
                if (uoffset <= UsersInRoleCount) { urequestModel.pagenumber = 0 } else
                {
                    urequestModel.pagenumber = uoffset - UsersInRoleCount;
                }

                urequestModel.pageLength = userrolelimit - $scope.UserList.length;
                urequestModel.isTotal = true;
                urequestModel.searchText = $scope.UserSearchText;

                var promise = UserService.getRoleLessUsers(urequestModel)
                promise.then(function (response) {

                    if (response.data.rows.length > 0 && response.data.rows[0].cell.length > 0) {
                        //$scope.isuPrevDisable = uoffset <= 0;
                        //$scope.isuNextDisable = uoffset + userrolelimit >= response.data.total + UsersInRoleCount;

                        $scope.TablePagination.totalCount = response.data.total + UsersInRoleCount;
                        angular.forEach(response.data.rows[0].cell[0], function (userCkedModel) {
                            $scope.UserList.push(userCkedModel);
                        });
                    }

                    if ($scope.UserCheckedFinal != null && $scope.UserCheckedFinal.length > 0) {
                        angular.forEach($scope.UserCheckedFinal, function (userCheckedModel) {
                            var filterUserList = $filter('filter')($scope.UserList, { UserId: userCheckedModel.UserId }, true);
                            if (typeof filterUserList != 'undefined' && filterUserList.length > 0) {
                                filterUserList[0].Checked = true;
                            }
                        });
                    }

                    if ($scope.UserInRoleList != null && $scope.UserInRoleList.length > 0) {
                        angular.forEach($scope.UserInRoleList, function (userCheckedModel) {
                            var filterUserList = $filter('filter')($scope.UserList, { UserId: userCheckedModel.UserId }, true);
                            if (typeof filterUserList != 'undefined' && filterUserList.length > 0) {
                                filterUserList[0].Checked = true;
                            }
                        });
                    }

                    if (deletedMemberList != null && deletedMemberList.length > 0) {
                        angular.forEach(deletedMemberList, function (userCheckedModel) {
                            var filterUserList = $filter('filter')($scope.UserList, { UserId: userCheckedModel.UserId }, true);
                            if (typeof filterUserList != 'undefined' && filterUserList.length > 0) {
                                filterUserList[0].Checked = false;
                            }
                        });
                    }

                    if ($scope.CheckedUserSelection) {//IsExternalUser UserTablePagination
                        var UserCheckedList = [];
                        if (urequestModel.pagenumber == 0) {
                            var start = 0;
                            var end = 10;
                            $scope.TablePagination.page = 1;
                            $scope.TablePagination.limit = 10;
                        }
                        else {
                            var start = ($scope.TablePagination.page - 1) * $scope.TablePagination.limit;
                            var end = ($scope.TablePagination.limit * $scope.TablePagination.page);
                            start = start+1;
                        }
                        
                        for (i = start; i < end ; i++) {
                            if ($scope.UserCheckedFinal[i] != undefined)
                                UserCheckedList.push($scope.UserCheckedFinal[i]);
                        }
                        $scope.UserList = UserCheckedList;
                        $scope.TablePagination.totalCount = $scope.UserCheckedFinal.length;
                    }

                }, function () {
                    alert('Data fetching failed.');
                });
            }



        }, function () {
            alert('Data fetching failed.');
        });
    }


    $scope.AddSelectedUser = function () {

        var promise = UserService.AddUsersToRole($scope.vm.selectedLibrary, $scope.RolesModel.RoleName, $scope.UserCheckedFinal, deletedMemberList);
        promise.then(function (response) {
            if (response.data.rows.length > 0) {
                if (response.data.rows[0].cell.length > 0) {

                    if (response.data.rows[0].cell[0] == 'Success') {


                        $scope.showValidation = false;
                        setTimeout(function () {
                            $mdDialog.hide();
                            $scope.ShowWarning = false;
                        }, 1500);
                    }
                    $scope.ShowWarning = true;
                    $scope.ErrorMessage = response.data.rows[0].cell[0];

                }

            }
            $scope.posting = false;

        }, function () {
        });
        //  }
    }


    function getAllUsersInRole() {
        var userrolelimit = 10;

        if (!$scope.vm.selectedLibrary || $scope.vm.selectedLibrary.trim().length == 0) return;
        $scope.lastSelectedLibrary = $scope.vm.selectedLibrary;
        $scope.UserInRoleList = [];

        urequestModel.libraryName = $scope.vm.selectedLibrary;
        urequestModel.pagenumber = uoffset;
        urequestModel.pageLength = userrolelimit;
        urequestModel.isTotal = true;
        urequestModel.searchText = $scope.UserSearchText;

        var promise = UserService.getAllUsersInRole(urequestModel, $scope.RolesModel.RoleName)
        promise.then(function (response) {
            if (response.data.rows.length > 0 && response.data.rows[0].cell.length > 0) {
                $scope.UserInRoleList = response.data.rows[0].cell[0];
            }

        }, function () {
            alert('Data fetching failed.');
        });

    }

    $scope.isAlreadyAvilable = function (userId) {
        var resultText = false;
        var filterUserList = $filter('filter')($scope.UserInRoleList, { UserId: userId }, true);
        if (typeof filterUserList != 'undefined' && filterUserList.length > 0) {
            resultText = true;
            var selectedUserList = $filter('filter')($scope.UserList, { UserId: userId }, true);
            angular.forEach(selectedUserList, function (tempItemModel) {
                tempItemModel.Checked = true;  
            });
        }


        return resultText;
    }

    $scope.PreviousPageButton_uClick = function () {
        $scope.SelAll.checked = false;
        uoffset -= userrolelimit;
        getAllUserList()
    }


    $scope.NextPageButton_uClick = function () {
        $scope.SelAll.checked = false;
        uoffset += userrolelimit;
        getAllUserList()
    }


    $scope.SelAll = { checked: false };
    $scope.SelectAll = function () {

        angular.forEach($scope.UserList, function (userModel) {

            var isDisabled = false;
            var filterUserList = $filter('filter')($scope.UserInRoleList, { UserId: userModel.UserId }, true);
            if (typeof filterUserList != 'undefined' && filterUserList.length > 0) {
                isDisabled = true;
            }
            userModel.Checked = $scope.SelAll.checked;
            
            if (isDisabled) {
                if (userModel.Checked) {
                    deletedMemberList = $.grep(deletedMemberList, function (item, index) {
                        return item.UserId != userModel.UserId;
                    });

                } else {
                    var filterUserListpush = $filter('filter')(deletedMemberList, { UserId: userModel.UserId }, true);
                    if (typeof filterUserListpush == 'undefined' || filterUserListpush.length == 0) {
                        deletedMemberList.push(userModel);
                    }
                }
            }
            else {
                if (userModel.Checked) {
                    var filterUserListpush = $filter('filter')($scope.UserCheckedFinal, { UserId: userModel.UserId }, true);
                    if (typeof filterUserListpush == 'undefined' || filterUserListpush.length == 0) {
                        $scope.UserCheckedFinal.push(userModel);
                    }

                } else {

                    $scope.UserCheckedFinal = $.grep($scope.UserCheckedFinal, function (item, index) {
                        return item.UserId != userModel.UserId;
                    });
                }
            }

        });
    }

    $scope.getAllCheckedUsers = function (userModel) {
        userModel.Checked = !userModel.Checked; 

    };

    $scope.SelectCurrentUser = function (userModel, $event) {
        $scope.UserSelected(userModel, $event)
        if ($event.ctrlKey) {
            userModel.Selected ? userModel.Selected = false : userModel.Selected = true;
        }
        else {
            this.getAllSelectedUsers(userModel);
        }
    };

    $scope.getAllSelectedUsers = function (userModel) {
        var selectedUserList = $filter('filter')($scope.UserList, { Selected: true });
        angular.forEach(selectedUserList, function (tempItemModel) {
            tempItemModel.Selected = false;
        });
        userModel.Selected = true;
    };

    $scope.UserSelected = function (userModel, $event) {

        var isDisabled = false;
        var filterUserList = $filter('filter')($scope.UserInRoleList, { UserId: userModel.UserId }, true);
        if (typeof filterUserList != 'undefined' && filterUserList.length > 0) {
            isDisabled = true;
        }

        if ($event && $event.ctrlKey) {
            userModel.Checked ? userModel.Checked = false : userModel.Checked = true;
        }
        else {
            this.getAllCheckedUsers(userModel);
        }
        if (isDisabled) {

            if (userModel.Checked) {
                deletedMemberList = $.grep(deletedMemberList, function (item, index) {
                    return item.UserId != userModel.UserId;
                });

            } else {
                var filterUserListpush = $filter('filter')(deletedMemberList, { UserId: userModel.UserId }, true);
                if (typeof filterUserListpush == 'undefined' || filterUserListpush.length == 0) {
                    deletedMemberList.push(userModel);
                }
            }
        }
        else {
            
            if (userModel.Checked) {
                var filterUserListpush = $filter('filter')($scope.UserCheckedFinal, { UserId: userModel.UserId }, true);
                if (typeof filterUserListpush == 'undefined' || filterUserListpush.length == 0) {
                    $scope.UserCheckedFinal.push(userModel);
                }

            } else {

                $scope.UserCheckedFinal = $.grep($scope.UserCheckedFinal, function (item, index) {
                    return item.UserId != userModel.UserId;
                });
            }
        }
    };


    $rootScope.$on('onsubTableFiltering', function (event, value, key) {

        if (urequestModel.filters.length > 0) {
            urequestModel.filters = jQuery.grep(urequestModel.filters, function (filterItem) {
                return filterItem.FilterKey !== key;
            });
        }
        //  if (value.length == 0) return;

        var filterValueList = [];
        filterValueList[0] = value;

        var filterItem = { 'FilterKey': key, 'FilterValues': filterValueList };
        urequestModel.filters.push(filterItem);
        uoffset = 0;
        getAllUserList();
    });


    $scope.onUserSearch = function () {
        if (searchUserTimeout) $timeout.cancel(searchUserTimeout);
        uoffset = 0;
        getAllUserList();
    }

    $scope.onUserClearSearch = function () {
        //if (searchUserTimeout) $timeout.cancel(searchUserTimeout);
        //uoffset = 0;
        $scope.UserSearchText = '';
        //getAllUserList();
    }

    var searchUserTimeout;
    $scope.$watch(function () { return $scope.UserSearchText }, function (val) {
        if (searchUserTimeout) $timeout.cancel(searchUserTimeout);

        searchUserTimeout = $timeout(function () {
            $scope.onUserSearch();
        }, 2000);
    }, true);

    //new table intgration events
  

    $scope.TablePagination = {
        order: 'name',
        limit: userrolelimit,
        page: 1,
        totalCount: 0
    };

    $scope.onPaginateUserList = function (page, limit) {
        userrolelimit = limit;
        uoffset = (page-1) * limit;

        //roleListRequestModel.pagenumber = page;
        //roleListRequestModel.pageLength = limit;
        getAllUserList();
        //$scope.promise1 = $timeout(function () {

        //}, 2000);
    };

    $scope.query = {
        order: 'name',
        limit: roleListRequestModel.pageLength,
        page: roleListRequestModel.pagenumber,
        totalCount: 0
    };

    $scope.onPaginate = function (page, limit) {

        roleListRequestModel.pagenumber = page;
        roleListRequestModel.pageLength = limit;
        getRoleList();
        $scope.promise = $timeout(function () {

        }, 2000);
    };

    $scope.deSelect = function (item) {
        setContextMenuObject();
    };

    $scope.onSelect = function (item) {
        setContextMenuObject();
    };

    $scope.log = function (item) {

    };

    $scope.loadStuff = function () {
        $scope.promise = $timeout(function () {

        }, 2000);
    };

    $scope.onReorder = function (order) {

        console.log('Scope Order: ' + $scope.query.order);
        console.log('Order: ' + order);

        $scope.promise = $timeout(function () {

        }, 2000);
    };

    $scope.CheckedUserSelectionChanged = function () {
        uoffset=0;
        userrolelimit=10;
        getAllUserList();
    }

};