﻿iManageApp.controller("UserController", UserController);
//UserController.$inject = ['$scope', '$rootScope', '$filter', '$timeout', 'UserService', 'userFactory']; //'toastr',  'datatableSettingsFactory', 'toastPlugins', '$mdDialog', '$mdMedia', 'GroupService',, 'DatabaseService'

//function UserController($scope, $rootScope, $filter, $timeout, UserService, userFactory) {
UserController.$inject = ['$scope', '$rootScope', '$filter', '$timeout', 'UserService', 'userFactory', 'homeFactory', 'HomeService']; //'toastr',  'datatableSettingsFactory', 'toastPlugins', '$mdDialog', '$mdMedia', 'GroupService',, 'DatabaseService' 'ngTableParams', 

function UserController($scope, $rootScope, $filter, $timeout, UserService, userFactory, homeFactory, HomeService) {//toastr, datatableSettingsFactory, toastPlugins, $mdDialog, $mdMedia,GroupService,, DatabaseService ngTableParams,
    $scope.PageEvents.Edit = undefined;
    $scope.PageEvents.AssignGroup = undefined;
    //$scope.tableParams = new ngTableParams({
    //    noPager: true
    //    //page: 1,            // show first page
    //    //                    count: 10,          // count per page
    //    //                    filter: {
    //    //                        //name: 'M'       // initial filter
    //    //                    },
    //    //                    sorting: {
    //    //                        //name: 'asc'     // initial sorting
    //    //                    }
    //}, {
    //    //total: data.length, // length of data					counts: [],
    //    getData: function ($defer, params) {
    //        $defer.resolve($scope.UserList);
    //    }
    //});

    $scope.PrefferedDB = {
        IsSearchTextFound: false,
        SearchText: ''
    };
    $scope.selectGroup = {
        IsSearchTextFound: false,
        SearchText: ''
    };

    $scope.SelAll = { checked: false };

    $timeout(function () {
        $('#responsive-table').slimScroll({
            height: '405px'
        });
        $('#dvUserAdminPanelTable').slimScroll({
            height: '265px'
        });
        $('#dvGroupMembershipPanelTable').slimScroll({
            height: '265px'
        });
        $('#dvHelpDeskPanelTable').slimScroll({
            height: '265px'
        });
        $('#dvAdminPanel').slimScroll({
            height: '200px'
        });
        $('#dvGroupMembershipPanel').slimScroll({
            height: '200px'
        });
        $('#dvHelpDeskPanel').slimScroll({
            height: '200px'
        });
    });

    $scope.PageEvents.ResetPasswordclicked = function () {
        if ($("#contextmenunode"))
            $("#contextmenunode").remove();
        $scope.ValidateUsers = $filter('filter')($scope.UserList, { Selected: true });
        if (typeof $scope.ValidateUsers !== 'undefined' && $scope.ValidateUsers.length > 0) {
            $scope.ShowWarning = false;
            $scope.validation.ConfirmPassword = '';
            $scope.validation.showMessage = false;
            $scope.user = userFactory.userInitailValues();
            var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
            $mdDialog.show({
                // controller: UserController,
                controller: DialogController,
                scope: $scope,        // use parent scope in template
                preserveScope: true,  // do not forget this if use parent scope
                templateUrl: 'Views/NgTemplates/ResetPassword.html',
                parent: angular.element(document.body),
                //targetEvent: event,
                clickOutsideToClose: true,
                fullscreen: useFullScreen
            })
            .then(function (answer) {
                $scope.status = 'You said the information was "' + answer + '".';
            }, function () {
                $scope.status = 'You cancelled the dialog.';
            });
            $scope.$watch(function () {
                return $mdMedia('xs') || $mdMedia('sm');
            }, function (wantsFullScreen) {
                $scope.customFullscreen = (wantsFullScreen === true);
            });
        }
        else {
            $scope.showAlertMessage('Select a User first.');
            return false;
        }

    };

    $scope.External = false;
    $scope.SortOrder = false;
    
    var ContextMenuVariables = {
        LockUnlock: {
            Label: 'Lock',
            Icon: 'img/icons/lock_outline_blue.svg',
            onClick: angular.noop
        }
    }

    $scope.ContextMenuFunctions = {
        Add: function () { $scope.PageEvents.Add(); },
        Edit: function () { editFunction(); },
        Delete: undefined,
        ResetPassword: function () { $scope.PageEvents.ResetPasswordclicked(); },
        AssignToGroup: function () { AssignGroupFunction(); },
        ViewUser: function () { viewFunction(); },
        ViewUserContent: function () { ViewUserContentFunction(); },
        EditUserContent: function () { EditUserContentFunction(); },
		LockAccount: function () {
            var selectedUsers = $filter('filter')($scope.UserList, { Selected: true });
            var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
            var confirm = $mdDialog.confirm()
                .title('Lock Accounts')
                .textContent('Are you sure to lock selected account(s)?')
                .ariaLabel('Lock Accounts')
                .ok('Proceed')
                .cancel('Cancel');

            $mdDialog.show(confirm).then(function () {
                var promise = UserService.LockUnlockUser($scope.selectedLibrary, selectedUsers, false);
                promise.then(function (response) {
                    if (response.data.length > 0) {
                        userInitalize();
                    }
                }, function () {
                    //$scope.status = 'You decided to keep your debt.';
                });
            });
        },
        UnlockAccount: function () {
            var selectedUsers = $filter('filter')($scope.UserList, { Selected: true });
            var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
            var confirm = $mdDialog.confirm()
                .title('Unlock Accounts')
                .textContent('Are you sure to unlock selected account(s)?')
                .ariaLabel('Unlock Accounts')
                .ok('Proceed')
                .cancel('Cancel');

            $mdDialog.show(confirm).then(function () {
                var promise = UserService.LockUnlockUser($scope.selectedLibrary, selectedUsers, true);
                promise.then(function (response) {
                    if (response.data.length > 0) {
                        userInitalize();
                    }
                }, function () {
                    //$scope.status = 'You decided to keep your debt.';
                });
            });
        }
    }

    function setContextMenuObject() {

        var selectedUsers = $filter('filter')($scope.UserList, { Selected: true });
        if (selectedUsers !== undefined && selectedUsers.length > 0) {
            if (selectedUsers.length == 1) {
                if (selectedUsers[0].IsAllowLogon) {
                    ContextMenuVariables.LockUnlock.Label = 'Lock Account';
                    ContextMenuVariables.LockUnlock.Icon = 'img/icons/lock_outline_blue.svg';
                    ContextMenuVariables.LockUnlock.onClick = $scope.ContextMenuFunctions.LockAccount;
                    $scope.PageEvents.LockAccount = $scope.ContextMenuFunctions.LockAccount;
                    $scope.PageEvents.UnlockAccount = undefined;
                } else {
                    ContextMenuVariables.LockUnlock.Label = 'Unlock Account';
                    ContextMenuVariables.LockUnlock.Icon = 'img/icons/lock_open_blue.svg';
                    ContextMenuVariables.LockUnlock.onClick = $scope.ContextMenuFunctions.UnlockAccount;
                    $scope.PageEvents.LockAccount = undefined;
                    $scope.PageEvents.UnlockAccount = $scope.ContextMenuFunctions.UnlockAccount;
                }
            } else {
                ContextMenuVariables.LockUnlock.Label = '';
                ContextMenuVariables.LockUnlock.onClick = undefined;
                $scope.PageEvents.LockAccount = undefined;
                $scope.PageEvents.UnlockAccount = undefined;
                var unlockedUsersInSelectedList = $filter('filter')(selectedUsers, { IsAllowLogon: true });
                if (unlockedUsersInSelectedList.length == selectedUsers.length) {
                    ContextMenuVariables.LockUnlock.Label = 'Lock Account';
                    ContextMenuVariables.LockUnlock.Icon = 'img/icons/lock_outline_blue.svg';
                    ContextMenuVariables.LockUnlock.onClick = $scope.ContextMenuFunctions.LockAccount;
                    $scope.PageEvents.LockAccount = $scope.ContextMenuFunctions.LockAccount;
                    $scope.PageEvents.UnlockAccount = undefined;
                } else {
                    var lockedUsersInSelectedList = $filter('filter')(selectedUsers, { IsAllowLogon: false });
                    if (lockedUsersInSelectedList.length == selectedUsers.length) {
                        ContextMenuVariables.LockUnlock.Label = 'Unlock Account';
                        ContextMenuVariables.LockUnlock.Icon = 'img/icons/lock_open_blue.svg';
                        ContextMenuVariables.LockUnlock.onClick = $scope.ContextMenuFunctions.UnlockAccount;
                        $scope.PageEvents.LockAccount = undefined;
                        $scope.PageEvents.UnlockAccount = $scope.ContextMenuFunctions.UnlockAccount;
                    }
                }
            }
        } else {
            ContextMenuVariables.LockUnlock.Label = '';
            ContextMenuVariables.LockUnlock.onClick = undefined;
            $scope.PageEvents.LockAccount = undefined;
            $scope.PageEvents.UnlockAccount = undefined;
        }

	    $scope.ContextMenuObject = [
	        {
	            Label: 'Edit',
	            Icon: 'img/icons/edit.svg',
	            onClick: $scope.ContextMenuFunctions.Edit
	        },
	        {
	            Label: 'Delete',
	            Icon: 'img/icons/delete.svg',
	            onClick: $scope.ContextMenuFunctions.Delete
	        },
	        {
	            Label: 'Seperator'
	        },
	         {
	             Label: 'Add/Remove Groups',
	             Icon: 'img/icons/group_blue.svg',
	             onClick: $scope.ContextMenuFunctions.AssignToGroup
	         } ,
	          {
	              Label: 'View General User',
	              Icon: 'img/icons/view_blue.svg',
	              onClick: $scope.ContextMenuFunctions.ViewUser
	          },
	           {
	               Label: 'View User Content',
	               Icon: 'img/icons/view_blue.svg',
	               onClick: $scope.ContextMenuFunctions.ViewUserContent
	           },
	            {
	                Label: 'Edit User Content',
	                Icon: 'img/icons/edit.svg',
	                onClick: $scope.ContextMenuFunctions.EditUserContent
	            },
            {
                Label: 'Seperator'
            },
            {
                Label: 'Reset Password',
                Icon: 'img/icons/key_blue.svg',
                onClick: $scope.ContextMenuFunctions.ResetPassword
            }//,
            //{
            //    Label: ContextMenuVariables.LockUnlock.Label,
            //    Icon: ContextMenuVariables.LockUnlock.Icon,
            //    onClick: ContextMenuVariables.LockUnlock.onClick
            //}
	    ];
    }

    var AssignGroupFunction = function () {
        $scope.IsShowErrorMessage = false;
        $scope.GroupCheckedFInal = [];
        $scope.AssignGroupSearchText = '';
        goffset = 1;
        getAllGroupList();
        $scope.ValidateAddRemoveGroups = $filter('filter')($scope.UserList, { Selected: true });
        if (typeof $scope.ValidateAddRemoveGroups != 'undefined' && $scope.ValidateAddRemoveGroups.length > 0) {
            angular.copy($scope.ValidateAddRemoveGroups[0], $scope.user);           
            var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
            $mdDialog.show({
                controller: DialogController,
                scope: $scope,        // use parent scope in template
                preserveScope: true,
                templateUrl: 'Views/NgTemplates/AddRemoveGroups.html',
                parent: angular.element(document.body),
                clickOutsideToClose: true,
                fullscreen: useFullScreen
            })
            .then(function (answer) {
                $scope.status = 'You said the information was "' + answer + '".';
            }, function () {
                $scope.status = 'You cancelled the dialog.';
            });
            $scope.$watch(function () {
                return $mdMedia('xs') || $mdMedia('sm');
            }, function (wantsFullScreen) {
                $scope.customFullscreen = (wantsFullScreen === true);
            });
            return true;
        }
        else {
            $scope.showAlertMessage('Select a User first.');
            return false;
        }
    }
    

    var EditUserContentFunction = function () {
        $scope.ShowWarning = false;
        $scope.PageEvents.UserAction = 'Edit User Content';
        $scope.DisableViewUserContent = false;
        $scope.ShowSaveButton = false;
        $scope.ValidateUsers = $filter('filter')($scope.UserList, { Selected: true });
        if (typeof $scope.ValidateUsers !== 'undefined' && $scope.ValidateUsers.length > 0) {
            getDatabaseByUser($scope.ValidateUsers[0].UserId, $scope.ValidateUsers[0].Password);
            FillUserScope($scope.ValidateUsers[0]);
            var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
            $mdDialog.show({
                controller: DialogController,
                scope: $scope,        // use parent scope in template
                preserveScope: true,
                templateUrl: 'Views/NgTemplates/ViewUserContent.html',
                parent: angular.element(document.body),
                clickOutsideToClose: true,
                fullscreen: useFullScreen
            })
            .then(function (answer) {
                $scope.status = 'You said the information was "' + answer + '".';
            }, function () {
                $scope.status = 'You cancelled the dialog.';
            });
            $scope.$watch(function () {
                return $mdMedia('xs') || $mdMedia('sm');
            }, function (wantsFullScreen) {
                $scope.customFullscreen = (wantsFullScreen === true);
            });
        }
        else {
            $scope.showAlertMessage('Select user to edit.');
        }
    }

    var ViewUserContentFunction = function () {
        $scope.ShowWarning = false;
        $scope.PageEvents.UserAction = 'View User Content';
        $scope.DisableViewUserContent = true;
        $scope.ShowSaveButton = false;
        $scope.ValidateUsers = $filter('filter')($scope.UserList, { Selected: true });
        if (typeof $scope.ValidateUsers !== 'undefined' && $scope.ValidateUsers.length > 0) {
            getDatabaseByUser($scope.ValidateUsers[0].UserId, $scope.ValidateUsers[0].Password);
            FillUserScope($scope.ValidateUsers[0]);            
            var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
            $mdDialog.show({
                controller: DialogController,
                scope: $scope,        // use parent scope in template
                preserveScope: true,
                templateUrl: 'Views/NgTemplates/ViewUserContent.html',
                parent: angular.element(document.body),
                clickOutsideToClose: true,
                fullscreen: useFullScreen
            })
            .then(function (answer) {
                $scope.status = 'You said the information was "' + answer + '".';
            }, function () {
                $scope.status = 'You cancelled the dialog.';
            });
            $scope.$watch(function () {
                return $mdMedia('xs') || $mdMedia('sm');
            }, function (wantsFullScreen) {
                $scope.customFullscreen = (wantsFullScreen === true);
            });
        }
        else {
            $scope.showAlertMessage('Select user to edit.');
        }
    }

    var viewFunction = function () {
        $scope.ShowWarning = false;
        $scope.PageEvents.UserAction = 'View';
        $scope.DisableSaveButton = true;
        $scope.ValidateUsers = $filter('filter')($scope.UserList, { Selected: true });
        if (typeof $scope.ValidateUsers !== 'undefined' && $scope.ValidateUsers.length > 0) {
            FillUserScope($scope.ValidateUsers[0]);
            var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
            $mdDialog.show({
                controller: DialogController,
                scope: $scope,        // use parent scope in template
                preserveScope: true,
                templateUrl: 'Views/NgTemplates/EditUser.html',
                parent: angular.element(document.body),
                //targetEvent: event,
                clickOutsideToClose: true,
                fullscreen: useFullScreen
            })
            .then(function (answer) {
                $scope.status = 'You said the information was "' + answer + '".';
            }, function () {
                $scope.status = 'You cancelled the dialog.';
            });
            $scope.$watch(function () {
                return $mdMedia('xs') || $mdMedia('sm');
            }, function (wantsFullScreen) {
                $scope.customFullscreen = (wantsFullScreen === true);
            });
        }
        else {
            $scope.showAlertMessage('Select user to edit.');
        }
    }

    var editFunction = function (event) {
        $scope.ShowWarning = false;
        $scope.DisableSaveButton = false;
        $scope.PageEvents.UserAction = 'Edit';
        $scope.ValidateUsers = $filter('filter')($scope.UserList, { Selected: true });
        if (typeof $scope.ValidateUsers !== 'undefined' && $scope.ValidateUsers.length > 0) {
            FillUserScope($scope.ValidateUsers[0]);
            var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
            $mdDialog.show({
                controller: DialogController,
                scope: $scope,        // use parent scope in template
                preserveScope: true,
                templateUrl: 'Views/NgTemplates/EditUser.html',
                parent: angular.element(document.body),
                targetEvent: event,
                clickOutsideToClose: true,
                fullscreen: useFullScreen
            })
            .then(function (answer) {
                $scope.status = 'You said the information was "' + answer + '".';
            }, function () {
                $scope.status = 'You cancelled the dialog.';
            });
            $scope.$watch(function () {
                return $mdMedia('xs') || $mdMedia('sm');
            }, function (wantsFullScreen) {
                $scope.customFullscreen = (wantsFullScreen === true);
            });
        }
        else {
            $scope.showAlertMessage('Select user to edit.');
        }
    }


    $scope.haveMoreRows = true;
    $scope.loading = true;
    $scope.lastSelectedLibrary = '';
    $scope.appsVar.SearchText = '';
    $scope.dtInstance = {};
    $scope.appsVar.selectedRecordId = '';
    $scope.ShowWarning = false;
    $scope.ErrorMessage = '';
    $scope.changePswrd = false;

    $scope.PreviousPageCursorList = [];
    $scope.CurrentPageCursor = '';
    $scope.NextPageCursor = '';
    $scope.PreviousPageCursor = '';
    $scope.PrefferedDB.SearchText = '';
    $scope.SelectedgroupList = [];


    //$scope.PanelHeader = 'Admin Panel';
    //$scope.SelectPanelTabIndex = 0;
    //$scope.UserAdminPanelModelList = [];
    //$scope.UserHelpDeskPanelModelList = [];
    var Pdoffset = 1;
    var sgoffset = 1;
    var offset = 1;
    var goffset = 1;
    var limit = 10;
    var glimit = 12;
    var total = true;
    var PrefferedDBSearchTimeout;
    var SelectGroupSearchTimeout;


    $scope.user = userFactory.userInitailValues();
    $scope.validation = userFactory.validations();
    $scope.dtColumnDefs = datatableSettingsFactory.dtUserTableColumns;
    $scope.tableSettings = datatableSettingsFactory.tableSettings();
    var requestModel = homeFactory.requestModel;
    var grequestModel = homeFactory.requestModel;
    var gsrequestModel = homeFactory.requestModel;
    var pdbrequestModel = homeFactory.requestModel;

    getUsers();

    $scope.$on('onUserAppSelected', function () {
        getUsers();
    })

    $scope.$on('onUserTabClick', function () {
        userInitalize();
    })

    $scope.PreviousPageButton_Click = function () {
        offset = offset - 1;
        getUsers();
    }

    $scope.NextPageButton_Click = function () {
        //$scope.PreviousPageCursorList.push($scope.CurrentPageCursor);
        //$scope.CurrentPageCursor = $scope.NextPageCursor;
        // clearPanelData();
        offset = offset + 1;
        getUsers();
    }

    function getUsers() {
        requestModel.libraryName = $scope.selectedLibrary;
        requestModel.pagenumber = offset;
        requestModel.pageLength = limit;
        requestModel.isTotal = total;
        requestModel.searchText = $scope.appsVar.SearchText;
        if ($scope.selectedApp.NoAppsPermission.trim().length > 0) return;
        if (!$scope.selectedLibrary || $scope.selectedLibrary.trim().length == 0) return;


        $scope.SortOrder = false;
        $scope.loading = true;
        $scope.lastSelectedLibrary = $scope.selectedLibrary;
        //var promise = UserService.getUsers($scope.selectedLibrary, offset, limit, total, $scope.appsVar.SearchText, false);
        var promise = UserService.getUsers(requestModel, false)
        promise.then(function (response) {
            $scope.appsVar.initialLoading = false;
           
                if (response.data.rows.length > 0 && response.data.rows[0].cell.length > 0) {
                    $scope.isPrevDisable = offset <= 1;
                    $scope.isNextDisable = offset * limit >= response.data.total;
                    $scope.UserList = response.data.rows[0].cell[0];

                    $scope.loading = false;
                    $('#card-more-button').attr('disabled', 'disabled');
                }
            //}
            $scope.selectedApp.ResponseCount = $scope.UserList.length;         
            $scope.loading = false;
            $timeout(function () {
                refreshFabIcons();
            });
        }, function () {
            alert('Data fetching failed.');
        });
        $scope.ScrollCounter = false;
    }

    $scope.loadMoreOnScrollEnd = function () {
        if ($scope.haveMoreRows) {
            getUsers();
            $scope.ScrollCounter = false;
        }
    };

    $scope.SelectCurrentRow = function (userModel, $event) {
        //   clearPanelData();
        if ($event.ctrlKey) {
            userModel.Selected ? userModel.Selected = false : userModel.Selected = true;
            $scope.PageEvents.Edit = undefined;
            $scope.PageEvents.ViewGeneralUser = undefined;
            $scope.PageEvents.AssignGroup = undefined;
            $timeout(function () {
                refreshFabIcons();
            });
        }
        else {
            this.getAllSelectedRows(userModel);
            $scope.PageEvents.Edit = editFunction;
            $scope.PageEvents.ViewGeneralUser = viewFunction;
            $scope.PageEvents.AssignGroup = AssignGroupFunction;
            $timeout(function () {
                refreshFabIcons();
            });
        }
        setContextMenuObject();
        var selectedUserList = $filter('filter')($scope.UserList, { Selected: true });
        if (selectedUserList.length == 0) {           
            $('#card-more-button').attr('disabled', 'disabled');
        } else {
            $('#card-more-button').removeAttr('disabled');          
        }
    };

    (function ($) {
        $(document).ready(function () {
            $('#card-more-button').attr('disabled', 'disabled');
        });
    })(jQuery);


    $scope.getAllSelectedRows = function (userModel) {
        var selectedUserList = $filter('filter')($scope.UserList, { Selected: true });
        angular.forEach(selectedUserList, function (tempItemModel) {
            tempItemModel.Selected = false; //set them all to false
        });
        userModel.Selected = true; //set the clicked one to true

        /*
        if ($('#tabbed').hasClass('tabbeddisplay')) {
            if ($('#btnTabBindData').hasClass('button-transform') == false) {
                viewAdminPanel(userModel);
                viewHelpDeskPanel(userModel);
            }
        }
        else if ($('#accordian').hasClass('tabbeddisplay')) {
            if ($('#btnAccordianBindData').hasClass('button-transform') == false) {
                viewAdminPanel(userModel);
                viewHelpDeskPanel(userModel);
            }
        }*///put close comment here
    };

    $scope.toastOptions = toastPlugins.toastOptions;

    $scope.$watchCollection('toastOptions', toastPlugins.toastOptionWatchCollection);

    function userInitalize() {

        $scope.lastSelectedLibrary = '';
        $scope.UserList = [];
        $scope.loading = true;
        $scope.haveMoreRows = true;
        //clearPanelData();
        offset = 1;
        getUsers();
    }

    function FillUserScope(selectedUser) {
        $scope.user.UserId = selectedUser.UserId;
        $scope.user.FullName = selectedUser.FullName;
        $scope.user.Location = selectedUser.Location
        $scope.user.Phone = selectedUser.Phone;
        $scope.user.Ext = selectedUser.Ext;
        $scope.user.Fax = selectedUser.Fax;
        $scope.user.Email = selectedUser.Email == null ? '' : selectedUser.Email;
        $scope.user.IsExternalUser = selectedUser.IsExternalUser;
        $scope.user.Password = '';
        $scope.user.UserMustChangePassword = selectedUser.UserMustChangePassword;
        $scope.user.PasswordNeverExpires = selectedUser.PasswordNeverExpires;
        $scope.user.IsAllowLogon = selectedUser.IsAllowLogon;
        $scope.user.PreferredDatabase = selectedUser.PreferredDatabase;
        $scope.user.FileServer = selectedUser.FileServer;
        $scope.user.SecuredDocServer =selectedUser.SecuredDocServer;
        $scope.user.UserNos = selectedUser.UserNos;
        $scope.user.UserNum = selectedUser.UserNum;
        $scope.user.UserIdEx = selectedUser.UserIdEx;
    }

    $scope.addUser = function () {
        $scope.posting = true;
        $scope.validation.showMessage = true;
        if ($scope.user.UserId == '' || $scope.user.Password == '' || $scope.validation.ConfirmPassword != $scope.user.Password || ($scope.user.Email != '' && !validateEmail($scope.user.Email))) {
            $scope.posting = false;
            return;
        } else {
             
            var promise = UserService.addUser($scope.user, $scope.selectedLibrary, $scope.SelectedgroupList);
            promise.then(function (response) {
                if (response.data.rows.length > 0) {
                    if (response.data.rows[0].cell.length > 0) {

                        if (response.data.rows[0].cell[2] == 'Success') {
                            $scope.SelectedgroupList = [];
                            getUsers();
                           
                            $scope.showValidation = false;
                            setTimeout(function () {
                                $mdDialog.hide();
                                $scope.ShowWarning = false;
                                $scope.user = userFactory.userInitailValues();
                                $scope.validation = userFactory.validations();
                            }, 1500);
                        }
                        $scope.ShowWarning = true;
                        $scope.ErrorMessage = response.data.rows[0].cell[2];

                    }

                }
                $scope.posting = false;

            }, function () {
            });
        }
    }

    $scope.cancelAddUserDialoge = function () {
        $scope.user = userFactory.userInitailValues();
        $scope.validation = userFactory.validations();
        $scope.ShowWarning = false;
        $scope.showValidation = false;
        $('#Add_Virtual_User').modal('hide');
    }

    $scope.$on('Search_Click', function (event, args) {
        userInitalize();
    });

    $rootScope.$on('onUserBulkDeleteClick', function () {
        $scope.Users = [];
        UserBulkDeleteClick();
    })

    function UserBulkDeleteClick() {
        $scope.Users = $filter('filter')($scope.UserList, { selected: true });
        var getUser = UserService.DeleteUser($scope.Users);
        getUser.then(function (response) {
            if (response.data == "success") {
                $scope.appsVar.selectedRecordId = '';
                userInitalize();
                $scope.showAlertMessage("Selected user(s) deleted successfully.");
            } else {
                $scope.showAlertMessage('Failed to delete selected user(s).');
            }
        }, function () {
            $scope.showAlertMessage('Failed to delete selected user(s).');
        });
    }

    $scope.singleDeleteConfirmMessageClick = function () {
        $scope.showSingleUserDeleteConfirmMessage('Are you sure to delete ' + $scope.appsVar.selectedRecordId + '?');
    };

    $scope.singleDeleteClick = function () {
        var s = $scope.appsVar.selectedRecordId;
        var getUser = UserService.DeleteUser(s);

        getUser.then(function (response) {
            if (response.data == "success") {
                $scope.appsVar.selectedRecordId = '';
                userInitalize();
                $scope.showAlertMessage("Selected user(s) deleted successfully.");
            } else {
                $scope.showAlertMessage('Failed to delete selected user(s).');
            }
        }, function () {
            $scope.showAlertMessage('Failed to delete selected user(s).');
        });

    };

    $rootScope.$on('onUserValidateBulkDeleteClick', function () {
        $scope.ValidateUsers = [];
        UserValidateBulkDeleteClick();
    })

    function UserValidateBulkDeleteClick(btnTemp) {
        $scope.ValidateUsers = $filter('filter')($scope.UserList, { selected: true });
        if (typeof $scope.ValidateUsers !== 'undefined' && $scope.ValidateUsers.length > 0) {

            $scope.showConfirmMessage('Are you sure to delete selected user(s)?');
            return true;
        }
        else {
            $scope.showAlertMessage('Select user(s) to delete.');
            return false;
        }
    }

    $scope.editUser = function () {
        $scope.validation.showMessage = true;
        if (($scope.user.Email != '' && !validateEmail($scope.user.Email))) {
            return;
        }
        var promise = UserService.editUser($scope.user, $scope.selectedLibrary);
        promise.then(function (response) {
            if (response.data.rows.length > 0) {

                if (response.data.rows.length > 0) {
                    if (response.data.rows[0].cell.length > 0) {

                        if (response.data.rows[0].cell[2] == 'Success') {
                            getUsers();
                            //$scope.user = userFactory.userInitailValues();
                            //$scope.validation = userFactory.validations();
                            $scope.showValidation = false;
                            setTimeout(function () {
                                //$('#Edit_User').modal('hide');
                                $mdDialog.hide();
                                ResetUserModel();
                                $scope.user = userFactory.userInitailValues();
                                $scope.validation = userFactory.validations();
                                $scope.ShowWarning = false;
                            }, 1500);
                        }
                        $scope.ShowWarning = true;
                        $scope.ErrorMessage = response.data.rows[0].cell[2];

                    }

                }
                $scope.posting = false;

            }
        }, function () {
        });
    }

    function validateEmail(emailAddress) {
        var EMAIL_REGEXP = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$/;
        if (!EMAIL_REGEXP.test(emailAddress)) {
            return false;
        }
        return true;
    }

    $scope.isChangePswrd = function () {
        $scope.changePswrd = ($scope.changePswrd) ? false : true;
        return $scope.changePswrd;
    };

    $scope.showSingleUserDeleteConfirmMessage = function (message) {
        $("#Singleconfirm_popup").find('#singleconfirmMsgText').text(message);
        $("#Singleconfirm_popup").modal();
    }

    $scope.$on('Refresh_Click', function () {
        userInitalize();
    });

    $scope.singleEditClick = function (event) {
        $scope.ShowWarning = false;
        $scope.ValidateUsers = $filter('filter')($scope.UserList, { UserId: $scope.appsVar.selectedRecordId });
        if (typeof $scope.ValidateUsers !== 'undefined' && $scope.ValidateUsers.length > 0) {
            FillUserScope($scope.ValidateUsers[0]);
            //$("#Edit_User").modal();UserController
            var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
            $mdDialog.show({
                //controller: DialogController,
                controller: DialogController,
                scope: $scope,        // use parent scope in template
                preserveScope: true,
                templateUrl: 'Views/NgTemplates/EditUser.html',
                parent: angular.element(document.body),
                targetEvent: event,
                clickOutsideToClose: true,
                fullscreen: useFullScreen,
                // scope: this.$new()
            })
            .then(function (answer) {
                $scope.status = 'You said the information was "' + answer + '".';
            }, function () {
                $scope.status = 'You cancelled the dialog.';
            });
            $scope.$watch(function () {
                return $mdMedia('xs') || $mdMedia('sm');
            }, function (wantsFullScreen) {
                $scope.customFullscreen = (wantsFullScreen === true);
            });
        }

    }

    $scope.$on('UserGroupAddRemoveMenu_Click', function () {
        var filterGroupList = $filter('filter')($scope.UserList, { selected: true }, true);
        if (typeof filterGroupList != 'undefined' && filterGroupList.length > 0) {
            $scope.$broadcast('UserAddRemoveGroupButton_Click', filterGroupList[0].UserId);
        }
        else {
            $scope.showAlertMessage('Select user to add / remove groups.');
        }
    });

    $scope.PageEvents.Add = function () {
        $scope.ShowWarning = false;
        $scope.validation.ConfirmPassword = '';
        $scope.validation.showMessage = false;
        $scope.user = userFactory.userInitailValues();
        var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
        $mdDialog.show({
            // controller: UserController,
            controller: DialogController,
            scope: $scope,        // use parent scope in template
            preserveScope: true,  // do not forget this if use parent scope
            templateUrl: 'Views/NgTemplates/AddUser.html',
            parent: angular.element(document.body),
            //targetEvent: event,
            clickOutsideToClose: true,
            fullscreen: useFullScreen
        })
        .then(function (answer) {
            $scope.status = 'You said the information was "' + answer + '".';
        }, function () {
            $scope.status = 'You cancelled the dialog.';
        });
        $scope.$watch(function () {
            return $mdMedia('xs') || $mdMedia('sm');
        }, function (wantsFullScreen) {
            $scope.customFullscreen = (wantsFullScreen === true);
        });
    }

    $scope.applyFilter = function (key, ctrlId) {
        var filterValue = $('#' + ctrlId).val().trim();

        if (requestModel.filters.length > 0) {
            requestModel.filters = jQuery.grep(requestModel.filters, function (filterItem) {
                return filterItem.FilterKey !== key;
            });
        }
        if (filterValue.length == 0) return;

        var filterValueList = [];
        filterValueList[0] = filterValue;

        var filterItem = { 'FilterKey': key, 'FilterValues': filterValueList };
        requestModel.filters.push(filterItem);

        getUsers();
    }


    $scope.hide = function () {
        $mdDialog.hide();
    };

    $scope.cancel = function () {
        $mdDialog.cancel();
    };

    $scope.answer = function () {
        $mdDialog.hide();
    };

    function DialogController($scope, $mdDialog) {
        $scope.hide = function () {
            $mdDialog.hide();
        };
        $scope.cancel = function () {
            $mdDialog.cancel();
        };
        $scope.answer = function () {
            $mdDialog.hide();
            $scope.SelectedgroupList = [];
        };
    }

    $scope.$on('onTableFiltering', function (event, value, key) {


        if (requestModel.filters.length > 0) {
            requestModel.filters = jQuery.grep(requestModel.filters, function (filterItem) {
                return filterItem.FilterKey !== key;
            });
        }
        

        var filterValueList = [];
        filterValueList[0] = value;

        var filterItem = { 'FilterKey': key, 'FilterValues': filterValueList };
        requestModel.filters.push(filterItem);
        offset = 1;
        getUsers();
    })

    $scope.ResetPassword = function () {
        $scope.posting = true;
        $scope.validation.showMessage = true;
        if ($scope.user.Password == '' || $scope.validation.ConfirmPassword != $scope.user.Password) {
            $scope.posting = false;
            return;
        }
        else {
            $scope.ResetPasswordUsers = $filter('filter')($scope.UserList, { Selected: true });
            if ($scope.ResetPasswordUsers.length > 0) {
                angular.forEach($scope.ResetPasswordUsers, function (temp) {
                    temp.Password = $scope.user.Password; //set them all to false
                    temp.UserMustChangePassword = $scope.user.UserMustChangePassword;
                    temp.PasswordNeverExpires = $scope.user.PasswordNeverExpires;
                });
                //$scope.user.UserId = $scope.appsVar.rightClickMenuID;
                var ResetPaswdUser = UserService.ResetPasswordUser($scope.ResetPasswordUsers, $scope.selectedLibrary);

                ResetPaswdUser.then(function (response) {
                    if (response.data.rows.length > 0) {

                        if (response.data.rows.length > 0) {
                            if (response.data.rows[0].cell.length > 0) {

                                if (response.data.rows[0].cell[2] == 'Success') {
                                    //getUsers();
                                    //$scope.showValidation = false;
                                    setTimeout(function () {
                                        $mdDialog.hide();
                                        //ResetUserModel();
                                        //$scope.user = userFactory.userInitailValues();
                                        //$scope.validation = userFactory.validations();
                                        $scope.ShowWarning = false;
                                    }, 1500);
                                }
                                $scope.ShowWarning = true;
                                $scope.ErrorMessage = response.data.rows[0].cell[2];

                            }

                        }
                        $scope.posting = false;

                    }
                }, function () {
                });

            }
            else {
                $mdDialog.show(
                 $mdDialog.alert()
                     .parent(angular.element(document.querySelector('#popupContainer')))
                     .clickOutsideToClose(true)
                     .title('Alert')
                     .textContent('Please select a User.')
                     .ariaLabel('Update info dialog')
                     .ok('OK')
                    );
            }

        }
    }

    $scope.$on('onsubTableFiltering', function (event, value, key) {
        if (grequestModel.filters.length > 0) {
            grequestModel.filters = jQuery.grep(grequestModel.filters, function (filterItem) {
                return filterItem.FilterKey !== key;
            });
        }
        //if (value.length == 0) return;

        var filterValueList = [];
        filterValueList[0] = value;

        var filterItem = { 'FilterKey': key, 'FilterValues': filterValueList };
        grequestModel.filters.push(filterItem);
        goffset = 1;
        getAllGroupList();
    })


    $scope.GroupSearchText = '';
    function getAllGroupList() {
        grequestModel.libraryName = $scope.selectedLibrary;      
        grequestModel.pageLength = limit;
        grequestModel.searchText = $scope.AssignGroupSearchText;
        grequestModel.pagenumber = goffset;      

        if (grequestModel.filters.length == 0) {
            var filterItem = { 'FilterKey': 'GroupEnabled', 'FilterValues': ['Y'] };
            grequestModel.filters.push(filterItem);
        }

        if (!$scope.selectedLibrary || $scope.selectedLibrary.trim().length == 0) return;
        $scope.lastSelectedLibrary = $scope.selectedLibrary;
        var Group = GroupService.getGroups(grequestModel);

        Group.then(function (response) {
            $scope.appsVar.initialLoading = false;
            if (response) {
                if (response.data.Status) {
                    $scope.isgPrevDisable = goffset <= 1;
                    $scope.isgNextDisable = goffset * limit >= response.data.total;
                    $scope.GroupDetails = response.data.rows[0].cell[0];

                    //$scope.NextPageCursor = response.data.cursor;
                    //$scope.haveMoreRows = response.data.moreRowsFound;
                    //if ($scope.CurrentPageCursor == '')
                    //    $scope.isgPrevDisable = true;
                    //else
                    //    $scope.isgPrevDisable = false;
                    //$scope.isgNextDisable = !response.data.moreRowsFound;
                    $scope.loading = false;
                    var groupschecklist = [];
                    angular.forEach($scope.GroupDetails, function (item) {
                        groupschecklist.push(item.GroupName);
                    });

                    var promiseOne = GroupService.GetSelectedGroupsOfUsers($scope.selectedLibrary, $scope.user.UserId, groupschecklist)
                    promiseOne.then(function (responseuser) {
                        $scope.GroupInUserList = responseuser.data.rows[0].cell[0];
                        if ($scope.GroupCheckedFInal != null && $scope.GroupCheckedFInal.length > 0) {
                            angular.forEach($scope.GroupCheckedFInal, function (GroupCheckedModel) {
                                var filterGroupList = $filter('filter')($scope.GroupDetails, { GroupName: GroupCheckedModel.GroupName }, true);
                                if (typeof filterGroupList != 'undefined' && filterGroupList.length > 0) {
                                    filterGroupList[0].Checked = true;
                                }
                            });
                        }
                        
                            if ($scope.GroupInUserList != null && $scope.GroupInUserList.length > 0) {
                                angular.forEach($scope.GroupInUserList, function (GroupCheckedModel) {
                                    var filterGroupList = $filter('filter')($scope.GroupDetails, { GroupName: GroupCheckedModel.GroupName }, true);
                                    if (typeof filterGroupList != 'undefined' && filterGroupList.length > 0) {
                                        filterGroupList[0].Checked = true;
                                    }
                                });
                            }

                            if ($scope.GroupRemovedFInal != null && $scope.GroupRemovedFInal.length > 0) {
                                angular.forEach($scope.GroupRemovedFInal, function (GroupCheckedModel) {
                                    var filterGroupList = $filter('filter')($scope.GroupDetails, { GroupName: GroupCheckedModel.GroupName }, true);
                                    if (typeof filterGroupList != 'undefined' && filterGroupList.length > 0) {
                                        filterGroupList[0].Checked = false;
                                    }
                                });
                            }
                        
                    }, function () {
                        alert('Data fetching failed.');
                    });




                }
            }
            $scope.selectedApp.ResponseCount = $scope.GroupDetails.length;

        }, function () {
            alert('Data fetching failed.');
        });

    }

    function getAllGroupsInUser() {
        if (!$scope.selectedLibrary || $scope.selectedLibrary.trim().length == 0) return;
        $scope.lastSelectedLibrary = $scope.selectedLibrary;
        var promise = GroupService.getAllGroupsInUser($scope.selectedLibrary, $scope.user.UserId)
        promise.then(function (response) {
            if (response.data.rows.length > 0 && response.data.rows[0].cell.length > 0) {
                $scope.GroupInUserList = response.data.rows[0].cell[0];
            }

        }, function () {
            alert('Data fetching failed.');
        });

    }

    $scope.PageEvents.AssignGroup = function (row) {
        $scope.IsShowErrorMessage = false;
        $scope.GroupCheckedFInal = [];
        $scope.AssignGroupSearchText = '';
        getAllGroupList();
        if (row) {
            var UserId = $scope.appsVar.selectedRecordId;
            $scope.ValidateAddRemoveGroups = $filter('filter')($scope.UserList, { UserId: UserId });
        }
        else {
            $scope.ValidateAddRemoveGroups = $filter('filter')($scope.UserList, { Selected: true });
        }
        if (typeof $scope.ValidateAddRemoveGroups != 'undefined' && $scope.ValidateAddRemoveGroups.length > 0) {
            angular.copy($scope.ValidateAddRemoveGroups[0], $scope.user);
            setTimeout(function () {
                getAllGroupsInUser();
                $scope.GroupCheckedFInal = [];
            }, 100);
            var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
            $mdDialog.show({
                controller: DialogController,
                scope: $scope,        // use parent scope in template
                preserveScope: true,
                templateUrl: 'Views/NgTemplates/AddRemoveGroups.html',
                parent: angular.element(document.body),
                clickOutsideToClose: true,
                fullscreen: useFullScreen
            })
            .then(function (answer) {
                $scope.status = 'You said the information was "' + answer + '".';
            }, function () {
                $scope.status = 'You cancelled the dialog.';
            });
            $scope.$watch(function () {
                return $mdMedia('xs') || $mdMedia('sm');
            }, function (wantsFullScreen) {
                $scope.customFullscreen = (wantsFullScreen === true);
            });
            return true;
        }
        else {
            $scope.showAlertMessage('Select a User first.');
            return false;
        }
    }

    $scope.SelectCurrentGroup = function (GroupModel, $event) {
        $scope.GroupSelected(GroupModel, $event)
        if ($event.ctrlKey) {
            GroupModel.Selected ? GroupModel.Selected = false : GroupModel.Selected = true;
        }
        else {
            this.getAllSelectedGroups(GroupModel);
        }
    };

    $scope.getAllSelectedGroups = function (GroupModel) {
        var selectedGroupList = $filter('filter')($scope.GroupDetails, { Selected: true });
        angular.forEach(selectedGroupList, function (tempItemModel) {
            tempItemModel.Selected = false; //set them all to false
        });
        GroupModel.Selected = true; //set the clicked one to true
    };

    $scope.GroupCheckedFInal = [];
    $scope.GroupRemovedFInal = [];
    $scope.GroupSelected = function (GroupModel, $event) {
        var isDisabled = false;
        var filterGroupList = $filter('filter')($scope.GroupInUserList, { GroupName: GroupModel.GroupName }, true);
        if (typeof filterGroupList != 'undefined' && filterGroupList.length > 0) {
            isDisabled = true;
        }

        if ($event.ctrlKey) {
            GroupModel.Checked ? GroupModel.Checked = false : GroupModel.Checked = true;
        }
        else {
            this.getAllCheckedGroups(GroupModel);
        }

        if (isDisabled) {

            if (GroupModel.Checked) {
                $scope.GroupRemovedFInal = $.grep($scope.GroupRemovedFInal, function (item, index) {
                    return item.GroupName != GroupModel.GroupName;
                });

            } else {
                var filterUserListpush = $filter('filter')($scope.GroupRemovedFInal, { GroupName: GroupModel.GroupName }, true);
                if (typeof filterUserListpush == 'undefined' || filterUserListpush.length == 0) {
                    $scope.GroupRemovedFInal.push(GroupModel);
                }

            }

        }
        else {

            //if (GroupModel.Checked) {
            //    $scope.GroupCheckedFInal.push(GroupModel);
            //} else {
            //    var filterUserListpop = $filter('filter')($scope.GroupCheckedFInal, { GroupName: GroupModel.GroupName }, true);
            //    if (typeof filterUserListpop == 'undefined' || filterUserListpop.length == 0) {
            //        $scope.GroupCheckedFInal.pop(GroupModel);
            //    }

            //}



            if (GroupModel.Checked) {
                var filterUserListpush = $filter('filter')($scope.GroupCheckedFInal, { GroupName: GroupModel.GroupName }, true);
                if (typeof filterUserListpush == 'undefined' || filterUserListpush.length == 0) {
                    $scope.GroupCheckedFInal.push(GroupModel);
                }
            } else {

                $scope.GroupCheckedFInal = $.grep($scope.GroupCheckedFInal, function (item, index) {
                    return item.GroupName != GroupModel.GroupName;
                });



            }
        }
    };

    $scope.getAllCheckedGroups = function (GroupModel) {
        GroupModel.Checked = !GroupModel.Checked; //set the clicked one to true
    };

    $scope.isAlreadyAvilable = function (GroupName) {
        var resultText = false;
        var filterGroupList = $filter('filter')($scope.GroupInUserList, { GroupName: GroupName }, true);
        if (typeof filterGroupList != 'undefined' && filterGroupList.length > 0) {
            resultText = true;
            var selectedGroupList = $filter('filter')($scope.GroupDetails, { GroupName: GroupName }, true);
            angular.forEach(selectedGroupList, function (tempItemModel) {
                tempItemModel.Checked = true; //set them all to false
            });
        }
        return resultText;
    }

    $scope.onGroupSearch = function () {
        goffset = 1;
        getAllGroupList();
    }

    $scope.PreviousPageButton_gClick = function () {
        $scope.SelAll.checked = false;
        //$scope.CurrentPageCursor = '';
        //if ($scope.PreviousPageCursorList && $scope.PreviousPageCursorList.length > 0)
        //    $scope.CurrentPageCursor = $scope.PreviousPageCursorList.pop();
        goffset -= 1;
        getAllGroupList()
    }

    $scope.NextPageButton_gClick = function () {
        $scope.SelAll.checked = false;
        //$scope.PreviousPageCursorList.push($scope.CurrentPageCursor);
        //$scope.CurrentPageCursor = $scope.NextPageCursor;
        goffset += 1;
        getAllGroupList()
    }

    $scope.AddSelectedGroup = function () {
        //var NewGroupsInUser = [];
        //var selectedGroupList = $filter('filter')($scope.GroupDetails, { Checked: true });
        //angular.forEach(selectedGroupList, function (tempItemModel) {

        //    var filterGroupList = $filter('filter')($scope.GroupInUserList, { GroupName: tempItemModel.GroupName }, true);
        //    if (typeof filterGroupList == 'undefined' || filterGroupList.length == 0) {
        //        NewGroupsInUser.push(tempItemModel);
        //    }
        //});
        //var promise = GroupService.AddGroupsToUser($scope.selectedLibrary, $scope.user.UserId, NewGroupsInUser);
        var promise = GroupService.AddUserGroup($scope.selectedLibrary, $scope.user.UserId, $scope.GroupCheckedFInal, $scope.GroupRemovedFInal);
        promise.then(function (response) {
            if (response.data.rows.length > 0) {
                if (response.data.rows[0].cell.length > 0) {

                    if (response.data.rows[0].cell[2] == 'Success') {
                        getUsers();
                        $scope.showValidation = false;
                        setTimeout(function () {
                            //$('#Add_Virtual_User').modal('hide');
                            $mdDialog.hide();
                            $scope.ShowWarning = false;
                        }, 1500);
                    }
                    else {
                        $scope.IsShowErrorMessage = true;
                    }
                    $scope.ShowWarning = true;
                    $scope.ErrorMessage = response.data.rows[0].cell[2];

                }

            }
            $scope.posting = false;

        }, function () {
        });
    }

    $scope.$on('$destroy', function () {
        $scope.PageEvents.Add = undefined;
        $scope.PageEvents.Edit = undefined;
        $scope.PageEvents.Save = undefined;
        $scope.PageEvents.Delete = undefined;
        $scope.PageEvents.CancelDialog = undefined;
        $scope.PageEvents.ShowSubclassList = undefined;
        $scope.PageEvents.AddRole = undefined;
        $scope.PageEvents.ResetPasswordclicked = undefined;
        $scope.PageEvents.ViewAssignUser = undefined;
        $scope.PageEvents.AssignUser = undefined;
        $scope.PageEvents.AssignGroup = undefined;
        $scope.PageEvents.LockAccount = undefined;
        $scope.PageEvents.UnlockAccount = undefined;
        $scope.PageEvents.ViewGeneralUser = undefined;
    });
    //$scope.FilterExternalClicked = function () {
    //    grequestModel.GroupIsExternal = !$scope.FilterExternal;
    //    getAllGroupList();
    //}


    function getSelectlGroupList() {
        grequestModel.libraryName = $scope.selectedLibrary;
     //   grequestModel.Cursor = $scope.CurrentPageCursor;
        grequestModel.pageLength = glimit;
        grequestModel.searchText = $scope.selectGroup.SearchText;
        grequestModel.pagenumber = sgoffset;
        

        if (!$scope.selectedLibrary || $scope.selectedLibrary.trim().length == 0) return;
        $scope.lastSelectedLibrary = $scope.selectedLibrary;
        var Group = GroupService.getGroups(grequestModel);

        Group.then(function (response) {
            $scope.appsVar.initialLoading = false;
            if (response) {
                if (response.data.Status) {
                    
                    $scope.isPrefferedsg_PrevDisable = sgoffset <= 1;
                    $scope.isPrefferedsg_NextDisable = sgoffset * limit >= response.data.total;
                    $scope.GroupDetails = response.data.rows[0].cell[0];
                     

                        angular.forEach($scope.SelectedgroupList, function (item) {
                            var result = $filter('filter')($scope.GroupDetails, { GroupName: item.GroupName });
                            if (result && result.length > 0) {
                                result[0].Checked = true;
                            }
                        });
                

                    //$scope.NextPageCursor = response.data.cursor;
                    //$scope.haveMoreRows = response.data.moreRowsFound;
                    //if ($scope.CurrentPageCursor == '')
                    //    $scope.isPrefferedsg_PrevDisable = true;
                    //else
                    //    $scope.isPrefferedsg_PrevDisable = false;
                    //$scope.isPrefferedsg_NextDisable = !response.data.moreRowsFound;
                    $scope.loading = false;

                    if ($scope.GroupCheckedFInal != null && $scope.GroupCheckedFInal.length > 0) {
                        angular.forEach($scope.GroupCheckedFInal, function (GroupCheckedModel) {
                            var filterGroupList = $filter('filter')($scope.GroupDetails, { GroupName: GroupCheckedModel.GroupName }, true);
                            if (typeof filterGroupList != 'undefined' && filterGroupList.length > 0) {
                                filterGroupList[0].Checked = true;
                            }
                        });
                    }
                    else {
                        if ($scope.GroupInUserList != null && $scope.GroupInUserList.length > 0) {
                            angular.forEach($scope.GroupInUserList, function (GroupCheckedModel) {
                                var filterGroupList = $filter('filter')($scope.GroupDetails, { GroupName: GroupCheckedModel.GroupName }, true);
                                if (typeof filterGroupList != 'undefined' && filterGroupList.length > 0) {
                                    filterGroupList[0].Checked = true;
                                }
                            });
                        }
                    }


                }
            }
            $scope.selectedApp.ResponseCount = $scope.GroupDetails.length;

        }, function () {
            alert('Data fetching failed.');
        });

    }
    $scope.SelectPrefferedDatabase = function () {
        $scope.fillDBinUserList();
        $('#popup-add-preferdDb').slideToggle();
    }
    $scope.ClosePrefferedDatabase = function () {


    }
    $scope.SelectGroups = function () {
        getSelectlGroupList();
        $('#popup-add-groups').slideToggle();
    }


    $scope.fillDBinUserList = function () {
        pdbrequestModel.libraryName = $scope.selectedLibrary;
        pdbrequestModel.searchText = $scope.PrefferedDB.SearchText;

        var promise = DatabaseService.getDatabase(pdbrequestModel);
        promise.then(function (response) {
            if (response.data.rows.length > 0 && response.data.rows[0].cell.length > 0) {
                $scope.DBList = response.data.rows[0].cell[0];
                $scope.isPrefferedDB_PrevDisable = Pdoffset <= 1;
                $scope.isPrefferedDB_NextDisable = Pdoffset * limit >= response.data.total;
                //if ($scope.CurrentPageCursor == '')
                //    $scope.isPrefferedDB_NextDisable = true;
                //else
                //    $scope.isPrefferedDB_PrevDisable = false;

            } else {
                $scope.DBList = [];
                $scope.isPrefferedDB_PrevDisable = true;
                $scope.isPrefferedDB_NextDisable = true;
            }
        }, function () {
            alert('Data fetching failed.');
            $scope.isPrefferedDB_PrevDisable = true;
            $scope.isPrefferedDB_NextDisable = true;
        });
    }
    $scope.SelectCurrentDB = function (DbModel, $event) {
        this.getAllSelectedDB(DbModel);
    };

    $scope.getAllSelectedDB = function (DbModel) {
        var selectedUserList = $filter('filter')($scope.DBList, { Selected: true });
        angular.forEach(selectedUserList, function (tempItemModel) {
            tempItemModel.Selected = false; //set them all to false
        });
        DbModel.Selected = true; //set the clicked one to true
        if (DbModel.Selected) {
            $scope.user.PreferredDatabase = DbModel.DatabaseName;

        }
    };
    $scope.AddDataDatabase = function () {
        $('#popup-add-preferdDb').slideToggle();
    }
    $scope.cancelGroupDialog = function () {
        $('#popup-add-groups').slideToggle();
        $scope.SelectedgroupList = [];
    }
    $scope.checkGroups = function (groupModal) {

        if (groupModal.Checked) {
            //if ($scope.groupInUserList.GroupName == groupModal.GroupName) {
            $scope.SelectedgroupList.push(groupModal);
            //}
        }
        else {
            $scope.SelectedgroupList.splice(groupModal);
        }
    }

   
    $scope.$watch(function () { return $scope.PrefferedDB.SearchText }, function (val) {
        if ($scope.PrefferedDB.SearchText.length > 0) {
            $scope.PrefferedDB.IsSearchTextFound = true;
        }
        if (PrefferedDBSearchTimeout) $timeout.cancel(PrefferedDBSearchTimeout);

        PrefferedDBSearchTimeout = $timeout(function () {
            if ($scope.PrefferedDB.IsSearchTextFound) {
                $scope.fillDBinUserList();
            }
        }, 2000);
    }, true);
    $scope.PreviousPageButton_PdbClick = function () {
        Pdoffset = Pdoffset - 1;
        $scope.fillDBinUserList();
    }

    $scope.NextPageButton_PdbClick = function () {
        Pdoffset = Pdoffset + 1;
        $scope.fillDBinUserList();
    }
    $scope.SearchPrefferedDB = function () {
        if (PrefferedDBSearchTimeout) $timeout.cancel(PrefferedDBSearchTimeout);
        Pdoffset = 1;
        $scope.fillDBinUserList();
    };

    $scope.cancelpreferdb = function () {
        $('#popup-add-preferdDb').slideToggle();
    }

    $scope.AddGroupToUser = function () {
        var ComaSep = '';
        angular.forEach($scope.SelectedgroupList, function (Item) {

            ComaSep = ComaSep + Item.GroupName + ","; //set them all to false
        });
        $scope.user.Groups = ComaSep.slice(0, -1);

        $('#popup-add-groups').slideToggle();

    }

    $scope.$watch(function () { return $scope.selectGroup.SearchText }, function (val) {
        if ($scope.selectGroup.SearchText.length > 0) {
            $scope.selectGroup.IsSearchTextFound = true;
        }
        if (SelectGroupSearchTimeout) $timeout.cancel(SelectGroupSearchTimeout);

        SelectGroupSearchTimeout = $timeout(function () {
            if ($scope.selectGroup.IsSearchTextFound) {
                getSelectlGroupList();
            }
        }, 2000);
    }, true);
    $scope.PreviousPageButton_PdbClick = function () {
        offset = offset - 1;
        getSelectlGroupList();
    }

    $scope.NextPageButton_PdbClick = function () {
        offset = offset + 1;
        $scope.fillDBinUserList();
    }
    $scope.SearchSelectGroups = function () {
        if (SelectGroupSearchTimeout) $timeout.cancel(SelectGroupSearchTimeout);
        offset = 1;
        $scope.fillDBinUserList();
    };
    $scope.PreviousPageButton_sgClick = function () {
        $scope.CurrentPageCursor = '';
        if ($scope.PreviousPageCursorList && $scope.PreviousPageCursorList.length > 0)
            $scope.CurrentPageCursor = $scope.PreviousPageCursorList.pop();
        getSelectlGroupList();

    }

    $scope.NextPageButton_sgClick = function () {
        $scope.PreviousPageCursorList.push($scope.CurrentPageCursor);
        $scope.CurrentPageCursor = $scope.NextPageCursor;
        getSelectlGroupList();
    }


    $scope.SelectAll = function () {
        angular.forEach($scope.GroupDetails, function (GroupModel) {

            var isDisabled = false;
            var filterGroupList = $filter('filter')($scope.GroupInUserList, { GroupName: GroupModel.GroupName }, true);
            if (typeof filterGroupList != 'undefined' && filterGroupList.length > 0) {
                isDisabled = true;
            }

          
            GroupModel.Checked = $scope.SelAll.checked;
         

            if (isDisabled) {

                if (GroupModel.Checked) {
                    $scope.GroupRemovedFInal = $.grep($scope.GroupRemovedFInal, function (item, index) {
                        return item.GroupName != GroupModel.GroupName;
                    });

                } else {
                    var filterUserListpush = $filter('filter')($scope.GroupRemovedFInal, { GroupName: GroupModel.GroupName }, true);
                    if (typeof filterUserListpush == 'undefined' || filterUserListpush.length == 0) {
                        $scope.GroupRemovedFInal.push(GroupModel);
                    }

                }

            }
            else {
                if (GroupModel.Checked) {
                    var filterUserListpush = $filter('filter')($scope.GroupCheckedFInal, { GroupName: GroupModel.GroupName }, true);
                    if (typeof filterUserListpush == 'undefined' || filterUserListpush.length == 0) {
                        $scope.GroupCheckedFInal.push(GroupModel);
                    }
                } else {

                    $scope.GroupCheckedFInal = $.grep($scope.GroupCheckedFInal, function (item, index) {
                        return item.GroupName != GroupModel.GroupName;
                    });



                }
            }

            
        });
    }

    $scope.ExternalChanged = function () {
        if ($scope.External) {
            var filterItem = { 'FilterKey': 'GroupIsExternal', 'FilterValues': ['Y'] };
            grequestModel.filters.push(filterItem);
        }
        else {
            angular.forEach(grequestModel.filters, function (reqModel) {
                if (reqModel.FilterKey == 'GroupIsExternal') {
                    grequestModel.filters.pop(reqModel);
                }
            });
        }
        getSelectlGroupList();
    }

    $scope.editViewUserContent = function () {
        $scope.validation.showMessage = true; 
        var promise = UserService.editUser($scope.user, $scope.selectedLibrary);
        //var promise = UserService.editUser($scope.user, $scope.selectedLibrary);
        promise.then(function (response) {
            if (response.data.rows.length > 0) {

                if (response.data.rows.length > 0) {
                    if (response.data.rows[0].cell.length > 0) {

                        if (response.data.rows[0].cell[2] == 'Success') {
                            getUsers();
                            $scope.showValidation = false;
                            setTimeout(function () {
                                $mdDialog.hide();
                                //ResetUserModel();
                                $scope.user = userFactory.userInitailValues();
                                $scope.validation = userFactory.validations();
                                $scope.ShowWarning = false;
                            }, 1500);
                        }
                        $scope.ShowWarning = true;
                        $scope.ErrorMessage = response.data.rows[0].cell[2];

                    }

                }
                $scope.posting = false;

            }
        }, function () {
        });
    }

    function getDatabaseByUser(userID, Password) {
        //$scope.SelectDataBase = $filter('filter')($scope.UserList, { Selected: true });
        var promise = UserService.getDBLibrariesByUser(userID);
        promise.then(function (response) {
            if (response.data.length > 0) {
                $scope.DBLibrariesByUser = response.data;
                $scope.user.PreferredDatabase = $scope.DBLibrariesByUser[0].DatabaseName;
                //$scope.selectedLibrary = $scope.DBLibrariesByUser[0].DatabaseName;
            }
        });
    }


};