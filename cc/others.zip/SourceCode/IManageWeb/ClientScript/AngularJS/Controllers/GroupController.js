﻿app.controller("GroupController", GroupController);
GroupController.$inject = ['$scope', '$rootScope', 'GroupService',   'groupFactory', '$filter', '$mdDialog', '$mdMedia',   '$timeout', 'homeFactory', 'UserService'];

function GroupController($scope, $rootScope, GroupService,   groupFactory, $filter, $mdDialog, $mdMedia, $timeout, homeFactory, UserService) {

    $scope.haveMoreRows = true;
    $scope.loading = true;
    $scope.showValidation = false;
    $scope.ShowWarning = false;
    $scope.ErrorMessage = '';
    $scope.SearchValue = null;
    $scope.appsVar.SearchText = '';
    $scope.lastSelectedLibrary = '';

    $scope.PreviousPageCursorList = [];
    $scope.CurrentPageCursor = '';
    $scope.CurrentUserPageCursor = '';
    $scope.NextPageCursor = '';
    $scope.PreviousPageCursor = '';
    $scope.CurrentViewUserPageCursor = '';

    //$scope.dtColumnDefs = datatableSettingsFactory.dtGroupTableColumns;
    //$scope.tableSettings = datatableSettingsFactory.tableSettings();
    $scope.GroupModel = groupFactory.groupInitialValues();    
  
    var userrequestModel = homeFactory.requestModelInstance();
    var requestModel = homeFactory.requestModelInstance();
    var gurequestModel = homeFactory.requestModelInstance();
    var guoffset = 1;
    var limit = 10;
    var offset = 1;
    var total = true;

    $scope.PageEvents.ViewAssignUser = 'undefined';
    $scope.PageEvents.AssignUser = 'undefined';
    $scope.PageEvents.Edit = 'undefined';
    $scope.PageEvents.Delete = 'undefined';
    $scope.UsersModel = {
        IsSearchTextFound: false,
        SearchText: '',
        ViewAssignUserSearchText: ''
    };

    $scope.SelAll = { checked: false };
    var UsersSearchTimeout;
    var ViewAssignUsersSearchTimeout;
    //getGroups();
    $scope.$on('InitializeTabContents', function () {
        getGroups();
    })

    //$scope.tableParams = new ngTableParams({
    //    noPager: true
    //}, {
    //    getData: function ($defer, params) {
    //        $defer.resolve($scope.UserList);
    //    }
    //});

    var ContextMenuVariables = {
        EnableDisable: {
            Label: 'Enable',
            Icon: 'img/icons/delete.svg',
            onClick: function () { }
        }
    }

    $scope.ContextMenuFunctions = {
        Edit: function () { GroupEditFunction(); },
        Delete: function () { GroupDeleteFunction(); },
        EnableGroup: function (event) {
            var selectedGroupList = $scope.selected;// = $filter('filter')($scope.GroupDetails, { selected: true });
            if (typeof selectedGroupList !== 'undefined' && selectedGroupList.length > 0) {

                var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
                var confirm = $mdDialog.confirm()
                    .title('Enable Groups')
                    .textContent('Are you sure to enable selected Group(s)?')
                    .ariaLabel('Enable Groups')
                    .targetEvent(event)
                    .ok('Proceed')
                    .cancel('Cancel');

                $mdDialog.show(confirm).then(function () {
                    var promise = GroupService.EnableDisableGroup($scope.vm.selectedLibrary, selectedGroupList, true);
                    promise.then(function (response) {
                        if (response.data.length > 0) {
                            getGroups();
                        }
                    }, function () {
                        //$scope.status = 'You decided to keep your debt.';
                    });
                });
            }
            else {
                $mdDialog.show(
                    $mdDialog.alert()
                        .parent(angular.element(document.body))
                        .clickOutsideToClose(true)
                        .title('Enable Groups')
                        .textContent('Select Group(s) to enable.')
                        .ariaLabel('Enable Groups')
                        .ok('OK')
                        .targetEvent(event)
                    );
            };
        },
        DisableGroup: function (event) {
            var selectedGroupList = $scope.selected;//= $filter('filter')($scope.GroupDetails, { selected: true });
            if (typeof selectedGroupList !== 'undefined' && selectedGroupList.length > 0) {

                var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
                var confirm = $mdDialog.confirm()
                    .title('Disable Groups')
                    .textContent('Are you sure to disable selected Group(s)?')
                    .ariaLabel('Disable Groups')
                    .targetEvent(event)
                    .ok('Proceed')
                    .cancel('Cancel');

                $mdDialog.show(confirm).then(function () {
                    var promise = GroupService.EnableDisableGroup($scope.vm.selectedLibrary, selectedGroupList, false);
                    promise.then(function (response) {
                        if (response.data.length > 0) {
                            getGroups();
                        }
                    }, function () {
                        //$scope.status = 'You decided to keep your debt.';
                    });
                });
            }
            else {
                $mdDialog.show(
                    $mdDialog.alert()
                        .parent(angular.element(document.body))
                        .clickOutsideToClose(true)
                        .title('Disable Groups')
                        .textContent('Select Group(s) to disable.')
                        .ariaLabel('Disable Groups')
                        .ok('OK')
                        .targetEvent(event)
                    );
            };
        },
        AssignToUser: function () { AssignUserFunction(); },
        ViewUsers: function () {
            ViewAssignUserFunction();
        },
        ViewDetails: function () {
            var selectedGroup = $scope.selected[0];//= $filter('filter')($scope.GroupDetails, { selected: true })[0];
            if (selectedGroup) {
                var promise = GroupService.getGroupDetails($scope.vm.selectedLibrary, selectedGroup.GroupName);
                promise.then(function (response) {
                    $scope.ViewModel = response.data.rows[0].cell[0][0];
                },
                    function () { });
                var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
                $mdDialog.show({
                    controller: DialogController,
                    scope: $scope,        // use parent scope in template
                    preserveScope: true,
                    templateUrl: 'Views/NgTemplates/ViewGroupDetails.html',
                    parent: angular.element(document.body),
                    clickOutsideToClose: true,
                    fullscreen: useFullScreen
                });
                $scope.$watch(function () {
                    return $mdMedia('xs') || $mdMedia('sm');
                }, function (wantsFullScreen) {
                    $scope.customFullscreen = (wantsFullScreen === true);
                });
            }
        },
        CopyGroup: function () {
            var selectedGroup = $scope.selected;//= $filter('filter')($scope.GroupDetails, { selected: true });
            if (selectedGroup && selectedGroup.length > 0) {
                $scope.CopyGroupModel.showDialog(selectedGroup[0].GroupName);
            }
        },
        ReassignGroupSecurity: function () {
            var selectedGroup = $scope.selected;//= $filter('filter')($scope.GroupDetails, { selected: true });
            if (selectedGroup && selectedGroup.length > 0) {
                $scope.ReassignGroupSecurityObject.showDialog(selectedGroup[0].GroupName);
            }
        }
    }

    function setContextMenuObject() {
        var selectedGroups = $scope.selected; //= $filter('filter')($scope.GroupDetails, { selected: true });
        if (selectedGroups !== undefined && selectedGroups.length > 0) {
            if (selectedGroups.length == 1) {
                if (selectedGroups[0].GroupEnabled) {
                    ContextMenuVariables.EnableDisable.Label = 'Disable';
                    ContextMenuVariables.EnableDisable.Icon = 'img/icons/highlight_off_blue.svg';
                    ContextMenuVariables.EnableDisable.onClick = $scope.ContextMenuFunctions.DisableGroup;
                    $scope.PageEvents.Enable = 'undefined';
                    $scope.PageEvents.Disable = $scope.ContextMenuFunctions.DisableGroup;
                } else {
                    ContextMenuVariables.EnableDisable.Label = 'Enable';
                    ContextMenuVariables.EnableDisable.Icon = 'img/icons/done_blue.svg';
                    ContextMenuVariables.EnableDisable.onClick = $scope.ContextMenuFunctions.EnableGroup;
                    $scope.PageEvents.Enable = $scope.ContextMenuFunctions.EnableGroup;
                    $scope.PageEvents.Disable = 'undefined';
                }
            } else {
                ContextMenuVariables.EnableDisable.Label = '';
                ContextMenuVariables.EnableDisable.onClick = 'undefined';
                $scope.PageEvents.Enable = 'undefined';
                $scope.PageEvents.Disable = 'undefined';
                var enabledGroupsInSelectedList = $filter('filter')(selectedGroups, { GroupEnabled: true });
                if (enabledGroupsInSelectedList.length == selectedGroups.length) {
                    ContextMenuVariables.EnableDisable.Label = 'Disable';
                    ContextMenuVariables.EnableDisable.Icon = 'img/icons/highlight_off_blue.svg';
                    ContextMenuVariables.EnableDisable.onClick = $scope.ContextMenuFunctions.DisableGroup;
                    $scope.PageEvents.Enable = 'undefined';
                    $scope.PageEvents.Disable = $scope.ContextMenuFunctions.DisableGroup;
                } else {
                    var disabledGroupsInSelectedList = $filter('filter')(selectedGroups, { GroupEnabled: false });
                    if (disabledGroupsInSelectedList.length == selectedGroups.length) {
                        ContextMenuVariables.EnableDisable.Label = 'Enable';
                        ContextMenuVariables.EnableDisable.Icon = 'img/icons/done_blue.svg';
                        ContextMenuVariables.EnableDisable.onClick = $scope.ContextMenuFunctions.EnableGroup;
                        $scope.PageEvents.Enable = $scope.ContextMenuFunctions.EnableGroup;
                        $scope.PageEvents.Disable = 'undefined';
                    }
                }
            }
        } else {
            ContextMenuVariables.EnableDisable.Label = '';
            ContextMenuVariables.EnableDisable.onClick = 'undefined';
            $scope.PageEvents.Enable = 'undefined';
            $scope.PageEvents.Disable = 'undefined';
        }
        $scope.menuList = [
        {
            Label: 'Edit',
            Icon: 'img/icons/edit.svg',
            onClick: $scope.ContextMenuFunctions.Edit,
            Enable:$scope.selected.length==1
        },
        {
            Label: 'Delete',
            Icon: 'img/icons/delete.svg',
            onClick: $scope.ContextMenuFunctions.Delete,
            Enable: $scope.selected.length == 1
        },
        {
            Label: 'Seperator'
        },
        {
            Label: ContextMenuVariables.EnableDisable.Label,
            Icon: ContextMenuVariables.EnableDisable.Icon,
            onClick: ContextMenuVariables.EnableDisable.Label == '' ? 'undefined' : ContextMenuVariables.EnableDisable.onClick,
            Enable:$scope.selected.length>0
        },
        {
            Label: 'Clone',
            Icon: 'icons/view_copy.svg',
            onClick: $scope.ContextMenuFunctions.CopyGroup,
            Enable: $scope.selected.length == 1
        },
         {
             Label: 'Add/Remove Members',
             Icon: 'img/icons/user_blue.svg',
             onClick: $scope.ContextMenuFunctions.AssignToUser,
             Enable: $scope.selected.length == 1
         },
         {
             Label: 'View Details',
             Icon: 'img/icons/description_blue.svg',
             onClick: $scope.ContextMenuFunctions.ViewDetails,
             Enable: $scope.selected.length == 1
         },
         {
             Label: 'View Members',
             Icon: 'img/icons/view_blue.svg',
             onClick: $scope.ContextMenuFunctions.ViewUsers,
             Enable: $scope.selected.length == 1
         },
         {
             Label: 'Reassign GroupSecurity',
             Icon: 'img/icons/view_blue.svg',
             onClick: $scope.ContextMenuFunctions.ReassignGroupSecurity,
             Enable: $scope.selected.length == 1
         }
        ];
    }

   

    

    //$scope.$on('InitializeTabContents', function () {
    //    Initalize();
    //})

    $scope.loadMoreOnScrollEnd = function () {
        if ($scope.haveMoreRows) {
            getGroups();
            $scope.ScrollCounter = false;
        }
    };

    function Initalize() {
        $scope.loading = true;
        $scope.GroupDetails = [];
        $scope.haveMoreRows = true;
        $scope.PreviousPageCursorList = [];
        //$scope.CurrentPageCursor = '';
        $scope.NextPageCursor = '';
        $scope.PreviousPageCursor = '';
        requestModel.pagenumber = 1;
        $scope.query.page = 1;
        $scope.query.totalCount = 0;
        
        getGroups();
    }

    //$scope.PreviousPageButton_Click = function () {
    //    //$scope.CurrentPageCursor = '';
    //    //if ($scope.PreviousPageCursorList && $scope.PreviousPageCursorList.length > 0)
    //    //    $scope.CurrentPageCursor = $scope.PreviousPageCursorList.pop();
    //    offset -= 1;

    //    getGroups();
    //}

    //$scope.NextPageButton_Click = function () {
    //    //$scope.PreviousPageCursorList.push($scope.CurrentPageCursor);
    //    //$scope.CurrentPageCursor = $scope.NextPageCursor;
    //    offset += 1;
    //    getGroups();
    //}

    $scope.$on('onTableSorting', function (object, sortFiled) {
        getGroups();
    });

    $scope.$on('onClearAllClicked', function () {
        requestModel.filters = [];
        getGroups();
    })

    function getGroups() {
        $scope.selected = [];
        if (!$scope.vm.selectedLibrary || $scope.vm.selectedLibrary.trim().length == 0) return;
        requestModel.libraryName = $scope.vm.selectedLibrary;
        requestModel.isTotal = total;        
        requestModel.searchText = $scope.appsVar.SearchText;
        var Group = GroupService.getGroups(requestModel);
        Group.then(function (response) {
            $scope.appsVar.initialLoading = false;
            if (response) {
                if (response.data.Status) {
                    //$scope.isPrevDisable = offset <= 1;
                    //$scope.isNextDisable = offset * limit >= 
                    $scope.query.totalCount = response.data.total;
                    $scope.GroupDetails = response.data.rows[0].cell[0];
                    
                    //$scope.loading = false;
                    $timeout(function () {
                        $('td').filter(function () {
                            if (!$(this).hasClass("md-checkbox-cell")) {
                                if ($(this).text().trim().length == 0) {

                                    $(this).html('&nbsp;');
                                }
                            }

                        });
                    });
                }
            }
            $scope.vm.selectedApp.ResponseCount = $scope.GroupDetails.length;
           
        }, function () {
            alert('Data fetching failed.');
        });
    }

    $scope.select = function (item, $event) {
        if ($event.ctrlKey) {
            item.selected ? item.selected = false : item.selected = true;
            $scope.PageEvents.ViewAssignUser = 'undefined';
            $scope.PageEvents.AssignUser = 'undefined';
            $scope.PageEvents.Edit = 'undefined';
            $scope.PageEvents.Delete = 'undefined';
        }
        else {
            this.getAllSelectedRows(item);
            $scope.PageEvents.ViewAssignUser = ViewAssignUserFunction;
            $scope.PageEvents.AssignUser = AssignUserFunction;
            $scope.PageEvents.Edit = GroupEditFunction;
            $scope.PageEvents.Delete = GroupDeleteFunction;
        }
        setContextMenuObject();
       
    };

    $scope.getAllSelectedRows = function (item) {
        angular.forEach($scope.GroupDetails, function (p) {
            p.selected = false; //set them all to false
        });
        item.selected = true; //set the clicked one to true
    };

    

    $scope.addGroup = function () {
        $scope.showValidation = true;
        $scope.posting = false;
        $scope.ShowWarning = false;

        if ($scope.GroupModel.GroupName == '') {
            $scope.posting = false;
            return;
        }
        $scope.posting = true;
        $scope.lastSelectedLibrary = $scope.vm.selectedLibrary;
        var addGroup = GroupService.addGroups($scope.vm.selectedLibrary, $scope.GroupModel);
        addGroup.then(function (response) {
            if (response && response.data && response.data.Status) {
                $scope.showValidation = false;
                $mdDialog.hide();
                $scope.GroupModel = groupFactory.groupInitialValues();
                getGroups();
            }
            else {
                $scope.ErrorMessage = response.data.Message;
                $scope.ShowWarning = true;
            }
            $scope.posting = false;
        }, function () {
            $scope.posting = false;
        });
    }

    $scope.$on('Search_Click', function (event, args) {
        Initalize();
    });

    $scope.$on('Refresh_Click', function (event, args) {
        Initalize();
    });

    $scope.singleDeleteClick = function () {
        var s = $scope.appsVar.selectedRecordId;
        var getGroup = GroupService.DeleteGroup(s);

        getGroup.then(function (response) {
            if (response.data == "success") {
                $scope.appsVar.selectedRecordId = '';
                $scope.haveMoreRows = true;
                $scope.lastSelectedLibrary = '';
                getGroups();
                $scope.showAlertMessage("Selected group(s) deleted successfully.");
            } else {
                $scope.showAlertMessage('Failed to delete selected group(s).');
            }
        }, function () {
            $scope.showAlertMessage('Failed to delete selected group(s).');
        });

    };

    $rootScope.$on('onGroupValidateBulkDeleteClick', function () {
        $scope.ValidateGroups = [];
        GroupValidateBulkDeleteClick();
    })

    function GroupValidateBulkDeleteClick() {
        $scope.ValidateGroups = $scope.selected;////= $filter('filter')($scope.GroupDetails, { selected: true });
        if (typeof $scope.ValidateGroups !== 'undefined' && $scope.ValidateGroups.length > 0) {
            $scope.showConfirmMessage('Are you sure to delete selected group(s)?');
            return true;
        }
        else {
            $scope.showAlertMessage('Select group(s) to delete.');
            return false;
        }
    }

    $rootScope.$on('onGroupBulkDeleteClick', function () {
        $scope.Groups = [];
        GroupBulkDeleteClick();
    })

    function GroupBulkDeleteClick() {
        $scope.Groups = $scope.selected;// // = $filter('filter')($scope.GroupDetails, { selected: true });
        var getGroup = GroupService.DeleteGroup($scope.Groups);

        getGroup.then(function (response) {
            if (response.data == "success") {
                $scope.appsVar.selectedRecordId = '';
                $scope.haveMoreRows = true;
                $scope.lastSelectedLibrary = '';
                getGroups();
                $scope.showAlertMessage("Selected group(s) deleted successfully.");
            } else {
                $scope.showAlertMessage('Failed to delete selected group(s).');
            }
        }, function () {
            $scope.showAlertMessage('Failed to delete selected group(s).');
        });

    }

    $scope.singleGroupDeleteConfirmMessageClick = function () {
        $scope.showSingleGroupDeleteConfirmMessage('Are you sure to delete ' + $scope.appsVar.selectedRecordId + '?');
    };

    $scope.showSingleGroupDeleteConfirmMessage = function (message) {
        $("#singlegroupconfirm_popup").find('#singlegroupconfirmMsgText').text(message);
        $("#singlegroupconfirm_popup").modal();
    }

    $scope.validation = {
        showMessage: false
    }

    $scope.EditGroup = function () {
        $scope.posting = true;
        $scope.validation.showMessage = true;
        $scope.ShowWarning = false;

        var UpdateData = GroupService.EditGroup($scope.vm.selectedLibrary, $scope.GroupModel);
        UpdateData.then(function (response) {
            if (response && response.data && response.data.Status) {
                $scope.showValidation = false;
                $mdDialog.hide();
                $scope.GroupModel = groupFactory.groupInitialValues();
                getGroups();
            }
            else {
                $scope.ErrorMessage = response.data.Message;
                $scope.ShowWarning = true;
            }
            $scope.posting = false;
        }, function () {
            $scope.posting = false;
            alert('Error in updating record');
        });
    };

    $scope.PageEvents.Add = function (event) {
        $scope.posting = false;
        $scope.PageEvents.UserAction = 'Add';
        $scope.GroupModel = groupFactory.groupInitialValues();
        $scope.ShowWarning = false;
        $scope.validation.showMessage = false;
        var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
        $mdDialog.show({
            // controller: UserController,
            controller: DialogController,
            scope: $scope,        // use parent scope in template
            preserveScope: true,  // do not forget this if use parent scope
            templateUrl: 'Views/NgTemplates/AddGroup.html',
            parent: angular.element(document.body),
            targetEvent: event,
            clickOutsideToClose: true,
            fullscreen: useFullScreen
        })
        .then(function (answer) {
            $scope.status = 'You said the information was "' + answer + '".';
        }, function () {
            $scope.status = 'You cancelled the dialog.';
        });
        $scope.$watch(function () {
            return $mdMedia('xs') || $mdMedia('sm');
        }, function (wantsFullScreen) {
            $scope.customFullscreen = (wantsFullScreen === true);
        });
    };

    var GroupEditFunction = function (row) {
        $scope.ShowWarning = false;
        $scope.posting = false;
        $scope.PageEvents.UserAction = 'Edit';
        $scope.ValidateGroups = $scope.selected; //$filter('filter')($scope.GroupDetails, { selected: true });
        if (row) {
            var groupID = $scope.appsVar.selectedRecordId;
            $scope.ValidateGroups = $scope.selected;////= $scope.selected;//= $filter('filter')($scope.GroupDetails, { GroupName: groupID });
        }
        if (typeof $scope.ValidateGroups !== 'undefined' && $scope.ValidateGroups.length > 0) {
            angular.copy($scope.ValidateGroups[0], $scope.GroupModel);
            var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
            $mdDialog.show({
                controller: DialogController,
                scope: $scope,        // use parent scope in template
                preserveScope: true,
                templateUrl: 'Views/NgTemplates/EditGroup.html',
                parent: angular.element(document.body),
                clickOutsideToClose: true,
                fullscreen: useFullScreen
            })
            .then(function (answer) {
                $scope.status = 'You said the information was "' + answer + '".';
            }, function () {
                $scope.status = 'You cancelled the dialog.';
            });
            $scope.$watch(function () {
                return $mdMedia('xs') || $mdMedia('sm');
            }, function (wantsFullScreen) {
                $scope.customFullscreen = (wantsFullScreen === true);
            });
            return true;
        }
        else {
            $scope.showAlertMessage('Select group to edit.');
            return false;
        }
    }

    $scope.PageEvents.BindLabel = function (data) {
        if ($scope.PageEvents.UserAction == 'Add') {
            return 'Add'
        } else {
            return 'Save';
        }
    }

    $scope.PageEvents.Save = function () {
        if ($scope.PageEvents.UserAction == 'Add') {
            return $scope.addGroup();
        } else {
            return $scope.EditGroup();
        }
    }

    var GroupDeleteFunction = function () {
        var selectedGroupList = $scope.selected;// = $filter('filter')($scope.GroupDetails, { selected: true });
        if (typeof selectedGroupList !== 'undefined' && selectedGroupList.length > 0) {

            var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
            var confirm = $mdDialog.confirm()
                .title('Delete Groups')
                .textContent('Are you sure to delete selected Group(s)?')
                .ariaLabel('Delete Groups')
                .ok('Proceed')
                .cancel('Cancel');

            $mdDialog.show(confirm).then(function () {

                $mdDialog.show(
                $mdDialog.alert()
                    .parent(angular.element(document.body))
                    .clickOutsideToClose(true)
                    .title('Delete Groups')
                    .textContent('You are deleting the selected Group(s).')
                    .ariaLabel('Delete Groups')
                    .ok('OK')
                ).then(function () {
                    var groupIdList = [];

                    angular.forEach(selectedGroupList, function (groupItemModel) {
                        groupIdList.push(groupItemModel.GroupName);
                    });

                    var promise = GroupService.DeleteGroup($scope.vm.selectedLibrary, groupIdList);
                    promise.then(function (response) {
                        if (response.data.length > 0) {
                            getGroups();
                        }
                    }, function () {
                        //$scope.status = 'You decided to keep your debt.';
                    });
                });
            });
        }
        else {
            $mdDialog.show(
                $mdDialog.alert()
                    .parent(angular.element(document.body))
                    .clickOutsideToClose(true)
                    .title('Delete Groups')
                    .textContent('Select Group(s) to delete.')
                    .ariaLabel('Delete Groups')
                    .ok('OK')
                );
        };
    }

    $scope.PageEvents.CancelDialog = function () {
        $scope.GroupModel = groupFactory.groupInitialValues();
        $scope.showValidation = false;
        $scope.ShowWarning = false;
        $('#virtual_group').modal('hide');
    }



    function DialogController($scope, $mdDialog) {
        $scope.hide = function () {
            $mdDialog.hide();
        };
        $scope.cancel = function () {
            $mdDialog.cancel();
        };
        $scope.answer = function () {
            $mdDialog.hide();
        };
    }

    $scope.$on('onTableFiltering', function (event, value, key) {


        if (requestModel.filters.length > 0) {
            requestModel.filters = jQuery.grep(requestModel.filters, function (filterItem) {
                return filterItem.FilterKey !== key;
            });
        }
        //  if (value.length == 0) return;

        var filterValueList = [];
        filterValueList[0] = value;

        var filterItem = { 'FilterKey': key, 'FilterValues': filterValueList };
        requestModel.filters.push(filterItem);
        offset = 1;
        requestModel.pagenumber = 1;
        $scope.query.page = 1;
        $scope.query.totalCount = 0;
        getGroups();
    });

    $scope.$on('$destroy', function () {
        $scope.PageEvents.Add = 'undefined';
        $scope.PageEvents.Edit = 'undefined';
        $scope.PageEvents.Save = 'undefined';
        $scope.PageEvents.Delete = 'undefined';
        $scope.PageEvents.CancelDialog = 'undefined';
        $scope.PageEvents.ShowSubclassList = 'undefined';
        $scope.PageEvents.AddRole = 'undefined';
        $scope.PageEvents.ResetPasswordclicked = 'undefined';
        $scope.PageEvents.Enable = 'undefined';
        $scope.PageEvents.Disable = 'undefined';
        $scope.PageEvents.ViewAssignUser = 'undefined';
        $scope.PageEvents.AssignUser = 'undefined';
        $scope.PageEvents.AssignGroup = 'undefined';
    });

    $scope.$on('onsubTableFiltering', function (event, value, key) {
        if (gurequestModel.filters.length > 0) {
            gurequestModel.filters = jQuery.grep(gurequestModel.filters, function (filterItem) {
                return filterItem.FilterKey !== key;
            });
        }
        //if (value.length == 0) return;

        var filterValueList = [];
        filterValueList[0] = value;

        var filterItem = { 'FilterKey': key, 'FilterValues': filterValueList };
        gurequestModel.filters.push(filterItem);
        //guoffset = 1;
        getAllUserList();
        //getMetaDataSubList($scope.selectedLibrary, 1, 10, true, subSerach, $scope.selectedApp.MetaDataItem, $scope.ValidateSubButtonMetaData[0].Alias);
    })

    //$scope.UserSearchText = '';
    $scope.UsersModel.SearchText = '';
    function getAllUserList() {
        //var userrolelimit = 10;
        if ($scope.vm.selectedApp.NoAppsPermission.trim().length > 0) return;
        if (!$scope.vm.selectedLibrary || $scope.vm.selectedLibrary.trim().length == 0) return;

        $scope.UserInGroupList = [];
        gurequestModel.libraryName = $scope.vm.selectedLibrary;
        gurequestModel.isTotal = total;
        gurequestModel.searchText = $scope.UsersModel.SearchText;
        var promise = UserService.getUsers(gurequestModel, false)
        promise.then(function (response) {

            if (response.data.rows.length > 0 && response.data.rows[0].cell.length > 0) {
                //$scope.isguPrevDisable = guoffset <= 1;
                //$scope.isguNextDisable = guoffset * userrolelimit >= response.data.total;

                $scope.UserTablePagination.totalCount = response.data.total;
                    

                $scope.UserList = response.data.rows[0].cell[0];
                var userschecklist = [];
                angular.forEach($scope.UserList, function (item) {
                    userschecklist.push(item.UserId);
                });
                var promiseOne = UserService.GetAllSelectedUsersFromTheList($scope.vm.selectedLibrary, $scope.GroupModel.GroupName, userschecklist)
                promiseOne.then(function (responseuser) {
                    $scope.UserInGroupList = responseuser.data.rows[0].cell[0];
                    if ($scope.UserCheckedFInal != null && $scope.UserCheckedFInal.length > 0) {
                        angular.forEach($scope.UserCheckedFInal, function (userCheckedModel) {
                            var filterUserList = $filter('filter')($scope.UserList, { UserId: userCheckedModel.UserId }, true);
                            if (typeof filterUserList != 'undefined' && filterUserList.length > 0) {
                                filterUserList[0].Checked = true;
                            }
                        });
                    }
                    if ($scope.UserInGroupList != null && $scope.UserInGroupList.length > 0) {
                        angular.forEach($scope.UserInGroupList, function (userCheckedModel) {
                            var filterUserList = $filter('filter')($scope.UserList, { UserId: userCheckedModel.UserId }, true);
                            if (typeof filterUserList != 'undefined' && filterUserList.length > 0) {
                                filterUserList[0].Checked = true;
                            }
                        });
                    }

                    if ($scope.UserRemovedFInal != null && $scope.UserRemovedFInal.length > 0) {
                        angular.forEach($scope.UserRemovedFInal, function (userRemovedModel) {
                            var filterUserList = $filter('filter')($scope.UserList, { UserId: userRemovedModel.UserId }, true);
                            if (typeof filterUserList != 'undefined' && filterUserList.length > 0) {
                                filterUserList[0].Checked = false;
                            }
                        });
                    }

                    if ($scope.CheckedUserSelection) {//IsExternalUser UserTablePagination
                        var UserCheckedList = [];
                        var start = (gurequestModel.pagenumber - 1) * gurequestModel.pageLength;
                        for (i = start; i < (gurequestModel.pageLength * gurequestModel.pagenumber) ; i++) {
                                if ($scope.UserCheckedFInal[i] != undefined)
                                    UserCheckedList.push($scope.UserCheckedFInal[i]);
                            }
                            $scope.UserList = UserCheckedList;
                            $scope.UserTablePagination.totalCount = $scope.UserCheckedFInal.length;
                    }



                }, function () {
                    alert('Data fetching failed.');
                });
            }
        }, function () {
            alert('Data fetching failed.');
        });
    }


    function getAllUsersInGroup() {
        if (!$scope.vm.selectedLibrary || $scope.vm.selectedLibrary.trim().length == 0) return;
        $scope.lastSelectedLibrary = $scope.vm.selectedLibrary;


        userrequestModel.libraryName = $scope.vm.selectedLibrary;
        userrequestModel.Cursor = $scope.CurrentViewUserPageCursor;
        userrequestModel.pageLength = limit;
        userrequestModel.searchText = $scope.appsVar.SearchText;
        $scope.isViewUserPrevDisable = true;

        var promise = UserService.getAllUsersInGroup(userrequestModel, $scope.GroupModel.GroupName)
        promise.then(function (response) {
            if (response.data.rows.length > 0 && response.data.rows[0].cell.length > 0) {
                $scope.UserInGroupList = response.data.rows[0].cell[0];
                //$scope.CurrentUserPageCursor = response.data.cursor;
                $scope.NextPageCursor = response.data.cursor;
                //$scope.isViewUserNextDisable = response.data.moreRowsFound;
                if ($scope.CurrentViewUserPageCursor == '')
                    $scope.isViewUserPrevDisable = true;
                else
                    $scope.isViewUserPrevDisable = false;
                $scope.isViewUserNextDisable = !response.data.moreRowsFound;
            }

        }, function () {
            alert('Data fetching failed.');
        });

    }

    $scope.PreviousPageButton_ViewUserClick = function () {
        $scope.CurrentViewUserPageCursor = '';
        if ($scope.PreviousPageCursorList && $scope.PreviousPageCursorList.length > 0)
            $scope.CurrentViewUserPageCursor = $scope.PreviousPageCursorList.pop();
        //goffset -= 1;
        getAllUsersInGroup()
    }

    $scope.NextPageButton_ViewUserClick = function () {
        $scope.PreviousPageCursorList.push($scope.CurrentViewUserPageCursor);
        $scope.CurrentViewUserPageCursor = $scope.NextPageCursor;
        getAllUsersInGroup()
    }

    var ViewAssignUserFunction = function () {
        $scope.IsShowErrorMessage = false;
        $scope.UserCheckedFInal = [];
        $scope.CurrentViewUserPageCursor = '';
        $scope.UserInGroupList = [];
        //getAllUserList();
        $scope.ValidateAddRemoveUsers = $scope.selected;// = $filter('filter')($scope.GroupDetails, { selected: true });
        if (typeof $scope.ValidateAddRemoveUsers != 'undefined' && $scope.ValidateAddRemoveUsers.length > 0) {
            angular.copy($scope.ValidateAddRemoveUsers[0], $scope.GroupModel);
            setTimeout(function () {
                getAllUsersInGroup();
                $scope.UserCheckedFInal = [];
            }, 100);
            var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
            $mdDialog.show({
                controller: DialogController,
                scope: $scope,        // use parent scope in template
                preserveScope: true,
                templateUrl: 'Views/NgTemplates/ViewAssignUser.html',
                parent: angular.element(document.body),
                clickOutsideToClose: true,
                fullscreen: useFullScreen
            })
            .then(function (answer) {
                $scope.status = 'You said the information was "' + answer + '".';
            }, function () {
                $scope.status = 'You cancelled the dialog.';
            });
            $scope.$watch(function () {
                return $mdMedia('xs') || $mdMedia('sm');
            }, function (wantsFullScreen) {
                $scope.customFullscreen = (wantsFullScreen === true);
            });
            return true;
        }
        else {
            $scope.showAlertMessage('Select a Group first.');
            return false;
        }
    }

    var AssignUserFunction = function () {
        $scope.IsShowErrorMessage = false;
        $scope.UserCheckedFInal = [];
        $scope.UsersModel.SearchText = '';
        guoffset = 1;
        $scope.UserList = [];
        $scope.UserTablePagination = {
            order: 'UserID',
            limit: gurequestModel.pageLength,
            page: gurequestModel.pagenumber,
            totalCount: 0
        };
        getAllUserList();
        $scope.ValidateAddRemoveUsers = $scope.selected;//= $filter('filter')($scope.GroupDetails, { selected: true });
        if (typeof $scope.ValidateAddRemoveUsers != 'undefined' && $scope.ValidateAddRemoveUsers.length > 0) {
            angular.copy($scope.ValidateAddRemoveUsers[0], $scope.GroupModel);

            var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
            $mdDialog.show({
                controller: DialogController,
                scope: $scope,        // use parent scope in template
                preserveScope: true,
                templateUrl: 'Views/NgTemplates/AddRemoveUsers.html',
                parent: angular.element(document.body),
                clickOutsideToClose: true,
                fullscreen: useFullScreen
            })
            .then(function (answer) {
                $scope.status = 'You said the information was "' + answer + '".';
            }, function () {
                $scope.status = 'You cancelled the dialog.';
            });
            $scope.$watch(function () {
                return $mdMedia('xs') || $mdMedia('sm');
            }, function (wantsFullScreen) {
                $scope.customFullscreen = (wantsFullScreen === true);
            });
            return true;
        }
        else {
            $scope.showAlertMessage('Select a Group first.');
            return false;
        }
    }

    $scope.SelectCurrentUser = function (user, $event) {
        $scope.UserSelected(user, $event)
        if ($event.ctrlKey) {
            user.Selected ? user.Selected = false : user.Selected = true;
        }
        else {
            this.getAllSelectedUsers(user);
        }
    };

    $scope.getAllSelectedUsers = function (user) {
        var selectedUserList = $filter('filter')($scope.UserList, { Selected: true });
        angular.forEach(selectedUserList, function (tempItemModel) {
            tempItemModel.Selected = false; //set them all to false
        });
        user.Selected = true; //set the clicked one to true
    };

    $scope.UserCheckedFInal = [];
    $scope.UserRemovedFInal = [];
    $scope.UserSelected = function (user, $event) {
        var isDisabled = false;
        var filterUserList = $filter('filter')($scope.UserInGroupList, { UserId: user.UserId }, true);
        if (typeof filterUserList != 'undefined' && filterUserList.length > 0) {
            isDisabled = true;
        }
        if ($event.ctrlKey) {
            user.Checked ? user.Checked = false : user.Checked = true;
        }
        else {
            this.getAllCheckedUsers(user);
        }
        if (isDisabled) {

            if (user.Checked) {
                $scope.UserRemovedFInal = $.grep($scope.UserRemovedFInal, function (item, index) {
                    return item.UserId != user.UserId;
                });

            } else {
                var filterUserListpush = $filter('filter')($scope.UserRemovedFInal, { UserId: user.UserId }, true);
                if (typeof filterUserListpush == 'undefined' || filterUserListpush.length == 0) {
                    $scope.UserRemovedFInal.push(user);
                }


            }

        }
        else {


            if (user.Checked) {
                var filterUserListpush = $filter('filter')($scope.UserCheckedFInal, { UserId: user.UserId }, true);
                if (typeof filterUserListpush == 'undefined' || filterUserListpush.length == 0) {
                    $scope.UserCheckedFInal.push(user);
                }
            } else {

                $scope.UserCheckedFInal = $.grep($scope.UserCheckedFInal, function (item, index) {
                    return item.UserId != user.UserId;
                });



            }
        }
    };

    $scope.getAllCheckedUsers = function (user) {
        user.Checked = !user.Checked; //set the clicked one to true
    };

    $scope.isAlreadyAvilable = function (UserId) {
        var resultText = false;
        var filterUserList = $filter('filter')($scope.UserInGroupList, { UserId: UserId }, true);
        if (typeof filterUserList != 'undefined' && filterUserList.length > 0) {
            resultText = true;
            var selectedUserList = $filter('filter')($scope.UserList, { UserId: UserId }, true);
            angular.forEach(selectedUserList, function (tempItemModel) {
                tempItemModel.Checked = true; //set them all to false
            });
        }
        return resultText;
    }

    $scope.onUserSearch = function () {
        goffset = 1;
        getAllUserList();
    }

    $scope.onViewUserSearch = function () {
        if (!$scope.vm.selectedLibrary || $scope.vm.selectedLibrary.trim().length == 0) return;
        $scope.lastSelectedLibrary = $scope.vm.selectedLibrary;


        userrequestModel.libraryName = $scope.vm.selectedLibrary;
        userrequestModel.Cursor = $scope.CurrentViewUserPageCursor;
        userrequestModel.pageLength = limit;
        userrequestModel.searchText = $scope.UsersModel.ViewAssignUserSearchText;
        $scope.isViewUserPrevDisable = true;

        var promise = UserService.getAllUsersInGroup(userrequestModel, $scope.GroupModel.GroupName)
        promise.then(function (response) {
            if (response.data.rows.length > 0 && response.data.rows[0].cell.length > 0) {
                $scope.UserInGroupList = response.data.rows[0].cell[0];
                //$scope.CurrentUserPageCursor = response.data.cursor;
                $scope.NextPageCursor = response.data.cursor;
                //$scope.isViewUserNextDisable = response.data.moreRowsFound;
                if ($scope.CurrentViewUserPageCursor == '')
                    $scope.isViewUserPrevDisable = true;
                else
                    $scope.isViewUserPrevDisable = false;
                $scope.isViewUserNextDisable = !response.data.moreRowsFound;
            }

        }, function () {
            alert('Data fetching failed.');
        });
        //var promise = UserService.getAllUsersInGroup($scope.selectedLibrary, $scope.GroupModel.GroupName)
        //promise.then(function (response) {
        //    if (response.data.rows.length > 0 && response.data.rows[0].cell.length > 0) {
        //        $scope.UserInGroupList = response.data.rows[0].cell[0];
        //    }

        //}, function () {
        //    alert('Data fetching failed.');
        //});
    }

    $scope.PreviousPageButton_guClick = function () {
        $scope.SelAll.checked = false;
        guoffset -= 1;
        getAllUserList()
    }

    $scope.NextPageButton_guClick = function () {
        $scope.SelAll.checked = false;
        guoffset += 1;
        getAllUserList()
    }

    $scope.AddSelectedUser = function () {
        var promise = UserService.AddGroupUser($scope.vm.selectedLibrary, $scope.GroupModel.GroupName, $scope.UserCheckedFInal, $scope.UserRemovedFInal);
        promise.then(function (response) {
            //if (response.data!='') {
            if (response.data.rows.length > 0) {
                if (response.data.rows[0].cell.length > 0) {

                    if (response.data.rows[0].cell[2] == 'Success') {
                        getUsers();
                        $scope.showValidation = false;
                        setTimeout(function () {
                            //$('#Add_Virtual_User').modal('hide');
                            $mdDialog.hide();
                            $scope.ShowWarning = false;
                        }, 1500);
                    }
                    else {
                        $scope.IsShowErrorMessage = true;
                    }
                    $scope.ShowWarning = true;
                    $scope.ErrorMessage = response.data.rows[0].cell[2];

                }

            }
            //}
            //else {
            //    $scope.IsShowErrorMessage = true;
            //}
            $scope.posting = false;

        }, function () {
        });
    }



    $scope.$watch(function () { return $scope.UsersModel.SearchText }, function (val) {
        if ($scope.UsersModel.SearchText.length > 0) {
            $scope.UsersModel.IsSearchTextFound = true;
        }
        if (UsersSearchTimeout) $timeout.cancel(UsersSearchTimeout);

        UsersSearchTimeout = $timeout(function () {
            if ($scope.UsersModel.IsSearchTextFound) {
                getAllUserList();
            }
        }, 2000);
    }, true);

    $scope.SelectAll = function () {
        angular.forEach($scope.UserList, function (userModel) {

            var isDisabled = false;
            var filterUserList = $filter('filter')($scope.UserInGroupList, { UserId: userModel.UserId }, true);
            if (typeof filterUserList != 'undefined' && filterUserList.length > 0) {
                isDisabled = true;
            }


            userModel.Checked = $scope.SelAll.checked;


            if (isDisabled) {

                if (userModel.Checked) {
                    $scope.UserRemovedFInal = $.grep($scope.UserRemovedFInal, function (item, index) {
                        return item.UserId != userModel.UserId;
                    });

                } else {
                    var filterUserListpush = $filter('filter')($scope.UserRemovedFInal, { UserId: userModel.UserId }, true);
                    if (typeof filterUserListpush == 'undefined' || filterUserListpush.length == 0) {
                        $scope.UserRemovedFInal.push(userModel);
                    }


                }

            }
            else {


                if (userModel.Checked) {
                    var filterUserListpush = $filter('filter')($scope.UserCheckedFInal, { UserId: userModel.UserId }, true);
                    if (typeof filterUserListpush == 'undefined' || filterUserListpush.length == 0) {
                        $scope.UserCheckedFInal.push(userModel);
                    }
                } else {

                    $scope.UserCheckedFInal = $.grep($scope.UserCheckedFInal, function (item, index) {
                        return item.UserId != userModel.UserId;
                    });



                }
            }
        });
    }

    $scope.$watch(function () { return $scope.UsersModel.ViewAssignUserSearchText }, function (val) {
        if ($scope.UsersModel.ViewAssignUserSearchText.length > 0) {
            $scope.UsersModel.IsSearchTextFound = true;
        }
        if (ViewAssignUsersSearchTimeout) $timeout.cancel(ViewAssignUsersSearchTimeout);

        ViewAssignUsersSearchTimeout = $timeout(function () {
            if ($scope.UsersModel.IsSearchTextFound) {
                $scope.onViewUserSearch();
            }
        }, 2000);
    }, true);


    $scope.CopyGroupModel = {
        FromGroupId: '',
        ToGroupModel: groupFactory.groupInitialValues(),
        IsShowErrorMsg: false,
        IsPosting: false,
        IsShowSuccessMsg: false,
        ErrorMessage: '',

        showDialog: function (fromGroupName) {

            var readGroup = GroupService.getGroupDetails($scope.vm.selectedLibrary, fromGroupName);
            readGroup.then(function (response) {
                var tempModel = response.data.rows[0].cell[0][0];
                $scope.CopyGroupModel.ToGroupModel.GroupFullName = tempModel.GroupFullName;
                $scope.CopyGroupModel.ToGroupModel.GroupName = '';// tempModel.GroupName;
                $scope.CopyGroupModel.ToGroupModel.GroupIsExternal = tempModel.GroupIsExternal;
                $scope.CopyGroupModel.ToGroupModel.GroupEnabled = tempModel.GroupEnabled;
                $scope.CopyGroupModel.ToGroupModel.GroupNOS = tempModel.GroupNOS;
                $scope.CopyGroupModel.ToGroupModel.GroupNum = tempModel.GroupNum;

                $scope.CopyGroupModel.FromGroupId = tempModel.GroupName;
                tempModel = null;

                var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;

                var dialogObject = {
                    controller: DialogController,
                    scope: $scope,
                    preserveScope: true,
                    templateUrl: 'Views/NgTemplates/CopyGroup.html',
                    parent: angular.element(document.body),
                    targetEvent: null,
                    clickOutsideToClose: true,
                    fullscreen: useFullScreen
                };
                $mdDialog.show(dialogObject)
                .then(function (answer) {
                    $scope.status = '';
                }, function () {
                    $scope.status = '';
                });
                $scope.$watch(function () {
                    return $mdMedia('xs') || $mdMedia('sm');
                }, function (wantsFullScreen) {
                    $scope.customFullscreen = (wantsFullScreen === true);
                });
            },
            function () { });
        },

        closeDialog: function () {
            $mdDialog.cancel();
            $scope.CopyGroupModel.ToGroupModel = groupFactory.groupInitialValues();
            $scope.CopyGroupModel.IsShowErrorMsg = false;
            $scope.CopyGroupModel.IsPosting = false;
            $scope.CopyGroupModel.IsShowSuccessMsg = false;
            $scope.CopyGroupModel.ErrorMessage = '';
            $scope.CopyGroupModel.FromGroupId = '';
        },

        copy: function () {
            $scope.CopyGroupModel.ErrorMessage = '';
            $scope.CopyGroupModel.IsShowErrorMsg = false;

            if ($scope.CopyGroupModel.ToGroupModel.GroupName.trim().length == 0) {
                //$scope.CopyGroupModel.IsShowErrorMsg = true;
                return;
            }

            $scope.CopyGroupModel.IsPosting = true;
            var addGroup = GroupService.copyGroup($scope.vm.selectedLibrary, $scope.CopyGroupModel.FromGroupId, $scope.CopyGroupModel.ToGroupModel);
            addGroup.then(function (response) {
                if (response && response.data && response.data.Status) {
                    $scope.CopyGroupModel.IsShowSuccessMsg = true;
                    if (response.data.Message && response.data.Message.trim().length > 0) {
                        $scope.CopyGroupModel.ErrorMessage = response.data.Message;
                    }
                    else {
                        $scope.CopyGroupModel.ErrorMessage = 'Group copied succesfully.';
                    }
                    getGroups();
                    setTimeout(function () {
                        $scope.CopyGroupModel.closeDialog();
                    }, 1500);
                }
                else {
                    $scope.CopyGroupModel.ErrorMessage = response.data.Message && response.data.Message.trim().length > 0 ? response.data.Message : '';
                    $scope.CopyGroupModel.IsShowErrorMsg = response.data.Message && response.data.Message.trim().length > 0;
                }
                $scope.CopyGroupModel.IsPosting = false;

            }, function () {

            });
        }
    };


    $scope.ClearGroupClick = function () {        
        $scope.UsersModel.SearchText = '';
        $scope.UsersModel.ViewAssignUserSearchText = '';

    }

    $scope.ReassignGroupSecurityObject = {
        IsPosting: false,
        IsShowErrorMsg: false,
        IsShowSuccessMsg: false,
        ErrorMessage: '',
        NewGroupId: '',
        SelectedGroupId: '',

        showDialog: function (fromGroupName) {
            $scope.ReassignGroupSecurityObject.SelectedGroupId = fromGroupName;
            $scope.ReassignGroupSecurityObject.NewGroupId = '';

            var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;

            var dialogObject = {
                controller: DialogController,
                scope: $scope,
                preserveScope: true,
                templateUrl: 'Views/NgTemplates/ReassignGroupSecurity.html',
                parent: angular.element(document.body),
                targetEvent: null,
                clickOutsideToClose: true,
                fullscreen: useFullScreen
            };
            $mdDialog.show(dialogObject)
            .then(function (answer) {
                $scope.status = '';
            }, function () {
                $scope.status = '';
            });
            $scope.$watch(function () {
                return $mdMedia('xs') || $mdMedia('sm');
            }, function (wantsFullScreen) {
                $scope.customFullscreen = (wantsFullScreen === true);
            });
        },

        closeDialog: function () {
            $mdDialog.cancel();
            $scope.ReassignGroupSecurityObject.SelectedGroupId = '';
            $scope.ReassignGroupSecurityObject.NewGroupId = '';
            $scope.ReassignGroupSecurityObject.IsShowErrorMsg = false;
            $scope.ReassignGroupSecurityObject.IsPosting = false;
            $scope.ReassignGroupSecurityObject.IsShowSuccessMsg = false;
            $scope.ReassignGroupSecurityObject.ErrorMessage = '';
            $scope.ReassignGroupSecurityObject.FromGroupId = '';
        },
        Reassign: function () {
            if ($scope.ReassignGroupSecurityObject.NewGroupId.trim().length == 0) {
                return;
            }

            $scope.ReassignGroupSecurityObject.SelectedGroupId.IsPosting = true;
            var dbWriter = GroupService.reassignSecurity($scope.vm.selectedLibrary, $scope.ReassignGroupSecurityObject.SelectedGroupId, $scope.ReassignGroupSecurityObject.NewGroupId);
            dbWriter.then(function (response) {
                if (response && response.data && response.data.Status) {
                    $scope.ReassignGroupSecurityObject.IsShowSuccessMsg = true;
                    if (response.data.Message && response.data.Message.trim().length > 0) {
                        $scope.ReassignGroupSecurityObject.ErrorMessage = response.data.Message;
                    }
                    else {
                        $scope.ReassignGroupSecurityObject.ErrorMessage = 'Group Security successfully reassigned.';
                    }
                    setTimeout(function () {
                        $scope.ReassignGroupSecurityObject.closeDialog();
                    }, 1500);
                }
                else {
                    $scope.ReassignGroupSecurityObject.ErrorMessage = response.data.Message && response.data.Message.trim().length > 0 ? response.data.Message : '';
                    $scope.ReassignGroupSecurityObject.IsShowErrorMsg = response.data.Message && response.data.Message.trim().length > 0;
                }
                $scope.ReassignGroupSecurityObject.IsPosting = false;

            }, function () {

            });
        }
    };

    //new table intgration events
    $scope.selected = [];

    $scope.query = {
        order: 'name',
        limit: requestModel.pageLength,
        page: requestModel.pagenumber,
        totalCount: 0
    };

    $scope.onPaginate = function (page, limit) {

        requestModel.pagenumber = page;
        requestModel.pageLength = limit;
        getGroups();
        $scope.promise = $timeout(function () {

        }, 2000);
    };

    $scope.deSelect = function (item) {
        setContextMenuObject();
    };

    $scope.onSelect = function (item) {
        setContextMenuObject();
    };

    $scope.log = function (item) {

    };

    $scope.loadStuff = function () {
        $scope.promise = $timeout(function () {

        }, 2000);
    };

    $scope.onReorder = function (order) {

        console.log('Scope Order: ' + $scope.query.order);
        console.log('Order: ' + order);

        $scope.promise = $timeout(function () {

        }, 2000);
    };

    $scope.UserTablePagination = {
        order: 'UserID',
        limit: gurequestModel.pageLength,
        page: gurequestModel.pagenumber,
        totalCount: 0
    };

    $scope.onUserTablePaginate = function (page, limit) {
        //$scope.SelAll.checked = false;
        gurequestModel.pagenumber = page;
        gurequestModel.pageLength = limit;
        //guoffset = page;
        getAllUserList();
    };

    $scope.ViewUserTablePagination = {
        order: 'UserID',
        limit: 10,
        page: 1,
        totalCount: 0
    };

    $scope.onViewUserTablePaginate = function (page, limit) {
        guoffset = page;
        getAllUserList()
    };

    $scope.CheckedUserSelectionChanged = function () {
        getAllUserList();
    }

};