﻿app.controller("DocTypeController", DocTypeController);
DocTypeController.$inject = ['$scope', '$rootScope', '$filter', '$timeout', '$mdDialog', '$mdMedia',  'DocTypeService',   'docTypeFactory', 'ngTableParams'];

function DocTypeController($scope, $rootScope, $filter, $timeout, $mdDialog, $mdMedia,   DocTypeService,    docTypeFactory, ngTableParams) {

    $scope.tableLastRowIndex = 0;
    $scope.loading = true;
    $scope.ScrollCounter = false;
    $scope.appsVar.SearchText = '';
    $scope.isPrevDisable = true;
    $scope.isNextDisable = true;
    //$scope.dtColumnDefs = datatableSettingsFactory.dtTypeTableColumns;
    //$scope.tableSettings = datatableSettingsFactory.tableSettings();

    $scope.DocTypeModel = docTypeFactory.docTypeInitialValues();

    $scope.tableParamsDocType = new ngTableParams({
        noPager: true
    }, {
        getData: function ($defer, params) {
            $defer.resolve($scope.DocTypes);
        }
    });

   

    function typeInitalize() {
        $scope.loading = true;
        $scope.DocTypes = null;
        $scope.tableLastRowIndex = 0;
        $scope.lastoffset_val = -1;
        if ($scope.selectedLibrary && $scope.selectedLibrary.trim().length > 0)
            getDocTypes($scope.selectedLibrary, 0, 10, true);
    }

    if ($scope.selectedLibrary && $scope.selectedLibrary.trim().length > 0)
        getDocTypes($scope.selectedLibrary, 0, 10, true);

    $rootScope.$on('onDocTypeTabClick', function () {
        typeInitalize();
    })

    $scope.lastoffset_val = 0;
    $scope.lastCursorValue = null;

    $scope.loadMoreOnScrollEnd = function () {
        if ($scope.vm.selectedApp.TotalRowCount > $scope.tableLastRowIndex) {
            if ($scope.selectedLibrary && $scope.selectedLibrary.trim().length > 0)
                getDocTypes($scope.selectedLibrary, $scope.tableLastRowIndex, 10, true);
        }
    };

    $scope.PreviousPageButton_Click = function () {
        $scope.tableLastRowIndex -= 10;
        getDocTypes($scope.selectedLibrary, $scope.tableLastRowIndex, 10, true);
    }

    $scope.NextPageButton_Click = function () {
        $scope.tableLastRowIndex += 10;
        getDocTypes($scope.selectedLibrary, $scope.tableLastRowIndex, 10, true);
    }

    function getDocTypes(selectedLibrary, offset_val, limit_val, total_val) {
        if ($scope.vm.selectedApp.NoAppsPermission.trim().length > 0) return;
        if (!$scope.selectedLibrary || $scope.selectedLibrary.trim().length == 0) return;

        $scope.lastSelectedLibrary = $scope.selectedLibrary;
        $scope.loading = true;

        var promise = DocTypeService.getDocTypes(selectedLibrary, offset_val, limit_val, total_val, $scope.appsVar.SearchText);
        promise.then(function (response) {
            $scope.appsVar.initialLoading = false;
            if (response.data.rows.length > 0 && response.data.rows[0].cell.length > 0) {

                if (offset_val <= 0) {
                    $scope.isPrevDisable = true;
                } else {
                    $scope.isPrevDisable = false;
                }
                $scope.DocTypes = response.data.rows[0].cell[0];
                $scope.loading = false;
                $scope.vm.selectedApp.TotalRowCount = response.data.rows[0].cell[1];
                if ($scope.tableLastRowIndex + 10 >= $scope.vm.selectedApp.TotalRowCount) {
                    $scope.isNextDisable = true;
                } else {
                    $scope.isNextDisable = false;
                }
                $('#card-more-button').attr('disabled', 'disabled');
            }
            $scope.vm.selectedApp.ResponseCount = $scope.DocTypes.length;
            $scope.loading = false;
            
        }, function () {
            alert('Data fetching failed.');
            $scope.loading = false;
        });
    }

    $scope.SelectCurrentRow = function (typeModel, $event) {
        if ($scope.vm.selectedApp.CurrentTab == 'App Setup') {
            $scope.appsetup.TempType = typeModel.TAlias;
            this.getAllSelectedRows(typeModel);
        }
        else {
            if ($event.ctrlKey) {
                typeModel.Selected ? typeModel.Selected = false : typeModel.Selected = true;
            }
            else {
                this.getAllSelectedRows(typeModel);
            }
        }
        var selectedUserList = $filter('filter')($scope.DocTypes, { Selected: true });
        if (selectedUserList.length == 0) {
            $('#card-more-button').attr('disabled', 'disabled')
        } else {
            $('#card-more-button').removeAttr('disabled')
        }
    };

    (function ($) {
        $(document).ready(function () {
            $('#card-more-button').attr('disabled', 'disabled');
        });
    })(jQuery);

    $scope.onTypeDbClick = function (typeModel, $event) {
        if ($scope.vm.selectedApp.CurrentTab == 'App Setup') {
            $scope.appsetup.Type = typeModel.TAlias;
            $("#Select_Types_appSetup").modal('hide');
        }
    }

    $scope.getAllSelectedRows = function (typeModel) {
        var selectedTypeList = $filter('filter')($scope.DocTypes, { Selected: true });
        angular.forEach(selectedTypeList, function (tempItemModel) {
            tempItemModel.Selected = false; //set them all to false
        });
        typeModel.Selected = true; //set the clicked one to true
    };

    $scope.addDocType = function () {
        $scope.showValidation = false;
        if ($scope.DocTypeModel.TAlias == '' || $scope.DocTypeModel.TypeDescription == '' || $scope.DocTypeModel.DmsExtension == '' || $scope.DocTypeModel.AppExtension == '') {
            $scope.showValidation = true;
            return;
        }

        $scope.lastCursorValue = $scope.cursorValue;
        $scope.lastSelectedLibrary = $scope.selectedLibrary;
        var addtype = DocTypeService.addDocType($scope.selectedLibrary, $scope.DocTypeModel);
        addtype.then(function (response) {
            if (response.data.rows.length > 0) {
                if (response.data.rows[0].cell.length > 0) {
                    if (response.data.rows[0].cell[2] == 'Success') {
                        typeInitalize();
                        $scope.DocTypeModel = docTypeFactory.docTypeInitialValues();
                        $scope.ShowWarning = false;
                        $scope.showValidation = false;
                        setTimeout(function () {
                            $scope.PageEvents.CancelDialog();
                            $scope.ShowWarning = false;
                        }, 1500);
                    }
                    $scope.ErrorMessage = response.data.rows[0].cell[2];
                    $scope.ShowWarning = true;
                }
            }

        }, function () {

        });
    }
    
    $scope.singleDeleteClick = function () {
        var s = $scope.appsVar.selectedRecordId;
        var getDocType = DocTypeService.DeleteDocType(s);

        getDocType.then(function (response) {
            if (response.data == "success") {
                $scope.appsVar.selectedRecordId = '';
                $scope.haveMoreRows = true;
                $scope.cursorValue = '';
                $scope.lastSelectedLibrary = '';
                getDocTypes($scope.selectedLibrary, 0, 10, true);
                $scope.showAlertMessage("Selected type(s) deleted successfully.");
            } else {
                $scope.showAlertMessage('Failed to delete selected type(s).');
            }
        }, function () {
            $scope.showAlertMessage('Failed to delete selected type(s).');
        });

    };

    $rootScope.$on('onTypesValidateBulkDeleteClick', function () {
        $scope.ValidateTypes = [];
        TypeValidateBulkDeleteClick();
    })

    function TypeValidateBulkDeleteClick() {
        $scope.ValidateTypes = $filter('filter')($scope.DocTypes, { selected: true });
        if (typeof $scope.ValidateTypes !== 'undefined' && $scope.ValidateTypes.length > 0) {
            $scope.showConfirmMessage('Are you sure to delete selected type(s)?');
            return true;
        }
        else {
            $scope.showAlertMessage('Select type(s) to delete.');
            return false;
        }
    }

    $rootScope.$on('onDocTypeBulkDeleteClick', function () {
        $scope.Type = [];
        DocTypeBulkDeleteClick();
    })

    function DocTypeBulkDeleteClick() {
        $scope.Type = $filter('filter')($scope.DocTypes, { selected: true });
        var getDocType = DocTypeService.DeleteDocType($scope.Type);

        getDocType.then(function (response) {
            if (response.data == "success") {
                $scope.appsVar.selectedRecordId = '';
                $scope.haveMoreRows = true;
                $scope.cursorValue = '';
                $scope.lastSelectedLibrary = '';
                getDocTypes($scope.selectedLibrary, 0, 10, true);
                $scope.showAlertMessage("Selected type(s) deleted successfully.");
            } else {
                $scope.showAlertMessage('Failed to delete selected type(s).');
            }
        }, function () {
            $scope.showAlertMessage('Failed to delete selected type(s).');
        });

    }

    $scope.singleTypeDeleteConfirmMessageClick = function () {
        $scope.showSingleTypeDeleteConfirmMessage('Are you sure to delete ' + $scope.appsVar.selectedRecordId + '?');
    };

    $scope.showSingleTypeDeleteConfirmMessage = function (message) {
        $("#singleTypeconfirm_popup").find('#singletypeconfirmMsgText').text(message);
        $("#singleTypeconfirm_popup").modal();
    }

    $scope.$on('Search_Click', function (event, args) {
        $scope.tableLastRowIndex = 0;
        $scope.loading = true;
        $scope.ScrollCounter = false;
        $scope.lastoffset_val = 0;
        $scope.lastCursorValue = null;
        $scope.lastSelectedLibrary = '';
        $scope.DocTypes = null;
        getDocTypes($scope.selectedLibrary, $scope.tableLastRowIndex, 10, true);
    });

    $scope.$on('Refresh_Click', function () {
        $scope.tableLastRowIndex = 0;
        $scope.loading = true;
        $scope.ScrollCounter = false;
        $scope.lastoffset_val = 0;
        $scope.lastCursorValue = null;
        $scope.lastSelectedLibrary = '';
        $scope.DocTypes = null;
        getDocTypes($scope.selectedLibrary, $scope.tableLastRowIndex, 10, true);

    });


    $scope.UpdateDocType = function () {
        $scope.ShowWarning = false;

        if ($scope.DocTypeModel.TAlias == '' || $scope.DocTypeModel.TypeDescription == '' || $scope.DocTypeModel.DmsExtension == '' || $scope.DocTypeModel.AppExtension == '') {
            $scope.showValidation = true;
            return;
        } else {
            $scope.showValidation = false;
        }
        $scope.posting = true;
        var UpdateData = DocTypeService.UpdateDocType($scope.selectedLibrary, $scope.DocTypeModel);
        UpdateData.then(function (response) {

            if (response.data.rows.length > 0) {
                if (response.data.rows[0].cell.length > 0) {
                    if (response.data.rows[0].cell[2] == 'Success') {
                        typeInitalize();
                        $scope.DocTypeModel = docTypeFactory.docTypeInitialValues();
                        $scope.ShowWarning = false;
                        $scope.showValidation = false;
                        setTimeout(function () {
                            $scope.PageEvents.CancelDialog();
                            $scope.ShowWarning = false;
                        }, 1500);
                    }
                    $scope.ErrorMessage = response.data.rows[0].cell[2];
                    $scope.ShowWarning = true;
                }
            }
            $scope.posting = false;
        }, function () {
            alert('Error in updating record');
        });
    }

    if ($scope.vm.selectedApp.CurrentTab == "Types") {
        $scope.PageEvents.Add = function () {
            $scope.PageEvents.UserAction = 'Add';
            $('#virtual_docs').modal();
        };

        $scope.PageEvents.Edit = function (row) {
            $scope.PageEvents.UserAction = 'Edit';
            $scope.ValidateTypes = $filter('filter')($scope.DocTypes, { selected: true });
            if (row) {
                var docID = $scope.appsVar.selectedRecordId;
                $scope.ValidateTypes = $filter('filter')($scope.DocTypes, { TAlias: docID });
            }
            if (typeof $scope.ValidateTypes !== 'undefined' && $scope.ValidateTypes.length > 0) {
                angular.copy($scope.ValidateTypes[0], $scope.DocTypeModel);
                $("#virtual_docs").modal();
                return true;
            }
            else {
                $scope.showAlertMessage('Select Type to edit.');
                return false;
            }
        }


        $scope.PageEvents.BindLabel = function (data) {
            if ($scope.PageEvents.UserAction == 'Add') {
                return 'Add'
            } else {
                return 'Save';
            }
        }

        $scope.PageEvents.Save = function () {
            if ($scope.PageEvents.UserAction == 'Add') {
                return $scope.addDocType();
            } else {
                return $scope.UpdateDocType();
            }
        }

        $scope.PageEvents.CancelDialog = function () {
            $scope.DocTypeModel = docTypeFactory.docTypeInitialValues();
            $scope.ShowWarning = false;
            $scope.showValidation = false;
            $('#virtual_docs').modal('hide');
        }
    }

};