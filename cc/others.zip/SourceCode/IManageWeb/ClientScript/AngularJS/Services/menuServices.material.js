﻿
(function () {
    angular.module('common.services').service("ManagementService", managementService);
    managementService.$inject = ['$http'];
    function managementService($http) {

        this.getUserPermission = function (libName) {
            var response = $http({
                url: appBaseURL + "Home/getUserPermission",
                method: "GET",
                params: { libraryName: libName }
            });
            return response;
        }
    }
})();
