﻿app.service("MetaDataService", MetaDataService);
MetaDataService.$inject = ['$http'];

function MetaDataService($http) {

    this.getMetaDataList = function (requestModel, MetaType) {
        var response = $http({
            url: "MetaData/GetMetaDataList",
            method: "GET",
            //params: { libraryName: libName, cursor: cursor_val, pageLength: limit_val, searchText: search,comboValue:ComboType }
            params: { searchModelJSONString: JSON.stringify(requestModel), metaType: MetaType }
        });
        return response;
    }

    this.addMetaData = function (metaDataDetails, selectedLibrary, ParentMetaData, SelectMetaData) {
        var promise = $http({
            url: "MetaData/Add",
            method: "POST",
            data: { 'libraryName': selectedLibrary, 'metaDataDetails': metaDataDetails, MetaType: ParentMetaData, selParentAlias: SelectMetaData }
        });
        return promise;
    }

    this.EditMetaData = function (libName, editData, ParentMetaData, SelectMetaData) {
        var promise = $http({
            url: "MetaData/Edit",
            method: "POST",
            data: { 'libraryName': libName, 'metaDataDetails': editData, MetaType: ParentMetaData, selParentAlias: SelectMetaData }
        });
        return promise;
    }

    this.getSubMetaDataList = function (subrequestModel, ComboType, SelectMetaData) {

        var response = $http({
            url: "MetaData/GetSubMetaDataList",
            method: "GET",
            params: { searchModelJSONString: JSON.stringify(subrequestModel), MetaType: ComboType, selParentAlias: SelectMetaData }
        });
        return response;
    }

    this.deleteMetaData = function (dbName, metaType, metaDataItem) {
        var promise = $http({
            url: "MetaData/Delete",
            method: "POST",
            data: { 'libraryName': dbName, 'metadataItem': metaDataItem, 'metaType': metaType }
        });
        return promise;
    }

    this.deleteSubMetaData = function (dbName, metaType, metaDataItem, parentItem) {
        var promise = $http({
            url: "MetaData/DeleteSubItem",
            method: "POST",
            data: { 'libraryName': dbName, 'metadataItem': metaDataItem, 'metaType': metaType, 'parentItem': parentItem }
        });
        return promise;
    }

    //this.addSubMetaData = function (metaDataDetails, selectedLibrary,ParentMetaData) {
    //    var promise = $http({
    //        url: "MetaData/AddSub",
    //        method: "POST",
    //        data: { 'libraryName': selectedLibrary, 'metaDataDetails': metaDataDetails, ParentData: ParentMetaData }
    //    });
    //    return promise;
    //}



}