﻿//app.service("ManagementService", managementService);
angular.module('common.services').service("ManagementService", managementService);
managementService.$inject = ['$http'];
function managementService($http) {
    //For Getting User Area(MAnagement,Content,System)
    this.getUserAreas = function () {
        var response = $http.get("Home/GetUserAppsType");
        return response;
    };

    this.getUserPermission = function (libName) {
        var response = $http({
            url: "Home/getUserPermission",
            method: "GET",
            params: { libraryName: libName }
        });
        return response;
    };

    //For Getting User Apps
    this.getUserApps = function () {
        var response = $http.get("Home/GetUserApps");
        return response;
    }

    this.getMetaDataList = function (libName) {
        var response = $http({
            url: "MetaData/List",
            method: "GET",
            params: { libraryName: libName }
        });
        return response;       
    }

    this.getCaptions = function (libName) {
        var response = $http({
            url: "Roles/Captions",
            method: "GET",
            params: { libraryName: libName }
        });
        return response;

    }

   
}