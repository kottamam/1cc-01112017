﻿app.service("DatabaseService", DatabaseService);
DatabaseService.$inject = ['$http'];
function DatabaseService($http)
{
  
    this.getDatabase = function (requestModel) {
        var response = $http({
            url: "Database/GetDatabases",
            method: "GET",
            params: { searchModelJSONString: JSON.stringify(requestModel) }
        });
        return response;
    }
    this.addDatabases = function (libName, DatabaseModel) {
        var response = $http({
            url: "Database/Add",
            method: "POST",
            data: { 'libraryName': libName, 'DMSModel': DatabaseModel },
            dataType: "json"
        });
        return response;
    }
    this.editDatabases = function (libName, DatabaseModel) {
        var promise = $http({
            url: "Database/Edit",
            method: "POST",
            data: { 'libraryName': libName, 'DMSModel': DatabaseModel },
            dataType: "json"
        });
        return promise;
    }

}
    