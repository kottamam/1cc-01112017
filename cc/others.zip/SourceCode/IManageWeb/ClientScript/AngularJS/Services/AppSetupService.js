﻿app.service("AppSetupService", AppSetupService);
AppSetupService.$inject = ['$http'];

function AppSetupService($http) {
    this.getAppSetupList = function (libName, offset_val, limit_val, total_val, search) {
        var response = $http({
            url: "AppSetup/GetAppSetupList",
            method: "GET",
            params: { libraryName: libName, offset: offset_val, limit: limit_val, total: total_val, searchText: search }
        });
        return response;
    }

    this.DeleteAppSetup = function (AppSetup) {
        var response = $http({
            method: "post",
            url: "AppSetup/DeleteAppSetup",
            params: {
                AppSetups: JSON.stringify(AppSetup)
            }
        });
        return response;
    }

    this.addAppSetup = function (appsetupDetails, selectedLibrary) {
        var promise = $http({
            url: "AppSetup/Add",
            method: "POST",
            data: { 'libraryName': selectedLibrary, 'appsetupDetails': appsetupDetails }
        });
        return promise;
    }

    this.getTypesForCombobox = function (libName) {
        var response = $http({
            url: "AppSetup/getDocTypes",
            method: "GET",
            params: { libraryName: libName }
        });
        return response;
    }

    this.EditAppSetup = function (libName, editData) {
        var promise = $http({
            url: "AppSetup/Edit",
            method: "POST",
            data: { 'libraryName': libName, 'AppSetupModel': editData }
        });
        return promise;

    }

    this.getDocTypes = function (libName, offset_val, limit_val, total_val, search) {
        var response = $http({
            url: "DocType/getDocTypes",
            method: "GET",
            params: { libraryName: libName, offset: offset_val, limit: limit_val, total: total_val, searchText: search }
        });
        return response;
    }

}