﻿app.service("SecurityTemplateService", SecurityTemplateService);
SecurityTemplateService.$inject = ['$http'];

function SecurityTemplateService($http) {

    this.getSecurityTemplateServiceList = function (libName, cursor_val, limit_val, search) {
        var response = $http({
            url: "SecurityTemplate/GetList",
            method: "GET",
            params: { libraryName: libName, cursor: cursor_val, pageLength: limit_val, searchText: search }
        });
        return response;
    }

    this.getServiceList = function (requestModel) {
        var response = $http({
            url: "SecurityTemplate/GetServiceList",
            method: "GET",
            params: { searchModelJSONString: JSON.stringify(requestModel) }
        });
        return response;
    }

    this.getByTemplateName = function (libName, templateName) {
        var response = $http({
            url: "SecurityTemplate/GetByName",
            method: "GET",
            params: { libraryName: libName, templateName: templateName }
        });
        return response;
    }

    this.save = function (libName, securityTemplateModel, isEditMode) {
        var response = $http({
            url: "SecurityTemplate/Save",
            method: "POST",
            data: { 'libraryName': libName, 'templateModel': securityTemplateModel, 'isEditMode': isEditMode }
        });
        return response;
    }

    this.getUserTemplate = function (libName, userId) {
        var response = $http({
            url: "SecurityTemplate/GetUserTemplate",
            method: "GET",
            params: { 'libraryName': libName, 'userId': userId }
        });
        return response;
    }
}