﻿
app.service("HomeService", homeService);
homeService.$inject = ['$http'];
function homeService($http) {
    this.getDBLibraries = function () {
        var promise = $http({
            url: appBaseURL + "Home/DBLibraries",
            method: "GET"
        });
        return promise;
    }
}