﻿app.service("RolesService", RolesService);
RolesService.$inject = ['$http'];

function RolesService($http) {
    this.getRoles = function (requestModel) {
        var response = $http({
            url: "Roles/GetRoles",
            method: "GET",
            params: { searchModelJSONString: JSON.stringify(requestModel) }
        });
        return response;
    }

    this.DeleteRole = function (libName, roleModel) {
        var response = $http({
            method: "POST",
            url: "Roles/DeleteRoles",
            params: {
                libraryName: libName,
                roleModelJSON: JSON.stringify(roleModel)
            }
        });
        return response;
    }

    this.getCaptions = function (libName) {
        var response = $http({
            url: "Roles/Captions",
            method: "GET",
            params: { libraryName: libName }
        });
        return response;

    }

    this.addRoles = function (libName, RolesModel, SelectedUsers) {
        var response = $http({
            url: "Roles/Add",
            method: "POST",
            data: { 'libraryName': libName, 'roleModel': RolesModel, 'SelectedUsers': SelectedUsers },
            dataType: "json"
        });
        return response;
    }

    this.editRole = function (libName, RolesModel, SelectedUsers, deletedMemberList) {
        var response = $http({
            url: "Roles/Edit",
            method: "POST",
            data: { 'libraryName': libName, 'roleModel': RolesModel, 'SelectedUsers': SelectedUsers, 'deletedMembers': deletedMemberList },
            dataType: "json"
        });
        return response;
    }

    this.getRole = function (libName, roleName) {
        var response = $http({
            url: "Roles/GetRole",
            method: "GET",
            params: { libraryName: libName, roleName: roleName }
        });
        return response;
    }

    this.copyRole = function (libName, fromRoleName, toRoleName) {
        var response = $http({
            url: "Roles/Copy",
            method: "POST",
            data: { 'libraryName': libName, 'fromRoleName': fromRoleName, 'toRoleName': toRoleName },
            dataType: "json"
        });
        return response;
    }
}