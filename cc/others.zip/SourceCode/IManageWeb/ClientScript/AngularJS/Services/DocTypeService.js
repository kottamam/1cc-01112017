﻿app.service("DocTypeService", DocTypeService);
DocTypeService.$inject = ['$http'];
function DocTypeService($http) {

    this.getDocTypes = function (libName, offset_val, limit_val, total_val, search) {
        var response = $http({
            url: "DocType/getDocTypes",
            method: "GET",
            params: { libraryName: libName, offset: offset_val, limit: limit_val, total: total_val, searchText: search }
        });
        return response;
    }

 	this.addDocType = function (libName, docTypeModel) {
        var response = $http({
            url: "DocType/Add",
            method: "POST",
            data: { 'libraryName': libName, 'docTypeModel': docTypeModel },
            dataType: "json"
        });
        return response;
    }

    this.DeleteDocType = function (DocTypeName) {
        var response = $http({
            method: "post",
            url: "DocType/DeleteDocType",
            params: {
                DocTypeNames: JSON.stringify(DocTypeName)
            }
        });
        return response;
    }

    this.UpdateDocType = function (libName, docTypeModel) {
        var promise = $http({
            url: "DocType/Edit",
            method: "POST",
            data: { 'libraryName': libName, 'docTypeModel': docTypeModel }
        });
        return promise;

    }


}