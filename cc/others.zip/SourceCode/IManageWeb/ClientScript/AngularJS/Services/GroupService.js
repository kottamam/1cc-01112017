﻿app.service("GroupService", GroupService);
GroupService.$inject = ['$http'];
function GroupService($http) {

    this.getGroupDetails = function (libName, group) {
        var response = $http({
            url: "Group/GroupDetails",
            method: "GET",
            params: { libraryName: libName, groupAlias: group }
        });
        return response;
    }

    this.getGroups = function (requestModel) {
        var response = $http({
            url: "Group/GetGroups",
            method: "POST",
            params: { searchModelJSONString: JSON.stringify(requestModel) },
            dataType: "json"
        });
        return response;
    }


    this.addGroups = function (libName, groupModel) {
        var response = $http({
            url: "Group/Add",
            method: "POST",
            data: { 'libraryName': libName, 'groupModel': groupModel },
            dataType: "json"
        });
        return response;
    }


    this.DeleteGroup = function (GroupName) {
        var response = $http({
            method: "post",
            url: "Group/DeleteGroup",
            params: {
                GroupNames: JSON.stringify(GroupName)
            }
        });
        return response;
    }

    this.EditGroup = function (libName, editData) {
        var promise = $http({
            url: "Group/Edit",
            method: "POST",
            data: { 'libraryName': libName, 'groupModel': editData }
        });
        return promise;

    }

    //this.AddRemoveUserGroup = function (libName, userId, addedGroup, deletedGroup) {
    //    var promise = $http({
    //        url: "Group/AddRemoveUserGroup",
    //        method: "POST",
    //        data: {
    //            libraryName: libName,
    //            userId: userId,
    //            addedGroupNameListString: JSON.stringify(addedGroup),
    //            deletedGroupNameListString: JSON.stringify(deletedGroup)
    //        }
    //    });
    //    return promise;
    //}

    this.AddUserGroup = function (libName, userId, addedGroup, deletedGroup) {
        var promise = $http({
            url: "Group/AddRemoveUserGroup",
            method: "POST",
            data: {
                libraryName: libName,
                userId: userId,
                addedGroupNameListString: JSON.stringify(addedGroup),
                deletedGroupNameListString: JSON.stringify(deletedGroup)
            }
        });
        return promise;
    }

    this.getAllGroupList = function (libName) {
        var response = $http({
            url: "Group/GetAllGroupList",
            method: "GET",
            params: { libraryName: libName }
        });
        return response;
    }

    this.getUserGroupList = function (libName, userId) {
        var response = $http({
            url: "Group/GetUserGroupList",
            method: "GET",
            params: { libraryName: libName, userId: userId }
        });
        return response;
    }

    this.getAllGroupsInUser = function (libName, UserId) {
        var promise = $http({
            url: "Group/getAllGroupsInUser",
            method: "GET",
            params: { libraryName: libName, user: UserId }
        });
        return promise;
    }

    //this.AddGroupsToUser = function (libName, UserId, GroupList) {
    //    var promise = $http({
    //        url: "Group/AddGroupsToUser",
    //        method: "POST",
    //        data: { 'libraryName': libName, 'userId': UserId, 'groups': JSON.stringify(GroupList) }
    //    });
    //    return promise;
    //}

    this.EnableDisableGroup = function (libName, GroupList, isEnable) {
        var response = $http({
            method: "post",
            url: "Group/EnableDisableGroup",
            params: {
                libraryName: libName, groups: JSON.stringify(GroupList), IsEnable: isEnable
            }
        });
        return response;
    }


    this.GetSelectedGroupsOfUsers = function (libName, userName, groups) {
        var promise = $http({
            url: "Group/GetSelectedGroupsOfUsers",
            method: "POST",
            params: { libraryName: libName, userName: userName, groupNames: groups }
        });
        return promise;
    }

    this.copyGroup = function (libName, fromGroupId, toGroupModel) {
        var response = $http({
            url: "Group/Copy",
            method: "POST",
            data: { 'libraryName': libName, 'fromGroupId': fromGroupId, 'toGroupModel': toGroupModel },
            dataType: "json"
        });
        return response;
    }

    this.reassignSecurity = function (libName, fromGroupId, toGroupId) {
        var response = $http({
            url: "Group/Reassign",
            method: "POST",
            data: { 'libraryName': libName, 'fromGroupId': fromGroupId, 'toGroupId': toGroupId },
            dataType: "json"
        });
        return response;
    }
}