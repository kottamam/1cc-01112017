﻿app.service("ClassService", ClassService);
ClassService.$inject = ['$http'];
function ClassService($http) {

    //this.getClasses = function (libName, offset, limit, total, searchText) {
    //    var promise = $http({
    //        url: "Class/List",
    //        method: "GET",
    //        params: { libraryName: libName, offset: offset, limit: limit, total: total, searchText: searchText }
    //    });
    //    return promise;
    //}

    this.getClasses = function (requestModel) {
        var promise = $http({
            url: "Class/List",
            method: "POST",
            params: { searchModelJSONString: JSON.stringify(requestModel) },
            dataType: "json"
        });
        return promise;
    }

    this.addClass = function (libName, classModel, requiredFieldsList) {
        var response = $http({
            url: "Class/Add",
            method: "POST",
            data: { 'libraryName': libName, 'ClassModel': classModel, 'requiredFieldsList': requiredFieldsList },
            dataType: "json"
        });
        return response;
    }

    this.addSubClass = function (libName, classModel, requiredFieldsList, ParentClass) {
        var response = $http({
            url: "Class/AddSubClass",
            method: "POST",
            data: { 'libraryName': libName, 'ClassModel': classModel, 'requiredFieldsList': requiredFieldsList, 'ParentClass': ParentClass },
            dataType: "json"
        });
        return response;
    }

    this.editClass = function (libName, classModel, requiredFieldsList) {
        var response = $http({
            url: "Class/Edit",
            method: "POST",
            data: { 'libraryName': libName, 'ClassModel': classModel, 'requiredFieldsList': requiredFieldsList },
            dataType: "json"
        });
        return response;
    }

    this.editSubClass = function (libName, classModel, requiredFieldsList, ParentClass) {
        var response = $http({
            url: "Class/EditSubClass",
            method: "POST",
            data: { 'libraryName': libName, 'ClassModel': classModel, 'requiredFieldsList': requiredFieldsList, 'ParentClass': ParentClass },
            dataType: "json"
        });
        return response;
    }

    this.getSubClasses = function (requestModel, classAlias) {
        var promise = $http({
            url: "Class/SubClassList",
            method: "POST",
            dataType: "json",
            params: { searchModelJSONString: JSON.stringify(requestModel), classAlias: classAlias }
        });
        return promise;
    }

    this.deleteClass = function (libName, classModel) {
        var promise = $http({
            url: "Class/Delete",
            method: "POST",
            data: { 'libraryName': libName, 'classModel': classModel }
        });
        return promise;
    }

    this.deleteSubClass = function (libName, classModel,ParentClass) {
        var promise = $http({
            url: "Class/SubClassDelete",
            method: "POST",
            data: { 'libraryName': libName, 'classModel': classModel, 'ParentClass': ParentClass }
        });
        return promise;
    }

}