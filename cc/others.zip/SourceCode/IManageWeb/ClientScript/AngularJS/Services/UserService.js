﻿app.service("UserService", UserService);
UserService.$inject = ['$http'];

function UserService($http) {

    //this.getUsers = function (libName, page_number, page_Length, is_Total, search, isInternalOnly) {
    //    var promise = $http({
    //        url: "User/GetUsers",
    //        method: "GET",
    //        params: { libraryName: libName, pagenumber: page_number, pageLength: page_Length, isTotal: is_Total, searchText: search, isInternalOnly: isInternalOnly }

    //    });
    //    return promise;
    //}
    this.getUsers = function (requestModel, isInternalOnly) {
        var promise = $http({
            url: "User/GetUsers",
            method: "GET",
            params: { searchModelJSONString: JSON.stringify(requestModel), isInternalOnly: isInternalOnly },
            dataType: "json"
        });
        return promise;
    }

    this.getAllUserList = function (libName, search) {
        var promise = $http({
            url: "User/GetAllUserList",
            method: "GET",
            params: { libraryName: libName, searchText: search }
        });
        return promise;
    }

    this.addUser = function (userDetails, selectedLibrary, groupDetails) {
        var promise = $http({
            url: "User/Add",
            method: "POST",
            data: { 'libraryName': selectedLibrary, 'userDetails': userDetails, 'groupDetails': JSON.stringify(groupDetails) }
        });
        return promise;
    }

    this.DeleteUser = function (UserId) {
        var response = $http({
            method: "post",
            url: "User/DeleteUser",
            params: {
                UserIds: JSON.stringify(UserId)
            }
        });
        return response;
    }
    this.editUser = function (userDetails, selectedLibrary) {
        var promise = $http({
            method: "POST",
            url: "User/Edit",
            data: { 'libraryName': selectedLibrary, 'userDetail': userDetails }
        });
        return promise;
    }

    this.getAllUsersInRole = function (requestModel, RoleName) {
        var promise = $http({
            url: "User/GetAllUsersInRole",
            method: "GET",
            params: { searchModelJSONString: JSON.stringify(requestModel), roleName: RoleName }
        });
        return promise;
    }
    this.getRoleLessUsers = function (requestModel) {
        var promise = $http({
            url: "User/getRoleLessUsers",
            method: "GET",
            params: { searchModelJSONString: JSON.stringify(requestModel) }
        });
        return promise;
    }

    this.AddUsersToRole = function (libName, RoleName, UserList, removedusers) {
        var promise = $http({
            url: "User/AddUsersToRole",
            method: "POST",
            data: { 'libraryName': libName, 'roleName': RoleName, 'users': JSON.stringify(UserList), 'removedusers': JSON.stringify(removedusers) }
        });
        return promise;
    }

    this.ResetPasswordUser = function (userDetails, selectedLibrary) {
        var promise = $http({
            method: "POST",
            url: "User/ResetPassword",
            data: { 'libraryName': selectedLibrary, 'userDetail': userDetails }
        });
        return promise;
    }

    this.getAllUsersInGroup = function (userrequestModel, GroupName) {
        var promise = $http({
            url: "User/GetAllUsersInGroup",
            method: "GET",
            params: { userrequestModel: userrequestModel, groupName: GroupName }
        });
        return promise;
    }

    this.AddGroupUser = function (libName, GroupName, addedUser, deletedUser) {
        var promise = $http({
            url: "User/AddRemoveGroupUser",
            method: "POST",
            data: {
                libraryName: libName,
                groupName: GroupName,
                addedUserIdListString: JSON.stringify(addedUser),
                deletedUserIdListString: JSON.stringify(deletedUser)
            }
        });
        return promise;
    }

    this.GetAllSelectedUsersFromTheList = function (libName, GroupName, users) {
        var promise = $http({
            url: "User/GetAllSelectedUsersFromTheList",
            method: "POST",
            params: { libraryName: libName, groupName: GroupName, userList: users }
        });
        return promise;
    }

    this.LockUnlockUser = function (libName, userList, isUnlock) {
        var response = $http({
            method: "post",
            url: "User/LockUnlockAccounts",
            params: {
                libraryName: libName, accounts: JSON.stringify(userList), IsUnlock: isUnlock
            }
        });
        return response;
    }

    this.getDBLibrariesByUser = function (userID) {
        var promise = $http({
            url: "User/DBLibraries",
            method: "GET",
            params: { userName: userID }
        });
        return promise;
    }

    this.AssignSecurity = function (libName, userId, oldTemplateName, newTemplateName) {
        var response = $http({
            method: "POST",
            url: "User/AssignSecurity",
            params: {
                'libraryName': libName, 'userId': userId, 'oldTemplateName': oldTemplateName, 'newTemplateName': newTemplateName
            }
        });
        return response;
    }

    this.RenameUser = function (libName, oldUserId, newUserId) {
        var response = $http({
            method: "POST",
            url: "User/RenameUser",
            params: {
                'libraryName': libName, 'oldUserId': oldUserId, 'newUserId': newUserId
            }
        });
        return response;
    };
}