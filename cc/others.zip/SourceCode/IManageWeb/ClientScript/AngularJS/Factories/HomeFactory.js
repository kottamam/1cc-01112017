﻿app.factory('homeFactory', homeFactory);
app.factory('sessionTimeoutInterceptor', sessionTimeoutInterceptor);

function homeFactory() {
    //Management
    var selectedAppSettings = {
        appType: '',
        CurrentTab: '',
        CurrentSubTab: '',
        NoAppsPermission: 'Error',
        TotalRowCount: 0,
        CurrentPageIndex: 1,
        ResponseCount: 10,
        MetaDataItem: ''
    }

    var appsVar = {
        initialLoading: true,
        selectedRecordId: '',
        SearchText: '',
        CaptionsList: [],
        selectedMetaData: 'CUSTOM1',
        sortField: '',
        rightClickMenuID: '',
        tooltipValue: ''
    }

    var requestModelDef = {
        libraryName: '',
        pagenumber: 1,
        pageLength: 10,
        isTotal: true,
        IsMoreRowsFound: false,
        Cursor: '',
        searchText: '',
        sortKey: '',
        sortValue: '',//,DESC
        filters: [] //[{'Key1',[{'Value1', 'Value2',etc}] },{'Key1',[{'Value1', 'Value2',etc}] }]
    }

    var requestModelDe = {
        libraryName: '',
        pagenumber: 1,
        pageLength: 10,
        isTotal: true,
        IsMoreRowsFound: false,
        Cursor: '',
        searchText: '',
        sortKey: '',
        sortValue: '',//,DESC
        filters: [] //[{'Key1',[{'Value1', 'Value2',etc}] },{'Key1',[{'Value1', 'Value2',etc}] }]
    }

    var returnrequestModelDef = function () {
        return angular.copy(requestModelDe);
    }

    var userAreaDef = [{ AppTypeName: "Management", visibility: true }, { AppTypeName: "Content", visibility: true }, { AppTypeName: "System", visibility: true }]

    return {
        selectedApp: selectedAppSettings,
        applicationVariables: appsVar,
        userArea: userAreaDef,
        requestModel: requestModelDef,
        requestModelInstance: returnrequestModelDef
    }
};

var sessionTimeout;
function sessionTimeoutInterceptor($window, $timeout) {
    return {
        response: function (response) {
            if (sessionTimeout) $timeout.cancel(sessionTimeout);

            sessionTimeout = $timeout(function () {
                alert('Your session has expired. Please login again.');
                $window.location = '/login/Index';
            }, 1000 * 60 * sessionTimeoutInterval);
            return response;
        },

        responseError: function (response) {
            if (response.status == 401) {
                alert(response.data.message);
                $window.location = '/login/Index';
            }
        }
    };
}