﻿app.factory('groupFactory', groupFactory);

function groupFactory() {

    var groupInitialValueSettings = {
        GroupFullName: '',
        GroupName: '',
        GroupIsExternal: false,
        GroupEnabled: true,
        GroupNOS: 'NOSVirtual',
        GroupNum: 0
    }

    var returnGroupInitialValueSettings = function () {
        return angular.copy(groupInitialValueSettings);
    }

    return {
        groupInitialValues: returnGroupInitialValueSettings
    }
}