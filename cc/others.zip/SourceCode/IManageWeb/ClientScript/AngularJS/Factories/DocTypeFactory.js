﻿app.factory('docTypeFactory', docTypeFactory);

function docTypeFactory() {

    var docTypeInitialValueSettings = {
        TAlias: '',
        TypeDescription: '',
        AutoDetect: true,
        DmsExtension: '',
        AppExtension: '',
        Indexable: 0,
        HIPAAComplaint: false
    }

    var returnDocTypeInitialValueSettings = function () {
        return angular.copy(docTypeInitialValueSettings);
    }

    return {
        docTypeInitialValues: returnDocTypeInitialValueSettings
    }
}