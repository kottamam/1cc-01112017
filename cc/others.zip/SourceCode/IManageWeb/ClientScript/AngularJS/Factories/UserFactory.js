﻿app.factory('userFactory', userFactory);

function userFactory() {

    var userInitialValueSettings = {
        UserId: '',
        FullName: '',
        Location: '',
        Phone: '',
        Ext: '',
        Fax: '',
        Email: '',
        IsExternalUser: false,
        Password: '',
        UserMustChangePassword: true,
        PasswordNeverExpires: false,
        IsAllowLogon:true,
        PreferredDatabase:'',
        FileServer:'',
        SecuredDocServer:'',
        UserNos:0,
        UserNum:0,
        UserIdEx: '',

        FailedLogin: '',
        DistName: '',
        UserDomain: '',
        ExchAutoDiscover: '',
        LastEdited: '',
        PasswordChangeDate: '',
        LastSyncDate: '',
        DateAccountLocked: '',
        PasswordChangeDate:''
    }
  

    var validationSettings = {
        showMessage: false,
        confirmationPassword: ''
    }

    var returnUserInitialValueSettings = function(){
        return angular.copy(userInitialValueSettings);
    }

    var returnUserValidationSettings = function(){
        return angular.copy(validationSettings);
    }

    return {
        userInitailValues: returnUserInitialValueSettings,
        validations: returnUserValidationSettings
    }
}