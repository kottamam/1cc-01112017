﻿app.factory('classFactory', classFactory);

function classFactory() {

    var classInitialValueSettings = {
        Description: '',
        Alias: '',
        RetainDays: 365,
        Security: 'PUBLIC',
        SubclassRequired: false,
        HIPAACompliant: false,
        Echo: false,
        ParentClass: '',
        FieldRequired:0
    }

    var classGeneralValuesSettings = {
        PopupTitle: ''
    }

    var validationSettings = {
        showMessage: false,
        showInformationMessage: false,
        serverResponse: false
    }

    var returnClassInitialValueSettings = function () {
        return angular.copy(classInitialValueSettings);
    }

    var returnUserValidationSettings = function () {
        return angular.copy(validationSettings);
    }

    var returnBindClassValues = function (classValues) {
        return angular.copy({
            Description: classValues.Description,
            Alias: classValues.Alias,
            RetainDays: classValues.RetainDays,
            Security: classValues.Security,
            SubclassRequired: classValues.SubclassRequired,
            HIPAACompliant: classValues.HIPAACompliant,
            Echo: classValues.Echo,
            FieldRequired: classValues.FieldRequired
        })
    }

    var initializeModelTabFun = function () {
        $("#addClassModelBody>.nav-tabs>li").removeClass("active in");
        $("#addClassModelBody>.tab-content>.tab-pane").removeClass("active in");
        $("#addClassModelBody>.nav-tabs>li:first").addClass("active in");
        $('#defaults_tab').addClass("active in");
        $('#cboSecurity').selectpicker('val', 'Public');
    }

    return {
        classInitailValues: returnClassInitialValueSettings,
        validations: returnUserValidationSettings,
        generalSettings: classGeneralValuesSettings,
        bindClassValues: returnBindClassValues,
        initializeModelTab: initializeModelTabFun
    }
}