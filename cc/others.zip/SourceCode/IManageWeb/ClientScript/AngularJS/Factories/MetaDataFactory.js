﻿app.factory('metaDataFactory', metaDataFactory);

function metaDataFactory() {

    var metaDataInitialValueSettings = {
        Alias :'',
        Description:'',
        HIPAAComplaint :false,
        EnableFlag :true,
        ParentAlias:'',
        GrandParentAlias: '',
        ShowEditButton:false
    }

    var returnMetaDataInitialValueSettings = function () {
        return angular.copy(metaDataInitialValueSettings);
    }

    return {
        meatDataInitialValues: returnMetaDataInitialValueSettings
    }
}