﻿app.factory('databasesFactory', databasesFactory);

function databasesFactory() {

    var databasesInitialValueSettings = {
        DatabaseName: '',
        Description: '',
        
    }

    var returnDatabasesInitialValueSettings = function () {
        return angular.copy(databasesInitialValueSettings);
    }

    return {
        databasesInitialValues: returnDatabasesInitialValueSettings
    }
}