﻿app.factory('securityTemplateFactory', securityTemplateFactory);

function securityTemplateFactory() {

    var templateInitialValueSettings = {
        TemplateName: '',
        Description: '',
        DefaultSecurity: '',
        PermissionList: []
    }

    var validationSettings = {
        showMessage: false
    }

    var returnTemplateInitialValueSettings = function () {
        return angular.copy(templateInitialValueSettings);
    }

    var returnTemplateValidationSettings = function () {
        return angular.copy(validationSettings);
    }

    return {
        templateInitailValues: returnTemplateInitialValueSettings,
        validations: returnTemplateValidationSettings
    }
}