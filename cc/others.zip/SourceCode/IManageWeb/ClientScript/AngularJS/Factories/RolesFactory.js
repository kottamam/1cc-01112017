﻿app.factory('rolesFactory', rolesFactory);

function rolesFactory() {

    var rolesInitialValueSettings = {
        RoleName: '',
        Description: '',
        RoleIsExternal: false,
        SelectedPrivileges: [],
        RemovedPrivileges: [],
        SelectedMembers: [],
        RemovedMembers: [],
        ProfileInfo: []
    };

    var rolesDBModelInitialValueSettings = {
        RoleName: '',
        Description: '',
        Privileges: '',
        IsExternal: false,
        ContentAndFolderOperationList: [],
        AdministrativeOperationList: [],
        WebOperationsList: [],
        RoleProfileModelList: []
    };

    var roleProfileModel = {
        RoleName: '',
        ProfileId: '',
        SearchValue: '',
        SetValue: '',
        SearchAccess: '',
        SetAccess: '',
        Profile:[]
    };

    var returnRolesInitialValueSettings = function () {
        return angular.copy(rolesInitialValueSettings);
    }

    var returnrolesDBModelInitialValueSettings = function () {
        return angular.copy(rolesDBModelInitialValueSettings);
    }

    var returnRoleProfileModel = function () {
        return angular.copy(roleProfileModel);
    }

    return {
        rolesInitialValues: returnRolesInitialValueSettings,
        dbRoleModelInitialValues: returnrolesDBModelInitialValueSettings,
        roleProfileModelInitialValues: returnRoleProfileModel
    }
}