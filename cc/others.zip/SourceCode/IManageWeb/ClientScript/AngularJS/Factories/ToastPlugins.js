﻿//app.factory('toastPlugins', toastPlugins);
//toastPlugins.$inject = ['toastrConfig'];

//function toastPlugins(toastrConfig) {

//    var toastOptionSettings = {
//        autoDismiss: false,
//        position: 'toast-top-center',
//        type: 'success',
//        timeout: '5000',
//        extendedTimeout: '1000',
//        html: false,
//        closeButton: true,
//        tapToDismiss: true,
//        progressBar: true,
//        closeHtml: '<button>&times;</button>',
//        newestOnTop: true,
//        maxOpened: 0,
//        preventDuplicates: false,
//        preventOpenDuplicates: false
//    };

//    var toastOptionWatchCollectionSettings = function (newValue) {
//        //toastrConfig.autoDismiss = newValue.autoDismiss;
//        //toastrConfig.allowHtml = newValue.html;
//        //toastrConfig.extendedTimeOut = parseInt(newValue.extendedTimeout, 10);
//        toastrConfig.positionClass = newValue.position;
//        //toastrConfig.timeOut = parseInt(newValue.timeout, 10);
//        toastrConfig.closeButton = newValue.closeButton;
//        //toastrConfig.tapToDismiss = newValue.tapToDismiss;
//        toastrConfig.progressBar = newValue.progressBar;
//        //toastrConfig.closeHtml = newValue.closeHtml;
//        toastrConfig.newestOnTop = newValue.newestOnTop;
//        //toastrConfig.maxOpened = newValue.maxOpened;
//        //toastrConfig.preventDuplicates = newValue.preventDuplicates;
//        //toastrConfig.preventOpenDuplicates = newValue.preventOpenDuplicates;
//        //if (newValue.customTemplate) {
//        //    toastrConfig.templates.toast = 'custom';
//        //} else {
//        //    toastrConfig.templates.toast = 'directives/toast/toast.html';
//        //}
//    };

//    return {
//        toastOptions: toastOptionSettings,
//        toastOptionWatchCollection: toastOptionWatchCollectionSettings
//    }
//}