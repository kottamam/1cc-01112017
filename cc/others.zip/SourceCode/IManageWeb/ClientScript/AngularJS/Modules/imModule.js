﻿//var app = angular.module('iManage', ['datatables', 'ui.bootstrap', 'ngRoute', 'toastr', 'ngTable', 'ngMaterial', 'ngMessages', 'material.svgAssetsCache']);
//app.config([
//  '$httpProvider', function ($httpProvider) {
//      return $httpProvider.interceptors.push('sessionTimeoutInterceptor');
//  }
//]);
var app = angular.module('iManage', ['ngMaterial', 'common.directives', 'ngAnimate', 'ui.router', 'ngAria', 'md.data.table', 'material.svgAssetsCache', 'ngTable', 'ngMessages']);
angular.module('common.services', []);
angular.module('common.directives', ['common.services']);

(function () {
    app.config(function ($mdThemingProvider) {
        $mdThemingProvider.theme('default')
          .primaryPalette('light-blue', {
              'default': '300'
          })
          .accentPalette('deep-orange', {
              'default': '500'
          });
    })
})();

(function () {
    app.config([
  '$httpProvider', function ($httpProvider) {
      return $httpProvider.interceptors.push('sessionTimeoutInterceptor');
  }
    ]);
})();

(function () {
    app.run(['$rootScope', '$log', '$timeout', function ($rootScope, $log, $timeout) {
        $rootScope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState, fromParams) {
              if (toState.name === 'home.user' ||
                  toState.name === 'home.group' ||
                  toState.name === 'home.roles' ||
                  toState.name === 'home.metadata' ||
                  toState.name === 'home.class') {
                  $timeout(function () {
                      $rootScope.$broadcast('InitializeTabContents');
                      $log.info("State changed from : " + fromState.name + ", to:" + toState.name);
                  });
              }
          })
    }]);
})();