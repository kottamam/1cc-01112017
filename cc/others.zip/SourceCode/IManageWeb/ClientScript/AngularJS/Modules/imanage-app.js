var iManageApp = angular.module('iManageApp', ['ngMaterial', 'common.directives', 'ngAnimate', 'ui.router', 'ngAria', 'md.data.table', 'material.svgAssetsCache', 'ngTable']);
angular.module('common.services', []);
angular.module('common.directives', ['common.services']);
var app = iManageApp;
(function () {    
    iManageApp.config(function ($mdThemingProvider) {
    $mdThemingProvider.theme('default')
      .primaryPalette('light-blue', {
          'default': '300'
      })
      .accentPalette('deep-orange', {
          'default': '500'
      });
})
})();

(function () {
    iManageApp.config([
  '$httpProvider', function ($httpProvider) {
      return $httpProvider.interceptors.push('sessionTimeoutInterceptor');
  }
    ]);
})();
  











