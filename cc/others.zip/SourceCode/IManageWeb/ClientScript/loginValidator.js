﻿$('#divValidation').hide();
$(document).ready(function () {
    $('input#checkbox2').click(function () {
        $(".url_link").toggle();
    });
});
function validateLogin() {
    if ($('#authModel_UserName').val().length == 0) {
        $('#divValidation').show();
        $('#divValidation').text('Please enter user name');
        return false;
    }
    else if ($('#authModel_Password').val().length == 0) {
        $('#divValidation').show();
        $('#divValidation').text('Please enter password');
        return false;
    }
    else if ($('#authModel_WhiteRabitUrl').val().length == 0) {
        $('#divValidation').show();
        $('#divValidation').text('Please enter api url');
        return false;
    }
    else {
        $('#divValidation').text("");
        $('#divValidation').hide();
    }
    return true;
}