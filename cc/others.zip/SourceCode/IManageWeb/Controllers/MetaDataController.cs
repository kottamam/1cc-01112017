﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using IManageWeb.CoreInterface.Model;
using IManageWeb.CoreInterface.Contract;
using IManageWeb.CoreInterface.Services;
using Newtonsoft.Json;
using System.Collections;

namespace IManageWeb.Controllers
{
    [IManageWeb.App_Start.SessionExpire]
    public class MetaDataController : Controller
    {
        private IMetaDataContract iMetaDataContract;

        public MetaDataController()
        {
            iMetaDataContract = new MetaDataService();
        }

        [HttpGet]
        [ActionName("List")]
        public string GetCaptions(string libraryName)
        {

            try
            {
                AjaxModel metaModels = iMetaDataContract.GetCaptions(libraryName,
                    new AuthenticationModel
                    {
                        DomainName = Convert.ToString(Session["Domain"]),
                        Password = Convert.ToString(Session["Password"]),
                        UserName = Convert.ToString(Session["UserName"]),
                        WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                    }, Convert.ToString(Session["AuthToken"]));

                return JsonConvert.SerializeObject(metaModels);
            }
            catch { return ""; }

        }


        [HttpGet]
        public string GetMetaDataList(string searchModelJSONString, string metaType)
        {
            try
            {
                IManageWeb.CoreInterface.Model.SerachModel searchModel = null;
                if (string.IsNullOrEmpty(metaType))
                {
                    return "";
                }
                else
                {
                    searchModel = JsonConvert.DeserializeObject<IManageWeb.CoreInterface.Model.SerachModel>(searchModelJSONString);
                    AjaxModel MetaDataModels = iMetaDataContract.getMetaData(searchModel.libraryName,
                        new AuthenticationModel
                        {
                            DomainName = Convert.ToString(Session["Domain"]),
                            Password = Convert.ToString(Session["Password"]),
                            UserName = Convert.ToString(Session["UserName"]),
                            WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                        }, Convert.ToString(Session["AuthToken"]), searchModel.pagenumber, searchModel.pageLength, searchModel.isTotal, searchModel.searchText, metaType, "", "",searchModel.filters);

                    return JsonConvert.SerializeObject(MetaDataModels);
                }
            }
            catch { return ""; }
        }

        //[HttpPost]
        //[ActionName("AddSub")]
        //public string addSubMetaData(string libraryName, MetaDataModel metaDataDetails, string MetaType)
        //{
        //    try
        //    {
        //        //AuthenticationEntity authEntity = generateAuthEntity(authenticationModel);
        //        //AppSetupBL appsBL = new AppSetupBL();
        //        //ManagementTabAPIEntity<AppSetupEntity> appSetupEntities = appsBL.addAppsSetup(libraryName, authEntity, authenticationModel.WhiteRabitUrl, AuthKey,
        //        //    new AppSetupEntity
        //        //    {
        //        //        DDE = appSetupModel.DDE,
        //        //        DDEAppName = appSetupModel.DDEAppName,
        //        //        DDEOpen = appSetupModel.DDEOpen,
        //        //        DDEPRint = appSetupModel.DDEPRint,
        //        //        DDEPrintandExitApp = appSetupModel.DDEPrintandExitApp,
        //        //        DDEReadOpen = appSetupModel.DDEReadOpen,
        //        //        DDETopic = appSetupModel.DDETopic,
        //        //        IntegrationMode = appSetupModel.IntegrationMode,
        //        //        Location = appSetupModel.Location,
        //        //        Name = appSetupModel.Name,
        //        //        Primary = appSetupModel.Primary,
        //        //        Type = appSetupModel.Type

        //        //    });


        //        //return GenerateAjaxModal(appSetupEntities);
        //        //metaDataDetails.ParentAlias = ParentData;
        //        AjaxModel MetaDataModels = iMetaDataContract.addCustomData(libraryName,
        //          new AuthenticationModel
        //          {
        //              DomainName = Convert.ToString(Session["Domain"]),
        //              Password = Convert.ToString(Session["Password"]),
        //              UserName = Convert.ToString(Session["UserName"]),
        //              WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
        //          }, Convert.ToString(Session["AuthToken"]), metaDataDetails, MetaType);

        //        return JsonConvert.SerializeObject(MetaDataModels); 


        //    }
        //    catch { return ""; }
        //}

        [HttpPost]
        [ActionName("Add")]
        public string addMetaData(string libraryName, MetaDataModel metaDataDetails, string MetaType, string selParentAlias)
        {
            try
            {
                if (!string.IsNullOrEmpty(selParentAlias))
                {
                    metaDataDetails.ParentAlias = selParentAlias;

                }
                AjaxModel MetaDataModels = iMetaDataContract.addCustomData(libraryName,
                  new AuthenticationModel
                  {
                      DomainName = Convert.ToString(Session["Domain"]),
                      Password = Convert.ToString(Session["Password"]),
                      UserName = Convert.ToString(Session["UserName"]),
                      WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                  }, Convert.ToString(Session["AuthToken"]), metaDataDetails, MetaType);

                return JsonConvert.SerializeObject(MetaDataModels);
            }
            catch { return ""; }
        }

        [HttpPost]
        [ActionName("Edit")]
        public string editMetaData(string libraryName, MetaDataModel metaDataDetails, string MetaType, string selParentAlias)
        {
            try
            {
                // metaDataDetails.ParentAlias = ParentData;
                if (!string.IsNullOrEmpty(selParentAlias))
                {
                    metaDataDetails.ParentAlias = selParentAlias;
                }
                AjaxModel MetaDataModels = iMetaDataContract.editCustomData(libraryName,
                  new AuthenticationModel
                  {
                      DomainName = Convert.ToString(Session["Domain"]),
                      Password = Convert.ToString(Session["Password"]),
                      UserName = Convert.ToString(Session["UserName"]),
                      WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                  }, Convert.ToString(Session["AuthToken"]), metaDataDetails, MetaType);

                return JsonConvert.SerializeObject(MetaDataModels);

            }
            catch { return ""; }
        }


        public string GetSubMetaDataList(string searchModelJSONString, string MetaType, string selParentAlias)
        {
            try
            {
                IManageWeb.CoreInterface.Model.SerachModel requestmodel = JsonConvert.DeserializeObject<IManageWeb.CoreInterface.Model.SerachModel>(searchModelJSONString);
                if (string.IsNullOrEmpty(MetaType))
                {
                    return "";
                }
                else
                {
                    string SubMetaType = "";
                    if (MetaType.Equals("CUSTOM1"))
                    {
                        SubMetaType = "CUSTOM2";
                    }
                    else
                    {
                        SubMetaType = "CUSTOM30";
                    }
                    AjaxModel MetaDataModels = iMetaDataContract.getMetaData(requestmodel.libraryName,
                       new AuthenticationModel
                       {
                           DomainName = Convert.ToString(Session["Domain"]),
                           Password = Convert.ToString(Session["Password"]),
                           UserName = Convert.ToString(Session["UserName"]),
                           WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                       }, Convert.ToString(Session["AuthToken"]), requestmodel.pagenumber, requestmodel.pageLength, requestmodel.isTotal, requestmodel.searchText, MetaType, SubMetaType, selParentAlias, requestmodel.filters);

                    return JsonConvert.SerializeObject(MetaDataModels);

                }
            }
            catch { return ""; }
        }

        [HttpPost]
        [ActionName("Delete")]
        public string DeleteMetaDataItem(string libraryName, string metadataItem, string metaType)
        {
            try
            {
                AjaxModel MetaDataModels = iMetaDataContract.DeleteCustomData(libraryName, Convert.ToString(Session["RestUrl"]), Convert.ToString(Session["AuthToken"]),
                    metaType, metadataItem);
                return JsonConvert.SerializeObject(MetaDataModels);
            }
            catch { return ""; }
        }

        [HttpPost]
        [ActionName("DeleteSubItem")]
        public string DeleteSubMetaDataItem(string libraryName, string metadataItem, string parentItem, string metaType)
        {
            try
            {
                string SubMetaType = "";
                if (metaType.Equals("CUSTOM1"))
                {
                    SubMetaType = "CUSTOM2";
                }
                else
                {
                    SubMetaType = "CUSTOM30";
                }
                AjaxModel MetaDataModels = iMetaDataContract.DeleteChildCustomData(libraryName, Convert.ToString(Session["RestUrl"]),
                    Convert.ToString(Session["AuthToken"]), SubMetaType, metadataItem, parentItem);

                return JsonConvert.SerializeObject(MetaDataModels);
            }
            catch { return ""; }
        }
    }
}