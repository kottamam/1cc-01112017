﻿using IManageWeb.CoreInterface.Model;
using IManageWeb.CoreInterface.Contract;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace IManageWeb.Controllers
{
    [IManageWeb.App_Start.SessionExpire]
    public class AppSetupController : Controller
    {
        private IAppSetupContract appSetupContract;

        public AppSetupController()
        {
            appSetupContract = new IManageWeb.CoreInterface.Services.AppSetupServices();
        }

        // GET: AppSetup
        public ActionResult Index()
        {
            return View();
        }

        public string GetAppSetupList(string libraryName, int offset, int limit, bool total, string searchText)
        {
            try
            {
                AjaxModel appsModels = appSetupContract.getAppSetups(libraryName,
                    new AuthenticationModel
                    {
                        DomainName = Convert.ToString(Session["Domain"]),
                        Password = Convert.ToString(Session["Password"]),
                        UserName = Convert.ToString(Session["UserName"]),
                        WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                    }, Convert.ToString(Session["AuthToken"]), offset, limit, total,searchText);

                return JsonConvert.SerializeObject(appsModels);
            }
            catch { return ""; }
        }

        [HttpPost]
        public string DeleteAppSetup(string AppSetups)
        {
            if (string.IsNullOrEmpty(AppSetups) || AppSetups == "[]")
                return "";
            return "success";
        }

        [HttpPost]
        [ActionName("Add")]
        public string addAppSetup(string libraryName, AppSetupModel appsetupDetails)
        {
            try
            {

                AjaxModel appsModels = appSetupContract.addAppsSetup(libraryName,
                   new AuthenticationModel
                   {
                       DomainName = Convert.ToString(Session["Domain"]),
                       Password = Convert.ToString(Session["Password"]),
                       UserName = Convert.ToString(Session["UserName"]),
                       WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                   }, Convert.ToString(Session["AuthToken"]), appsetupDetails);
              
                return JsonConvert.SerializeObject(appsModels); 
            }
            catch { return ""; }
        }

        [HttpPost]
        [ActionName("Edit")]
        public string editAppSetup(string libraryName, AppSetupModel appSetupModel)
        {
            try
            {

                AjaxModel appsModels = appSetupContract.editAppsSetup(libraryName,
                 new AuthenticationModel
                 {
                     DomainName = Convert.ToString(Session["Domain"]),
                     Password = Convert.ToString(Session["Password"]),
                     UserName = Convert.ToString(Session["UserName"]),
                     WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                 }, Convert.ToString(Session["AuthToken"]), appSetupModel);
              
                return JsonConvert.SerializeObject(appsModels); 
            }
            catch { return ""; }
        }

    }
}