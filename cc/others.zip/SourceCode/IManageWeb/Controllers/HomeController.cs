﻿using System;
using System.Collections.Generic;
using System.Web.Mvc;
using IManageWeb.CoreInterface.Contract;
using IManageWeb.CoreInterface.Services;
using IManageWeb.CoreInterface.Model;
using System.Web.Security;
using Newtonsoft.Json;

namespace IManageWeb.Controllers
{
    [IManageWeb.App_Start.SessionExpire]
    public class HomeController : Controller
    {
        IUserContract userContract = null;
        public HomeController()
        {
            userContract = new UserServices();
        }
        //
        // GET: /Home/
        public ActionResult Index()
        {
            if (Session["UserName"] == null)
            {
                return RedirectToAction("Index", "Login");
            }

            return View();
        }


        public ActionResult HeaderPartialView()
        {
            ViewBag.UserName = Session["UserName"];
            return PartialView("HeaderPartialView");
        }


        [HttpGet]
        public string getUserPermission(string libraryName)
        {

            try
            {
                List<UserAppsModel> userAppsModels = userContract.getUserApps(libraryName,
                    new AuthenticationModel
                    {
                        DomainName = "",
                        Password = Convert.ToString(Session["Password"]),
                        UserName = Convert.ToString(Session["UserName"]),
                        WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                    }, Convert.ToString(Session["AuthToken"]));
                return JsonConvert.SerializeObject(userAppsModels);
            }
            catch { return ""; }

            /* UserModel  userModel= userContract.GetUser(Convert.ToString(Session["UserName"]), Convert.ToString(Session["RestUrl"]));
             if (userModel.groupModel.Count > 0) 
             {
                 if (userModel.groupModel.Exists(r=>r.GroupId.Equals("NRTADMIN")))
                 { 
                   return "true";
                 }
             }
             return "false"; */
        }

        public ActionResult LogOut()
        {
            Session.Abandon();
            FormsAuthentication.SignOut();
            return RedirectToAction("Index", "Login");
        }

        [HttpGet]
        [ActionName("DBLibraries")]
        public string getLibraryNameList()
        {
            try
            {
                List<DMSModel> dmsModel = new List<DMSModel>();
                IDMSContract dmsService = new DMSService();

                AuthenticationModel authMode = new AuthenticationModel
                {
                    DomainName = "",
                    Password = Convert.ToString(Session["Password"]),
                    UserName = Convert.ToString(Session["UserName"]),
                    WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                };

                dmsModel = dmsService.getDMSList(authMode, Convert.ToString(Session["AuthToken"]));
                return JsonConvert.SerializeObject(dmsModel);
            }
            catch { return ""; }
        }
    }
}