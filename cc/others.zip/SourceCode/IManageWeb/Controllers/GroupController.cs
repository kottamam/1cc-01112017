﻿using Newtonsoft.Json;
using System;
using System.Web.Mvc;
using IManageWeb.CoreInterface.Model;
using IManageWeb.CoreInterface.Contract;
using IManageWeb.CoreInterface.Services;
using System.Collections.Generic;
using System.Collections;

namespace IManageWeb.Controllers
{
    [IManageWeb.App_Start.SessionExpire]
    public class GroupController : Controller
    {
        IGroupContract groupContract = null;
        public GroupController()
        {
            groupContract = new GroupServices();
        }
        // GET: Group HeaderPartial 
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public string GetGroups(string searchModelJSONString)
        {
            IManageWeb.CoreInterface.Model.SerachModel searchModel = null;
            try
            {
                searchModel = JsonConvert.DeserializeObject<IManageWeb.CoreInterface.Model.SerachModel>(searchModelJSONString);
                //AjaxModel groupsModels = groupContract.getGroups(searchModel.libraryName,
                //    new AuthenticationModel
                //    {
                //        DomainName = Convert.ToString(Session["Domain"]),
                //        Password = Convert.ToString(Session["Password"]),
                //        UserName = Convert.ToString(Session["UserName"]),
                //        WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                //    }, Convert.ToString(Session["AuthToken"]), searchModel.Cursor, searchModel.pageLength, searchModel.searchText);

                AjaxModel groupsModels = groupContract.getGroups(searchModel,
                    new AuthenticationModel
                    {
                        DomainName = Convert.ToString(Session["Domain"]),
                        Password = Convert.ToString(Session["Password"]),
                        UserName = Convert.ToString(Session["UserName"]),
                        WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                    }, Convert.ToString(Session["AuthToken"]));


                return JsonConvert.SerializeObject(groupsModels);
            }
            catch { return ""; }
        }

        [HttpGet]
        [ActionName("GroupDetails")]
        public string GetGroupDetails(string libraryName, string groupAlias)
        {
            try
            {
                AjaxModel groupsModels = groupContract.getGroup(libraryName, new AuthenticationModel
                    {
                        DomainName = Convert.ToString(Session["Domain"]),
                        Password = Convert.ToString(Session["Password"]),
                        UserName = Convert.ToString(Session["UserName"]),
                        WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                    }, Convert.ToString(Session["AuthToken"]), groupAlias);
                return JsonConvert.SerializeObject(groupsModels);

                // return "{\"GroupID\":\"NRTADMIN\",\"GroupNumber\":\"NRTADMIN06521\",\"FullName\":\"NRT ADMIN\", \"OSType\": \"WinNT\", \"DisguishedName\" : \"Disguished Name\", \"Domain\": \"\", \"SyncID\": \"1245\", \"LastSync\": \"03/08/2016 04:10:15\"}";
            }
            catch
            {
                return "";
            }
        }

        [HttpPost]
        [ActionName("Add")]
        public string addGroups(string libraryName, GroupModel groupModel)
        {
            AjaxModel groupAddModels = null;

            try
            {
                groupAddModels = groupContract.addGroup(libraryName,
                  new AuthenticationModel
                  {
                      DomainName = Convert.ToString(Session["Domain"]),
                      Password = Convert.ToString(Session["Password"]),
                      UserName = Convert.ToString(Session["UserName"]),
                      WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                  }, Convert.ToString(Session["AuthToken"]), groupModel);

                return JsonConvert.SerializeObject(groupAddModels);
            }
            catch
            {
                groupAddModels = new AjaxModel
                {
                    Message = "Group add faild due to some unknown error.",
                    Status = false
                };
                return JsonConvert.SerializeObject(groupAddModels);
            }
        }

        [HttpPost]
        [ActionName("Edit")]
        public string editGroup(string libraryName, GroupModel groupModel)
        {
            AjaxModel groupAddModels = null;
            try
            {
                groupAddModels = groupContract.edit(libraryName,
                  new AuthenticationModel
                  {
                      DomainName = Convert.ToString(Session["Domain"]),
                      Password = Convert.ToString(Session["Password"]),
                      UserName = Convert.ToString(Session["UserName"]),
                      WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                  }, Convert.ToString(Session["AuthToken"]), groupModel);

                return JsonConvert.SerializeObject(groupAddModels);
            }
            catch
            {
                groupAddModels = new AjaxModel
                {
                    Message = "Group edit faild due to some unknown error.",
                    Status = false
                };
                return JsonConvert.SerializeObject(groupAddModels);
            }
        }

        [HttpPost]
        public string DeleteGroup(string GroupNames)
        {
            if (string.IsNullOrEmpty(GroupNames) || GroupNames == "[]")
                return "";
            return "success";
        }

        [ActionName("Copy")]
        public string copyGroup(string libraryName, string fromGroupId, GroupModel toGroupModel)
        {
            AjaxModel groupAddModels = null;
            try
            {
                groupAddModels = groupContract.copyGroup(libraryName,
                  new AuthenticationModel
                  {
                      DomainName = Convert.ToString(Session["Domain"]),
                      Password = Convert.ToString(Session["Password"]),
                      UserName = Convert.ToString(Session["UserName"]),
                      WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                  }, Convert.ToString(Session["AuthToken"]), fromGroupId, toGroupModel);

                return JsonConvert.SerializeObject(groupAddModels);
            }
            catch
            {
                groupAddModels = new AjaxModel
                {
                    Status = false,
                    Message = "Groups coping faild due to some unknown error."
                };
                return JsonConvert.SerializeObject(groupAddModels);
            }
        }

        [ActionName("Reassign")]
        public string reassignSecurity(string libraryName, string fromGroupId, string toGroupId)
        {
            AjaxModel ajaxModel = null;
            try
            {
                ajaxModel = groupContract.reassignGroupSecurityObject(libraryName,
                  new AuthenticationModel
                  {
                      DomainName = Convert.ToString(Session["Domain"]),
                      Password = Convert.ToString(Session["Password"]),
                      UserName = Convert.ToString(Session["UserName"]),
                      WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                  }, Convert.ToString(Session["AuthToken"]), fromGroupId, toGroupId);

                return JsonConvert.SerializeObject(ajaxModel);
            }
            catch
            {
                ajaxModel = new AjaxModel
                {
                    Status = false,
                    Message = "Reassign group security object faild due to some unknown error!!!"
                };
                return JsonConvert.SerializeObject(ajaxModel);
            }
        }

        public string GetAllGroupList(string libraryName)
        {
            try
            {
                AjaxModel groupsModels = groupContract.getAllGroupList(libraryName,
                    new AuthenticationModel
                    {
                        DomainName = Convert.ToString(Session["Domain"]),
                        Password = Convert.ToString(Session["Password"]),
                        UserName = Convert.ToString(Session["UserName"]),
                        WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                    }, Convert.ToString(Session["AuthToken"]));

                return JsonConvert.SerializeObject(groupsModels);
            }
            catch { return ""; }
        }

        [HttpPost]
        [ActionName("AddRemoveUserGroup")]
        public string addRemoveUserGroup(string libraryName, string userId, string addedGroupNameListString, string deletedGroupNameListString)
        {
            try
            {
                System.Web.Script.Serialization.JavaScriptSerializer jSerialize;
                jSerialize = new System.Web.Script.Serialization.JavaScriptSerializer();

                List<GroupModel> addedGroupModel = null;
                List<GroupModel> deletedGroupmodel = null;

                UserModel userModel = new UserModel { UserId = userId };

                if (addedGroupNameListString.Trim().Length > 0)
                    addedGroupModel = jSerialize.Deserialize<List<GroupModel>>(addedGroupNameListString);
                if (deletedGroupNameListString.Trim().Length > 0)
                    deletedGroupmodel = jSerialize.Deserialize<List<GroupModel>>(deletedGroupNameListString);

                AjaxModel groupAddModels = groupContract.AddRemoveUserFromGroup(libraryName,
                             new AuthenticationModel
                             {
                                 DomainName = Convert.ToString(Session["Domain"]),
                                 Password = Convert.ToString(Session["Password"]),
                                 UserName = Convert.ToString(Session["UserName"]),
                                 WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                             }, Convert.ToString(Session["AuthToken"]), userModel, addedGroupModel, deletedGroupmodel);


                //AjaxModel groupAddModels = groupContract.addGroup(libraryName,
                //    new AuthenticationModel
                //    {
                //        DomainName = Convert.ToString(Session["Domain"]),
                //        Password = Convert.ToString(Session["Password"]),
                //        UserName = Convert.ToString(Session["UserName"]),
                //        WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                //    }, Convert.ToString(Session["AuthToken"]), null);

                return JsonConvert.SerializeObject(groupAddModels);
            }
            catch { return ""; }
        }

        public string GetUserGroupList(string libraryName, string userId)
        {
            try
            {
                UserModel userModel = new UserModel { UserId = userId };
                AjaxModel groupsModels = groupContract.getGroupsofUser(libraryName,
                    new AuthenticationModel
                    {
                        DomainName = Convert.ToString(Session["Domain"]),
                        Password = Convert.ToString(Session["Password"]),
                        UserName = Convert.ToString(Session["UserName"]),
                        WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                    }, Convert.ToString(Session["AuthToken"]), userModel);

                return JsonConvert.SerializeObject(groupsModels);
            }
            catch { return ""; }
        }

        public string getAllGroupsInUser(string libraryName, string user)
        {
            try
            {
                UserModel userModel = new UserModel();
                userModel.UserId = user;
                AjaxModel groups = groupContract.getGroupsofUser(libraryName,
                     new AuthenticationModel
                    {
                        DomainName = Convert.ToString(Session["Domain"]),
                        Password = Convert.ToString(Session["Password"]),
                        UserName = Convert.ToString(Session["UserName"]),
                        WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                    }, Convert.ToString(Session["AuthToken"]), userModel);
                return JsonConvert.SerializeObject(groups);
            }
            catch { return ""; }
        }

        [HttpPost]
        public string AddGroupsToUser(string libraryName, string userId, string users)
        {
            try
            {

                AjaxModel ajaxModel = new AjaxModel();
                ajaxModel.page = 1;
                ajaxModel.records = 1;
                ajaxModel.total = 1;


                ajaxModel.rows = new List<Ajax>();

                Ajax ajdo = new Ajax();
                ajdo.id = 1;
                ajdo.cell = new ArrayList();
                ajdo.cell.Add("Not Implemented");//0
                ajaxModel.rows.Add(ajdo);
                return JsonConvert.SerializeObject(ajaxModel);
            }
            catch { return ""; }
        }



        [HttpPost]
        public string EnableDisableGroup(string libraryName, string groups, bool isEnable)
        {
            try
            {
                System.Web.Script.Serialization.JavaScriptSerializer jSerialize;
                jSerialize = new System.Web.Script.Serialization.JavaScriptSerializer();
                List<GroupModel> GroupModels = jSerialize.Deserialize<List<GroupModel>>(groups);
                AjaxModel groupsmodel = groupContract.EnableDisableGroup(libraryName,
                     new AuthenticationModel
                    {
                        DomainName = Convert.ToString(Session["Domain"]),
                        Password = Convert.ToString(Session["Password"]),
                        UserName = Convert.ToString(Session["UserName"]),
                        WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                    }, Convert.ToString(Session["AuthToken"]), GroupModels, isEnable);

                return JsonConvert.SerializeObject(groupsmodel);
            }
            catch { return ""; }
        }


        public string GetSelectedGroupsOfUsers(string libraryName, string userName, string[] groupNames)
        {
            try
            {
                GroupModel[] groups = new GroupModel[groupNames.Length];
                int i = 0;
                foreach (string groupname in groupNames)
                {
                    groups[i] = new GroupModel { GroupName = groupname };
                    i++;
                }

                AjaxModel userModel = groupContract.GetSelectedGroupsOfUsers(libraryName, new AuthenticationModel
                {
                    DomainName = Convert.ToString(Session["Domain"]),
                    Password = Convert.ToString(Session["Password"]),
                    UserName = Convert.ToString(Session["UserName"]),
                    WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                }, Convert.ToString(Session["AuthToken"]), userName, groups);

                return JsonConvert.SerializeObject(userModel);
            }
            catch { return ""; }
        }
    }
}