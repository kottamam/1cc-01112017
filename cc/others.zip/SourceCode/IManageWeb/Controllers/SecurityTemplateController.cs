﻿using Newtonsoft.Json;
using System;
using System.Web.Mvc;
using IManageWeb.CoreInterface.Model;
using IManageWeb.CoreInterface.Contract;
using IManageWeb.CoreInterface.Services;
using System.Collections.Generic;

namespace IManageWeb.Controllers
{
    [IManageWeb.App_Start.SessionExpire]
    public class SecurityTemplateController : Controller
    {
        ISecurityTemplateContract securityTemplateContract;

        public SecurityTemplateController()
        {

        }

        // GET: SecurityTemplate
        public ActionResult Index()
        {
            return View();
        }

        public string GetList(string libraryName, int pageNo, int pageLength, bool isReadTotalCount)
        {
            AjaxModel templateModelList = null;
            try
            {
                securityTemplateContract = new SecurityTemplateService(Convert.ToString(Session["AuthToken"]),
                                        new AuthenticationModel
                                        {
                                            DomainName = Convert.ToString(Session["Domain"]),
                                            Password = Convert.ToString(Session["Password"]),
                                            UserName = Convert.ToString(Session["UserName"]),
                                            WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                                        });
                templateModelList = this.securityTemplateContract.getSecurityTemplateList(libraryName, pageNo, pageLength, isReadTotalCount);
                return JsonConvert.SerializeObject(templateModelList);
            }
            catch { return ""; }
        }

        public string GetServiceList(string searchModelJSONString)
        {
            AjaxModel templateModelList = null;
            IManageWeb.CoreInterface.Model.SerachModel requestModel = null;
            try
            {
                requestModel = JsonConvert.DeserializeObject<IManageWeb.CoreInterface.Model.SerachModel>(searchModelJSONString);
                securityTemplateContract = new SecurityTemplateService(Convert.ToString(Session["AuthToken"]),
                                        new AuthenticationModel
                                        {
                                            DomainName = Convert.ToString(Session["Domain"]),
                                            Password = Convert.ToString(Session["Password"]),
                                            UserName = Convert.ToString(Session["UserName"]),
                                            WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                                        });
                templateModelList = this.securityTemplateContract.getSecurityTemplateList(requestModel.libraryName, requestModel.pagenumber, requestModel.pageLength, requestModel.isTotal);
                return JsonConvert.SerializeObject(templateModelList);
            }
            catch { return ""; }
        }

        public string GetByName(string libraryName, string templateName)
        {
            SecurityTemplateModel securityTemplateModel = null;
            try
            {
                securityTemplateContract = new SecurityTemplateService(Convert.ToString(Session["AuthToken"]),
                                        new AuthenticationModel
                                        {
                                            DomainName = Convert.ToString(Session["Domain"]),
                                            Password = Convert.ToString(Session["Password"]),
                                            UserName = Convert.ToString(Session["UserName"]),
                                            WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                                        });
                securityTemplateModel = this.securityTemplateContract.getSecurityTemplate(libraryName, templateName);
                return JsonConvert.SerializeObject(securityTemplateModel);
            }
            catch { return ""; }
        }

        [HttpGet]
        public string GetUserTemplate(string libraryName, string userId)
        {
            SecurityTemplateModel securityTemplateModel = null;
            try
            {
                securityTemplateContract = new SecurityTemplateService(Convert.ToString(Session["AuthToken"]),
                                        new AuthenticationModel
                                        {
                                            DomainName = Convert.ToString(Session["Domain"]),
                                            Password = Convert.ToString(Session["Password"]),
                                            UserName = Convert.ToString(Session["UserName"]),
                                            WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                                        });
                securityTemplateModel = this.securityTemplateContract.getUserSecurityTemplate(libraryName, userId);
                return JsonConvert.SerializeObject(securityTemplateModel);
            }
            catch { return ""; }
        }

        [HttpPost]
        public string Save(string libraryName, SecurityTemplateModel templateModel, bool isEditMode)
        {
            string strRes = "";
            //SecurityTemplateModel securityTemplateModel = null;
            try
            {
                //securityTemplateModel=
                securityTemplateContract = new SecurityTemplateService(Convert.ToString(Session["AuthToken"]),
                                        new AuthenticationModel
                                        {
                                            DomainName = Convert.ToString(Session["Domain"]),
                                            Password = Convert.ToString(Session["Password"]),
                                            UserName = Convert.ToString(Session["UserName"]),
                                            WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                                        });
                strRes = this.securityTemplateContract.addSecurityTemplate(libraryName, templateModel);
                return strRes;
            }
            catch { return ""; }
        }
    }
}