﻿using IManageWeb.CoreInterface.Contract;
using IManageWeb.CoreInterface.Model;
using IManageWeb.CoreInterface.Services;
using IManageWeb.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace IManageWeb.Controllers
{
    public class NetworkLoginController : Controller
    {
         IUserContract userService = null;

         public NetworkLoginController()
        {
            userService = new UserServices();
        }
        //
        // GET: /Login/
        public ActionResult Index()
        {

            LoginViewModel loginVM = new LoginViewModel { authModel = new AuthenticationModel { WhiteRabitUrl = ConfigurationManager.AppSettings["RestApiUrl"] } };
            return View(loginVM);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [AllowAnonymous]
        public ActionResult Index(LoginViewModel loginViewModel)
        {
             
           AjaxModel ajaxREsponse = userService.ValidateUser(loginViewModel.authModel);
            ViewBag.ErrorMessage = "";
            if (Convert.ToBoolean(ajaxREsponse.rows[0].cell[0]))
            {
                //ViewBag. 
                Session["AuthToken"] = ajaxREsponse.rows[0].cell[1];
                Session["UserName"] = loginViewModel.authModel.UserName;
                Session["RestUrl"] = loginViewModel.authModel.WhiteRabitUrl;
                Session["Password"] = loginViewModel.authModel.Password;
                Session["Domain"] = loginViewModel.authModel.DomainName;

                System.Web.Security.FormsAuthentication.SetAuthCookie(loginViewModel.authModel.UserName, false);
                return RedirectToAction("Index", "Home");
            }
            int errcode = 0;
            int.TryParse(Convert.ToString(ajaxREsponse.rows[0].cell[2]),out errcode);
            if (errcode == 404)
            {
                ViewBag.ErrorMessage = "You don't have sufficient privilege to access IManage Control Center. Please Contact Administrator";
            }
            else
            {
                ViewBag.ErrorMessage = "The username and password you entered is invalid.";
            }
            return View("Index");
        }

        [HttpPost]
        public ActionResult ValidateUser(LoginViewModel loginViewModel)
        {
         
         
            AjaxModel ajaxREsponse = userService.ValidateUser(loginViewModel.authModel);
            ViewBag.ErrorMessage = "";
            if (Convert.ToBoolean(ajaxREsponse.rows[0].cell[0]))
            {
                //ViewBag. 
                Session["AuthToken"] = ajaxREsponse.rows[0].cell[1];
                Session["UserName"] = loginViewModel.authModel.UserName;
                Session["RestUrl"] = loginViewModel.authModel.WhiteRabitUrl;
                Session["Password"] = loginViewModel.authModel.Password;
                Session["Domain"] = loginViewModel.authModel.DomainName;

                System.Web.Security.FormsAuthentication.SetAuthCookie(loginViewModel.authModel.UserName, false);
                return RedirectToAction("Index", "Home");
            }
            ViewBag.ErrorMessage = "The username and password you entered is invalid.";
            return View("Index");
        }
    }
}