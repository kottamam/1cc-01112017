﻿using System;
using System.Web.Mvc;
using IManageWeb.CoreInterface.Contract;
using IManageWeb.CoreInterface.Services;
using IManageWeb.CoreInterface.Model;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Collections;

namespace IManageWeb.Controllers
{
    public class RolesController : Controller
    {
        IRolesContract roleContract = null;
        public RolesController()
        {
            roleContract = new RoleServices();

        }
        //
        // GET: /Roles/
        public ActionResult Index()
        {
            return View();
        }

        public string GetRoles(string searchModelJSONString) // libraryName, int offset, int limit, bool total, string searchText
        {
            //try
            //{
            //    IManageWeb.CoreInterface.Model.SerachModel searchModel = JsonConvert.DeserializeObject<IManageWeb.CoreInterface.Model.SerachModel>(searchModelJSONString);
            //    AjaxModel rolesModels = roleContract.getRoles(searchModel.libraryName,
            //        new AuthenticationModel
            //        {
            //            DomainName = Convert.ToString(Session["Domain"]),
            //            Password = Convert.ToString(Session["Password"]),
            //            UserName = Convert.ToString(Session["UserName"]),
            //            WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
            //        }, Convert.ToString(Session["AuthToken"]), searchModel.pagenumber, searchModel.pageLength, searchModel.isTotal, searchModel.searchText);

            //    return JsonConvert.SerializeObject(rolesModels);
            //}
            //catch { return ""; }

            try
            {
                IManageWeb.CoreInterface.Model.SerachModel searchModel = JsonConvert.DeserializeObject<IManageWeb.CoreInterface.Model.SerachModel>(searchModelJSONString);
                AjaxModel rolesModels = roleContract.getRoles(searchModel, Convert.ToString(Session["RestUrl"]), Convert.ToString(Session["AuthToken"]));

                return JsonConvert.SerializeObject(rolesModels);
            }
            catch { return ""; }
        }

        [HttpGet]
        public string GetRole(string libraryName, string roleName)
        {
            try
            {
                RoleModel rolesModel = roleContract.getRole(libraryName,
                    new AuthenticationModel
                    {
                        DomainName = Convert.ToString(Session["Domain"]),
                        Password = Convert.ToString(Session["Password"]),
                        UserName = Convert.ToString(Session["UserName"]),
                        WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                    }, Convert.ToString(Session["AuthToken"]), roleName);

                return JsonConvert.SerializeObject(rolesModel);
            }
            catch { return ""; }
        }

        [HttpPost]
        public string DeleteRoles(string libraryName, string roleModelJSON)
        {
            RoleModel roleModel = null;

            try
            {
                roleModel = JsonConvert.DeserializeObject<RoleModel>(roleModelJSON);

                return "";
            }
            catch { return ""; }
        }

        [HttpGet]
        [ActionName("Captions")]
        public string GetCaptions(string libraryName)
        {

            try
            {
                AjaxModel metaModels = roleContract.GetCaptions(libraryName,
                    new AuthenticationModel
                    {
                        DomainName = Convert.ToString(Session["Domain"]),
                        Password = Convert.ToString(Session["Password"]),
                        UserName = Convert.ToString(Session["UserName"]),
                        WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                    }, Convert.ToString(Session["AuthToken"]));

                return JsonConvert.SerializeObject(metaModels);
            }
            catch { return ""; }

        }

        [HttpPost]
        [ActionName("Add")]
        public string add(string libraryName, RoleModel roleModel, UserModel[] SelectedUsers)
        {
            try
            {
                string strResult = roleContract.addRole(libraryName,
                    new AuthenticationModel
                    {
                        DomainName = Convert.ToString(Session["Domain"]),
                        Password = Convert.ToString(Session["Password"]),
                        UserName = Convert.ToString(Session["UserName"]),
                        WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                    }, Convert.ToString(Session["AuthToken"]), roleModel, SelectedUsers);

                return strResult;
            }
            catch { return ""; }
        }

        [HttpPost]
        [ActionName("Edit")]
        public string edit(string libraryName, RoleModel roleModel, UserModel[] SelectedUsers, UserModel[] deletedMembers)
        {
            try
            {
                string strResult = roleContract.editRole(libraryName,
                    new AuthenticationModel
                    {
                        DomainName = Convert.ToString(Session["Domain"]),
                        Password = Convert.ToString(Session["Password"]),
                        UserName = Convert.ToString(Session["UserName"]),
                        WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                    }, Convert.ToString(Session["AuthToken"]), roleModel, SelectedUsers, deletedMembers);

                return strResult;
            }
            catch { return ""; }
        }

        [ActionName("Copy")]
        public string copyRole(string libraryName, string fromRoleName, string toRoleName)
        {
            AjaxModel resultAjaxModel = null;
            try
            {
                resultAjaxModel = roleContract.copyRole(libraryName,
                    new AuthenticationModel
                    {
                        DomainName = Convert.ToString(Session["Domain"]),
                        Password = Convert.ToString(Session["Password"]),
                        UserName = Convert.ToString(Session["UserName"]),
                        WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                    }, Convert.ToString(Session["AuthToken"]), fromRoleName, toRoleName);

                return JsonConvert.SerializeObject(resultAjaxModel);
            }
            catch
            {
                resultAjaxModel = new AjaxModel
                {
                    Status = false,
                    Message = "Role coping faild due to some unknown error!!!"
                };
                return JsonConvert.SerializeObject(resultAjaxModel);
            }
        }
    }
}