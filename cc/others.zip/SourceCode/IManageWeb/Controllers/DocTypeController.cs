﻿using System;
using System.Web.Mvc;
using IManageWeb.CoreInterface.Contract;
using IManageWeb.CoreInterface.Services;
using IManageWeb.CoreInterface.Model;
using Newtonsoft.Json;

namespace IManageWeb.Controllers
{
    [IManageWeb.App_Start.SessionExpire]
    public class DocTypeController : Controller
    {
        IDocTypeContract docTypeContract;
        //
        // GET: /DocType/
        public DocTypeController()
        {
            docTypeContract = new DocTypeServices();

        }


        //
        // GET: /DocType/
        public ActionResult Index()
        {
            return View();
        }

        public string getDocTypes(string libraryName, int offset, int limit, bool total, string searchText)
        {
            try
            {
                AjaxModel docTypeModels = docTypeContract.getDocTypes(libraryName, Convert.ToString(Session["RestUrl"]), Convert.ToString(Session["AuthToken"]),
                    offset, limit, total, searchText);
                return JsonConvert.SerializeObject(docTypeModels);
            }
            catch { return ""; }
        }

		[HttpPost]
        [ActionName("Add")]
        public string addDocTypes(string libraryName, DocTypeModel docTypeModel)
        {
            try
            {
                AjaxModel docAddModels = docTypeContract.addDocTypes(libraryName,
                    new AuthenticationModel
                    {
                        DomainName = Convert.ToString(Session["Domain"]),
                        Password = Convert.ToString(Session["Password"]),
                        UserName = Convert.ToString(Session["UserName"]),
                        WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                    }, Convert.ToString(Session["AuthToken"]), docTypeModel);

                return JsonConvert.SerializeObject(docAddModels);
            }
            catch { return ""; }
        }


        [HttpPost]
        public string DeleteDocType(string DocTypeNames)
        {
            if (string.IsNullOrEmpty(DocTypeNames) || DocTypeNames == "[]")
                return "";
            return "success";
        }


        [HttpPost]
        [ActionName("Edit")]
        public string UpdateDocTypes(string libraryName, DocTypeModel docTypeModel)
        {
            try
            {
                AjaxModel docAddModels = docTypeContract.UpdateDocTypes(libraryName,
                    new AuthenticationModel
                    {
                        DomainName = Convert.ToString(Session["Domain"]),
                        Password = Convert.ToString(Session["Password"]),
                        UserName = Convert.ToString(Session["UserName"]),
                        WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                    }, Convert.ToString(Session["AuthToken"]), docTypeModel);

                return JsonConvert.SerializeObject(docAddModels);
            }
            catch { return ""; }
        }

    }
}