﻿using IManageWeb.App_Start;
using IManageWeb.CoreInterface.Contract;
using IManageWeb.CoreInterface.Model;
using IManageWeb.CoreInterface.Services;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Web.Mvc;

namespace IManageWeb.Controllers
{
    [SessionExpire]
    public class UserController : Controller
    {
        IUserContract userContract;

        public UserController()
        {
            userContract = new UserServices();
           
        }

        // GET: User
        public ActionResult Index()
        {
            return View();
        }

        public string GetUsers(string searchModelJSONString, bool isInternalOnly)
        {
            IManageWeb.CoreInterface.Model.SerachModel requestModel = null;
            try
            {
               
                requestModel = JsonConvert.DeserializeObject<IManageWeb.CoreInterface.Model.SerachModel>(searchModelJSONString);
              

                AjaxModel users = userContract.getUsers(requestModel, Convert.ToString(Session["RestUrl"]), Convert.ToString(Session["AuthToken"]));
                return JsonConvert.SerializeObject(users);
            }
            catch { return ""; }
        }

        public string GetAllUserList(string libraryName, string searchText)
        {
            try
            {
                AjaxModel users = userContract.getAllUserList(libraryName, Convert.ToString(Session["RestUrl"]), Convert.ToString(Session["AuthToken"]), searchText);
                return JsonConvert.SerializeObject(users);
            }
            catch { return ""; }
        }

        public string GetAllUsersInRole(string searchModelJSONString, string roleName)
        {
            try
            {
                IManageWeb.CoreInterface.Model.SerachModel searchModel = null;
                searchModel = JsonConvert.DeserializeObject<IManageWeb.CoreInterface.Model.SerachModel>(searchModelJSONString);
                AjaxModel users = userContract.GetUsersInRole(searchModel.libraryName, Convert.ToString(Session["RestUrl"]), Convert.ToString(Session["AuthToken"]), searchModel.pagenumber, searchModel.pageLength, searchModel.isTotal, searchModel.searchText, roleName);
             
                return JsonConvert.SerializeObject(users);
            }
            catch { return ""; }
        }

        public string getRoleLessUsers(string searchModelJSONString)
        {
            try
            {
                IManageWeb.CoreInterface.Model.SerachModel searchModel = null;
                searchModel = JsonConvert.DeserializeObject<IManageWeb.CoreInterface.Model.SerachModel>(searchModelJSONString);
                AjaxModel users = userContract.GetRolelessUsers(searchModel.libraryName, Convert.ToString(Session["RestUrl"]), Convert.ToString(Session["AuthToken"]), searchModel.pagenumber, searchModel.pageLength, searchModel.isTotal, searchModel.searchText);

                return JsonConvert.SerializeObject(users);
            }
            catch { return ""; }
        }


        
        [HttpPost]
        [ActionName("Add")]
        public string addUsers(string libraryName, UserModel userDetails, string groupDetails)
        {
            AjaxModel userModels = null;

            try
            {
               // string IP = ((HttpContextBase)Request.Properties["MS_HttpContext"]).Request.UserHostAddress;
                //string ipAddress = Request.ServerVariables["REMOTE_ADDR"];

	 

    //string ipAddress2 = Request.UserHostAddress;

                List<IManageWeb.CoreInterface.Model.GroupModel> gModel = null;
                gModel = JsonConvert.DeserializeObject<List<IManageWeb.CoreInterface.Model.GroupModel>>(groupDetails);
                userModels = userContract.addUser(libraryName,(AuthenticationModel)Session["Auth"], Convert.ToString(Session["AuthToken"]), userDetails, gModel);

                return JsonConvert.SerializeObject(userModels);
            }
            catch
            {
                userModels = new AjaxModel
                {
                    Message = "Group edit faild due to some unknown error.",
                    Status = false
                };
                return JsonConvert.SerializeObject(userModels);
            }
        }

        [HttpPost]
        [ActionName("Edit")]
        public string editUser(string libraryName, UserModel userDetail)
        {
            AjaxModel userModels = null;
            try
            {
                userModels = userContract.editUser(libraryName,
                 (AuthenticationModel)Session["Auth"], Convert.ToString(Session["AuthToken"]), userDetail);

                return JsonConvert.SerializeObject(userModels);
            }
            catch
            {
                userModels = new AjaxModel
                {
                    Message = "Group edit faild due to some unknown error.",
                    Status = false
                };
                return JsonConvert.SerializeObject(userModels);
            }
        }

        [HttpPost]
        public string AddUsersToRole(string libraryName, string roleName,string users,string removedusers)
        {
              try
            {

                List<IManageWeb.CoreInterface.Model.UserModel> usermodel = null;
                usermodel = JsonConvert.DeserializeObject<List<IManageWeb.CoreInterface.Model.UserModel>>(users);

                List<IManageWeb.CoreInterface.Model.UserModel> removedusermodel = null;
                removedusermodel = JsonConvert.DeserializeObject<List<IManageWeb.CoreInterface.Model.UserModel>>(removedusers);


                   IRolesContract  roleContract;


                   roleContract = new RoleServices();

                   AjaxModel removeajaxModel = roleContract.RemoveUserFromRole(libraryName, Convert.ToString(Session["RestUrl"]), Convert.ToString(Session["AuthToken"]), removedusermodel, roleName);

                   AjaxModel ajaxModel = roleContract.AddUserToRole(libraryName, Convert.ToString(Session["RestUrl"]), Convert.ToString(Session["AuthToken"]),usermodel,roleName);

                   return JsonConvert.SerializeObject(ajaxModel);
                   
                  
            }
              catch { return ""; }
        }
        [HttpPost]
        public string DeleteUser(string UserIds)
        {
            if (string.IsNullOrEmpty(UserIds) || UserIds == "[]")
                return "";
            return "success";
        }

        [HttpPost]
        public string ResetPassword(string libraryName, UserModel[] userDetail)
        {
            AjaxModel userModels = null;
            try
            {
                List<UserModel> users = new List<UserModel>();
                foreach (UserModel user in userDetail)
                {
                    users.Add(user);
                }
                userModels = userContract.ResetPasswordProperties(libraryName,
                 (AuthenticationModel)Session["Auth"], Convert.ToString(Session["AuthToken"]), users);

                return JsonConvert.SerializeObject(userModels);

            }
            catch
            {
                userModels = new AjaxModel
                {
                    Message = "Reset password due to some unknown error.",
                    Status = false
                };
                return JsonConvert.SerializeObject(userModels);
            }
        }

        public string GetAllUsersInGroup(string userrequestModel, string groupName)
        {
            try
            {


                IManageWeb.CoreInterface.Model.SerachModel searchModel = JsonConvert.DeserializeObject<IManageWeb.CoreInterface.Model.SerachModel>(userrequestModel);
                AjaxModel users = userContract.GetUsersInGroup(searchModel.libraryName, (AuthenticationModel)Session["Auth"], Convert.ToString(Session["AuthToken"]), groupName, searchModel.Cursor, searchModel.pageLength, searchModel.searchText);
                
                return JsonConvert.SerializeObject(users);
            }
            catch { return ""; }
        }

        public string GetAllSelectedUsersFromTheList(string libraryName, string groupName, string[] userList)
        {
            try
            {
                UserModel[] users = new UserModel[userList.Length];
                int i = 0;
                foreach (string user in userList) 
                {
                    users[i] = new UserModel { UserId = user };
                    i++;
                }

                AjaxModel userModel = userContract.GetSelectedUsersinGroup(libraryName, (AuthenticationModel)Session["Auth"], Convert.ToString(Session["AuthToken"]), groupName, users);

                 return JsonConvert.SerializeObject(userModel);
            }
            catch { return ""; }
        }


        [HttpPost]
        [ActionName("AddRemoveGroupUser")]
        public string addRemoveGroupUser(string libraryName, string groupName, string addedUserIdListString, string deletedUserIdListString)
        {
            try
            {
                System.Web.Script.Serialization.JavaScriptSerializer jSerialize;
                jSerialize = new System.Web.Script.Serialization.JavaScriptSerializer();

                List<UserModel> addedUserModel = null;
                List<UserModel> deletedUserModel = null;

                GroupModel groupModel = new GroupModel { GroupName = groupName };

                if (addedUserIdListString.Trim().Length > 0)
                    addedUserModel = jSerialize.Deserialize<List<UserModel>>(addedUserIdListString);
                if (deletedUserIdListString.Trim().Length > 0)
                    deletedUserModel = jSerialize.Deserialize<List<UserModel>>(deletedUserIdListString);
                
                AjaxModel groupAddModels = userContract.AssignReassignUser(libraryName,
                            (AuthenticationModel)Session["Auth"], Convert.ToString(Session["AuthToken"]), groupModel, addedUserModel, deletedUserModel);

                

                return JsonConvert.SerializeObject(groupAddModels);
                //return "";
            }
            catch { return ""; }
        }


        [HttpPost]
        public string LockUnlockAccounts(string libraryName, string accounts, bool IsUnlock)
        {
            try
            {
                AjaxModel userModels = null;
                System.Web.Script.Serialization.JavaScriptSerializer jSerialize;
                jSerialize = new System.Web.Script.Serialization.JavaScriptSerializer();
                List<UserModel> addedUserModel = null;
                if (accounts.Trim().Length > 0)
                    addedUserModel = jSerialize.Deserialize<List<UserModel>>(accounts);

                userModels = userContract.LockUnlockUsers(libraryName,
               (AuthenticationModel)Session["Auth"], Convert.ToString(Session["AuthToken"]), addedUserModel, IsUnlock);

                return JsonConvert.SerializeObject(userModels);

                
            }
            catch { return ""; }
        }

        [HttpGet]
        [ActionName("DBLibraries")]
        public string getLibraryNameList(string userName)
        {
            try
            {
                List<DMSModel> dmsModel = new List<DMSModel>();
                IDMSContract dmsService = new DMSService();

                //AuthenticationModel authMode = new AuthenticationModel
                //{
                //    DomainName = "",
                //    Password = Convert.ToString(Session["Password"]),
                //    UserName = userName,
                //    WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                //};
                AuthenticationModel authMode = (AuthenticationModel)Session["Auth"];

                dmsModel = dmsService.getDMSList(authMode, Convert.ToString(Session["AuthToken"]));
                return JsonConvert.SerializeObject(dmsModel);
            }
            catch { return ""; }
        }


        [HttpPost]
        [ActionName("AssignSecurity")]
        public string assignSecurityTemplate(string libraryName, string userId, string oldTemplateName,string newTemplateName)
        {
            AjaxModel ajaxModel = null;
            try
            {
                ajaxModel = userContract.assignSecurityTemplate(libraryName,
                  (AuthenticationModel)Session["Auth"], Convert.ToString(Session["AuthToken"]), userId, oldTemplateName, newTemplateName);

                return JsonConvert.SerializeObject(ajaxModel);
            }
            catch
            {
                ajaxModel = new AjaxModel
                {
                    Status = false,
                    Message = "User Security assign failed."
                };
                return JsonConvert.SerializeObject(ajaxModel);
            }
        }

        [HttpPost]
        [ActionName("RenameUser")]
        public string rename(string libraryName, string oldUserId, string newUserId)
        {
            AjaxModel ajaxModel = null;
            try
            {
                ajaxModel = userContract.renameUser(libraryName,
                   new AuthenticationModel
                   {
                       DomainName = Convert.ToString(Session["Domain"]),
                       Password = Convert.ToString(Session["Password"]),
                       UserName = Convert.ToString(Session["UserName"]),
                       WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                   }, Convert.ToString(Session["AuthToken"]), oldUserId, newUserId);

                return JsonConvert.SerializeObject(ajaxModel);
            }
            catch
            {
                ajaxModel = new AjaxModel
                {
                    Status = false,
                    Message = "Rename User failed."
                };
                return JsonConvert.SerializeObject(ajaxModel);
            }
        }
    }
}