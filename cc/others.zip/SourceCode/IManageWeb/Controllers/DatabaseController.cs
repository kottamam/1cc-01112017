﻿using Newtonsoft.Json;
using System;
using System.Web.Mvc;
using IManageWeb.CoreInterface.Model;
using IManageWeb.CoreInterface.Contract;
using IManageWeb.CoreInterface.Services;
using System.Collections.Generic;
using System.Collections;

namespace IManageWeb.Controllers
{
    [IManageWeb.App_Start.SessionExpire]
    public class DatabaseController : Controller
    {
        IDMSContract dmsContract;


        IDMSContract dmsTemplateContract;

        public DatabaseController()
        {
            dmsTemplateContract = new DMSService();
        }

        //
        // GET: /Database/
        public ActionResult Index()
        {
            return View();
        }
        public string GetDatabases(string searchModelJSONString)
        {
            IManageWeb.CoreInterface.Model.SerachModel searchModel = null;
            try
            {
                searchModel = JsonConvert.DeserializeObject<IManageWeb.CoreInterface.Model.SerachModel>(searchModelJSONString);
                dmsContract = new DMSService();

                AjaxModel databaseModels = dmsContract.getDatabaseList(searchModel.libraryName, new AuthenticationModel
                    {
                        DomainName = Convert.ToString(Session["Domain"]),
                        Password = Convert.ToString(Session["Password"]),
                        UserName = Convert.ToString(Session["UserName"]),
                        WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                    }, Convert.ToString(Session["AuthToken"]), searchModel.Cursor, searchModel.pageLength, searchModel.searchText);

                return JsonConvert.SerializeObject(databaseModels);
            }
            catch { return ""; }
        }
        [HttpPost]
        [ActionName("Add")]
        public string addDatabases(string libraryName, DMSModel dmsModel)
        {
            try
            {
                AjaxModel databaseModels = dmsTemplateContract.addDataBase(libraryName, new AuthenticationModel
                {
                    DomainName = Convert.ToString(Session["Domain"]),
                    Password = Convert.ToString(Session["Password"]),
                    UserName = Convert.ToString(Session["UserName"]),
                    WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                }, Convert.ToString(Session["AuthToken"]), dmsModel);

                return JsonConvert.SerializeObject(databaseModels);
               
            }
            catch { return ""; }
        }
        [ActionName("Edit")]
        public string editDatabases(string libraryName, DMSModel dmsModel)
        {
            try
            {
                AjaxModel  dmsModels = dmsTemplateContract.UpdateDataBase(libraryName, new AuthenticationModel
                {
                    DomainName = Convert.ToString(Session["Domain"]),
                    Password = Convert.ToString(Session["Password"]),
                    UserName = Convert.ToString(Session["UserName"]),
                    WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                }, Convert.ToString(Session["AuthToken"]), dmsModel);

                return JsonConvert.SerializeObject(dmsModels);

              
               
            }
            catch { return ""; }
        }


	}
}