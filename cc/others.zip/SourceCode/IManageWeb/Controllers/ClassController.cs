﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using IManageWeb.CoreInterface.Model;
using IManageWeb.CoreInterface.Services;
using IManageWeb.CoreInterface.Contract;
using Newtonsoft.Json;

namespace IManageWeb.Controllers
{
    [IManageWeb.App_Start.SessionExpire]
    public class ClassController : Controller
    {

        private IClassContract classContract;

        public ClassController()
        {
            classContract = new ClassServices();
        }

        [HttpPost]
        [ActionName("List")]
        public string ClassList(string searchModelJSONString)
        {
            IManageWeb.CoreInterface.Model.SerachModel searchModel = null;
            try
            {
                searchModel = JsonConvert.DeserializeObject<IManageWeb.CoreInterface.Model.SerachModel>(searchModelJSONString);

                AjaxModel classModels = classContract.getClasses(searchModel, Convert.ToString(Session["RestUrl"]), Convert.ToString(Session["AuthToken"]));

                return JsonConvert.SerializeObject(classModels);
            }
            catch { return ""; }
        }

        [ActionName("Add")]
        public string addClass(string libraryName, ClassModel classModel, List<int> requiredFieldsList)
        {
            AjaxModel classModels = null;
            try
            {
                if (requiredFieldsList != null)
                {
                    classModel.RequiredFields = requiredFieldsList.ToArray<int>();
                }
                else
                {
                    classModel.RequiredFields = new int[0];
                }
                classModels = classContract.addClasses(libraryName, new AuthenticationModel
              {
                  DomainName = Convert.ToString(Session["Domain"]),
                  Password = Convert.ToString(Session["Password"]),
                  UserName = Convert.ToString(Session["UserName"]),
                  WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
              }, Convert.ToString(Session["AuthToken"]), classModel);

                return JsonConvert.SerializeObject(classModels);

            }
            catch
            {
                classModels = new AjaxModel
                {
                    Message = "Class adding faild due to some unknown error.",
                    Status = false
                };
                return JsonConvert.SerializeObject(classModels);
            }
        }

        [ActionName("Edit")]
        public string editClass(string libraryName, ClassModel classModel, List<int> requiredFieldsList)
        {
            AjaxModel classModels = null;
            try
            {
                if (requiredFieldsList == null)
                {
                    requiredFieldsList = new List<int>();
                    requiredFieldsList.Add(0);
                }
                if (requiredFieldsList != null)
                    classModel.RequiredFields = requiredFieldsList.ToArray<int>();

                classModels = classContract.editClasses(libraryName, new AuthenticationModel
                              {
                                  DomainName = Convert.ToString(Session["Domain"]),
                                  Password = Convert.ToString(Session["Password"]),
                                  UserName = Convert.ToString(Session["UserName"]),
                                  WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                              }, Convert.ToString(Session["AuthToken"]), classModel);
                return JsonConvert.SerializeObject(classModels);
            }
            catch
            {
                classModels = new AjaxModel
                {
                    Message = "Class editing faild due to some unknown error.",
                    Status = false
                };
                return JsonConvert.SerializeObject(classModels);
            }
        }

        public string EditSubClass(string libraryName, ClassModel classModel, List<int> requiredFieldsList, string ParentClass)
        {
            try
            {
                if (requiredFieldsList != null)
                {
                    classModel.RequiredFields = requiredFieldsList.ToArray<int>();
                }
                else
                {
                    classModel.RequiredFields = new int[0];
                }

                AjaxModel classModels = classContract.editSubClasses(libraryName, new AuthenticationModel
                {
                    DomainName = Convert.ToString(Session["Domain"]),
                    Password = Convert.ToString(Session["Password"]),
                    UserName = Convert.ToString(Session["UserName"]),
                    WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                }, Convert.ToString(Session["AuthToken"]), classModel, ParentClass);

                return JsonConvert.SerializeObject(classModels);


            }
            catch { return ""; }
        }

        [HttpPost]
        [ActionName("SubClassList")]
        public string SubClassList(string searchModelJSONString, string classAlias)
        {
            IManageWeb.CoreInterface.Model.SerachModel searchModel = null;
            try
            {
                searchModel = JsonConvert.DeserializeObject<IManageWeb.CoreInterface.Model.SerachModel>(searchModelJSONString);
                AjaxModel classModels = new AjaxModel();
                if (string.IsNullOrEmpty(classAlias))
                {
                    classModels = classContract.getAllSubClasses(searchModel.libraryName,
                         new AuthenticationModel
                         {
                             DomainName = Convert.ToString(Session["Domain"]),
                             Password = Convert.ToString(Session["Password"]),
                             UserName = Convert.ToString(Session["UserName"]),
                             WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                         }, Convert.ToString(Session["AuthToken"]), searchModel.pagenumber, searchModel.pageLength, searchModel.isTotal, searchModel.searchText);
                }
                else
                {
                    classModels = classContract.getSubClasses(searchModel, Convert.ToString(Session["RestUrl"]), Convert.ToString(Session["AuthToken"]), classAlias);
                }
                return JsonConvert.SerializeObject(classModels);
            }
            catch { return ""; }
        }

        [HttpPost]
        [ActionName("Delete")]
        public string deleteClass(string libraryName, ClassModel classModel)
        {
            return "";
        }

        [HttpPost]
        [ActionName("SubClassDelete")]
        public string deleteSubClass(string libraryName, ClassModel classModel, string ParentClass)
        {
            return "";
        }


        public string AddSubClass(string libraryName, ClassModel classModel, List<int> requiredFieldsList, string ParentClass)
        {
            AjaxModel classModels = null;
            try
            {
                if (requiredFieldsList != null)
                {
                    classModel.RequiredFields = requiredFieldsList.ToArray<int>();
                }
                else
                {
                    classModel.RequiredFields = new int[0];
                }
                classModels = classContract.addSubClasses(libraryName, new AuthenticationModel
                {
                    DomainName = Convert.ToString(Session["Domain"]),
                    Password = Convert.ToString(Session["Password"]),
                    UserName = Convert.ToString(Session["UserName"]),
                    WhiteRabitUrl = Convert.ToString(Session["RestUrl"])
                }, Convert.ToString(Session["AuthToken"]), classModel, ParentClass);

                return JsonConvert.SerializeObject(classModels);

            }
            catch
            {
                classModels = new AjaxModel
                {
                    Message = "Sub Class adding faild due to some unknown error.",
                    Status = false
                };
                return JsonConvert.SerializeObject(classModels);
            }
        }
    }
}