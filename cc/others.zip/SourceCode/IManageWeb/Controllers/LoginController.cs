﻿using System.Web.Mvc;
using IManageWeb.Models;
using IManageWeb.CoreInterface.Contract;
using IManageWeb.CoreInterface.Services;
using System.Configuration;
using IManageWeb.CoreInterface.Model;
using System;

namespace IManageWeb.Controllers
{
    public class LoginController : Controller
    {

        IUserContract userService = null;

        public LoginController()
        {
            userService = new UserServices();
        }
        //
        // GET: /Login/
        public ActionResult Index()
        {

            LoginViewModel loginVM = new LoginViewModel { authModel = new AuthenticationModel { WhiteRabitUrl = ConfigurationManager.AppSettings["RestApiUrl"] } };
            return View(loginVM);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [AllowAnonymous]
        public ActionResult Index(LoginViewModel loginViewModel)
        {
             
           AjaxModel ajaxREsponse = userService.ValidateUser(loginViewModel.authModel);
            ViewBag.ErrorMessage = "";
            ViewBag.ErrorMessage = "";
           // string ipAddress = Request.ServerVariables["REMOTE_ADDR"];



           // string ipAddress2 = Request.UserHostAddress;
            AuthenticationModel authModel = new AuthenticationModel();
            if (Convert.ToBoolean(ajaxREsponse.rows[0].cell[0]))
            {
                //ViewBag. 
                Session["AuthToken"] = ajaxREsponse.rows[0].cell[1];
                Session["UserName"] = loginViewModel.authModel.UserName;
                Session["RestUrl"] = loginViewModel.authModel.WhiteRabitUrl;
                Session["Password"] = loginViewModel.authModel.Password;
                Session["Domain"] = loginViewModel.authModel.DomainName;
                authModel.DomainName = loginViewModel.authModel.DomainName;
                authModel.AuthKey = Convert.ToString(ajaxREsponse.rows[0].cell[1]);
                authModel.IpAddress = Request.UserHostAddress;
                authModel.Password = loginViewModel.authModel.Password;
                authModel.UserName = loginViewModel.authModel.UserName;
                authModel.WhiteRabitUrl = loginViewModel.authModel.WhiteRabitUrl;
                Session["Auth"] = authModel;
                System.Web.Security.FormsAuthentication.SetAuthCookie(loginViewModel.authModel.UserName, false);
                return RedirectToAction("Index", "Home");
            }
            int errcode = 0;
            int.TryParse(Convert.ToString(ajaxREsponse.rows[0].cell[2]),out errcode);
            if (errcode == 404)
            {
                ViewBag.ErrorMessage = "You don't have sufficient privilege to access IManage Control Center. Please Contact Administrator";
            }
            else
            {
                ViewBag.ErrorMessage = "The username and password you entered is invalid.";
            }
            return View("Index");
        }

        [HttpPost]
        public ActionResult ValidateUser(LoginViewModel loginViewModel)
        {
         
         
            AjaxModel ajaxREsponse = userService.ValidateUser(loginViewModel.authModel);
            ViewBag.ErrorMessage = "";
            //string ipAddress = Request.ServerVariables["REMOTE_ADDR"];


            AuthenticationModel authModel = new AuthenticationModel();
            //string ipAddress2 = Request.UserHostAddress;
            if (Convert.ToBoolean(ajaxREsponse.rows[0].cell[0]))
            {
                //ViewBag. 
                Session["AuthToken"] = ajaxREsponse.rows[0].cell[1];
                Session["UserName"] = loginViewModel.authModel.UserName;
                Session["RestUrl"] = loginViewModel.authModel.WhiteRabitUrl;
                Session["Password"] = loginViewModel.authModel.Password;
                Session["Domain"] = loginViewModel.authModel.DomainName;
                authModel.DomainName = loginViewModel.authModel.DomainName;
                authModel.AuthKey = Convert.ToString(ajaxREsponse.rows[0].cell[1]);
                authModel.IpAddress = Request.UserHostAddress;
                authModel.Password = loginViewModel.authModel.Password;
                authModel.UserName = loginViewModel.authModel.UserName;
                authModel.WhiteRabitUrl = loginViewModel.authModel.WhiteRabitUrl;
                Session["Auth"] = authModel;
                System.Web.Security.FormsAuthentication.SetAuthCookie(loginViewModel.authModel.UserName, false);
                return RedirectToAction("Index", "Home");
            }
            ViewBag.ErrorMessage = "The username and password you entered is invalid.";
            return View("Index");
        }
    }
}