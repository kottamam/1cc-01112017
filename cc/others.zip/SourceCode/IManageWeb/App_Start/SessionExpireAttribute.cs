﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace IManageWeb.App_Start
{
    public class SessionExpireAttribute : AuthorizeAttribute
    {
        protected override void HandleUnauthorizedRequest(AuthorizationContext filterContext)
        {
            filterContext.HttpContext.Response.StatusCode = 401;
            filterContext.Result = new JsonResult
            {
                Data = new
                {
                    message = "Your session has expired. Please login again."
                },
                JsonRequestBehavior = JsonRequestBehavior.AllowGet
            };
            filterContext.HttpContext.Response.SuppressFormsAuthenticationRedirect = true;
        }
    }
}