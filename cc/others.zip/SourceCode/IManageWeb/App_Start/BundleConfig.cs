﻿using System.Web.Optimization;

namespace IManageWeb
{
    public class BundleConfig
    {
        public static void RegisterBundles(BundleCollection bundles)
        {
            //bundles.Add(new StyleBundle("~/Content/bootstrap")
            //    .Include(
            //        "~/Content/bootstrap.css",
            //        "~/Content/bootstrap-datetimepicker.css",
            //        "~/Content/bootstrap-select.css",
            //        "~/Content/bootstrap-check-radio.css"
            //        ));

            //bundles.Add(new StyleBundle("~/Content/font-awesome")
            //.Include("~/Content/font-awesome.css"));

          //  bundles.Add(new StyleBundle("~/Content/open-sans")
          //.Include("~/Content/open-sans.css", new CssRewriteUrlTransform()));

            //bundles.Add(new StyleBundle("~/Content/style")
            // .Include("~/Content/style.css"));

            //bundles.Add(new StyleBundle("~/Content/responsive")
            // .Include("~/Content/responsive.css"));

            //bundles.Add(new StyleBundle("~/Content/apps")
            //.Include("~/Content/app.css"));


           // bundles.Add(new StyleBundle("~/Content/multi")
           //.Include("~/Content/multiple-select.css"));

           // bundles.Add(new StyleBundle("~/Content/aciTree_CSS")
           //.Include("~/Content/aci-tree/aciTree.css", "~/Content/aci-tree/demo.css"));




            //bundles.Add(new StyleBundle("~/Content/angular")
            // .Include("~/Content/angular-toastr.css"));

            //bundles.Add(new StyleBundle("~/Content/datatable")
            //    .Include(
            //        "~/Content/datatable/dataTables.bootstrap.min.css",
            //        "~/Content/datatable/responsive.bootstrap.min.css"
            //        ));

           // bundles.Add(new StyleBundle("~/Content/directives")
           //     .Include(
           //         "~/Content/directives/numericSpinner.css",
           //         "~/Content/directives/tablePagination.css"
           //         ));

           // bundles.Add(new StyleBundle("~/Content/anguluarMD")
           //.Include("~/Content/angular-material.css", "~/Content/normalize-table.css", "~/Content/responsive-table.css", "~/Content/component.css", "~/Content/demo.css"));

                    


            bundles.Add(new StyleBundle("~/Content/home")
            .Include("~/Content/home.css"));

            bundles.Add(new ScriptBundle("~/bundles/jquery").Include("~/Scripts/jquery.min.js"));

            //bundles.Add(new ScriptBundle("~/bundles/bootstrap")
            //    .Include(
            //        "~/Scripts/bootstrap.min.js",
            //        "~/Scripts/bootstrap-datetime.js",
            //        "~/Scripts/bootstrap-datetimepicker.min.js",
            //        "~/Scripts/bootstrap-select.js"
            //        ));

            //bundles.Add(new ScriptBundle("~/bundles/bootstraptpls")
            //  .Include(
            //       "~/Scripts/ui-bootstrap-tpls.min.js"
            //      ));

            //bundles.Add(new ScriptBundle("~/bundles/jquery.placeholder").Include("~/Scripts/jquery.placeholder.js"));

            //bundles.Add(new ScriptBundle("~/bundles/application").Include("~/ClientScript/app.js", "~/ClientScript/application.js"));

            //bundles.Add(new ScriptBundle("~/bundles/ClientScriptJS").Include("~/ClientScript/jquery_005.js"));

            //bundles.Add(new ScriptBundle("~/bundles/angular")
            //    .Include(
            //          "~/Scripts/angular.js",
            //          "~/Scripts/ng-table.js",
            //          "~/Scripts/angular-animate.js",                     
            //          "~/Scripts/angular-route.js",
            //          "~/Scripts/angular-material.js",
            //          "~/Scripts/angular-aria.min.js",
            //          "~/Scripts/angular-messages.min.js"
            //          ));

            bundles.Add(new ScriptBundle("~/bundles/angular")
           .Include(
                 "~/Scripts/angularjs/angular.min.js",
                   "~/Scripts/ng-table.js",
                 "~/Scripts/angularjs/angular-animate.min.js",
                 "~/Scripts/angularjs/angular-aria.min.js",
                 "~/Scripts/angularjs/angular-messages.min.js",
                 "~/Scripts/angular-ui-router.js",
                 "~/Scripts/angular_material/angular-material.min.js"
                 ));

            bundles.Add(new ScriptBundle("~/bundles/module")
                .Include(
                    "~/ClientScript/AngularJS/Modules/imModule.js"
                    ));

            bundles.Add(new ScriptBundle("~/bundles/ng-navigation")
                .Include(
                    "~/ClientScript/AngularJS/Controllers/NavigationController.js",
                    "~/ClientScript/AngularJS/Services/NavigationService.js"
                   
                    ));

            bundles.Add(new ScriptBundle("~/bundles/ng-management")
                .Include(
                    "~/ClientScript/AngularJS/Controllers/ManagementController.js",
                    "~/ClientScript/AngularJS/Services/ManagementService.js"                     
                    ));

            bundles.Add(new ScriptBundle("~/bundles/ng-home")
                 .Include(
                     "~/ClientScript/AngularJS/Controllers/HomeController.js",
                     "~/ClientScript/AngularJS/Services/HomeService.js",
                     "~/ClientScript/AngularJS/Directives/HomeDirective.js",
                     "~/ClientScript/AngularJS/Factories/HomeFactory.js  ",
                     "~/ClientScript/AngularJS/Routes/HomeRoute.js",
                      "~/ClientScript/AngularJS/Filters/CustomFilters.js"
                     ));


            bundles.Add(new ScriptBundle("~/bundles/plugins")
                  .Include(
                      "~/ClientScript/AngularJS/Factories/ToastPlugins.js"
                      ));

            bundles.Add(new ScriptBundle("~/bundles/ng-user")
                  .Include(
                      "~/ClientScript/AngularJS/Controllers/UserController.js",
                      "~/ClientScript/AngularJS/Services/UserService.js",
                      "~/ClientScript/AngularJS/Factories/UserFactory.js"
                      ));

            bundles.Add(new ScriptBundle("~/bundles/ng-group")
                .Include(
                    "~/ClientScript/AngularJS/Controllers/GroupController.js",
                    "~/ClientScript/AngularJS/Services/GroupService.js",
                     "~/ClientScript/AngularJS/Factories/GroupFactory.js"
                    ));

            bundles.Add(new ScriptBundle("~/bundles/ng-docType")
                 .Include(
                     "~/ClientScript/AngularJS/Controllers/DocTypeController.js",
                     "~/ClientScript/AngularJS/Services/DocTypeService.js",
                     "~/ClientScript/AngularJS/Factories/DocTypeFactory.js"
                     ));

            bundles.Add(new ScriptBundle("~/bundles/AppSetupScript")
                   .Include(
                       "~/ClientScript/AngularJS/Controllers/AppSetupController.js",
                       "~/ClientScript/AngularJS/Services/AppSetupService.js"
                       ));

            bundles.Add(new ScriptBundle("~/bundles/RoleScript")
                     .Include(
                         "~/ClientScript/AngularJS/Controllers/RolesController.js",
                         "~/ClientScript/AngularJS/Services/RolesService.js",
                         "~/ClientScript/AngularJS/Factories/RolesFactory.js"
                         ));
            bundles.Add(new ScriptBundle("~/bundles/DatabaseScript")
            .Include
            (
                    "~/ClientScript/AngularJS/Controllers/DatabaseController.js",
                    "~/ClientScript/AngularJS/Services/DatabaseService.js",
                    "~/ClientScript/AngularJS/Factories/DatabasesFactory.js"
            ));

            bundles.Add(new ScriptBundle("~/bundles/ng-class")
                     .Include(
                         "~/ClientScript/AngularJS/Controllers/ClassController.js",
                         "~/ClientScript/AngularJS/Services/ClassService.js",
                         "~/ClientScript/AngularJS/Factories/ClassFactory.js"
                         ));

            bundles.Add(new ScriptBundle("~/bundles/MetaDataScript")
        .Include
        (
                "~/ClientScript/AngularJS/Controllers/MetaDataController.js",
                "~/ClientScript/AngularJS/Services/MetaDataService.js",
                "~/ClientScript/AngularJS/Factories/MetaDataFactory.js"
        ));

            bundles.Add(new ScriptBundle("~/bundles/login-validation").Include("~/ClientScript/loginValidator.js"));

            bundles.Add(new ScriptBundle("~/bundles/multijs").Include("~/Script/multiple-select.js"));
            
            bundles.Add(new ScriptBundle("~/bundles/dataTables")
                        .Include(
                            "~/Scripts/datatable/jquery.dataTables.min.js",
                            "~/Scripts/datatable/dataTables.bootstrap.min.js",
                            "~/Scripts/datatable/dataTables.responsive.min.js",
                            "~/Scripts/datatable/responsive.bootstrap.min.js",
                            "~/Scripts/ng-Datatable/angular-datatables.min.js"
                            ));

            bundles.Add(new ScriptBundle("~/bundles/jQuery.Plugins")
                         .Include("~/Scripts/jquery.caret.js",
                                  "~/Scripts/jquery.nicescroll.min.js"
                                ));

            bundles.Add(new ScriptBundle("~/bundles/AddRemoveGroup")
              .Include(
                  "~/ClientScript/AngularJS/Controllers/AddRemoveUserGroupController.js"
                  ));

            bundles.Add(new ScriptBundle("~/bundles/SecurityTemplateScript")
                        .Include(
                            "~/ClientScript/AngularJS/Controllers/SecurityTemplateController.js",
                            "~/ClientScript/AngularJS/Services/SecurityTemplateService.js",
                             "~/ClientScript/AngularJS/Factories/SecurityTemplateFactory.js"
                            ));

         

            bundles.Add(new ScriptBundle("~/bundles/aci_tree_js")
                     .Include(
                         "~/Scripts/aci-tree/jquery.aciPlugin.min.js",
                         "~/Scripts/aci-tree/jquery.aciTree.dom.js",
                          "~/Scripts/aci-tree/jquery.aciTree.core.js",
                          "~/Scripts/aci-tree/jquery.aciTree.selectable.js",
                         "~/Scripts/aci-tree/jquery.aciTree.radio.js",
                          "~/Scripts/aci-tree/jquery.aciTree.checkbox.js"
                         ));

            bundles.Add(new ScriptBundle("~/bundles/SearchList")
             .Include(
                 "~/ClientScript/AngularJS/Controllers/SearchListController.js"
                 ));

            bundles.Add(new ScriptBundle("~/bundles/Assets")
             .Include(
                 "~/Scripts/svg-assets-cache.js"
                 ));


            bundles.Add(new StyleBundle("~/Content/iManage")
             .Include(
                 "~/Content/imanage-style.css",
                 "~/Content/imanage-responsive.css"
                 ));
            bundles.Add(new StyleBundle("~/Content/angularmaterial")
            .Include(
                "~/Content/angular_material/angular-material.min.css"
                ));

            bundles.Add(new StyleBundle("~/Content/material-icons")
               .Include(
                   "~/Fonts/material-icons/material-icons.css"
                   ));

            bundles.Add(new StyleBundle("~/Content/mdtableStyle")
             .Include(
                 "~/Content/md-data-table.css"
                 ));


     

            bundles.Add(new ScriptBundle("~/bundles/angularUIRouter")
        .Include(
             "~/Scripts/angular-ui-router.js"
              ));

            bundles.Add(new ScriptBundle("~/bundles/mdtable")
             .Include(
                   "~/Scripts/md-data-table.js"
                   ));

            bundles.Add(new ScriptBundle("~/bundles/imanageApp")
            .Include(
                  "~/ClientScript/AngularJS/Modules/imanage-app.js"
                  ));

            bundles.Add(new ScriptBundle("~/bundles/imanageUIRouter")
            .Include(
                  "~/ClientScript/AngularJS/Routes/app.routes.js"
                  ));

            bundles.Add(new ScriptBundle("~/bundles/Assets")
                    .Include(
                        "~/Scripts/svg-assets-cache.js"
                        ));
              

            BundleTable.EnableOptimizations= false;
        }
    }
}