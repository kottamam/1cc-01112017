﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using IManageWeb.CoreInterface.Model;

namespace IManageWeb.Models
{
    public class LoginViewModel
    {

        public AuthenticationModel authModel
        {
            get;
            set;
        }
        public bool rememberMe
        {
            get;
            set;
        }

        public bool changeAPIUrl
        {
            get;
            set;
        }
       
    }
}