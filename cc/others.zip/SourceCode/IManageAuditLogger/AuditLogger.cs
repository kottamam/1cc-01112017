﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IManageAuditLogger
{
    public static class AuditLogger
    {
        public static void Log( string message)
        {
            IManageLogger.LogHelper.Log(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, message);
        }
        public static void Debug( string message)
        {
            IManageLogger.LogHelper.Debug(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, message);
        }

        public static void PublishException( IManageLogger.ExceptionType exceptionType, Exception ex, object message)
        {
            IManageLogger.LogHelper.PublishException(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, exceptionType, ex, message);
        }
    }
}
