﻿using Com.Interwoven.WorkSite;
using Interop.iManExt;
using Interop.iManExt2;
using Optionalfolders.helpers;
using System;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace Optionalfolders
{
    [Guid("4641A085-9165-4D2D-AD13-CC37A047E01D")]
    [ProgId("IManage.FlexibleFolderCmd")]
    public class DocumentFolder : ICommand
    {
        private int mAccelerator;
        private object mBitmap;
        private ContextItems mContext;
        private string mHelpFile;
        private int mHelpID;
        private string mHelpText;
        private string mMenuText;
        private string mName;
        private int mOptions;
        private int mStatus;
        private Commands mSubCommands;
        private string mTitle;
        private CommandType mType;
        private const int tempVirtKey = 65536;
        private const int tempNoInvert = 131072;
        private const int tempShift = 262144;
        private const int tempControl = 524288;
        private const int tempAlt = 1048576;
        public DocumentFolder()
        {
            try
            {
                LogHelper.SetupLogger();
                Name = ImanResources.IDS_DOCFOLDER_COMMANDNAME;
                Title = ImanResources.IDS_DOCFOLDER_COMMANDTITLE;

                Type = CommandType.nrStandardCommand;

                Status = (int)CommandStatus.nrDisabledCommand;

                MenuText = ImanResources.IDS_DOCFOLDER_COMMANDTITLE;

                HelpText = ImanResources.IDS_DOCFOLDER_COMMANDTITLE;



                Byte[] encodedBytes = Encoding.ASCII.GetBytes("F");
                Accelerator = encodedBytes[0] + tempVirtKey + tempControl;

                System.Drawing.Bitmap bm = Optionalfolders.ImanResources.document_folder;
                System.IntPtr bp = bm.GetHbitmap();
                Bitmap = bp;

            }
            catch
            {
                // Do not throw exception
            }
        }
        public int Accelerator
        {
            get
            {
                return mAccelerator;
            }
            set
            {
                mAccelerator = value;
            }
        }

        public object Bitmap
        {
            get
            {
                return mBitmap;
            }
            set
            {
                mBitmap = value;
            }
        }

        public ContextItems Context
        {
            get { return mContext; }
        }
        NewIManDocumentFolderCmdClass cl = new NewIManDocumentFolderCmdClass();
        public void Execute()
        {
            try
            {
                if (!isDatabaseSelected())
                {
                    ImccHelper helperClass = new ImccHelper();
                    applyTemplates applyform = new applyTemplates(helperClass.GetIMCCURL(Context), Context, "applyhome.ApplyTemplates", imObjectType.imTypeDocumentFolder);
                    applyform.CommandName = "Flexible Folders";
                    applyform.Text = "Create New...";
                    if (applyform.IsLoggedIn)
                    {
                        applyform.WindowState = FormWindowState.Normal;
                        applyform.ShowDialog();
                    }
                }
                else
                {



                    cl.Execute();


                }
            }
            catch (Exception ex)
            {
                LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, ex.Message);

            }
        }

        public string HelpFile
        {
            get
            {
                return mHelpFile;
            }
            set
            {
                mHelpFile = value;
            }
        }

        public int HelpID
        {
            get
            {
                return mHelpID;
            }
            set
            {
                mHelpID = value;
            }
        }

        public string HelpText
        {
            get
            {
                return mHelpText;
            }
            set
            {
                mHelpText = value;
            }
        }

        public void Initialize(ContextItems Context)
        {
            mContext = Context;
            IMANEXTLib.ContextItems cntItems = Context as IMANEXTLib.ContextItems;
            cl.Initialize(cntItems);
        }

        public string MenuText
        {
            get
            {
                return mMenuText;
            }
            set
            {
                mMenuText = value;
            }
        }

        public string Name
        {
            get
            {
                return mName;
            }
            set
            {
                mName = value;
            }
        }

        public int Options
        {
            get
            {
                return mOptions;
            }
            set
            {
                mOptions = value;
            }
        }

        public int Status
        {
            get
            {
                return mStatus;
            }
            set
            {
                mStatus = value;
            }
        }

        public Commands SubCommands
        {
            get
            {
                return mSubCommands;
            }
            set
            {
                mSubCommands = value;
            }
        }

        public string Title
        {
            get
            {
                return mTitle;
            }
            set
            {
                mTitle = value;
            }
        }

        public CommandType Type
        {
            get
            {
                return mType;
            }
            set
            {
                mType = value;
            }
        }

        public void Update()
        {
            //ImccHelper helperClass = new ImccHelper();

            //if (helperClass.SpecialPermissions(Context))
            //    Status = (int)CommandStatus.nrActiveCommand;
            //else if (helperClass.HaveUserRights(Context))
            //     Status = (int)CommandStatus.nrActiveCommand;
            //else 
            //    Status = (int)CommandStatus.nrGrayedCommand;

            if (IsFolderOptionEnabled())
            {
                NewIManDocumentFolderCmdClass cl = new NewIManDocumentFolderCmdClass();
                IMANEXTLib.ContextItems cntItems = Context as IMANEXTLib.ContextItems;
                cl.Initialize(cntItems);
                cl.Update();
                Status = cl.Status;
            }
            else
                Status = (int)CommandStatus.nrGrayedCommand;




        }



        public bool IsFolderOptionEnabled()
        {
            bool bRet = true;
            if (isDatabaseSelected())
                bRet = false;
            if (isLinkSiteDB())
                bRet = false;
            ImccHelper helperClass = new ImccHelper();
            string strIMCCURL = helperClass.GetIMCCURL(Context);
            if (strIMCCURL == null || strIMCCURL.Trim().Length == 0)
                bRet = false;



            return bRet;
        }

        private bool isLinkSiteDB()
        {
            bool bShareFolder = false;
            try
            {
                object objFolder = GetContextItemVal(Context, "SelectedFolderObject");
                if (objFolder != null)
                {
                    IManFolder fld = objFolder as IManFolder;
                    if (fld is IManFolderShortcut)
                    {
                        IManFolderShortcut shortcu = fld as IManFolderShortcut;
                        if (shortcu != null)
                        {
                            IManFolder realFolder = shortcu.Resolve();

                            bShareFolder = IsDatabaseNameInLinksiteDbs(realFolder.Database.Name, fld.Database.Session);
                        }
                    }
                }
            }
            catch
            {

            }

            return bShareFolder;
        }

        private bool IsDatabaseNameInLinksiteDbs(string dbName, IManSession manSession)
        {
            bool bShareFolder = false;
            try
            {
                IManAdditionalProperty prop = manSession.ConfigurationData.ItemByName("LinkSiteDBs");
                if (prop != null && prop.Value != null)
                {
                    string val = prop.Value;
                    if (val.ToLower().Contains(dbName.ToLower()))
                        bShareFolder = true;
                }
            }
            catch
            {

            }
            return bShareFolder;
        }

        private bool isDatabaseSelected()
        {
            bool bRet = false;
            object objSelected = GetContextItemVal(Context, "SelectedIManObject");

            if (objSelected != null)
            {
                IManDatabase db = objSelected as IManDatabase;
                if (db != null)
                    bRet = true;
            }

            object objFolder = GetContextItemVal(Context, "SelectedFolderObject");
            if (objFolder != null)
            {
                IManObject obj;
                IManFolder fld = objFolder as IManFolder;
                while (fld.Parent != null)
                    fld = fld.Parent;
                if (fld.ObjectType.ObjectType == imObjectType.imTypeDocumentFolder || fld.ObjectType.ObjectType == imObjectType.imTypeDocumentSearchFolder)
                    bRet = true;
            }
            return bRet;


        }

        public object GetContextItemVal(ContextItems Context, string value)
        {
            object objVal = null;
            try
            {
                objVal = Context.Item(value);

            }
            catch
            {

            }
            return objVal;
        }


    }

}
