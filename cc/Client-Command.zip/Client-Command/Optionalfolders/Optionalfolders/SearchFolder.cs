﻿using Interop.iManExt;
using System;
using System.Collections.Generic;
using System.Text; 
using System.Runtime.InteropServices;
using Com.Interwoven.WorkSite;
using Interop.iManExt2;
using System.Diagnostics;
using Microsoft.Win32;
using System.Windows.Forms;
using System.Net;
using System.IO;
using Optionalfolders.helpers;
using System.Drawing;
 

namespace Optionalfolders
{
    [Guid("00ED14AA-7138-4919-B6F2-7D9272CC5D26")]
    [ProgId("IManage.FlexibleSearchFolderCmd")]
    public class SearchFolderCmd : ICommand
    {
        private int mAccelerator;
        private object mBitmap;
        private ContextItems mContext;
        private string mHelpFile;
        private int mHelpID;
        private string mHelpText;
        private string mMenuText;
        private string mName;
        private int mOptions;
        private int mStatus;
        private Commands mSubCommands;
        private string mTitle;
        private CommandType mType;
        private const int tempVirtKey = 65536;
        private const int tempNoInvert = 131072;
        private const int tempShift = 262144;
        private const int tempControl = 524288;
        private const int tempAlt = 1048576;
        public SearchFolderCmd()
        {
            try
            {
                LogHelper.SetupLogger();
                Name = ImanResources.IDS_SEARCHFOLDER_COMMANDNAME;
                Title = ImanResources.IDS_SEARCHFOLDER_TITLE;

                Type = CommandType.nrStandardCommand;

                Status = (int)CommandStatus.nrDisabledCommand;

                MenuText = ImanResources.IDS_SEARCHFOLDER_TITLE;

                HelpText = ImanResources.IDS_SEARCHFOLDER_TITLE;



                Byte[] encodedBytes = Encoding.ASCII.GetBytes("F");
                Accelerator = encodedBytes[0] + tempVirtKey + tempControl;

                System.Drawing.Bitmap bm = Optionalfolders.ImanResources.search_folder;
                System.IntPtr bp = bm.GetHbitmap();
                Bitmap = bp;

            }
            catch
            {
                // Do not throw exception
            }
        }
        public int Accelerator
        {
            get
            {
                return mAccelerator;
            }
            set
            {
                mAccelerator = value;
            }
        }

        public object Bitmap
        {
            get
            {
                return mBitmap;
            }
            set
            {
                mBitmap = value;
            }
        }

        public ContextItems Context
        {
            get { return mContext; }
        }
        NewIManDocumentSearchFolderCmdClass cl = new NewIManDocumentSearchFolderCmdClass();
        public void Execute()
        {
            try
            {
                if (!isDatabaseSelected())
                {
                    ImccHelper helperClass = new ImccHelper();
                    applyTemplates applyform = new applyTemplates(helperClass.GetIMCCURL(Context), Context, "applyhome.ApplyTemplates", imObjectType.imTypeDocumentSearchFolder);
                    applyform.Text = "Create Search Folder";
                    applyform.CommandName = "Flexible Folders";
                    if (applyform.IsLoggedIn)
                    {
                        applyform.WindowState = FormWindowState.Normal;
                        applyform.ShowDialog();
                    }
                }
                else
                {
                    
                  
                    
                    cl.Execute();

                    
                }
            }
            catch (Exception ex)
            {
                LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, ex.Message); 

            }
        }

        public string HelpFile
        {
            get
            {
                return mHelpFile;
            }
            set
            {
                mHelpFile = value;
            }
        }

        public int HelpID
        {
            get
            {
                return mHelpID;
            }
            set
            {
                mHelpID = value;
            }
        }

        public string HelpText
        {
            get
            {
                return mHelpText;
            }
            set
            {
                mHelpText = value;
            }
        }

        public void Initialize(ContextItems Context)
        {
            mContext = Context;
            IMANEXTLib.ContextItems cntItems = Context as IMANEXTLib.ContextItems;
            cl.Initialize(cntItems);
        }

        public string MenuText
        {
            get
            {
                return mMenuText;
            }
            set
            {
                mMenuText = value;
            }
        }

        public string Name
        {
            get
            {
                return mName;
            }
            set
            {
                mName = value;
            }
        }

        public int Options
        {
            get
            {
                return mOptions;
            }
            set
            {
                mOptions = value;
            }
        }

        public int Status
        {
            get
            {
                return mStatus;
            }
            set
            {
                mStatus = value;
            }
        }

        public Commands SubCommands
        {
            get
            {
                return mSubCommands;
            }
            set
            {
                mSubCommands = value;
            }
        }

        public string Title
        {
            get
            {
                return mTitle;
            }
            set
            {
                mTitle = value;
            }
        }

        public CommandType Type
        {
            get
            {
                return mType;
            }
            set
            {
                mType = value;
            }
        }

        public void Update()
        {
            //ImccHelper helperClass = new ImccHelper();
            
                //if (helperClass.SpecialPermissions(Context))
                //    Status = (int)CommandStatus.nrActiveCommand;
                //else if (helperClass.HaveUserRights(Context))
                //     Status = (int)CommandStatus.nrActiveCommand;
                //else 
                //    Status = (int)CommandStatus.nrGrayedCommand;

            if (IsFolderOptionEnabled())
            {
                NewIManDocumentSearchFolderCmdClass cl = new NewIManDocumentSearchFolderCmdClass();
                IMANEXTLib.ContextItems cntItems = Context as IMANEXTLib.ContextItems;
                cl.Initialize(cntItems);
                cl.Update();
                Status = cl.Status;
            }
            else
                Status = (int)CommandStatus.nrGrayedCommand;

            
          

        }



        public bool IsFolderOptionEnabled()
        {
            bool bRet = true;
            if (isDatabaseSelected())
                bRet = false;
            if (isLinkSiteDB())
                bRet = false;
            ImccHelper helperClass = new ImccHelper();
            string strIMCCURL = helperClass.GetIMCCURL(Context);
            if (strIMCCURL == null || strIMCCURL.Trim().Length == 0)
                bRet = false;



            return bRet;
        }

        private bool isLinkSiteDB()
        {
            bool bShareFolder = false;
            try
            {
                object objFolder = GetContextItemVal(Context, "SelectedFolderObject");
                if (objFolder != null)
                {
                    IManFolder fld = objFolder as IManFolder;
                    if (fld is IManFolderShortcut)
                    {
                        IManFolderShortcut shortcu = fld as IManFolderShortcut;
                        if (shortcu != null)
                        {
                            IManFolder realFolder = shortcu.Resolve();

                            bShareFolder = IsDatabaseNameInLinksiteDbs(realFolder.Database.Name, fld.Database.Session);
                        }
                    }
                }
            }
            catch
            {

            }

            return bShareFolder;
        }

        private bool IsDatabaseNameInLinksiteDbs(string dbName, IManSession manSession)
        {
            bool bShareFolder = false;
            try
            {
                IManAdditionalProperty prop = manSession.ConfigurationData.ItemByName("LinkSiteDBs");
                if (prop != null && prop.Value != null)
                {
                    string val = prop.Value;
                    if (val.ToLower().Contains(dbName.ToLower()))
                        bShareFolder = true;
                }
            }
            catch
            {

            }
            return bShareFolder;
        }
        private bool isDatabaseSelected()
        {
            bool bRet = false;
            object objSelected = GetContextItemVal(Context, "SelectedIManObject");

            if(objSelected != null)
            {
                IManDatabase db = objSelected as IManDatabase;
                if (db != null)
                    bRet = true;
            }
            object objFolder = GetContextItemVal(Context, "SelectedFolderObject");
            if (objFolder != null)
            {
                IManObject obj;
                IManFolder fld = objFolder as IManFolder;
                while (fld.Parent != null)
                    fld = fld.Parent;
                if (fld.ObjectType.ObjectType == imObjectType.imTypeDocumentFolder || fld.ObjectType.ObjectType == imObjectType.imTypeDocumentSearchFolder)
                    bRet = true;
            }   
            return bRet;


        }

        public object GetContextItemVal(ContextItems Context, string value)
        {
            object objVal = null;
            try
            {
                objVal = Context.Item(value);

            }
            catch
            {

            }
            return objVal;
        }
       

    }

}
