﻿using Interop.iManExt;
using System;
using System.Collections.Generic;
using System.Text; 
using System.Runtime.InteropServices;
using Com.Interwoven.WorkSite;
using Interop.iManExt2;
using System.Diagnostics;
using Microsoft.Win32;
using System.Windows.Forms;
using System.Net;
using System.IO;
using Optionalfolders.helpers;
using System.Drawing;
 

namespace Optionalfolders
{
    [Guid("C4671D71-8664-46D5-A38E-B602DEF0B85A")]
    [ProgId("OptionalFolders.RenameCmd")]
    public class RenameCommand : ICommand
    {
        private int mAccelerator;
        private object mBitmap;
        private ContextItems mContext;
        private string mHelpFile;
        private int mHelpID;
        private string mHelpText;
        private string mMenuText;
        private string mName;
        private int mOptions;
        private int mStatus;
        private Commands mSubCommands;
        private string mTitle;
        private CommandType mType;
        private const int tempVirtKey = 65536;
        private const int tempNoInvert = 131072;
        private const int tempShift = 262144;
        private const int tempControl = 524288;
        private const int tempAlt = 1048576;
        [DllImport("user32.dll")]
        static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, int dwExtraInfo);
        public RenameCommand()
        {
            try
            {
                LogHelper.SetupLogger();
                Name = ImanResources.IDS_RENAME_COMMANDNAME;
                Title = ImanResources.IDS_RENAME_TITLE;

                Type = CommandType.nrStandardCommand;

                Status = (int)CommandStatus.nrDisabledCommand;

                MenuText = ImanResources.IDS_RENAME_TITLE;

                HelpText = ImanResources.IDS_RENAME_TITLE;



                Byte[] encodedBytes = Encoding.ASCII.GetBytes("F");
                Accelerator = encodedBytes[0] + tempVirtKey + tempControl;

              
            }
            catch
            {
                // Do not throw exception
            }
        }
        public int Accelerator
        {
            get
            {
                return mAccelerator;
            }
            set
            {
                mAccelerator = value;
            }
        }

        public object Bitmap
        {
            get
            {
                return mBitmap;
            }
            set
            {
                mBitmap = value;
            }
        }

        public void SendKey(Keys Key, bool Release, bool Resume)
        {
            try
            {
                if (!Resume)
                {
                    keybd_event(Convert.ToByte(Key), 0, 0, 0);

                    if (Release)
                        keybd_event(Convert.ToByte(Key), 0, 0x02, 0);
                }
                else
                {
                    keybd_event(Convert.ToByte(Key), 0, 0x02, 0);
                }
            }
            catch { }
        }

        public ContextItems Context
        {
            get { return mContext; }
        }

        public void Execute()
        {
            try
            {
                SendKey(Keys.F2, true, false);
            }
            catch (Exception ex)
            {
                LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, ex.Message);

            }
        }

        public string HelpFile
        {
            get
            {
                return mHelpFile;
            }
            set
            {
                mHelpFile = value;
            }
        }

        public int HelpID
        {
            get
            {
                return mHelpID;
            }
            set
            {
                mHelpID = value;
            }
        }

        public string HelpText
        {
            get
            {
                return mHelpText;
            }
            set
            {
                mHelpText = value;
            }
        }

        public void Initialize(ContextItems Context)
        {
            mContext = Context;
        }

        public string MenuText
        {
            get
            {
                return mMenuText;
            }
            set
            {
                mMenuText = value;
            }
        }

        public string Name
        {
            get
            {
                return mName;
            }
            set
            {
                mName = value;
            }
        }

        public int Options
        {
            get
            {
                return mOptions;
            }
            set
            {
                mOptions = value;
            }
        }

        public int Status
        {
            get
            {
                return mStatus;
            }
            set
            {
                mStatus = value;
            }
        }

        public Commands SubCommands
        {
            get
            {
                return mSubCommands;
            }
            set
            {
                mSubCommands = value;
            }
        }

        public string Title
        {
            get
            {
                return mTitle;
            }
            set
            {
                mTitle = value;
            }
        }

        public CommandType Type
        {
            get
            {
                return mType;
            }
            set
            {
                mType = value;
            }
        }

        public void Update()
        {
            //ImccHelper helperClass = new ImccHelper();

            //if (helperClass.SpecialPermissions(Context))
            //    Status = (int)CommandStatus.nrActiveCommand;
            //else if (helperClass.HaveUserRights(Context))
            //     Status = (int)CommandStatus.nrActiveCommand;
            //else 
            //    Status = (int)CommandStatus.nrGrayedCommand;

            IManFolder selectedFolderItem = null, templateFolder = null;
            IManAdditionalProperty folderAddProperty = null, templateFolderAddProperty = null;
            int intTemplateFolderId = 0;

            try
            {
                Status = (int)CommandStatus.nrActiveCommand;
                selectedFolderItem = GetContextItemVal(Context, "SelectedFolderObject") as IManFolder;
                if (selectedFolderItem == null)
                {
                    return;
                }
                Title = String.Format("Rename \"{0}\"", selectedFolderItem.Name);
                MenuText = String.Format("Rename \"{0}\"", selectedFolderItem.Name);
                HelpText = String.Format("Rename \"{0}\"", selectedFolderItem.Name);

                folderAddProperty = selectedFolderItem.AdditionalProperties.ItemByName("FolderTemplateId");
                if (folderAddProperty != null)
                {
                    intTemplateFolderId = Convert.ToInt32(folderAddProperty.Value.Substring(folderAddProperty.Value.IndexOf("!") + 1));
                }
                if (intTemplateFolderId > 0)
                    templateFolder = selectedFolderItem.Database.GetFolder(intTemplateFolderId);
                if (templateFolder != null)
                {
                    templateFolderAddProperty = templateFolder.AdditionalProperties.ItemByName("icc_isrename");
                }
                if (templateFolderAddProperty != null && templateFolderAddProperty.Value.Equals("0"))
                {
                    Status = (int)CommandStatus.nrGrayedCommand;
                }
            }
            catch { }
            finally
            {
                selectedFolderItem = null;
                templateFolder = null;
                folderAddProperty = null;
                templateFolderAddProperty = null;
                intTemplateFolderId = 0;
            }
        }

        public bool IsFolderOptionEnabled()
        {
            bool bRet = true;

            if (!isDatabaseSelected())
            {
                ImccHelper helperClass = new ImccHelper();
                string strIMCCURL = helperClass.GetIMCCURL(Context);
                if (strIMCCURL == null || strIMCCURL.Trim().Length == 0)
                    bRet = false;
            }
            else
                return true;

            return bRet;
        }

        private bool isDatabaseSelected()
        {
            bool bRet = false;
            object objSelected = GetContextItemVal(Context, "SelectedIManObject");

            if(objSelected != null)
            {
                IManDatabase db = objSelected as IManDatabase;
                if (db != null)
                    bRet = true;
            }
            return bRet;


        }

        public object GetContextItemVal(ContextItems Context, string value)
        {
            object objVal = null;
            try
            {
                objVal = Context.Item(value);

            }
            catch
            {

            }
            return objVal;
        }
       

    }

}
