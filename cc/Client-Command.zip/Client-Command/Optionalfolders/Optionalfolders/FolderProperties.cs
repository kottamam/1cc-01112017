﻿using Interop.iManExt;
using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using Com.Interwoven.WorkSite;
using Interop.iManExt2;
using System.Diagnostics;
using Microsoft.Win32;
using System.Windows.Forms;
using System.Net;
using System.IO;
using Optionalfolders.helpers;
using System.Drawing;

namespace Optionalfolders
{
    [Guid("758C0B55-F735-45BC-80D9-8A5F8F7AA245")]
    [ProgId("IManage.Properties")]
    public class FolderProperties : ICommand
    {
        private int mAccelerator;
        private object mBitmap;
        private ContextItems mContext;
        private string mHelpFile;
        private int mHelpID;
        private string mHelpText;
        private string mMenuText;
        private string mName;
        private int mOptions;
        private int mStatus;
        private Commands mSubCommands;
        private string mTitle;
        private CommandType mType;
        private const int tempVirtKey = 65536;
        private const int tempNoInvert = 131072;
        private const int tempShift = 262144;
        private const int tempControl = 524288;
        private const int tempAlt = 1048576;
        public FolderProperties()
        {
            try
            {
                LogHelper.SetupLogger();
                Name = ImanResources.IDS_PROPERTIES_COMMANDNAME;
                Title = ImanResources.IDS_PROPERTIES_COMMANDTITLE;

                Type = CommandType.nrStandardCommand;

                Status = (int)CommandStatus.nrDisabledCommand;

                MenuText = ImanResources.IDS_PROPERTIES_COMMANDTITLE;

                HelpText = ImanResources.IDS_PROPERTIES_COMMANDTITLE;



                

            }
            catch
            {
                // Do not throw exception
            }
        }
        public int Accelerator
        {
            get
            {
                return mAccelerator;
            }
            set
            {
                mAccelerator = value;
            }
        }

        public object Bitmap
        {
            get
            {
                return mBitmap;
            }
            set
            {
                mBitmap = value;
            }
        }

        public ContextItems Context
        {
            get { return mContext; }
        }
        public object GetContextItemVal(ContextItems Context, string value)
        {
            object objVal = null;
            try
            {
                objVal = Context.Item(value);

            }
            catch
            {

            }
            return objVal;
        }
        IManPropertiesCmdClass oldProp = new IManPropertiesCmdClass();
        public void Execute()
        {
            try
            {
                if (!isDatabaseSelected())
                {
                    ImccHelper helperClass = new ImccHelper();
                    applyTemplates applyform = new applyTemplates(helperClass.GetIMCCURL(Context), Context, "applyhome.ObjectProperties", imObjectType.imTypeDocumentFolder);
                    applyform.CommandName = "Folder Properties";
                    IManFolder folder = (IManFolder)Context.Item("SelectedFolderObject");
                    applyform.Width = 700;
                    applyform.Height = 673;
                    applyform.Text = "Properties";
                    if (folder != null)
                    {
                        if (folder is IManFolderShortcut)
                        {
                            folder = ((IManFolderShortcut)folder).Resolve();
                        }
                        imObjectType OType = folder.ObjectType.ObjectType;
                        if (OType == imObjectType.imTypeWorkspace)
                        {
                            applyform.Text = "Workspace Properties";
                        }
                        else
                        {
                            applyform.Text = folder.Name + " Properties";
                        }
                    }
                    if (applyform.IsLoggedIn)
                    {
                        applyform.WindowState = FormWindowState.Normal;
                        applyform.ShowDialog();
                    }
                }

                else
                {
                    
                    IMANEXTLib.ContextItems cntItems = Context as IMANEXTLib.ContextItems;
                    oldProp.Initialize(cntItems);
                    oldProp.Update();
                    oldProp.Execute();

                }
                
            }
            catch (Exception ex)
            {
                LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, ex.Message);

            }
        }
        private bool isDatabaseSelected()
        {
            bool bRet = false;
            object objSelected = GetContextItemVal(Context, "SelectedIManObject");

            if (objSelected != null)
            {
                IManDatabase db = objSelected as IManDatabase;
                if (db != null)
                    bRet = true;
            }

            object objFolder = GetContextItemVal(Context, "SelectedFolderObject");
            if (objFolder != null)
            {
                IManObject obj;
                IManFolder fld = objFolder as IManFolder;
                while (fld.Parent != null)
                    fld = fld.Parent;
                if (fld.ObjectType.ObjectType == imObjectType.imTypeDocumentFolder || fld.ObjectType.ObjectType == imObjectType.imTypeDocumentSearchFolder)
                    bRet = true;
            }
            return bRet;


        }

        public string HelpFile
        {
            get
            {
                return mHelpFile;
            }
            set
            {
                mHelpFile = value;
            }
        }

        public int HelpID
        {
            get
            {
                return mHelpID;
            }
            set
            {
                mHelpID = value;
            }
        }

        public string HelpText
        {
            get
            {
                return mHelpText;
            }
            set
            {
                mHelpText = value;
            }
        }

        public void Initialize(ContextItems Context)
        {
            mContext = Context;
            IMANEXTLib.ContextItems cntItems = mContext as IMANEXTLib.ContextItems;
            oldProp.Initialize(cntItems);
        }

        public string MenuText
        {
            get
            {
                return mMenuText;
            }
            set
            {
                mMenuText = value;
            }
        }

        public string Name
        {
            get
            {
                return mName;
            }
            set
            {
                mName = value;
            }
        }

        public int Options
        {
            get
            {
                return mOptions;
            }
            set
            {
                mOptions = value;
            }
        }

        public int Status
        {
            get
            {
                return mStatus;
            }
            set
            {
                mStatus = value;
            }
        }

        public Commands SubCommands
        {
            get
            {
                return mSubCommands;
            }
            set
            {
                mSubCommands = value;
            }
        }

        public string Title
        {
            get
            {
                return mTitle;
            }
            set
            {
                mTitle = value;
            }
        }

        public CommandType Type
        {
            get
            {
                return mType;
            }
            set
            {
                mType = value;
            }
        }

        public void Update()
        {
            ImccHelper helperClass = new ImccHelper();
            
                //if (helperClass.SpecialPermissions(Context))
                //    Status = (int)CommandStatus.nrActiveCommand;
                //else if (helperClass.HaveUserRights(Context))
                //     Status = (int)CommandStatus.nrActiveCommand;
                //else 
                //    Status = (int)CommandStatus.nrGrayedCommand;

            if (helperClass.IsFolderPropertiesEnabled(Context))
            {

                IMANEXTLib.ContextItems cntItems = mContext as IMANEXTLib.ContextItems;
                oldProp.Update();
                Status = oldProp.Status;

            }
            else
                Status = (int)CommandStatus.nrGrayedCommand;
            
          

        } 
       

       

    }

}

 
