﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Optionalfolders
{
    class LogoutEntity
    {
        public Links links;
    }
    class Links
    {
        public string saml_logout_url;
    }
}
