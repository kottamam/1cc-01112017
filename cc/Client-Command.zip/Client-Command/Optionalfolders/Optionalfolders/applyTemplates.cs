﻿using Com.Interwoven.WorkSite;
using Interop.iManExt;
using Microsoft.Win32;
using Optionalfolders.helpers;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using Interop.iwSingleton;
using PositionLibrary;

namespace Optionalfolders
{
    [ComVisible(true)]
    public partial class applyTemplates : Form
    {

        const string COMMON_AUTH_APP_COOKIE = "3CEEF535-CE6A-4C05-BEBC-333A5AC92E2C";
        const string COMMON_AUTH_MUTEX_OBJECT = "5DEB0A5C-E230-478C-B90D-2899D1A18CC0";
        const string CLSID_COMMONAUTH = "E278C076-6F35-48FB-B98D-A0BFD3047915";

        public ContextItems mContext { get; set; }
        public string propSate { get; set; }
        public imObjectType ObjectType { get; set; }

        public string CommandName {  set { position = new FormPositionSaver(value); } }


        private PositionLibrary.FormPositionSaver position = null;
        [DllImport("user32.dll")]
        static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, int dwExtraInfo);

        [DllImport("wininet.dll", CharSet = CharSet.Auto, SetLastError = true)]
        static extern bool InternetSetCookie(string lpszUrlName, string lpszCookieName, string lpszCookieData);

        private const Int32 InternetCookieHttponly = 0x2000;
        [DllImport("wininet.dll", CharSet = CharSet.Auto, SetLastError = true)]
        static extern bool InternetSetCookieEx(string lpszUrlName, string lpszCookieName, string lpszCookieData, uint dwFlags, IntPtr dwReserved);

        [DllImport("wininet.dll", SetLastError = true)]
        public static extern bool InternetGetCookieEx(
            string url,
            string cookieName,
            StringBuilder cookieData,
            ref int size,
            Int32 dwFlags,
            IntPtr lpReserved);
        private const int INTERNET_OPTION_END_BROWSER_SESSION = 42;

        [DllImport("wininet.dll", SetLastError = true)]
        private static extern bool InternetSetOption(IntPtr hInternet, int dwOption, IntPtr lpBuffer, int lpdwBufferLength);

        [DllImport("user32.dll", SetLastError = true)]
        public static extern bool AllowSetForegroundWindow(uint procId);

        static List<string> sessionUsers = new List<string>();
        string LOGGEDUSER = "";
        private bool _isLoggedIn = false;

        public bool IsLoggedIn
        {
            get { return _isLoggedIn; }
        }
        public applyTemplates()
        {
            InitializeComponent();
        }



        private void SetBrowserFeatureControlKey(string feature, string appName, uint value)
        {
            using (var key = Registry.CurrentUser.CreateSubKey(
                String.Concat(@"Software\Microsoft\Internet Explorer\Main\FeatureControl\", feature),
                RegistryKeyPermissionCheck.ReadWriteSubTree))
            {
                key.SetValue(appName, (UInt32)value, RegistryValueKind.DWord);
            }
        }

        private void SetIMCCAuthKey(string feature, string appName, string value)
        {
            using (var key = Registry.CurrentUser.CreateSubKey(
                String.Concat(@"Software\Interwoven\WorkSite\8.0\", feature),
                RegistryKeyPermissionCheck.ReadWriteSubTree))
            {
                key.SetValue(appName, value, RegistryValueKind.String);
            }
        }

        private void SetBrowserFeatureControl()
        {
            // http://msdn.microsoft.com/en-us/library/ee330720(v=vs.85).aspx

            // FeatureControl settings are per-process
            var fileName = System.IO.Path.GetFileName(Process.GetCurrentProcess().MainModule.FileName);

            // make the control is not running inside Visual Studio Designer
            if (String.Compare(fileName, "devenv.exe", true) == 0 || String.Compare(fileName, "XDesProc.exe", true) == 0)
                return;

            SetBrowserFeatureControlKey("FEATURE_BROWSER_EMULATION", fileName, GetBrowserEmulationMode()); // Webpages containing standards-based !DOCTYPE directives are displayed in IE10 Standards mode.
            SetBrowserFeatureControlKey("FEATURE_AJAX_CONNECTIONEVENTS", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_ENABLE_CLIPCHILDREN_OPTIMIZATION", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_MANAGE_SCRIPT_CIRCULAR_REFS", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_DOMSTORAGE ", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_GPU_RENDERING ", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_IVIEWOBJECTDRAW_DMLT9_WITH_GDI  ", fileName, 0);
            SetBrowserFeatureControlKey("FEATURE_DISABLE_LEGACY_COMPRESSION", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_LOCALMACHINE_LOCKDOWN", fileName, 0);
            SetBrowserFeatureControlKey("FEATURE_BLOCK_LMZ_OBJECT", fileName, 0);
            SetBrowserFeatureControlKey("FEATURE_BLOCK_LMZ_SCRIPT", fileName, 0);
            SetBrowserFeatureControlKey("FEATURE_DISABLE_NAVIGATION_SOUNDS", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_SCRIPTURL_MITIGATION", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_SPELLCHECKING", fileName, 0);
            SetBrowserFeatureControlKey("FEATURE_STATUS_BAR_THROTTLING", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_TABBED_BROWSING", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_VALIDATE_NAVIGATE_URL", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_WEBOC_DOCUMENT_ZOOM", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_WEBOC_POPUPMANAGEMENT", fileName, 0);
            SetBrowserFeatureControlKey("FEATURE_WEBOC_MOVESIZECHILD", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_ADDON_MANAGEMENT", fileName, 0);
            SetBrowserFeatureControlKey("FEATURE_WEBSOCKET", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_WINDOW_RESTRICTIONS ", fileName, 0);
            SetBrowserFeatureControlKey("FEATURE_XMLHTTP", fileName, 1);
        }

        private UInt32 GetBrowserEmulationMode()
        {
            int browserVersion = 7;
            using (var ieKey = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Internet Explorer",
                RegistryKeyPermissionCheck.ReadSubTree,
                System.Security.AccessControl.RegistryRights.QueryValues))
            {
                var version = ieKey.GetValue("svcVersion");
                if (null == version)
                {
                    version = ieKey.GetValue("Version");
                    if (null == version)
                        throw new ApplicationException("Microsoft Internet Explorer is required!");
                }
                int.TryParse(version.ToString().Split('.')[0], out browserVersion);
            }

            UInt32 mode = 11000; // Internet Explorer 11. Webpages containing standards-based !DOCTYPE directives are displayed in IE11 Standards mode. Default value for Internet Explorer 11.
            switch (browserVersion)
            {
                case 7:
                    mode = 7000; // Webpages containing standards-based !DOCTYPE directives are displayed in IE7 Standards mode. Default value for applications hosting the WebBrowser Control.
                    break;
                case 8:
                    mode = 8000; // Webpages containing standards-based !DOCTYPE directives are displayed in IE8 mode. Default value for Internet Explorer 8
                    break;
                case 9:
                    mode = 9000; // Internet Explorer 9. Webpages containing standards-based !DOCTYPE directives are displayed in IE9 mode. Default value for Internet Explorer 9.
                    break;
                case 10:
                    mode = 10000; // Internet Explorer 10. Webpages containing standards-based !DOCTYPE directives are displayed in IE10 mode. Default value for Internet Explorer 10.
                    break;
                default:
                    // use IE11 mode by default
                    break;
            }

            return mode;
        }
        private imObjectType objectType = imObjectType.imTypeDocumentFolder;
        private string _samlUrl = string.Empty;
        public applyTemplates(string Url, ContextItems Context, string stateName, imObjectType obj)
        {
            try
            {
                ImccHelper helperclass = new ImccHelper();


                //  $scope.mc.loginModel.UserName = UserName;
                this.ObjectType = obj;
                this.mContext = Context;
                this.propSate = stateName;
                SetBrowserFeatureControl();
                InitializeComponent();
               
                objectType = obj;
                //applyBrowser.ScriptErrorsSuppressed = true;
                applyBrowser.ObjectForScripting = this;
                System.Uri uri = new Uri(Url);

                //Before navigate
                //check cookie if it exists and set in X-Auth-Token
                
                string actualHost = uri.AbsoluteUri.Replace(uri.LocalPath, "");
                _imccURL = actualHost;
                string strToken = string.Empty;
                DateTime expiresDateTime = DateTime.MinValue;
                
                
                bool bCommonLogin = CommonLogin(ref strToken, ref expiresDateTime);

                if (bCommonLogin)
                {

                    string authTokenKey = "X-Auth-Token";
                    Cookie XauthTokenCookie = new Cookie(authTokenKey, strToken, "/", uri.Host);
                    XauthTokenCookie.Expires = expiresDateTime;
                    bool bDone = InternetSetCookieEx(_imccURL, null, XauthTokenCookie.ToString(), InternetCookieHttponly, IntPtr.Zero);
                    RedirectToObjectType();
                    _isLoggedIn = true;
                }
                else
                {
                    MessageBox.Show(ImanResources.IDS_LOGIN_FAILED,"Flexible Folders");
                    _isLoggedIn = false;
                }


            }
            catch (Exception ex)
            {
                LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "applyTemplates(" + Url + ", ContectObject):" + ex.Message);
                
            }
        }

        private bool CommonLogin(ref string strToken, ref DateTime expiresDateTime)
        {
            bool bLoggedIn = false;
            try
            {
                using (System.Threading.Semaphore bouncer = new System.Threading.Semaphore(1, 5, COMMON_AUTH_MUTEX_OBJECT)) // common name shared among login agents
                {
                    if (bouncer.WaitOne(0) ||
                        bouncer.WaitOne(60 * 1000))
                    {
                        Type comType = Type.GetTypeFromCLSID(new Guid(CLSID_COMMONAUTH));
                        ICommonAuth auth = Activator.CreateInstance(comType) as ICommonAuth;
                        if (auth == null)
                            return bLoggedIn;
                        auth.AppCookie = COMMON_AUTH_APP_COOKIE;
                        auth.HostUri = _imccURL;
                        auth.RestApiVersion = 1;
                        auth.TimeOut = 60;
                        AllowSetForegroundWindow(unchecked((uint)-1));

                        int procId = 0;
                        auth.LOGINTYPE = LOGINTYPE.Auto;
                        auth.AppID = "3CEEF535-CE6A-4C05-BEBC-333A5AC92E2C";
                        strToken = auth.Execute(procId = Process.GetCurrentProcess().Id);
                        if (!String.IsNullOrEmpty(strToken))
                        {
                            bLoggedIn = true;
                            expiresDateTime = auth.TokenExpiry;
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());

            }
            return bLoggedIn;
        }
        
     






        private string _imccURL = string.Empty;

        public string IMCCURL
        {
            get { return _imccURL; }
            set { _imccURL = value; }
        }

      

        private string GetObjectType()
        {
            string type = imObjectType.imTypeDocumentFolder.ToString();
            helpers.ImccHelper helper = new ImccHelper();
            object objFolder = helper.GetContextItemVal(mContext, "SelectedFolderObject");
            IManFolder folder = null;
            if (objFolder != null)
            {
                if (objFolder is IManFolderShortcut)
                {
                    IManFolderShortcut shortCutFolder = objFolder as IManFolderShortcut;
                    if (shortCutFolder != null)
                        folder = shortCutFolder.Resolve();
                }
                else
                    folder = objFolder as IManFolder;

                type = folder.ObjectType.ObjectType.ToString();

            }
            return type;
        }

        private void RedirectToObjectType()
        {
            ImccHelper helperclass = new ImccHelper();
            string URL = _imccURL;
            if (propSate == "applyhome.ObjectProperties")
            {

                string type = GetObjectType();

                if (type.ToLower() == "imtypedocumentsearchfolder")
                {
                    this.Width = 800;
                    this.Height = 700;
                    URL += "/dialogs/flexible-folders/Applytemplate.html#/ApplyTemplates/Properties" + helperclass.GetQueryString(mContext, "");
                }
                else
                {
                    string Id = "";
                    IManFolder folder = (IManFolder)mContext.Item("SelectedFolderObject");
                    if (folder is IManFolderShortcut)
                    {
                        folder = ((IManFolderShortcut)folder).Resolve();
                    }
                    if (folder != null)
                    {
                        Id = folder.Database.Name + "!" + folder.FolderID;
                    }
                    URL += "/dialogs/folder-properties/?id=" + Id;
                }
            }
            else
            {
                string type = Convert.ToString(objectType);


                URL += "/dialogs/flexible-folders/Applytemplate.html#/ApplyTemplates/Apply" + helperclass.GetQueryString(mContext, type);

            }
            applyBrowser.Navigate(URL);
        }

        


        public void GetParams()
        {
            try
            {
                ImccHelper helperclass = new ImccHelper();
                ContextItems cont = mContext;
                int Level = 0;
                IManFolder folder = (IManFolder)mContext.Item("SelectedFolderObject");
                if (folder is IManFolderShortcut)
                {
                    folder = ((IManFolderShortcut)folder).Resolve();
                }
                string ftype = "";
                if (folder != null)
                {

                    imObjectType OType = folder.ObjectType.ObjectType;
                    if (OType == imObjectType.imTypeWorkspace)
                    {

                        ftype = "ws";
                    }
                    else if (OType == imObjectType.imTypeDocumentFolder)
                    {
                        ftype = "regular";
                    }
                    else if (OType == imObjectType.imTypeDocumentSearchFolder)
                    { ftype = "search"; }
                    else if (OType == imObjectType.imTypeTab)
                    { ftype = "tab"; }


                    if (OType == imObjectType.imTypeWorkspace)
                        Level = 0;
                    else
                        Level += helperclass.FindObjectLevel(folder);
                }
                else
                {
                    LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "GetParams():folder Object is null");

                }

                object[] args = new object[8];
                args[0] = "";
                args[1] = LOGGEDUSER;
                args[2] = "";
                args[3] = folder.FolderID;
                args[4] = Level;
                args[5] = folder.Database.Name + "!" + folder.FolderID;
                if (propSate.Equals("applyhome.ApplyTemplates")) { args[6] = Convert.ToString(ObjectType); }
                else
                {
                    args[6] = ftype;
                }
                args[7] = propSate;

                applyBrowser.Document.InvokeScript("SetParams", args);
            }
            catch (Exception ex)
            {
                LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, ex.Message);


            }
        }


        public void closeWindow(string folders)
        {
            try
            {
                folders = folders.TrimEnd(";".ToCharArray());
                RefreshClient(folders.Split(";".ToCharArray()));
                this.Close();
            }
            catch (Exception ex)
            {
                LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "closeWindow():" + ex.Message);
            }
        }

        public void resizeWindow(string widthHeight)
        {
          /*  string[] widHie = widthHeight.Split(';');

            this.Size = new Size(Convert.ToInt32(widHie[0]), Convert.ToInt32(widHie[1]));
            this.CenterToParent();
            this.Top = 60;*/
        }

        public void changeFormTitle(string title)
        {
            this.Text = title;
        }





        public void SendKey(Keys Key, bool Release, bool Resume)
        {
            try
            {
                if (!Resume)
                {
                    keybd_event(Convert.ToByte(Key), 0, 0, 0);

                    if (Release)
                        keybd_event(Convert.ToByte(Key), 0, 0x02, 0);
                }
                else
                {
                    keybd_event(Convert.ToByte(Key), 0, 0x02, 0);
                }
            }
            catch { }
        }



        internal void RefreshClient(string[] newFolders)
        {
            ImccHelper helperClass = new ImccHelper();

            try
            {
                try
                {
                    //Refresh the tree
                    if (helperClass.GetAppName(mContext) == "DeskSite")
                    {
                        IManFolder folder = (IManFolder)mContext.Item("SelectedFolderObject");
                        if (folder is IManFolderShortcut)
                        {
                            folder = ((IManFolderShortcut)folder).Resolve();
                        }
                        IManSession _oldSession = helperClass.GetSession(mContext);
                        IManFolder fld = (IManFolder)_oldSession.DMS.GetObjectBySID(folder.ObjectID);
                        mContext.Add("IManExt.Refresh", true);
                        foreach (string newfid in newFolders)
                        {
                            try
                            {
                                IManFolder Nfld = (IManFolder)_oldSession.DMS.GetObjectBySID(newfid);
                                mContext.Add("IManExt.NewFolderObject", new UnknownWrapper(Nfld));

                            }
                            catch (Exception ex) { }

                        }
                        mContext.Add("IManExt.NewFolderObject", new UnknownWrapper(fld));

                        mContext.Add("RefreshAllFolders", true);
                        mContext.Add("RefreshSubFolders", true);
                        SendKey(Keys.F5, true, false);

                        IManWorkspace folderParent = (IManWorkspace)folder.Workspace;
                        if (folderParent != null)
                        {

                            folderParent.SubFolders.Refresh();

                        }
                        else
                        {
                            folder.SubFolders.Refresh();


                        }



                    }
                    else if (helperClass.GetAppName(mContext) == "FileSite")
                    {

                        mContext.Add("IManExt.Refresh", true);
                        mContext.Add("RefreshAllFolders", true);
                        mContext.Add("RefreshSubFolders", true);

                    }
                }
                catch (Exception ex)
                {

                    mContext.Add("IManExt.Refresh", true);
                    mContext.Add("RefreshAllFolders", true);
                    mContext.Add("RefreshSubFolders", true);
                    //  SendKey(Keys.F5, true, false);
                    LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "RefreshClient():From ex" + ex.Message);

                }
            }
            catch (Exception EXP)
            {
                LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "RefreshClient():From EXP" + EXP.Message);

            }
        }

        private void applyTemplates_Load(object sender, EventArgs e)
        {
            
            Point location = new Point(0, 0);
            Size size = new Size(702, 618);
            bool bLocFound = false;
            bool bSizeFound = false;
            position.GetPosition(ref location, ref size, ref bLocFound, ref bSizeFound);

            if (bLocFound)
            {
                this.StartPosition = FormStartPosition.Manual;
                this.Location = location;
            }
            if (bSizeFound)
            {
                this.Size = size;
            }
        }

        private void applyTemplates_FormClosing(object sender, FormClosingEventArgs e)
        {
            position.SavePosition(this.Location, this.Size);
        }
    }
}
