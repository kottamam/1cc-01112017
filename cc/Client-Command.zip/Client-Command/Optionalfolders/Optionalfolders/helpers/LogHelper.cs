﻿using log4net;
using log4net.Appender;
using log4net.Core;
using log4net.Layout;
using log4net.Repository.Hierarchy;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Optionalfolders.helpers
{
    public static class LogHelper
    {
        private static ILog log;
       

        public static void SetupLogger(){
            try
            {
                Hierarchy hierarchy = (Hierarchy)LogManager.GetRepository();
                PatternLayout patternLayout = new PatternLayout();
                patternLayout.ConversionPattern = "%date [%thread] %-5level %logger - %message%newline";
                patternLayout.ActivateOptions();
                RollingFileAppender roller = new RollingFileAppender();
                roller.AppendToFile = false;
                roller.File = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), @"IMCCLogs\ICommandLogs.txt");
                roller.Layout = patternLayout;
                roller.MaxSizeRollBackups = 5;
                roller.MaximumFileSize = "1GB";
                roller.RollingStyle = RollingFileAppender.RollingMode.Size;
                roller.StaticLogFileName = true;
                roller.ActivateOptions();
                hierarchy.Root.AddAppender(roller);
                MemoryAppender memory = new MemoryAppender();
                memory.ActivateOptions();
                hierarchy.Root.AddAppender(memory);
                hierarchy.Root.Level = Level.Info;
                hierarchy.Configured = true;
            }
            catch (Exception ex)
            {

            }
        }


        /// <summary>
        /// Log the message
        /// </summary>
        /// <param name="declaringtype"></param>
        /// <param name="message"></param>
        public static void Log(System.Type declaringtype, object message)
        {

            log =  LogManager.GetLogger(declaringtype);
            lock (log)
            {
                log.Info(message);

            }
        }

        /// <summary>
        /// Logs a message using the Debug method.
        /// </summary>
        /// <param name="declaringType"></param>
        /// <param name="message"></param>
        public static void Debug(System.Type declaringType, string message)
        {
            log =  LogManager.GetLogger(declaringType);
            lock (log)
            {
                log.Debug(message);


            }
        }

        /// <summary>
        /// Logs a message using the Error method.
        /// </summary>
        /// <param name="declaringType"></param>
        /// <param name="message"></param>
        public static void Error(System.Type declaringType, string message)
        {
            log =  LogManager.GetLogger(declaringType);
            lock (log)
            {
                log.Error(message);
            }
        }
    }
}
