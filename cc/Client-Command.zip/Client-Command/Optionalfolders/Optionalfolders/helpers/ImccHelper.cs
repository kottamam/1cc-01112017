﻿using Interop.iManExt;
using Com.Interwoven.WorkSite;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Text;
using System.Collections;
 
 

namespace Optionalfolders.helpers
{
    public class ImccHelper
    {
        private const string REG_IMAN_FLDWIZ_FLD_PERMISSIONS = "IMAN_FLDWIZ_FLD_PERMISSIONS";
        public ImccHelper()
        {
        }

        public object GetContextItemVal(ContextItems Context,string value)
        {
            object objVal = null;
            try
            {
               objVal = Context.Item(value);

            }
            catch
            {

            }
            return objVal;
        }

        public string GetIMCCURL(ContextItems Context)
        {  
            LogHelper.Log(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType ,"Trying to get Host Url:Method Name:GetIMCCURL " ) ;
            object dmsObject = null;
            dmsObject = GetContextItemVal(Context, "IManDMS");
            
            
            IManDMS dms  =null;
            if (dmsObject != null)
                dms = dmsObject as IManDMS;
            else
            {
                object objFolder = GetContextItemVal(Context, "SelectedFolderObject");
                IManFolder folder = null;
                if(objFolder != null)
                {
                    if (objFolder is IManFolderShortcut)
                    {
                        IManFolderShortcut shortCutFolder = objFolder as IManFolderShortcut;
                        if (shortCutFolder != null)
                            folder = shortCutFolder.Resolve();
                    }
                    else
                        folder = objFolder as IManFolder;
                   
                    if(folder != null)
                    {
                        
                        if(folder.Database != null && folder.Database.Session != null)
                            dms  = folder.Database.Session.DMS;
                    }
                }
            }

            if (dms!= null)
            {
                object objFolder = GetContextItemVal(Context, "SelectedFolderObject");
                IManFolder folder = null;
                IManSession session = null;
                if (objFolder != null)
                {
                    if (objFolder is IManFolderShortcut)
                    {
                        IManFolderShortcut shortCutFolder = objFolder as IManFolderShortcut;
                        if(shortCutFolder != null)
                            folder = shortCutFolder.Resolve();
                    }
                    else
                        folder = objFolder as IManFolder;
                    
                   
                    if (folder != null)
                    {
                        if (folder.Database != null)
                            session = folder.Database.Session;
                    }

                }
                IManAdditionalProperty additional;
                if (session != null)
                {

                    additional = session.ConfigurationData.ItemByName("IMCC_HOSTURL");
                    if (additional != null)
                    {
                        LogHelper.Log(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Host Url:" + additional.Value);

                        return additional.Value;
                    }

                }
                else
                {
                    LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "IManSessions is Not Avilable null");

                }
            }
            else
            {
                LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "IManDMS object is getting null"); 

            }
            return "";
        }

         

        public string getApplyTemplateUrl(ContextItems Context,imObjectType obj)
        {
            if (Context != null)
            {
                string url = GetIMCCURL(Context) + "Applytemplate.html#/ApplyTemplates/Apply" + GetQueryString(Context, Convert.ToString(obj));
                
                LogHelper.Log(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, url); 
          
                return url;
            }
            else 
            {
                LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "getApplyTemplateUrl returning EMPTY since ContextItems is null");

                return ""; 
            
            }
        }

        public string GetQueryString(ContextItems Context,string ObjType)
        {
            string qryString = "?";
           // session.ServerName
            try
            {
                ContextItems cont = Context;
                int Level = 0;
                IManFolder folder = (IManFolder)Context.Item("SelectedFolderObject");
                if (folder is IManFolderShortcut)
                {
                    folder = ((IManFolderShortcut)folder).Resolve();
                }               
                if (folder != null)
                {
                    qryString += "dbname=" + folder.Database.Name + "&id=" + folder.FolderID;
                    if (ObjType != "")
                    {
                        qryString += "&type="+ObjType;
                        if (folder.ObjectType.ObjectType == imObjectType.imTypeWorkspace)
                            Level = 0;
                        else
                            Level += FindObjectLevel(folder);

                        qryString += "&level=" + Level;
                    }
                    else
                    {
                        qryString +=  "&type=" + Convert.ToString(folder.ObjectType.ObjectType);
                    }
                  
                }
                else
                {
                    LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "GetParams():folder Object is null");

                }

                IManSession session = (IManSession)Context.Item("SelectedIManSession");
                if (session != null)
                {
                    qryString += "&server=" + session.ServerName;
                    qryString += "&userid=" + session.UserID;
                }

              
              
            }
            catch (Exception ex)
            {
                LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, ex.Message);


            }
            return qryString;
        }

        public int FindObjectLevel(IManFolder folder)
        {
            if (folder != null)
            {
                if (folder.Parent != null && (folder.Parent.ObjectType.ObjectType == imObjectType.imTypeWorkspace || folder.Parent.ObjectType.ObjectType == imObjectType.imTypeWorkspaces))
                    return 1;
                else
                    return 1 + FindObjectLevel(folder.Parent);
            }
            else
            {
                LogHelper.Log(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "FindObjectLevel cannot be find since the folder is empty");
                return -1;
            }
        }

      

        public IManSession GetSession(ContextItems Context)
        {
            IManFolder folder = (IManFolder)Context.Item("SelectedFolderObject");
            if (folder is IManFolderShortcut)
            {
                folder = ((IManFolderShortcut)folder).Resolve();
            }
            if (folder != null)
            {
                return folder.Database.Session;
            }
            else
            {
                LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "IManSession is null");
               
                return null;
            }
        }


        public string GetAppName(ContextItems mContext)
        {
            try
            {
                object obj = mContext.Item("IManExt.AppMode.AppName");
                LogHelper.Log(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "AppName:"+Convert.ToString(obj));

                return Convert.ToString(obj);
            }
            catch (Exception ex)
            {
                LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType,"GetAppName():"+ ex.Message);
                return "";
            }
        }



        internal bool HaveUserRights(ContextItems Context)
        {
            try
            {
                IManFolder folder = (IManFolder)Context.Item("SelectedFolderObject");
                if (folder is IManFolderShortcut)
                {
                    folder = ((IManFolderShortcut)folder).Resolve();
                }
                if ((imAccessRight)folder.EffectiveAccess == imAccessRight.imRightRead || (imAccessRight)folder.EffectiveAccess == imAccessRight.imRightNone)
                {

                    return false;
                }
                else if ((imAccessRight)folder.EffectiveAccess == imAccessRight.imRightReadWrite)
                {
                    imObjectType OType = folder.ObjectType.ObjectType;

                    if (OType == imObjectType.imTypeWorkspace || OType == imObjectType.imTypeWorkspaces)
                        return false;
                    else
                        return true;


                }
                else if ((imAccessRight)folder.EffectiveAccess == imAccessRight.imRightAll)
                {

                    return true;


                }
                else
                {
                    return false;
                }

            }
            catch (Exception ex)
            {

                LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, ex.Message);
                return false;

            }
           
        }

        internal bool SpecialPermissions(ContextItems Context)
        {
            try
            {
                IManFolder folder = (IManFolder)Context.Item("SelectedFolderObject");
                if (folder is IManFolderShortcut)
                {
                    folder = ((IManFolderShortcut)folder).Resolve();
                }
                IManWorkspace WSPace;

                if (folder is IManWorkspace)
                {
                    WSPace = (IManWorkspace)folder;
                }
                else
                {
                    WSPace = folder.Workspace;
                }

                IManAdditionalProperties IProps = WSPace.Database.Session.ConfigurationData;
                string Permissions = GetPropertyValue(IProps, REG_IMAN_FLDWIZ_FLD_PERMISSIONS);
                if (!String.IsNullOrEmpty(Permissions))
                {
                    //If Delete Permissions specified, then process accordingly.
                    Permissions = Permissions.ToUpper();
                    ArrayList PermsArray = new ArrayList(Permissions.Split(char.Parse(",")));
                    if (PermsArray.Contains("ACCESS:ALL") &&
                        WSPace.EffectiveAccess == imAccessRight.imRightAll)
                        return true;
                    else if ((PermsArray.Contains("ACCESS:RW") || PermsArray.Contains("ACCESS:READWRITE")) &&
                        (WSPace.EffectiveAccess == imAccessRight.imRightAll || WSPace.EffectiveAccess == imAccessRight.imRightReadWrite))
                        return true;
                    else if ((PermsArray.Contains("ACCESS:R") || PermsArray.Contains("ACCESS:READ")) &&
                        (WSPace.EffectiveAccess == imAccessRight.imRightAll || WSPace.EffectiveAccess == imAccessRight.imRightReadWrite || WSPace.EffectiveAccess == imAccessRight.imRightRead))
                        return true;

                    else if (PermsArray.Contains("SECURITYTYPE:PUBLIC")
                            && WSPace.Security.DefaultVisibility == imSecurityType.imPublic)
                        return true;
                }
            }
            catch (Exception ex)
            {

                LogHelper.Log(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType,ex.Message);

            }
            return false;
        }

        private string GetPropertyValue(IManAdditionalProperties confData, string key)
        {
            //get the string value of the specified key
            string val = string.Empty;
            if (confData.ContainsByName(key))
            {
                val = confData.ItemByName(key).Value;
            }
            return val;
        }

        public string getPropertiesUrl(ContextItems Context)
        {
            if (Context != null)
            {
                string url = GetIMCCURL(Context) + "Applytemplate.html#/ApplyTemplates/Properties" + GetQueryString(Context, ""); ;
                LogHelper.Log(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, url);

                return url;
            }
            else
            {
                LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "getPropertiesUrl returning EMPTY since ContextItems is null");

                return "";

            }
        }

        public bool IsFolderPropertiesEnabled(ContextItems Context)
        {
            bool bRet = true;
            string strIMCCURL = GetIMCCURL(Context);
            if (strIMCCURL == null || strIMCCURL.Trim().Length == 0)
                bRet = false;

            object objSelected = GetContextItemVal(Context, "SelectedFolderObject");
            if (objSelected == null)
                bRet = false;

            return bRet;
        }


        
    }
}
