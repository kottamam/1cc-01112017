﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CustomActionRegistryTest
{
    class Session
    {
        public void Log(string p1)
        {

        }
    }
}
