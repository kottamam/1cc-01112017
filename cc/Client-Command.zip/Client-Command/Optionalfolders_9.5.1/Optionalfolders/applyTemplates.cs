﻿using Microsoft.Win32;
using Optionalfolders.helpers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Com.Interwoven.WorkSite;
using Interop.iManExt;
using Interop.iManExt2;
using System.Net;
 

namespace Optionalfolders
{
    [ComVisible(true)]
    public partial class applyTemplates : Form
    {

        public ContextItems mContext { get; set; }
        public string propSate { get; set; }
        public imObjectType  ObjectType { get; set; }
        [DllImport("user32.dll")]
        static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, int dwExtraInfo);

        [DllImport("wininet.dll", CharSet = CharSet.Auto, SetLastError = true)]
        static extern bool InternetSetCookie(string lpszUrlName, string lpszCookieName, string lpszCookieData);
        string LOGGEDUSER = "";
        public applyTemplates()
        {
            InitializeComponent();
        }

         

        private void SetBrowserFeatureControlKey(string feature, string appName, uint value)
        {
            using (var key = Registry.CurrentUser.CreateSubKey(
                String.Concat(@"Software\Microsoft\Internet Explorer\Main\FeatureControl\", feature),
                RegistryKeyPermissionCheck.ReadWriteSubTree))
            {
                key.SetValue(appName, (UInt32)value, RegistryValueKind.DWord);
            }
        }

        private void SetIMCCAuthKey(string feature, string appName, string value)
        {
            using (var key = Registry.CurrentUser.CreateSubKey(
                String.Concat(@"Software\Interwoven\WorkSite\8.0\", feature),
                RegistryKeyPermissionCheck.ReadWriteSubTree))
            {
                key.SetValue(appName,  value, RegistryValueKind.String);
            }
        }

        private void SetBrowserFeatureControl()
        {
            // http://msdn.microsoft.com/en-us/library/ee330720(v=vs.85).aspx
          
            // FeatureControl settings are per-process
            var fileName = System.IO.Path.GetFileName(Process.GetCurrentProcess().MainModule.FileName);

            // make the control is not running inside Visual Studio Designer
            if (String.Compare(fileName, "devenv.exe", true) == 0 || String.Compare(fileName, "XDesProc.exe", true) == 0)
                return;

            SetBrowserFeatureControlKey("FEATURE_BROWSER_EMULATION", fileName, GetBrowserEmulationMode()); // Webpages containing standards-based !DOCTYPE directives are displayed in IE10 Standards mode.
            SetBrowserFeatureControlKey("FEATURE_AJAX_CONNECTIONEVENTS", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_ENABLE_CLIPCHILDREN_OPTIMIZATION", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_MANAGE_SCRIPT_CIRCULAR_REFS", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_DOMSTORAGE ", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_GPU_RENDERING ", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_IVIEWOBJECTDRAW_DMLT9_WITH_GDI  ", fileName, 0);
            SetBrowserFeatureControlKey("FEATURE_DISABLE_LEGACY_COMPRESSION", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_LOCALMACHINE_LOCKDOWN", fileName, 0);
            SetBrowserFeatureControlKey("FEATURE_BLOCK_LMZ_OBJECT", fileName, 0);
            SetBrowserFeatureControlKey("FEATURE_BLOCK_LMZ_SCRIPT", fileName, 0);
            SetBrowserFeatureControlKey("FEATURE_DISABLE_NAVIGATION_SOUNDS", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_SCRIPTURL_MITIGATION", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_SPELLCHECKING", fileName, 0);
            SetBrowserFeatureControlKey("FEATURE_STATUS_BAR_THROTTLING", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_TABBED_BROWSING", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_VALIDATE_NAVIGATE_URL", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_WEBOC_DOCUMENT_ZOOM", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_WEBOC_POPUPMANAGEMENT", fileName, 0);
            SetBrowserFeatureControlKey("FEATURE_WEBOC_MOVESIZECHILD", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_ADDON_MANAGEMENT", fileName, 0);
            SetBrowserFeatureControlKey("FEATURE_WEBSOCKET", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_WINDOW_RESTRICTIONS ", fileName, 0);
            SetBrowserFeatureControlKey("FEATURE_XMLHTTP", fileName, 1);
        }

        private UInt32 GetBrowserEmulationMode()
        {
            int browserVersion = 7;
            using (var ieKey = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Internet Explorer",
                RegistryKeyPermissionCheck.ReadSubTree,
                System.Security.AccessControl.RegistryRights.QueryValues))
            {
                var version = ieKey.GetValue("svcVersion");
                if (null == version)
                {
                    version = ieKey.GetValue("Version");
                    if (null == version)
                        throw new ApplicationException("Microsoft Internet Explorer is required!");
                }
                int.TryParse(version.ToString().Split('.')[0], out browserVersion);
            }

            UInt32 mode = 11000; // Internet Explorer 11. Webpages containing standards-based !DOCTYPE directives are displayed in IE11 Standards mode. Default value for Internet Explorer 11.
            switch (browserVersion)
            {
                case 7:
                    mode = 7000; // Webpages containing standards-based !DOCTYPE directives are displayed in IE7 Standards mode. Default value for applications hosting the WebBrowser Control.
                    break;
                case 8:
                    mode = 8000; // Webpages containing standards-based !DOCTYPE directives are displayed in IE8 mode. Default value for Internet Explorer 8
                    break;
                case 9:
                    mode = 9000; // Internet Explorer 9. Webpages containing standards-based !DOCTYPE directives are displayed in IE9 mode. Default value for Internet Explorer 9.
                    break;
                case 10:
                    mode = 10000; // Internet Explorer 10. Webpages containing standards-based !DOCTYPE directives are displayed in IE10 mode. Default value for Internet Explorer 10.
                    break;
                default:
                    // use IE11 mode by default
                    break;
            }

            return mode;
        }

        public applyTemplates(string Url ,ContextItems Context,string  stateName,imObjectType obj)
        {
            try
            {
                ImccHelper helperclass = new ImccHelper();
                SetCookie(helperclass.GetIMCCURL(Context));
                
                  //  $scope.mc.loginModel.UserName = UserName;
                this.ObjectType = obj;
                this.mContext = Context;
                this.propSate = stateName;
                SetBrowserFeatureControl();
                InitializeComponent();
                this.CenterToParent(); 
                //applyBrowser.ScriptErrorsSuppressed = true;
                applyBrowser.ObjectForScripting = this;
                this.applyBrowser.Navigate(Url);
                LogHelper.Log(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Navigated to Browser with url:" + Url);

            }
            catch (Exception ex)
            {
                LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "applyTemplates(" + Url +", ContectObject):" + ex.Message);
               
            }
        }

        private void SetCookie(string Url)
        {
            string AUTHTOKEN = "";
            DateTime AUTHTIMESTAMP = DateTime.Now.AddDays(-1);
           
            string XSRFTOKEN = "";
            try
            {
               /* using (var ieKey = Registry.CurrentUser.OpenSubKey(@"Software\Interwoven\WorkSite\8.0\IMCC\",
                  RegistryKeyPermissionCheck.ReadSubTree,
                  System.Security.AccessControl.RegistryRights.QueryValues))
                {
                    AUTHTOKEN = Convert.ToString(ieKey.GetValue("AUTHTOKEN"));
                    XSRFTOKEN = Convert.ToString(ieKey.GetValue("XSRFTOKEN"));
                    if (!string.IsNullOrEmpty(AUTHTOKEN) && !string.IsNullOrEmpty(XSRFTOKEN))
                    {
                        AUTHTIMESTAMP = Convert.ToDateTime(ieKey.GetValue("AUTHTIMESTAMP"));
                        LOGGEDUSER = Convert.ToString(ieKey.GetValue("LOGGEDUSER"));
                   
                        if ((DateTime.Now - AUTHTIMESTAMP).Hours < 4 && (DateTime.Now - AUTHTIMESTAMP).Days <= 0 && session.UserID.ToLower().Equals(LOGGEDUSER.ToLower()))
                        {


                        }
                        else
                        {
                            LogHelper.Log(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "GetParams():Token resseted");
                            SetIMCCAuthKey("IMCC", "AUTHTOKEN", "");
                            AUTHTOKEN = "";
                            XSRFTOKEN = "";
                        }
                    }
                    else
                    {
                        AUTHTOKEN = "";
                        XSRFTOKEN = "";
                    }
                }*/


                IManSession session = (IManSession)mContext.Item("SelectedIManSession");
                AUTHTOKEN = "";//get the logic for authtoken 
                XSRFTOKEN = "";//get the logic for XSRF-TOKEN 

                Cookie temp1 = new Cookie(session.ServerName + "_" + session.UserID + "_" + "AUTH-TOKEN", AUTHTOKEN);
                Cookie temp2 = new Cookie(session.ServerName + "_" + session.UserID + "_" + "XSRF-TOKEN", XSRFTOKEN);
                if (AUTHTOKEN != "")
                {
                    InternetSetCookie(Url, null, temp1.ToString() + "; expires =" + DateTime.Now.AddHours(4).ToString());
                }
                if (XSRFTOKEN != "")
                {
                    InternetSetCookie(Url, null, temp2.ToString() + "; expires =" + DateTime.Now.AddHours(4).ToString());
                }


            }
            catch (Exception ex)
            {
                LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "GetParams():" + ex.Message);

            }

           
           
        }
         
        
     

        private void applyTemplates_FormClosing(object sender, FormClosingEventArgs e)
        {
            
           
        }

        
       

        public void GetParams()
        {
            try
            {
                ImccHelper helperclass = new ImccHelper();
                ContextItems cont = mContext;
                int Level = 0;
                IManFolder folder = (IManFolder)mContext.Item("SelectedFolderObject");
                if (folder is IManFolderShortcut)
                {
                    folder = ((IManFolderShortcut)folder).Resolve();
                }
                string ftype ="";
                if (folder != null)
                {

                    imObjectType OType = folder.ObjectType.ObjectType;
                    if (OType == imObjectType.imTypeWorkspace)
                    {

                        ftype = "ws";
                    }else if (OType == imObjectType.imTypeDocumentFolder)
                    {
                        ftype = "regular";
                    }else if (OType == imObjectType.imTypeDocumentSearchFolder)
                    { ftype = "search"; }
                    else if (OType == imObjectType.imTypeTab)
                    { ftype = "tab"; }
                    
                       
                    if (OType == imObjectType.imTypeWorkspace)
                        Level = 0;
                    else
                        Level += helperclass.FindObjectLevel(folder);
                }
                else
                {
                    LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "GetParams():folder Object is null");

                }
               
                object[] args = new object[8];
                args[0] = "";
                args[1] = LOGGEDUSER;
                args[2] = "";
                args[3] = folder.FolderID;
                args[4] = Level;
                args[5] = folder.Database.Name + "!" + folder.FolderID;
                if (propSate.Equals("applyhome.ApplyTemplates")) { args[6] = Convert.ToString(ObjectType);  }
                else
                {
                    args[6] = ftype;
                }
                args[7] = propSate;
                
                applyBrowser.Document.InvokeScript("SetParams", args);
            }
            catch (Exception ex)
            {
                LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, ex.Message);


            }
        }
        

        public void closeWindow(string folders)
        {
            try
            {
               folders= folders.TrimEnd(";".ToCharArray());
                RefreshClient(folders.Split(";".ToCharArray()));
            this.Close();
             }catch(Exception ex)
            {
                LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "closeWindow():" + ex.Message);
            }
        }

        public void resizeWindow(string widthHeight)
        {
            string [] widHie=widthHeight.Split(';');

            this.Size = new Size(Convert.ToInt32(widHie[0]), Convert.ToInt32(widHie[1]));
            this.CenterToParent(); 
        }

        public void SetXSRFTOKEN(string data)
        {
            try
            {
                 
                    SetIMCCAuthKey("IMCC", "XSRFTOKEN", data);


            }
            catch (Exception ex)
            {
                LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "SetXSRFTOKEN():" + ex.Message);
            }
        }

        public void SetLoggedUser(string data)
        {
            try
            {

                    SetIMCCAuthKey("IMCC", "LOGGEDUSER", data);


            }
            catch (Exception ex)
            {
                LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "SetLoggedUser():" + ex.Message);
            }
        }

        public void SetAuthData(string data)
        {
            try
            {
                
             
                 
                    SetIMCCAuthKey("IMCC", "AUTHTOKEN", data);
                    SetIMCCAuthKey("IMCC", "AUTHTIMESTAMP", DateTime.Now.ToString());

               
               
            }
            catch (Exception ex)
            {
                LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "SetAuthData():" + ex.Message);
            }
        }


        public void SendKey(Keys Key, bool Release, bool Resume)
        {
            try
            {
                if (!Resume)
                {
                    keybd_event(Convert.ToByte(Key), 0, 0, 0);

                    if (Release)
                        keybd_event(Convert.ToByte(Key), 0, 0x02, 0);
                }
                else
                {
                    keybd_event(Convert.ToByte(Key), 0, 0x02, 0);
                }
            }
            catch { }
        }



        internal void RefreshClient(string[] newFolders)
        {
            ImccHelper helperClass = new ImccHelper(); 

            try
            {
                try
                {
                    //Refresh the tree
                    if (helperClass.GetAppName(mContext) == "DeskSite")
                    {
                        IManFolder folder = (IManFolder)mContext.Item("SelectedFolderObject");
                        if (folder is IManFolderShortcut)
                        {
                            folder = ((IManFolderShortcut)folder).Resolve();
                        }
                        IManSession _oldSession = helperClass.GetSession(mContext);
                        IManFolder fld = (IManFolder)_oldSession.DMS.GetObjectBySID(folder.ObjectID);
                        mContext.Add("IManExt.Refresh", true);
                        foreach (string newfid in newFolders)
                        {
                            try
                            {
                                IManFolder Nfld = (IManFolder)_oldSession.DMS.GetObjectBySID(newfid);
                                mContext.Add("IManExt.NewFolderObject", new UnknownWrapper(Nfld));
                               
                            }
                            catch(Exception ex) { }

                        }
                        mContext.Add("IManExt.NewFolderObject", new UnknownWrapper(fld));
                       
                        mContext.Add("RefreshAllFolders", true);
                        mContext.Add("RefreshSubFolders", true);
                        SendKey(Keys.F5, true, false);
                       
                        IManWorkspace folderParent = (IManWorkspace)folder.Workspace;
                         if (folderParent != null)
                         {
                           
                             folderParent.SubFolders.Refresh();
                          
                         }
                         else
                         {
                             folder.SubFolders.Refresh();
                            
                           
                         } 

                        

                    }
                    else if (helperClass.GetAppName(mContext) == "FileSite")
                    {

                        mContext.Add("IManExt.Refresh", true);
                        mContext.Add("RefreshAllFolders", true);
                        mContext.Add("RefreshSubFolders", true);

                    }
                }
                catch(Exception ex)
                {
                    
                    mContext.Add("IManExt.Refresh", true);
                    mContext.Add("RefreshAllFolders", true);
                    mContext.Add("RefreshSubFolders", true);
                    //  SendKey(Keys.F5, true, false);
                    LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "RefreshClient():From ex" + ex.Message);
           
                }
            }
            catch (Exception EXP)
            {
                LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "RefreshClient():From EXP" + EXP.Message);
           
            }
        }



        
    }
}
