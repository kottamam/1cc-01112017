﻿using Interop.iManExt;
using System;
using System.Collections.Generic;
using System.Text; 
using System.Runtime.InteropServices;
using Com.Interwoven.WorkSite;
using Interop.iManExt2;
using System.Diagnostics;
using Microsoft.Win32;
using System.Windows.Forms;
using System.Net;
using System.IO;
using Optionalfolders.helpers;
using System.Drawing;
 

namespace Optionalfolders
{
    [Guid("4641A085-9165-4D2D-AD13-CC37A047E01D")]
    [ProgId("IManage.FlexibleFolderCmd")]
    public class DocumentFolder : ICommand
    {
        private int mAccelerator;
        private object mBitmap;
        private ContextItems mContext;
        private string mHelpFile;
        private int mHelpID;
        private string mHelpText;
        private string mMenuText;
        private string mName;
        private int mOptions;
        private int mStatus;
        private Commands mSubCommands;
        private string mTitle;
        private CommandType mType;
        private const int tempVirtKey = 65536;
        private const int tempNoInvert = 131072;
        private const int tempShift = 262144;
        private const int tempControl = 524288;
        private const int tempAlt = 1048576;
        public DocumentFolder()
        {
            try
            {
                LogHelper.SetupLogger();
                Name = "IManage.DocumentFolders";
                Title = "Document Folder";

                Type = CommandType.nrStandardCommand;

                Status = (int)CommandStatus.nrDisabledCommand;

                MenuText = "Document Folder";

                HelpText = "Document Folder";



                Byte[] encodedBytes = Encoding.ASCII.GetBytes("F");
                Accelerator = encodedBytes[0] + tempVirtKey + tempControl;

                System.Drawing.Bitmap bm = Optionalfolders.ImanResources.document_folder;
                System.IntPtr bp = bm.GetHbitmap();
                Bitmap = bp;

            }
            catch
            {
                // Do not throw exception
            }
        }
        public int Accelerator
        {
            get
            {
                return mAccelerator;
            }
            set
            {
                mAccelerator = value;
            }
        }

        public object Bitmap
        {
            get
            {
                return mBitmap;
            }
            set
            {
                mBitmap = value;
            }
        }

        public ContextItems Context
        {
            get { return mContext; }
        }
        NewIManDocumentFolderCmdClass cl = new NewIManDocumentFolderCmdClass();
        public void Execute()
        {
            try
            {
                if (!isDatabaseSelected() && !NoFolderInTemplate())
                {
                    ImccHelper helperClass = new ImccHelper();
                    applyTemplates applyform = new applyTemplates(helperClass.getApplyTemplateUrl(Context, imObjectType.imTypeDocumentFolder), Context, "applyhome.ApplyTemplates", imObjectType.imTypeDocumentFolder);
                    applyform.Text = "Create Document Folder";
                    applyform.WindowState = FormWindowState.Normal;
                    applyform.ShowDialog();
                }
                else
                {
                   
                   
                   
                    cl.Execute();

                    
                }
            }
            catch (Exception ex)
            {
                LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, ex.Message); 

            }
        }
        //remove this in 10.0
        private bool NoFolderInTemplate()
        {
            bool bRet = false;
            //Get the seleted folder and if it is not available then go back to web (not possible as update will check this)
            IManFolder selectedFolder = GetSelectItem();
            if (selectedFolder == null)
                return false;
            //Get the target workspace of the selected folder.If no, then go back to web (not possible as this will bring up the other dialog)
            IManWorkspace targetWorkspace = GetWorkspace(selectedFolder);
            if (targetWorkspace == null)
                return false;

            targetWorkspace.Refresh();
            targetWorkspace.AdditionalProperties.Refresh();

            //Get the template associated with workspace
            IManAdditionalProperty addProperty = targetWorkspace.AdditionalProperties.ItemByName("TemplateId");
            if (addProperty == null || addProperty.Value.Trim().Length == 0)
            {
                if (MatchingTemplatesFound(targetWorkspace,selectedFolder.Database))
                    return false;
                else
                    return true;
            }
            string templateId = addProperty.Value;

            //Get the template object and if template is not there then flexible folders should be done so return false

            IManWorkspace template = GetWorkspaceObject(templateId, selectedFolder.Database) as IManWorkspace;


            if (template == null)
                return false;

            //Get the path of the folder
            IManFolders selectedFolderPath = selectedFolder.Path;
            int count = 0;
            //Check if folder has FolderTemplateId addtitional property of FolderTemplateId introduced in 10.0
            //If present just take the count of subfolders from that object else the huge logic

            count = GetCountOfSubFolders(selectedFolderPath, template);


            if (count == 0)
                bRet = true;

            return bRet;

        }

        private bool MatchingTemplatesFound(IManWorkspace targetWorkspace,IManDatabase db)
        {
            bool bResult = false;
            try
            {
                targetWorkspace.Refresh();
                db.Session.ConfigurationData.Refresh();
                
                IManAdditionalProperty additional = db.Session.ConfigurationData.ItemByName("IMCC_OF_MATCHFIELDS");
                IManWorkspaceSearchParameters workParameter = db.Session.DMS.CreateWorkspaceSearchParameters();
                IManProfileSearchParameters profileParam = db.Session.DMS.CreateProfileSearchParameters();
                bool bFirstCheckREquired = false;
                bool bSecondCheckRequired = false;
                string strFirstAttrVal = "";
                string strSecondAttrVal = "";
                 string strFullVal = "";
                imProfileAttributeID firstAttr = imProfileAttributeID.imProfileExternalAsNormal;
                 imProfileAttributeID secondAttr = imProfileAttributeID.imProfileExternalAsNormal;
                 if (additional != null)
                 {
                     strFullVal = additional.Value;
                     string[] splitVal = { "," };
                     string[] indVals = strFullVal.Split(splitVal, StringSplitOptions.RemoveEmptyEntries);

                     if (indVals.Length > 0)
                     {
                         

                         firstAttr = GetProfileValFromData(indVals[0]);
                         if (firstAttr != imProfileAttributeID.imProfileExternalAsNormal)
                         {
                             bFirstCheckREquired = true;
                             object objVal = targetWorkspace.GetAttributeValueByID(firstAttr);
                             if (objVal != null && objVal.ToString().Length > 0)
                             {
                                 strFirstAttrVal = objVal.ToString();
                                 profileParam.Add(firstAttr, objVal.ToString());
                             }
                         }

                     }
                     if (indVals.Length > 1)
                     {
                        

                         secondAttr = GetProfileValFromData(indVals[1]);



                         if (secondAttr != imProfileAttributeID.imProfileExternalAsNormal)
                         {
                             bSecondCheckRequired = true;
                             object objVal = targetWorkspace.GetAttributeValueByID(secondAttr);
                             if (objVal != null && objVal.ToString().Length > 0)
                             {
                                 profileParam.Add(secondAttr, objVal.ToString());
                                 strSecondAttrVal = objVal.ToString();
                             }
                         }

                     }
                 }
                 
                

                workParameter.Add(imFolderAttributeID.imFolderSubtype, "template");
                IManFolders folders = db.SearchWorkspaces(profileParam, workParameter);
                 bool bFound = false;
                foreach (IManFolder fld in folders)
                {
                    IManWorkspace template = fld as IManWorkspace;
                   
                    if (template != null)
                    {
                        
                        if (bFirstCheckREquired&&bSecondCheckRequired)
                        {
                            object objTemplateFirstVal  = template.GetAttributeValueByID(firstAttr);
                            object objTemplateSecondVal  = template.GetAttributeValueByID(secondAttr);
                            if(strFirstAttrVal == objTemplateFirstVal.ToString() && strSecondAttrVal == objTemplateSecondVal.ToString() )
                            {
                                bFound = true;
                                break;
                            }
                        }
                        else if(bFirstCheckREquired)
                        {
                            object objTemplateFirstVal = template.GetAttributeValueByID(firstAttr);
                            
                            if (strFirstAttrVal == objTemplateFirstVal.ToString() )
                            {
                                bFound = true;
                                break;
                            }
                        }
                        else
                        {
                            bFound = true;
                            break;
                        }
                    }

                }
                bResult = bFound;

            }
            catch
            {
                bResult = false;
            }



            return bResult;
        }

        private imProfileAttributeID GetProfileValFromData(string profileVal)
        {
            imProfileAttributeID returnAttr = imProfileAttributeID.imProfileExternalAsNormal;
            switch(profileVal.ToLower())
            {
                case "improfilecustom1":

                    returnAttr = imProfileAttributeID.imProfileCustom1;
                    break;
                case "improfilecustom2":

                    returnAttr = imProfileAttributeID.imProfileCustom2;
                    break;
                case "improfilecustom3":

                    returnAttr = imProfileAttributeID.imProfileCustom3;
                    break;
                case "improfilecustom4":

                    returnAttr = imProfileAttributeID.imProfileCustom4;
                    break;
                case "improfilecustom5":

                    returnAttr = imProfileAttributeID.imProfileCustom5;
                    break;
                case "improfilecustom6":

                    returnAttr = imProfileAttributeID.imProfileCustom6;
                    break;
                case "improfilecustom7":

                    returnAttr = imProfileAttributeID.imProfileCustom7;
                    break;
                case "improfilecustom8":

                    returnAttr = imProfileAttributeID.imProfileCustom8;
                    break;
                case "improfilecustom9":

                    returnAttr = imProfileAttributeID.imProfileCustom9;
                    break;
                case "improfilecustom10":

                    returnAttr = imProfileAttributeID.imProfileCustom10;
                    break;
                case "improfilecustom11":

                    returnAttr = imProfileAttributeID.imProfileCustom11;
                    break;
                case "improfilecustom12":

                    returnAttr = imProfileAttributeID.imProfileCustom12;
                    break;
                case "improfilecustom29":

                    returnAttr = imProfileAttributeID.imProfileCustom29;
                    break;
                case "improfilecustom30":

                    returnAttr = imProfileAttributeID.imProfileCustom30;
                    break;
               
                default:
                    returnAttr = imProfileAttributeID.imProfileExternalAsNormal;
                    break;
            }
            return returnAttr;
        }

        private IManWorkspace GetWorkspaceObject(string templateId,IManDatabase db)
        {
            IManWorkspace wrk = null;
            IManWorkspaceSearchParameters workParameter = db.Session.DMS.CreateWorkspaceSearchParameters();
            

            string[] splitChar = { "!" };
            string[] splitString = templateId.Split(splitChar, StringSplitOptions.RemoveEmptyEntries);
            string id = splitString[1];
            IManProfileSearchParameters profileParam = db.Session.DMS.CreateProfileSearchParameters();
            
            workParameter.Add(imFolderAttributeID.imFolderID, id);
            IManFolders folders = db.SearchWorkspaces(profileParam,workParameter);
            if (folders != null && folders.Count > 0)
                wrk = folders.ItemByIndex(1) as IManWorkspace;
            return wrk;

        }
        //Need to be tested well
        private int GetCountOfSubFolders(IManFolders selectedFolderPath, IManFolder template)
        {
            template.Refresh();
            int count = 0;


            int i = 0;

            //Put current folder as template
            IManFolder currentFolder = template;
            
            //For each component in the path
            bool bTemplateMismatch = false;
            foreach (IManFolder fldSubPath in selectedFolderPath)
            {
                //Ignore first component as that is workspace so no need to compare at all
                if (i == 0)
                {
                    i++;
                    continue;
                }
                
                //Get the folder from current folder.subfolders which match by name and type to current path
                currentFolder = GetFolderFromTemplate(currentFolder, fldSubPath);

                //If not available at any level, we need to return 0 since some subpath is not available
                if (currentFolder == null)
                    return 0;
                //If available continue with next subpath

            }

            currentFolder.Refresh();
            currentFolder.SubFolders.Refresh();
            //At the end take the subfolders count.Here the folder will be at that level so next level check

          /*  bool bFoundFolder = false;
            foreach(IManFolder subFolder in currentFolder.SubFolders)
            {
                if (subFolder.ObjectType.ObjectType == imObjectType.imTypeDocumentFolder)
                    bFoundFolder = true;
            }
            if (bFoundFolder)
                count = 1;
            else
                count = 0;*/

            count = currentFolder.SubFolders.Count;



            return count;
        }

        private IManFolder GetFolderFromTemplate(IManFolder currentFolder, IManFolder fldSubPath)
        {
            IManFolder retFOlder = null;
            foreach(IManFolder fld in currentFolder.SubFolders)
            {
                if (fld.Name.ToLower() == fldSubPath.Name.ToLower() && fld.ObjectType == fldSubPath.ObjectType)
                {
                    retFOlder = fld;
                    break;
                }

            }
            return retFOlder;
        }

       

        private int GetLevelOfFolder(IManFolder selectedFolder)
        {
            int level = 0;
            
            while (selectedFolder.Parent != null)
                level++;
            return level;
        }

        private IManWorkspace GetWorkspace(IManFolder selectedFolder)
        {
            IManWorkspace targetWs = null;
            while (selectedFolder.Parent != null)
                selectedFolder = selectedFolder.Parent;
            targetWs = selectedFolder as IManWorkspace;

            return targetWs;
            
        }

        private IManFolder GetSelectItem()
        {
            object objFolder = GetContextItemVal(Context, "SelectedFolderObject");
            IManFolder folder = null;
            if (objFolder != null)
            {
                if (objFolder is IManFolderShortcut)
                {
                    IManFolderShortcut shortCutFolder = objFolder as IManFolderShortcut;
                    if (shortCutFolder != null)
                        folder = shortCutFolder.Resolve();
                }
                else
                    folder = objFolder as IManFolder;
            }
            return folder;
        }

        public string HelpFile
        {
            get
            {
                return mHelpFile;
            }
            set
            {
                mHelpFile = value;
            }
        }

        public int HelpID
        {
            get
            {
                return mHelpID;
            }
            set
            {
                mHelpID = value;
            }
        }

        public string HelpText
        {
            get
            {
                return mHelpText;
            }
            set
            {
                mHelpText = value;
            }
        }

        public void Initialize(ContextItems Context)
        {
            mContext = Context;
            IMANEXTLib.ContextItems cntItems = Context as IMANEXTLib.ContextItems;
            cl.Initialize(cntItems);
        }

        public string MenuText
        {
            get
            {
                return mMenuText;
            }
            set
            {
                mMenuText = value;
            }
        }

        public string Name
        {
            get
            {
                return mName;
            }
            set
            {
                mName = value;
            }
        }

        public int Options
        {
            get
            {
                return mOptions;
            }
            set
            {
                mOptions = value;
            }
        }

        public int Status
        {
            get
            {
                return mStatus;
            }
            set
            {
                mStatus = value;
            }
        }

        public Commands SubCommands
        {
            get
            {
                return mSubCommands;
            }
            set
            {
                mSubCommands = value;
            }
        }

        public string Title
        {
            get
            {
                return mTitle;
            }
            set
            {
                mTitle = value;
            }
        }

        public CommandType Type
        {
            get
            {
                return mType;
            }
            set
            {
                mType = value;
            }
        }

        public void Update()
        {
            //ImccHelper helperClass = new ImccHelper();
            
                //if (helperClass.SpecialPermissions(Context))
                //    Status = (int)CommandStatus.nrActiveCommand;
                //else if (helperClass.HaveUserRights(Context))
                //     Status = (int)CommandStatus.nrActiveCommand;
                //else 
                //    Status = (int)CommandStatus.nrGrayedCommand;

            if (IsFolderOptionEnabled())
            {
                NewIManDocumentFolderCmdClass cl = new NewIManDocumentFolderCmdClass();
                IMANEXTLib.ContextItems cntItems = Context as IMANEXTLib.ContextItems;
                cl.Initialize(cntItems);
                cl.Update();
                Status = cl.Status;
            }
            else
                Status = (int)CommandStatus.nrGrayedCommand;

            
          

        }

       

        public bool IsFolderOptionEnabled()
        {
            bool bRet = true;

            if (!isDatabaseSelected())
            {
                ImccHelper helperClass = new ImccHelper();
                string strIMCCURL = helperClass.GetIMCCURL(Context);
                if (strIMCCURL == null || strIMCCURL.Trim().Length == 0)
                    bRet = false;
            }
            else
                return true;

            return bRet;
        }

        private bool isDatabaseSelected()
        {
            bool bRet = false;
            object objSelected = GetContextItemVal(Context, "SelectedIManObject");

            if(objSelected != null)
            {
                IManDatabase db = objSelected as IManDatabase;
                if (db != null)
                    bRet = true;
            }

            object objFolder = GetContextItemVal(Context, "SelectedFolderObject");
            if(objFolder != null)
            {
                IManObject obj;
                IManFolder fld = objFolder as IManFolder;
               
                while (fld.Parent != null)
                    fld = fld.Parent;
                if (fld.ObjectType.ObjectType == imObjectType.imTypeDocumentFolder || fld.ObjectType.ObjectType == imObjectType.imTypeDocumentSearchFolder)
                    bRet = true;

               
            }   
            
            return bRet;


        }

        public object GetContextItemVal(ContextItems Context, string value)
        {
            object objVal = null;
            try
            {
                objVal = Context.Item(value);

            }
            catch
            {

            }
            return objVal;
        }
       

    }

}
