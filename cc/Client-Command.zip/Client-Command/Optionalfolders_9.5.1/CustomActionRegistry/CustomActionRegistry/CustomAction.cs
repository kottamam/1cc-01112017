using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Deployment.WindowsInstaller;
using Microsoft.Win32;

namespace CustomActionRegistry
{
    public class CustomActions
    {

        const string WorkSite_85_32   = @"SOFTWARE\Interwoven\Worksite\8.0\Common\InstallRoot";
        const string WorkSite_85_64   = @"SOFTWARE\Wow6432Node\Interwoven\Worksite\8.0\Common\InstallRoot";
        const string WorkSite_90_32   = @"SOFTWARE\Interwoven\Worksite\Client\Common\InstallRoot";
        const string WorkSite_90_64   = @"SOFTWARE\Wow6432Node\Interwoven\Worksite\Client\Common\InstallRoot";

        const string Cmd_OptionalFolder = "IManage.Properties";
        const string Cmd_Native1 = "@32798";
        const string Cmd_Native2 = "IManExt2.IManPropertiesCmd";

        const string Cmd_Rename = "OptionalFolders.RenameCmd";
        const string Cmd_Desksite = "@32796";
        const string Cmd_FileSite = "@33752@529";

        const string Cmd_NewFolder = "IManage.FlexibleFolderCmd";
        const string Cmd_NewSearchFolder = "IManage.FlexibleSearchFolderCmd";
        const string Cmd_NewTab = "IManage.FlexibleTabCmd";

        const string Cmd_Desksite_NewFolder = "IManExt2.NewIManDocumentFolderCmd@33991";
        const string Cmd_Desksite_NewSearchFolder = "IManExt2.NewIManDocumentSearchFolderCmd@33992";
        const string Cmd_Desksite_NewTab = "IManExt2.NewIManTabCmd@33990";

        //Filesite to be done
        const string Cmd_FileSite_NewFolder = "IManExt2.NewIManDocumentFolderCmd";
        const string Cmd_FileSite_NewSearchFolder = "IManExt2.NewIManDocumentSearchFolderCmd";
        const string Cmd_FileSite_NewTab = "IManExt2.NewIManTabCmd";


        const string Cmd_iIntegrationDlg_NewFolder = "IManExt2.NewIManDocumentFolderCmd@33851";
        const string Cmd_iIntegrationDlg_NewSearchFolder = "IManExt2.NewIManDocumentSearchFolderCmd@33852";
        const string Cmd_iIntegrationDlg_NewTab = "IManExt2.NewIManTabCmd@33860";

        // **********  For 32-bit Machines - 8.5

        const string Key_FileSite1_Tab_32_85 = @"SOFTWARE\Interwoven\WorkSite\8.0\FileSite\Commands\Tab";
        const string Key_FileSite1_Folder_32_85 = @"SOFTWARE\Interwoven\WorkSite\8.0\FileSite\Commands\Folder";
        const string Key_FileSite1_SearchFolder_32_85 = @"SOFTWARE\Interwoven\WorkSite\8.0\FileSite\Commands\SearchFolder";

        const string Key_DeskSite1_Tab_32_85 = @"SOFTWARE\Interwoven\WorkSite\8.0\DeskSite\Commands\Popup Menus\Folder";
        const string Key_DeskSite1_SearchFolder_32_85 = @"SOFTWARE\Interwoven\WorkSite\8.0\DeskSite\Commands\Popup Menus\SearchFolder";
	   

        const string Key_FileSite4_32_85 = @"SOFTWARE\Interwoven\Worksite\8.0\iManExt\Enhanced Integration Dialog\Toolbar";
        const string Key_FileSite5_32_85 = @"SOFTWARE\Interwoven\Worksite\8.0\iManExt\Browse Dialog\Toolbar";
        const string Key_iManExt1_32_85 =  @"SOFTWARE\Interwoven\WorkSite\8.0\iManExt\Browse Dialog\Popup Menus\Folder";
        const string Key_iManExt1_SearchFolder_32_85 =  @"SOFTWARE\Interwoven\WorkSite\8.0\iManExt\Browse Dialog\Popup Menus\SearchFolder";
        const string Key_iManExt1_Folder_32_85 =  @"SOFTWARE\Interwoven\WorkSite\8.0\iManExt\Browse Dialog\Popup Menus\Folder";
        const string Key_iManExt2_32_85 =  @"SOFTWARE\Interwoven\WorkSite\8.0\iManExt\Enhanced Integration Dialog\Popup Menus\Folder";
        const string Key_iManExt2_SearchFolder_32_85 =  @"SOFTWARE\Interwoven\WorkSite\8.0\iManExt\Enhanced Integration Dialog\Popup Menus\SearchFolder";

        const string Key_iManExt3_32_85 =  @"SOFTWARE\Interwoven\WorkSite\8.0\iIntegrationDlg\Commands\TreePopupMenu\Folder";
        const string Key_iManExt3_SearchFolder_32_85 =  @"SOFTWARE\Interwoven\WorkSite\8.0\iIntegrationDlg\Commands\TreePopupMenu\SearchFolder";

        //From here
        const string Key_Desksite_FolderNew_32_85 = @"SOFTWARE\Interwoven\WorkSite\8.0\DeskSite\Commands\Popup Menus\Folder\New";
        const string Key_Desksite_SearchFolderNew_32_85 = @"SOFTWARE\Interwoven\WorkSite\8.0\DeskSite\Commands\Popup Menus\SearchFolder\New";
        const string Key_Desksite_WorkspaceNew_32_85 = @"SOFTWARE\Interwoven\WorkSite\8.0\DeskSite\Commands\Popup Menus\WorkSpace\New";

        const string Key_FileSite1_TabNew_32_85 = @"SOFTWARE\Interwoven\WorkSite\8.0\FileSite\Commands\Tab\New";
        const string Key_FileSite1_FolderNew_32_85 = @"SOFTWARE\Interwoven\WorkSite\8.0\FileSite\Commands\Folder\New";
        const string Key_FileSite1_SearchFolderNew_32_85 = @"SOFTWARE\Interwoven\WorkSite\8.0\FileSite\Commands\SearchFolder\New";
        const string Key_FileSite1_WorkspaceNew_32_85 = @"SOFTWARE\Interwoven\WorkSite\8.0\FileSite\Commands\Workspace\New";

        const string Key_iManExt1_FolderNew_32_85 = @"SOFTWARE\Interwoven\WorkSite\8.0\iManExt\Browse Dialog\Popup Menus\Folder\New";
        const string Key_iManExt1_SearchFolderNew_32_85 = @"SOFTWARE\Interwoven\WorkSite\8.0\iManExt\Browse Dialog\Popup Menus\SearchFolder\New";
        const string Key_iManExt1_WorkspaceNew_32_85 = @"SOFTWARE\Interwoven\WorkSite\8.0\iManExt\Browse Dialog\Popup Menus\WorkSpace\New";
        
        const string Key_iManExt2_FolderNew_32_85 = @"SOFTWARE\Interwoven\WorkSite\8.0\iManExt\Enhanced Integration Dialog\Popup Menus\Folder\New";
        const string Key_iManExt2_SearchFolderNew_32_85 = @"SOFTWARE\Interwoven\WorkSite\8.0\iManExt\Enhanced Integration Dialog\Popup Menus\SearchFolder\New";
        const string Key_iManExt2_WorkSpaceNew_32_85 = @"SOFTWARE\Interwoven\WorkSite\8.0\iManExt\Enhanced Integration Dialog\Popup Menus\WorkSpace\New";

        const string Key_iManExt3_FolderNew_32_85 = @"SOFTWARE\Interwoven\WorkSite\8.0\iIntegrationDlg\Commands\TreePopupMenu\Folder\New";
        const string Key_iManExt3_SearchFolderNew_32_85 = @"SOFTWARE\Interwoven\WorkSite\8.0\iIntegrationDlg\Commands\TreePopupMenu\SearchFolder\New";
        const string Key_iManExt3_WorkspaceNew_32_85 = @"SOFTWARE\Interwoven\WorkSite\8.0\iIntegrationDlg\Commands\TreePopupMenu\Workspace\New";

        // ********** For 64-bit Machines - 8.5

        const string Key_FileSite1_Tab_64_85 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\8.0\FileSite\Commands\Tab";
        const string Key_FileSite1_Folder_64_85 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\8.0\FileSite\Commands\Folder";
        const string Key_FileSite1_SearchFolder_64_85 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\8.0\FileSite\Commands\SearchFolder";

        const string Key_DeskSite1_Tab_64_85 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\8.0\DeskSite\Commands\Popup Menus\Folder"	;	   
        const string Key_DeskSite1_SearchFolder_64_85 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\8.0\DeskSite\Commands\Popup Menus\SearchFolder";


        const string Key_FileSite4_64_85 = @"SOFTWARE\Wow6432Node\Interwoven\Worksite\8.0\iManExt\Enhanced Integration Dialog\Toolbar";
        const string Key_FileSite5_64_85 = @"SOFTWARE\Wow6432Node\Interwoven\Worksite\8.0\iManExt\Browse Dialog\Toolbar";
        const string Key_iManExt1_64_85 =  @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\8.0\iManExt\Browse Dialog\Popup Menus\Folder";
        const string Key_iManExt1_SearchFolder_64_85 =  @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\8.0\iManExt\Browse Dialog\Popup Menus\SearchFolder";
        const string Key_iManExt2_64_85 =  @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\8.0\iManExt\Enhanced Integration Dialog\Popup Menus\Folder";
        const string Key_iManExt2_SearchFolder_64_85 =  @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\8.0\iManExt\Enhanced Integration Dialog\Popup Menus\SearchFolder";

        const string Key_iManExt3_64_85 =  @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\8.0\iIntegrationDlg\Commands\TreePopupMenu\Folder";
        const string Key_iManExt3_SearchFolder_64_85 =  @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\8.0\iIntegrationDlg\Commands\TreePopupMenu\SearchFolder";

        //From here
        const string Key_Desksite_FolderNew_64_85 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\8.0\DeskSite\Commands\Popup Menus\Folder\New";
        const string Key_Desksite_SearchFolderNew_64_85 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\8.0\DeskSite\Commands\Popup Menus\SearchFolder\New";
        const string Key_Desksite_WorkspaceNew_64_85 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\8.0\DeskSite\Commands\Popup Menus\WorkSpace\New";

        const string Key_FileSite1_TabNew_64_85 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\FileSite\Commands\Tab\New";
        const string Key_FileSite1_FolderNew_64_85 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\8.0\FileSite\Commands\Folder\New";
        const string Key_FileSite1_SearchFolderNew_64_85 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\8.0\FileSite\Commands\SearchFolder\New";
        const string Key_FileSite1_WorkspaceNew_64_85 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\8.0\FileSite\Commands\Workspace\New";

        const string Key_iManExt1_FolderNew_64_85 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\8.0\iManExt\Browse Dialog\Popup Menus\Folder\New";
        const string Key_iManExt1_SearchFolderNew_64_85 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\8.0\iManExt\Browse Dialog\Popup Menus\SearchFolder\New";
        const string Key_iManExt1_WorkspaceNew_64_85 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\8.0\iManExt\Browse Dialog\Popup Menus\WorkSpace\New";

        const string Key_iManExt2_FolderNew_64_85 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\8.0\iManExt\Enhanced Integration Dialog\Popup Menus\Folder\New";
        const string Key_iManExt2_SearchFolderNew_64_85 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\8.0\iManExt\Enhanced Integration Dialog\Popup Menus\SearchFolder\New";
        const string Key_iManExt2_WorkSpaceNew_64_85 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\8.0\iManExt\Enhanced Integration Dialog\Popup Menus\WorkSpace\New";

        const string Key_iManExt3_FolderNew_64_85 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\8.0\iIntegrationDlg\Commands\TreePopupMenu\Folder\New";
        const string Key_iManExt3_SearchFolderNew_64_85 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\8.0\iIntegrationDlg\Commands\TreePopupMenu\SearchFolder\New";
        const string Key_iManExt3_WorkspaceNew_64_85 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\8.0\iIntegrationDlg\Commands\TreePopupMenu\Workspace\New";


        //**********  For 32-bit Machines - 9.0

        const string Key_FileSite1_Tab_32_90 = @"SOFTWARE\Interwoven\WorkSite\Client\FileSite\Commands\Tab";
        const string Key_FileSite1_Folder_32_90 = @"SOFTWARE\Interwoven\WorkSite\Client\FileSite\Commands\Folder";
        const string Key_FileSite1_SearchFolder_32_90 = @"SOFTWARE\Interwoven\WorkSite\Client\FileSite\Commands\SearchFolder";

        const string Key_DeskSite1_Tab_32_90 = @"SOFTWARE\Interwoven\WorkSite\Client\DeskSite\Commands\Popup Menus\Folder";	
        const string Key_DeskSite1_SearchFolder_32_90 = @"SOFTWARE\Interwoven\WorkSite\Client\DeskSite\Commands\Popup Menus\SearchFolder"	   ;

        const string Key_FileSite4_32_90 = @"SOFTWARE\Interwoven\Worksite\Client\iManExt\Enhanced Integration Dialog\Toolbar";
        const string Key_FileSite5_32_90 = @"SOFTWARE\Interwoven\Worksite\Client\iManExt\Browse Dialog\Toolbar";
        const string Key_iManExt1_32_90 =  @"SOFTWARE\Interwoven\WorkSite\Client\iManExt\Browse Dialog\Popup Menus\Folder";
        const string Key_iManExt1_SearchFolder_32_90 = @"SOFTWARE\Interwoven\WorkSite\Client\iManExt\Browse Dialog\Popup Menus\SearchFolder";
        const string Key_iManExt2_32_90 =  @"SOFTWARE\Interwoven\WorkSite\Client\iManExt\Enhanced Integration Dialog\Popup Menus\Folder";
        const string Key_iManExt2_SearchFolder_32_90 =  @"SOFTWARE\Interwoven\WorkSite\Client\iManExt\Enhanced Integration Dialog\Popup Menus\SearchFolder";

        const string Key_iManExt3_32_90 =  @"SOFTWARE\Interwoven\WorkSite\Client\iIntegrationDlg\Commands\TreePopupMenu\Folder";
        const string Key_iManExt3_SearchFolder_32_90 =  @"SOFTWARE\Interwoven\WorkSite\Client\iIntegrationDlg\Commands\TreePopupMenu\SearchFolder";


        //From here
        const string Key_Desksite_FolderNew_32_90 = @"SOFTWARE\Interwoven\WorkSite\Client\DeskSite\Commands\Popup Menus\Folder\New";
        const string Key_Desksite_SearchFolderNew_32_90 = @"SOFTWARE\Interwoven\WorkSite\Client\DeskSite\Commands\Popup Menus\SearchFolder\New";
        const string Key_Desksite_WorkspaceNew_32_90 = @"SOFTWARE\Interwoven\WorkSite\Client\DeskSite\Commands\Popup Menus\WorkSpace\New";

        const string Key_FileSite1_TabNew_32_90 = @"SOFTWARE\Interwoven\WorkSite\Client\FileSite\Commands\Tab\New";
        const string Key_FileSite1_FolderNew_32_90 = @"SOFTWARE\Interwoven\WorkSite\Client\FileSite\Commands\Folder\New";
        const string Key_FileSite1_SearchFolderNew_32_90 = @"SOFTWARE\Interwoven\WorkSite\Client\FileSite\Commands\SearchFolder\New";
        const string Key_FileSite1_WorkspaceNew_32_90 = @"SOFTWARE\Interwoven\WorkSite\Client\FileSite\Commands\Workspace\New";

        const string Key_iManExt1_FolderNew_32_90 = @"SOFTWARE\Interwoven\WorkSite\Client\iManExt\Browse Dialog\Popup Menus\Folder\New";
        const string Key_iManExt1_SearchFolderNew_32_90 = @"SOFTWARE\Interwoven\WorkSite\Client\iManExt\Browse Dialog\Popup Menus\SearchFolder\New";
        const string Key_iManExt1_WorkspaceNew_32_90 = @"SOFTWARE\Interwoven\WorkSite\Client\iManExt\Browse Dialog\Popup Menus\WorkSpace\New";

        const string Key_iManExt2_FolderNew_32_90 = @"SOFTWARE\Interwoven\WorkSite\Client\iManExt\Enhanced Integration Dialog\Popup Menus\Folder\New";
        const string Key_iManExt2_SearchFolderNew_32_90 = @"SOFTWARE\Interwoven\WorkSite\Client\iManExt\Enhanced Integration Dialog\Popup Menus\SearchFolder\New";
        const string Key_iManExt2_WorkSpaceNew_32_90 = @"SOFTWARE\Interwoven\WorkSite\Client\iManExt\Enhanced Integration Dialog\Popup Menus\WorkSpace\New";

        const string Key_iManExt3_FolderNew_32_90 = @"SOFTWARE\Interwoven\WorkSite\Client\iIntegrationDlg\Commands\TreePopupMenu\Folder\New";
        const string Key_iManExt3_SearchFolderNew_32_90 = @"SOFTWARE\Interwoven\WorkSite\Client\iIntegrationDlg\Commands\TreePopupMenu\SearchFolder\New";
        const string Key_iManExt3_WorkspaceNew_32_90 = @"SOFTWARE\Interwoven\WorkSite\Client\iIntegrationDlg\Commands\TreePopupMenu\Workspace\New";


        // ********** For 64-bit Machines - 9.0

        const string Key_FileSite1_Tab_64_90 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\Client\FileSite\Commands\Tab";
        const string Key_FileSite1_Folder_64_90 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\Client\FileSite\Commands\Folder";
        const string Key_FileSite1_SearchFolder_64_90 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\Client\FileSite\Commands\SearchFolder";

        const string Key_DeskSite1_Tab_64_90 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\Client\DeskSite\Commands\Popup Menus\Folder";
        const string Key_DeskSite1_SearchFolder_64_90 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\Client\DeskSite\Commands\Popup Menus\SearchFolder"		   ;

        const string Key_FileSite4_64_90 = @"SOFTWARE\Wow6432Node\Interwoven\Worksite\Client\iManExt\Enhanced Integration Dialog\Toolbar";
        const string Key_FileSite5_64_90 = @"SOFTWARE\Wow6432Node\Interwoven\Worksite\Client\iManExt\Browse Dialog\Toolbar";
        const string Key_iManExt1_64_90 =  @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\Client\iManExt\Browse Dialog\Popup Menus\Folder";
        const string Key_iManExt1_SearchFolder_64_90 =  @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\Client\iManExt\Browse Dialog\Popup Menus\SearchFolder";
        const string Key_iManExt2_64_90 =  @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\Client\iManExt\Enhanced Integration Dialog\Popup Menus\Folder";
        const string Key_iManExt2_SearchFolder_64_90 =  @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\Client\iManExt\Enhanced Integration Dialog\Popup Menus\SearchFolder";

        const string Key_iManExt3_64_90 =  @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\Client\iIntegrationDlg\Commands\TreePopupMenu\Folder";
        const string Key_iManExt3_SearchFolder_64_90 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\Client\iIntegrationDlg\Commands\TreePopupMenu\SearchFolder";

        //From here
        const string Key_Desksite_FolderNew_64_90 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\Client\DeskSite\Commands\Popup Menus\Folder\New";
        const string Key_Desksite_SearchFolderNew_64_90 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\Client\DeskSite\Commands\Popup Menus\SearchFolder\New";
        const string Key_Desksite_WorkspaceNew_64_90 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\Client\DeskSite\Commands\Popup Menus\WorkSpace\New";

        const string Key_FileSite1_TabNew_64_90 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\Client\FileSite\Commands\Tab\New";
        const string Key_FileSite1_FolderNew_64_90 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\Client\FileSite\Commands\Folder\New";
        const string Key_FileSite1_SearchFolderNew_64_90 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\Client\FileSite\Commands\SearchFolder\New";
        const string Key_FileSite1_WorkspaceNew_64_90 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\Client\FileSite\Commands\Workspace\New";

        const string Key_iManExt1_FolderNew_64_90 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\Client\iManExt\Browse Dialog\Popup Menus\Folder\New";
        const string Key_iManExt1_SearchFolderNew_64_90 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\Client\iManExt\Browse Dialog\Popup Menus\SearchFolder\New";
        const string Key_iManExt1_WorkspaceNew_64_90 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\Client\iManExt\Browse Dialog\Popup Menus\WorkSpace\New";

        const string Key_iManExt2_FolderNew_64_90 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\Client\iManExt\Enhanced Integration Dialog\Popup Menus\Folder\New";
        const string Key_iManExt2_SearchFolderNew_64_90 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\Client\iManExt\Enhanced Integration Dialog\Popup Menus\SearchFolder\New";
        const string Key_iManExt2_WorkSpaceNew_64_90 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\Client\iManExt\Enhanced Integration Dialog\Popup Menus\WorkSpace\New";

        const string Key_iManExt3_FolderNew_64_90 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\Client\iIntegrationDlg\Commands\TreePopupMenu\Folder\New";
        const string Key_iManExt3_SearchFolderNew_64_90 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\Client\iIntegrationDlg\Commands\TreePopupMenu\SearchFolder\New";
        const string Key_iManExt3_WorkspaceNew_64_90 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\Client\iIntegrationDlg\Commands\TreePopupMenu\Workspace\New";




        [CustomAction]
        public static ActionResult RegisterProperties(Session session)
        {
            string WSVer_OSBit = string.Empty;
            try
            {
                session.Log("Register Properties started");
                //NT-58503- 8.0 and 9.0 , 9.0 should take priority
                if (KeyExists(WorkSite_90_32, true))
                    WSVer_OSBit = "90 32";
                else if (KeyExists(WorkSite_90_64, false))
                    WSVer_OSBit = "90 64";
                else if (KeyExists(WorkSite_85_32, true))
                    WSVer_OSBit = "85 32";
                else if (KeyExists(WorkSite_85_64, false))
                    WSVer_OSBit = "85 64";
               
                
                if (WSVer_OSBit.Trim().Length == 0)
                {
                    session.Log("Desksite/Filesite not found");
                    return ActionResult.NotExecuted;
                }


                if (WSVer_OSBit == "85 32")
                {


                    //---------------------
                    //--FOR 32-bit MACHINES  Version 8.5
                    //---------------------
                    //---------------------


                    if (!CommandExists(Key_DeskSite1_Tab_32_85, Cmd_OptionalFolder, true))
                        ReplaceCommands(Key_DeskSite1_Tab_32_85, Cmd_Native1, Cmd_OptionalFolder, true);

                    session.Log(Key_DeskSite1_Tab_32_85 + "Registration over");

                    if (!CommandExists(Key_FileSite1_Tab_32_85, Cmd_OptionalFolder, true))
                        ReplaceCommands(Key_FileSite1_Tab_32_85, Cmd_Native2, Cmd_OptionalFolder, true);
                    session.Log(Key_FileSite1_Tab_32_85 + "Registration over");





                    if (!CommandExists(Key_FileSite4_32_85, Cmd_OptionalFolder, true))
                        ReplaceCommands(Key_FileSite4_32_85, Cmd_Native2, Cmd_OptionalFolder, true);
                    session.Log(Key_FileSite4_32_85 + "Registration over");

                    if (!CommandExists(Key_FileSite5_32_85, Cmd_OptionalFolder, true))
                        ReplaceCommands(Key_FileSite5_32_85, Cmd_Native2, Cmd_OptionalFolder, true);

                    session.Log(Key_FileSite5_32_85 + "Registration over");
                    if (!CommandExists(Key_iManExt1_32_85, Cmd_OptionalFolder, true))
                        ReplaceCommands(Key_iManExt1_32_85, Cmd_Native2, Cmd_OptionalFolder, true);

                    session.Log(Key_iManExt1_32_85 + "Registration over");
                    if (!CommandExists(Key_iManExt2_32_85, Cmd_OptionalFolder, true))
                        ReplaceCommands(Key_iManExt2_32_85, Cmd_Native2, Cmd_OptionalFolder, true);
                    session.Log(Key_iManExt2_32_85 + "Registration over");
                    //Added
                    if (!CommandExists(Key_FileSite1_Folder_32_85, Cmd_OptionalFolder, true))
                        ReplaceCommands(Key_FileSite1_Folder_32_85, Cmd_Native2, Cmd_OptionalFolder, true);
                    session.Log(Key_FileSite1_Folder_32_85 + "Registration over");

                    if (!CommandExists(Key_FileSite1_SearchFolder_32_85, Cmd_OptionalFolder, true))
                        ReplaceCommands(Key_FileSite1_SearchFolder_32_85, Cmd_Native2, Cmd_OptionalFolder, true);
                    session.Log(Key_FileSite1_SearchFolder_32_85 + "Registration over");

                    if (!CommandExists(Key_iManExt2_SearchFolder_32_85, Cmd_OptionalFolder, true))
                        ReplaceCommands(Key_iManExt2_SearchFolder_32_85, Cmd_Native2, Cmd_OptionalFolder, true);
                    session.Log(Key_iManExt2_SearchFolder_32_85 + "Registration over");
                    if (!CommandExists(Key_iManExt1_SearchFolder_32_85, Cmd_OptionalFolder, true))
                        ReplaceCommands(Key_iManExt1_SearchFolder_32_85, Cmd_Native2, Cmd_OptionalFolder, true);
                    session.Log(Key_iManExt1_SearchFolder_32_85 + "Registration over");

                    if (!CommandExists(Key_iManExt3_32_85, Cmd_OptionalFolder, true))
                        ReplaceCommands(Key_iManExt3_32_85, Cmd_Native2, Cmd_OptionalFolder, true);
                    session.Log(Key_iManExt3_32_85 + "Registration over");
                    if (!CommandExists(Key_iManExt3_SearchFolder_32_85, Cmd_OptionalFolder, true))
                        ReplaceCommands(Key_iManExt3_SearchFolder_32_85, Cmd_Native2, Cmd_OptionalFolder, true);
                    session.Log(Key_iManExt3_SearchFolder_32_85 + "Registration over");

                    if (!CommandExists(Key_DeskSite1_SearchFolder_32_85, Cmd_OptionalFolder, true))
                        ReplaceCommands(Key_DeskSite1_SearchFolder_32_85, Cmd_Native1, Cmd_OptionalFolder, true);
                    session.Log(Key_DeskSite1_SearchFolder_32_85 + "Registration over");
                    // Rename
                    if (!CommandExists(Key_DeskSite1_Tab_32_85, Cmd_Rename, true))
                        ReplaceCommands(Key_DeskSite1_Tab_32_85, Cmd_Desksite, Cmd_Rename, true);
                    session.Log(Key_DeskSite1_Tab_32_85 + "Registration over");


                    if (!CommandExists(Key_FileSite1_Tab_32_85, Cmd_Rename, true))
                        ReplaceCommands(Key_FileSite1_Tab_32_85, Cmd_FileSite, Cmd_Rename, true);
                    session.Log(Key_FileSite1_Tab_32_85 + "Registration over");




                    if (!CommandExists(Key_FileSite1_Folder_32_85, Cmd_Rename, true))
                        ReplaceCommands(Key_FileSite1_Folder_32_85, Cmd_FileSite, Cmd_Rename, true);
                    session.Log(Key_FileSite1_Folder_32_85 + "Registration over");

                    if (!CommandExists(Key_FileSite1_SearchFolder_32_85, Cmd_Rename, true))
                        ReplaceCommands(Key_FileSite1_SearchFolder_32_85, Cmd_FileSite, Cmd_Rename, true);
                    session.Log(Key_FileSite1_SearchFolder_32_85 + "Registration over");
                    if (!CommandExists(Key_DeskSite1_SearchFolder_32_85, Cmd_Rename, true))
                        ReplaceCommands(Key_DeskSite1_SearchFolder_32_85, Cmd_Desksite, Cmd_Rename, true);

                    //From here

                    //Search folder new for Desksite
                    if (!CommandExists(Key_Desksite_SearchFolderNew_32_85, Cmd_NewSearchFolder, true))
                        ReplaceCommands(Key_Desksite_SearchFolderNew_32_85, Cmd_Desksite_NewSearchFolder, Cmd_NewSearchFolder, true);
                    if (!CommandExists(Key_Desksite_SearchFolderNew_32_85, Cmd_NewFolder, true))
                        ReplaceCommands(Key_Desksite_SearchFolderNew_32_85, Cmd_Desksite_NewFolder, Cmd_NewFolder, true);

                    //folder new for Desksite
                    if (!CommandExists(Key_Desksite_FolderNew_32_85, Cmd_NewSearchFolder, true))
                        ReplaceCommands(Key_Desksite_FolderNew_32_85, Cmd_Desksite_NewSearchFolder, Cmd_NewSearchFolder, true);
                    if (!CommandExists(Key_Desksite_FolderNew_32_85, Cmd_NewFolder, true))
                        ReplaceCommands(Key_Desksite_FolderNew_32_85, Cmd_Desksite_NewFolder, Cmd_NewFolder, true);

                    //Workspace new for Desksite
                    if (!CommandExists(Key_Desksite_WorkspaceNew_32_85, Cmd_NewSearchFolder, true))
                        ReplaceCommands(Key_Desksite_WorkspaceNew_32_85, Cmd_Desksite_NewSearchFolder, Cmd_NewSearchFolder, true);
                    if (!CommandExists(Key_Desksite_WorkspaceNew_32_85, Cmd_NewFolder, true))
                        ReplaceCommands(Key_Desksite_WorkspaceNew_32_85, Cmd_Desksite_NewFolder, Cmd_NewFolder, true);
                    if (!CommandExists(Key_Desksite_WorkspaceNew_32_85, Cmd_NewTab, true))
                        ReplaceCommands(Key_Desksite_WorkspaceNew_32_85, Cmd_Desksite_NewTab, Cmd_NewTab, true);

                    
                    //Search folder new for Filesite
                    if (!CommandExists(Key_FileSite1_SearchFolderNew_32_85, Cmd_NewSearchFolder, true))
                        ReplaceCommands(Key_FileSite1_SearchFolderNew_32_85, Cmd_FileSite_NewSearchFolder, Cmd_NewSearchFolder, true);
                    if (!CommandExists(Key_FileSite1_SearchFolderNew_32_85, Cmd_NewFolder, true))
                        ReplaceCommands(Key_FileSite1_SearchFolderNew_32_85, Cmd_FileSite_NewFolder, Cmd_NewFolder, true);

                    //folder new for Filesite
                    if (!CommandExists(Key_FileSite1_FolderNew_32_85, Cmd_NewSearchFolder, true))
                        ReplaceCommands(Key_FileSite1_FolderNew_32_85, Cmd_FileSite_NewSearchFolder, Cmd_NewSearchFolder, true);
                    if (!CommandExists(Key_FileSite1_FolderNew_32_85, Cmd_NewFolder, true))
                        ReplaceCommands(Key_FileSite1_FolderNew_32_85, Cmd_FileSite_NewFolder, Cmd_NewFolder, true);

                    //Tab new for Filesite
                    if (!CommandExists(Key_FileSite1_TabNew_32_85, Cmd_NewSearchFolder, true))
                        ReplaceCommands(Key_FileSite1_TabNew_32_85, Cmd_FileSite_NewSearchFolder, Cmd_NewSearchFolder, true);
                    if (!CommandExists(Key_FileSite1_TabNew_32_85, Cmd_NewFolder, true))
                        ReplaceCommands(Key_FileSite1_TabNew_32_85, Cmd_FileSite_NewFolder, Cmd_NewFolder, true);

                    //Workspace new for Filesite
                    if (!CommandExists(Key_FileSite1_WorkspaceNew_32_85, Cmd_NewSearchFolder, true))
                        ReplaceCommands(Key_FileSite1_WorkspaceNew_32_85, Cmd_FileSite_NewSearchFolder, Cmd_NewSearchFolder, true);
                    if (!CommandExists(Key_FileSite1_WorkspaceNew_32_85, Cmd_NewFolder, true))
                        ReplaceCommands(Key_FileSite1_WorkspaceNew_32_85, Cmd_FileSite_NewFolder, Cmd_NewFolder, true);
                    if (!CommandExists(Key_FileSite1_WorkspaceNew_32_85, Cmd_NewTab, true))
                        ReplaceCommands(Key_FileSite1_WorkspaceNew_32_85, Cmd_FileSite_NewTab, Cmd_NewTab, true);

                    //iManext1
                    //Search folder new for imanext1
                    if (!CommandExists(Key_iManExt1_SearchFolderNew_32_85, Cmd_NewSearchFolder, true))
                        ReplaceCommands(Key_iManExt1_SearchFolderNew_32_85, Cmd_Desksite_NewSearchFolder, Cmd_NewSearchFolder, true);
                    if (!CommandExists(Key_iManExt1_SearchFolderNew_32_85, Cmd_NewFolder, true))
                        ReplaceCommands(Key_iManExt1_SearchFolderNew_32_85, Cmd_Desksite_NewFolder, Cmd_NewFolder, true);

                    //folder new for imanext1
                    if (!CommandExists(Key_iManExt1_FolderNew_32_85, Cmd_NewSearchFolder, true))
                        ReplaceCommands(Key_iManExt1_FolderNew_32_85, Cmd_Desksite_NewSearchFolder, Cmd_NewSearchFolder, true);
                    if (!CommandExists(Key_iManExt1_FolderNew_32_85, Cmd_NewFolder, true))
                        ReplaceCommands(Key_iManExt1_FolderNew_32_85, Cmd_Desksite_NewFolder, Cmd_NewFolder, true);

                    //Workspace new for imanext1
                    if (!CommandExists(Key_iManExt1_WorkspaceNew_32_85, Cmd_NewSearchFolder, true))
                        ReplaceCommands(Key_iManExt1_WorkspaceNew_32_85, Cmd_Desksite_NewSearchFolder, Cmd_NewSearchFolder, true);
                    if (!CommandExists(Key_iManExt1_WorkspaceNew_32_85, Cmd_NewFolder, true))
                        ReplaceCommands(Key_iManExt1_WorkspaceNew_32_85, Cmd_Desksite_NewFolder, Cmd_NewFolder, true);
                    if (!CommandExists(Key_iManExt1_WorkspaceNew_32_85, Cmd_NewTab, true))
                        ReplaceCommands(Key_iManExt1_WorkspaceNew_32_85, Cmd_Desksite_NewTab, Cmd_NewTab, true);

                    //imanext2
                    //Search folder new for imanext2
                    if (!CommandExists(Key_iManExt2_SearchFolderNew_32_85, Cmd_NewSearchFolder, true))
                        ReplaceCommands(Key_iManExt2_SearchFolderNew_32_85, Cmd_Desksite_NewSearchFolder, Cmd_NewSearchFolder, true);
                    if (!CommandExists(Key_iManExt2_SearchFolderNew_32_85, Cmd_NewFolder, true))
                        ReplaceCommands(Key_iManExt2_SearchFolderNew_32_85, Cmd_Desksite_NewFolder, Cmd_NewFolder, true);

                    //folder new for imanext2
                    if (!CommandExists(Key_iManExt2_FolderNew_32_85, Cmd_NewSearchFolder, true))
                        ReplaceCommands(Key_iManExt2_FolderNew_32_85, Cmd_Desksite_NewSearchFolder, Cmd_NewSearchFolder, true);
                    if (!CommandExists(Key_iManExt2_FolderNew_32_85, Cmd_NewFolder, true))
                        ReplaceCommands(Key_iManExt2_FolderNew_32_85, Cmd_Desksite_NewFolder, Cmd_NewFolder, true);

                    //Workspace new for imanext2
                    if (!CommandExists(Key_iManExt2_WorkSpaceNew_32_85, Cmd_NewSearchFolder, true))
                        ReplaceCommands(Key_iManExt2_WorkSpaceNew_32_85, Cmd_Desksite_NewSearchFolder, Cmd_NewSearchFolder, true);
                    if (!CommandExists(Key_iManExt2_WorkSpaceNew_32_85, Cmd_NewFolder, true))
                        ReplaceCommands(Key_iManExt2_WorkSpaceNew_32_85, Cmd_Desksite_NewFolder, Cmd_NewFolder, true);
                    if (!CommandExists(Key_iManExt2_WorkSpaceNew_32_85, Cmd_NewTab, true))
                        ReplaceCommands(Key_iManExt2_WorkSpaceNew_32_85, Cmd_Desksite_NewTab, Cmd_NewTab, true);

                    //imanext3
                    //Search folder new for imanext3
                    if (!CommandExists(Key_iManExt3_SearchFolderNew_32_85, Cmd_NewSearchFolder, true))
                        ReplaceCommands(Key_iManExt3_SearchFolderNew_32_85, Cmd_iIntegrationDlg_NewSearchFolder, Cmd_NewSearchFolder, true);
                    if (!CommandExists(Key_iManExt3_SearchFolderNew_32_85, Cmd_NewFolder, true))
                        ReplaceCommands(Key_iManExt3_SearchFolderNew_32_85, Cmd_iIntegrationDlg_NewFolder, Cmd_NewFolder, true);

                    //folder new for imanext3
                    if (!CommandExists(Key_iManExt3_FolderNew_32_85, Cmd_NewSearchFolder, true))
                        ReplaceCommands(Key_iManExt3_FolderNew_32_85, Cmd_iIntegrationDlg_NewSearchFolder, Cmd_NewSearchFolder, true);
                    if (!CommandExists(Key_iManExt3_FolderNew_32_85, Cmd_NewFolder, true))
                        ReplaceCommands(Key_iManExt3_FolderNew_32_85, Cmd_iIntegrationDlg_NewFolder, Cmd_NewFolder, true);

                    //Workspace new for imanext3
                    if (!CommandExists(Key_iManExt3_WorkspaceNew_32_85, Cmd_NewSearchFolder, true))
                        ReplaceCommands(Key_iManExt3_WorkspaceNew_32_85, Cmd_iIntegrationDlg_NewSearchFolder, Cmd_NewSearchFolder, true);
                    if (!CommandExists(Key_iManExt3_WorkspaceNew_32_85, Cmd_NewFolder, true))
                        ReplaceCommands(Key_iManExt3_WorkspaceNew_32_85, Cmd_iIntegrationDlg_NewFolder, Cmd_NewFolder, true);
                    if (!CommandExists(Key_iManExt3_WorkspaceNew_32_85, Cmd_NewTab, true))
                        ReplaceCommands(Key_iManExt3_WorkspaceNew_32_85, Cmd_iIntegrationDlg_NewTab, Cmd_NewTab, true);


                    session.Log("Completed 85 32");




                }


                else if (WSVer_OSBit == "85 64")
                {

                    //---------------------
                    //--FOR 64-bit MACHINES
                    //---------------------


                    if (!CommandExists(Key_DeskSite1_Tab_64_85, Cmd_OptionalFolder, false))
                        ReplaceCommands(Key_DeskSite1_Tab_64_85, Cmd_Native1, Cmd_OptionalFolder, false);

                    session.Log(Key_DeskSite1_Tab_64_85 + "Registration over");


                    if (!CommandExists(Key_FileSite1_Tab_64_85, Cmd_OptionalFolder, false))
                        ReplaceCommands(Key_FileSite1_Tab_64_85, Cmd_Native2, Cmd_OptionalFolder, false);

                    session.Log(Key_FileSite1_Tab_64_85 + "Registration over");




                    if (!CommandExists(Key_FileSite4_64_85, Cmd_OptionalFolder, false))
                        ReplaceCommands(Key_FileSite4_64_85, Cmd_Native2, Cmd_OptionalFolder, false);

                    session.Log(Key_FileSite4_64_85 + "Registration over");
                    if (!CommandExists(Key_FileSite5_64_85, Cmd_OptionalFolder, false))
                        ReplaceCommands(Key_FileSite5_64_85, Cmd_Native2, Cmd_OptionalFolder, false);

                    session.Log(Key_FileSite5_64_85 + "Registration over");
                    if (!CommandExists(Key_iManExt1_64_85, Cmd_OptionalFolder, false))
                        ReplaceCommands(Key_iManExt1_64_85, Cmd_Native2, Cmd_OptionalFolder, false);

                    session.Log(Key_iManExt1_64_85 + "Registration over");
                    if (!CommandExists(Key_iManExt2_64_85, Cmd_OptionalFolder, false))
                        ReplaceCommands(Key_iManExt2_64_85, Cmd_Native2, Cmd_OptionalFolder, false);
                    session.Log(Key_iManExt2_64_85 + "Registration over");
                    //Added
                    if (!CommandExists(Key_FileSite1_Folder_64_85, Cmd_OptionalFolder, false))
                        ReplaceCommands(Key_FileSite1_Folder_64_85, Cmd_Native2, Cmd_OptionalFolder, false);
                    session.Log(Key_FileSite1_Folder_64_85 + "Registration over");
                    if (!CommandExists(Key_FileSite1_SearchFolder_64_85, Cmd_OptionalFolder, false))
                        ReplaceCommands(Key_FileSite1_SearchFolder_64_85, Cmd_Native2, Cmd_OptionalFolder, false);
                    session.Log(Key_FileSite1_SearchFolder_64_85 + "Registration over");
                    if (!CommandExists(Key_iManExt2_SearchFolder_64_85, Cmd_OptionalFolder, false))
                        ReplaceCommands(Key_iManExt2_SearchFolder_64_85, Cmd_Native2, Cmd_OptionalFolder, false);
                    session.Log(Key_iManExt2_SearchFolder_64_85 + "Registration over");
                    if (!CommandExists(Key_iManExt1_SearchFolder_64_85, Cmd_OptionalFolder, false))
                        ReplaceCommands(Key_iManExt1_SearchFolder_64_85, Cmd_Native2, Cmd_OptionalFolder, false);
                    session.Log(Key_iManExt1_SearchFolder_64_85 + "Registration over");
                    if (!CommandExists(Key_iManExt3_64_85, Cmd_OptionalFolder, false))
                        ReplaceCommands(Key_iManExt3_64_85, Cmd_Native2, Cmd_OptionalFolder, false);
                    session.Log(Key_iManExt3_64_85 + "Registration over");
                    if (!CommandExists(Key_iManExt3_SearchFolder_64_85, Cmd_OptionalFolder, false))
                        ReplaceCommands(Key_iManExt3_SearchFolder_64_85, Cmd_Native2, Cmd_OptionalFolder, false);
                    session.Log(Key_iManExt3_SearchFolder_64_85 + "Registration over");
                    if (!CommandExists(Key_DeskSite1_SearchFolder_64_85, Cmd_OptionalFolder, false))
                        ReplaceCommands(Key_DeskSite1_SearchFolder_64_85, Cmd_Native1, Cmd_OptionalFolder, false);
                    session.Log(Key_DeskSite1_SearchFolder_64_85 + "Registration over");
                    //Rename
                    if (!CommandExists(Key_DeskSite1_Tab_64_85, Cmd_Rename, false))
                        ReplaceCommands(Key_DeskSite1_Tab_64_85, Cmd_Desksite, Cmd_Rename, false);
                    session.Log(Key_DeskSite1_Tab_64_85 + "Registration over");



                    if (!CommandExists(Key_FileSite1_Tab_64_85, Cmd_Rename, false))
                        ReplaceCommands(Key_FileSite1_Tab_64_85, Cmd_FileSite, Cmd_Rename, false);
                    session.Log(Key_FileSite1_Tab_64_85 + "Registration over");


                    if (!CommandExists(Key_FileSite1_Folder_64_85, Cmd_Rename, false))
                        ReplaceCommands(Key_FileSite1_Folder_64_85, Cmd_FileSite, Cmd_Rename, false);
                    session.Log(Key_FileSite1_Folder_64_85 + "Registration over");
                    if (!CommandExists(Key_FileSite1_SearchFolder_64_85, Cmd_Rename, false))
                        ReplaceCommands(Key_FileSite1_SearchFolder_64_85, Cmd_FileSite, Cmd_Rename, false);
                    session.Log(Key_FileSite1_SearchFolder_64_85 + "Registration over");
                    if (!CommandExists(Key_DeskSite1_SearchFolder_64_85, Cmd_Rename, false))
                        ReplaceCommands(Key_DeskSite1_SearchFolder_64_85, Cmd_Desksite, Cmd_Rename, false);

                    //From here

                    //Search folder new for Desksite
                    if (!CommandExists(Key_Desksite_SearchFolderNew_64_85, Cmd_NewSearchFolder, false))
                        ReplaceCommands(Key_Desksite_SearchFolderNew_64_85, Cmd_Desksite_NewSearchFolder, Cmd_NewSearchFolder, false);
                    if (!CommandExists(Key_Desksite_SearchFolderNew_64_85, Cmd_NewFolder, false))
                        ReplaceCommands(Key_Desksite_SearchFolderNew_64_85, Cmd_Desksite_NewFolder, Cmd_NewFolder, false);

                    //folder new for Desksite
                    if (!CommandExists(Key_Desksite_FolderNew_64_85, Cmd_NewSearchFolder, false))
                        ReplaceCommands(Key_Desksite_FolderNew_64_85, Cmd_Desksite_NewSearchFolder, Cmd_NewSearchFolder, false);
                    if (!CommandExists(Key_Desksite_FolderNew_64_85, Cmd_NewFolder, false))
                        ReplaceCommands(Key_Desksite_FolderNew_64_85, Cmd_Desksite_NewFolder, Cmd_NewFolder, false);

                    //Workspace new for Desksite
                    if (!CommandExists(Key_Desksite_WorkspaceNew_64_85, Cmd_NewSearchFolder, false))
                        ReplaceCommands(Key_Desksite_WorkspaceNew_64_85, Cmd_Desksite_NewSearchFolder, Cmd_NewSearchFolder, false);
                    if (!CommandExists(Key_Desksite_WorkspaceNew_64_85, Cmd_NewFolder, false))
                        ReplaceCommands(Key_Desksite_WorkspaceNew_64_85, Cmd_Desksite_NewFolder, Cmd_NewFolder, false);
                    if (!CommandExists(Key_Desksite_WorkspaceNew_64_85, Cmd_NewTab, false))
                        ReplaceCommands(Key_Desksite_WorkspaceNew_64_85, Cmd_Desksite_NewTab, Cmd_NewTab, false);

                    //Search folder new for Filesite
                    if (!CommandExists(Key_FileSite1_SearchFolderNew_64_85, Cmd_NewSearchFolder, false))
                        ReplaceCommands(Key_FileSite1_SearchFolderNew_64_85, Cmd_FileSite_NewSearchFolder, Cmd_NewSearchFolder, false);
                    if (!CommandExists(Key_FileSite1_SearchFolderNew_64_85, Cmd_NewFolder, false))
                        ReplaceCommands(Key_FileSite1_SearchFolderNew_64_85, Cmd_FileSite_NewFolder, Cmd_NewFolder, false);

                    //folder new for Filesite
                    if (!CommandExists(Key_FileSite1_FolderNew_64_85, Cmd_NewSearchFolder, false))
                        ReplaceCommands(Key_FileSite1_FolderNew_64_85, Cmd_FileSite_NewSearchFolder, Cmd_NewSearchFolder, false);
                    if (!CommandExists(Key_FileSite1_FolderNew_64_85, Cmd_NewFolder, false))
                        ReplaceCommands(Key_FileSite1_FolderNew_64_85, Cmd_FileSite_NewFolder, Cmd_NewFolder, false);

                    //Tab new for Filesite
                    if (!CommandExists(Key_FileSite1_TabNew_64_85, Cmd_NewSearchFolder, false))
                        ReplaceCommands(Key_FileSite1_TabNew_64_85, Cmd_FileSite_NewSearchFolder, Cmd_NewSearchFolder, false);
                    if (!CommandExists(Key_FileSite1_TabNew_64_85, Cmd_NewFolder, false))
                        ReplaceCommands(Key_FileSite1_TabNew_64_85, Cmd_FileSite_NewFolder, Cmd_NewFolder, false);

                    //Workspace new for Filesite
                    if (!CommandExists(Key_FileSite1_WorkspaceNew_64_85, Cmd_NewSearchFolder, false))
                        ReplaceCommands(Key_FileSite1_WorkspaceNew_64_85, Cmd_FileSite_NewSearchFolder, Cmd_NewSearchFolder, false);
                    if (!CommandExists(Key_FileSite1_WorkspaceNew_64_85, Cmd_NewFolder, false))
                        ReplaceCommands(Key_FileSite1_WorkspaceNew_64_85, Cmd_FileSite_NewFolder, Cmd_NewFolder, false);
                    if (!CommandExists(Key_FileSite1_WorkspaceNew_64_85, Cmd_NewTab, false))
                        ReplaceCommands(Key_FileSite1_WorkspaceNew_64_85, Cmd_FileSite_NewTab, Cmd_NewTab, false);

                    //iManext1
                    //Search folder new for imanext1
                    if (!CommandExists(Key_iManExt1_SearchFolderNew_64_85, Cmd_NewSearchFolder, false))
                        ReplaceCommands(Key_iManExt1_SearchFolderNew_64_85, Cmd_Desksite_NewSearchFolder, Cmd_NewSearchFolder, false);
                    if (!CommandExists(Key_iManExt1_SearchFolderNew_64_85, Cmd_NewFolder, false))
                        ReplaceCommands(Key_iManExt1_SearchFolderNew_64_85, Cmd_Desksite_NewFolder, Cmd_NewFolder, false);

                    //folder new for imanext1
                    if (!CommandExists(Key_iManExt1_FolderNew_64_85, Cmd_NewSearchFolder, false))
                        ReplaceCommands(Key_iManExt1_FolderNew_64_85, Cmd_Desksite_NewSearchFolder, Cmd_NewSearchFolder, false);
                    if (!CommandExists(Key_iManExt1_FolderNew_64_85, Cmd_NewFolder, false))
                        ReplaceCommands(Key_iManExt1_FolderNew_64_85, Cmd_Desksite_NewFolder, Cmd_NewFolder, false);

                    //Workspace new for imanext1
                    if (!CommandExists(Key_iManExt1_WorkspaceNew_64_85, Cmd_NewSearchFolder, false))
                        ReplaceCommands(Key_iManExt1_WorkspaceNew_64_85, Cmd_Desksite_NewSearchFolder, Cmd_NewSearchFolder, false);
                    if (!CommandExists(Key_iManExt1_WorkspaceNew_64_85, Cmd_NewFolder, false))
                        ReplaceCommands(Key_iManExt1_WorkspaceNew_64_85, Cmd_Desksite_NewFolder, Cmd_NewFolder, false);
                    if (!CommandExists(Key_iManExt1_WorkspaceNew_64_85, Cmd_NewTab, false))
                        ReplaceCommands(Key_iManExt1_WorkspaceNew_64_85, Cmd_Desksite_NewTab, Cmd_NewTab, false);

                    //imanext2
                    //Search folder new for imanext2
                    if (!CommandExists(Key_iManExt2_SearchFolderNew_64_85, Cmd_NewSearchFolder, false))
                        ReplaceCommands(Key_iManExt2_SearchFolderNew_64_85, Cmd_Desksite_NewSearchFolder, Cmd_NewSearchFolder, false);
                    if (!CommandExists(Key_iManExt2_SearchFolderNew_64_85, Cmd_NewFolder, false))
                        ReplaceCommands(Key_iManExt2_SearchFolderNew_64_85, Cmd_Desksite_NewFolder, Cmd_NewFolder, false);

                    //folder new for imanext2
                    if (!CommandExists(Key_iManExt2_FolderNew_64_85, Cmd_NewSearchFolder, false))
                        ReplaceCommands(Key_iManExt2_FolderNew_64_85, Cmd_Desksite_NewSearchFolder, Cmd_NewSearchFolder, false);
                    if (!CommandExists(Key_iManExt2_FolderNew_64_85, Cmd_NewFolder, false))
                        ReplaceCommands(Key_iManExt2_FolderNew_64_85, Cmd_Desksite_NewFolder, Cmd_NewFolder, false);

                    //Workspace new for imanext2
                    if (!CommandExists(Key_iManExt2_WorkSpaceNew_64_85, Cmd_NewSearchFolder, false))
                        ReplaceCommands(Key_iManExt2_WorkSpaceNew_64_85, Cmd_Desksite_NewSearchFolder, Cmd_NewSearchFolder, false);
                    if (!CommandExists(Key_iManExt2_WorkSpaceNew_64_85, Cmd_NewFolder, false))
                        ReplaceCommands(Key_iManExt2_WorkSpaceNew_64_85, Cmd_Desksite_NewFolder, Cmd_NewFolder, false);
                    if (!CommandExists(Key_iManExt2_WorkSpaceNew_64_85, Cmd_NewTab, false))
                        ReplaceCommands(Key_iManExt2_WorkSpaceNew_64_85, Cmd_Desksite_NewTab, Cmd_NewTab, false);

                    //imanext3
                    //Search folder new for imanext3
                    if (!CommandExists(Key_iManExt3_SearchFolderNew_64_85, Cmd_NewSearchFolder, false))
                        ReplaceCommands(Key_iManExt3_SearchFolderNew_64_85, Cmd_iIntegrationDlg_NewSearchFolder, Cmd_NewSearchFolder, false);
                    if (!CommandExists(Key_iManExt3_SearchFolderNew_64_85, Cmd_NewFolder, false))
                        ReplaceCommands(Key_iManExt3_SearchFolderNew_64_85, Cmd_iIntegrationDlg_NewFolder, Cmd_NewFolder, false);

                    //folder new for imanext3
                    if (!CommandExists(Key_iManExt3_FolderNew_64_85, Cmd_NewSearchFolder, false))
                        ReplaceCommands(Key_iManExt3_FolderNew_64_85, Cmd_iIntegrationDlg_NewSearchFolder, Cmd_NewSearchFolder, false);
                    if (!CommandExists(Key_iManExt3_FolderNew_64_85, Cmd_NewFolder, false))
                        ReplaceCommands(Key_iManExt3_FolderNew_64_85, Cmd_iIntegrationDlg_NewFolder, Cmd_NewFolder, false);

                    //Workspace new for imanext3
                    if (!CommandExists(Key_iManExt3_WorkspaceNew_64_85, Cmd_NewSearchFolder, false))
                        ReplaceCommands(Key_iManExt3_WorkspaceNew_64_85, Cmd_iIntegrationDlg_NewSearchFolder, Cmd_NewSearchFolder, false);
                    if (!CommandExists(Key_iManExt3_WorkspaceNew_64_85, Cmd_NewFolder, false))
                        ReplaceCommands(Key_iManExt3_WorkspaceNew_64_85, Cmd_iIntegrationDlg_NewFolder, Cmd_NewFolder, false);
                    if (!CommandExists(Key_iManExt3_WorkspaceNew_64_85, Cmd_NewTab, false))
                        ReplaceCommands(Key_iManExt3_WorkspaceNew_64_85, Cmd_iIntegrationDlg_NewTab, Cmd_NewTab, false);

                    session.Log("85 64 over");

                }


                else if (WSVer_OSBit == "90 32")
                {


                    //---------------------
                    //--FOR 32-bit MACHINES  Version 9.0
                    //---------------------



                    if (!CommandExists(Key_DeskSite1_Tab_32_90, Cmd_OptionalFolder, true))
                        ReplaceCommands(Key_DeskSite1_Tab_32_90, Cmd_Native1, Cmd_OptionalFolder, true);

                    session.Log(Key_DeskSite1_Tab_32_90 + "Registration over");


                    if (!CommandExists(Key_FileSite1_Tab_32_90, Cmd_OptionalFolder, true))
                        ReplaceCommands(Key_FileSite1_Tab_32_90, Cmd_Native2, Cmd_OptionalFolder, true);
                    session.Log(Key_FileSite1_Tab_32_90 + "Registration over");





                    if (!CommandExists(Key_FileSite4_32_90, Cmd_OptionalFolder, true))
                        ReplaceCommands(Key_FileSite4_32_90, Cmd_Native2, Cmd_OptionalFolder, true);
                    session.Log(Key_FileSite4_32_90 + "Registration over");

                    if (!CommandExists(Key_FileSite5_32_90, Cmd_OptionalFolder, true))
                        ReplaceCommands(Key_FileSite5_32_90, Cmd_Native2, Cmd_OptionalFolder, true);

                    session.Log(Key_FileSite5_32_90 + "Registration over");
                    if (!CommandExists(Key_iManExt1_32_90, Cmd_OptionalFolder, true))
                        ReplaceCommands(Key_iManExt1_32_90, Cmd_Native2, Cmd_OptionalFolder, true);

                    session.Log(Key_iManExt1_32_90 + "Registration over");
                    if (!CommandExists(Key_iManExt2_32_90, Cmd_OptionalFolder, true))
                        ReplaceCommands(Key_iManExt2_32_90, Cmd_Native2, Cmd_OptionalFolder, true);
                    session.Log(Key_iManExt2_32_90 + "Registration over");
                    //Added
                    if (!CommandExists(Key_FileSite1_Folder_32_90, Cmd_OptionalFolder, true))
                        ReplaceCommands(Key_FileSite1_Folder_32_90, Cmd_Native2, Cmd_OptionalFolder, true);
                    session.Log(Key_FileSite1_Folder_32_90 + "Registration over");
                    if (!CommandExists(Key_FileSite1_SearchFolder_32_90, Cmd_OptionalFolder, true))
                        ReplaceCommands(Key_FileSite1_SearchFolder_32_90, Cmd_Native2, Cmd_OptionalFolder, true);
                    session.Log(Key_FileSite1_SearchFolder_32_90 + "Registration over");
                    if (!CommandExists(Key_iManExt2_SearchFolder_32_90, Cmd_OptionalFolder, true))
                        ReplaceCommands(Key_iManExt2_SearchFolder_32_90, Cmd_Native2, Cmd_OptionalFolder, true);
                    session.Log(Key_iManExt2_SearchFolder_32_90 + "Registration over");
                    if (!CommandExists(Key_iManExt1_SearchFolder_32_90, Cmd_OptionalFolder, true))
                        ReplaceCommands(Key_iManExt1_SearchFolder_32_90, Cmd_Native2, Cmd_OptionalFolder, true);
                    session.Log(Key_iManExt1_SearchFolder_32_90 + "Registration over");
                    if (!CommandExists(Key_iManExt3_32_90, Cmd_OptionalFolder, true))
                        ReplaceCommands(Key_iManExt3_32_90, Cmd_Native2, Cmd_OptionalFolder, true);
                    session.Log(Key_iManExt3_32_90 + "Registration over");
                    if (!CommandExists(Key_iManExt3_SearchFolder_32_90, Cmd_OptionalFolder, true))
                        ReplaceCommands(Key_iManExt3_SearchFolder_32_90, Cmd_Native2, Cmd_OptionalFolder, true);
                    session.Log(Key_iManExt3_SearchFolder_32_90 + "Registration over");
                    if (!CommandExists(Key_DeskSite1_SearchFolder_32_90, Cmd_OptionalFolder, true))
                        ReplaceCommands(Key_DeskSite1_SearchFolder_32_90, Cmd_Native1, Cmd_OptionalFolder, true);
                    session.Log(Key_DeskSite1_SearchFolder_32_90 + "Registration over");
                    //Rename
                    if (!CommandExists(Key_DeskSite1_Tab_32_90, Cmd_Rename, true))
                        ReplaceCommands(Key_DeskSite1_Tab_32_90, Cmd_Desksite, Cmd_Rename, true);
                    session.Log(Key_DeskSite1_Tab_32_90 + "Registration over");



                    if (!CommandExists(Key_FileSite1_Tab_32_90, Cmd_Rename, true))
                        ReplaceCommands(Key_FileSite1_Tab_32_90, Cmd_FileSite, Cmd_Rename, true);
                    session.Log(Key_FileSite1_Tab_32_90 + "Registration over");



                    if (!CommandExists(Key_FileSite1_Folder_32_90, Cmd_Rename, true))
                        ReplaceCommands(Key_FileSite1_Folder_32_90, Cmd_FileSite, Cmd_Rename, true);
                    session.Log(Key_FileSite1_Folder_32_90 + "Registration over");
                    if (!CommandExists(Key_FileSite1_SearchFolder_32_90, Cmd_Rename, true))
                        ReplaceCommands(Key_FileSite1_SearchFolder_32_90, Cmd_FileSite, Cmd_Rename, true);
                    session.Log(Key_FileSite1_SearchFolder_32_90 + "Registration over");
                    if (!CommandExists(Key_DeskSite1_SearchFolder_32_90, Cmd_Rename, true))
                        ReplaceCommands(Key_DeskSite1_SearchFolder_32_90, Cmd_Desksite, Cmd_Rename, true);


                    //From here

                    //Search folder new for Desksite
                    if (!CommandExists(Key_Desksite_SearchFolderNew_32_90, Cmd_NewSearchFolder, true))
                        ReplaceCommands(Key_Desksite_SearchFolderNew_32_90, Cmd_Desksite_NewSearchFolder, Cmd_NewSearchFolder, true);
                    if (!CommandExists(Key_Desksite_SearchFolderNew_32_90, Cmd_NewFolder, true))
                        ReplaceCommands(Key_Desksite_SearchFolderNew_32_90, Cmd_Desksite_NewFolder, Cmd_NewFolder, true);

                    //folder new for Desksite
                    if (!CommandExists(Key_Desksite_FolderNew_32_90, Cmd_NewSearchFolder, true))
                        ReplaceCommands(Key_Desksite_FolderNew_32_90, Cmd_Desksite_NewSearchFolder, Cmd_NewSearchFolder, true);
                    if (!CommandExists(Key_Desksite_FolderNew_32_90, Cmd_NewFolder, true))
                        ReplaceCommands(Key_Desksite_FolderNew_32_90, Cmd_Desksite_NewFolder, Cmd_NewFolder, true);

                    //Workspace new for Desksite
                    if (!CommandExists(Key_Desksite_WorkspaceNew_32_90, Cmd_NewSearchFolder, true))
                        ReplaceCommands(Key_Desksite_WorkspaceNew_32_90, Cmd_Desksite_NewSearchFolder, Cmd_NewSearchFolder, true);
                    if (!CommandExists(Key_Desksite_WorkspaceNew_32_90, Cmd_NewFolder, true))
                        ReplaceCommands(Key_Desksite_WorkspaceNew_32_90, Cmd_Desksite_NewFolder, Cmd_NewFolder, true);
                    if (!CommandExists(Key_Desksite_WorkspaceNew_32_90, Cmd_NewTab, true))
                        ReplaceCommands(Key_Desksite_WorkspaceNew_32_90, Cmd_Desksite_NewTab, Cmd_NewTab, true);

                    //Search folder new for Filesite
                    if (!CommandExists(Key_FileSite1_SearchFolderNew_32_90, Cmd_NewSearchFolder, true))
                        ReplaceCommands(Key_FileSite1_SearchFolderNew_32_90, Cmd_FileSite_NewSearchFolder, Cmd_NewSearchFolder, true);
                    if (!CommandExists(Key_FileSite1_SearchFolderNew_32_90, Cmd_NewFolder, true))
                        ReplaceCommands(Key_FileSite1_SearchFolderNew_32_90, Cmd_FileSite_NewFolder, Cmd_NewFolder, true);

                    //folder new for Filesite
                    if (!CommandExists(Key_FileSite1_FolderNew_32_90, Cmd_NewSearchFolder, true))
                        ReplaceCommands(Key_FileSite1_FolderNew_32_90, Cmd_FileSite_NewSearchFolder, Cmd_NewSearchFolder, true);
                    if (!CommandExists(Key_FileSite1_FolderNew_32_90, Cmd_NewFolder, true))
                        ReplaceCommands(Key_FileSite1_FolderNew_32_90, Cmd_FileSite_NewFolder, Cmd_NewFolder, true);

                    //Tab new for Filesite
                    if (!CommandExists(Key_FileSite1_TabNew_32_90, Cmd_NewSearchFolder, true))
                        ReplaceCommands(Key_FileSite1_TabNew_32_90, Cmd_FileSite_NewSearchFolder, Cmd_NewSearchFolder, true);
                    if (!CommandExists(Key_FileSite1_TabNew_32_90, Cmd_NewFolder, true))
                        ReplaceCommands(Key_FileSite1_TabNew_32_90, Cmd_FileSite_NewFolder, Cmd_NewFolder, true);

                    //Workspace new for Filesite
                    if (!CommandExists(Key_FileSite1_WorkspaceNew_32_90, Cmd_NewSearchFolder, true))
                        ReplaceCommands(Key_FileSite1_WorkspaceNew_32_90, Cmd_FileSite_NewSearchFolder, Cmd_NewSearchFolder, true);
                    if (!CommandExists(Key_FileSite1_WorkspaceNew_32_90, Cmd_NewFolder, true))
                        ReplaceCommands(Key_FileSite1_WorkspaceNew_32_90, Cmd_FileSite_NewFolder, Cmd_NewFolder, true);
                    if (!CommandExists(Key_FileSite1_WorkspaceNew_32_90, Cmd_NewTab, true))
                        ReplaceCommands(Key_FileSite1_WorkspaceNew_32_90, Cmd_FileSite_NewTab, Cmd_NewTab, true);

                    //iManext1
                    //Search folder new for imanext1
                    if (!CommandExists(Key_iManExt1_SearchFolderNew_32_90, Cmd_NewSearchFolder, true))
                        ReplaceCommands(Key_iManExt1_SearchFolderNew_32_90, Cmd_Desksite_NewSearchFolder, Cmd_NewSearchFolder, true);
                    if (!CommandExists(Key_iManExt1_SearchFolderNew_32_90, Cmd_NewFolder, true))
                        ReplaceCommands(Key_iManExt1_SearchFolderNew_32_90, Cmd_Desksite_NewFolder, Cmd_NewFolder, true);

                    //folder new for imanext1
                    if (!CommandExists(Key_iManExt1_FolderNew_32_90, Cmd_NewSearchFolder, true))
                        ReplaceCommands(Key_iManExt1_FolderNew_32_90, Cmd_Desksite_NewSearchFolder, Cmd_NewSearchFolder, true);
                    if (!CommandExists(Key_iManExt1_FolderNew_32_90, Cmd_NewFolder, true))
                        ReplaceCommands(Key_iManExt1_FolderNew_32_90, Cmd_Desksite_NewFolder, Cmd_NewFolder, true);

                    //Workspace new for imanext1
                    if (!CommandExists(Key_iManExt1_WorkspaceNew_32_90, Cmd_NewSearchFolder, true))
                        ReplaceCommands(Key_iManExt1_WorkspaceNew_32_90, Cmd_Desksite_NewSearchFolder, Cmd_NewSearchFolder, true);
                    if (!CommandExists(Key_iManExt1_WorkspaceNew_32_90, Cmd_NewFolder, true))
                        ReplaceCommands(Key_iManExt1_WorkspaceNew_32_90, Cmd_Desksite_NewFolder, Cmd_NewFolder, true);
                    if (!CommandExists(Key_iManExt1_WorkspaceNew_32_90, Cmd_NewTab, true))
                        ReplaceCommands(Key_iManExt1_WorkspaceNew_32_90, Cmd_Desksite_NewTab, Cmd_NewTab, true);

                    //imanext2
                    //Search folder new for imanext2
                    if (!CommandExists(Key_iManExt2_SearchFolderNew_32_90, Cmd_NewSearchFolder, true))
                        ReplaceCommands(Key_iManExt2_SearchFolderNew_32_90, Cmd_Desksite_NewSearchFolder, Cmd_NewSearchFolder, true);
                    if (!CommandExists(Key_iManExt2_SearchFolderNew_32_90, Cmd_NewFolder, true))
                        ReplaceCommands(Key_iManExt2_SearchFolderNew_32_90, Cmd_Desksite_NewFolder, Cmd_NewFolder, true);

                    //folder new for imanext2
                    if (!CommandExists(Key_iManExt2_FolderNew_32_90, Cmd_NewSearchFolder, true))
                        ReplaceCommands(Key_iManExt2_FolderNew_32_90, Cmd_Desksite_NewSearchFolder, Cmd_NewSearchFolder, true);
                    if (!CommandExists(Key_iManExt2_FolderNew_32_90, Cmd_NewFolder, true))
                        ReplaceCommands(Key_iManExt2_FolderNew_32_90, Cmd_Desksite_NewFolder, Cmd_NewFolder, true);

                    //Workspace new for imanext2
                    if (!CommandExists(Key_iManExt2_WorkSpaceNew_32_90, Cmd_NewSearchFolder, true))
                        ReplaceCommands(Key_iManExt2_WorkSpaceNew_32_90, Cmd_Desksite_NewSearchFolder, Cmd_NewSearchFolder, true);
                    if (!CommandExists(Key_iManExt2_WorkSpaceNew_32_90, Cmd_NewFolder, true))
                        ReplaceCommands(Key_iManExt2_WorkSpaceNew_32_90, Cmd_Desksite_NewFolder, Cmd_NewFolder, true);
                    if (!CommandExists(Key_iManExt2_WorkSpaceNew_32_90, Cmd_NewTab, true))
                        ReplaceCommands(Key_iManExt2_WorkSpaceNew_32_90, Cmd_Desksite_NewTab, Cmd_NewTab, true);

                    //imanext3
                    //Search folder new for imanext3
                    if (!CommandExists(Key_iManExt3_SearchFolderNew_32_90, Cmd_NewSearchFolder, true))
                        ReplaceCommands(Key_iManExt3_SearchFolderNew_32_90, Cmd_iIntegrationDlg_NewSearchFolder, Cmd_NewSearchFolder, true);
                    if (!CommandExists(Key_iManExt3_SearchFolderNew_32_90, Cmd_NewFolder, true))
                        ReplaceCommands(Key_iManExt3_SearchFolderNew_32_90, Cmd_iIntegrationDlg_NewFolder, Cmd_NewFolder, true);

                    //folder new for imanext3
                    if (!CommandExists(Key_iManExt3_FolderNew_32_90, Cmd_NewSearchFolder, true))
                        ReplaceCommands(Key_iManExt3_FolderNew_32_90, Cmd_iIntegrationDlg_NewSearchFolder, Cmd_NewSearchFolder, true);
                    if (!CommandExists(Key_iManExt3_FolderNew_32_90, Cmd_NewFolder, true))
                        ReplaceCommands(Key_iManExt3_FolderNew_32_90, Cmd_iIntegrationDlg_NewFolder, Cmd_NewFolder, true);

                    //Workspace new for imanext3
                    if (!CommandExists(Key_iManExt3_WorkspaceNew_32_90, Cmd_NewSearchFolder, true))
                        ReplaceCommands(Key_iManExt3_WorkspaceNew_32_90, Cmd_iIntegrationDlg_NewSearchFolder, Cmd_NewSearchFolder, true);
                    if (!CommandExists(Key_iManExt3_WorkspaceNew_32_90, Cmd_NewFolder, true))
                        ReplaceCommands(Key_iManExt3_WorkspaceNew_32_90, Cmd_iIntegrationDlg_NewFolder, Cmd_NewFolder, true);
                    if (!CommandExists(Key_iManExt3_WorkspaceNew_32_90, Cmd_NewTab, true))
                        ReplaceCommands(Key_iManExt3_WorkspaceNew_32_90, Cmd_iIntegrationDlg_NewTab, Cmd_NewTab, true);
                    session.Log("32 90 over");

                }


                else if (WSVer_OSBit == "90 64")
                {


                    //---------------------
                    //--FOR 64-bit MACHINES
                    //---------------------


                    if (!CommandExists(Key_DeskSite1_Tab_64_90, Cmd_OptionalFolder, false))
                        ReplaceCommands(Key_DeskSite1_Tab_64_90, Cmd_Native1, Cmd_OptionalFolder, false);

                    session.Log(Key_DeskSite1_Tab_64_90 + "Registration over");


                    if (!CommandExists(Key_FileSite1_Tab_64_90, Cmd_OptionalFolder, false))
                        ReplaceCommands(Key_FileSite1_Tab_64_90, Cmd_Native2, Cmd_OptionalFolder, false);
                    session.Log(Key_FileSite1_Tab_64_90 + "Registration over");





                    if (!CommandExists(Key_FileSite4_64_90, Cmd_OptionalFolder, false))
                        ReplaceCommands(Key_FileSite4_64_90, Cmd_Native2, Cmd_OptionalFolder, false);
                    session.Log(Key_FileSite4_64_90 + "Registration over");

                    if (!CommandExists(Key_FileSite5_64_90, Cmd_OptionalFolder, false))
                        ReplaceCommands(Key_FileSite5_64_90, Cmd_Native2, Cmd_OptionalFolder, false);

                    session.Log(Key_FileSite5_64_90 + "Registration over");
                    if (!CommandExists(Key_iManExt1_64_90, Cmd_OptionalFolder, false))
                        ReplaceCommands(Key_iManExt1_64_90, Cmd_Native2, Cmd_OptionalFolder, false);

                    session.Log(Key_iManExt1_64_90 + "Registration over");
                    if (!CommandExists(Key_iManExt2_64_90, Cmd_OptionalFolder, false))
                        ReplaceCommands(Key_iManExt2_64_90, Cmd_Native2, Cmd_OptionalFolder, false);
                    session.Log(Key_iManExt2_64_90 + "Registration over");
                    //Added
                    if (!CommandExists(Key_FileSite1_Folder_64_90, Cmd_OptionalFolder, false))
                        ReplaceCommands(Key_FileSite1_Folder_64_90, Cmd_Native2, Cmd_OptionalFolder, false);
                    session.Log(Key_FileSite1_Folder_64_90 + "Registration over");
                    if (!CommandExists(Key_FileSite1_SearchFolder_64_90, Cmd_OptionalFolder, false))
                        ReplaceCommands(Key_FileSite1_SearchFolder_64_90, Cmd_Native2, Cmd_OptionalFolder, false);
                    session.Log(Key_FileSite1_SearchFolder_64_90 + "Registration over");
                    if (!CommandExists(Key_iManExt2_SearchFolder_64_90, Cmd_OptionalFolder, false))
                        ReplaceCommands(Key_iManExt2_SearchFolder_64_90, Cmd_Native2, Cmd_OptionalFolder, false);
                    session.Log(Key_iManExt2_SearchFolder_64_90 + "Registration over");
                    if (!CommandExists(Key_iManExt1_SearchFolder_64_90, Cmd_OptionalFolder, false))
                        ReplaceCommands(Key_iManExt1_SearchFolder_64_90, Cmd_Native2, Cmd_OptionalFolder, false);
                    session.Log(Key_iManExt1_SearchFolder_64_90 + "Registration over");
                    if (!CommandExists(Key_iManExt3_64_90, Cmd_OptionalFolder, false))
                        ReplaceCommands(Key_iManExt3_64_90, Cmd_Native2, Cmd_OptionalFolder, false);
                    session.Log(Key_iManExt3_64_90 + "Registration over");
                    if (!CommandExists(Key_iManExt3_SearchFolder_64_90, Cmd_OptionalFolder, false))
                        ReplaceCommands(Key_iManExt3_SearchFolder_64_90, Cmd_Native2, Cmd_OptionalFolder, false);
                    session.Log(Key_iManExt3_SearchFolder_64_90 + "Registration over");
                    if (!CommandExists(Key_DeskSite1_SearchFolder_64_90, Cmd_OptionalFolder, false))
                        ReplaceCommands(Key_DeskSite1_SearchFolder_64_90, Cmd_Native1, Cmd_OptionalFolder, false);
                    session.Log(Key_DeskSite1_SearchFolder_64_90 + "Registration over");
                    //Rename
                    if (!CommandExists(Key_DeskSite1_Tab_64_90, Cmd_Rename, false))
                        ReplaceCommands(Key_DeskSite1_Tab_64_90, Cmd_Desksite, Cmd_Rename, false);
                    session.Log(Key_DeskSite1_Tab_64_90 + "Registration over");



                    if (!CommandExists(Key_FileSite1_Tab_64_90, Cmd_Rename, false))
                        ReplaceCommands(Key_FileSite1_Tab_64_90, Cmd_FileSite, Cmd_Rename, false);
                    session.Log(Key_FileSite1_Tab_64_90 + "Registration over");
                    if (!CommandExists(Key_FileSite1_Folder_64_90, Cmd_Rename, false))
                        ReplaceCommands(Key_FileSite1_Folder_64_90, Cmd_FileSite, Cmd_Rename, false);
                    session.Log(Key_FileSite1_Folder_64_90 + "Registration over");
                    if (!CommandExists(Key_FileSite1_SearchFolder_64_90, Cmd_Rename, false))
                        ReplaceCommands(Key_FileSite1_SearchFolder_64_90, Cmd_FileSite, Cmd_Rename, false);
                    session.Log(Key_FileSite1_SearchFolder_64_90 + "Registration over");
                    if (!CommandExists(Key_DeskSite1_SearchFolder_64_90, Cmd_Rename, false))
                        ReplaceCommands(Key_DeskSite1_SearchFolder_64_90, Cmd_Desksite, Cmd_Rename, false);

                    //From here

                    //Search folder new for Desksite
                    if (!CommandExists(Key_Desksite_SearchFolderNew_64_90, Cmd_NewSearchFolder, false))
                        ReplaceCommands(Key_Desksite_SearchFolderNew_64_90, Cmd_Desksite_NewSearchFolder, Cmd_NewSearchFolder, false);
                    if (!CommandExists(Key_Desksite_SearchFolderNew_64_90, Cmd_NewFolder, false))
                        ReplaceCommands(Key_Desksite_SearchFolderNew_64_90, Cmd_Desksite_NewFolder, Cmd_NewFolder, false);

                    //folder new for Desksite
                    if (!CommandExists(Key_Desksite_FolderNew_64_90, Cmd_NewSearchFolder, false))
                        ReplaceCommands(Key_Desksite_FolderNew_64_90, Cmd_Desksite_NewSearchFolder, Cmd_NewSearchFolder, false);
                    if (!CommandExists(Key_Desksite_FolderNew_64_90, Cmd_NewFolder, false))
                        ReplaceCommands(Key_Desksite_FolderNew_64_90, Cmd_Desksite_NewFolder, Cmd_NewFolder, false);

                    //Workspace new for Desksite
                    if (!CommandExists(Key_Desksite_WorkspaceNew_64_90, Cmd_NewSearchFolder, false))
                        ReplaceCommands(Key_Desksite_WorkspaceNew_64_90, Cmd_Desksite_NewSearchFolder, Cmd_NewSearchFolder, false);
                    if (!CommandExists(Key_Desksite_WorkspaceNew_64_90, Cmd_NewFolder, false))
                        ReplaceCommands(Key_Desksite_WorkspaceNew_64_90, Cmd_Desksite_NewFolder, Cmd_NewFolder, false);
                    if (!CommandExists(Key_Desksite_WorkspaceNew_64_90, Cmd_NewTab, false))
                        ReplaceCommands(Key_Desksite_WorkspaceNew_64_90, Cmd_Desksite_NewTab, Cmd_NewTab, false);

                    //Search folder new for Filesite
                    if (!CommandExists(Key_FileSite1_SearchFolderNew_64_90, Cmd_NewSearchFolder, false))
                        ReplaceCommands(Key_FileSite1_SearchFolderNew_64_90, Cmd_FileSite_NewSearchFolder, Cmd_NewSearchFolder, false);
                    if (!CommandExists(Key_FileSite1_SearchFolderNew_64_90, Cmd_NewFolder, false))
                        ReplaceCommands(Key_FileSite1_SearchFolderNew_64_90, Cmd_FileSite_NewFolder, Cmd_NewFolder, false);

                    //folder new for Filesite
                    if (!CommandExists(Key_FileSite1_FolderNew_64_90, Cmd_NewSearchFolder, false))
                        ReplaceCommands(Key_FileSite1_FolderNew_64_90, Cmd_FileSite_NewSearchFolder, Cmd_NewSearchFolder, false);
                    if (!CommandExists(Key_FileSite1_FolderNew_64_90, Cmd_NewFolder, false))
                        ReplaceCommands(Key_FileSite1_FolderNew_64_90, Cmd_FileSite_NewFolder, Cmd_NewFolder, false);

                    //Tab new for Filesite
                    if (!CommandExists(Key_FileSite1_TabNew_64_90, Cmd_NewSearchFolder, false))
                        ReplaceCommands(Key_FileSite1_TabNew_64_90, Cmd_FileSite_NewSearchFolder, Cmd_NewSearchFolder, false);
                    if (!CommandExists(Key_FileSite1_TabNew_64_90, Cmd_NewFolder, false))
                        ReplaceCommands(Key_FileSite1_TabNew_64_90, Cmd_FileSite_NewFolder, Cmd_NewFolder, false);

                    //Workspace new for Filesite
                    if (!CommandExists(Key_FileSite1_WorkspaceNew_64_90, Cmd_NewSearchFolder, false))
                        ReplaceCommands(Key_FileSite1_WorkspaceNew_64_90, Cmd_FileSite_NewSearchFolder, Cmd_NewSearchFolder, false);
                    if (!CommandExists(Key_FileSite1_WorkspaceNew_64_90, Cmd_NewFolder, false))
                        ReplaceCommands(Key_FileSite1_WorkspaceNew_64_90, Cmd_FileSite_NewFolder, Cmd_NewFolder, false);
                    if (!CommandExists(Key_FileSite1_WorkspaceNew_64_90, Cmd_NewTab, false))
                        ReplaceCommands(Key_FileSite1_WorkspaceNew_64_90, Cmd_FileSite_NewTab, Cmd_NewTab, false);


                    //iManext1
                    //Search folder new for imanext1
                    if (!CommandExists(Key_iManExt1_SearchFolderNew_64_90, Cmd_NewSearchFolder, false))
                        ReplaceCommands(Key_iManExt1_SearchFolderNew_64_90, Cmd_Desksite_NewSearchFolder, Cmd_NewSearchFolder, false);
                    if (!CommandExists(Key_iManExt1_SearchFolderNew_64_90, Cmd_NewFolder, false))
                        ReplaceCommands(Key_iManExt1_SearchFolderNew_64_90, Cmd_Desksite_NewFolder, Cmd_NewFolder, false);

                    //folder new for imanext1
                    if (!CommandExists(Key_iManExt1_FolderNew_64_90, Cmd_NewSearchFolder, false))
                        ReplaceCommands(Key_iManExt1_FolderNew_64_90, Cmd_Desksite_NewSearchFolder, Cmd_NewSearchFolder, false);
                    if (!CommandExists(Key_iManExt1_FolderNew_64_90, Cmd_NewFolder, false))
                        ReplaceCommands(Key_iManExt1_FolderNew_64_90, Cmd_Desksite_NewFolder, Cmd_NewFolder, false);

                    //Workspace new for imanext1
                    if (!CommandExists(Key_iManExt1_WorkspaceNew_64_90, Cmd_NewSearchFolder, false))
                        ReplaceCommands(Key_iManExt1_WorkspaceNew_64_90, Cmd_Desksite_NewSearchFolder, Cmd_NewSearchFolder, false);
                    if (!CommandExists(Key_iManExt1_WorkspaceNew_64_90, Cmd_NewFolder, false))
                        ReplaceCommands(Key_iManExt1_WorkspaceNew_64_90, Cmd_Desksite_NewFolder, Cmd_NewFolder, false);
                    if (!CommandExists(Key_iManExt1_WorkspaceNew_64_90, Cmd_NewTab, false))
                        ReplaceCommands(Key_iManExt1_WorkspaceNew_64_90, Cmd_Desksite_NewTab, Cmd_NewTab, false);

                    //imanext2
                    //Search folder new for imanext2
                    if (!CommandExists(Key_iManExt2_SearchFolderNew_64_90, Cmd_NewSearchFolder, false))
                        ReplaceCommands(Key_iManExt2_SearchFolderNew_64_90, Cmd_Desksite_NewSearchFolder, Cmd_NewSearchFolder, false);
                    if (!CommandExists(Key_iManExt2_SearchFolderNew_64_90, Cmd_NewFolder, false))
                        ReplaceCommands(Key_iManExt2_SearchFolderNew_64_90, Cmd_Desksite_NewFolder, Cmd_NewFolder, false);

                    //folder new for imanext2
                    if (!CommandExists(Key_iManExt2_FolderNew_64_90, Cmd_NewSearchFolder, false))
                        ReplaceCommands(Key_iManExt2_FolderNew_64_90, Cmd_Desksite_NewSearchFolder, Cmd_NewSearchFolder, false);
                    if (!CommandExists(Key_iManExt2_FolderNew_64_90, Cmd_NewFolder, false))
                        ReplaceCommands(Key_iManExt2_FolderNew_64_90, Cmd_Desksite_NewFolder, Cmd_NewFolder, false);

                    //Workspace new for imanext2
                    if (!CommandExists(Key_iManExt2_WorkSpaceNew_64_90, Cmd_NewSearchFolder, false))
                        ReplaceCommands(Key_iManExt2_WorkSpaceNew_64_90, Cmd_Desksite_NewSearchFolder, Cmd_NewSearchFolder, false);
                    if (!CommandExists(Key_iManExt2_WorkSpaceNew_64_90, Cmd_NewFolder, false))
                        ReplaceCommands(Key_iManExt2_WorkSpaceNew_64_90, Cmd_Desksite_NewFolder, Cmd_NewFolder, false);
                    if (!CommandExists(Key_iManExt2_WorkSpaceNew_64_90, Cmd_NewTab, false))
                        ReplaceCommands(Key_iManExt2_WorkSpaceNew_64_90, Cmd_Desksite_NewTab, Cmd_NewTab, false);

                    //imanext3
                    //Search folder new for imanext3
                    if (!CommandExists(Key_iManExt3_SearchFolderNew_64_90, Cmd_NewSearchFolder, false))
                        ReplaceCommands(Key_iManExt3_SearchFolderNew_64_90, Cmd_iIntegrationDlg_NewSearchFolder, Cmd_NewSearchFolder, false);
                    if (!CommandExists(Key_iManExt3_SearchFolderNew_64_90, Cmd_NewFolder, false))
                        ReplaceCommands(Key_iManExt3_SearchFolderNew_64_90, Cmd_iIntegrationDlg_NewFolder, Cmd_NewFolder, false);

                    //folder new for imanext3
                    if (!CommandExists(Key_iManExt3_FolderNew_64_90, Cmd_NewSearchFolder, false))
                        ReplaceCommands(Key_iManExt3_FolderNew_64_90, Cmd_iIntegrationDlg_NewSearchFolder, Cmd_NewSearchFolder, false);
                    if (!CommandExists(Key_iManExt3_FolderNew_64_90, Cmd_NewFolder, false))
                        ReplaceCommands(Key_iManExt3_FolderNew_64_90, Cmd_iIntegrationDlg_NewFolder, Cmd_NewFolder, false);

                    //Workspace new for imanext3
                    if (!CommandExists(Key_iManExt3_WorkspaceNew_64_90, Cmd_NewSearchFolder, false))
                        ReplaceCommands(Key_iManExt3_WorkspaceNew_64_90, Cmd_iIntegrationDlg_NewSearchFolder, Cmd_NewSearchFolder, false);
                    if (!CommandExists(Key_iManExt3_WorkspaceNew_64_90, Cmd_NewFolder, false))
                        ReplaceCommands(Key_iManExt3_WorkspaceNew_64_90, Cmd_iIntegrationDlg_NewFolder, Cmd_NewFolder, false);
                    if (!CommandExists(Key_iManExt3_WorkspaceNew_64_90, Cmd_NewTab, false))
                        ReplaceCommands(Key_iManExt3_WorkspaceNew_64_90, Cmd_iIntegrationDlg_NewTab, Cmd_NewTab, false);
                    session.Log("64 90 over");

                }
                session.Log("Registration Completed");

            }
            catch (Exception ex)
            {

            }
            return ActionResult.Success;
        }

        [CustomAction]
        public static ActionResult UnRegisterProperties(Session session)
        {
            string WSVer_OSBit = string.Empty;
            try
            {
                session.Log("UnRegistration started");
                if (KeyExists(WorkSite_85_32, true))
                    WSVer_OSBit = "85 32";
                else if (KeyExists(WorkSite_85_64, false))
                    WSVer_OSBit = "85 64";
                else if (KeyExists(WorkSite_90_32, true))
                    WSVer_OSBit = "90 32";
                else if (KeyExists(WorkSite_90_64, false))
                    WSVer_OSBit = "90 64";
                if (WSVer_OSBit.Trim().Length == 0)
                {
                    session.Log("Desksite/Filesite not found");
                    return ActionResult.NotExecuted;
                }


                if (WSVer_OSBit == "85 32")
                {


                    //---------------------
                    //--FOR 32-bit MACHINES  Version 8.5
                    //---------------------
                    //---------------------


                    if (!CommandExists(Key_DeskSite1_Tab_32_85, Cmd_Native1, true))
                        ReplaceCommands(Key_DeskSite1_Tab_32_85, Cmd_OptionalFolder, Cmd_Native1, true);

                    session.Log(Key_DeskSite1_Tab_32_85 + "UnRegistration over");

                    if (!CommandExists(Key_FileSite1_Tab_32_85, Cmd_Native2, true))
                        ReplaceCommands(Key_FileSite1_Tab_32_85, Cmd_OptionalFolder, Cmd_Native2, true);
                    session.Log(Key_FileSite1_Tab_32_85 + "UnRegistration over");





                    if (!CommandExists(Key_FileSite4_32_85, Cmd_Native2, true))
                        ReplaceCommands(Key_FileSite4_32_85, Cmd_OptionalFolder, Cmd_Native2, true);
                    session.Log(Key_FileSite4_32_85 + "UnRegistration over");

                    if (!CommandExists(Key_FileSite5_32_85, Cmd_Native2, true))
                        ReplaceCommands(Key_FileSite5_32_85, Cmd_OptionalFolder, Cmd_Native2, true);
                    session.Log(Key_FileSite5_32_85 + "UnRegistration over");

                    if (!CommandExists(Key_iManExt1_32_85, Cmd_Native2, true))
                        ReplaceCommands(Key_iManExt1_32_85, Cmd_OptionalFolder, Cmd_Native2, true);

                    session.Log(Key_iManExt1_32_85 + "UnRegistration over");
                    if (!CommandExists(Key_iManExt2_32_85, Cmd_Native2, true))
                        ReplaceCommands(Key_iManExt2_32_85, Cmd_OptionalFolder, Cmd_Native2, true);
                    session.Log(Key_iManExt2_32_85 + "UnRegistration over");
                    //Added
                    if (!CommandExists(Key_FileSite1_Folder_32_85, Cmd_Native2, true))
                        ReplaceCommands(Key_FileSite1_Folder_32_85, Cmd_OptionalFolder, Cmd_Native2, true);
                    session.Log(Key_FileSite1_Folder_32_85 + "UnRegistration over");

                    if (!CommandExists(Key_FileSite1_SearchFolder_32_85, Cmd_Native2, true))
                        ReplaceCommands(Key_FileSite1_SearchFolder_32_85, Cmd_OptionalFolder, Cmd_Native2, true);
                    session.Log(Key_FileSite1_SearchFolder_32_85 + "UnRegistration over");

                    if (!CommandExists(Key_iManExt2_SearchFolder_32_85, Cmd_Native2, true))
                        ReplaceCommands(Key_iManExt2_SearchFolder_32_85, Cmd_OptionalFolder, Cmd_Native2, true);
                    session.Log(Key_iManExt2_SearchFolder_32_85 + "UnRegistration over");
                    if (!CommandExists(Key_iManExt1_SearchFolder_32_85, Cmd_Native2, true))
                        ReplaceCommands(Key_iManExt1_SearchFolder_32_85, Cmd_OptionalFolder, Cmd_Native2, true);
                    session.Log(Key_iManExt1_SearchFolder_32_85 + "UnRegistration over");

                    if (!CommandExists(Key_iManExt3_32_85, Cmd_Native2, true))
                        ReplaceCommands(Key_iManExt3_32_85, Cmd_OptionalFolder, Cmd_Native2, true);
                    session.Log(Key_iManExt3_32_85 + "UnRegistration over");
                    if (!CommandExists(Key_iManExt3_SearchFolder_32_85, Cmd_Native2, true))
                        ReplaceCommands(Key_iManExt3_SearchFolder_32_85, Cmd_OptionalFolder, Cmd_Native2, true);

                    session.Log(Key_iManExt3_SearchFolder_32_85 + "UnRegistration over");
                    if (!CommandExists(Key_DeskSite1_SearchFolder_32_85, Cmd_Native1, true))
                        ReplaceCommands(Key_DeskSite1_SearchFolder_32_85, Cmd_OptionalFolder, Cmd_Native1, true);
                    session.Log(Key_DeskSite1_SearchFolder_32_85 + "UnRegistration over");
                    //Rename

                    if (!CommandExists(Key_DeskSite1_Tab_32_85, Cmd_Desksite, true))
                        ReplaceCommands(Key_DeskSite1_Tab_32_85, Cmd_Rename, Cmd_Desksite, true);

                    session.Log(Key_DeskSite1_Tab_32_85 + "UnRegistration over");

                    if (!CommandExists(Key_FileSite1_Tab_32_85, Cmd_FileSite, true))
                        ReplaceCommands(Key_FileSite1_Tab_32_85, Cmd_Rename, Cmd_FileSite, true);
                    session.Log(Key_FileSite1_Tab_32_85 + "UnRegistration over");



                    if (!CommandExists(Key_FileSite1_Folder_32_85, Cmd_FileSite, true))
                        ReplaceCommands(Key_FileSite1_Folder_32_85, Cmd_Rename, Cmd_FileSite, true);
                    session.Log(Key_FileSite1_Folder_32_85 + "UnRegistration over");

                    if (!CommandExists(Key_FileSite1_SearchFolder_32_85, Cmd_FileSite, true))
                        ReplaceCommands(Key_FileSite1_SearchFolder_32_85, Cmd_Rename, Cmd_FileSite, true);
                    session.Log(Key_FileSite1_SearchFolder_32_85 + "UnRegistration over");

                    if (!CommandExists(Key_DeskSite1_SearchFolder_32_85, Cmd_Desksite, true))
                        ReplaceCommands(Key_DeskSite1_SearchFolder_32_85, Cmd_Rename, Cmd_Desksite, true);


                    //From here

                    //Search folder new for Desksite
                    if (!CommandExists(Key_Desksite_SearchFolderNew_32_85, Cmd_Desksite_NewSearchFolder, true))
                        ReplaceCommands(Key_Desksite_SearchFolderNew_32_85, Cmd_NewSearchFolder,Cmd_Desksite_NewSearchFolder, true);
                    if (!CommandExists(Key_Desksite_SearchFolderNew_32_85, Cmd_Desksite_NewFolder, true))
                        ReplaceCommands(Key_Desksite_SearchFolderNew_32_85, Cmd_NewFolder, Cmd_Desksite_NewFolder,true);

                    //folder new for Desksite
                    if (!CommandExists(Key_Desksite_FolderNew_32_85, Cmd_Desksite_NewSearchFolder, true))
                        ReplaceCommands(Key_Desksite_FolderNew_32_85,  Cmd_NewSearchFolder,Cmd_Desksite_NewSearchFolder, true);
                    if (!CommandExists(Key_Desksite_FolderNew_32_85, Cmd_Desksite_NewFolder, true))
                        ReplaceCommands(Key_Desksite_FolderNew_32_85, Cmd_NewFolder,Cmd_Desksite_NewFolder, true);

                    //Workspace new for Desksite
                    if (!CommandExists(Key_Desksite_WorkspaceNew_32_85, Cmd_Desksite_NewSearchFolder, true))
                        ReplaceCommands(Key_Desksite_WorkspaceNew_32_85, Cmd_NewSearchFolder, Cmd_Desksite_NewSearchFolder,true);
                    if (!CommandExists(Key_Desksite_WorkspaceNew_32_85, Cmd_Desksite_NewFolder, true))
                        ReplaceCommands(Key_Desksite_WorkspaceNew_32_85,  Cmd_NewFolder,Cmd_Desksite_NewFolder, true);
                    if (!CommandExists(Key_Desksite_WorkspaceNew_32_85, Cmd_Desksite_NewTab, true))
                        ReplaceCommands(Key_Desksite_WorkspaceNew_32_85,  Cmd_NewTab,Cmd_Desksite_NewTab, true);


                    //Search folder new for Filesite
                    if (!CommandExists(Key_FileSite1_SearchFolderNew_32_85, Cmd_FileSite_NewSearchFolder, true))
                        ReplaceCommands(Key_FileSite1_SearchFolderNew_32_85, Cmd_NewSearchFolder, Cmd_FileSite_NewSearchFolder, true);
                    if (!CommandExists(Key_FileSite1_SearchFolderNew_32_85, Cmd_FileSite_NewFolder, true))
                        ReplaceCommands(Key_FileSite1_SearchFolderNew_32_85, Cmd_NewFolder, Cmd_FileSite_NewFolder, true);

                    //folder new for Filesite
                    if (!CommandExists(Key_FileSite1_FolderNew_32_85, Cmd_FileSite_NewSearchFolder, true))
                        ReplaceCommands(Key_FileSite1_FolderNew_32_85, Cmd_NewSearchFolder, Cmd_FileSite_NewSearchFolder, true);
                    if (!CommandExists(Key_FileSite1_FolderNew_32_85, Cmd_FileSite_NewFolder, true))
                        ReplaceCommands(Key_FileSite1_FolderNew_32_85, Cmd_NewFolder, Cmd_FileSite_NewFolder, true);
                    //Tab new for Filesite
                    if (!CommandExists(Key_FileSite1_TabNew_32_85, Cmd_FileSite_NewSearchFolder, true))
                        ReplaceCommands(Key_FileSite1_TabNew_32_85, Cmd_NewSearchFolder, Cmd_FileSite_NewSearchFolder, true);
                    if (!CommandExists(Key_FileSite1_TabNew_32_85, Cmd_FileSite_NewFolder, true))
                        ReplaceCommands(Key_FileSite1_TabNew_32_85, Cmd_NewFolder, Cmd_FileSite_NewFolder, true);

                    //Workspace new for Filesite
                    if (!CommandExists(Key_FileSite1_WorkspaceNew_32_85, Cmd_FileSite_NewSearchFolder, true))
                        ReplaceCommands(Key_FileSite1_WorkspaceNew_32_85, Cmd_NewSearchFolder, Cmd_FileSite_NewSearchFolder, true);
                    if (!CommandExists(Key_FileSite1_WorkspaceNew_32_85, Cmd_FileSite_NewFolder, true))
                        ReplaceCommands(Key_FileSite1_WorkspaceNew_32_85, Cmd_NewFolder, Cmd_FileSite_NewFolder, true);
                    if (!CommandExists(Key_FileSite1_WorkspaceNew_32_85, Cmd_FileSite_NewTab, true))
                        ReplaceCommands(Key_FileSite1_WorkspaceNew_32_85, Cmd_NewTab, Cmd_FileSite_NewTab, true);


                    //iManext1
                    //Search folder new for imanext1
                    if (!CommandExists(Key_iManExt1_SearchFolderNew_32_85, Cmd_Desksite_NewSearchFolder, true))
                        ReplaceCommands(Key_iManExt1_SearchFolderNew_32_85, Cmd_NewSearchFolder,Cmd_Desksite_NewSearchFolder, true);
                    if (!CommandExists(Key_iManExt1_SearchFolderNew_32_85, Cmd_Desksite_NewFolder, true))
                        ReplaceCommands(Key_iManExt1_SearchFolderNew_32_85,  Cmd_NewFolder,Cmd_Desksite_NewFolder, true);

                    //folder new for imanext1
                    if (!CommandExists(Key_iManExt1_FolderNew_32_85, Cmd_Desksite_NewSearchFolder, true))
                        ReplaceCommands(Key_iManExt1_FolderNew_32_85, Cmd_NewSearchFolder, Cmd_Desksite_NewSearchFolder,true);
                    if (!CommandExists(Key_iManExt1_FolderNew_32_85, Cmd_Desksite_NewFolder, true))
                        ReplaceCommands(Key_iManExt1_FolderNew_32_85,  Cmd_NewFolder,Cmd_Desksite_NewFolder, true);

                    //Workspace new for imanext1
                    if (!CommandExists(Key_iManExt1_WorkspaceNew_32_85, Cmd_Desksite_NewSearchFolder, true))
                        ReplaceCommands(Key_iManExt1_WorkspaceNew_32_85, Cmd_NewSearchFolder, Cmd_Desksite_NewSearchFolder, true);
                    if (!CommandExists(Key_iManExt1_WorkspaceNew_32_85, Cmd_Desksite_NewFolder, true))
                        ReplaceCommands(Key_iManExt1_WorkspaceNew_32_85, Cmd_NewFolder, Cmd_Desksite_NewFolder, true);
                    if (!CommandExists(Key_iManExt1_WorkspaceNew_32_85, Cmd_Desksite_NewTab, true))
                        ReplaceCommands(Key_iManExt1_WorkspaceNew_32_85, Cmd_NewTab, Cmd_Desksite_NewTab, true);

                    //imanext2
                    //Search folder new for imanext2
                    if (!CommandExists(Key_iManExt2_SearchFolderNew_32_85, Cmd_Desksite_NewSearchFolder, true))
                        ReplaceCommands(Key_iManExt2_SearchFolderNew_32_85,  Cmd_NewSearchFolder,Cmd_Desksite_NewSearchFolder, true);
                    if (!CommandExists(Key_iManExt2_SearchFolderNew_32_85, Cmd_Desksite_NewFolder, true))
                        ReplaceCommands(Key_iManExt2_SearchFolderNew_32_85, Cmd_NewFolder, Cmd_Desksite_NewFolder,true);

                    //folder new for imanext2
                    if (!CommandExists(Key_iManExt2_FolderNew_32_85, Cmd_Desksite_NewSearchFolder, true))
                        ReplaceCommands(Key_iManExt2_FolderNew_32_85,  Cmd_NewSearchFolder,Cmd_Desksite_NewSearchFolder, true);
                    if (!CommandExists(Key_iManExt2_FolderNew_32_85, Cmd_Desksite_NewFolder, true))
                        ReplaceCommands(Key_iManExt2_FolderNew_32_85,  Cmd_NewFolder,Cmd_Desksite_NewFolder, true);

                    //Workspace new for imanext2
                    if (!CommandExists(Key_iManExt2_WorkSpaceNew_32_85, Cmd_Desksite_NewSearchFolder, true))
                        ReplaceCommands(Key_iManExt2_WorkSpaceNew_32_85, Cmd_NewSearchFolder, Cmd_Desksite_NewSearchFolder, true);
                    if (!CommandExists(Key_iManExt2_WorkSpaceNew_32_85, Cmd_Desksite_NewFolder, true))
                        ReplaceCommands(Key_iManExt2_WorkSpaceNew_32_85, Cmd_NewFolder, Cmd_Desksite_NewFolder, true);
                    if (!CommandExists(Key_iManExt2_WorkSpaceNew_32_85, Cmd_Desksite_NewTab, true))
                        ReplaceCommands(Key_iManExt2_WorkSpaceNew_32_85, Cmd_NewTab, Cmd_Desksite_NewTab, true);

                    //imanext3
                    //Search folder new for imanext3
                    if (!CommandExists(Key_iManExt3_SearchFolderNew_32_85, Cmd_iIntegrationDlg_NewSearchFolder, true))
                        ReplaceCommands(Key_iManExt3_SearchFolderNew_32_85,  Cmd_NewSearchFolder,Cmd_iIntegrationDlg_NewSearchFolder, true);
                    if (!CommandExists(Key_iManExt3_SearchFolderNew_32_85, Cmd_iIntegrationDlg_NewFolder, true))
                        ReplaceCommands(Key_iManExt3_SearchFolderNew_32_85,  Cmd_NewFolder,Cmd_iIntegrationDlg_NewFolder, true);

                    //folder new for imanext3
                    if (!CommandExists(Key_iManExt3_FolderNew_32_85, Cmd_iIntegrationDlg_NewSearchFolder, true))
                        ReplaceCommands(Key_iManExt3_FolderNew_32_85, Cmd_NewSearchFolder, Cmd_iIntegrationDlg_NewSearchFolder,true);
                    if (!CommandExists(Key_iManExt3_FolderNew_32_85, Cmd_iIntegrationDlg_NewFolder, true))
                        ReplaceCommands(Key_iManExt3_FolderNew_32_85,  Cmd_NewFolder,Cmd_iIntegrationDlg_NewFolder, true);

                    //Workspace new for imanext3
                    if (!CommandExists(Key_iManExt3_WorkspaceNew_32_85, Cmd_iIntegrationDlg_NewSearchFolder, true))
                        ReplaceCommands(Key_iManExt3_WorkspaceNew_32_85, Cmd_NewSearchFolder, Cmd_iIntegrationDlg_NewSearchFolder, true);
                    if (!CommandExists(Key_iManExt3_WorkspaceNew_32_85, Cmd_iIntegrationDlg_NewFolder, true))
                        ReplaceCommands(Key_iManExt3_WorkspaceNew_32_85, Cmd_NewFolder, Cmd_iIntegrationDlg_NewFolder, true);
                    if (!CommandExists(Key_iManExt3_WorkspaceNew_32_85, Cmd_iIntegrationDlg_NewTab, true))
                        ReplaceCommands(Key_iManExt3_WorkspaceNew_32_85, Cmd_NewTab, Cmd_iIntegrationDlg_NewTab, true);


                    session.Log("85 32 done");
                }


                else if (WSVer_OSBit == "85 64")
                {

                    //---------------------
                    //--FOR 64-bit MACHINES
                    //---------------------


                    if (!CommandExists(Key_DeskSite1_Tab_64_85, Cmd_Native1, false))
                        ReplaceCommands(Key_DeskSite1_Tab_64_85, Cmd_OptionalFolder, Cmd_Native1, false);

                    session.Log(Key_DeskSite1_Tab_64_85 + "UnRegistration over");


                    if (!CommandExists(Key_FileSite1_Tab_64_85, Cmd_Native2, false))
                        ReplaceCommands(Key_FileSite1_Tab_64_85, Cmd_OptionalFolder, Cmd_Native2, false);

                    session.Log(Key_FileSite1_Tab_64_85 + "UnRegistration over");




                    if (!CommandExists(Key_FileSite4_64_85, Cmd_Native2, false))
                        ReplaceCommands(Key_FileSite4_64_85, Cmd_OptionalFolder, Cmd_Native2, false);
                    session.Log(Key_FileSite4_64_85 + "UnRegistration over");

                    if (!CommandExists(Key_FileSite5_64_85, Cmd_Native2, false))
                        ReplaceCommands(Key_FileSite5_64_85, Cmd_OptionalFolder, Cmd_Native2, false);

                    session.Log(Key_FileSite5_64_85 + "UnRegistration over");
                    if (!CommandExists(Key_iManExt1_64_85, Cmd_Native2, false))
                        ReplaceCommands(Key_iManExt1_64_85, Cmd_OptionalFolder, Cmd_Native2, false);

                    session.Log(Key_iManExt1_64_85 + "UnRegistration over");
                    if (!CommandExists(Key_iManExt2_64_85, Cmd_Native2, false))
                        ReplaceCommands(Key_iManExt2_64_85, Cmd_OptionalFolder, Cmd_Native2, false);
                    session.Log(Key_iManExt2_64_85 + "UnRegistration over");
                    //Added
                    if (!CommandExists(Key_FileSite1_Folder_64_85, Cmd_Native2, false))
                        ReplaceCommands(Key_FileSite1_Folder_64_85, Cmd_OptionalFolder, Cmd_Native2, false);
                    session.Log(Key_FileSite1_Folder_64_85 + "UnRegistration over");
                    if (!CommandExists(Key_FileSite1_SearchFolder_64_85, Cmd_Native2, false))
                        ReplaceCommands(Key_FileSite1_SearchFolder_64_85, Cmd_OptionalFolder, Cmd_Native2, false);
                    session.Log(Key_FileSite1_SearchFolder_64_85 + "UnRegistration over");
                    if (!CommandExists(Key_iManExt2_SearchFolder_64_85, Cmd_Native2, false))
                        ReplaceCommands(Key_iManExt2_SearchFolder_64_85, Cmd_OptionalFolder, Cmd_Native2, false);
                    session.Log(Key_iManExt2_SearchFolder_64_85 + "UnRegistration over");
                    if (!CommandExists(Key_iManExt1_SearchFolder_64_85, Cmd_Native2, false))
                        ReplaceCommands(Key_iManExt1_SearchFolder_64_85, Cmd_OptionalFolder, Cmd_Native2, false);
                    session.Log(Key_iManExt1_SearchFolder_64_85 + "UnRegistration over");
                    if (!CommandExists(Key_iManExt3_64_85, Cmd_Native2, false))
                        ReplaceCommands(Key_iManExt3_64_85, Cmd_OptionalFolder, Cmd_Native2, false);
                    session.Log(Key_iManExt3_64_85 + "UnRegistration over");
                    if (!CommandExists(Key_iManExt3_SearchFolder_64_85, Cmd_Native2, false))
                        ReplaceCommands(Key_iManExt3_SearchFolder_64_85, Cmd_OptionalFolder, Cmd_Native2, false);
                    session.Log(Key_iManExt3_SearchFolder_64_85 + "UnRegistration over");
                    if (!CommandExists(Key_DeskSite1_SearchFolder_64_85, Cmd_Native1, false))
                        ReplaceCommands(Key_DeskSite1_SearchFolder_64_85, Cmd_OptionalFolder, Cmd_Native1, false);
                    session.Log(Key_DeskSite1_SearchFolder_64_85 + "UnRegistration over");

                    //Rename

                    if (!CommandExists(Key_DeskSite1_Tab_64_85, Cmd_Desksite, false))
                        ReplaceCommands(Key_DeskSite1_Tab_64_85, Cmd_Rename, Cmd_Desksite, false);
                    session.Log(Key_DeskSite1_Tab_64_85 + "UnRegistration over");



                    if (!CommandExists(Key_FileSite1_Tab_64_85, Cmd_FileSite, false))
                        ReplaceCommands(Key_FileSite1_Tab_64_85, Cmd_Rename, Cmd_FileSite, false);
                    session.Log(Key_FileSite1_Tab_64_85 + "UnRegistration over");
                    if (!CommandExists(Key_FileSite1_Folder_64_85, Cmd_FileSite, false))
                        ReplaceCommands(Key_FileSite1_Folder_64_85, Cmd_Rename, Cmd_FileSite, false);
                    session.Log(Key_FileSite1_Folder_64_85 + "UnRegistration over");
                    if (!CommandExists(Key_FileSite1_SearchFolder_64_85, Cmd_FileSite, false))
                        ReplaceCommands(Key_FileSite1_SearchFolder_64_85, Cmd_Rename, Cmd_FileSite, false);
                    session.Log(Key_FileSite1_SearchFolder_64_85 + "UnRegistration over");
                    if (!CommandExists(Key_DeskSite1_SearchFolder_64_85, Cmd_Desksite, false))
                        ReplaceCommands(Key_DeskSite1_SearchFolder_64_85, Cmd_Rename, Cmd_Desksite, false);

                    //From here

                    //Search folder new for Desksite
                    if (!CommandExists(Key_Desksite_SearchFolderNew_64_85, Cmd_Desksite_NewSearchFolder, false))
                        ReplaceCommands(Key_Desksite_SearchFolderNew_64_85, Cmd_NewSearchFolder, Cmd_Desksite_NewSearchFolder, false);
                    if (!CommandExists(Key_Desksite_SearchFolderNew_64_85, Cmd_Desksite_NewFolder, false))
                        ReplaceCommands(Key_Desksite_SearchFolderNew_64_85, Cmd_NewFolder, Cmd_Desksite_NewFolder, false);

                    //folder new for Desksite
                    if (!CommandExists(Key_Desksite_FolderNew_64_85, Cmd_Desksite_NewSearchFolder, false))
                        ReplaceCommands(Key_Desksite_FolderNew_64_85, Cmd_NewSearchFolder, Cmd_Desksite_NewSearchFolder, false);
                    if (!CommandExists(Key_Desksite_FolderNew_64_85, Cmd_Desksite_NewFolder, false))
                        ReplaceCommands(Key_Desksite_FolderNew_64_85, Cmd_NewFolder, Cmd_Desksite_NewFolder, false);

                    //Workspace new for Desksite
                    if (!CommandExists(Key_Desksite_WorkspaceNew_64_85, Cmd_Desksite_NewSearchFolder, false))
                        ReplaceCommands(Key_Desksite_WorkspaceNew_64_85, Cmd_NewSearchFolder, Cmd_Desksite_NewSearchFolder, false);
                    if (!CommandExists(Key_Desksite_WorkspaceNew_64_85, Cmd_Desksite_NewFolder, false))
                        ReplaceCommands(Key_Desksite_WorkspaceNew_64_85, Cmd_NewFolder, Cmd_Desksite_NewFolder, false);
                    if (!CommandExists(Key_Desksite_WorkspaceNew_64_85, Cmd_Desksite_NewTab, false))
                        ReplaceCommands(Key_Desksite_WorkspaceNew_64_85, Cmd_NewTab, Cmd_Desksite_NewTab, false);

                    //Search folder new for Filesite
                    if (!CommandExists(Key_FileSite1_SearchFolderNew_64_85, Cmd_FileSite_NewSearchFolder, false))
                        ReplaceCommands(Key_FileSite1_SearchFolderNew_64_85, Cmd_NewSearchFolder, Cmd_FileSite_NewSearchFolder, false);
                    if (!CommandExists(Key_FileSite1_SearchFolderNew_64_85, Cmd_FileSite_NewFolder, false))
                        ReplaceCommands(Key_FileSite1_SearchFolderNew_64_85, Cmd_NewFolder, Cmd_FileSite_NewFolder, false);

                    //folder new for Filesite
                    if (!CommandExists(Key_FileSite1_FolderNew_64_85, Cmd_FileSite_NewSearchFolder, false))
                        ReplaceCommands(Key_FileSite1_FolderNew_64_85, Cmd_NewSearchFolder, Cmd_FileSite_NewSearchFolder, false);
                    if (!CommandExists(Key_FileSite1_FolderNew_64_85, Cmd_FileSite_NewFolder, false))
                        ReplaceCommands(Key_FileSite1_FolderNew_64_85, Cmd_NewFolder, Cmd_FileSite_NewFolder, false);
                    //Tab new for Filesite
                    if (!CommandExists(Key_FileSite1_TabNew_64_85, Cmd_FileSite_NewSearchFolder, false))
                        ReplaceCommands(Key_FileSite1_TabNew_64_85, Cmd_NewSearchFolder, Cmd_FileSite_NewSearchFolder, false);
                    if (!CommandExists(Key_FileSite1_TabNew_64_85, Cmd_FileSite_NewFolder, false))
                        ReplaceCommands(Key_FileSite1_TabNew_64_85, Cmd_NewFolder, Cmd_FileSite_NewFolder, false);

                    //Workspace new for Filesite
                    if (!CommandExists(Key_FileSite1_WorkspaceNew_64_85, Cmd_FileSite_NewSearchFolder, false))
                        ReplaceCommands(Key_FileSite1_WorkspaceNew_64_85, Cmd_NewSearchFolder, Cmd_FileSite_NewSearchFolder, false);
                    if (!CommandExists(Key_FileSite1_WorkspaceNew_64_85, Cmd_FileSite_NewFolder, false))
                        ReplaceCommands(Key_FileSite1_WorkspaceNew_64_85, Cmd_NewFolder, Cmd_FileSite_NewFolder, false);
                    if (!CommandExists(Key_FileSite1_WorkspaceNew_64_85, Cmd_FileSite_NewTab, false))
                        ReplaceCommands(Key_FileSite1_WorkspaceNew_64_85, Cmd_NewTab, Cmd_FileSite_NewTab, false);


                    //iManext1
                    //Search folder new for imanext1
                    if (!CommandExists(Key_iManExt1_SearchFolderNew_64_85, Cmd_Desksite_NewSearchFolder, false))
                        ReplaceCommands(Key_iManExt1_SearchFolderNew_64_85, Cmd_NewSearchFolder, Cmd_Desksite_NewSearchFolder, false);
                    if (!CommandExists(Key_iManExt1_SearchFolderNew_64_85, Cmd_Desksite_NewFolder, false))
                        ReplaceCommands(Key_iManExt1_SearchFolderNew_64_85, Cmd_NewFolder, Cmd_Desksite_NewFolder, false);

                    //folder new for imanext1
                    if (!CommandExists(Key_iManExt1_FolderNew_64_85, Cmd_Desksite_NewSearchFolder, false))
                        ReplaceCommands(Key_iManExt1_FolderNew_64_85, Cmd_NewSearchFolder, Cmd_Desksite_NewSearchFolder, false);
                    if (!CommandExists(Key_iManExt1_FolderNew_64_85, Cmd_Desksite_NewFolder, false))
                        ReplaceCommands(Key_iManExt1_FolderNew_64_85, Cmd_NewFolder, Cmd_Desksite_NewFolder, false);

                    //Workspace new for imanext1
                    if (!CommandExists(Key_iManExt1_WorkspaceNew_64_85, Cmd_Desksite_NewSearchFolder, false))
                        ReplaceCommands(Key_iManExt1_WorkspaceNew_64_85, Cmd_NewSearchFolder, Cmd_Desksite_NewSearchFolder, false);
                    if (!CommandExists(Key_iManExt1_WorkspaceNew_64_85, Cmd_Desksite_NewFolder, false))
                        ReplaceCommands(Key_iManExt1_WorkspaceNew_64_85, Cmd_NewFolder, Cmd_Desksite_NewFolder, false);
                    if (!CommandExists(Key_iManExt1_WorkspaceNew_64_85, Cmd_Desksite_NewTab, false))
                        ReplaceCommands(Key_iManExt1_WorkspaceNew_64_85, Cmd_NewTab, Cmd_Desksite_NewTab, false);

                    //imanext2
                    //Search folder new for imanext2
                    if (!CommandExists(Key_iManExt2_SearchFolderNew_64_85, Cmd_Desksite_NewSearchFolder, false))
                        ReplaceCommands(Key_iManExt2_SearchFolderNew_64_85, Cmd_NewSearchFolder, Cmd_Desksite_NewSearchFolder, false);
                    if (!CommandExists(Key_iManExt2_SearchFolderNew_64_85, Cmd_Desksite_NewFolder, false))
                        ReplaceCommands(Key_iManExt2_SearchFolderNew_64_85, Cmd_NewFolder, Cmd_Desksite_NewFolder, false);

                    //folder new for imanext2
                    if (!CommandExists(Key_iManExt2_FolderNew_64_85, Cmd_Desksite_NewSearchFolder, false))
                        ReplaceCommands(Key_iManExt2_FolderNew_64_85, Cmd_NewSearchFolder, Cmd_Desksite_NewSearchFolder, false);
                    if (!CommandExists(Key_iManExt2_FolderNew_64_85, Cmd_Desksite_NewFolder, false))
                        ReplaceCommands(Key_iManExt2_FolderNew_64_85, Cmd_NewFolder, Cmd_Desksite_NewFolder, false);

                    //Workspace new for imanext2
                    if (!CommandExists(Key_iManExt2_WorkSpaceNew_64_85, Cmd_Desksite_NewSearchFolder, false))
                        ReplaceCommands(Key_iManExt2_WorkSpaceNew_64_85, Cmd_NewSearchFolder, Cmd_Desksite_NewSearchFolder, false);
                    if (!CommandExists(Key_iManExt2_WorkSpaceNew_64_85, Cmd_Desksite_NewFolder, false))
                        ReplaceCommands(Key_iManExt2_WorkSpaceNew_64_85, Cmd_NewFolder, Cmd_Desksite_NewFolder, false);
                    if (!CommandExists(Key_iManExt2_WorkSpaceNew_64_85, Cmd_Desksite_NewTab, false))
                        ReplaceCommands(Key_iManExt2_WorkSpaceNew_64_85, Cmd_NewTab, Cmd_Desksite_NewTab, false);

                    //imanext3
                    //Search folder new for imanext3
                    if (!CommandExists(Key_iManExt3_SearchFolderNew_64_85, Cmd_iIntegrationDlg_NewSearchFolder, false))
                        ReplaceCommands(Key_iManExt3_SearchFolderNew_64_85, Cmd_NewSearchFolder, Cmd_iIntegrationDlg_NewSearchFolder, false);
                    if (!CommandExists(Key_iManExt3_SearchFolderNew_64_85, Cmd_iIntegrationDlg_NewFolder, false))
                        ReplaceCommands(Key_iManExt3_SearchFolderNew_64_85, Cmd_NewFolder, Cmd_iIntegrationDlg_NewFolder, false);

                    //folder new for imanext3
                    if (!CommandExists(Key_iManExt3_FolderNew_64_85, Cmd_iIntegrationDlg_NewSearchFolder, false))
                        ReplaceCommands(Key_iManExt3_FolderNew_64_85, Cmd_NewSearchFolder, Cmd_iIntegrationDlg_NewSearchFolder, false);
                    if (!CommandExists(Key_iManExt3_FolderNew_64_85, Cmd_iIntegrationDlg_NewFolder, false))
                        ReplaceCommands(Key_iManExt3_FolderNew_64_85, Cmd_NewFolder, Cmd_iIntegrationDlg_NewFolder, false);

                    //Workspace new for imanext3
                    if (!CommandExists(Key_iManExt3_WorkspaceNew_64_85, Cmd_iIntegrationDlg_NewSearchFolder, false))
                        ReplaceCommands(Key_iManExt3_WorkspaceNew_64_85, Cmd_NewSearchFolder, Cmd_iIntegrationDlg_NewSearchFolder, false);
                    if (!CommandExists(Key_iManExt3_WorkspaceNew_64_85, Cmd_iIntegrationDlg_NewFolder, false))
                        ReplaceCommands(Key_iManExt3_WorkspaceNew_64_85, Cmd_NewFolder, Cmd_iIntegrationDlg_NewFolder, false);
                    if (!CommandExists(Key_iManExt3_WorkspaceNew_64_85, Cmd_iIntegrationDlg_NewTab, false))
                        ReplaceCommands(Key_iManExt3_WorkspaceNew_64_85, Cmd_NewTab, Cmd_iIntegrationDlg_NewTab, false);
                    session.Log("85 64 done");

                }


                else if (WSVer_OSBit == "90 32")
                {


                    //---------------------
                    //--FOR 32-bit MACHINES  Version 9.0
                    //---------------------



                    if (!CommandExists(Key_DeskSite1_Tab_32_90, Cmd_Native1, true))
                        ReplaceCommands(Key_DeskSite1_Tab_32_90, Cmd_OptionalFolder, Cmd_Native1, true);

                    session.Log(Key_DeskSite1_Tab_32_90 + "UnRegistration over");


                    if (!CommandExists(Key_FileSite1_Tab_32_90, Cmd_Native2, true))
                        ReplaceCommands(Key_FileSite1_Tab_32_90, Cmd_OptionalFolder, Cmd_Native2, true);

                    session.Log(Key_FileSite1_Tab_32_90 + "UnRegistration over");




                    if (!CommandExists(Key_FileSite4_32_90, Cmd_Native2, true))
                        ReplaceCommands(Key_FileSite4_32_90, Cmd_OptionalFolder, Cmd_Native2, true);
                    session.Log(Key_FileSite4_32_90 + "UnRegistration over");

                    if (!CommandExists(Key_FileSite5_32_90, Cmd_Native2, true))
                        ReplaceCommands(Key_FileSite5_32_90, Cmd_OptionalFolder, Cmd_Native2, true);
                    session.Log(Key_FileSite5_32_90 + "UnRegistration over");

                    if (!CommandExists(Key_iManExt1_32_90, Cmd_Native2, true))
                        ReplaceCommands(Key_iManExt1_32_90, Cmd_OptionalFolder, Cmd_Native2, true);

                    session.Log(Key_iManExt1_32_90 + "UnRegistration over");
                    if (!CommandExists(Key_iManExt2_32_90, Cmd_Native2, true))
                        ReplaceCommands(Key_iManExt2_32_90, Cmd_OptionalFolder, Cmd_Native2, true);
                    session.Log(Key_iManExt2_32_90 + "UnRegistration over");
                    //Added
                    if (!CommandExists(Key_FileSite1_Folder_32_90, Cmd_Native2, true))
                        ReplaceCommands(Key_FileSite1_Folder_32_90, Cmd_OptionalFolder, Cmd_Native2, true);

                    session.Log(Key_FileSite1_Folder_32_90 + "UnRegistration over");
                    if (!CommandExists(Key_FileSite1_SearchFolder_32_90, Cmd_Native2, true))
                        ReplaceCommands(Key_FileSite1_SearchFolder_32_90, Cmd_OptionalFolder, Cmd_Native2, true);
                    session.Log(Key_FileSite1_SearchFolder_32_90 + "UnRegistration over");
                    if (!CommandExists(Key_iManExt2_SearchFolder_32_90, Cmd_Native2, true))
                        ReplaceCommands(Key_iManExt2_SearchFolder_32_90, Cmd_OptionalFolder, Cmd_Native2, true);
                    session.Log(Key_iManExt2_SearchFolder_32_90 + "UnRegistration over");
                    if (!CommandExists(Key_iManExt1_SearchFolder_32_90, Cmd_Native2, true))
                        ReplaceCommands(Key_iManExt1_SearchFolder_32_90, Cmd_OptionalFolder, Cmd_Native2, true);
                    session.Log(Key_iManExt1_SearchFolder_32_90 + "UnRegistration over");
                    if (!CommandExists(Key_iManExt3_32_90, Cmd_Native2, true))
                        ReplaceCommands(Key_iManExt3_32_90, Cmd_OptionalFolder, Cmd_Native2, true);
                    session.Log(Key_iManExt3_32_90 + "UnRegistration over");
                    if (!CommandExists(Key_iManExt3_SearchFolder_32_90, Cmd_Native2, true))
                        ReplaceCommands(Key_iManExt3_SearchFolder_32_90, Cmd_OptionalFolder, Cmd_Native2, true);
                    session.Log(Key_iManExt3_SearchFolder_32_90 + "UnRegistration over");
                    if (!CommandExists(Key_DeskSite1_SearchFolder_32_90, Cmd_Native1, true))
                        ReplaceCommands(Key_DeskSite1_SearchFolder_32_90, Cmd_OptionalFolder, Cmd_Native1, true);
                    session.Log(Key_DeskSite1_SearchFolder_32_90 + "UnRegistration over");

                    //Rename

                    if (!CommandExists(Key_DeskSite1_Tab_32_90, Cmd_Desksite, true))
                        ReplaceCommands(Key_DeskSite1_Tab_32_90, Cmd_Rename, Cmd_Desksite, true);
                    session.Log(Key_DeskSite1_Tab_32_90 + "UnRegistration over");



                    if (!CommandExists(Key_FileSite1_Tab_32_90, Cmd_FileSite, true))
                        ReplaceCommands(Key_FileSite1_Tab_32_90, Cmd_Rename, Cmd_FileSite, true);

                    session.Log(Key_FileSite1_Tab_32_90 + "UnRegistration over");

                    if (!CommandExists(Key_FileSite1_Folder_32_90, Cmd_FileSite, true))
                        ReplaceCommands(Key_FileSite1_Folder_32_90, Cmd_Rename, Cmd_FileSite, true);
                    session.Log(Key_FileSite1_Folder_32_90 + "UnRegistration over");

                    if (!CommandExists(Key_FileSite1_SearchFolder_32_90, Cmd_FileSite, true))
                        ReplaceCommands(Key_FileSite1_SearchFolder_32_90, Cmd_Rename, Cmd_FileSite, true);
                    session.Log(Key_FileSite1_SearchFolder_32_90 + "UnRegistration over");
                    if (!CommandExists(Key_DeskSite1_SearchFolder_32_90, Cmd_Desksite, true))
                        ReplaceCommands(Key_DeskSite1_SearchFolder_32_90, Cmd_Rename, Cmd_Desksite, true);

                    //From here

                    //Search folder new for Desksite
                    if (!CommandExists(Key_Desksite_SearchFolderNew_32_90, Cmd_Desksite_NewSearchFolder, true))
                        ReplaceCommands(Key_Desksite_SearchFolderNew_32_90, Cmd_NewSearchFolder, Cmd_Desksite_NewSearchFolder, true);
                    if (!CommandExists(Key_Desksite_SearchFolderNew_32_90, Cmd_Desksite_NewFolder, true))
                        ReplaceCommands(Key_Desksite_SearchFolderNew_32_90, Cmd_NewFolder, Cmd_Desksite_NewFolder, true);

                    //folder new for Desksite
                    if (!CommandExists(Key_Desksite_FolderNew_32_90, Cmd_Desksite_NewSearchFolder, true))
                        ReplaceCommands(Key_Desksite_FolderNew_32_90, Cmd_NewSearchFolder, Cmd_Desksite_NewSearchFolder, true);
                    if (!CommandExists(Key_Desksite_FolderNew_32_90, Cmd_Desksite_NewFolder, true))
                        ReplaceCommands(Key_Desksite_FolderNew_32_90, Cmd_NewFolder, Cmd_Desksite_NewFolder, true);

                    //Workspace new for Desksite
                    if (!CommandExists(Key_Desksite_WorkspaceNew_32_90, Cmd_Desksite_NewSearchFolder, true))
                        ReplaceCommands(Key_Desksite_WorkspaceNew_32_90, Cmd_NewSearchFolder, Cmd_Desksite_NewSearchFolder, true);
                    if (!CommandExists(Key_Desksite_WorkspaceNew_32_90, Cmd_Desksite_NewFolder, true))
                        ReplaceCommands(Key_Desksite_WorkspaceNew_32_90, Cmd_NewFolder, Cmd_Desksite_NewFolder, true);
                    if (!CommandExists(Key_Desksite_WorkspaceNew_32_90, Cmd_Desksite_NewTab, true))
                        ReplaceCommands(Key_Desksite_WorkspaceNew_32_90, Cmd_NewTab, Cmd_Desksite_NewTab, true);

                    //Search folder new for Filesite
                    if (!CommandExists(Key_FileSite1_SearchFolderNew_32_90, Cmd_FileSite_NewSearchFolder, true))
                        ReplaceCommands(Key_FileSite1_SearchFolderNew_32_90, Cmd_NewSearchFolder, Cmd_FileSite_NewSearchFolder, true);
                    if (!CommandExists(Key_FileSite1_SearchFolderNew_32_90, Cmd_FileSite_NewFolder, true))
                        ReplaceCommands(Key_FileSite1_SearchFolderNew_32_90, Cmd_NewFolder, Cmd_FileSite_NewFolder, true);

                    //folder new for Filesite
                    if (!CommandExists(Key_FileSite1_FolderNew_32_90, Cmd_FileSite_NewSearchFolder, true))
                        ReplaceCommands(Key_FileSite1_FolderNew_32_90, Cmd_NewSearchFolder, Cmd_FileSite_NewSearchFolder, true);
                    if (!CommandExists(Key_FileSite1_FolderNew_32_90, Cmd_FileSite_NewFolder, true))
                        ReplaceCommands(Key_FileSite1_FolderNew_32_90, Cmd_NewFolder, Cmd_FileSite_NewFolder, true);
                    //Tab new for Filesite
                    if (!CommandExists(Key_FileSite1_TabNew_32_90, Cmd_FileSite_NewSearchFolder, true))
                        ReplaceCommands(Key_FileSite1_TabNew_32_90, Cmd_NewSearchFolder, Cmd_FileSite_NewSearchFolder, true);
                    if (!CommandExists(Key_FileSite1_TabNew_32_90, Cmd_FileSite_NewFolder, true))
                        ReplaceCommands(Key_FileSite1_TabNew_32_90, Cmd_NewFolder, Cmd_FileSite_NewFolder, true);

                    //Workspace new for Filesite
                    if (!CommandExists(Key_FileSite1_WorkspaceNew_32_90, Cmd_FileSite_NewSearchFolder, true))
                        ReplaceCommands(Key_FileSite1_WorkspaceNew_32_90, Cmd_NewSearchFolder, Cmd_FileSite_NewSearchFolder, true);
                    if (!CommandExists(Key_FileSite1_WorkspaceNew_32_90, Cmd_FileSite_NewFolder, true))
                        ReplaceCommands(Key_FileSite1_WorkspaceNew_32_90, Cmd_NewFolder, Cmd_FileSite_NewFolder, true);
                    if (!CommandExists(Key_FileSite1_WorkspaceNew_32_90, Cmd_FileSite_NewTab, true))
                        ReplaceCommands(Key_FileSite1_WorkspaceNew_32_90, Cmd_NewTab, Cmd_FileSite_NewTab, true);


                    //iManext1
                    //Search folder new for imanext1
                    if (!CommandExists(Key_iManExt1_SearchFolderNew_32_90, Cmd_Desksite_NewSearchFolder, true))
                        ReplaceCommands(Key_iManExt1_SearchFolderNew_32_90, Cmd_NewSearchFolder, Cmd_Desksite_NewSearchFolder, true);
                    if (!CommandExists(Key_iManExt1_SearchFolderNew_32_90, Cmd_Desksite_NewFolder, true))
                        ReplaceCommands(Key_iManExt1_SearchFolderNew_32_90, Cmd_NewFolder, Cmd_Desksite_NewFolder, true);

                    //folder new for imanext1
                    if (!CommandExists(Key_iManExt1_FolderNew_32_90, Cmd_Desksite_NewSearchFolder, true))
                        ReplaceCommands(Key_iManExt1_FolderNew_32_90, Cmd_NewSearchFolder, Cmd_Desksite_NewSearchFolder, true);
                    if (!CommandExists(Key_iManExt1_FolderNew_32_90, Cmd_Desksite_NewFolder, true))
                        ReplaceCommands(Key_iManExt1_FolderNew_32_90, Cmd_NewFolder, Cmd_Desksite_NewFolder, true);

                    //Workspace new for imanext1
                    if (!CommandExists(Key_iManExt1_WorkspaceNew_32_90, Cmd_Desksite_NewSearchFolder, true))
                        ReplaceCommands(Key_iManExt1_WorkspaceNew_32_90, Cmd_NewSearchFolder, Cmd_Desksite_NewSearchFolder, true);
                    if (!CommandExists(Key_iManExt1_WorkspaceNew_32_90, Cmd_Desksite_NewFolder, true))
                        ReplaceCommands(Key_iManExt1_WorkspaceNew_32_90, Cmd_NewFolder, Cmd_Desksite_NewFolder, true);
                    if (!CommandExists(Key_iManExt1_WorkspaceNew_32_90, Cmd_Desksite_NewTab, true))
                        ReplaceCommands(Key_iManExt1_WorkspaceNew_32_90, Cmd_NewTab, Cmd_Desksite_NewTab, true);

                    //imanext2
                    //Search folder new for imanext2
                    if (!CommandExists(Key_iManExt2_SearchFolderNew_32_90, Cmd_Desksite_NewSearchFolder, true))
                        ReplaceCommands(Key_iManExt2_SearchFolderNew_32_90, Cmd_NewSearchFolder, Cmd_Desksite_NewSearchFolder, true);
                    if (!CommandExists(Key_iManExt2_SearchFolderNew_32_90, Cmd_Desksite_NewFolder, true))
                        ReplaceCommands(Key_iManExt2_SearchFolderNew_32_90, Cmd_NewFolder, Cmd_Desksite_NewFolder, true);

                    //folder new for imanext2
                    if (!CommandExists(Key_iManExt2_FolderNew_32_90, Cmd_Desksite_NewSearchFolder, true))
                        ReplaceCommands(Key_iManExt2_FolderNew_32_90, Cmd_NewSearchFolder, Cmd_Desksite_NewSearchFolder, true);
                    if (!CommandExists(Key_iManExt2_FolderNew_32_90, Cmd_Desksite_NewFolder, true))
                        ReplaceCommands(Key_iManExt2_FolderNew_32_90, Cmd_NewFolder, Cmd_Desksite_NewFolder, true);

                    //Workspace new for imanext2
                    if (!CommandExists(Key_iManExt2_WorkSpaceNew_32_90, Cmd_Desksite_NewSearchFolder, true))
                        ReplaceCommands(Key_iManExt2_WorkSpaceNew_32_90, Cmd_NewSearchFolder, Cmd_Desksite_NewSearchFolder, true);
                    if (!CommandExists(Key_iManExt2_WorkSpaceNew_32_90, Cmd_Desksite_NewFolder, true))
                        ReplaceCommands(Key_iManExt2_WorkSpaceNew_32_90, Cmd_NewFolder, Cmd_Desksite_NewFolder, true);
                    if (!CommandExists(Key_iManExt2_WorkSpaceNew_32_90, Cmd_Desksite_NewTab, true))
                        ReplaceCommands(Key_iManExt2_WorkSpaceNew_32_90, Cmd_NewTab, Cmd_Desksite_NewTab, true);

                    //imanext3
                    //Search folder new for imanext3
                    if (!CommandExists(Key_iManExt3_SearchFolderNew_32_90, Cmd_iIntegrationDlg_NewSearchFolder, true))
                        ReplaceCommands(Key_iManExt3_SearchFolderNew_32_90, Cmd_NewSearchFolder, Cmd_iIntegrationDlg_NewSearchFolder, true);
                    if (!CommandExists(Key_iManExt3_SearchFolderNew_32_90, Cmd_iIntegrationDlg_NewFolder, true))
                        ReplaceCommands(Key_iManExt3_SearchFolderNew_32_90, Cmd_NewFolder, Cmd_iIntegrationDlg_NewFolder, true);

                    //folder new for imanext3
                    if (!CommandExists(Key_iManExt3_FolderNew_32_90, Cmd_iIntegrationDlg_NewSearchFolder, true))
                        ReplaceCommands(Key_iManExt3_FolderNew_32_90, Cmd_NewSearchFolder, Cmd_iIntegrationDlg_NewSearchFolder, true);
                    if (!CommandExists(Key_iManExt3_FolderNew_32_90, Cmd_iIntegrationDlg_NewFolder, true))
                        ReplaceCommands(Key_iManExt3_FolderNew_32_90, Cmd_NewFolder, Cmd_iIntegrationDlg_NewFolder, true);

                    //Workspace new for imanext3
                    if (!CommandExists(Key_iManExt3_WorkspaceNew_32_90, Cmd_iIntegrationDlg_NewSearchFolder, true))
                        ReplaceCommands(Key_iManExt3_WorkspaceNew_32_90, Cmd_NewSearchFolder, Cmd_iIntegrationDlg_NewSearchFolder, true);
                    if (!CommandExists(Key_iManExt3_WorkspaceNew_32_90, Cmd_iIntegrationDlg_NewFolder, true))
                        ReplaceCommands(Key_iManExt3_WorkspaceNew_32_90, Cmd_NewFolder, Cmd_iIntegrationDlg_NewFolder, true);
                    if (!CommandExists(Key_iManExt3_WorkspaceNew_32_90, Cmd_iIntegrationDlg_NewTab, true))
                        ReplaceCommands(Key_iManExt3_WorkspaceNew_32_90, Cmd_NewTab, Cmd_iIntegrationDlg_NewTab, true);


                    session.Log("90 32 done");


                }


                else if (WSVer_OSBit == "90 64")
                {


                    //---------------------
                    //--FOR 64-bit MACHINES
                    //---------------------


                    if (!CommandExists(Key_DeskSite1_Tab_64_90, Cmd_Native1, false))
                        ReplaceCommands(Key_DeskSite1_Tab_64_90, Cmd_OptionalFolder, Cmd_Native1, false);

                    session.Log(Key_DeskSite1_Tab_64_90 + "UnRegistration over");


                    if (!CommandExists(Key_FileSite1_Tab_64_90, Cmd_Native2, false))
                        ReplaceCommands(Key_FileSite1_Tab_64_90, Cmd_OptionalFolder, Cmd_Native2, false);


                    session.Log(Key_FileSite1_Tab_64_90 + "UnRegistration over");



                    if (!CommandExists(Key_FileSite4_64_90, Cmd_Native2, false))
                        ReplaceCommands(Key_FileSite4_64_90, Cmd_OptionalFolder, Cmd_Native2, false);

                    session.Log(Key_FileSite4_64_90 + "UnRegistration over");
                    if (!CommandExists(Key_FileSite5_64_90, Cmd_Native2, false))
                        ReplaceCommands(Key_FileSite5_64_90, Cmd_OptionalFolder, Cmd_Native2, false);

                    session.Log(Key_FileSite5_64_90 + "UnRegistration over");
                    if (!CommandExists(Key_iManExt1_64_90, Cmd_Native2, false))
                        ReplaceCommands(Key_iManExt1_64_90, Cmd_OptionalFolder, Cmd_Native2, false);

                    session.Log(Key_iManExt1_64_90 + "UnRegistration over");
                    if (!CommandExists(Key_iManExt2_64_90, Cmd_Native2, false))
                        ReplaceCommands(Key_iManExt2_64_90, Cmd_OptionalFolder, Cmd_Native2, false);
                    session.Log(Key_iManExt2_64_90 + "UnRegistration over");
                    //Added
                    if (!CommandExists(Key_FileSite1_Folder_64_90, Cmd_Native2, false))
                        ReplaceCommands(Key_FileSite1_Folder_64_90, Cmd_OptionalFolder, Cmd_Native2, false);
                    session.Log(Key_FileSite1_Folder_64_90 + "UnRegistration over");
                    if (!CommandExists(Key_FileSite1_SearchFolder_64_90, Cmd_Native2, false))
                        ReplaceCommands(Key_FileSite1_SearchFolder_64_90, Cmd_OptionalFolder, Cmd_Native2, false);
                    session.Log(Key_FileSite1_SearchFolder_64_90 + "UnRegistration over");
                    if (!CommandExists(Key_iManExt2_SearchFolder_64_90, Cmd_Native2, false))
                        ReplaceCommands(Key_iManExt2_SearchFolder_64_90, Cmd_OptionalFolder, Cmd_Native2, false);
                    session.Log(Key_iManExt2_SearchFolder_64_90 + "UnRegistration over");
                    if (!CommandExists(Key_iManExt1_SearchFolder_64_90, Cmd_Native2, false))
                        ReplaceCommands(Key_iManExt1_SearchFolder_64_90, Cmd_OptionalFolder, Cmd_Native2, false);
                    session.Log(Key_iManExt1_SearchFolder_64_90 + "UnRegistration over");
                    if (!CommandExists(Key_iManExt3_64_90, Cmd_Native2, false))
                        ReplaceCommands(Key_iManExt3_64_90, Cmd_OptionalFolder, Cmd_Native2, false);
                    session.Log(Key_iManExt3_64_90 + "UnRegistration over");
                    if (!CommandExists(Key_iManExt3_SearchFolder_64_90, Cmd_Native2, false))
                        ReplaceCommands(Key_iManExt3_SearchFolder_64_90, Cmd_OptionalFolder, Cmd_Native2, false);
                    session.Log(Key_iManExt3_SearchFolder_64_90 + "UnRegistration over");
                    if (!CommandExists(Key_DeskSite1_SearchFolder_64_90, Cmd_Native1, false))
                        ReplaceCommands(Key_DeskSite1_SearchFolder_64_90, Cmd_OptionalFolder, Cmd_Native1, false);
                    session.Log(Key_DeskSite1_SearchFolder_64_90 + "UnRegistration over");
                    //Rename
                    if (!CommandExists(Key_DeskSite1_Tab_64_90, Cmd_Desksite, false))
                        ReplaceCommands(Key_DeskSite1_Tab_64_90, Cmd_Rename, Cmd_Desksite, false);
                    session.Log(Key_DeskSite1_Tab_64_90 + "UnRegistration over");



                    if (!CommandExists(Key_FileSite1_Tab_64_90, Cmd_FileSite, false))
                        ReplaceCommands(Key_FileSite1_Tab_64_90, Cmd_Rename, Cmd_FileSite, false);
                    session.Log(Key_FileSite1_Tab_64_90 + "UnRegistration over");


                    if (!CommandExists(Key_FileSite1_Folder_64_90, Cmd_FileSite, false))
                        ReplaceCommands(Key_FileSite1_Folder_64_90, Cmd_Rename, Cmd_FileSite, false);
                    session.Log(Key_FileSite1_Folder_64_90 + "UnRegistration over");
                    if (!CommandExists(Key_FileSite1_SearchFolder_64_90, Cmd_FileSite, false))
                        ReplaceCommands(Key_FileSite1_SearchFolder_64_90, Cmd_Rename, Cmd_FileSite, false);
                    session.Log(Key_FileSite1_SearchFolder_64_90 + "UnRegistration over");
                    if (!CommandExists(Key_DeskSite1_SearchFolder_64_90, Cmd_Desksite, false))
                        ReplaceCommands(Key_DeskSite1_SearchFolder_64_90, Cmd_Rename, Cmd_Desksite, false);

                    //From here

                    //Search folder new for Desksite
                    if (!CommandExists(Key_Desksite_SearchFolderNew_64_90, Cmd_Desksite_NewSearchFolder, false))
                        ReplaceCommands(Key_Desksite_SearchFolderNew_64_90, Cmd_NewSearchFolder, Cmd_Desksite_NewSearchFolder, false);
                    if (!CommandExists(Key_Desksite_SearchFolderNew_64_90, Cmd_Desksite_NewFolder, false))
                        ReplaceCommands(Key_Desksite_SearchFolderNew_64_90, Cmd_NewFolder, Cmd_Desksite_NewFolder, false);

                    //folder new for Desksite
                    if (!CommandExists(Key_Desksite_FolderNew_64_90, Cmd_Desksite_NewSearchFolder, false))
                        ReplaceCommands(Key_Desksite_FolderNew_64_90, Cmd_NewSearchFolder, Cmd_Desksite_NewSearchFolder, false);
                    if (!CommandExists(Key_Desksite_FolderNew_64_90, Cmd_Desksite_NewFolder, false))
                        ReplaceCommands(Key_Desksite_FolderNew_64_90, Cmd_NewFolder, Cmd_Desksite_NewFolder, false);

                    //Workspace new for Desksite
                    if (!CommandExists(Key_Desksite_WorkspaceNew_64_90, Cmd_Desksite_NewSearchFolder, false))
                        ReplaceCommands(Key_Desksite_WorkspaceNew_64_90, Cmd_NewSearchFolder, Cmd_Desksite_NewSearchFolder, false);
                    if (!CommandExists(Key_Desksite_WorkspaceNew_64_90, Cmd_Desksite_NewFolder, false))
                        ReplaceCommands(Key_Desksite_WorkspaceNew_64_90, Cmd_NewFolder, Cmd_Desksite_NewFolder, false);
                    if (!CommandExists(Key_Desksite_WorkspaceNew_64_90, Cmd_Desksite_NewTab, false))
                        ReplaceCommands(Key_Desksite_WorkspaceNew_64_90, Cmd_NewTab, Cmd_Desksite_NewTab, false);

                    //Search folder new for Filesite
                    if (!CommandExists(Key_FileSite1_SearchFolderNew_64_90, Cmd_FileSite_NewSearchFolder, false))
                        ReplaceCommands(Key_FileSite1_SearchFolderNew_64_90, Cmd_NewSearchFolder, Cmd_FileSite_NewSearchFolder, false);
                    if (!CommandExists(Key_FileSite1_SearchFolderNew_64_90, Cmd_FileSite_NewFolder, false))
                        ReplaceCommands(Key_FileSite1_SearchFolderNew_64_90, Cmd_NewFolder, Cmd_FileSite_NewFolder, false);

                    //folder new for Filesite
                    if (!CommandExists(Key_FileSite1_FolderNew_64_90, Cmd_FileSite_NewSearchFolder, false))
                        ReplaceCommands(Key_FileSite1_FolderNew_64_90, Cmd_NewSearchFolder, Cmd_FileSite_NewSearchFolder, false);
                    if (!CommandExists(Key_FileSite1_FolderNew_64_90, Cmd_FileSite_NewFolder, false))
                        ReplaceCommands(Key_FileSite1_FolderNew_64_90, Cmd_NewFolder, Cmd_FileSite_NewFolder, false);
                    //Tab new for Filesite
                    if (!CommandExists(Key_FileSite1_TabNew_64_90, Cmd_FileSite_NewSearchFolder, false))
                        ReplaceCommands(Key_FileSite1_TabNew_64_90, Cmd_NewSearchFolder, Cmd_FileSite_NewSearchFolder, false);
                    if (!CommandExists(Key_FileSite1_TabNew_64_90, Cmd_FileSite_NewFolder, false))
                        ReplaceCommands(Key_FileSite1_TabNew_64_90, Cmd_NewFolder, Cmd_FileSite_NewFolder, false);

                    //Workspace new for Filesite
                    if (!CommandExists(Key_FileSite1_WorkspaceNew_64_90, Cmd_FileSite_NewSearchFolder, false))
                        ReplaceCommands(Key_FileSite1_WorkspaceNew_64_90, Cmd_NewSearchFolder, Cmd_FileSite_NewSearchFolder, false);
                    if (!CommandExists(Key_FileSite1_WorkspaceNew_64_90, Cmd_FileSite_NewFolder, false))
                        ReplaceCommands(Key_FileSite1_WorkspaceNew_64_90, Cmd_NewFolder, Cmd_FileSite_NewFolder, false);
                    if (!CommandExists(Key_FileSite1_WorkspaceNew_64_90, Cmd_FileSite_NewTab, false))
                        ReplaceCommands(Key_FileSite1_WorkspaceNew_64_90, Cmd_NewTab, Cmd_FileSite_NewTab, false);


                    //iManext1
                    //Search folder new for imanext1
                    if (!CommandExists(Key_iManExt1_SearchFolderNew_64_90, Cmd_Desksite_NewSearchFolder, false))
                        ReplaceCommands(Key_iManExt1_SearchFolderNew_64_90, Cmd_NewSearchFolder, Cmd_Desksite_NewSearchFolder, false);
                    if (!CommandExists(Key_iManExt1_SearchFolderNew_64_90, Cmd_Desksite_NewFolder, false))
                        ReplaceCommands(Key_iManExt1_SearchFolderNew_64_90, Cmd_NewFolder, Cmd_Desksite_NewFolder, false);

                    //folder new for imanext1
                    if (!CommandExists(Key_iManExt1_FolderNew_64_90, Cmd_Desksite_NewSearchFolder, false))
                        ReplaceCommands(Key_iManExt1_FolderNew_64_90, Cmd_NewSearchFolder, Cmd_Desksite_NewSearchFolder, false);
                    if (!CommandExists(Key_iManExt1_FolderNew_64_90, Cmd_Desksite_NewFolder, false))
                        ReplaceCommands(Key_iManExt1_FolderNew_64_90, Cmd_NewFolder, Cmd_Desksite_NewFolder, false);

                    //Workspace new for imanext1
                    if (!CommandExists(Key_iManExt1_WorkspaceNew_64_90, Cmd_Desksite_NewSearchFolder, false))
                        ReplaceCommands(Key_iManExt1_WorkspaceNew_64_90, Cmd_NewSearchFolder, Cmd_Desksite_NewSearchFolder, false);
                    if (!CommandExists(Key_iManExt1_WorkspaceNew_64_90, Cmd_Desksite_NewFolder, false))
                        ReplaceCommands(Key_iManExt1_WorkspaceNew_64_90, Cmd_NewFolder, Cmd_Desksite_NewFolder, false);
                    if (!CommandExists(Key_iManExt1_WorkspaceNew_64_90, Cmd_Desksite_NewTab, false))
                        ReplaceCommands(Key_iManExt1_WorkspaceNew_64_90, Cmd_NewTab, Cmd_Desksite_NewTab, false);

                    //imanext2
                    //Search folder new for imanext2
                    if (!CommandExists(Key_iManExt2_SearchFolderNew_64_90, Cmd_Desksite_NewSearchFolder, false))
                        ReplaceCommands(Key_iManExt2_SearchFolderNew_64_90, Cmd_NewSearchFolder, Cmd_Desksite_NewSearchFolder, false);
                    if (!CommandExists(Key_iManExt2_SearchFolderNew_64_90, Cmd_Desksite_NewFolder, false))
                        ReplaceCommands(Key_iManExt2_SearchFolderNew_64_90, Cmd_NewFolder, Cmd_Desksite_NewFolder, false);

                    //folder new for imanext2
                    if (!CommandExists(Key_iManExt2_FolderNew_64_90, Cmd_Desksite_NewSearchFolder, false))
                        ReplaceCommands(Key_iManExt2_FolderNew_64_90, Cmd_NewSearchFolder, Cmd_Desksite_NewSearchFolder, false);
                    if (!CommandExists(Key_iManExt2_FolderNew_64_90, Cmd_Desksite_NewFolder, false))
                        ReplaceCommands(Key_iManExt2_FolderNew_64_90, Cmd_NewFolder, Cmd_Desksite_NewFolder, false);

                    //Workspace new for imanext2
                    if (!CommandExists(Key_iManExt2_WorkSpaceNew_64_90, Cmd_Desksite_NewSearchFolder, false))
                        ReplaceCommands(Key_iManExt2_WorkSpaceNew_64_90, Cmd_NewSearchFolder, Cmd_Desksite_NewSearchFolder, false);
                    if (!CommandExists(Key_iManExt2_WorkSpaceNew_64_90, Cmd_Desksite_NewFolder, false))
                        ReplaceCommands(Key_iManExt2_WorkSpaceNew_64_90, Cmd_NewFolder, Cmd_Desksite_NewFolder, false);
                    if (!CommandExists(Key_iManExt2_WorkSpaceNew_64_90, Cmd_Desksite_NewTab, false))
                        ReplaceCommands(Key_iManExt2_WorkSpaceNew_64_90, Cmd_NewTab, Cmd_Desksite_NewTab, false);

                    //imanext3
                    //Search folder new for imanext3
                    if (!CommandExists(Key_iManExt3_SearchFolderNew_64_90, Cmd_iIntegrationDlg_NewSearchFolder, false))
                        ReplaceCommands(Key_iManExt3_SearchFolderNew_64_90, Cmd_NewSearchFolder, Cmd_iIntegrationDlg_NewSearchFolder, false);
                    if (!CommandExists(Key_iManExt3_SearchFolderNew_64_90, Cmd_iIntegrationDlg_NewFolder, false))
                        ReplaceCommands(Key_iManExt3_SearchFolderNew_64_90, Cmd_NewFolder, Cmd_iIntegrationDlg_NewFolder, false);

                    //folder new for imanext3
                    if (!CommandExists(Key_iManExt3_FolderNew_64_90, Cmd_iIntegrationDlg_NewSearchFolder, false))
                        ReplaceCommands(Key_iManExt3_FolderNew_64_90, Cmd_NewSearchFolder, Cmd_iIntegrationDlg_NewSearchFolder, false);
                    if (!CommandExists(Key_iManExt3_FolderNew_64_90, Cmd_iIntegrationDlg_NewFolder, false))
                        ReplaceCommands(Key_iManExt3_FolderNew_64_90, Cmd_NewFolder, Cmd_iIntegrationDlg_NewFolder, false);

                    //Workspace new for imanext3
                    if (!CommandExists(Key_iManExt3_WorkspaceNew_64_90, Cmd_iIntegrationDlg_NewSearchFolder, false))
                        ReplaceCommands(Key_iManExt3_WorkspaceNew_64_90, Cmd_NewSearchFolder, Cmd_iIntegrationDlg_NewSearchFolder, false);
                    if (!CommandExists(Key_iManExt3_WorkspaceNew_64_90, Cmd_iIntegrationDlg_NewFolder, false))
                        ReplaceCommands(Key_iManExt3_WorkspaceNew_64_90, Cmd_NewFolder, Cmd_iIntegrationDlg_NewFolder, false);
                    if (!CommandExists(Key_iManExt3_WorkspaceNew_64_90, Cmd_iIntegrationDlg_NewTab, false))
                        ReplaceCommands(Key_iManExt3_WorkspaceNew_64_90, Cmd_NewTab, Cmd_iIntegrationDlg_NewTab, false);
                    
                    session.Log("90 64 done");

                }

            }
            catch (Exception ex)
            {

            }
            session.Log("UnRegistration Completed");
            return ActionResult.Success;
        }

        private static bool CommandExists(string key, string cmd, bool b64)
        {
            bool bExists = false;
            RegistryKey regKey = null;
            RegistryKey hklm = null;
            try
            {
                if (b64)
                {
                    hklm = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64);
                    regKey = hklm.OpenSubKey(key);
                }
                else
                {
                    hklm = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry32);
                    regKey = hklm.OpenSubKey(key);
                }

                if (regKey != null)
                {
                    object objVal = regKey.GetValue("Commands");
                    if (objVal != null)
                    {
                        string strVal = objVal as string;
                        if (strVal != null && strVal.Length > 0)
                        {
                            if (strVal.Contains(cmd))
                                bExists = true;
                        }
                    }
                }
            }
            finally
            {
                if (hklm != null)
                    hklm.Close();
                if (regKey != null)
                    regKey.Close();
            }
            return bExists;

        }
        private static void ReplaceCommands(string key, string Cmd1, string Cmd2, bool b64)
        {
            RegistryKey regKey = null;
            RegistryKey hklm = null;
            try
            {

                if (b64)
                {
                    hklm = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64);
                    regKey = hklm.OpenSubKey(key, true);
                }
                else
                {
                    hklm = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry32);
                    regKey = hklm.OpenSubKey(key, true);
                }

                if (regKey != null)
                {
                    object objVal = regKey.GetValue("Commands");
                    if (objVal != null)
                    {
                        string strVal = objVal as string;
                        if (strVal != null && strVal.Length > 0)
                        {
                            string replacedCommand = strVal.Replace(Cmd1, Cmd2);
                            regKey.SetValue("Commands", replacedCommand);
                        }

                    }
                }
            }
            finally
            {
                if (hklm != null)
                    hklm.Close();
                if (regKey != null)
                    regKey.Close();

            }
        }
        public static bool KeyExists(string key, bool bHive)
        {
            bool bExists = false;
            RegistryKey regKey = null;
            RegistryKey hklm = null;

            if (bHive)
            {
                hklm = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64);
                regKey = hklm.OpenSubKey(key);
            }
            else
            {
                hklm = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry32);
                regKey = hklm.OpenSubKey(key);
            }
            if (regKey != null)
            {

                object objVal = regKey.GetValue("path");
                if (objVal != null)
                    bExists = true;
                regKey.Close();
            }
            if (hklm != null)
                hklm.Close();
            return bExists;

        }
    }
}
