﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;
namespace PositionLibrary
{
    public class FormPositionSaver
    {
       
        string _commandName;
        public FormPositionSaver(string commandName)
        {
           
            _commandName = commandName;
        }

        public void SavePosition(Point location,Size size)
        {
            Microsoft.Win32.RegistryKey key = null;
            try
            {
                key = Microsoft.Win32.Registry.CurrentUser.CreateSubKey(@"Software\Interwoven\WorkSite\8.0\Work Add-ons\" + _commandName);
                if (key == null)
                    return;
                key.SetValue("X", location.X);
                key.SetValue("Y", location.Y);
                key.SetValue("Height", size.Height);
                key.SetValue("Width", size.Width);

            }
            catch
            {

            }
            finally
            {
                if (key != null)
                    key.Close();
            }

        }

        public void GetPosition(ref Point location,ref Size size,ref bool bLocationFound,ref bool bSizeFound)
        {
            
            Microsoft.Win32.RegistryKey key = null;
            try
            {
                key = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(@"Software\Interwoven\WorkSite\8.0\Work Add-ons\" + _commandName);
                if (key == null)
                    return ;
                object objX  = key.GetValue("X");
                object objY = key.GetValue("Y");
                if(objX != null && objY != null)
                {
                    location.X = (int)objX;
                    location.Y = (int)objY;
                    bLocationFound = true;
                }

                object objWidth = key.GetValue("Width");
                object objHeight = key.GetValue("Height");
                if(objWidth != null && objHeight != null)
                {
                    size.Width = (int)objWidth;
                    size.Height = (int)objHeight;
                    bSizeFound = true;
                }
            }
            catch
            {

            }
            finally
            {
                if (key != null)
                    key.Close();
            }
            
        }

    }
}
