﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;

namespace AHWorkspaceRegistryChanger
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        const string WorkSite_85_32 = @"SOFTWARE\Interwoven\Worksite\8.0\Common\InstallRoot";
        const string WorkSite_85_64 = @"SOFTWARE\Wow6432Node\Interwoven\Worksite\8.0\Common\InstallRoot";
        const string WorkSite_90_32 = @"SOFTWARE\Interwoven\Worksite\Client\Common\InstallRoot";
        const string WorkSite_90_64 = @"SOFTWARE\Wow6432Node\Interwoven\Worksite\Client\Common\InstallRoot";

        const string Cmd_AdHocWorkspace = "IManage.AdHocWorkspaceCmd";

        const string Cmd_Desksite = "iManExt2.IManNewWorkspaceCmd@266";
        const string Cmd_FileSite = "IManExt2.IManNewWorkspaceCmd@485";
        const string Cmd_Browse_EAI = "iManExt2.IManNewWorkspaceCmd@807";
        const string Cmd_Normal_EAI = "iManExt2.IManNewWorkspaceCmd";


        // **********  For 32-bit Machines - 9.0
        const string Key_FileSite_MyMatters_32_90 = @"SOFTWARE\Interwoven\WorkSite\Client\FileSite\Commands\MyMatters\New";
        const string Key_FileSite_MyWorkspaces_32_90 = @"SOFTWARE\Interwoven\WorkSite\Client\FileSite\Commands\MyWorkspaces\New";




        const string Key_DeskSite_SubscriptionFolder_32_90 = @"SOFTWARE\Interwoven\WorkSite\Client\DeskSite\Commands\Popup Menus\SubscriptionFolder\New";
        const string Key_DeskSite_Database_32_90 = @"SOFTWARE\Interwoven\WorkSite\Client\DeskSite\Commands\Popup Menus\Database\New";
        const string Key_DeskSite_MyWorkspace_32_90 = @"SOFTWARE\Interwoven\WorkSite\Client\DeskSite\Commands\Popup Menus\MyWorkSpaces";

        const string Key_Browse_SubscriptionFolder_32_90 = @"SOFTWARE\Interwoven\WorkSite\Client\iManExt\Browse Dialog\Popup Menus\SubscriptionFolder\New";
        const string Key_Browse_MyWorkspace_32_90 = @"SOFTWARE\Interwoven\WorkSite\Client\iManExt\Browse Dialog\Popup Menus\MyWorkSpaces";
        const string Key_Browse_Database_32_90 = @"SOFTWARE\Interwoven\WorkSite\Client\iManExt\Browse Dialog\Popup Menus\Database\New";

        const string Key_EAI_SubscriptionFolder_32_90 = @"SOFTWARE\Interwoven\WorkSite\Client\iManExt\Enhanced Integration Dialog\Popup Menus\SubscriptionFolder\New";
        const string Key_EAI_MyWorkspace_32_90 = @"SOFTWARE\Interwoven\WorkSite\Client\iManExt\Enhanced Integration Dialog\Popup Menus\MyWorkSpaces";
        const string Key_EAI_Database_32_90 = @"SOFTWARE\Interwoven\WorkSite\Client\iManExt\Enhanced Integration Dialog\Popup Menus\Database\New";


        const string Key_iIntegrationDialog_SubscriptionFolder_32_90 = @"SOFTWARE\Interwoven\WorkSite\Client\iIntegrationDlg\Commands\TreePopupMenu\SubscriptionFolder\New";
        const string Key_iIntegrationDialog_MyWorkspace_32_90 = @"SOFTWARE\Interwoven\WorkSite\Client\iIntegrationDlg\Commands\TreePopupMenu\MyWorkSpaces";


        // ********** For 64-bit Machines - 9.0
        const string Key_FileSite_MyMatters_64_90 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\Client\FileSite\Commands\MyMatters\New";
        const string Key_FileSite_MyWorkspaces_64_90 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\Client\FileSite\Commands\MyWorkspaces\New";




        const string Key_DeskSite_SubscriptionFolder_64_90 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\Client\DeskSite\Commands\Popup Menus\SubscriptionFolder\New";
        const string Key_DeskSite_Database_64_90 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\Client\DeskSite\Commands\Popup Menus\Database\New";
        const string Key_DeskSite_MyWorkspace_64_90 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\Client\DeskSite\Commands\Popup Menus\MyWorkSpaces";

        const string Key_Browse_SubscriptionFolder_64_90 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\Client\iManExt\Browse Dialog\Popup Menus\SubscriptionFolder\New";
        const string Key_Browse_MyWorkspace_64_90 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\Client\iManExt\Browse Dialog\Popup Menus\MyWorkSpaces";
        const string Key_Browse_Database_64_90 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\Client\iManExt\Browse Dialog\Popup Menus\Database\New";

        const string Key_EAI_SubscriptionFolder_64_90 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\Client\iManExt\Enhanced Integration Dialog\Popup Menus\SubscriptionFolder\New";
        const string Key_EAI_MyWorkspace_64_90 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\Client\iManExt\Enhanced Integration Dialog\Popup Menus\MyWorkSpaces";
        const string Key_EAI_Database_64_90 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\Client\iManExt\Enhanced Integration Dialog\Popup Menus\Database\New";


        const string Key_iIntegrationDialog_SubscriptionFolder_64_90 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\Client\iIntegrationDlg\Commands\TreePopupMenu\SubscriptionFolder\New";
        const string Key_iIntegrationDialog_MyWorkspace_64_90 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\Client\iIntegrationDlg\Commands\TreePopupMenu\MyWorkSpaces";


        //**********  For 32-bit Machines - 8.5
        const string Key_FileSite_MyMatters_32_85 = @"SOFTWARE\Interwoven\WorkSite\8.0\FileSite\Commands\MyMatters\New";
        const string Key_FileSite_MyWorkspaces_32_85 = @"SOFTWARE\Interwoven\WorkSite\8.0\FileSite\Commands\MyWorkspaces\New";



        const string Key_DeskSite_SubscriptionFolder_32_85 = @"SOFTWARE\Interwoven\WorkSite\8.0\DeskSite\Commands\Popup Menus\SubscriptionFolder\New";
        const string Key_DeskSite_MyWorkspace_32_85 = @"SOFTWARE\Interwoven\WorkSite\8.0\DeskSite\Commands\Popup Menus\MyWorkSpaces";
        const string Key_DeskSite_Database_32_85 = @"SOFTWARE\Interwoven\WorkSite\8.0\DeskSite\Commands\Popup Menus\Database\New";

        const string Key_Browse_SubscriptionFolder_32_85 = @"SOFTWARE\Interwoven\WorkSite\8.0\iManExt\Browse Dialog\Popup Menus\SubscriptionFolder\New";
        const string Key_Browse_MyWorkspace_32_85 = @"SOFTWARE\Interwoven\WorkSite\8.0\iManExt\Browse Dialog\Popup Menus\MyWorkSpaces";
        const string Key_Browse_Database_32_85 = @"SOFTWARE\Interwoven\WorkSite\8.0\iManExt\Browse Dialog\Popup Menus\Database\New";

        const string Key_EAI_SubscriptionFolder_32_85 = @"SOFTWARE\Interwoven\WorkSite\8.0\iManExt\Enhanced Integration Dialog\Popup Menus\SubscriptionFolder\New";
        const string Key_EAI_MyWorkspace_32_85 = @"SOFTWARE\Interwoven\WorkSite\8.0\iManExt\Enhanced Integration Dialog\Popup Menus\MyWorkSpaces";
        const string Key_EAI_Database_32_85 = @"SOFTWARE\Interwoven\WorkSite\8.0\iManExt\Enhanced Integration Dialog\Popup Menus\Database\New";

        const string Key_iIntegrationDialog_SubscriptionFolder_32_85 = @"SOFTWARE\Interwoven\WorkSite\8.0\iIntegrationDlg\Commands\TreePopupMenu\SubscriptionFolder\New";
        const string Key_iIntegrationDialog_MyWorkspace_32_85 = @"SOFTWARE\Interwoven\WorkSite\8.0\iIntegrationDlg\Commands\TreePopupMenu\MyWorkSpaces";


        // ********** For 64-bit Machines - 8.5

        const string Key_FileSite_MyMatters_64_85 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\8.0\FileSite\Commands\MyMatters\New";
        const string Key_FileSite_MyWorkspaces_64_85 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\8.0\FileSite\Commands\MyWorkspaces\New";



        const string Key_DeskSite_SubscriptionFolder_64_85 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\8.0\DeskSite\Commands\Popup Menus\SubscriptionFolder\New";
        const string Key_DeskSite_MyWorkspace_64_85 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\8.0\DeskSite\Commands\Popup Menus\MyWorkSpaces";
        const string Key_DeskSite_Database_64_85 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\8.0\DeskSite\Commands\Popup Menus\Database\New";

        const string Key_Browse_SubscriptionFolder_64_85 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\8.0\iManExt\Browse Dialog\Popup Menus\SubscriptionFolder\New";
        const string Key_Browse_MyWorkspace_64_85 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\8.0\iManExt\Browse Dialog\Popup Menus\MyWorkSpaces";
        const string Key_Browse_Database_64_85 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\8.0\iManExt\Browse Dialog\Popup Menus\Database\New";

        const string Key_EAI_SubscriptionFolder_64_85 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\8.0\iManExt\Enhanced Integration Dialog\Popup Menus\SubscriptionFolder\New";
        const string Key_EAI_MyWorkspace_64_85 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\8.0\iManExt\Enhanced Integration Dialog\Popup Menus\MyWorkSpaces";
        const string Key_EAI_Database_64_85 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\8.0\iManExt\Enhanced Integration Dialog\Popup Menus\Database\New";

        const string Key_iIntegrationDialog_SubscriptionFolder_64_85 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\8.0\iIntegrationDlg\Commands\TreePopupMenu\SubscriptionFolder\New";
        const string Key_iIntegrationDialog_MyWorkspace_64_85 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\8.0\iIntegrationDlg\Commands\TreePopupMenu\MyWorkSpaces";
       

        private void button1_Click(object sender, EventArgs e)
        {
            string WSVer_OSBit = string.Empty;
            try
            {
                
                //NT-58503- 8.0 and 9.0 , 9.0 should take priority
                if (KeyExists(WorkSite_90_32, true))
                    WSVer_OSBit = "90 32";
                else if (KeyExists(WorkSite_90_64, false))
                    WSVer_OSBit = "90 64";
                else if (KeyExists(WorkSite_85_32, true))
                    WSVer_OSBit = "85 32";
                else if (KeyExists(WorkSite_85_64, false))
                    WSVer_OSBit = "85 64";


                if (WSVer_OSBit.Trim().Length == 0)
                {
                    
                    return ;
                }


                if (WSVer_OSBit == "85 32")
                {


                    //---------------------
                    //--FOR 32-bit MACHINES  Version 8.5
                    //---------------------
                    //---------------------Cmd_AdHocWorkspace 

                    //Filesite
                    if (!CommandExists(Key_FileSite_MyMatters_32_85, Cmd_AdHocWorkspace, true))
                        ReplaceCommands(Key_FileSite_MyMatters_32_85, Cmd_FileSite, Cmd_AdHocWorkspace, true);
                    if (!CommandExists(Key_FileSite_MyWorkspaces_32_85, Cmd_AdHocWorkspace, true))
                        ReplaceCommands(Key_FileSite_MyWorkspaces_32_85, Cmd_FileSite, Cmd_AdHocWorkspace, true);
                    

                    //Desksite
                    if (!CommandExists(Key_DeskSite_SubscriptionFolder_32_85, Cmd_AdHocWorkspace, true))
                        ReplaceCommands(Key_DeskSite_SubscriptionFolder_32_85, Cmd_Desksite, Cmd_AdHocWorkspace, true);
                    if (!CommandExists(Key_DeskSite_Database_32_85, Cmd_AdHocWorkspace, true))
                        ReplaceCommands(Key_DeskSite_Database_32_85, Cmd_Desksite, Cmd_AdHocWorkspace, true);
                    if (!CommandExists(Key_DeskSite_MyWorkspace_32_85, Cmd_AdHocWorkspace, true))
                        ReplaceCommands(Key_DeskSite_MyWorkspace_32_85, Cmd_Desksite, Cmd_AdHocWorkspace, true);
                    
                    //Browse dialog
                    if (!CommandExists(Key_Browse_SubscriptionFolder_32_85, Cmd_AdHocWorkspace, true))
                        ReplaceCommands(Key_Browse_SubscriptionFolder_32_85, Cmd_Browse_EAI, Cmd_AdHocWorkspace, true);
                    if (!CommandExists(Key_Browse_MyWorkspace_32_85, Cmd_AdHocWorkspace, true))
                        ReplaceCommands(Key_Browse_MyWorkspace_32_85, Cmd_Normal_EAI, Cmd_AdHocWorkspace, true);
                    if (!CommandExists(Key_Browse_Database_32_85, Cmd_AdHocWorkspace, true))
                        ReplaceCommands(Key_Browse_Database_32_85, Cmd_Normal_EAI, Cmd_AdHocWorkspace, true);
                    
                    //EAI dialog
                    if (!CommandExists(Key_EAI_SubscriptionFolder_32_85, Cmd_AdHocWorkspace, true))
                        ReplaceCommands(Key_EAI_SubscriptionFolder_32_85, Cmd_Browse_EAI, Cmd_AdHocWorkspace, true);
                    if (!CommandExists(Key_EAI_MyWorkspace_32_85, Cmd_AdHocWorkspace, true))
                        ReplaceCommands(Key_EAI_MyWorkspace_32_85, Cmd_Normal_EAI, Cmd_AdHocWorkspace, true);
                    if (!CommandExists(Key_EAI_Database_32_85, Cmd_AdHocWorkspace, true))
                        ReplaceCommands(Key_EAI_Database_32_85, Cmd_Normal_EAI, Cmd_AdHocWorkspace, true);
                    

                    //iIntegration Dialog
                    if (!CommandExists(Key_iIntegrationDialog_SubscriptionFolder_32_85, Cmd_AdHocWorkspace, true))
                        ReplaceCommands(Key_iIntegrationDialog_SubscriptionFolder_32_85, Cmd_Desksite, Cmd_AdHocWorkspace, true);
                    if (!CommandExists(Key_iIntegrationDialog_MyWorkspace_32_85, Cmd_AdHocWorkspace, true))
                        ReplaceCommands(Key_iIntegrationDialog_MyWorkspace_32_85, Cmd_Normal_EAI, Cmd_AdHocWorkspace, true);
                    




                }


                else if (WSVer_OSBit == "85 64")
                {

                    //---------------------
                    //--FOR 64-bit MACHINES
                    //---------------------
                    //Filesite
                    if (!CommandExists(Key_FileSite_MyMatters_64_85, Cmd_AdHocWorkspace, false))
                        ReplaceCommands(Key_FileSite_MyMatters_64_85, Cmd_FileSite, Cmd_AdHocWorkspace, false);
                    if (!CommandExists(Key_FileSite_MyWorkspaces_64_85, Cmd_AdHocWorkspace, false))
                        ReplaceCommands(Key_FileSite_MyWorkspaces_64_85, Cmd_FileSite, Cmd_AdHocWorkspace, false);
                    

                    //Desksite
                    if (!CommandExists(Key_DeskSite_SubscriptionFolder_64_85, Cmd_AdHocWorkspace, false))
                        ReplaceCommands(Key_DeskSite_SubscriptionFolder_64_85, Cmd_Desksite, Cmd_AdHocWorkspace, false);
                    if (!CommandExists(Key_DeskSite_MyWorkspace_64_85, Cmd_AdHocWorkspace, false))
                        ReplaceCommands(Key_DeskSite_MyWorkspace_64_85, Cmd_Desksite, Cmd_AdHocWorkspace, false);
                    if (!CommandExists(Key_DeskSite_Database_64_85, Cmd_AdHocWorkspace, false))
                        ReplaceCommands(Key_DeskSite_Database_64_85, Cmd_Desksite, Cmd_AdHocWorkspace, false);
                    

                    //Browse dialog
                    if (!CommandExists(Key_Browse_SubscriptionFolder_64_85, Cmd_AdHocWorkspace, false))
                        ReplaceCommands(Key_Browse_SubscriptionFolder_64_85, Cmd_Browse_EAI, Cmd_AdHocWorkspace, false);
                    if (!CommandExists(Key_Browse_MyWorkspace_64_85, Cmd_AdHocWorkspace, false))
                        ReplaceCommands(Key_Browse_MyWorkspace_64_85, Cmd_Normal_EAI, Cmd_AdHocWorkspace, false);
                    if (!CommandExists(Key_Browse_Database_64_85, Cmd_AdHocWorkspace, false))
                        ReplaceCommands(Key_Browse_Database_64_85, Cmd_Normal_EAI, Cmd_AdHocWorkspace, false);
                    

                    //EAI dialog
                    if (!CommandExists(Key_EAI_SubscriptionFolder_64_85, Cmd_AdHocWorkspace, false))
                        ReplaceCommands(Key_EAI_SubscriptionFolder_64_85, Cmd_Browse_EAI, Cmd_AdHocWorkspace, false);
                    if (!CommandExists(Key_EAI_MyWorkspace_64_85, Cmd_AdHocWorkspace, false))
                        ReplaceCommands(Key_EAI_MyWorkspace_64_85, Cmd_Normal_EAI, Cmd_AdHocWorkspace, false);
                    if (!CommandExists(Key_EAI_Database_64_85, Cmd_AdHocWorkspace, false))
                        ReplaceCommands(Key_EAI_Database_64_85, Cmd_Normal_EAI, Cmd_AdHocWorkspace, false);
                    

                    //iIntegration Dialog
                    if (!CommandExists(Key_iIntegrationDialog_SubscriptionFolder_64_85, Cmd_AdHocWorkspace, false))
                        ReplaceCommands(Key_iIntegrationDialog_SubscriptionFolder_64_85, Cmd_Desksite, Cmd_AdHocWorkspace, false);
                    if (!CommandExists(Key_iIntegrationDialog_MyWorkspace_64_85, Cmd_AdHocWorkspace, false))
                        ReplaceCommands(Key_iIntegrationDialog_MyWorkspace_64_85, Cmd_Normal_EAI, Cmd_AdHocWorkspace, false);
                    

                }


                else if (WSVer_OSBit == "90 32")
                {


                    //---------------------
                    //--FOR 32-bit MACHINES  Version 9.0
                    //---------------------
                    //Filesite
                    if (!CommandExists(Key_FileSite_MyMatters_32_90, Cmd_AdHocWorkspace, true))
                        ReplaceCommands(Key_FileSite_MyMatters_32_90, Cmd_FileSite, Cmd_AdHocWorkspace, true);
                    if (!CommandExists(Key_FileSite_MyWorkspaces_32_90, Cmd_AdHocWorkspace, true))
                        ReplaceCommands(Key_FileSite_MyWorkspaces_32_90, Cmd_FileSite, Cmd_AdHocWorkspace, true);
                    

                    //Desksite
                    if (!CommandExists(Key_DeskSite_SubscriptionFolder_32_90, Cmd_AdHocWorkspace, true))
                        ReplaceCommands(Key_DeskSite_SubscriptionFolder_32_90, Cmd_Desksite, Cmd_AdHocWorkspace, true);
                    if (!CommandExists(Key_DeskSite_Database_32_90, Cmd_AdHocWorkspace, true))
                        ReplaceCommands(Key_DeskSite_Database_32_90, Cmd_Desksite, Cmd_AdHocWorkspace, true);
                    if (!CommandExists(Key_DeskSite_MyWorkspace_32_90, Cmd_AdHocWorkspace, true))
                        ReplaceCommands(Key_DeskSite_MyWorkspace_32_90, Cmd_Normal_EAI, Cmd_AdHocWorkspace, true);
                    

                    //Browse dialog
                    if (!CommandExists(Key_Browse_SubscriptionFolder_32_90, Cmd_AdHocWorkspace, true))
                        ReplaceCommands(Key_Browse_SubscriptionFolder_32_90, Cmd_Browse_EAI, Cmd_AdHocWorkspace, true);
                    if (!CommandExists(Key_Browse_MyWorkspace_32_90, Cmd_AdHocWorkspace, true))
                        ReplaceCommands(Key_Browse_MyWorkspace_32_90, Cmd_Normal_EAI, Cmd_AdHocWorkspace, true);
                    if (!CommandExists(Key_Browse_Database_32_90, Cmd_AdHocWorkspace, true))
                        ReplaceCommands(Key_Browse_Database_32_90, Cmd_Normal_EAI, Cmd_AdHocWorkspace, true);
                    

                    //EAI
                    //Browse dialog
                    if (!CommandExists(Key_EAI_SubscriptionFolder_32_90, Cmd_AdHocWorkspace, true))
                        ReplaceCommands(Key_EAI_SubscriptionFolder_32_90, Cmd_Browse_EAI, Cmd_AdHocWorkspace, true);
                    if (!CommandExists(Key_EAI_MyWorkspace_32_90, Cmd_AdHocWorkspace, true))
                        ReplaceCommands(Key_EAI_MyWorkspace_32_90, Cmd_Normal_EAI, Cmd_AdHocWorkspace, true);
                    if (!CommandExists(Key_EAI_Database_32_90, Cmd_AdHocWorkspace, true))
                        ReplaceCommands(Key_EAI_Database_32_90, Cmd_Normal_EAI, Cmd_AdHocWorkspace, true);
                    

                    //iIntegration Dialog
                    if (!CommandExists(Key_iIntegrationDialog_SubscriptionFolder_32_90, Cmd_AdHocWorkspace, true))
                        ReplaceCommands(Key_iIntegrationDialog_SubscriptionFolder_32_90, Cmd_Desksite, Cmd_AdHocWorkspace, true);
                    if (!CommandExists(Key_iIntegrationDialog_MyWorkspace_32_90, Cmd_AdHocWorkspace, true))
                        ReplaceCommands(Key_iIntegrationDialog_MyWorkspace_32_90, Cmd_Normal_EAI, Cmd_AdHocWorkspace, true);
                    

                }


                else if (WSVer_OSBit == "90 64")
                {


                    //---------------------
                    //--FOR 64-bit MACHINES
                    //---------------------
                    //Filesite
                    if (!CommandExists(Key_FileSite_MyMatters_64_90, Cmd_AdHocWorkspace, false))
                        ReplaceCommands(Key_FileSite_MyMatters_64_90, Cmd_FileSite, Cmd_AdHocWorkspace, false);
                    if (!CommandExists(Key_FileSite_MyWorkspaces_64_90, Cmd_AdHocWorkspace, false))
                        ReplaceCommands(Key_FileSite_MyWorkspaces_64_90, Cmd_FileSite, Cmd_AdHocWorkspace, false);
                    

                    if (!CommandExists(Key_DeskSite_SubscriptionFolder_64_90, Cmd_AdHocWorkspace, false))
                        ReplaceCommands(Key_DeskSite_SubscriptionFolder_64_90, Cmd_Desksite, Cmd_AdHocWorkspace, false);
                    if (!CommandExists(Key_DeskSite_Database_64_90, Cmd_AdHocWorkspace, false))
                        ReplaceCommands(Key_DeskSite_Database_64_90, Cmd_Desksite, Cmd_AdHocWorkspace, false);
                    if (!CommandExists(Key_DeskSite_MyWorkspace_64_90, Cmd_AdHocWorkspace, false))
                        ReplaceCommands(Key_DeskSite_MyWorkspace_64_90, Cmd_Normal_EAI, Cmd_AdHocWorkspace, false);

                    

                    //Browse dialog
                    if (!CommandExists(Key_Browse_SubscriptionFolder_64_90, Cmd_AdHocWorkspace, false))
                        ReplaceCommands(Key_Browse_SubscriptionFolder_64_90, Cmd_Browse_EAI, Cmd_AdHocWorkspace, false);
                    if (!CommandExists(Key_Browse_MyWorkspace_64_90, Cmd_AdHocWorkspace, false))
                        ReplaceCommands(Key_Browse_MyWorkspace_64_90, Cmd_Normal_EAI, Cmd_AdHocWorkspace, false);
                    if (!CommandExists(Key_Browse_Database_64_90, Cmd_AdHocWorkspace, false))
                        ReplaceCommands(Key_Browse_Database_64_90, Cmd_Desksite, Cmd_AdHocWorkspace, false);

                    
                    //EAI dialog
                    if (!CommandExists(Key_EAI_SubscriptionFolder_64_90, Cmd_AdHocWorkspace, false))
                        ReplaceCommands(Key_EAI_SubscriptionFolder_64_90, Cmd_Browse_EAI, Cmd_AdHocWorkspace, false);
                    if (!CommandExists(Key_EAI_MyWorkspace_64_90, Cmd_AdHocWorkspace, false))
                        ReplaceCommands(Key_EAI_MyWorkspace_64_90, Cmd_Normal_EAI, Cmd_AdHocWorkspace, false);
                    if (!CommandExists(Key_EAI_Database_64_90, Cmd_AdHocWorkspace, false))
                        ReplaceCommands(Key_EAI_Database_64_90, Cmd_Normal_EAI, Cmd_AdHocWorkspace, false);

                    
                    //iIntegration Dialog
                    if (!CommandExists(Key_iIntegrationDialog_SubscriptionFolder_64_90, Cmd_AdHocWorkspace, false))
                        ReplaceCommands(Key_iIntegrationDialog_SubscriptionFolder_64_90, Cmd_Desksite, Cmd_AdHocWorkspace, false);
                    if (!CommandExists(Key_iIntegrationDialog_MyWorkspace_64_90, Cmd_AdHocWorkspace, false))
                        ReplaceCommands(Key_iIntegrationDialog_MyWorkspace_64_90, Cmd_Normal_EAI, Cmd_AdHocWorkspace, false);
                    


                    

                }
                

            }
            catch (Exception ex)
            {

            }
            

        }
        private static bool CommandExists(string key, string cmd, bool b64)
        {
            bool bExists = false;
            RegistryKey regKey = null;
            RegistryKey hklm = null;
            try
            {
                if (b64)
                {
                    hklm = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64);
                    regKey = hklm.OpenSubKey(key);
                }
                else
                {
                    hklm = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry32);
                    regKey = hklm.OpenSubKey(key);
                }

                if (regKey != null)
                {
                    object objVal = regKey.GetValue("Commands");
                    if (objVal != null)
                    {
                        string strVal = objVal as string;
                        if (strVal != null && strVal.Length > 0)
                        {
                            if (strVal.Contains(cmd))
                                bExists = true;
                        }
                    }
                }
            }
            finally
            {
                if (hklm != null)
                    hklm.Close();
                if (regKey != null)
                    regKey.Close();
            }
            return bExists;

        }
        private static void ReplaceCommands(string key, string Cmd1, string Cmd2, bool b64)
        {
            RegistryKey regKey = null;
            RegistryKey hklm = null;
            try
            {

                if (b64)
                {
                    hklm = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64);
                    regKey = hklm.OpenSubKey(key, true);
                }
                else
                {
                    hklm = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry32);
                    regKey = hklm.OpenSubKey(key, true);
                }

                if (regKey != null)
                {
                    object objVal = regKey.GetValue("Commands");
                    if (objVal != null)
                    {
                        string strVal = objVal as string;
                        if (strVal != null && strVal.Length > 0)
                        {
                            string replacedCommand = strVal.Replace(Cmd1, Cmd2);
                            regKey.SetValue("Commands", replacedCommand);
                        }

                    }
                }
            }
            finally
            {
                if (hklm != null)
                    hklm.Close();
                if (regKey != null)
                    regKey.Close();

            }
        }
        public static bool KeyExists(string key, bool bHive)
        {
            bool bExists = false;
            RegistryKey regKey = null;
            RegistryKey hklm = null;

            if (bHive)
            {
                hklm = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64);
                regKey = hklm.OpenSubKey(key);
            }
            else
            {
                hklm = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry32);
                regKey = hklm.OpenSubKey(key);
            }
            if (regKey != null)
            {

                object objVal = regKey.GetValue("path");
                if (objVal != null)
                    bExists = true;
                regKey.Close();
            }
            if (hklm != null)
                hklm.Close();
            return bExists;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string WSVer_OSBit = string.Empty;
            try
            {
                
                if (KeyExists(WorkSite_85_32, true))
                    WSVer_OSBit = "85 32";
                else if (KeyExists(WorkSite_85_64, false))
                    WSVer_OSBit = "85 64";
                else if (KeyExists(WorkSite_90_32, true))
                    WSVer_OSBit = "90 32";
                else if (KeyExists(WorkSite_90_64, false))
                    WSVer_OSBit = "90 64";
                if (WSVer_OSBit.Trim().Length == 0)
                {
                    
                    return;
                }


                if (WSVer_OSBit == "85 32")
                {


                    //---------------------
                    //--FOR 32-bit MACHINES  Version 8.5
                    //---------------------
                    //---------------------
                    //Filesite
                    if (!CommandExists(Key_FileSite_MyMatters_32_85, Cmd_FileSite, true))
                        ReplaceCommands(Key_FileSite_MyMatters_32_85, Cmd_AdHocWorkspace, Cmd_FileSite, true);
                    if (!CommandExists(Key_FileSite_MyWorkspaces_32_85, Cmd_FileSite, true))
                        ReplaceCommands(Key_FileSite_MyWorkspaces_32_85, Cmd_AdHocWorkspace, Cmd_FileSite, true);
                    

                    //Desksite
                    if (!CommandExists(Key_DeskSite_SubscriptionFolder_32_85, Cmd_Desksite, true))
                        ReplaceCommands(Key_DeskSite_SubscriptionFolder_32_85, Cmd_AdHocWorkspace, Cmd_Desksite, true);
                    if (!CommandExists(Key_DeskSite_MyWorkspace_32_85, Cmd_Desksite, true))
                        ReplaceCommands(Key_DeskSite_MyWorkspace_32_85, Cmd_AdHocWorkspace, Cmd_Desksite, true);
                    if (!CommandExists(Key_DeskSite_Database_32_85, Cmd_Desksite, true))
                        ReplaceCommands(Key_DeskSite_Database_32_85, Cmd_AdHocWorkspace, Cmd_Desksite, true);
                    

                    //Browse dialog

                    if (!CommandExists(Key_Browse_SubscriptionFolder_32_85, Cmd_Browse_EAI, true))
                        ReplaceCommands(Key_Browse_SubscriptionFolder_32_85, Cmd_AdHocWorkspace, Cmd_Browse_EAI, true);
                    if (!CommandExists(Key_Browse_MyWorkspace_32_85, Cmd_Normal_EAI, true))
                        ReplaceCommands(Key_Browse_MyWorkspace_32_85, Cmd_AdHocWorkspace, Cmd_Normal_EAI, true);
                    if (!CommandExists(Key_Browse_Database_32_85, Cmd_Normal_EAI, true))
                        ReplaceCommands(Key_Browse_Database_32_85, Cmd_AdHocWorkspace, Cmd_Normal_EAI, true);
                    

                    //EAI dialog

                    if (!CommandExists(Key_EAI_SubscriptionFolder_32_85, Cmd_Browse_EAI, true))
                        ReplaceCommands(Key_EAI_SubscriptionFolder_32_85, Cmd_AdHocWorkspace, Cmd_Browse_EAI, true);
                    if (!CommandExists(Key_EAI_MyWorkspace_32_85, Cmd_Normal_EAI, true))
                        ReplaceCommands(Key_EAI_MyWorkspace_32_85, Cmd_AdHocWorkspace, Cmd_Normal_EAI, true);
                    if (!CommandExists(Key_EAI_Database_32_85, Cmd_Normal_EAI, true))
                        ReplaceCommands(Key_EAI_Database_32_85, Cmd_AdHocWorkspace, Cmd_Normal_EAI, true);
                    


                    //iIntegration dialog

                    if (!CommandExists(Key_iIntegrationDialog_SubscriptionFolder_32_85, Cmd_Desksite, true))
                        ReplaceCommands(Key_iIntegrationDialog_SubscriptionFolder_32_85, Cmd_AdHocWorkspace, Cmd_Desksite, true);
                    if (!CommandExists(Key_iIntegrationDialog_MyWorkspace_32_85, Cmd_Normal_EAI, true))
                        ReplaceCommands(Key_iIntegrationDialog_MyWorkspace_32_85, Cmd_AdHocWorkspace, Cmd_Normal_EAI, true);

                    
                }


                else if (WSVer_OSBit == "85 64")
                {

                    //Filesite
                    if (!CommandExists(Key_FileSite_MyMatters_64_85, Cmd_FileSite, false))
                        ReplaceCommands(Key_FileSite_MyMatters_64_85, Cmd_AdHocWorkspace, Cmd_FileSite, false);
                    if (!CommandExists(Key_FileSite_MyWorkspaces_64_85, Cmd_FileSite, false))
                        ReplaceCommands(Key_FileSite_MyWorkspaces_64_85, Cmd_AdHocWorkspace, Cmd_FileSite, false);
                    

                    //Desksite
                    if (!CommandExists(Key_DeskSite_SubscriptionFolder_64_85, Cmd_Desksite, false))
                        ReplaceCommands(Key_DeskSite_SubscriptionFolder_64_85, Cmd_AdHocWorkspace, Cmd_Desksite, false);
                    if (!CommandExists(Key_DeskSite_MyWorkspace_64_85, Cmd_Desksite, false))
                        ReplaceCommands(Key_DeskSite_MyWorkspace_64_85, Cmd_AdHocWorkspace, Cmd_Desksite, false);
                    if (!CommandExists(Key_DeskSite_Database_64_85, Cmd_Desksite, false))
                        ReplaceCommands(Key_DeskSite_Database_64_85, Cmd_AdHocWorkspace, Cmd_Desksite, false);
                    

                    //Browse dialog

                    if (!CommandExists(Key_Browse_SubscriptionFolder_64_85, Cmd_Browse_EAI, false))
                        ReplaceCommands(Key_Browse_SubscriptionFolder_64_85, Cmd_AdHocWorkspace, Cmd_Browse_EAI, false);
                    if (!CommandExists(Key_Browse_MyWorkspace_64_85, Cmd_Normal_EAI, false))
                        ReplaceCommands(Key_Browse_MyWorkspace_64_85, Cmd_AdHocWorkspace, Cmd_Normal_EAI, false);
                    if (!CommandExists(Key_Browse_Database_64_85, Cmd_Normal_EAI, false))
                        ReplaceCommands(Key_Browse_Database_64_85, Cmd_AdHocWorkspace, Cmd_Normal_EAI, false);
                    

                    //EAI dialog

                    if (!CommandExists(Key_EAI_SubscriptionFolder_64_85, Cmd_Browse_EAI, false))
                        ReplaceCommands(Key_EAI_SubscriptionFolder_64_85, Cmd_AdHocWorkspace, Cmd_Browse_EAI, false);
                    if (!CommandExists(Key_EAI_MyWorkspace_64_85, Cmd_Normal_EAI, false))
                        ReplaceCommands(Key_EAI_MyWorkspace_64_85, Cmd_AdHocWorkspace, Cmd_Normal_EAI, false);
                    if (!CommandExists(Key_EAI_Database_64_85, Cmd_Normal_EAI, false))
                        ReplaceCommands(Key_EAI_Database_64_85, Cmd_AdHocWorkspace, Cmd_Normal_EAI, false);
                    


                    //iIntegration dialog

                    if (!CommandExists(Key_iIntegrationDialog_SubscriptionFolder_64_85, Cmd_Desksite, false))
                        ReplaceCommands(Key_iIntegrationDialog_SubscriptionFolder_64_85, Cmd_AdHocWorkspace, Cmd_Desksite, false);
                    if (!CommandExists(Key_iIntegrationDialog_MyWorkspace_64_85, Cmd_Normal_EAI, false))
                        ReplaceCommands(Key_iIntegrationDialog_MyWorkspace_64_85, Cmd_AdHocWorkspace, Cmd_Normal_EAI, false);

                    

                    

                }


                else if (WSVer_OSBit == "90 32")
                {


                    //---------------------
                    //--FOR 32-bit MACHINES  Version 9.0
                    //---------------------




                    //Filesite
                    if (!CommandExists(Key_FileSite_MyMatters_32_90, Cmd_FileSite, true))
                        ReplaceCommands(Key_FileSite_MyMatters_32_90, Cmd_AdHocWorkspace, Cmd_FileSite, true);
                    if (!CommandExists(Key_FileSite_MyWorkspaces_32_90, Cmd_FileSite, true))
                        ReplaceCommands(Key_FileSite_MyWorkspaces_32_90, Cmd_AdHocWorkspace, Cmd_FileSite, true);
                    

                    //Desksite
                    if (!CommandExists(Key_DeskSite_SubscriptionFolder_32_90, Cmd_Desksite, true))
                        ReplaceCommands(Key_DeskSite_SubscriptionFolder_32_90, Cmd_AdHocWorkspace, Cmd_Desksite, true);
                    if (!CommandExists(Key_DeskSite_MyWorkspace_32_90, Cmd_Desksite, true))
                        ReplaceCommands(Key_DeskSite_MyWorkspace_32_90, Cmd_AdHocWorkspace, Cmd_Desksite, true);
                    if (!CommandExists(Key_DeskSite_Database_32_90, Cmd_Desksite, true))
                        ReplaceCommands(Key_DeskSite_Database_32_90, Cmd_AdHocWorkspace, Cmd_Desksite, true);
                    

                    //Browse dialog

                    if (!CommandExists(Key_Browse_SubscriptionFolder_32_90, Cmd_Browse_EAI, true))
                        ReplaceCommands(Key_Browse_SubscriptionFolder_32_90, Cmd_AdHocWorkspace, Cmd_Browse_EAI, true);
                    if (!CommandExists(Key_Browse_MyWorkspace_32_90, Cmd_Normal_EAI, true))
                        ReplaceCommands(Key_Browse_MyWorkspace_32_90, Cmd_AdHocWorkspace, Cmd_Normal_EAI, true);
                    if (!CommandExists(Key_Browse_Database_32_90, Cmd_Normal_EAI, true))
                        ReplaceCommands(Key_Browse_Database_32_90, Cmd_AdHocWorkspace, Cmd_Normal_EAI, true);
                    

                    //EAI dialog

                    if (!CommandExists(Key_EAI_SubscriptionFolder_32_90, Cmd_Browse_EAI, true))
                        ReplaceCommands(Key_EAI_SubscriptionFolder_32_90, Cmd_AdHocWorkspace, Cmd_Browse_EAI, true);
                    if (!CommandExists(Key_EAI_MyWorkspace_32_90, Cmd_Normal_EAI, true))
                        ReplaceCommands(Key_EAI_MyWorkspace_32_90, Cmd_AdHocWorkspace, Cmd_Normal_EAI, true);
                    if (!CommandExists(Key_EAI_Database_32_90, Cmd_Normal_EAI, true))
                        ReplaceCommands(Key_EAI_Database_32_90, Cmd_AdHocWorkspace, Cmd_Normal_EAI, true);
                    


                    //iIntegration dialog

                    if (!CommandExists(Key_iIntegrationDialog_SubscriptionFolder_32_90, Cmd_Desksite, true))
                        ReplaceCommands(Key_iIntegrationDialog_SubscriptionFolder_32_90, Cmd_AdHocWorkspace, Cmd_Desksite, true);
                    if (!CommandExists(Key_iIntegrationDialog_MyWorkspace_32_90, Cmd_Normal_EAI, true))
                        ReplaceCommands(Key_iIntegrationDialog_MyWorkspace_32_90, Cmd_AdHocWorkspace, Cmd_Normal_EAI, true);

                    


                    


                }


                else if (WSVer_OSBit == "90 64")
                {


                    //---------------------
                    //--FOR 64-bit MACHINES
                    //---------------------
                    //Filesite
                    if (!CommandExists(Key_FileSite_MyMatters_64_90, Cmd_FileSite, false))
                        ReplaceCommands(Key_FileSite_MyMatters_64_90, Cmd_AdHocWorkspace, Cmd_FileSite, false);
                    if (!CommandExists(Key_FileSite_MyWorkspaces_64_90, Cmd_FileSite, false))
                        ReplaceCommands(Key_FileSite_MyWorkspaces_64_90, Cmd_AdHocWorkspace, Cmd_FileSite, false);
                    

                    //Desksite
                    if (!CommandExists(Key_DeskSite_SubscriptionFolder_64_90, Cmd_Desksite, false))
                        ReplaceCommands(Key_DeskSite_SubscriptionFolder_64_90, Cmd_AdHocWorkspace, Cmd_Desksite, false);
                    if (!CommandExists(Key_DeskSite_MyWorkspace_64_90, Cmd_Desksite, false))
                        ReplaceCommands(Key_DeskSite_MyWorkspace_64_90, Cmd_AdHocWorkspace, Cmd_Desksite, false);
                    if (!CommandExists(Key_DeskSite_Database_64_90, Cmd_Desksite, false))
                        ReplaceCommands(Key_DeskSite_Database_64_90, Cmd_AdHocWorkspace, Cmd_Desksite, false);
                    

                    //Browse dialog

                    if (!CommandExists(Key_Browse_SubscriptionFolder_64_90, Cmd_Browse_EAI, false))
                        ReplaceCommands(Key_Browse_SubscriptionFolder_64_90, Cmd_AdHocWorkspace, Cmd_Browse_EAI, false);
                    if (!CommandExists(Key_Browse_MyWorkspace_64_90, Cmd_Normal_EAI, false))
                        ReplaceCommands(Key_Browse_MyWorkspace_64_90, Cmd_AdHocWorkspace, Cmd_Normal_EAI, false);
                    if (!CommandExists(Key_Browse_Database_64_90, Cmd_Normal_EAI, false))
                        ReplaceCommands(Key_Browse_Database_64_90, Cmd_AdHocWorkspace, Cmd_Normal_EAI, false);
                    

                    //EAI dialog

                    if (!CommandExists(Key_EAI_SubscriptionFolder_64_90, Cmd_Browse_EAI, false))
                        ReplaceCommands(Key_EAI_SubscriptionFolder_64_90, Cmd_AdHocWorkspace, Cmd_Browse_EAI, false);
                    if (!CommandExists(Key_EAI_MyWorkspace_64_90, Cmd_Normal_EAI, false))
                        ReplaceCommands(Key_EAI_MyWorkspace_64_90, Cmd_AdHocWorkspace, Cmd_Normal_EAI, false);
                    if (!CommandExists(Key_EAI_Database_64_90, Cmd_Normal_EAI, false))
                        ReplaceCommands(Key_EAI_Database_64_90, Cmd_AdHocWorkspace, Cmd_Normal_EAI, false);
                    


                    //iIntegration dialog

                    if (!CommandExists(Key_iIntegrationDialog_SubscriptionFolder_64_90, Cmd_Desksite, false))
                        ReplaceCommands(Key_iIntegrationDialog_SubscriptionFolder_64_90, Cmd_AdHocWorkspace, Cmd_Desksite, false);
                    if (!CommandExists(Key_iIntegrationDialog_MyWorkspace_64_90, Cmd_Normal_EAI, false))
                        ReplaceCommands(Key_iIntegrationDialog_MyWorkspace_64_90, Cmd_AdHocWorkspace, Cmd_Normal_EAI, false);

                    

                }

            }
            catch (Exception ex)
            {

            }
            
            
        }
    }
}
