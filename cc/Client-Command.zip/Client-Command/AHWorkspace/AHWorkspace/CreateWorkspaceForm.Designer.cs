﻿namespace AHWorkspace
{
    partial class CreateWorkspaceForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CreateWorkspaceForm));
            this.brwsCreateWorkspace = new System.Windows.Forms.WebBrowser();
            this.SuspendLayout();
            // 
            // brwsCreateWorkspace
            // 
            this.brwsCreateWorkspace.Dock = System.Windows.Forms.DockStyle.Fill;
            this.brwsCreateWorkspace.Location = new System.Drawing.Point(0, 0);
            this.brwsCreateWorkspace.MinimumSize = new System.Drawing.Size(20, 20);
            this.brwsCreateWorkspace.Name = "brwsCreateWorkspace";
            this.brwsCreateWorkspace.Size = new System.Drawing.Size(534, 571);
            this.brwsCreateWorkspace.TabIndex = 0;
            // 
            // CreateWorkspaceForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(534, 571);
            this.Controls.Add(this.brwsCreateWorkspace);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Location = new System.Drawing.Point(10, 10);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "CreateWorkspaceForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Create a Workspace";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CreateWorkspaceForm_FormClosing);
            this.Load += new System.EventHandler(this.CreateWorkspaceForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.WebBrowser brwsCreateWorkspace;
    }
}