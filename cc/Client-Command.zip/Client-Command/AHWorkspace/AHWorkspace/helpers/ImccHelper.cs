﻿using Interop.iManExt;
using Com.Interwoven.WorkSite;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Text;
using System.Collections;



namespace AHWorkspace.helpers
{
    public class ImccHelper
    {
        
        public ImccHelper()
        {
        }

        public object GetContextItemVal(ContextItems Context,string value)
        {
            object objVal = null;
            try
            {
               objVal = Context.Item(value);

            }
            catch
            {

            }
            return objVal;
        }

        public string GetIMCCURL(ContextItems Context)
        {
            LogHelper.Log(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Trying to get Host Url:Method Name:GetIMCCURL ");



            IManSession session = GetIManSession(Context);
            

            if (session != null)
            {
                IManFolder fld = session.Databases.ItemByIndex(1).GetFolder(5);
                IManAdditionalProperty additional;
                if (session != null)
                {

                    additional = session.ConfigurationData.ItemByName("IMCC_HOSTURL");
                    if (additional != null)
                    {
                        LogHelper.Log(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Host Url:" + additional.Value);

                        return additional.Value;
                    }

                }
                else
                {
                    LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "IManSessions is Not Avilable null");

                }
            }

            return "";
        }

         

        public string getWorkspaceCreateUrl(ContextItems Context)
        {
            if (Context != null)
            {
                string url = GetIMCCURL(Context) + "adhocws/#/workspace/create" + GetQueryString(Context);
                
                LogHelper.Log(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, url); 
          
                return url;
            }
            else 
            {
                LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "getApplyTemplateUrl returning EMPTY since ContextItems is null");

                return ""; 
            
            }
        }

        public IManSession GetIManSession(ContextItems Context)
        {
            IManSession session = null;
            object objSession = GetContextItemVal(Context, "SelectedIManSession");

            if(objSession != null)
            {
                session = objSession as IManSession;
                return session;
            }
            object[] objSessions = GetContextItemVal(Context, "SelectedNRTSessions") as object[];
            if(objSessions != null  && objSessions.Length > 0)
            {
                session = objSessions[0] as IManSession;
                return session;
            }

            IManDMS dms = GetDMSObject(Context);
            if(dms !=null && dms.Sessions != null && dms.Sessions.Count > 0 )
            {
                session = dms.Sessions.ItemByIndex(1) as IManSession;
            }
            return session;

        }

        public IManDMS GetDMSObject(ContextItems Context)
        {
            IManDMS dms = null;
            object objDMS = GetContextItemVal(Context, "NRTDMS");
            if(objDMS !=null)
            {
                dms = objDMS as IManDMS;
                return dms;
            }
            objDMS = GetContextItemVal(Context, "IMANDMS");
            if (objDMS != null)
            {
                dms = objDMS as IManDMS;
                return dms;
            }
            return dms;
        }

        public string GetQueryString(ContextItems Context)
        {
            string qryString = "?protocol=external";
           
            try
            {
                ContextItems cont = Context;
                
                
                IManSession session = GetIManSession(Context);
                IManDatabase db = null;
                object objDB = GetContextItemVal(Context, "DestinationObject");
                if (objDB != null)
                {
                    db = objDB as IManDatabase;
                }
              
                
                if (db != null)
                {
                    qryString += "&dbname=" + db.Name;
                }
                if (session != null)
                {
                    qryString += "&userid=" + session.UserID;
                    qryString += "&server=" + session.ServerName;
                }



            }
            catch (Exception ex)
            {
                LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, ex.Message);


            }
            return qryString;
        }

        

      

       



        

        

       
        


        
    }
}
