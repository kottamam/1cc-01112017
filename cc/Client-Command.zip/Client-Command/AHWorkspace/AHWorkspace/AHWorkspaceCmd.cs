﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using Com.Interwoven.WorkSite;
using Interop.iManExt2;
using System.Diagnostics;
using Microsoft.Win32;
using System.Windows.Forms;
using System.Net;
using System.IO;
using Interop.iManExt;
using System.Drawing;
using AHWorkspace.helpers;

namespace AHWorkspace
{
    [Guid("75D05ABE-F44F-4F22-84AC-7601428AA3FD")]
    [ProgId("IManage.AdHocWorkspaceCmd")]
    public class AHWorkspaceCmd:ICommand
    {
        private int mAccelerator;
        private object mBitmap;
        private ContextItems mContext;
        private string mHelpFile;
        private int mHelpID;
        private string mHelpText;
        private string mMenuText;
        private string mName;
        private int mOptions;
        private int mStatus;
        private Commands mSubCommands;
        private string mTitle;
        private CommandType mType;
        private const int tempVirtKey = 65536;
        private const int tempNoInvert = 131072;
        private const int tempShift = 262144;
        private const int tempControl = 524288;
        private const int tempAlt = 1048576;

        [DllImport("user32.dll", SetLastError = false)]
        static extern IntPtr GetDesktopWindow();
        public AHWorkspaceCmd()
        {

            try
            {
                LogHelper.SetupLogger();
                Name = IManResources.IDS_COMMAND_NAME;
                Title = IManResources.IDS_COMMAND_TITLE;

                Type = CommandType.nrStandardCommand;

                Status = (int)CommandStatus.nrDisabledCommand;

                MenuText = IManResources.IDS_COMMAND_TITLE;

                HelpText = IManResources.IDS_COMMAND_HELPTEXT;



                Byte[] encodedBytes = Encoding.ASCII.GetBytes("W");
                Accelerator = encodedBytes[0] + tempVirtKey + tempControl;

                System.Drawing.Bitmap bm = AHWorkspace.IManResources.workspace;
                System.IntPtr bp = bm.GetHbitmap();
                Bitmap = bp;

            }
            catch
            {
                // Do not throw exception
            }

        }
        public int Accelerator
        {
            get
            {
                return mAccelerator;
            }
            set
            {
                mAccelerator = value;
            }
        }

        public object Bitmap
        {
            get
            {
                return mBitmap;
            }
            set
            {
                mBitmap = value;
            }
        }

        public ContextItems Context
        {
            get { return mContext; }
        }

        public void Execute()
        {
            try
            {
                ImccHelper helper = new ImccHelper();
                IManSession session = helper.GetIManSession(Context);
                if (session == null)
                    return;
              

                ImccHelper helperClass = new ImccHelper();
                CreateWorkspaceForm createForm = new CreateWorkspaceForm(helperClass.GetIMCCURL(Context), Context);
                if (createForm.IsLoggedIn)
                {
                    createForm.WindowState = FormWindowState.Normal;
                    
                    createForm.ShowDialog();
                }
            }
            catch(Exception ex)
            {
                
            }


        }
       

        public string HelpFile
        {
            get
            {
                return mHelpFile;
            }
            set
            {
                mHelpFile = value;
            }
        }

        public int HelpID
        {
            get
            {
                return mHelpID;
            }
            set
            {
                mHelpID = value;
            }
        }

        public string HelpText
        {
            get
            {
                return mHelpText;
            }
            set
            {
                mHelpText = value;
            }
        }
        IManNewWorkspaceCmdClass newWorkpaceCmd = new IManNewWorkspaceCmdClass();
        IMANEXTLib.ContextItems cntItems = new IMANEXTLib.ContextItems();
        public void Initialize(ContextItems Context)
        {
            mContext = Context;
            cntItems = (IMANEXTLib.ContextItems)Context;
            newWorkpaceCmd.Initialize(cntItems);
        }

        public string MenuText
        {
            get
            {
                return mMenuText;
            }
            set
            {
                mMenuText = value;
            }
        }

        public string Name
        {
            get
            {
                return mName;
            }
            set
            {
                mName = value;
            }
        }

        public int Options
        {
            get
            {
                return mOptions;
            }
            set
            {
                mOptions = value;
            }
        }

        public int Status
        {
            get
            {
                return mStatus;
            }
            set
            {
                mStatus = value;
            }
        }

        public Commands SubCommands
        {
            get
            {
                return mSubCommands;
            }
            set
            {
                mSubCommands = value;
            }
        }

        public string Title
        {
            get
            {
                return mTitle;
            }
            set
            {
                mTitle = value;
            }
        }

        public CommandType Type
        {
            get
            {
                return mType;
            }
            set
            {
                mType = value;
            }
        }

        public void Update()
        {

            ImccHelper helperClass = new ImccHelper();
            string strIMCCURL = helperClass.GetIMCCURL(Context);
            if (strIMCCURL == null || strIMCCURL.Trim().Length == 0)
            {
                Status = (int)CommandStatus.nrGrayedCommand;
            }
            else
            {
                newWorkpaceCmd.Update();



                Status = newWorkpaceCmd.Status;
            }
            
        }
    }
}
