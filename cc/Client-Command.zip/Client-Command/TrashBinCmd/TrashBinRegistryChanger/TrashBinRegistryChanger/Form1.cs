﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32;

namespace TrashBinRegistryChanger
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        const string WorkSite_90_64 = @"SOFTWARE\Interwoven\Worksite\Client\Common\InstallRoot";
        const string WorkSite_90_32 = @"SOFTWARE\Wow6432Node\Interwoven\Worksite\Client\Common\InstallRoot";
        const string Filesite_90_64 = @"SOFTWARE\Interwoven\WorkSite\Client\FileSite\Commands\ToolBarWithEMM";
        const string Filesite_90_32 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\Client\FileSite\Commands\ToolBarWithEMM";

        const string Filesite_90_64_iManageMenu = @"SOFTWARE\Interwoven\WorkSite\Client\FileSite\Commands\iManageMenu";
        const string Filesite_90_32_iManageMenu = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\Client\FileSite\Commands\iManageMenu";
        const string Desksite_90_64 = @"SOFTWARE\Interwoven\WorkSite\Client\DeskSite\Commands\Menus\Content";
        const string Desksite_90_32 = @"SOFTWARE\Wow6432Node\Interwoven\WorkSite\Client\DeskSite\Commands\Menus\Content";
        const string Cmd_TrashBin = "IManage.TrashBinCmd";

        public static bool KeyExists(string key, bool bHive,string bitness)
        {
            bool bExists = false;
            RegistryKey regKey = null;
            RegistryKey hklm = null;

            if (bHive)
            {
                hklm = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64);
                regKey = hklm.OpenSubKey(key);
            }
            else
            {
                hklm = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry32);
                regKey = hklm.OpenSubKey(key);
            }
            if (regKey != null)
            {

                object objVal = regKey.GetValue("bitness");
                if (objVal != null && objVal.ToString().ToLower() ==bitness.ToLower())
                    bExists = true;
                regKey.Close();
            }
            if (hklm != null)
                hklm.Close();
            return bExists;

        }
        private void button1_Click(object sender, EventArgs e)
        {
            string WSVer_OSBit = string.Empty;
            try
            {
                if (KeyExists(WorkSite_90_64, true,"x64"))
                    WSVer_OSBit = "90 64";
                else if (KeyExists(WorkSite_90_32, false,"x86"))
                    WSVer_OSBit = "90 32";
                if(WSVer_OSBit == "90 64")
                {
                    //Use filesite_90_64 and use true for hive
                    ChangeFilesiteRegistry(true);
                    ChangeDesksiteRegistry(true);
                }
                else if(WSVer_OSBit == "90 32")
                {
                    //Use filesite_90_32 and use FALSE for hive
                    ChangeFilesiteRegistry(false);
                    ChangeDesksiteRegistry(false);
                }



            }
            catch
            {

            }

        }
        public void ChangeDesksiteRegistry(bool bHive)
        {
            RegistryKey regKey = null;
            RegistryKey hklm = null;
            
            try
            {

                if (bHive)
                {
                    hklm = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64);
                    regKey = hklm.OpenSubKey(Desksite_90_64, true);
                }
                else
                {
                    hklm = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry32);
                    regKey = hklm.OpenSubKey(Desksite_90_32, true);
                }
                if (regKey == null)
                    return;



                object objExistingValue = regKey.GetValue("Commands");
                if (objExistingValue != null && objExistingValue.ToString().Length > 0)
                {
                    string strExist = objExistingValue.ToString();
                    if (!strExist.Contains(Cmd_TrashBin))
                    {
                        strExist += ",-,";
                        strExist += Cmd_TrashBin;
                        regKey.SetValue("Commands", strExist);
                    }
                }
                else
                {
                    regKey.SetValue("Commands", Cmd_TrashBin);
                }


            }
            catch
            {

            }
            finally
            {
               
                if (regKey != null)
                    regKey.Close();
                if (hklm != null)
                    hklm.Close();
            }

        }
        public void ChangeFilesiteRegistry(bool bHive)
        {
            RegistryKey regKey = null;
            RegistryKey hklm = null;
            RegistryKey documentsKey = null;
            RegistryKey hklmIManage = null;
            RegistryKey regKeyIManage = null;
            try
            {

                if (bHive)
                {
                    hklm = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64);
                    regKey = hklm.OpenSubKey(Filesite_90_64, true);
                }
                else
                {
                    hklm = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry32);
                    regKey = hklm.OpenSubKey(Filesite_90_32, true);
                }
                if (regKey == null)
                    return;
                //Changing ToolBarWithEMM
                string[] existingSubKeys = regKey.GetSubKeyNames();


                

                object objExistingValue = regKey.GetValue("Commands");
                if (objExistingValue != null && objExistingValue.ToString().Length > 0)
                {
                    string strExist = objExistingValue.ToString();
                    if (!strExist.Contains(Cmd_TrashBin))
                    {
                        strExist += ",";
                        strExist += Cmd_TrashBin;
                        regKey.SetValue("Commands", strExist);
                    }
                }
                else
                {
                    string strExist = objExistingValue.ToString();

                    if (!strExist.Contains(Cmd_TrashBin))
                    {
                        regKey.SetValue("Commands", Cmd_TrashBin);
                    }
                }

                //Change in iManageMenu
                if (bHive)
                {
                    hklmIManage = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64);
                    regKeyIManage = hklmIManage.OpenSubKey(Filesite_90_64_iManageMenu, true);
                }
                else
                {
                    hklmIManage = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry32);
                    regKeyIManage = hklmIManage.OpenSubKey(Filesite_90_32_iManageMenu, true);
                }
                if (regKeyIManage == null)
                    return;
                string[] strKeys = regKeyIManage.GetSubKeyNames();
                if (!Exists(strKeys, "Documents"))
                    documentsKey = regKeyIManage.CreateSubKey("Documents");
                else
                    documentsKey = regKeyIManage.OpenSubKey("Documents", true);

                object objCommands = documentsKey.GetValue("Commands");
                if(objCommands != null && objCommands.ToString().Length > 0)
                {
                    string strEx = objCommands.ToString();
                    if (!strEx.Contains(Cmd_TrashBin))
                    {
                        strEx += ",";
                        strEx += Cmd_TrashBin;
                        documentsKey.SetValue("Commands", strEx);
                    }
                }
                else
                {
                    documentsKey.SetValue("Commands", Cmd_TrashBin);
                }
                CreateDocumentsInAppropriatePlace(regKeyIManage);


            }
            catch
            {

            }
            finally
            {
                if (documentsKey != null)
                    documentsKey.Close();
                if (regKeyIManage != null)
                    regKeyIManage.Close();
                if (hklmIManage != null)
                    hklmIManage.Close();
                if (regKey != null)
                    regKey.Close();
                if (hklm != null)
                    hklm.Close();
            }

        }

        private void CreateDocumentsInAppropriatePlace(RegistryKey regKeyIManage)
        {
            try
            {
                object objCOmmands  = regKeyIManage.GetValue("Commands");
                if(objCOmmands  == null || objCOmmands.ToString().Length ==0)
                {
                    //Case of 0
                    regKeyIManage.SetValue("Commands", "Documents");
                }
                else
                {
                    string strExt = objCOmmands.ToString();
                    char [] CommaChar = {','};
                    string[] strCommands = strExt.Split(CommaChar,StringSplitOptions.RemoveEmptyEntries);
                    if(!Exists(strCommands,"Documents"))
                    {
                        bool bLayoutFound = false;
                        if(Exists(strCommands,"Layout"))
                        {
                            string strNewCommands = string.Empty;  
                            foreach(string strEx in strCommands)
                            {
                                if(strEx == "Layout")
                                {
                                    strNewCommands += "Documents";
                                    strNewCommands += ",";
                                    strNewCommands += "Layout";
                                    strNewCommands += ",";
                                    bLayoutFound = true;
                                }
                                else
                                {
                                    strNewCommands += strEx;
                                    strNewCommands += ",";
                                }
                            }
                            strNewCommands = strNewCommands.Trim(CommaChar);
                            if(bLayoutFound)
                            {
                                regKeyIManage.SetValue("Commands", strNewCommands);

                            }
                        }
                        if(!bLayoutFound)
                        {
                            if (strCommands.Length >= 3)
                            {
                                

                                List<string> lstCommands = strCommands.ToList();
                                int lstLength = lstCommands.Count();
                                int index = lstLength - 3;
                                lstCommands.Insert(index, "Documents");
                                string strNewCommands = string.Empty;
                                for (int i = 0; i < lstCommands.Count(); i++)
                                {
                                    strNewCommands += lstCommands[i];
                                    strNewCommands += ",";

                                }
                                strNewCommands = strNewCommands.Trim(CommaChar);

                                regKeyIManage.SetValue("Commands", strNewCommands);


                            }
                            else
                            {
                                string strNewCommands = "Documents";
                                strNewCommands += ",";
                                foreach(string strCommand in strCommands)
                                {
                                    strNewCommands += strCommand;
                                    strNewCommands += ",";
                                }
                                strNewCommands = strNewCommands.Trim(CommaChar);

                                regKeyIManage.SetValue("Commands", strNewCommands);

                            }

                        }

                    }
                }

            }
            catch
            {

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
             string WSVer_OSBit = string.Empty;
             try
             {
                 if (KeyExists(WorkSite_90_64, true, "x64"))
                     WSVer_OSBit = "90 64";
                 else if (KeyExists(WorkSite_90_32, false, "x86"))
                     WSVer_OSBit = "90 32";
                 if (WSVer_OSBit == "90 64")
                 {
                     UnregisterFilesiteRegistry(true);
                     UnregisterDesksiteRegistry(true);
                 }
                 else if (WSVer_OSBit == "90 32")
                 {
                     UnregisterFilesiteRegistry(false);
                     UnregisterDesksiteRegistry(false);
                 }
             }
            catch
             {

             }
            

        }

        private void UnregisterDesksiteRegistry(bool bHive)
        {
            RegistryKey regKey = null;
            RegistryKey hklm = null;

            try
            {

                if (bHive)
                {
                    hklm = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64);
                    regKey = hklm.OpenSubKey(Desksite_90_64, true);
                }
                else
                {
                    hklm = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry32);
                    regKey = hklm.OpenSubKey(Desksite_90_32, true);
                }
                if (regKey == null)
                    return;
              



                object objExistingValue = regKey.GetValue("Commands");
                if (objExistingValue != null && objExistingValue.ToString().Length > 0)
                {
                    string strExist = objExistingValue.ToString();
                    string finalCommands = string.Empty;
                    char[] splitChar = { ',' };
                    string[] indCommands = strExist.Split(splitChar, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string indCommand in indCommands)
                    {
                        if (indCommand.ToLower() != Cmd_TrashBin.ToLower())
                        {
                            finalCommands += indCommand;
                            finalCommands += ",";
                        }
                    }
                    char[] trimVal = { ',', '-' };
                    finalCommands = finalCommands.Trim(trimVal);
                    regKey.SetValue("Commands", finalCommands);
                }



            }
            catch
            {

            }
            finally
            {

                if (regKey != null)
                    regKey.Close();
                if (hklm != null)
                    hklm.Close();
            }
        }

        private void UnregisterFilesiteRegistry(bool bHive)
        {
            RegistryKey regKey = null;
            RegistryKey hklm = null;
            RegistryKey documentsKey = null;
            RegistryKey hklmIManage = null;
            RegistryKey regKeyIManage = null;
            
            try
            {

                if (bHive)
                {
                    hklm = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64);
                    regKey = hklm.OpenSubKey(Filesite_90_64, true);
                }
                else
                {
                    hklm = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry32);
                    regKey = hklm.OpenSubKey(Filesite_90_32, true);
                }
                if (regKey == null)
                    return;
               


                //For EMMToolbar
                object objExistingValue = regKey.GetValue("Commands");
                if (objExistingValue != null && objExistingValue.ToString().Length > 0)
                {
                    string strExist = objExistingValue.ToString();
                    string finalCommands = string.Empty;
                    char[] splitChar = { ',' };
                    string[]indCommands = strExist.Split(splitChar, StringSplitOptions.RemoveEmptyEntries);
                    
                    foreach(string indCommand in indCommands)
                    {
                        if(indCommand.ToLower() != Cmd_TrashBin.ToLower())
                        {
                            finalCommands += indCommand;
                            finalCommands += ",";
                        }
                    }
                    finalCommands = finalCommands.Trim(splitChar);
                    regKey.SetValue("Commands", finalCommands);
                }
                
                //For iManage menu
                if (bHive)
                {
                    hklmIManage = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64);
                    regKeyIManage = hklmIManage.OpenSubKey(Filesite_90_64_iManageMenu, true);
                }
                else
                {
                    hklmIManage = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry32);
                    regKeyIManage = hklmIManage.OpenSubKey(Filesite_90_32_iManageMenu, true);
                }
                if (regKeyIManage == null)
                    return;
                string[] subKeynames = regKeyIManage.GetSubKeyNames();
                if (Exists(subKeynames, "Documents"))
                    regKeyIManage.DeleteSubKey("Documents");

                object objVal = regKeyIManage.GetValue("Commands");
                if(objVal != null && objVal.ToString().Length > 0)
                {
                     string strExt = objVal.ToString();
                    char [] CommaChar = {','};
                    string[] strCommands = strExt.Split(CommaChar,StringSplitOptions.RemoveEmptyEntries);
                    if (Exists(strCommands, "Documents"))
                    {

                        string strNewCommands = string.Empty;
                        foreach (string strEx in strCommands)
                        {
                            if (strEx != "Documents")
                            {
                                strNewCommands += strEx;
                                strNewCommands += ",";
                            }
                           
                        }
                        strNewCommands = strNewCommands.Trim(CommaChar);
                        regKeyIManage.SetValue("Commands", strNewCommands);
                    }
                }
            }
            catch
            {

            }
            finally
            {

                if (documentsKey != null)
                    documentsKey.Close();
                if (regKeyIManage != null)
                    regKeyIManage.Close();
                if (hklmIManage != null)
                    hklmIManage.Close();
                if (regKey != null)
                    regKey.Close();
                if (hklm != null)
                    hklm.Close();
            }
        }

        private static bool Exists(string[] existingSubKeys, string findKey)
        {
            bool bExists = false;
            foreach (string strKey in existingSubKeys)
            {
                if (strKey.Trim().ToLower() == findKey.Trim().ToLower())
                {
                    bExists = true;
                    break;
                }
            }
            return bExists;
        }
    }
}
