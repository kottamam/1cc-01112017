﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using Com.Interwoven.WorkSite;
using Interop.iManExt2;
using System.Diagnostics;
using Microsoft.Win32;
using System.Windows.Forms;
using System.Net;
using System.IO;
using TrashBinCmd.helpers;
using Interop.iManExt;

using System.Drawing;

namespace TrashBinCmd
{
    [Guid("36BCC5B0-66A8-46B3-A9DA-A50A610E8E0B")]
    [ProgId("IManage.TrashBinCmd")]
    public class TrashBin:ICommand,ICommand2
    {
        private int mAccelerator;
        private object mBitmap;
        private ContextItems mContext;
        private string mHelpFile;
        private int mHelpID;
        private string mHelpText;
        private string mMenuText;
        private string mName;
        private int mOptions;
        private int mStatus;
        private Commands mSubCommands;
        private string mTitle;
        private CommandType mType;
        private const int tempVirtKey = 65536;
        private const int tempNoInvert = 131072;
        private const int tempShift = 262144;
        private const int tempControl = 524288;
        private string textLabel = "Trash Bin";
        private object largeBitmap = null;
        public TrashBin()
        {
            try
            {
                LogHelper.SetupLogger();
                Name = Resource1.IDS_TRASHBIN_COMMANDNAME;
                Title = Resource1.IDS_TRASHBIN_COMMANDTITLE;

                Type = CommandType.nrStandardCommand;

                Status = (int)CommandStatus.nrActiveCommand;

                MenuText = Resource1.IDS_TRASHBIN_COMMANDTITLE;

                HelpText = Resource1.IDS_TRASHBIN_COMMANDTITLE;



               /*Byte[] encodedBytes = Encoding.ASCII.GetBytes("F");
                Accelerator = encodedBytes[0] + tempVirtKey + tempControl;*/

                //Icon to see
                System.Drawing.Bitmap bm = Resource1.Trash.ToBitmap();
                System.IntPtr bp = bm.GetHbitmap();
                Bitmap = bp;
                largeBitmap = bp;

            }
            catch
            {
                // Do not throw exception
            }
        }

        public int Accelerator
        {

            get
            {
                return mAccelerator;
            }
            set
            {
                mAccelerator = value;
            }
        }

        public object Bitmap
        {
            get
            {
                return mBitmap;
            }
            set
            {
                mBitmap = value;
            }
        }

        public ContextItems Context
        {
            get { return mContext; }
        }

        public void Execute()
        {
            TrashbinForm tbForm = new TrashbinForm(mContext);
            if (tbForm.LoggedIn)
            {
                tbForm.WindowState = FormWindowState.Normal;
                tbForm.ShowDialog();
            }
            
        }

        public string HelpFile
        {
            get
            {
                return mHelpFile;
            }
            set
            {
                mHelpFile = value;
            }
        }

        public int HelpID
        {
             get
            {
                return mHelpID;
            }
            set
            {
                mHelpID = value;
            }
        
        }

        public string HelpText
        {
            get
            {
                return mHelpText;
            }
            set
            {
                mHelpText = value;
            }
        }

        public void Initialize(ContextItems Context)
        {
            mContext = Context;
           
            
         
        }

        public string MenuText
        {
            get
            {
                return mMenuText;
            }
            set
            {
                mMenuText = value;
            }
        }

        public string Name
        {
            get
            {
                return mName;
            }
            set
            {
                mName = value;
            }
        }

        public int Options
        {
            get
            {
                return mOptions;
            }
            set
            {
                mOptions = value;
            }
        }

        public int Status
        {
            get
            {
                return mStatus;
            }
            set
            {
                mStatus = value;
            }
        }

        public Commands SubCommands
        {
            get
            {
                return mSubCommands;
            }
            set
            {
                mSubCommands = value;
            }
        }

        public string Title
        {
            get
            {
                return mTitle;
            }
            set
            {
                mTitle = value;
            }
        }

        public CommandType Type
        {
            get
            {
                return mType;
            }
            set
            {
                mType = value;
            }
        }

        public void Update()
        {
            helpers.ImccHelper helper = new ImccHelper();
            IManSession session = helper.GetIManSession(mContext);
            if (session == null)
            {
                Status = (int)CommandStatus.nrGrayedCommand;
                return;
            }
            IManAdditionalProperty addProperty = session.ConfigurationData.ItemByName("Enable Trash");
            if (addProperty == null)
            {

                Status = (int)CommandStatus.nrGrayedCommand;
                return;
            }

            if (addProperty != null && addProperty.Value == "Y")
            {
                Status = (int)CommandStatus.nrActiveCommand;
                return;

            }
            else
            {
                Status = (int)CommandStatus.nrGrayedCommand;
                return;

            }
            
        }

        public object LargeBitmap
        {
            get
            {
                return largeBitmap;
            }
            set
            {
                largeBitmap = value;
            }
        }

        public string TextLabel
        {
            get
            {
                return textLabel;
            }
            set
            {
                textLabel = value;
            }
        }
    }
}
