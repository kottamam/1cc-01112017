﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Com.Interwoven.WorkSite;
using Interop.iManExt;
using Interop.iManExt2;
using System.Net;
using System.IO;
using System.Web.Script.Serialization;
using Microsoft.Win32;
using TrashBinCmd.helpers;
using System.Diagnostics;
using Interop.iwSingleton;
using PositionLibrary;

namespace TrashBinCmd
{
    [ComVisible(true)]
    public partial class TrashbinForm : Form
    {
       
        public ContextItems mContext { get; set; }
        public string propSate { get; set; }
        public imObjectType ObjectType { get; set; }
        [DllImport("user32.dll")]
        static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, int dwExtraInfo);

        PositionLibrary.FormPositionSaver position = new FormPositionSaver("Trash Bin");

        public TrashbinForm()
        {
            InitializeComponent();
        }

        
        public bool LoggedIn
        {
            get { return _loginHelper._bLoggedIn; }
        }
        
        private ImccHelper _helper = new ImccHelper();
        private CommonLoginHelper _loginHelper = new CommonLoginHelper();
        public TrashbinForm(ContextItems Context)
        {
            
            try
            {
                


              
              
                this.mContext = Context;

                _helper.SetBrowserFeatureControl(Process.GetCurrentProcess().MainModule.FileName);
                InitializeComponent();
                this.CenterToParent();
                this.Top = 60;

                

                tbBrowserCtrl.ObjectForScripting = this;

                _loginHelper.NavigateToAppropriatePage(tbBrowserCtrl, mContext);
                
              
               
                

            }
            catch (Exception ex)
            {
                

            }
        }

     
        
        


        public void closeWindow()
        {
            try
            {
                
                this.Close();
            }
            catch (Exception ex)
            {
                LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "closeWindow():" + ex.Message);
            }
        }

        public void resizeWindow(string widthHeight)
        {
            string[] widHie = widthHeight.Split(';');

            this.Size = new Size(Convert.ToInt32(widHie[0]), Convert.ToInt32(widHie[1]));
            this.CenterToParent();
            this.Top = 60;
        }

        private void TrashbinForm_Load(object sender, EventArgs e)
        {
            Point location = new Point(0, 0);
            Size size = new Size(1063, 861);
            bool bLocFound = false;
            bool bSizeFound = false;
            position.GetPosition(ref location, ref size, ref bLocFound, ref bSizeFound);

            if (bLocFound)
            {
                this.StartPosition = FormStartPosition.Manual;
                this.Location = location;
            }
            if (bSizeFound)
            {
                this.Size = size;
            }
        }

        private void TrashbinForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            position.SavePosition(this.Location, this.Size);

        }
    }
}
