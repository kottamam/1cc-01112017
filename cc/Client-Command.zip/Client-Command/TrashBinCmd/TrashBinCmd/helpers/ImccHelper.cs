﻿using Interop.iManExt;
using Com.Interwoven.WorkSite;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Text;
using System.Collections;
using System.Runtime.InteropServices;
using System.Net;


namespace TrashBinCmd.helpers
{
    public class ImccHelper
    {
        private const string REG_IMAN_FLDWIZ_FLD_PERMISSIONS = "IMAN_FLDWIZ_FLD_PERMISSIONS";

        
      
        public ImccHelper()
        {
        }

        public object GetContextItemVal(ContextItems Context,string value)
        {
            object objVal = null;
            try
            {
               objVal = Context.Item(value);

            }
            catch
            {

            }
            return objVal;
        }

        public string GetIMCCURL(ContextItems Context)
        {  
            LogHelper.Log(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType ,"Trying to get Host Url:Method Name:GetIMCCURL " ) ;
            object dmsObject = null;
            dmsObject = GetContextItemVal(Context, "IManDMS");
            
            
            IManDMS dms  =null;
            if (dmsObject != null)
                dms = dmsObject as IManDMS;
            else
            {
                object objFolder = GetContextItemVal(Context, "SelectedFolderObject");
                IManFolder folder = null;
                if(objFolder != null)
                {
                    if (objFolder is IManFolderShortcut)
                    {
                        IManFolderShortcut shortCutFolder = objFolder as IManFolderShortcut;
                        if (shortCutFolder != null)
                            folder = shortCutFolder.Resolve();
                    }
                    else
                        folder = objFolder as IManFolder;
                   
                    if(folder != null)
                    {
                        
                        if(folder.Database != null && folder.Database.Session != null)
                            dms  = folder.Database.Session.DMS;
                    }
                }
            }

            if (dms!= null)
            {
                object objFolder = GetContextItemVal(Context, "SelectedFolderObject");
                IManFolder folder = null;
                IManSession session = null;
                if (objFolder != null)
                {
                    if (objFolder is IManFolderShortcut)
                    {
                        IManFolderShortcut shortCutFolder = objFolder as IManFolderShortcut;
                        if(shortCutFolder != null)
                            folder = shortCutFolder.Resolve();
                    }
                    else
                        folder = objFolder as IManFolder;
                    
                   
                    if (folder != null)
                    {
                        if (folder.Database != null)
                            session = folder.Database.Session;
                    }

                }
                IManAdditionalProperty additional;
                if (session != null)
                {

                    additional = session.ConfigurationData.ItemByName("IMCC_HOSTURL");
                    if (additional != null)
                    {
                        LogHelper.Log(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Host Url:" + additional.Value);

                        return additional.Value;
                    }

                }
                else
                {
                    LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "IManSessions is Not Avilable null");

                }
            }
            else
            {
                LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "IManDMS object is getting null"); 

            }
            return "";
        }

        private void SetBrowserFeatureControlKey(string feature, string appName, uint value)
        {
            using (var key = Registry.CurrentUser.CreateSubKey(
                String.Concat(@"Software\Microsoft\Internet Explorer\Main\FeatureControl\", feature),
                RegistryKeyPermissionCheck.ReadWriteSubTree))
            {
                key.SetValue(appName, (UInt32)value, RegistryValueKind.DWord);
            }
        }


        

        public void SetBrowserFeatureControl(string moduleName)
        {
            // http://msdn.microsoft.com/en-us/library/ee330720(v=vs.85).aspx

            // FeatureControl settings are per-process
            var fileName = System.IO.Path.GetFileName(moduleName);

            // make the control is not running inside Visual Studio Designer
            if (String.Compare(fileName, "devenv.exe", true) == 0 || String.Compare(fileName, "XDesProc.exe", true) == 0)
                return;

            SetBrowserFeatureControlKey("FEATURE_BROWSER_EMULATION", fileName, GetBrowserEmulationMode()); // Webpages containing standards-based !DOCTYPE directives are displayed in IE10 Standards mode.
            SetBrowserFeatureControlKey("FEATURE_AJAX_CONNECTIONEVENTS", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_ENABLE_CLIPCHILDREN_OPTIMIZATION", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_MANAGE_SCRIPT_CIRCULAR_REFS", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_DOMSTORAGE ", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_GPU_RENDERING ", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_IVIEWOBJECTDRAW_DMLT9_WITH_GDI  ", fileName, 0);
            SetBrowserFeatureControlKey("FEATURE_DISABLE_LEGACY_COMPRESSION", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_LOCALMACHINE_LOCKDOWN", fileName, 0);
            SetBrowserFeatureControlKey("FEATURE_BLOCK_LMZ_OBJECT", fileName, 0);
            SetBrowserFeatureControlKey("FEATURE_BLOCK_LMZ_SCRIPT", fileName, 0);
            SetBrowserFeatureControlKey("FEATURE_DISABLE_NAVIGATION_SOUNDS", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_SCRIPTURL_MITIGATION", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_SPELLCHECKING", fileName, 0);
            SetBrowserFeatureControlKey("FEATURE_STATUS_BAR_THROTTLING", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_TABBED_BROWSING", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_VALIDATE_NAVIGATE_URL", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_WEBOC_DOCUMENT_ZOOM", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_WEBOC_POPUPMANAGEMENT", fileName, 0);
            SetBrowserFeatureControlKey("FEATURE_WEBOC_MOVESIZECHILD", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_ADDON_MANAGEMENT", fileName, 0);
            SetBrowserFeatureControlKey("FEATURE_WEBSOCKET", fileName, 1);
            SetBrowserFeatureControlKey("FEATURE_WINDOW_RESTRICTIONS ", fileName, 0);
            SetBrowserFeatureControlKey("FEATURE_XMLHTTP", fileName, 1);
        }

        private UInt32 GetBrowserEmulationMode()
        {
            int browserVersion = 7;
            using (var ieKey = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Internet Explorer",
                RegistryKeyPermissionCheck.ReadSubTree,
                System.Security.AccessControl.RegistryRights.QueryValues))
            {
                var version = ieKey.GetValue("svcVersion");
                if (null == version)
                {
                    version = ieKey.GetValue("Version");
                    if (null == version)
                        throw new ApplicationException("Microsoft Internet Explorer is required!");
                }
                int.TryParse(version.ToString().Split('.')[0], out browserVersion);
            }

            UInt32 mode = 11000; // Internet Explorer 11. Webpages containing standards-based !DOCTYPE directives are displayed in IE11 Standards mode. Default value for Internet Explorer 11.
            switch (browserVersion)
            {
                case 7:
                    mode = 7000; // Webpages containing standards-based !DOCTYPE directives are displayed in IE7 Standards mode. Default value for applications hosting the WebBrowser Control.
                    break;
                case 8:
                    mode = 8000; // Webpages containing standards-based !DOCTYPE directives are displayed in IE8 mode. Default value for Internet Explorer 8
                    break;
                case 9:
                    mode = 9000; // Internet Explorer 9. Webpages containing standards-based !DOCTYPE directives are displayed in IE9 mode. Default value for Internet Explorer 9.
                    break;
                case 10:
                    mode = 10000; // Internet Explorer 10. Webpages containing standards-based !DOCTYPE directives are displayed in IE10 mode. Default value for Internet Explorer 10.
                    break;
                default:
                    // use IE11 mode by default
                    break;
            }

            return mode;
        }
       

        public const string g_bstrSelectedNRTSessions = @"SelectedNRTSessions";
        public const string g_bstrSelectedIManSession = @"SelectedIManSession";
        public IManSession GetIManSession(ContextItems _contexts)
        {
            IManSession session = null;
            object[] sessions = null;

            try
            {
                sessions = _contexts.Item(g_bstrSelectedNRTSessions) as object[];
                if (sessions.Length > 0)
                    session = sessions[0] as IManSession;
                else
                    throw new ArgumentNullException(); ;
            }
            catch
            {
                try
                {
                    session = _contexts.Item(g_bstrSelectedIManSession) as IManSession;
                }
                catch
                {
                    IManDMS dms = GetIManDMS(_contexts);

                    if (dms != null && dms.Sessions.Count > 0)
                        session = dms.Sessions.ItemByIndex(1) as IManSession; // zeor based collection
                }
            }

            return session;
        }
        public const string g_bstrNRTDMS = @"NRTDMS";
        public const string g_bstrIMANDMS = @"IMANDMS";
        public IManDMS GetIManDMS(ContextItems _contexts)
        {
            IManDMS dms = null;

            try
            {
                INRTDMS nrtdms = _contexts.Item(g_bstrNRTDMS) as INRTDMS;
                dms = nrtdms as IManDMS;
            }
            catch
            {
                try
                {
                    dms = _contexts.Item(g_bstrIMANDMS) as IManDMS;

                }
                catch
                {
                }
            }

            return dms;
        }

       
        public string GetQueryString(ContextItems Context)
        {
            string qryString = "?";
           // session.ServerName
            try
            {
                IManDatabase db  =  GetDatabase(Context);
                if(db != null)
                    qryString += "dbname=" + db.Name + "&";
                qryString += "protocol=external";
              
            }
            catch (Exception ex)
            {
                LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, ex.Message);


            }
            return qryString;
        }

        private IManDatabase GetDatabase(ContextItems Context)
        {
            IManDatabase dbReturn = null;

            object objDB = GetContextItemVal(Context, "DestinationObject");
            if(objDB != null)
            {
                IManDatabase db = objDB as IManDatabase;
                if(db != null)
                {
                    dbReturn = db;
                    return dbReturn;
                }
            }
            objDB = GetContextItemVal(Context, "IManDestinationObject");
            if (objDB != null)
            {
                IManDatabase db = objDB as IManDatabase;
                if (db != null)
                {
                    dbReturn = db;
                    return dbReturn;
                }
            }


            return dbReturn;
        }

        public int FindObjectLevel(IManFolder folder)
        {
            if (folder != null)
            {
                if (folder.Parent != null && (folder.Parent.ObjectType.ObjectType == imObjectType.imTypeWorkspace || folder.Parent.ObjectType.ObjectType == imObjectType.imTypeWorkspaces))
                    return 1;
                else
                    return 1 + FindObjectLevel(folder.Parent);
            }
            else
            {
                LogHelper.Log(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "FindObjectLevel cannot be find since the folder is empty");
                return -1;
            }
        }

      

        public IManSession GetSession(ContextItems Context)
        {
            IManFolder folder = (IManFolder)Context.Item("SelectedFolderObject");
            if (folder is IManFolderShortcut)
            {
                folder = ((IManFolderShortcut)folder).Resolve();
            }
            if (folder != null)
            {
                return folder.Database.Session;
            }
            else
            {
                LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "IManSession is null");
               
                return null;
            }
        }


        public string GetAppName(ContextItems mContext)
        {
            try
            {
                object obj = mContext.Item("IManExt.AppMode.AppName");
                LogHelper.Log(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "AppName:"+Convert.ToString(obj));

                return Convert.ToString(obj);
            }
            catch (Exception ex)
            {
                LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType,"GetAppName():"+ ex.Message);
                return "";
            }
        }



        internal bool HaveUserRights(ContextItems Context)
        {
            try
            {
                IManFolder folder = (IManFolder)Context.Item("SelectedFolderObject");
                if (folder is IManFolderShortcut)
                {
                    folder = ((IManFolderShortcut)folder).Resolve();
                }
                if ((imAccessRight)folder.EffectiveAccess == imAccessRight.imRightRead || (imAccessRight)folder.EffectiveAccess == imAccessRight.imRightNone)
                {

                    return false;
                }
                else if ((imAccessRight)folder.EffectiveAccess == imAccessRight.imRightReadWrite)
                {
                    imObjectType OType = folder.ObjectType.ObjectType;

                    if (OType == imObjectType.imTypeWorkspace || OType == imObjectType.imTypeWorkspaces)
                        return false;
                    else
                        return true;


                }
                else if ((imAccessRight)folder.EffectiveAccess == imAccessRight.imRightAll)
                {

                    return true;


                }
                else
                {
                    return false;
                }

            }
            catch (Exception ex)
            {

                LogHelper.Error(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, ex.Message);
                return false;

            }
           
        }

        internal bool SpecialPermissions(ContextItems Context)
        {
            try
            {
                IManFolder folder = (IManFolder)Context.Item("SelectedFolderObject");
                if (folder is IManFolderShortcut)
                {
                    folder = ((IManFolderShortcut)folder).Resolve();
                }
                IManWorkspace WSPace;

                if (folder is IManWorkspace)
                {
                    WSPace = (IManWorkspace)folder;
                }
                else
                {
                    WSPace = folder.Workspace;
                }

                IManAdditionalProperties IProps = WSPace.Database.Session.ConfigurationData;
                string Permissions = GetPropertyValue(IProps, REG_IMAN_FLDWIZ_FLD_PERMISSIONS);
                if (!String.IsNullOrEmpty(Permissions))
                {
                    //If Delete Permissions specified, then process accordingly.
                    Permissions = Permissions.ToUpper();
                    ArrayList PermsArray = new ArrayList(Permissions.Split(char.Parse(",")));
                    if (PermsArray.Contains("ACCESS:ALL") &&
                        WSPace.EffectiveAccess == imAccessRight.imRightAll)
                        return true;
                    else if ((PermsArray.Contains("ACCESS:RW") || PermsArray.Contains("ACCESS:READWRITE")) &&
                        (WSPace.EffectiveAccess == imAccessRight.imRightAll || WSPace.EffectiveAccess == imAccessRight.imRightReadWrite))
                        return true;
                    else if ((PermsArray.Contains("ACCESS:R") || PermsArray.Contains("ACCESS:READ")) &&
                        (WSPace.EffectiveAccess == imAccessRight.imRightAll || WSPace.EffectiveAccess == imAccessRight.imRightReadWrite || WSPace.EffectiveAccess == imAccessRight.imRightRead))
                        return true;

                    else if (PermsArray.Contains("SECURITYTYPE:PUBLIC")
                            && WSPace.Security.DefaultVisibility == imSecurityType.imPublic)
                        return true;
                }
            }
            catch (Exception ex)
            {

                LogHelper.Log(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType,ex.Message);

            }
            return false;
        }

        private string GetPropertyValue(IManAdditionalProperties confData, string key)
        {
            //get the string value of the specified key
            string val = string.Empty;
            if (confData.ContainsByName(key))
            {
                val = confData.ItemByName(key).Value;
            }
            return val;
        }

       

        public bool IsFolderPropertiesEnabled(ContextItems Context)
        {
            bool bRet = true;
            string strIMCCURL = GetIMCCURL(Context);
            if (strIMCCURL == null || strIMCCURL.Trim().Length == 0)
                bRet = false;

            object objSelected = GetContextItemVal(Context, "SelectedFolderObject");
            if (objSelected == null)
                bRet = false;

            return bRet;
        }


        
    }
}
