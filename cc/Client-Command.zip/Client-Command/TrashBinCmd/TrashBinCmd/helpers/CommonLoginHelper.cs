﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Interop.iManExt;
using Com.Interwoven.WorkSite;
using System.Runtime.InteropServices;
using System.Net;
using System.Windows.Forms;
using Interop.iwSingleton;
using System.Diagnostics;

namespace TrashBinCmd.helpers
{
    class CommonLoginHelper
    {
        const string COMMON_AUTH_APP_COOKIE = "3CEEF535-CE6A-4C05-BEBC-333A5AC92E2C";
        const string COMMON_AUTH_MUTEX_OBJECT = "5DEB0A5C-E230-478C-B90D-2899D1A18CC0";
        const string CLSID_COMMONAUTH = "E278C076-6F35-48FB-B98D-A0BFD3047915";

        ImccHelper _helper = new ImccHelper();

        private const Int32 InternetCookieHttponly = 0x2000;
        [DllImport("wininet.dll", CharSet = CharSet.Auto, SetLastError = true)]
        static extern bool InternetSetCookieEx(string lpszUrlName, string lpszCookieName, string lpszCookieData, uint dwFlags, IntPtr dwReserved);

        [DllImport("wininet.dll", SetLastError = true)]
        public static extern bool InternetGetCookieEx(
            string url,
            string cookieName,
            StringBuilder cookieData,
            ref int size,
            Int32 dwFlags,
            IntPtr lpReserved);

        [DllImport("user32.dll", SetLastError = true)]
        public static extern bool AllowSetForegroundWindow(uint procId);

        public bool _bLoggedIn = false;

        public void NavigateToAppropriatePage(System.Windows.Forms.WebBrowser tbBrowserCtrl, ContextItems mContext)
        {
            ImccHelper helperclass = new ImccHelper();
            
            string Url = string.Empty;

            IManSession session = _helper.GetIManSession(mContext);

            if (session != null)
            {

                IManAdditionalProperty additional = session.ConfigurationData.ItemByName("IMCC_HOSTURL");
                if (additional != null)
                {
                    LogHelper.Log(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, "Host Url:" + additional.Value);

                    Url = additional.Value;
                }

            }
            if (String.IsNullOrEmpty(Url))
                return;
            System.Uri uri = new Uri(Url);

            //Before navigate
            //check cookie if it exists and set in X-Auth-Token

            string actualHost = uri.AbsoluteUri.Replace(uri.LocalPath, "");
            string imccURL = actualHost;

            string strToken = string.Empty;
            DateTime expiresDateTime = DateTime.MinValue;
            bool bCommonLogin = CommonLogin(imccURL, ref strToken, ref expiresDateTime);

            if (bCommonLogin)
            {

                string authTokenKey = "X-Auth-Token";
                Cookie XauthTokenCookie = new Cookie(authTokenKey, strToken, "/", uri.Host);
                XauthTokenCookie.Expires = expiresDateTime;
                bool bDone = InternetSetCookieEx(imccURL, null, XauthTokenCookie.ToString(), InternetCookieHttponly, IntPtr.Zero);
                string urlTrash = "/dialogs/trash-bin/#/" + _helper.GetQueryString(mContext);
                RedirectToTrashBin(imccURL, urlTrash, tbBrowserCtrl, mContext);
                _bLoggedIn = true;
            }
            else
            {
                MessageBox.Show(Resource1.IDS_LOGIN_FAILED,"Trash Bin");
                _bLoggedIn = false;
            }



        }

        private bool CommonLogin(string imccURL,ref string strToken, ref DateTime expiresDateTime)
        {
            bool bLoggedIn = false;
            try
            {
                using (System.Threading.Semaphore bouncer = new System.Threading.Semaphore(1, 5, COMMON_AUTH_MUTEX_OBJECT)) // common name shared among login agents
                {
                    if (bouncer.WaitOne(0) ||
                        bouncer.WaitOne(60 * 1000))
                    {
                        Type comType = Type.GetTypeFromCLSID(new Guid(CLSID_COMMONAUTH));
                        ICommonAuth auth = Activator.CreateInstance(comType) as ICommonAuth;
                        if (auth == null)
                            return bLoggedIn;
                        auth.AppCookie = COMMON_AUTH_APP_COOKIE;
                        auth.HostUri = imccURL;
                        auth.RestApiVersion = 1;
                        auth.TimeOut = 60;
                        AllowSetForegroundWindow(unchecked((uint)-1));

                        int procId = 0;
                        auth.LOGINTYPE = LOGINTYPE.Auto;
                        auth.AppID = "3CEEF535-CE6A-4C05-BEBC-333A5AC92E2C";
                        strToken = auth.Execute(procId = Process.GetCurrentProcess().Id);
                        if (!String.IsNullOrEmpty(strToken))
                        {
                            bLoggedIn = true;
                            expiresDateTime = auth.TokenExpiry;
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());

            }
            return bLoggedIn;
        }

       
      

        private void RedirectToTrashBin(string imccURL, string Url, System.Windows.Forms.WebBrowser tbBrowserCtrl, ContextItems mContext)
        {
            string URL = imccURL;
            ImccHelper helperclass = new ImccHelper();
            //URL += "/dialogs/trash-bin/#/" + helperclass.GetQueryString(mContext);
            URL += Url;
            tbBrowserCtrl.Navigate(URL);
        }

        

    }
}
