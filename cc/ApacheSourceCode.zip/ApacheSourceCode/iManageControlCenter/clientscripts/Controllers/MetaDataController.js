﻿app.controller("MetaDataController", MetaDataController);
MetaDataController.$inject = ['$scope', '$rootScope', 'MetaDataService', 'metaDataFactory', '$filter', '$timeout', '$mdDialog', '$mdMedia', 'homeFactory', 'CONST_METADATA', '$q'];

function MetaDataController($scope, $rootScope, MetaDataService, metaDataFactory, $filter, $timeout, $mdDialog, $mdMedia, homeFactory, CONST_METADATA, $q) {

	$scope.IsShowSelectedMetaDataDetails = false;
	$scope.selected = [];
	$scope.MetaDataList = [];

	var selectedRowIndex = -1;
	var FilterSearchTimeout;
	var requestModel = homeFactory.requestModelInstance();

	$scope.ShowWarning = false;
	$scope.MetaDataModel = metaDataFactory.meatDataInitialValues();
	$scope.validation = metaDataFactory.validations();
	var noDataExist = false;

	$scope.ContextMenuFunctions = {
		Edit: function () { $scope.PageEvents.Edit(false); },
		SubMetaDataList: function () { $scope.PageEvents.ShowSubMetaDataList(); },
		EnableMetaData: function () { enableSelectedMetaDataItem(); },
		DisableMetaData: function () { disableSelectedMetaDataItem(); },
		EditSubMetaData: function () { $scope.OpenEditSubMetaData(); },
		EnableSubMetaData: function () { enableSubClassItemList(); },
		DisableSubMetaData: function () { disableSubClassItemList(); },
	};

	var ContextMenuVariables = {
		EnableDisable: {
			Label: 'Enable',
			Icon: 'img/icons/delete.svg',
			IconType: 'font-icon',
			onClick: function () {
			},
			IconType: 'font-icon'
		},
		SubMetaDataEnableDisable: {
			Label: 'Enable',
			Icon: 'img/icons/delete.svg',
			IconType: 'font-icon',
			onClick: function () {
			},
			IconType: 'font-icon'
		}
	};
	$timeout(function () {
		$(window).scrollTop(0);
	});
	function setContextMenuObject() {
		$scope.menuList = [];
		ContextMenuVariables.EnableDisable.Label = '';
		ContextMenuVariables.EnableDisable.onClick = 'undefined';
		$scope.PageEvents.Enable = 'undefined';
		$scope.PageEvents.Disable = 'undefined';

		if ($scope.selected && $scope.selected.length === 1) {
			if ($scope.selected[0].EnableFlag) {
				ContextMenuVariables.EnableDisable.Label = 'Disable';
				ContextMenuVariables.EnableDisable.Icon = 'icon-disable';
				ContextMenuVariables.EnableDisable.onClick = $scope.ContextMenuFunctions.DisableMetaData;
				$scope.PageEvents.Enable = 'undefined';
				$scope.PageEvents.Disable = $scope.ContextMenuFunctions.DisableMetaData;
			} else {
				ContextMenuVariables.EnableDisable.Label = 'Enable';
				ContextMenuVariables.EnableDisable.Icon = 'icon-enable';
				ContextMenuVariables.EnableDisable.onClick = $scope.ContextMenuFunctions.EnableMetaData;
				$scope.PageEvents.Enable = $scope.ContextMenuFunctions.EnableMetaData;
				$scope.PageEvents.Disable = 'undefined';
			}
		}
		else if ($scope.selected && $scope.selected.length > 1) {
			var filterList = $filter('filter')($scope.selected, {
				EnableFlag: false
			});
			if (filterList.length === $scope.selected.length) {
				ContextMenuVariables.EnableDisable.Label = 'Enable';
				ContextMenuVariables.EnableDisable.Icon = 'icon-enable';
				ContextMenuVariables.EnableDisable.onClick = $scope.ContextMenuFunctions.EnableMetaData;
				$scope.PageEvents.Enable = $scope.ContextMenuFunctions.EnableMetaData;
				$scope.PageEvents.Disable = 'undefined';
			}
			else {
				filterList = [];
				filterList = $filter('filter')($scope.selected, {
					EnableFlag: true
				});
				if (filterList.length === $scope.selected.length) {
					ContextMenuVariables.EnableDisable.Label = 'Disable';
					ContextMenuVariables.EnableDisable.Icon = 'icon-disable';
					ContextMenuVariables.EnableDisable.onClick = $scope.ContextMenuFunctions.DisableMetaData;
					$scope.PageEvents.Enable = 'undefined';
					$scope.PageEvents.Disable = $scope.ContextMenuFunctions.DisableMetaData;
				}
			}
			filterList = [];
		}
		$scope.menuList = [
			{
				Label: 'Edit',
				Icon: 'icon-edit',
				onClick: $scope.ContextMenuFunctions.Edit,
				Enable: $scope.selected.length === 1 && $scope.appsVar.selectedMetaData !== 'CUSTOM1' && $scope.appsVar.selectedMetaData !== 'CUSTOM29',
				IconType: 'font-icon'
			},
			//{
			//	Label: $scope.appsVar.tooltipValue,
			//	Icon: 'icon-metadata',
			//	onClick: $scope.ContextMenuFunctions.SubMetaDataList,
			//	Enable: $scope.selected.length === 1 && ($scope.appsVar.selectedMetaData == "CUSTOM1" || $scope.appsVar.selectedMetaData == "CUSTOM29"),
			//	IconType: 'font-icon'
			//},
			{
				Label: ContextMenuVariables.EnableDisable.Label,
				Icon: ContextMenuVariables.EnableDisable.Icon,
				onClick: ContextMenuVariables.EnableDisable.Label === '' ? 'undefined' : ContextMenuVariables.EnableDisable.onClick,
				Enable: ContextMenuVariables.EnableDisable.Label !== '',
				IconType: 'font-icon'
			}
		];
	}

	var destroybroadCast;
	RegisterInitializeTabContents();

	$scope.$on('RegisterInitializeTabContents', function () {
		if (angular.isFunction(destroybroadCast))
			destroybroadCast();

		RegisterInitializeTabContents();
	});

	function RegisterInitializeTabContents() {
		destroybroadCast = $scope.$on('InitializeTabContents', function () {
			var selectedAppsName = $filter('filter')($scope.appsVar.CaptionsList, { MetaDataItem: $scope.appsVar.selectedMetaData }, true);
			if (selectedAppsName.length > 0) {
				$scope.vm.selectedApp.CurrentTab = selectedAppsName[0].DisplayText;
			}

			if ($scope.vm.selectedApp.NoAppsPermission.trim().length > 0)
				return;
			if (!$scope.vm.selectedLibrary || $scope.vm.selectedLibrary.trim().length == 0)
				return;

			$scope.IsShowSelectedMetaDataDetails = false;
			$scope.selected = [];
			$scope.MetaDataList = [];

			selectedRowIndex = -1;
			FilterSearchTimeout = null;
			requestModel = homeFactory.requestModelInstance();

			$scope.ShowWarning = false;
			$scope.MetaDataModel = metaDataFactory.meatDataInitialValues();
			$scope.validation = metaDataFactory.validations();
			noDataExist = false;
			SelectedMetaDataListForFilter = [];
			LastAddedSelectedItemMetaData = [];
			lastAppendItemCount = 0;

			Initalize();
			destroybroadCast();
		});
	}

	function Initalize() {
		$scope.selected = [];
		$scope.MetaDataList = [];
		requestModel.pagenumber = 1;
		lastAppendItemCount = 0;
		getMetaDataList($scope.appsVar.selectedMetaData);
	}

	$scope.$on('Window_Scrolled', function () {
		if (!$scope.IsShowSelectedMetaDataDetails) {
			if ($scope.query.totalCount > $scope.MetaDataList.length) {
				requestModel.pagenumber += 1;
				getMetaDataList($scope.appsVar.selectedMetaData);
			}
		}
		else {
			if ($scope.MetaDataView.totalCount > $scope.MetaDataView.SubMatadataList.length) {
				subMetadataReqModel.pagenumber += 1;
				fillSubMetaDataList();
			}
		}
	});

	$scope.PageEvents.ShowOnlySelected = function () {
		$scope.vm.viewSelectedOnlyLabel = $scope.vm.viewSelectedOnlyLabel == 'View selected' ? 'Show all' : 'View selected';
	};

	var SelectedMetaDataListForFilter = [];
	var LastAddedSelectedItemMetaData = [];
	var lastAppendItemCount = 0;

	function getMetaDataList(MetaType) {
		$mdDialog.hide();

		$scope.vm.selectedApp.MetaDataItem = MetaType;
		if (!$scope.vm.selectedLibrary || $scope.vm.selectedLibrary.length == 0) return;

		requestModel.libraryName = $scope.vm.selectedLibrary;
		requestModel.searchText = $scope.appsVar.SearchText;
		requestModel.MetaType = MetaType;

		if (isSearch) {
			showProgressDialog();
			// $scope.showSearchProgress = true;
		}


		var apiUrl = metaDataFactory.getAPIUrl('SEARCHMETADATA', requestModel);
		$scope.mc.getlogDetails("Debug", "Method:GET;URL:" + JSON.stringify(apiUrl));
		lstMetadata = MetaDataService.getMetaDataList(apiUrl, $scope.mc.loginModel.AuthKey);
		lstMetadata.then(function (response) {
			if (response.data && response.status === 200) {
				var tempListFilter = [];
				var metaDataUIModel;
				var filterTempModel;

				$scope.mc.getlogDetails("Debug", 'Response:Success');
				if (lastAppendItemCount > 0) {
					$scope.MetaDataList.splice($scope.MetaDataList.length - lastAppendItemCount, lastAppendItemCount);
					$scope.selected.splice($scope.selected.length - lastAppendItemCount, lastAppendItemCount);
				}

				$scope.query.totalCount = response.data[CONST_METADATA.TotalCount];
				angular.forEach(response.data[CONST_METADATA.MetaDataList], function (metadata) {
					metaDataUIModel = metaDataFactory.getMetaDataUI(metadata);

					if (SelectedMetaDataListForFilter.length === 0) {
						$scope.MetaDataList.push(metaDataUIModel);
					}
					else {
						tempListFilter = $filter('filter')(SelectedMetaDataListForFilter, {
							Alias: metaDataUIModel.Alias
						}, true);
						if (tempListFilter.length === 0) {
							$scope.MetaDataList.push(metaDataUIModel);
						}
						else {
							LastAddedSelectedItemMetaData = $.grep(LastAddedSelectedItemMetaData,
							   function (item, index) {
								   return item.Alias != metaDataUIModel.Alias;
							   });

							tempListFilter[0].Description = metaDataUIModel.Description;
							tempListFilter[0].HIPAAComplaint = metaDataUIModel.HIPAAComplaint;
							tempListFilter[0].EnableFlag = metaDataUIModel.EnableFlag;
							tempListFilter[0].ParentAlias = metaDataUIModel.ParentAlias;
							tempListFilter[0].GrandParentAlias = metaDataUIModel.GrandParentAlias;

							filterTempModel = angular.copy(tempListFilter[0]);
							$scope.MetaDataList.push(filterTempModel);
							$scope.selected.push(filterTempModel);
							filterTempModel = null;
						}
						tempListFilter = [];
					}
					metaDataUIModel = null;
				});
				lastAppendItemCount = 0;
				if ($scope.appsVar.SearchText.length === 0 && !isValidFilterFind()) {
					angular.forEach(LastAddedSelectedItemMetaData, function (metadata) {
						filterTempModel = angular.copy(metadata);
						$scope.MetaDataList.push(filterTempModel);
						$scope.selected.push(filterTempModel);
						filterTempModel = null;
						lastAppendItemCount += 1;
					});
				}

				if ($scope.selected.length > 0) {
					setContextMenuObject();
				}

				if (MetaType == 'CUSTOM1' || MetaType == 'CUSTOM29') {
					$timeout(function () {
						switch (MetaType) {
							case "CUSTOM1":
								var selectedNextDisplayText = $filter('filter')($scope.metaDataList, { MetaDataItem: 'CUSTOM2' }, true);
								$scope.appsVar.tooltipValue = selectedNextDisplayText[0].DisplayText;
								break;
							case "CUSTOM29":
								var selectedNextDisplayText = $filter('filter')($scope.metaDataList, { MetaDataItem: 'CUSTOM30' }, true);
								$scope.appsVar.tooltipValue = selectedNextDisplayText[0].DisplayText;
								break;
						}
					});
				}
				if (isSearch) $mdDialog.hide();
				$scope.showSearchProgress = false;
			}
			else {
				$scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
			}
		}, function (response) {
			if (isSearch) $mdDialog.hide();
			$scope.showSearchProgress = false;
			$scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
		});
	}

	$scope.query = {
		limit: requestModel.pageLength,
		page: requestModel.pagenumber,
		totalCount: 0
	};

	$scope.onPaginate = function (page, limit) {
		isSearch = false;
		requestModel.pagenumber = page;
		requestModel.pageLength = limit;
		getMetaDataList($scope.appsVar.selectedMetaData);
	};

	$scope.deSelect = function (metaDataModel) {
		setContextMenuObject();

		if (SelectedMetaDataListForFilter.length > 0) {
			SelectedMetaDataListForFilter = $.grep(SelectedMetaDataListForFilter,
								function (item, index) {
									return item.Alias != metaDataModel.Alias;
								});
		}
		if (SelectedMetaDataListForFilter.length > 0) {
			LastAddedSelectedItemMetaData = $.grep(LastAddedSelectedItemMetaData,
								   function (item, index) {
									   return item.Alias != metaDataModel.Alias;
								   });
		}
	};

	$scope.onSelect = function (metaDataModel) {
		setContextMenuObject();

		var tempListFilter = $filter('filter')(SelectedMetaDataListForFilter, {
			UserId: metaDataModel.Alias
		}, true);
		if (tempListFilter.length === 0) {
			SelectedMetaDataListForFilter.push(angular.copy(metaDataModel));
		}
	};

	function showProgressDialog() {
		$mdDialog.show({
			parent: angular.element(document.body),
			template: '<md-dialog ng-cloak height="100%" style="min-width: 1px !important;"><md-dialog-content><div class="md-dialog-content-clearpadding">' +
			  '<md-progress-circular md-mode="indeterminate"></md-progress-circular>' +
			  '</div></md-dialog-content></md-dialog>',
			controller: DialogController
		});
	}

	function isValidFilterFind() {
		var filterKeyItem = null;
		var blnResult = false;

		for (var iCount = 0; iCount < requestModel.filters.length; iCount++) {
			filterKeyItem = requestModel.filters[iCount];
			if (filterKeyItem.FilterValues && filterKeyItem.FilterValues[0] && filterKeyItem.FilterValues[0].trim().length > 0) {
				blnResult = true;
				break;
			}
			filterKeyItem = null;
		}
		return blnResult;
	}

	$scope.onTableFilter = function (value, key, isInstantFilter, disablePerformFilter) {
		if (requestModel.filters.length > 0) {
			requestModel.filters = jQuery.grep(requestModel.filters, function (filterItem) {
				return filterItem.FilterKey !== key;
			});
		}

		var filterValueList = [];
		filterValueList[0] = value;

		var filterItem = { 'FilterKey': key, 'FilterValues': filterValueList };
		requestModel.filters.push(filterItem);

		//requestModel.pagenumber = 1;
		//$scope.query.page = 1;
		//$scope.query.totalCount = 0;

		if (FilterSearchTimeout) $timeout.cancel(FilterSearchTimeout);

		if (!disablePerformFilter) {
			if (isInstantFilter) {
				search_Click();
			} else {
				FilterSearchTimeout = $timeout(function () {
					search_Click();
				}, 2000);
			}
		};
	};

	$scope.endScroll = function (info) {
		if ($scope.query.totalCount > $scope.MetaDataList.length) {
			requestModel.pagenumber++;
			getMetaDataList($scope.appsVar.selectedMetaData);
		}
	}

	var isSearch = false;

	$scope.$on('Search_Click', function () {
		search_Click();
	});

	function search_Click() {
		lastAppendItemCount = 0;
		LastAddedSelectedItemMetaData = angular.copy(SelectedMetaDataListForFilter);
		isSearch = true;
		Initalize();
	}

	$scope.$on('$destroy', function () {
		$scope.PageEvents.Add = 'undefined';
		$scope.PageEvents.Edit = 'undefined';
		$scope.PageEvents.Save = 'undefined';
		$scope.PageEvents.Delete = 'undefined';
		$scope.PageEvents.CancelDialog = 'undefined';
		$scope.PageEvents.ShowSubclassList = 'undefined';
		$scope.PageEvents.ShowSubMetaDataList = 'undefined';
		$scope.PageEvents.AddRole = 'undefined';
		$scope.PageEvents.ResetPasswordclicked = 'undefined';
		$scope.PageEvents.ViewAssignUser = 'undefined';
		$scope.PageEvents.AssignUser = 'undefined';
		$scope.PageEvents.AssignGroup = 'undefined';
	});

	$scope.PageEvents.Add = function (event) {
		$scope.ShowWarning = false;
		$scope.validation.showMessage = false;
		$scope.MetaDataModel = metaDataFactory.meatDataInitialValues();
		$scope.PageEvents.UserAction = 'Add';

		var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;

		var dialogObject = {
			controller: DialogController,
			scope: $scope,
			preserveScope: true,
			templateUrl: 'Views/AddEditMetaData.html',
			parent: angular.element(document.body),
			targetEvent: event,
			clickOutsideToClose: true,
			fullscreen: useFullScreen,
			onComplete: function () {
				$("#metadataForm input[id=metadataAlias]").focus();
				$("#metadataForm input[id=metadataAlias]").select();
			}
		};
		$mdDialog.show(dialogObject)
		.then(function (answer) {
			$scope.status = '';
		}, function () {
			$scope.status = '';
		});
		$scope.$watch(function () {
			return $mdMedia('xs') || $mdMedia('sm');
		}, function (wantsFullScreen) {
			$scope.customFullscreen = (wantsFullScreen === true);
		});
	};

	$scope.PageEvents.Edit = function () {
		$scope.PageEvents.UserAction = 'Edit';
		$scope.ValidateMetaData = $scope.selected;
		selectedRowIndex = -1;

		if (typeof $scope.ValidateMetaData != 'undefined' && $scope.ValidateMetaData.length > 0) {
			selectedRowIndex = $scope.MetaDataList.indexOf($scope.selected[0]);
			angular.copy($scope.ValidateMetaData[0], $scope.MetaDataModel);

			$scope.originalmeatdata = metaDataFactory.meatDataInitialValues();
			angular.copy($scope.MetaDataModel, $scope.originalmeatdata);
			var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;

			$mdDialog.show({
				controller: DialogController,
				scope: $scope,
				preserveScope: true,
				templateUrl: 'Views/AddEditMetaData.html',
				parent: angular.element(document.body),
				clickOutsideToClose: true,
				fullscreen: useFullScreen,
				onComplete: function () {
					$("#metadataForm input[id=metadataDesc]").focus();
					$("#metadataForm input[id=metadataDesc]").select();
				}
			})
			.then(function (answer) {
				$scope.status = '';
			}, function () {
				$scope.status = '';
			});
			$scope.$watch(function () {
				return $mdMedia('xs') || $mdMedia('sm');
			}, function (wantsFullScreen) {
				$scope.customFullscreen = (wantsFullScreen === true);
			});
			return true;
		}
		else {
			$scope.showAlertMessage('Select a MetaData to edit.');
			return false;
		}
	}

	$scope.PageEvents.Save = function () {
		if ($scope.PageEvents.UserAction == 'Add') {
			return $scope.AddMetaData();
		} else {
			return $scope.EditMetaData();
		}
	};

	$scope.AddMetaData = function () {
		$scope.validation.showMessage = false;
		$scope.posting = false;

		if ($scope.MetaDataModel.Alias == '' || $scope.metadataForm.$invalid) {
			$scope.validation.showMessage = true;
			return;
		}
		$scope.posting = true;
		$scope.MetaDataModel.MetaType = $scope.vm.selectedApp.MetaDataItem;
		$scope.MetaDataModel.ParentAlias = '';

		var apiUrl = metaDataFactory.getAPIUrl('POSTMETADATA', $scope.MetaDataModel);
		var apiModel = metaDataFactory.getMetaAPIModel($scope.MetaDataModel, $scope.vm.selectedLibrary);
		$scope.mc.getlogDetails("Debug", 'Method:POST;URL:' + JSON.stringify(apiUrl) + 'Request Body:' + JSON.stringify(apiModel));

		var promise = MetaDataService.addMetaData(apiUrl, $scope.mc.loginModel.AuthKey, apiModel);
		promise.then(function (response) {
			if (response && response.status === 200) {
				$scope.dialogPopup.CallbackFunction = function () {
					$mdDialog.hide();
				}
				$scope.dialogPopup.Header = 'Success';
				$scope.dialogPopup.Message = 'Metadata added succesfully';
				$scope.dialogPopup.Show();

				$timeout(function () {
					$scope.dialogPopup.OK();
					$scope.MetaDataModel = metaDataFactory.meatDataInitialValues();
					// getMetaDataList($scope.appsVar.selectedMetaData);
					requestModel.pagenumber = 1;
					$scope.selected = [];
					$scope.MetaDataList = [];
					getMetaDataList($scope.appsVar.selectedMetaData);
					$scope.showValidation = false;
					$scope.ShowWarning = false;
				}, 2000);
				//$scope.mc.setSecurityLogDetails("Info", "Response: Success " + $scope.mc.loginModel.UserName + " added new Metadata (" + $scope.MetaDataModel.Alias + ")");
				$scope.mc.setSecurityLogDetails("Info", 'Success', $scope.vm.selectedApp.MetaDataItem, 'Custom Add', JSON.stringify(apiModel));

			} else {
				$scope.ShowWarning = true;
				$scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.vm.selectedApp.MetaDataItem, 'Custom Add', JSON.stringify(apiModel));
			}
			$scope.posting = false;
		}, function (response) {
			$scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.vm.selectedApp.MetaDataItem, 'Custom Add', JSON.stringify(apiModel));
			$scope.ShowWarning = true;
			$scope.posting = false;
		});
	};

	$scope.EditMetaData = function () {
		$scope.posting = false;
		$scope.validation.showMessage = false;
		if ($scope.MetaDataModel.Alias == '') {
			$scope.validation.showMessage = true;
			return;
		}
		$scope.posting = true;
		$scope.MetaDataModel.MetaType = $scope.vm.selectedApp.MetaDataItem;
		$scope.MetaDataModel.ParentAlias = '';
		var apiUrl = metaDataFactory.getAPIUrl('PUTMETADATA', $scope.MetaDataModel);
		var apiModel = metaDataFactory.getMetaAPIModel($scope.MetaDataModel, $scope.vm.selectedLibrary);

		$scope.mc.getlogDetails("Debug", 'Method:POST;URL:' + JSON.stringify(apiUrl) + 'Request Body:' + JSON.stringify(apiModel));

		var UpdateData = MetaDataService.EditMetaData(apiUrl, $scope.mc.loginModel.AuthKey, apiModel);
		UpdateData.then(function (response) {
			if (response && response.status === 200) {
				$scope.dialogPopup.CallbackFunction = function () {
					$mdDialog.hide();
				}
				$scope.dialogPopup.Header = 'Success';
				$scope.dialogPopup.Message = 'Metadata Updated succesfully';
				$scope.dialogPopup.Show();

				$scope.result = angular.equals($scope.MetaDataModel, $scope.originalmeatdata);
				if (!$scope.result)
					$scope.mc.setSecurityLogDetails("Info", 'Success', $scope.vm.selectedApp.MetaDataItem, 'Custom Add', JSON.stringify(apiModel));

				$timeout(function () {
					$scope.dialogPopup.OK();
					$scope.MetaDataModel = metaDataFactory.meatDataInitialValues();
					//getMetaDataList($scope.appsVar.selectedMetaData);
					$scope.showValidation = false;
					$scope.ShowWarning = false;
				}, 2000);

				if (selectedRowIndex >= 0) {
					$scope.MetaDataList[selectedRowIndex].Description = $scope.MetaDataModel.Description;
					$scope.MetaDataList[selectedRowIndex].HIPAAComplaint = $scope.MetaDataModel.HIPAAComplaint;
					$scope.MetaDataList[selectedRowIndex].EnableFlag = $scope.MetaDataModel.EnableFlag;
				}
				var tmpList = [];
				tmpList = angular.copy($scope.MetaDataList);
				$scope.selected = [];
				$scope.MetaDataList = [];
				$scope.MetaDataList = angular.copy(tmpList);
				$scope.MetaDataModel = metaDataFactory.meatDataInitialValues();
				tmpList = [];

			} else {
				$scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.vm.selectedApp.MetaDataItem, 'Custom Add', JSON.stringify(apiModel));
				if (response && response.data && response.data.details && response.data.details.message)
					$scope.ErrorMessage = response.data.details.message;
				else
					$scope.ErrorMessage = "Posting user failed due to unknown errors";
				$scope.ShowWarning = true;
			}
			$scope.posting = false;
		}, function (response) {
			$scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.vm.selectedApp.MetaDataItem, 'Custom Add', JSON.stringify(apiModel));
			if (response && response.data && response.data.details && response.data.details.message)
				$scope.ErrorMessage = response.data.details.message;
			else
				$scope.ErrorMessage = "Posting user failed due to unknown errors";

			$scope.ShowWarning = true;
			$scope.posting = false;
		});
	}

	function enableSelectedMetaDataItem() {
		var deferredarray = [];

		if ($scope.selected.length === 0) return;

		var confirm = $mdDialog.confirm().title('Warning!').theme('confirm-dialog').textContent('Are you sure you want to enable the selected items?').
			ariaLabel('').ok('Yes').cancel('No');
		$mdDialog.show(confirm).then(function () {

			angular.forEach($scope.selected, function (metaDataModel) {
				var deferredItem = $q.defer();
				metaDataModel.MetaType = $scope.vm.selectedApp.MetaDataItem;
				metaDataModel.ParentAlias = '';
				metaDataModel.EnableFlag = true;

				var apiUrl = metaDataFactory.getAPIUrl('PUTMETADATA', metaDataModel);
				var apiModel = metaDataFactory.getMetaAPIModel(metaDataModel, $scope.vm.selectedLibrary);

				$scope.mc.getlogDetails("Debug", 'Method:POST;URL:' + JSON.stringify(apiUrl) + 'Request Body:' + JSON.stringify(apiModel));

				var UpdateData = MetaDataService.EditMetaData(apiUrl, $scope.mc.loginModel.AuthKey, apiModel);
				UpdateData.then(function (response) {
					deferredItem.resolve(response);
					if (response && response.status === 200) {
						//$scope.mc.setSecurityLogDetails("Info", "Response: Success " + $scope.mc.loginModel.UserName + " updated-enabled Metadata (" + metaDataModel.Alias + ")");
						$scope.mc.setSecurityLogDetails("Info", 'Success', $scope.MetaDataModel.Alias, 'Enable Metadata')
					} else {
						$scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.MetaDataModel.Alias, 'Enable Metadata')
						metaDataModel.EnableFlag = false;
					}
				}, function (response) {
					deferredItem.resolve(response);
					$scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.MetaDataModel.Alias, 'Enable Metadata')
					metaDataModel.EnableFlag = false;
				});
				deferredarray.push(deferredItem.promise);
			});
			$q.all(deferredarray).then(function () {
				setContextMenuObject();
			}, function () {
				setContextMenuObject();
			});
		});
	}

	function disableSelectedMetaDataItem() {
		var deferredarray = [];

		if ($scope.selected.length === 0) return;

		var confirm = $mdDialog.confirm().title('Warning!').theme('confirm-dialog').textContent('Are you sure you want to disable the selected items?').
			ariaLabel('').ok('Yes').cancel('No');
		$mdDialog.show(confirm).then(function () {

			angular.forEach($scope.selected, function (metaDataModel) {
				var deferredItem = $q.defer();
				metaDataModel.MetaType = $scope.vm.selectedApp.MetaDataItem;
				metaDataModel.ParentAlias = '';
				metaDataModel.EnableFlag = false;

				var apiUrl = metaDataFactory.getAPIUrl('PUTMETADATA', metaDataModel);
				var apiModel = metaDataFactory.getMetaAPIModel(metaDataModel, $scope.vm.selectedLibrary);
				$scope.mc.getlogDetails("Debug", 'Method:POST;URL:' + JSON.stringify(apiUrl) + 'Request Body:' + JSON.stringify(apiModel));

				var UpdateData = MetaDataService.EditMetaData(apiUrl, $scope.mc.loginModel.AuthKey, apiModel);
				UpdateData.then(function (response) {
					deferredItem.resolve(response);
					if (response && response.status === 200) {
						//$scope.mc.setSecurityLogDetails("Info", "Response: Success " + $scope.mc.loginModel.UserName + " updated-disabled Metadata (" + metaDataModel.Alias + ")");
						$scope.mc.setSecurityLogDetails("Info", 'Success', metaDataModel.Alias, 'Disable Parent Custom')
					} else {
						$scope.mc.setSecurityLogDetails("Info", 'Failure', metaDataModel.Alias, 'Disable Parent Custom')
						metaDataModel.EnableFlag = true;
					}
				}, function (response) {
					deferredItem.resolve(response);
					$scope.mc.setSecurityLogDetails("Info", 'Failure', metaDataModel.Alias, 'Disable Parent Custom')
					metaDataModel.EnableFlag = true;
				});
				deferredarray.push(deferredItem.promise);
			});
			$q.all(deferredarray).then(function () {
				setContextMenuObject();
			}, function () {
				setContextMenuObject();
			});
		});
	}

	function DialogController($scope, $mdDialog) {

		$scope.dialogPopup = {
			Header: '',
			Message: '',
			CallbackFunction: null,
			Show: function () {
				$('#popup-alert-dialog-bg').slideToggle();
			},
			OK: function () {
				$('#popup-alert-dialog-bg').slideToggle();
				$scope.dialogPopup.Header = '';
				$scope.dialogPopup.Message = '';

				if ($scope.dialogPopup.CallbackFunction) {
					$scope.dialogPopup.CallbackFunction();
					$scope.dialogPopup.CallbackFunction = null;
				}
			}
		};

		$scope.hide = function () {
			$mdDialog.hide();
		};
		$scope.cancel = function () {
			$mdDialog.cancel();
		};
		$scope.answer = function () {
			$mdDialog.hide();
		};

		$scope.MetaDataTextChange = CustomMetaDataTextChange;

		function CustomMetaDataTextChange($event) {
			if ($event.keyCode === 13) {
				$event.preventDefault();
			}
		}
		$scope.MetaDataButtonChange = function ($event, type) {
			if ($event.keyCode === 9) {
				$event.preventDefault();
				if (type == "Add")
					$("#metadataForm input[id=metadataAlias]").focus();
				else if (type == "Edit") {
					$("#metadataForm input[id=metadataDesc]").focus();
					$("#metadataForm input[id=metadataDesc]").select();
				}
			}

		}

	}

	$scope.PageEvents.BindLabel = function (data) {
		if ($scope.PageEvents.UserAction == 'Add') {
			return 'Add'
		} else {
			return 'Save';
		}
	}

	$scope.PageEvents.ShowSubMetaDataList = function () {
		$scope.PageEvents.isSubMetaData = true;
		var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
		var dialogObject = {
			controller: SubMetaDataController,
			preserveScope: false,
			templateUrl: 'Views/SubMetaDataTable.html',
			parent: angular.element(document.body),
			clickOutsideToClose: true,
			fullscreen: useFullScreen,
			locals: {
				parentScope: $scope
			}
		};
		$mdDialog.show(dialogObject)
		.then(function (answer) {
			$scope.status = '';
		}, function () {
			$scope.status = '';
		});
		$scope.$watch(function () {
			return $mdMedia('xs') || $mdMedia('sm');
		}, function (wantsFullScreen) {
			$scope.customFullscreen = (wantsFullScreen === true);
		});
	};

	function SubMetaDataController($scope, $mdDialog, parentScope) {

		$scope.TableScrollOptions = {
			cursorcolor: '#999',
			cursorwidth: "10px",
			cursorborder: "none",
			background: "#ccc",
			smoothscroll: true,
			autohidemode: false
		}

		$scope.SubMetaDataListScrolled = function (info) {
			if ($scope.SubMetaDataTablePagination.totalCount > $scope.subMetaDataList.length) {
				subrequestModel.pagenumber += 1;
				getMetaDataSubList();
			}
		};

		$scope.hide = function () {
			$mdDialog.hide();
		};
		$scope.cancel = function () {
			$mdDialog.cancel();
		};
		$scope.answer = function () {
			$mdDialog.hide();
		};

		$scope.SubMetaDataTextChange = CustomSubMetaDataTextChange;

		function CustomSubMetaDataTextChange($event) {
			if ($event.keyCode === 13) {
				$event.preventDefault();
			}
		}
		var selectedRowIndex = -1;
		var IsInatantSearch = false;
		var subrequestModel = homeFactory.requestModelInstance();
		$scope.validation = metaDataFactory.validations();
		$scope.MetaDataModel = metaDataFactory.meatDataInitialValues();
		$scope.ValidateSubButtonMetaData = parentScope.selected;
		$scope.subSelected = [];
		$scope.subMetaDataList = [];
		$scope.SubMetaSearchText = '';
		//$scope.appsVar = {
		//    selectedMetaData:''
		//};
		//$scope.appsVar.selectedMetaData = parentScope.appsVar.selectedMetaData;
		$scope.PageEvents = {
			isSubMetaData: false
		};
		$scope.SubMetaDataButtonChange = function ($event, type) {
			if ($event.keyCode === 9) {
				$event.preventDefault();
				if (type == "Add")
					$('#popup-add-sub-metadata input[id=metadataSubAlias]').focus();
				else if (type == "Edit") {
					$('#popup-add-sub-metadata input[id=metadataSubDesc]').focus();
					$('#popup-add-sub-metadata input[id=metadataSubDesc]').select();
				}
			}

		}
		function getMetaDataSubList() {
			switch (parentScope.appsVar.selectedMetaData) {
				case "CUSTOM1":
					var selectedNextDisplayText = $filter('filter')(parentScope.metaDataList, { MetaDataItem: 'CUSTOM2' });
					$scope.SubMetaDataDisplayName = selectedNextDisplayText[0].DisplayText;
					break;
				case "CUSTOM29":
					var selectedNextDisplayText = $filter('filter')(parentScope.metaDataList, { MetaDataItem: 'CUSTOM30' });
					$scope.SubMetaDataDisplayName = selectedNextDisplayText[0].DisplayText;
					break;
			}
			//$scope.subMetaDataList = [];
			//$scope.subSelected = [];
			$scope.appsVar = {
				CaptionsList: []
			};
			$scope.appsVar.CaptionsList = parentScope.appsVar.CaptionsList;

			subrequestModel.libraryName = parentScope.vm.selectedLibrary;
			subrequestModel.searchText = $scope.SubMetaSearchText;
			subrequestModel.MetaType = parentScope.appsVar.selectedMetaData;
			subrequestModel.parentAlias = parentScope.selected[0].Alias;
			subrequestModel.subType = subrequestModel.MetaType == 'CUSTOM1' ? "CUSTOM2" : "CUSTOM30";
			$scope.showSearchProgressInDialog = true;
			var apiUrl = metaDataFactory.getAPIUrl('SEARCHCHILDMETADATA', subrequestModel);
			parentScope.mc.getlogDetails("Debug", "Requested Api:" + JSON.stringify(apiUrl));
			var subMetadata = MetaDataService.getMetaDataList(apiUrl, parentScope.mc.loginModel.AuthKey);
			subMetadata.then(function (response) {
				if (response.data && response.status === 200) {
					$scope.SubMetaDataTablePagination.totalCount = response.data[CONST_METADATA.TotalCount];
					angular.forEach(response.data[CONST_METADATA.MetaDataList], function (metadata) {
						$scope.subMetaDataList.push(metaDataFactory.getMetaDataUI(metadata));
					});
				}
				$scope.showSearchProgressInDialog = false;
			}, function () {
				//alert('Data fetching failed.');
				$scope.showSearchProgressInDialog = false;
			});
		}

		$scope.SubMetaDataTablePagination = {
			limit: subrequestModel.pageLength,
			page: subrequestModel.pagenumber,
			totalCount: 0
		};


		$scope.onSubMetaDataPaginate = function (page, limit) {
			subrequestModel.pageLength = limit;
			subrequestModel.pagenumber = page;
			getMetaDataSubList();
		};

		getMetaDataSubList();

		$scope.PageEvents.CancelDialog = function () {
			$scope.PageEvents.isSubMetaData = false;
			$mdDialog.hide();
		}

		$scope.MetadataSubItem = {
			SearchText: '',
			Header: '',
			Message: '',
			CallbackFunction: null,
			Show: function () {
				$('#popup-alert-dialog-bg').slideToggle();
			},
			Add: function (event) {
				$scope.ShowWarning = false;
				$scope.validation.showMessage = false;
				$scope.MetaDataModel = metaDataFactory.meatDataInitialValues();
				$scope.appsVar.selectedMetaData = parentScope.appsVar.selectedMetaData;
				$scope.PageEvents.UserAction = 'Add';
				$('#popup-add-sub-metadata').slideToggle();
				$('#popup-add-sub-metadata input[id=metadataSubAlias]').focus();

			},
			Edit: function (row) {
				selectedRowIndex = $scope.subMetaDataList.indexOf($scope.subSelected[0]);
				$scope.PageEvents.UserAction = 'Edit';
				$scope.MetaDataModel = metaDataFactory.meatDataInitialValues();
				$scope.ValidateMetaData = $scope.subSelected;
				$scope.appsVar.selectedMetaData = parentScope.appsVar.selectedMetaData;
				$scope.originalsubmetadata = metaDataFactory.meatDataInitialValues();

				if (typeof $scope.ValidateMetaData != 'undefined' && $scope.ValidateMetaData.length > 0) {
					angular.copy($scope.ValidateMetaData[0], $scope.MetaDataModel);
					angular.copy($scope.MetaDataModel, $scope.originalsubmetadata);
					$('#popup-add-sub-metadata').slideToggle();
					$('#popup-add-sub-metadata input[id=metadataSubDesc]').focus();
					$('#popup-add-sub-metadata input[id=metadataSubDesc]').select();
				}
				else {
					this.Header = 'No ' + $scope.SubMetaDataDisplayName + ' selected.';
					this.Message = 'Please select one ' + $scope.SubMetaDataDisplayName + ' to edit.';
					$('#popup-alert-dialog-bg').slideToggle();
				}
			},
			Delete: function (ev) {
				$scope.MetaDataModel = metaDataFactory.meatDataInitialValues();
				var metaDataObject = $scope.subSelected[0];//= $filter('filter')($scope.subMetaDataList, { selected: true })[0];
				if (metaDataObject) {
					this.Header = 'Warning';
					this.Message = 'Are you sure you want to delete the selected ' + $scope.SubMetaDataDisplayName + '(s)?';
					$('#popup-confirm-dialog-bg').slideToggle();
				} else {
					this.Header = '';
					this.Message = 'Please select ' + $scope.SubMetaDataDisplayName + ' to delete.';
					$('#popup-alert-dialog-bg').slideToggle();
				}
			},
			CloseAddEditDialog: function () {
				$scope.MetaDataModel = metaDataFactory.meatDataInitialValues();
				$scope.validation.showMessage = false;
				$('#popup-add-sub-metadata').slideToggle();
				$scope.ShowWarning = false;
			},
			CloseAlertDialog: function () {
				$scope.MetadataSubItem.Header = '';
				$scope.MetadataSubItem.Message = '';

				if ($scope.MetadataSubItem.CallbackFunction) {
					$('#popup-alert-dialog-bg').slideToggle();
					$scope.MetadataSubItem.CallbackFunction();
					$scope.MetadataSubItem.CallbackFunction = null;
				}
				//$('#popup-alert-dialog-bg').slideToggle();
			},
			CloseDeleteDialog: function () {
				$('#popup-confirm-dialog-bg').slideToggle();
			},
			ProceedDelete: function () {
				var selectedMetaDataItems = $scope.subSelected[0];//= $filter('filter')($scope.subMetaDataList, { selected: true })[0];
				selectedMetaDataItems.MetaType = parentScope.vm.selectedApp.MetaDataItem;
				selectedMetaDataItems.libraryName = parentScope.selectedLibrary;
				selectedMetaDataItems.parentAlias = $scope.ValidateSubButtonMetaData[0].Alias;
				selectedMetaDataItems.MetaType = (selectedMetaDataItems.MetaType == 'CUSTOM1') ? 'CUSTOM2' : 'CUSTOM30';
				var apiUrl = metaDataFactory.getAPIUrl('DELETEMETADATA', selectedMetaDataItems);
				var promise = MetaDataService.deleteMetaData(apiUrl, parentScope.mc.loginModel.AuthKey);
				promise.then(function (response) {

					$('#popup-confirm-dialog-bg').slideToggle();
					$scope.MetadataSubItem.onSearch();

				}, function () {
					$('#popup-confirm-dialog-bg').slideToggle();
				}
				);
			},
			onSearch: function () {
				$scope.subSelected = [];
				$scope.ValidateSubButtonMetaData = parentScope.selected;
				if (typeof $scope.ValidateSubButtonMetaData != 'undefined' && $scope.ValidateSubButtonMetaData.length > 0) {
					angular.copy($scope.ValidateSubButtonMetaData[0], $scope.MetaDataModel);
					$timeout(function () {
						$scope.PageEvents.isSubMetaData = true;
						switch (parentScope.appsVar.selectedMetaData) {
							case "CUSTOM1":
								var selectedNextDisplayText = $filter('filter')(parentScope.metaDataList, { MetaDataItem: 'CUSTOM2' });
								if (!selectedNextDisplayText)
									$scope.SubMetaDataDisplayName = selectedNextDisplayText[0].DisplayText;
								break;
							case "CUSTOM29":
								var selectedNextDisplayText = $filter('filter')(parentScope.metaDataList, { MetaDataItem: 'CUSTOM30' });
								if (!selectedNextDisplayText)
									$scope.SubMetaDataDisplayName = selectedNextDisplayText[0].DisplayText;
								break;
						}
						subrequestModel.libraryName = parentScope.selectedLibrary;
						subrequestModel.pagenumber = 1;
						//subrequestModel.pageLength = 10;
						subrequestModel.isTotal = true;
						subrequestModel.searchText = $scope.MetadataSubItem.SearchText;
						subrequestModel.MetaType = parentScope.appsVar.selectedMetaData;
						subrequestModel.parentAlias = $scope.ValidateSubButtonMetaData[0].Alias;
						subrequestModel.subType = subrequestModel.MetaType == 'CUSTOM1' ? "CUSTOM2" : "CUSTOM30";
						var apiUrl = metaDataFactory.getAPIUrl('SEARCHCHILDMETADATA', subrequestModel);
						parentScope.mc.getlogDetails("Debug", "Requested Api:" + JSON.stringify(apiUrl));
						var subMetadata = MetaDataService.getMetaDataList(apiUrl, parentScope.mc.loginModel.AuthKey);
						subMetadata.then(function (response) {
							$scope.appsVar.initialLoading = false;
							$scope.subMetaDataList = [];
							if (response.data) {
								$scope.SubMetaDataTablePagination.totalCount = response.data[CONST_METADATA.TotalCount];
								angular.forEach(response.data[CONST_METADATA.MetaDataList], function (metadata) {
									$scope.subMetaDataList.push(metaDataFactory.getMetaDataUI(metadata));
								});
							}
						}, function () {
							//alert('Data fetching failed.');
						});
						$scope.isSubPrevDisable = true;
						return true;
					});
				}
				else {
					$scope.showAlertMessage('Select a Metadata to implement submetadata.');
					return false;
				}
			},
		}

		$scope.PageEvents.BindLabel = function (data) {
			if ($scope.PageEvents.UserAction == 'Add') {
				return 'Add'
			} else {
				return 'Save';
			}
		}

		$scope.AddMetaData = function () {
			$scope.posting = true;
			$scope.validation.showMessage = true;
			if ($scope.MetaDataModel.Alias == '') {
				$scope.posting = false;
				return;
			}
			$scope.MetaDataModel.MetaType = (parentScope.vm.selectedApp.MetaDataItem == 'CUSTOM1') ? 'CUSTOM2' : 'CUSTOM30';
			$scope.MetaDataModel.ParentAlias = $scope.ValidateSubButtonMetaData[0].Alias;
			var apiUrl = metaDataFactory.getAPIUrl('POSTMETADATA', $scope.MetaDataModel);
			parentScope.mc.getlogDetails("Debug", "Requested Api:" + JSON.stringify(apiUrl));
			var promise = MetaDataService.addMetaData(apiUrl, parentScope.mc.loginModel.AuthKey, metaDataFactory.getMetaAPIModel($scope.MetaDataModel, parentScope.vm.selectedLibrary));
			promise.then(function (response) {
				if (response) {
					if (response.status == 200) {
						//$scope.showValidation = false;
						//$scope.ShowWarning = false;
						//$('#popup-add-sub-metadata').slideToggle();
						//$scope.MetaDataModel = metaDataFactory.meatDataInitialValues();
						//getMetaDataSubList($scope.selectedLibrary, 1, 10, true, $scope.appsVar.SearchText, parentScope.vm.selectedApp.MetaDataItem, $scope.ValidateSubButtonMetaData[0].Alias);
						$scope.MetadataSubItem.CallbackFunction = function () {
							$('#popup-add-sub-metadata').slideToggle();
						}
						$scope.MetadataSubItem.Header = 'Success';
						$scope.MetadataSubItem.Message = 'SubMetadata added succesfully';
						parentScope.mc.setSecurityLogDetails("Info", 'Success', metaDataModel.Alias, ' Custom Add')
						$scope.MetadataSubItem.Show();
						$timeout(function () {
							$scope.showValidation = false;
							$scope.ShowWarning = false;
							$scope.posting = false;
							$scope.MetadataSubItem.CloseAlertDialog();
							$scope.MetaDataModel = metaDataFactory.meatDataInitialValues();
							$scope.subMetaDataList = [];
							$scope.subSelected = [];
							// getMetaDataSubList($scope.selectedLibrary, 1, 10, true, $scope.appsVar.SearchText, parentScope.vm.selectedApp.MetaDataItem, $scope.ValidateSubButtonMetaData[0].Alias);
							$scope.SubMetaDataTablePagination.page = 1;
							subrequestModel.pagenumber = 1;
							getMetaDataSubList();
						}, 2000);

					} else {
						$scope.ErrorMessage = response.data.error.message;
						parentScope.mc.setSecurityLogDetails("Info", 'Failure', metaDataModel.Alias, ' Custom Add')
						$scope.ShowWarning = true;
						$scope.posting = false;
						if (response && response.data && response.data.details && response.data.details.message)
							$scope.ErrorMessage = response.data.details.message;
						else
							$scope.ErrorMessage = "Posting user failed due to unknown errors";
					}

				}

				$scope.posting = false;

			}, function (response) {
				$scope.ErrorMessage = response.data.error.message;
				parentScope.mc.setSecurityLogDetails("Info", 'Failure', metaDataModel.Alias, ' Custom Add')
				$scope.ShowWarning = true;
				$scope.posting = false;
			});
		}

		$scope.EditMetaData = function () {
			$scope.posting = true;
			$scope.validation.showMessage = true;
			if ($scope.MetaDataModel.Alias == '') {
				$scope.posting = false;
				return;
			}
			$scope.MetaDataModel.MetaType = (parentScope.vm.selectedApp.MetaDataItem == 'CUSTOM1') ? 'CUSTOM2' : 'CUSTOM30';
			$scope.MetaDataModel.ParentAlias = $scope.ValidateSubButtonMetaData[0].Alias;
			var apiUrl = metaDataFactory.getAPIUrl('PUTMETADATA', $scope.MetaDataModel);
			parentScope.mc.getlogDetails("Debug", "Requested Api:" + JSON.stringify(apiUrl));
			var UpdateData = MetaDataService.EditMetaData(apiUrl, parentScope.mc.loginModel.AuthKey, metaDataFactory.getMetaAPIPUTModel($scope.MetaDataModel, parentScope.vm.selectedLibrary));
			//    var  = MetaDataService.($scope.selectedLibrary, $scope.MetaDataModel, $scope.vm.selectedApp.MetaDataItem, $scope.ValidateSubButtonMetaData[0].Alias);
			UpdateData.then(function (response) {
				if (response) {
					if (response.status == 200) {
						$scope.MetadataSubItem.CallbackFunction = function () {
							$('#popup-add-sub-metadata').slideToggle();
						}
						$scope.MetadataSubItem.Header = 'Success';
						$scope.MetadataSubItem.Message = 'SubMetadata Updated succesfully';
						$scope.result = angular.equals($scope.MetaDataModel, $scope.originalsubmetadata);
						if (!$scope.result)
							//parentScope.mc.setSecurityLogDetails("Info", parentScope.mc.loginModel.UserName + " Update " + $scope.MetaDataModel.Alias + " Details for " + $scope.MetaDataModel.ParentAlias);
							parentScope.mc.setSecurityLogDetails("Info", 'Success', metaDataModel.Alias, ' Custom Update')
						$scope.MetadataSubItem.Show();
						$timeout(function () {
							$scope.showValidation = false;
							$scope.ShowWarning = false;
							$scope.posting = false;
							$scope.MetadataSubItem.CloseAlertDialog();
							$scope.MetaDataModel = metaDataFactory.meatDataInitialValues();
							//getMetaDataSubList($scope.selectedLibrary, 1, 10, true, $scope.appsVar.SearchText, parentScope.vm.selectedApp.MetaDataItem, $scope.ValidateSubButtonMetaData[0].Alias);
						}, 2000);

						selectedRowIndex = $scope.subMetaDataList.indexOf($scope.subSelected[0]);
						if (selectedRowIndex >= 0) {
							$scope.subMetaDataList[selectedRowIndex].Description = $scope.MetaDataModel.Description;
							$scope.subMetaDataList[selectedRowIndex].HIPAAComplaint = $scope.MetaDataModel.HIPAAComplaint;
							$scope.subMetaDataList[selectedRowIndex].EnableFlag = $scope.MetaDataModel.EnableFlag;
						}

						var tmpList = [];
						tmpList = angular.copy($scope.subMetaDataList);
						$scope.subSelected = [];
						$scope.subMetaDataList = [];
						$scope.subMetaDataList = angular.copy(tmpList);
						$scope.MetaDataModel = metaDataFactory.meatDataInitialValues();
						tmpList = [];
					} else {
						$scope.ErrorMessage = response.data.error.message;
						$scope.ShowWarning = true;
						//parentScope.mc.setSecurityLogDetails("Error", 'Response:' + JSON.stringify(response));
						parentScope.mc.setSecurityLogDetails("Info", 'Failure', metaDataModel.Alias, 'Custom Update')
						if (response && response.data && response.data.details && response.data.details.message)
							$scope.ErrorMessage = response.data.details.message;
						else
							$scope.ErrorMessage = "Posting user failed due to unknown errors";
					}
				}
				//getMetaDataSubList($scope.selectedLibrary, 1, 10, true, $scope.appsVar.SearchText, parentScope.vm.selectedApp.MetaDataItem, $scope.ValidateSubButtonMetaData[0].Alias);
			}, function (response) {
				$scope.ErrorMessage = response.data.error.message;
				parentScope.mc.setSecurityLogDetails("Info", 'Failure', metaDataModel.Alias, ' Custom Update')
				$scope.ShowWarning = true;
				$scope.posting = false;
				if (response && response.data && response.data.details && response.data.details.message)
					$scope.ErrorMessage = response.data.details.message;
				else
					$scope.ErrorMessage = "Posting user failed due to unknown errors";
			});
		}

		$scope.PageEvents.Save = function () {
			if ($scope.PageEvents.UserAction == 'Add') {
				return $scope.AddMetaData();
			} else {
				return $scope.EditMetaData();
			}
		}

		var searchTimeout;
		var FilterSearchTimeout;
		var isSubserchTxtDirty = false;

		$scope.$watch(function () { return $scope.MetadataSubItem.SearchText }, function (val) {
			if ($scope.MetadataSubItem.SearchText.length > 0) {
				isSubserchTxtDirty = true;
			}
			if (searchTimeout) $timeout.cancel(searchTimeout);

			if (IsInatantSearch) {
				IsInatantSearch = false;
				$scope.MetadataSubItem.onSearch();
			}
			else {
				searchTimeout = $timeout(function () {
					if (isSubserchTxtDirty) {
						$scope.MetadataSubItem.onSearch();
					}
				}, 2000);
			}
		}, true);

		$scope.Search_SubMetaData_Click = function () {
			if (searchTimeout) $timeout.cancel(searchTimeout);
			$scope.SubMetaDataTablePagination.page = 1;
			subrequestModel.pagenumber = 1;
			IsInatantSearch = false;
			$scope.MetadataSubItem.onSearch();
		}

		$scope.ClearMetaDataClick = function () {
			$scope.SubMetaDataTablePagination.page = 1;
			subrequestModel.pagenumber = 1;
			IsInatantSearch = true;
			$scope.MetadataSubItem.SearchText = '';
			//getMetaDataSubList();
		}

		$scope.onTableFilter = function (value, key, isInstantFilter, disablePerformFilter) {
			if (subrequestModel.filters.length > 0) {
				subrequestModel.filters = jQuery.grep(subrequestModel.filters, function (filterItem) {
					return filterItem.FilterKey !== key;
				});
			}

			var filterValueList = [];
			filterValueList[0] = value;

			var filterItem = { 'FilterKey': key, 'FilterValues': filterValueList };
			subrequestModel.filters.push(filterItem);

			$scope.SubMetaDataTablePagination.page = 1;
			subrequestModel.pagenumber = 1;

			if (FilterSearchTimeout) $timeout.cancel(FilterSearchTimeout);
			if (!disablePerformFilter) {
				if (isInstantFilter) {
					$scope.subMetaDataList = [];
					$scope.subSelected = [];
					getMetaDataSubList();
				} else {
					FilterSearchTimeout = $timeout(function () {
						$scope.subMetaDataList = [];
						$scope.subSelected = [];
						getMetaDataSubList();
					}, 2000);
				}
			};
		};


	}

	$scope.MetaDataView = {
		SearchText: '',
		SubMetaDataDisplayName: '',
		IsViewListErrorMsg: false,
		IsPosting: false,
		SubListErrorMsg: '',
		ViewSelectedText: '',
		SubMatadataList: [],
		SelectedSubMatadataList: [],
		SubMetaDataMenuList: [],
		NewAddSubMetaDataList: [],
		EditSubMetaDataList: [],
		totalCount: 0,
		IsSetTitleMsg: false,
		SubClassListTitle: ''
	};

	$scope.OriginalMeatData = metaDataFactory.meatDataInitialValues();
	var subMetadataReqModel = homeFactory.requestModelInstance();
	var subMetaDataListSearchTimeout;
	var isInstantSearch;
	var isSubMetaDataListSearchTextDirty;
	var totalSubMetaListCountWithoutFilter = 0;

	var SelectedMetaDataListForFilter = [];
	var LastAddedSelectedItemMetaData = [];
	var lastAppendMetaDataItemCount = 0;

	function initializeSubMetaDataView() {
		$scope.MetaDataView.SearchText = '';
		$scope.MetaDataView.SubMetaDataDisplayName = '';
		$scope.MetaDataView.IsViewListErrorMsg = false;
		$scope.MetaDataView.SubListErrorMsg = '';
		$scope.MetaDataView.SubMatadataList = [];
		$scope.MetaDataView.SelectedSubMatadataList = [];
		$scope.MetaDataView.SubMetaDataMenuList = [];
		$scope.MetaDataView.NewAddSubMetaDataList = [];
		$scope.MetaDataView.EditSubMetaDataList = [];
		$scope.MetaDataView.totalCount = 0;
		$scope.MetaDataView.ViewSelectedText = 'View selected';
		$scope.MetaDataView.IsPosting = false;
		$scope.MetaDataView.IsSetTitleMsg = true;
		$scope.MetaDataView.SubClassListTitle = '';

		SelectedMetaDataListForFilter = [];
		LastAddedSelectedItemMetaData = [];
		lastAppendMetaDataItemCount = 0;
		subMetaDataListSearchTimeout = null;
		isInstantSearch = false;
		$scope.IsPosting = false;
		totalSubMetaListCountWithoutFilter = 0;
	}

	$scope.PageEvents.ViewSelected = function (selectedRow, $event) {
		if ($scope.appsVar.selectedMetaData !== 'CUSTOM1' && $scope.appsVar.selectedMetaData !== 'CUSTOM29') return;

		initializeSubMetaDataView();
		switch ($scope.appsVar.selectedMetaData) {
			case "CUSTOM1":
				var selectedNextDisplayText = $filter('filter')($scope.metaDataList, { MetaDataItem: 'CUSTOM2' });
				$scope.MetaDataView.SubMetaDataDisplayName = selectedNextDisplayText[0].DisplayText;
				break;
			case "CUSTOM29":
				var selectedNextDisplayText = $filter('filter')($scope.metaDataList, { MetaDataItem: 'CUSTOM30' });
				$scope.MetaDataView.SubMetaDataDisplayName = selectedNextDisplayText[0].DisplayText;
				break;
		}
		$rootScope.checkReadyToChangeState = function () {
			return $q(function (resolve, reject) {
				if (!isMetaDataEdited()) {
					resolve({ Status: 0 });
					return;
				}
				var confirm = $mdDialog.confirm()
						.title('Warning!')
						.theme('confirm-dialog')
						.textContent('Do you want to save the changes?')
						.ariaLabel('Warning!').ok('Yes').cancel('No');

				$mdDialog.show(confirm).then(function () {
					var userSavePromise = saveMetaData();
					userSavePromise.then(function (response) {
						if (response && response.Status === 0 && response.ErrorMessage.length === 0) {
							resolve({ Status: 0 });
						}
						else if (response && response.ErrorMessage) {
							$mdDialog.show($mdDialog.alert()
										.parent(angular.element(document.body))
										.clickOutsideToClose(true)
										.title('Warning!')
										.textContent(response.ErrorMessage)
										.ariaLabel('Warning!')
										.ok('OK')
									);
							resolve({ Status: -1 });
						}

					});
				}, function () {
					resolve({ Status: 0 });
				});
			});
		};

		selectedRowIndex = $scope.MetaDataList.indexOf(selectedRow);
		$scope.MetaDataModel = metaDataFactory.meatDataInitialValues();
		angular.copy(selectedRow, $scope.MetaDataModel);
		angular.copy(selectedRow, $scope.OriginalMeatData);

		subMetadataReqModel.libraryName = $scope.vm.selectedLibrary;
		subMetadataReqModel.MetaType = $scope.appsVar.selectedMetaData;
		subMetadataReqModel.parentAlias = $scope.MetaDataModel.Alias;
		subMetadataReqModel.subType = subMetadataReqModel.MetaType === 'CUSTOM1' ? "CUSTOM2" : "CUSTOM30";

		fillSubMetaDataList();
		$scope.IsShowSelectedMetaDataDetails = true;
	};

	$scope.HideViewSelected = function () {
		if (!isMetaDataEdited()) {
			closeViewWindow();
			return;
		}
		if (noDataExist) {
			closeViewWindow();
			return;
		}
		var confirm = $mdDialog.confirm()
				.title('Warning!')
				.theme('confirm-dialog')
				.textContent('Do you want to save the changes?')
				.ariaLabel('Warning!').ok('Yes').cancel('No');

		$mdDialog.show(confirm).then(function () {
			var classPromise = saveMetaData();
			classPromise.then(function (response) {
				if (response && response.Status === 0 && response.ErrorMessage.length === 0) {
					closeViewWindow();
				}
				else if (response && response.ErrorMessage) {
					$mdDialog.show($mdDialog.alert()
								.parent(angular.element(document.body))
								.clickOutsideToClose(true)
								.title('Warning!')
								.textContent(response.ErrorMessage)
								.ariaLabel('Warning!')
								.ok('OK')
							);
				}
			});
		}, function () {
			closeViewWindow();
		});
	};

	function isMetaDataEdited() {
		if ($scope.OriginalMeatData.Description !== $scope.MetaDataModel.Description
		   || $scope.OriginalMeatData.HIPAAComplaint !== $scope.MetaDataModel.HIPAAComplaint
		   || $scope.OriginalMeatData.EnableFlag !== $scope.MetaDataModel.EnableFlag) {
			return true;
		}

		if ($scope.MetaDataView.NewAddSubMetaDataList.length > 0 || $scope.MetaDataView.EditSubMetaDataList.length > 0) {
			return true;
		}
		return false;
	}

	function closeViewWindow() {
		$scope.IsShowSelectedMetaDataDetails = false;
		initializeSubMetaDataView();
		$scope.MetaDataModel = metaDataFactory.meatDataInitialValues();
		$scope.OriginalMeatData = metaDataFactory.meatDataInitialValues();

		$timeout(function () {
			$(window).scrollTop($scope.scrollTop);
		});
	}

	function fillSubClassGrid() {
		$scope.MetaDataView.SubMatadataList = [];
		$scope.MetaDataView.SelectedSubMatadataList = [];
		subMetadataReqModel.pagenumber = 1;
		fillNewAddSubMetaDataList();
		fillSubMetaDataList();
	}

	function fillNewAddSubMetaDataList() {
		angular.forEach($scope.MetaDataView.NewAddSubMetaDataList, function (subMetaDataModel) {
			if ($scope.MetaDataView.SearchText.length === 0) {
				$scope.MetaDataView.SubMatadataList.push(subMetaDataModel);
			}
			else {
				if (subMetaDataModel.Alias.indexOf($scope.MetaDataView.SearchText) >= 0 || subMetaDataModel.Description.indexOf($scope.MetaDataView.SearchText) >= 0) {
					$scope.MetaDataView.SubMatadataList.push(subMetaDataModel);
				}
			}
		});
	}

	function fillSubMetaDataList() {
		$scope.MetaDataView.IsViewListErrorMsg = false;
		$scope.MetaDataView.SubListErrorMsg = '';

		subMetadataReqModel.searchText = $scope.MetaDataView.SearchText;
		var apiUrl = metaDataFactory.getAPIUrl('SEARCHCHILDMETADATA', subMetadataReqModel);
		$scope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(apiUrl));

		var subMetadata = MetaDataService.getMetaDataList(apiUrl, $scope.mc.loginModel.AuthKey);
		subMetadata.then(function (response) {
			if (response.data && response.status === 200) {
				$scope.mc.getlogDetails("Debug", 'Response:Success');
				$scope.MetaDataView.totalCount = response.data[CONST_METADATA.TotalCount];

				if ($scope.MetaDataView.IsSetTitleMsg) {
					$scope.MetaDataView.IsSetTitleMsg = false;
					totalSubMetaListCountWithoutFilter = $scope.MetaDataView.totalCount;

					if ($scope.MetaDataView.totalCount > 0 || $scope.MetaDataView.NewAddSubMetaDataList.length > 0) {
						$scope.MetaDataView.SubClassListTitle = ($scope.MetaDataView.totalCount + $scope.MetaDataView.NewAddSubMetaDataList.length).toString() +
							' ' + $scope.MetaDataView.SubMetaDataDisplayName + ' for ' + $scope.MetaDataModel.Alias;
					}
					else {
						$scope.MetaDataView.SubClassListTitle = $scope.MetaDataView.SubMetaDataDisplayName + ' for ' + $scope.MetaDataModel.Alias + ' not found';
					}
				}
				if (lastAppendMetaDataItemCount > 0) {
					$scope.MetaDataView.SubMatadataList.splice($scope.MetaDataView.SubMatadataList.length - lastAppendMetaDataItemCount, lastAppendMetaDataItemCount);
					$scope.MetaDataView.SelectedSubMatadataList.splice($scope.MetaDataView.SelectedSubMatadataList.length - lastAppendMetaDataItemCount, lastAppendMetaDataItemCount);
					lastAppendMetaDataItemCount = 0;
				}
				var metaDataUIModel;
				var filterTempModel;
				var tempListFilter = [];

				angular.forEach(response.data[CONST_METADATA.MetaDataList], function (metadata) {
					metaDataUIModel = metaDataFactory.getMetaDataUI(metadata);
					if (SelectedMetaDataListForFilter.length === 0) {
						$scope.MetaDataView.SubMatadataList.push(metaDataUIModel);
					}
					else {
						tempListFilter = $filter('filter')(SelectedMetaDataListForFilter, {
							Alias: metaDataUIModel.Alias
						}, true);
						if (tempListFilter.length === 0) {
							$scope.MetaDataView.SubMatadataList.push(metaDataUIModel);
						}
						else {
							LastAddedSelectedItemMetaData = $.grep(LastAddedSelectedItemMetaData,
							   function (item, index) {
								   return item.Alias != metaDataUIModel.Alias;
							   });

							$scope.MetaDataView.SubMatadataList.push(metaDataUIModel);
							$scope.MetaDataView.SelectedSubMatadataList.push(metaDataUIModel);
						}
						tempListFilter = [];
					}
					metaDataUIModel = null;
				});
				lastAppendMetaDataItemCount = 0;
				if ($scope.MetaDataView.SearchText.length === 0) {
					angular.forEach(LastAddedSelectedItemMetaData, function (metadata) {
						filterTempModel = angular.copy(metadata);
						$scope.MetaDataView.SubMatadataList.push(filterTempModel);
						$scope.MetaDataView.SelectedSubMatadataList.push(filterTempModel);
						filterTempModel = null;
						lastAppendMetaDataItemCount += 1;
					});
				}
				if ($scope.MetaDataView.SelectedSubMatadataList.length > 0) {
					$scope.setSubMetaDataListContextMenuObject();
				}
				if ($scope.MetaDataView.SearchText.length > 0 && $scope.MetaDataView.SubMatadataList.length === 0) {
					$scope.MetaDataView.IsViewListErrorMsg = true;
					$scope.MetaDataView.SubListErrorMsg = $scope.MetaDataView.SubMetaDataDisplayName + ' not found, based on this search.';
				}
			}
			else {
				$scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
			}
		}, function (response) {
			$scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
		});
	}

	$scope.$watch(function () { return $scope.MetaDataView.SearchText; }, function (val) {
		if ($scope.MetaDataView.SearchText.length > 0) {
			isSubMetaDataListSearchTextDirty = true;
		}
		if (subMetaDataListSearchTimeout) $timeout.cancel(subMetaDataListSearchTimeout);

		if (isInstantSearch) {
			isInstantSearch = false;
			$scope.SubMetaDataList_SearchClick();
		}
		else {
			subMetaDataListSearchTimeout = $timeout(function () {
				if (isSubMetaDataListSearchTextDirty) {
					$scope.SubMetaDataList_SearchClick();
				}
			}, 2000);
		}
	}, true);

	$scope.SubMetaDataList_SearchClick = function () {
		if (subMetaDataListSearchTimeout) $timeout.cancel(subMetaDataListSearchTimeout);

		lastAppendMetaDataItemCount = 0;
		LastAddedSelectedItemMetaData = angular.copy(SelectedMetaDataListForFilter);
		subMetadataReqModel.pagenumber = 1;
		$scope.MetaDataView.IsViewListErrorMsg = false;
		$scope.MetaDataView.SubListErrorMsg = '';
		$scope.MetaDataView.SubMatadataList = [];
		$scope.MetaDataView.SelectedSubMatadataList = [];

		fillSubClassGrid();
	};

	$scope.ClearSubMetaDataListSearch = function () {
		isInstantSearch = true;
		$scope.MetaDataView.SearchText = '';
	};

	$scope.onSubMetaDataSelect = function (subMetaDataModel) {
		$scope.setSubMetaDataListContextMenuObject();

		var tempListFilter = $filter('filter')(SelectedMetaDataListForFilter, {
			Alias: subMetaDataModel.Alias
		}, true);
		if (tempListFilter.length === 0) {
			SelectedMetaDataListForFilter.push(angular.copy(subMetaDataModel));
		}
		tempListFilter = [];

	};

	$scope.onSubMetaDataDeselect = function (subMetaDataModel) {
		$scope.setSubMetaDataListContextMenuObject();

		if (SelectedMetaDataListForFilter.length > 0) {
			SelectedMetaDataListForFilter = $.grep(SelectedMetaDataListForFilter,
								function (item, index) {
									return item.Alias != subMetaDataModel.Alias;
								});
		}
		if (SelectedMetaDataListForFilter.length > 0) {
			LastAddedSelectedItemMetaData = $.grep(LastAddedSelectedItemMetaData,
								   function (item, index) {
									   return item.Alias != subMetaDataModel.Alias;
								   });
		}
	};

	$scope.setSubMetaDataListContextMenuObject = function () {

		$scope.MetaDataView.SubMetaDataMenuList = [];
		ContextMenuVariables.SubMetaDataEnableDisable.Label = '';
		ContextMenuVariables.SubMetaDataEnableDisable.onClick = 'undefined';
		//$scope.PageEvents.Enable = 'undefined';
		//$scope.PageEvents.Disable = 'undefined';

		if ($scope.MetaDataView.SelectedSubMatadataList.length === 1) {
			if ($scope.MetaDataView.SelectedSubMatadataList[0].EnableFlag) {
				ContextMenuVariables.SubMetaDataEnableDisable.Label = 'Disable';
				ContextMenuVariables.SubMetaDataEnableDisable.Icon = 'icon-disable';
				ContextMenuVariables.SubMetaDataEnableDisable.onClick = $scope.ContextMenuFunctions.DisableSubMetaData;
				//$scope.PageEvents.Enable = 'undefined';
				//$scope.PageEvents.Disable = $scope.ContextMenuFunctions.DisableMetaData;
			} else {
				ContextMenuVariables.SubMetaDataEnableDisable.Label = 'Enable';
				ContextMenuVariables.SubMetaDataEnableDisable.Icon = 'icon-enable';
				ContextMenuVariables.SubMetaDataEnableDisable.onClick = $scope.ContextMenuFunctions.EnableSubMetaData;
				//$scope.PageEvents.Enable = $scope.ContextMenuFunctions.EnableMetaData;
				//$scope.PageEvents.Disable = 'undefined';
			}
		}
		else if ($scope.MetaDataView.SelectedSubMatadataList.length > 1) {
			var filterList = $filter('filter')($scope.MetaDataView.SelectedSubMatadataList, {
				EnableFlag: false
			});
			if (filterList.length === $scope.MetaDataView.SelectedSubMatadataList.length) {
				ContextMenuVariables.SubMetaDataEnableDisable.Label = 'Enable';
				ContextMenuVariables.SubMetaDataEnableDisable.Icon = 'icon-enable';
				ContextMenuVariables.SubMetaDataEnableDisable.onClick = $scope.ContextMenuFunctions.EnableSubMetaData;
				//$scope.PageEvents.Enable = $scope.ContextMenuFunctions.EnableMetaData;
				//$scope.PageEvents.Disable = 'undefined';
			}
			else {
				filterList = [];
				filterList = $filter('filter')($scope.MetaDataView.SelectedSubMatadataList, {
					EnableFlag: true
				});
				if (filterList.length === $scope.MetaDataView.SelectedSubMatadataList.length) {
					ContextMenuVariables.SubMetaDataEnableDisable.Label = 'Disable';
					ContextMenuVariables.SubMetaDataEnableDisable.Icon = 'icon-disable';
					ContextMenuVariables.SubMetaDataEnableDisable.onClick = $scope.ContextMenuFunctions.DisableSubMetaData;
					//$scope.PageEvents.Enable = 'undefined';
					//$scope.PageEvents.Disable = $scope.ContextMenuFunctions.DisableMetaData;
				}
			}
			filterList = [];
		}
		$scope.MetaDataView.SubMetaDataMenuList = [
			{
				Label: 'Edit',
				Icon: 'icon-edit',
				onClick: $scope.ContextMenuFunctions.EditSubMetaData,
				Enable: $scope.MetaDataView.SelectedSubMatadataList.length === 1,
				IconType: 'font-icon'
			},
			{
				Label: ContextMenuVariables.SubMetaDataEnableDisable.Label,
				Icon: ContextMenuVariables.SubMetaDataEnableDisable.Icon,
				onClick: ContextMenuVariables.SubMetaDataEnableDisable.Label === '' ? 'undefined' : ContextMenuVariables.SubMetaDataEnableDisable.onClick,
				Enable: ContextMenuVariables.SubMetaDataEnableDisable.Label !== '',
				IconType: 'font-icon'
			}
		];
	};

	$scope.SelectedOnlyFilterOnGrid = function (selectedList) {
		return function (subMetaDataModel) {
			if ($scope.MetaDataView.ViewSelectedText === 'View selected') {
				return true;
			}
			if ($scope.MetaDataView.ViewSelectedText === 'Show all') {
				if (selectedList.length === 0) {
					$scope.MetaDataView.ViewSelectedText = 'View selected';
				}
				var tempListFilter = $filter('filter')(selectedList, {
					Alias: subMetaDataModel.Alias
				}, true);
				if (tempListFilter.length > 0) {
					return true;
				}
				return false;
			}
			return false;
		}
	};

	$scope.ViewSelected_Click = function () {
		$scope.MetaDataView.ViewSelectedText = $scope.MetaDataView.ViewSelectedText == 'View selected' ? 'Show all' : 'View selected';
	};

	$scope.OpenAddSubMetaData = function () {
		var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
		$mdDialog.show({
			controller: MetaDataAddDialogController,
			preserveScope: false,
			templateUrl: 'Views/AddEditSubMetaData.html',
			parent: angular.element(document.body),
			clickOutsideToClose: true,
			fullscreen: useFullScreen,
			onComplete: function () {
				$("#submetadataForm input[id=subMetadataAlias]").focus();
			},
			bindToController: true,
			locals: {
				parentScope: $scope
			}
		})
		.then(function (answer) {

		}, function () {

		});
		$scope.$watch(function () {
			return $mdMedia('xs') || $mdMedia('sm');
		}, function (wantsFullScreen) {
			$scope.customFullscreen = (wantsFullScreen === true);
		});
	};

	function MetaDataAddDialogController($scope, $mdDialog, parentScope) {

		$scope.hide = function () {
			$mdDialog.hide();
		};
		$scope.cancel = function () {
			$mdDialog.cancel();
		};
		$scope.answer = function () {
			$mdDialog.hide();
		};

		$scope.MetaDataTextChange = CustomClassTextChange;

		function CustomClassTextChange($event) {
			if ($event.keyCode === 13) {
				$event.preventDefault();
			}
		}

		$scope.MetaDataButtonChange = function ($event, type) {
			if ($event.keyCode === 9) {
				$event.preventDefault();
				if (type == "Add")
					$("#submetadataForm input[id=subMetadataAlias]").focus();
				else if (type == "Edit") {
					$("#submetadataForm input[id=subMetadataDesc]").focus();
					$("#submetadataForm input[id=subMetadataDesc]").select();
				}
			}
		};

		$scope.SubMetaDataDisplayName = parentScope.MetaDataView.SubMetaDataDisplayName;
		$scope.SubMetaDataModel = metaDataFactory.meatDataInitialValues();

		$scope.PageEvents = {
			UserAction: 'Add',
			Save: null
		};

		$scope.PageEvents.Save = function () {
			if ($scope.SubMetaDataModel.Alias === undefined || $scope.SubMetaDataModel.Alias === '' || $scope.SubMetaDataModel.Alias.$invalid) {
				return;
			}
			$scope.SubMetaDataModel.MetaType = (parentScope.vm.selectedApp.MetaDataItem === 'CUSTOM1') ? 'CUSTOM2' : 'CUSTOM30';
			$scope.SubMetaDataModel.ParentAlias = parentScope.MetaDataModel.Alias;
			parentScope.MetaDataView.NewAddSubMetaDataList.push($scope.SubMetaDataModel);
			parentScope.MetaDataView.SubClassListTitle = (totalSubMetaListCountWithoutFilter + parentScope.MetaDataView.NewAddSubMetaDataList.length).toString() +
							' ' + parentScope.MetaDataView.SubMetaDataDisplayName + ' for ' + parentScope.MetaDataModel.Alias;

			if (parentScope.MetaDataView.SearchText.length === 0) {
				parentScope.MetaDataView.SubMatadataList.splice(parentScope.MetaDataView.NewAddSubMetaDataList.length - 1, 0, $scope.SubMetaDataModel);
			}
			else {
				if ($scope.SubMetaDataModel.Alias.indexOf(parentScope.MetaDataView.SearchText) >= 0 || $scope.SubMetaDataModel.Description.indexOf(parentScope.MetaDataView.SearchText) >= 0) {
					parentScope.MetaDataView.SubMatadataList.splice(parentScope.MetaDataView.NewAddSubMetaDataList.length - 1, 0, $scope.SubMetaDataModel);
				}
			}
			$scope.SubMetaDataModel = metaDataFactory.meatDataInitialValues();
			$mdDialog.cancel();
		};
	}

	$scope.OpenEditSubMetaData = function () {
		var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
		$mdDialog.show({
			controller: MetaDataEditDialogController,
			preserveScope: false,
			templateUrl: 'Views/AddEditSubMetaData.html',
			parent: angular.element(document.body),
			clickOutsideToClose: true,
			fullscreen: useFullScreen,
			onComplete: function () {
				$("#submetadataForm input[id=subMetadataDesc]").focus();
			},
			bindToController: true,
			locals: {
				parentScope: $scope
			}
		})
		.then(function (answer) {

		}, function () {

		});
		$scope.$watch(function () {
			return $mdMedia('xs') || $mdMedia('sm');
		}, function (wantsFullScreen) {
			$scope.customFullscreen = (wantsFullScreen === true);
		});
	};

	function MetaDataEditDialogController($scope, $mdDialog, parentScope) {

		$scope.hide = function () {
			$mdDialog.hide();
		};
		$scope.cancel = function () {
			$mdDialog.cancel();
		};
		$scope.answer = function () {
			$mdDialog.hide();
		};

		$scope.MetaDataTextChange = CustomClassTextChange;

		function CustomClassTextChange($event) {
			if ($event.keyCode === 13) {
				$event.preventDefault();
			}
		}

		$scope.MetaDataButtonChange = function ($event, type) {
			if ($event.keyCode === 9) {
				$event.preventDefault();
				if (type == "Add")
					$("#submetadataForm input[id=subMetadataAlias]").focus();
				else if (type == "Edit") {
					$("#submetadataForm input[id=subMetadataDesc]").focus();
					$("#submetadataForm input[id=subMetadataDesc]").select();
				}
			}
		};

		$scope.SubMetaDataDisplayName = parentScope.MetaDataView.SubMetaDataDisplayName;
		$scope.SubMetaDataModel = angular.copy(parentScope.MetaDataView.SelectedSubMatadataList[0]);

		$scope.PageEvents = {
			UserAction: 'Edit',
			Save: null
		};

		$scope.PageEvents.Save = function () {
			if ($scope.SubMetaDataModel.Alias === undefined || $scope.SubMetaDataModel.Alias === '' || $scope.SubMetaDataModel.Alias.$invalid) {
				return;
			}
			var tempListFilter = $filter('filter')(parentScope.MetaDataView.NewAddSubMetaDataList, {
				Alias: $scope.SubMetaDataModel.Alias
			}, true);
			if (tempListFilter.length > 0) {
				tempListFilter[0].Description = $scope.SubMetaDataModel.Description;
				tempListFilter[0].HIPAAComplaint = $scope.SubMetaDataModel.HIPAAComplaint;
				tempListFilter[0].EnableFlag = $scope.SubMetaDataModel.EnableFlag;
			}
			else {
				parentScope.MetaDataView.EditSubMetaDataList = $.grep(parentScope.MetaDataView.EditSubMetaDataList,
							   function (item, index) {
								   return item.Alias != $scope.SubMetaDataModel.Alias;
							   });

				tempListFilter = $filter('filter')(parentScope.MetaDataView.SubMatadataList, {
					Alias: $scope.SubMetaDataModel.Alias
				}, true);
				if (tempListFilter.length > 0) {
					tempListFilter[0].Description = $scope.SubMetaDataModel.Description;
					tempListFilter[0].HIPAAComplaint = $scope.SubMetaDataModel.HIPAAComplaint;
					tempListFilter[0].EnableFlag = $scope.SubMetaDataModel.EnableFlag;
				}
				parentScope.MetaDataView.EditSubMetaDataList.push(tempListFilter[0]);
			}
			tempListFilter = [];

			$scope.SubMetaDataModel = metaDataFactory.meatDataInitialValues();
			parentScope.setSubMetaDataListContextMenuObject();
			$mdDialog.cancel();
		};
	}

	$scope.SaveCurrentEditContent = function () {
		$scope.MetaDataView.IsPosting = true;
		var metaDataPromise = saveMetaData();
		metaDataPromise.then(function (response) {
			if (response && response.Status === 0 && response.ErrorMessage.length === 0) {
				$mdDialog.show($mdDialog.alert()
						   .parent(angular.element(document.body))
						   .clickOutsideToClose(true)
						   .title('Success')
						   .textContent('Metadata succesfully updated.')
						   .ariaLabel('Success')
						   .ok('OK')
					   );
				initializeSubMetaDataView();
				angular.copy($scope.MetaDataModel, $scope.OriginalMeatData);
				fillSubClassGrid();
			}
			else if (response && response.ErrorMessage) {
				$mdDialog.show($mdDialog.alert()
							.parent(angular.element(document.body))
							.clickOutsideToClose(true)
							.title('Warning!')
							.textContent(response.ErrorMessage)
							.ariaLabel('Warning!')
							.ok('OK')
						);
			}
			$scope.MetaDataView.IsPosting = false;
		}, function (response) {
			$scope.MetaDataView.IsPosting = false;
			if (response && response.ErrorMessage) {
				$mdDialog.show($mdDialog.alert()
							.parent(angular.element(document.body))
							.clickOutsideToClose(true)
							.title('Warning!')
							.textContent(response.ErrorMessage)
							.ariaLabel('Warning!')
							.ok('OK')
						);
			}
		});
	};

	function saveMetaData() {
		var deferredarray = [];
		return $q(function (resolve, reject) {
			var errorMesssage = '';
			var status = 0;

			$scope.MetaDataModel.MetaType = $scope.vm.selectedApp.MetaDataItem;
			$scope.MetaDataModel.ParentAlias = '';
			$scope.MetaDataModel.HIPAAComplaint = $scope.MetaDataModel.HIPAAComplaint === true || $scope.MetaDataModel.HIPAAComplaint === "true";
			$scope.MetaDataModel.EnableFlag = $scope.MetaDataModel.EnableFlag === true || $scope.MetaDataModel.EnableFlag === "true";
			$scope.MetaDataModel.libraryName = $scope.vm.selectedLibrary;


			var apiUrlExist = metaDataFactory.getAPIUrl('GETMETADATAEXIST', $scope.MetaDataModel);
			exstMetadata = MetaDataService.getExstMetaDataList(apiUrlExist, $scope.mc.loginModel.AuthKey);
			var deferredexstMetadata = $q.defer();
			exstMetadata.then(function (aresponse) {
				deferredexstMetadata.resolve(aresponse);
				deferredarray.push(deferredexstMetadata.promise);
				if (aresponse && aresponse.data && aresponse.data.data) {
					if (aresponse.data.data.length == 0) {
						noDataExist = true;
						errorMesssage = $scope.vm.selectedApp.CurrentTab + " does not contain " + $scope.MetaDataModel.Alias;
						$scope.MetaDataList = $.grep($scope.MetaDataList,
							  function (item, index) {
								  return item.Alias != $scope.MetaDataModel.Alias;
							  });
						$q.all(deferredarray).then(function () {
							resolve({ Status: -1, ErrorMessage: errorMesssage });
						}, function () {
							resolve({ Status: -1, ErrorMessage: errorMesssage });
						});
					}
					else {
						noDataExist = false;
						var apiUrl = metaDataFactory.getAPIUrl('PUTMETADATA', $scope.MetaDataModel);
						var apiModel = metaDataFactory.getMetaAPIModel($scope.MetaDataModel, $scope.vm.selectedLibrary);
						$scope.mc.getlogDetails("Debug", 'Method:POST;URL:' + JSON.stringify(apiUrl) + 'Request Body:' + JSON.stringify(apiModel));

						var deferredClass = $q.defer();
						var UpdateData = MetaDataService.EditMetaData(apiUrl, $scope.mc.loginModel.AuthKey, apiModel);
						UpdateData.then(function (response) {
							deferredClass.resolve(response);
							if (response && !response.data.error) {
								$scope.result = angular.equals($scope.MetaDataModel, $scope.OriginalMeatData);
								if (!$scope.result)
									$scope.mc.setSecurityLogDetails("Info", 'Success', $scope.vm.selectedApp.MetaDataItem, 'Custom Update', JSON.stringify(apiModel));

								if (selectedRowIndex >= 0) {
									$scope.MetaDataList[selectedRowIndex].Description = $scope.MetaDataModel.Description;
									$scope.MetaDataList[selectedRowIndex].HIPAAComplaint = $scope.MetaDataModel.HIPAAComplaint;
									$scope.MetaDataList[selectedRowIndex].EnableFlag = $scope.MetaDataModel.EnableFlag;
								}
								var tmpList = [];
								tmpList = angular.copy($scope.MetaDataList);
								$scope.selected = [];
								$scope.MetaDataList = [];
								$scope.MetaDataList = angular.copy(tmpList);
								tmpList = [];

							} else {
								status = -1;
								$scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.vm.selectedApp.MetaDataItem, 'Custom Update', JSON.stringify(apiModel));

								if (response && response.data && response.data.details && response.data.details.message)
									errorMesssage = response.data.details.message;
								else if (response && response.data && response.data.error && response.data.error.message)
									errorMesssage = response.data.error.message;
								else
									errorMesssage = "Metadata update failed due to unknown errors";
							}
						}, function (response) {
							deferredClass.resolve(response);
							$scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.vm.selectedApp.MetaDataItem, 'Custom Update', JSON.stringify(apiModel));
							status = -1;
							if (response && response.data && response.data.details && response.data.details.message)
								errorMesssage = response.data.details.message;
							else if (response && response.data && response.data.error && response.data.error.message)
								errorMesssage = response.data.error.message;
							else
								errorMesssage = "Metadata update failed due to unknown errors";
						});
						deferredarray.push(deferredClass.promise);

						var deferredAddSubMetaData = $q.defer();
						var subMetaDataAddPromise = addNewSubMetaDataList();
						subMetaDataAddPromise.then(function (responseAddSubMetaData) {
							deferredAddSubMetaData.resolve(responseAddSubMetaData);
							if (errorMesssage.length === 0 && responseAddSubMetaData && responseAddSubMetaData.ErrorMessage.length > 0) {
								errorMesssage = responseAddSubMetaData.ErrorMessage;
							}
						});
						deferredarray.push(deferredAddSubMetaData.promise);

						var deferredEditSubMetaData = $q.defer();
						var subMetdataEditPromise = editSubMetaDataList();
						subMetdataEditPromise.then(function (responseEditSubMetaData) {
							deferredEditSubMetaData.resolve(responseEditSubMetaData);
							if (errorMesssage.length === 0 && responseEditSubMetaData && responseEditSubMetaData.ErrorMessage.length > 0) {
								errorMesssage = responseEditSubMetaData.ErrorMessage;
							}
						});
						deferredarray.push(deferredEditSubMetaData.promise);

						$q.all(deferredarray).then(function () {
							resolve({ Status: 0, ErrorMessage: errorMesssage });
						}, function () {
							resolve({ Status: -1, ErrorMessage: errorMesssage });
						});
					}
				}
				else {
					errorMesssage = $scope.vm.selectedApp.CurrentTab + " does not contain " + $scope.MetaDataModel.Alias;
					$q.all(deferredarray).then(function () {
						resolve({ Status: -1, ErrorMessage: errorMesssage });
					}, function () {
						resolve({ Status: -1, ErrorMessage: errorMesssage });
					});
				}


			}, function (aresponse) {
				errorMesssage = $scope.vm.selectedApp.CurrentTab + " does not contain " + $scope.MetaDataModel.Alias;
				$q.all(deferredarray).then(function () {
					resolve({ Status: -1, ErrorMessage: errorMesssage });
				}, function () {
					resolve({ Status: -1, ErrorMessage: errorMesssage });
				});

			});


		});
	}

	function addNewSubMetaDataList() {
		var deferredarray = [];

		return $q(function (resolve, reject) {
			var errorMesssage = '';
			var status = 0;

			angular.forEach($scope.MetaDataView.NewAddSubMetaDataList, function (subMetaDataModel) {
				var deferredItem = $q.defer();
				var apiUrl = metaDataFactory.getAPIUrl('POSTMETADATA', subMetaDataModel);
				var apiModel = metaDataFactory.getMetaAPIModel(subMetaDataModel, $scope.vm.selectedLibrary);
				$scope.mc.getlogDetails("Debug", 'Method:POST;URL:' + JSON.stringify(apiUrl) + 'Request Body:' + JSON.stringify(apiModel));

				var promise = MetaDataService.addMetaData(apiUrl, $scope.mc.loginModel.AuthKey, apiModel);
				promise.then(function (response) {
					deferredItem.resolve(response);
					if (response && response.status === 200) {
						$scope.mc.setSecurityLogDetails("Info", 'Success', ($scope.vm.selectedApp.MetaDataItem === 'CUSTOM1') ? 'CUSTOM2' : 'CUSTOM30', 'Custom Add Child', JSON.stringify(apiModel));
					} else {
						status = -1;
						$scope.mc.setSecurityLogDetails("Info", 'Failure', ($scope.vm.selectedApp.MetaDataItem === 'CUSTOM1') ? 'CUSTOM2' : 'CUSTOM30', 'Custom Add Child', JSON.stringify(apiModel));

						if (response && response.data && response.data.details && response.data.details.message)
							errorMesssage = response.data.details.message;
						else if (response && response.data && response.data.error && response.data.error.message)
							errorMesssage = response.data.error.message;
						else
							errorMesssage = "Posting Metadata failed due to unknown errors";
					}
				}, function (response) {
					deferredItem.resolve(response);
					status = -1;
					$scope.mc.setSecurityLogDetails("Info", 'Failure', ($scope.vm.selectedApp.MetaDataItem === 'CUSTOM1') ? 'CUSTOM2' : 'CUSTOM30', 'Custom Add Child', JSON.stringify(apiModel));

					if (response && response.data && response.data.details && response.data.details.message)
						errorMesssage = response.data.details.message;
					else if (response && response.data && response.data.error && response.data.error.message)
						errorMesssage = response.data.error.message;
					else
						errorMesssage = "Posting Metadata failed due to unknown errors";
				});
				deferredarray.push(deferredItem.promise);
			});
			$q.all(deferredarray).then(function () {
				resolve({ Status: 0, ErrorMessage: errorMesssage });
			}, function () {
				resolve({ Status: -1, ErrorMessage: errorMesssage });
			});
		});
	}

	function editSubMetaDataList() {
		var deferredarray = [];

		return $q(function (resolve, reject) {
			var errorMesssage = '';
			var status = 0;

			angular.forEach($scope.MetaDataView.EditSubMetaDataList, function (subMetaDataModel) {
				var deferredItem = $q.defer();
				subMetaDataModel.MetaType = ($scope.vm.selectedApp.MetaDataItem == 'CUSTOM1') ? 'CUSTOM2' : 'CUSTOM30';
				subMetaDataModel.ParentAlias = $scope.MetaDataModel.Alias;

				var apiUrl = metaDataFactory.getAPIUrl('PUTMETADATA', subMetaDataModel);
				var apiModel = metaDataFactory.getMetaAPIPUTModel(subMetaDataModel, $scope.vm.selectedLibrary);
				$scope.mc.getlogDetails("Debug", 'Method:POST;URL:' + JSON.stringify(apiUrl) + 'Request Body:' + JSON.stringify(apiModel));

				var UpdateData = MetaDataService.EditMetaData(apiUrl, $scope.mc.loginModel.AuthKey, apiModel);
				UpdateData.then(function (response) {
					deferredItem.resolve(response);
					if (response && response.status == 200) {
						$scope.mc.setSecurityLogDetails("Info", 'Success', ($scope.vm.selectedApp.MetaDataItem === 'CUSTOM1') ? 'CUSTOM2' : 'CUSTOM30', 'Custom Update Child', JSON.stringify(apiModel));
					} else {
						status = -1;
						$scope.mc.setSecurityLogDetails("Info", 'Failure', ($scope.vm.selectedApp.MetaDataItem === 'CUSTOM1') ? 'CUSTOM2' : 'CUSTOM30', 'Custom Update Child', JSON.stringify(apiModel));

						if (response && response.data && response.data.details && response.data.details.message)
							errorMesssage = response.data.details.message;
						else if (response && response.data && response.data.error && response.data.error.message)
							errorMesssage = response.data.error.message;
						else
							errorMesssage = "Metadata update failed due to unknown errors";
					}
				}, function (response) {
					deferredItem.resolve(response);
					status = -1;
					$scope.mc.setSecurityLogDetails("Info", 'Failure', ($scope.vm.selectedApp.MetaDataItem === 'CUSTOM1') ? 'CUSTOM2' : 'CUSTOM30', 'Custom Update Child', JSON.stringify(apiModel));

					if (response && response.data && response.data.details && response.data.details.message)
						errorMesssage = response.data.details.message;
					else if (response && response.data && response.data.error && response.data.error.message)
						errorMesssage = response.data.error.message;
					else
						errorMesssage = "Metadata update failed due to unknown errors";
				});
				deferredarray.push(deferredItem.promise);
			});
			$q.all(deferredarray).then(function () {
				resolve({ Status: 0, ErrorMessage: errorMesssage });
			}, function () {
				resolve({ Status: -1, ErrorMessage: errorMesssage });
			});
		});
	}

	function enableSubClassItemList() {
		var errorMesssage = '';
		var status = 0;
		var deferredarray = [];

		if ($scope.MetaDataView.SelectedSubMatadataList.length === 0) return;

		var confirm = $mdDialog.confirm().title('Warning!').theme('confirm-dialog').textContent('Are you sure you want to enable the selected items?').
			ariaLabel('').ok('Yes').cancel('No');
		$mdDialog.show(confirm).then(function () {

			angular.forEach($scope.MetaDataView.SelectedSubMatadataList, function (subMetaDataModel) {

				var blnItemFound = false;

				for (iNewItemCount = 0; iNewItemCount < $scope.MetaDataView.NewAddSubMetaDataList.length; iNewItemCount++) {
					if ($scope.MetaDataView.NewAddSubMetaDataList[iNewItemCount].Alias === subMetaDataModel.Alias) {
						blnItemFound = true;
						$scope.MetaDataView.NewAddSubMetaDataList[iNewItemCount].EnableFlag = true;
						break;
					}
				}
				if (!blnItemFound) {
					var deferredItem = $q.defer();
					for (iEditItemCount = 0; iEditItemCount < $scope.MetaDataView.EditSubMetaDataList.length; iEditItemCount++) {
						if ($scope.MetaDataView.EditSubMetaDataList[iEditItemCount].Alias === subMetaDataModel.Alias) {
							$scope.MetaDataView.EditSubMetaDataList[iEditItemCount].EnableFlag = true;
							break;
						}
					}
					subMetaDataModel.MetaType = ($scope.vm.selectedApp.MetaDataItem == 'CUSTOM1') ? 'CUSTOM2' : 'CUSTOM30';
					subMetaDataModel.ParentAlias = $scope.MetaDataModel.Alias;
					subMetaDataModel.EnableFlag = true;

					var apiUrl = metaDataFactory.getAPIUrl('PUTMETADATA', subMetaDataModel);
					var apiModel = metaDataFactory.getMetaAPIPUTModel(subMetaDataModel, $scope.vm.selectedLibrary);
					$scope.mc.getlogDetails("Debug", 'Method:POST;URL:' + JSON.stringify(apiUrl) + 'Request Body:' + JSON.stringify(apiModel));

					var UpdateData = MetaDataService.EditMetaData(apiUrl, $scope.mc.loginModel.AuthKey, apiModel);
					UpdateData.then(function (response) {
						deferredItem.resolve(response);
						if (response && response.status == 200) {
							//$scope.mc.setSecurityLogDetails("Info", "Response: Success " + $scope.mc.loginModel.UserName + " updated-enabled (" + subMetaDataModel.Alias + ")" +
							//$scope.MetaDataView.SubMetaDataDisplayName + " for " + $scope.MetaDataModel.Alias);
							$scope.mc.setSecurityLogDetails("Info", 'Success', subMetaDataModel.Alias, ' Child Custom Enable')
						} else {
							subMetaDataModel.EnableFlag = false;
							status = -1;
							//$scope.mc.setSecurityLogDetails("Error", 'Response:' + JSON.stringify(response));
							$scope.mc.setSecurityLogDetails("Info", 'Failure', subMetaDataModel.Alias, 'Child Custom Enable')

							if (response && response.data && response.data.details && response.data.details.message)
								errorMesssage = response.data.details.message;
							else if (response && response.data && response.data.error && response.data.error.message)
								errorMesssage = response.data.error.message;
							else
								errorMesssage = "Metadata update failed due to unknown errors";
						}
					}, function (response) {
						deferredItem.resolve(response);
						subMetaDataModel.EnableFlag = false;
						status = -1;
						$scope.mc.setSecurityLogDetails("Info", 'Failure', subMetaDataModel.Alias, 'Child Custom Enable')

						if (response && response.data && response.data.details && response.data.details.message)
							errorMesssage = response.data.details.message;
						else if (response && response.data && response.data.error && response.data.error.message)
							errorMesssage = response.data.error.message;
						else
							errorMesssage = "Metadata update failed due to unknown errors";
					});
					deferredarray.push(deferredItem.promise);
				}
			});
			$q.all(deferredarray).then(function () {
				$scope.setSubMetaDataListContextMenuObject();
			}, function () {
				$scope.setSubMetaDataListContextMenuObject();
			});
		});
	}

	function disableSubClassItemList() {
		var errorMesssage = '';
		var status = 0;
		var deferredarray = [];

		if ($scope.MetaDataView.SelectedSubMatadataList.length === 0) return;

		var confirm = $mdDialog.confirm().title('Warning!').theme('confirm-dialog').textContent('Are you sure you want to disable the selected items?').
			ariaLabel('').ok('Yes').cancel('No');
		$mdDialog.show(confirm).then(function () {

			angular.forEach($scope.MetaDataView.SelectedSubMatadataList, function (subMetaDataModel) {
				var blnItemFound = false;

				for (iNewItemCount = 0; iNewItemCount < $scope.MetaDataView.NewAddSubMetaDataList.length; iNewItemCount++) {
					if ($scope.MetaDataView.NewAddSubMetaDataList[iNewItemCount].Alias === subMetaDataModel.Alias) {
						blnItemFound = true;
						$scope.MetaDataView.NewAddSubMetaDataList[iNewItemCount].EnableFlag = false;
						break;
					}
				}
				if (!blnItemFound) {
					var deferredItem = $q.defer();
					for (iEditItemCount = 0; iEditItemCount < $scope.MetaDataView.EditSubMetaDataList.length; iEditItemCount++) {
						if ($scope.MetaDataView.EditSubMetaDataList[iEditItemCount].Alias === subMetaDataModel.Alias) {
							$scope.MetaDataView.EditSubMetaDataList[iEditItemCount].EnableFlag = false;
							break;
						}
					}
					subMetaDataModel.MetaType = ($scope.vm.selectedApp.MetaDataItem == 'CUSTOM1') ? 'CUSTOM2' : 'CUSTOM30';
					subMetaDataModel.ParentAlias = $scope.MetaDataModel.Alias;
					subMetaDataModel.EnableFlag = false;
					var apiUrl = metaDataFactory.getAPIUrl('PUTMETADATA', subMetaDataModel);
					var apiModel = metaDataFactory.getMetaAPIPUTModel(subMetaDataModel, $scope.vm.selectedLibrary);

					$scope.mc.getlogDetails("Debug", 'Method:POST;URL:' + JSON.stringify(apiUrl) + 'Request Body:' + JSON.stringify(apiModel));

					var UpdateData = MetaDataService.EditMetaData(apiUrl, $scope.mc.loginModel.AuthKey, apiModel);
					UpdateData.then(function (response) {
						deferredItem.resolve(response);
						if (response && response.status == 200) {
							//$scope.mc.setSecurityLogDetails("Info", "Response: Success " + $scope.mc.loginModel.UserName + " updated-disabled (" + subMetaDataModel.Alias + ")" +
							//				 $scope.MetaDataView.SubMetaDataDisplayName + " for " + $scope.MetaDataModel.Alias);
							$scope.mc.setSecurityLogDetails("Info", 'Success', subMetaDataModel.Alias, 'Child Custom Disable', '')
						} else {
							subMetaDataModel.EnableFlag = true;
							status = -1;
							//$scope.mc.setSecurityLogDetails("Error", 'Response:' + JSON.stringify(response));
							$scope.mc.setSecurityLogDetails("Info", 'Failure', subMetaDataModel.Alias, 'Child Custom Disable', '')

							if (response && response.data && response.data.details && response.data.details.message)
								errorMesssage = response.data.details.message;
							else if (response && response.data && response.data.error && response.data.error.message)
								errorMesssage = response.data.error.message;
							else
								errorMesssage = "Metadata update failed due to unknown errors";
						}
					}, function (response) {
						deferredItem.resolve(response);
						subMetaDataModel.EnableFlag = true;
						status = -1;
						//$scope.mc.setSecurityLogDetails("Error", 'Response:' + JSON.stringify(response));
						$scope.mc.setSecurityLogDetails("Info", 'Failure', subMetaDataModel.Alias, 'Child Custom Disable', '')

						if (response && response.data && response.data.details && response.data.details.message)
							errorMesssage = response.data.details.message;
						else if (response && response.data && response.data.error && response.data.error.message)
							errorMesssage = response.data.error.message;
						else
							errorMesssage = "Metadata update failed due to unknown errors";
					});
					deferredarray.push(deferredItem.promise);
				}
			});
			$q.all(deferredarray).then(function () {
				$scope.setSubMetaDataListContextMenuObject();
			}, function () {
				$scope.setSubMetaDataListContextMenuObject();
			});
		});
	}
}