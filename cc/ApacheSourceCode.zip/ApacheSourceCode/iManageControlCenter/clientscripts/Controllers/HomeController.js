﻿app.controller("HomeController", homeController);
homeController.$inject = ['$scope', '$log', '$state', '$location', '$rootScope', '$timeout', 'HomeService', 'homeFactory', '$http', '$filter', 'captionsFactory', 'CaptionService', '$cookies', '$mdDialog', '$mdMedia', '$interval', '$window', '$q', 'loginService', 'databasesFactory', 'userFactory'];

function homeController($scope, $log, $state, $location, $rootScope, $timeout, HomeService, homeFactory, $http, $filter, captionsFactory, CaptionService, $cookies, $mdDialog, $mdMedia, $interval, $window, $q, loginService, databasesFactory, userFactory) {
    var vm = this;

    //functions for menu-link and menu-toggle

    $scope.SelectedDBName = '';
    vm.isSideNavOpen = true;
    vm.isOpen = isOpen;
    vm.toggleOpen = toggleOpen;
    vm.setActiveSection = setActiveSection;
    vm.isCurrentSection = isCurrentSection;
    vm.headerNavigationMenu = undefined;
    vm.headerNavigationSelectedMenu = undefined;
    vm.selectedApp = homeFactory.selectedApp;
    vm.showmask = false;
    vm.currentdate = new Date();
    vm.filterhomevalue = [];
    vm.UserPhoto = null; // = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAIAAABt+uBvAAAACXBIWXMAAABIAAAASABGyWs+AAAACXZwQWcAAABgAAAAYAB429n0AAA1mklEQVR42rW9B3yN5xv/f589sodMGRJkiewhSwSJkZBBhAghW2SIhFiJkGFviha196it2qpvq62WVlFUbRkytXTQ4vyv+76f5znPOTn01//r9/O6XnnFyck47/O51v3c9/WgIMuIYMu+fazAIkOt+4Va9w+z7h9uMyDcZmCETXSkTUyk7aB+2AZHdR3Sv+vQAXaxA+3iBtoNi7YfFmM/fJB9/GD7hMEOiUMcksCGOowY6jgyzjEZbJjjqGHdUoZjGx3vBDYGLMEplbWxic7Ykt5p9DnwZO4b47HhHwU/Fn44/Ar8ixxHwW+MdRyJ/wDylwxxSIS/Cv48+CPB4A+GPxv++P5dY6O6Do2yHQIvCl4avEB4mfBi4SXDCw/FFgUoiPUFOIjQiXw3HfhxgAZ+NKUTjenAb1WjGUrQxDJo8J+LuThxXPALS3ROTXSiLzttBLZxYCOdxzPWHVsyMfo59yX6TPiWJGxj4YckkB9FeBFSTpjUcD4mTIrBNMg+gWKKxowwJngh/fmMbAe9gxHS1M4ANR3ynVg4lA4nHDuMBn4r0NFCQ7hgNJRLAsNFDWUkEMEI0qmN6jGBtYkpumwUNvwE7lsoODUs57GsrIAUwUQEpaUmIqUE+LOjWSn1tyOMugKjwRRTX5voCIbRAD4jpFs7HB21W8VywhmkFg7jUMNY1fDQUPdJIzIBLuQV8nCM7pGBrSdYJtiYnllaRh/HRp6pxQt+4EiiLEqK+iCHaZgmJsbjCCNWSpy7/QsjxNcOfLkvocMGHc6tQDhsxMFoErFwHKlwAE0KRZPQGQ3mMgG4EEVgHGMIi1QXsOxU1+yxYC45Y13BcjtZDv0SPA0/2SWbgANkACuDwmI1xZBK1MJE3rZYx2TW4xJZKQ2nUqKM+tsOfQcjxNcOn05/Ph0S5wZhn+ILh4013fiqSWMiC6MXygWgZMIrJCBy0rDlgo1zywMb7zaJGPeJhtHngKVRZMSAL5WYBikSrThMCWpMKWxg4kuJx4i4my5GOB4hLc96G53BHB0sHJKkunHCYVRD0dDgQpyIOA4WC+WSO86VIZKOLT/dPX+C+2TWCjoZ86V0MLd8NS9XBhbWlJqUBiZ4nzinox4Xx0qJ727RxN3ezQj9Kx2SyBNZOkye4oUbxqE00GBXyiIeRLmAWCYRLpjIRI+Cie5ghRkehRm9ijI9qBVn9irOIgaf4P+Sx+EJ8LSJYPAtHpgaJTueknLLpT5IMGWk8PxuBBub+B7HY4QjNxeSBjAhSYMRzWtIKypzdNS53IHS4acqVjgkQzGxhkGTSSTDoqF6cWe4YCLwsnsVERBTsj2x5XiW5PSmNjWXWA428ohnCX1OFhgGB7AoL0Zi493yWe/LxZhc1JjgT2I8zpmVkhMuBdjIrYORlo5o7ke8ekczKqvp4J+lpsPmKbVwemDhQKIh0VcDDfWdiQwXFgrDojTXqzTPq4zYtEm6jP1qGTwZU2N5wY9iSLlTTRHvc83j/A68G2IT/GE8KTHBWx2SSHbTZER8zVaDEeLRGaKTDq/MUWdxJuJ0H8/6FMTgLA5NujtGA389vAaqlxxQCkBhicCLz/eenu8zfbJPOViB7wywQt+ZnNFHCnxm0CfAkzlkHKwsQgp+Pud6xO+Y8MQFJlZKGowYd9PJiJTaAITW2YhfK2vEnbfSYVI4iTgTiXAyQd40BjPexKApziJ6oVwoFDUOv5lFfrPAiv1nE5szRdPo4/Q58GT6XQwsb0LKC5PKZr2PxTSJOh3jcTjNMcE7iURu0qmMHtZNB6NoDUZMnY060yE5i4nKPDoppGNQx2Oapzifgndvgns+g8ajiKDBfoTReE+jXEAamIjfbJZCRUlA5VRsc0sZqyKGP4cHS/DHypKACgaZH+ZF9UVJsZhKKCbO6TQ8jkiJTXBcrfRWRlx9RHsRxARmtlbmZXR1VCba4dHpgenQ0oYRDgk3ExmHUquGkwxVCrzIEv8KeM2lgXPLAqvKAudNwzZ/WtD86cFg1WoLwg/iLwXOK8NWVRpYhWH5V1BxqUl5l4M2qd8RpwMpFXIex0ipZxZmhN3tnYzU9RHbi9gOQTT00BaUXw1SOsMZz3o7HYg4bvkkQ9FYU0JVA2ioH1G9gAoIFwIFcATNLw+qnhFcQ6wWPpZjqy5nPsHGPQhPnhE8rzyoqjywahr+CVRcFVRT1PsgnHFqIlKiHoerJ8IohzDKSGZCEo8Rm9c0aki2X4NghLRCD7/eYbUzphOdLBp0aApn6TBhGN5PqhoODfgLy6W6nBLpUzuzD/kYUjc7dGFl2NL5EStr+q6pjVxbG7kGPqnuu3p+xCp4EKw6YtWMsFWlISvLQpZND15Yjn9OFdEUg4kGKfilNDZpSYmWl+BuNCTpYpTCZ0R7kYE08XeNRewKBi9tOY7Qyuid6NCgo3YrCAFQv2Dh+EynDsWoJpBBw+NSNytkwZywRfMiVgCOush18/uunBlSW+A/bULv3GS31Lge8dHdYiId+oXZhYfbhcHHEPuBMz3jNwSMWRyYOzd4TnnI0rKQFdMIqWkMpkqKicYmKqVszxJSDQCjAsiqNCQBI9KdTKDxiI3ZTGdLa0i6isQFI8Q5F7t8gTsJthrsTCcT02FrHPj1oGf4UzjhsD4FDoXREO+omYHFUgNiAaVU910FGpkbvrQ4YFaK+7hw+wh38562BhbGcn2FRCwVIbEQCQXEhEggQPAvzRx95Y4u90ZfekrPepru83Jf65dQFVQ+vc/isuAl04JqpgfOpWqisQmKAxq/czynUncjjPL5OqKMSF6jNeRots7mghFlFIf4zjWUdS6ODq13aM7i0jkJyQUZTIFTkudViiOOD43EIBwca4hDUTTYj+ZHrACxzAlbmO1dOLDbYGcTR0OZFHCIhJiIRIRkYqQQI6VEoAcmFepLhQZSoUgszLEV3ggSXg0VXAlHP4Shy33QtwHoKx/0ibdyl6/vksDMmcG1U4OXTQuqLgus5EuJYYTdrRj+VIYR1RETs2nu57VsmBHb97OOhsjKaTwjH+xceJ2UdhKEThqT0dmoPJ7SYULyVC4eU7ciwqmaTgNwn1rwpnkYzdriwFmDnIZ2M3YECqALiZDiQAQHMYIGHqFmIEVIiAaaoe/6oO+j0I9D0Y3hglsJgp/iRdfiRFcGCS9HoUuh6EIgOuzfY0VganlwXWnwYkh5pZhRBc1xuhix8Ygy6g464mrI0aSnZdZGuOVaxHOuJA3nck7Fa4CkVqb1Dhd3tOjAnwJuBQkYgvG0oHmQd6hw5oYvq41cXehfHtI1xFRhCF4DYoEXD+rgs+hsehIkFSNTKdrhha5Go+/j0a0xgjvpwnsZwnuZwjsZotvp4ltjxddGiq/EiX7oj74OFRwJcl4SlFEWvKg0qI5ICZcC8IfRkMQwor6GSySc++Eth0KXCdjOY+kiNw3Y/KyPaNHMOhfXiOIuFBRImyxNOoV8z2Lo4FRVxQRjIhwINNP7VPW1jzKQycCPwIOo4+i9DYoUwCEDGTYjGRKKULgZutgfXUoU3EgT3skS3c8XPiwWPZoqelQqflgqeTBVcq9IfDtHcmOc7Gqi+EoM+jpMuDs4oCqorCRoSRkumoDRHA1GTMyezOR+aEdwy4aLI7qK1MnRkgAO4mIzrZiBojr04MCMW1DQJG0j2JylTacsoIqLx5VhSyASj3JPs9K3AG+SYzQCnZIBIvoyjAaeI0La/wZboWvxwitp4tu5ImDxoFT8uFxcP1vcUClpmCdpmC+tr5I9rpQ9LJfeLZTdmii7NkJ8ZSA6F2q0JiipNGjB1MCaqayOuJhN81o6YTTWNZdL/GQJiXG04YyjMeU1ovIBZrzMRaoesrgzmqYtHJiZeofmLBp3GM8KZOkE10DEmRVaF2wbLBEJIPSCZHTqBWRiKENSIcPCUCZwsxb29xAmBaAxfRB87G2PQi0Fl0aIb+SIfymWPJgueTRH2lAlbayRNi2QPVkse7JU1rRM3rRU3rhYXl8rfzhHfrdYdnOCHJheikR7g71nB86aEriQzyjXq4zkflwfaQds0tCSymjMcI3yOhHx5DOKi80kr1PnytIMPbjegYxOozL2rEC1dqCiKwma7WzSDcIN5CN9qUArsugR1RgrBDKCxspQHB8gX5Otd2Wx4tlmyZtdItVupNqD7eVWdHk6+nas6Fah9G659FGFtL5a1rRQ9mSZrHmFrGW1vGWNvGWdvHmdonmtonm1omm5or5O/mC2/JfJ8uujZeBxp0KsagLzigMXUUY0r5H6aAoJRqyj4WCUwTkazWhctAY4aAhPPmTVnZ/XGeeiBSEOPYQOeDXNWTSd03ahOmL1ZL8ycCuIOHw0FAoYyMREIYT4Av/szWWVycpraxWqkzLVWZnqhFJ12EC1T6naJVHtEKi2I9VOpPoQPZoqvl4kfzBX9rhG3rhE3rxS3rJW3vqeom2jsvUDZRvYJvxJy/t6LRuUzWuVTcsUj+fL706V/5Qu/zEWfR6qXBqYWhy4EMdskvtJ1wbBaAoNRlxlpBYRjtapJFrTSDQCUfkM78bJJ42JzWxeh9QILTIoM4d1LlAszeiQs6h2oCEo8J9uoTQhdIR8NMDFSC4wlgvN9cV6Iog4islxpvc3GajOOTefj/7x49E/n4779YTHm6OGqqP6rw8Zq/bKVTtFb7ahN1vR02rRzVLFwxpl4xLFk1WK5vXK1veV7ZuV7R8q27cq27fptW/Xa9+mbNuq17ZFD5Nar3yySlm/QH6/XH4zU35lmOiLMPHKgISiwAUluIZUB2wIRpyjqUXknK4uHVkRIV7y0pQPWQAbhxcxaOYC5yqFZoeGHug8IVPgjB5cUxW+fFpwla2hNZ8OQYOM5EJjhdBUKeyiL1Ig5OrY9Vh191/Pehz9uHr63lMjlxwYMOP94bU7Snad2Xxiw71jIaoT+m8Om6j2KlU7RKod6O81gruzFA8X6jWtVmI6IJkPAYqyfadeB9guvY7d+CP8F0gBptbNei0bleBxDQsVD2ZgRt8PF30ZJljhH18YgBnBWwsvQcvRuBYEyiJWRGM4EaHO0YfIJ4Mpmql8PIqze0PmKmOdi4Ye3HnOCV0EfYNHFzeIO5SOHinzQDigGkBjrie0MBApBWhgROgvB6MefxIx48DZATO2WnuGOTt1GzywX3CAn22P3hF5Cwv3X/zi6DjVCeM3h02JjoSqD1DDfPmDxfpP3tNv2aTXCkrZod++S79jt37HHv2OvcT2ENvNYtqC3e0JZgQ6kt3IkF0eJjofIl7sn1IYUDcFi4hzNCIiN7YF6Zmp2X+MpgvYiNdYMMlLHX0Y+eDVL9xteU+DVot1Lhx6oPOs6bs6xmkw0NGjdEgtAz4F4cYMhKMnsjaS6gtQ0rBhbecLWk97Fu87HzqxQiEVxkX3v/L9pZaW5ob6xxNSR4kR8o1Jzt7zw6VjiaqTBm8Omqj2SFVbUOsC6YNlBk82GrR8aNC6w6B9t377XoMOsH2atpdltI3oaL2yaaUCIte9Uun1dOl3Q4QfB8qr/LILA6qL/GbkE0eDjEbLa56IdKQzRLt2Xu1D6mZ2NYNEH7V8iknmgi60PIgJPZN8SwykcrmY9lBAB0ccExAOdiuhjbHEUIRGxg5+cGmv6qzj6kPrYmZsgjDdw8nxcX39Xy9eNjQ0qFSq7du2CgRC6C5CU4vnHv3s6YmeqqPGb/bpq7YJfl0qebjc8Mkmw5bthm27DYBO+z5DsA5sb2H0IQ5VkN0al8ofzZXdKZL+OEYKNechP8tp/tML/SsLfPEKdw5fRDQS9WDSGa2JaAeLuM4riWkstORTqC2fwLk4r/epnR2ycF7Ecs8uHjRt6ZHqRu1W+iJbY6mJGMWEeF7//rtX32bcO+KVtfPbnr39IYu59nD6+datN2/evPz770vfXXTr7iQCDYoFZoZ6aevPfX48V3VS/xWIaKf42TIAZNS0xahlh1HbbsO2vYYUUNs++okBNTWjXfoQpNo2Q8BWPFkhr6+TPZgp/TlXcjlR8lUY2ugbUBgwH0drUjpiEWlHItx8sKvXWESI+pdG166ufZjkpS0fkrnAucZ5ZsnEAi7ugHYoHUsDka2J1EIp6OVo8fmpQ20Pf3jzcfePj+UkLfnIRCkFEDIBCvDynDVt6rgxo8P7BC2omW9tZqiAwhKhAYXLtp/Z+Oak6Zsjpqpd0ucAaIVR04fGLbuMW/cYt+0zIgakjFr3GLVR28tqioSk9h16bSCiDYrmVfLGhfLHldK7xZLr48QXB4vO+ovm+46b7D+vwLecF4lwE0uaD63CmgGEV1RJ50X8C2d3qH1yaWMB38/Ix1cj+oB8wL88zF3FRD76hI4JS8fGSNLVWGypJ1xdN6Ot6VHzjUOqU4Y7ji0cVrnJTIrgOeZ6SE+I5LhjRw6Wxtnjx9iYKkwVyFQoiEgrWX3myJ8nbFVHAZD86VLZ/ZXGTVtNWnaZAKDWvcat+4xagc5u49ZdRth2AyAjRlDggHsM2nfqt21Vtm1UtKyWNS2S1c+T3p8m+Tlb9MMI8YUItMvHsdi/stBvFq9uJDWRKy9Us0UjwEE8/wL5TIBnEP9iSucczylc8uLkA1bdd3W2T6G+VAptFACiRSBEZfAsayOxvam0iwIlxfR5ePNiU8ODZ7e2qo6Ldx5fNKJ2h4MRsjMW2JsIHEyFDqYCRzNhVyNkLETw0d5U0FUhiMmZtebM4b9O2qqOmb3ZoWisVd5fadK41fTJTpPm3cDIpGWPMbZdxs07sLUQRq17sPdhKe02aMOA9FoxIHnTYlnDPOnDcsmdfNFPqaKLgwSfBaBa39GT/ecX+OD1WQivmbpCNQbkjAsiRPwrlV33UTfuILxMWjpD7eMzA6p1qH2IfPACWG3k2kj7fgKS2rFzkWLHQl8I3YOtkdjORORoJju0/b22+hutLU1/3d6kOobOnshP/+BzXxfL7qYCNyuhqwVizBK5W5P/Wgrcu6DURXu2n1z95rQ5AHq2XHFnjv7jdSZNO8xa9pq1HjBvO2jWdsgMf9xv1rbPrH2/afsB0/aDph2HTJ4eMu44YNy+xxCSXcsW/ZaNes0AaJEMOrhH5eJ7BaJb6aLvhwsvhKMdvj0L/ecV4uaDl+/d89kWH7yMyWXgWwSQE+dfGUzj7pbPFYdc6UxrH7LQsxQ6UnsjW/AvA6nQUCZknQvTATQWcpQyNPzBre+ePLz+7LeOl/f3qo4qHp0MKTj0Y8L4cW5GyMdB7N0VceZli3wdRO6mKLqfz+RDN744mqb6zOSPjSb3iuX3agwerjO+v9Hk/gaTe+uM7642+mWF4c0lhjcXGV6vM7haY3CtzuCnxYa3Vxrd32jcuA2Lq32vccd2w+YNeo0rFY0LZQ1zJY+nie8XiG5PFF5NEkA6Ox2gN8tv8mS/uZN9NIpGDS9jFxtRAg1AZGGM9S+m/Mnm+5c/419Q+0BTmu1dqBCLoCPFeZ1zLkPQjtjRXGZjINi8urbl8c3Whp//+P3p363fvjlhrzpt+sHhZRO3fz8kwq23KfJ3RAHdBAHdhPijk8DLAkW4GuesP1Fz5Njzz3q+2Gl+Y4zscqrku0zJl2PFX6SIvh4pvJgo+DYBXYxHF4cLLsYLvh6OLsShL8GGoS+GCf6XILwwRvx1tvSbUsWNOv2Gtfotq5WNC+SPK6SPSsUPJgvvTBT+lIwuDRZcCEFL/YZN8qspBC/z5lp81svYhTQahiigNHodGRJ8mmsO619FuPzxLsP+5cf5Vw1dDIvtHg/FIZEPjj5M5jJi6IT2drj85amWx7eeNt/76/fmv188e/1ViuqopP1j39kHjmduvZiY2L+PA/K3QX42+GNgVzSkr3vee4eKj1y9eTJaddb8dr7y60Hoykh0bQS6kYJupwnuTRTczxY8nCR8VCB8XCx6XCx+XCSpL5Y8LpI+KpA8mCS+myX6ebzgWgr6JgF9Olx4JkX89WTZnQr5oznSB1PF9/OEdycIbo5CP8QJL/VFH/oHQBgqJLmMac1IGKJepg5DFBC38EwXN9JJfcj17tB8Ef9iy5/QhZDgfa18MSBSFpqy8oHM5WyhAP/KGRP7+JcrTx7dfNbx6MXvTX//89er1guvTzioThnUnwmpPrAn59AvE5btSc6dlJSamJwxPr1mfd6BmzM+uvDD0RjVObOna6xvpqG7uaJHhaL6UnHDTEljhbSxSto4X9pUI2usUzQuUOClj8Wi5iWoZSlqWYKaFwqe1Iqa5kua5soaZsgeFEmvZ4jOJ4s+ThaBBn/JF9/LEd4dL7g9Cl2NF/44AB0O6gENUwHOZfiqLNR66oqRF4agGkJcg8otreK1MXdeAPJjAlB5UDX4V2X4koqwxXaGVlIRabgUTLdlg5OXxKmLrKsBWllT3lr/85NHt54/rX/5R+vff7b+8+rv1/VH3pzspjoh//Ns91Mf5S8+enDmyR+mnrhVfuraghOn9x6e0XK8m+qc/eufF7Vs7Fc/Q9BURygsxasczWsULWuVLe9B8pZ2bEZPt6D2TZInG8zq19g/Wt390Sqn+tVdn6w1aV0v79goeLoBdaxF7ctQS63o7jTx5Szxd+ni62ni26MFv4wS3EgUXo9Bp/vYlPnNKPCbM5lL9r0K6aUhrqQe0R1XQ4iWiMzas2s22byCI3Q2KaDzfabT7pQJQCF18yJWlAZVmsgVCgni/IsmL0czqYOpyNVGeXT3xtb6260Nt//4tfEFBtT2z19tr17//brj2zffpKhOWarOKF+csmg87nb/qF/9sV7PT9mpzndXXc191XH51etXTw9FNy9HrZtMWjcZtG4xaN+q375N9nSX4OkuYctWy/uro65WF381fcVnhTtP5x48nnXkaMbBoxk7j2VuPJm7+Gzh9C+mjf++asDtJe4Na7q0b5D9uhZYo5tT0Y00dC8Z3Roh/GmI8PPQLjP8ywr8Kgt8aEnNWyFyyRnNxmkGENfBjyWAcITupRmhIQAFziOr8bg7zfOdQi5gMYCg56L+1c1cZmeEgtysv/n0aPOjW21P7v7xW9OL31teYkDtr/5qffXqxet/fn/d8vmrn6pU36Wovh2q+j5ZdaNYVb/11bPbr0Bl//wBz/nzzq6OncbtH6L27YKnO9DTXahtt/mjjf2u1c39ctqxTyZ/ezr38qmsb09kXDg64fyR8Z8dTPtk/5ize0ad2THy9IcJJz+IO7Yh7tCGYTs3Ja3ZM27WycnjvpnZ79r8nh/n+Z0e4nlvBHoYi/4XZjEtYGYheJkvXSEqyeT3HGRDCCkXxyL11QtIYS45dHU104PXYdAKKHA+vVxRF7kurVeGFK834+UeWv7g/GUsxv5liKKD3W5cOt/08EZH830WEBURMGp79fLp69cvX6tUr1+9fIVxvHz1RvXqzRuM5mXHqxftoLW/X/7xx+MzT/83ru24f+uJvg1fFvywZfvnRVfOFf10rujSZ0UXPpn8xcd5n5/O+exk1ifHJp75KP3UoXHHD6Qe3Tv68M7kg9uS9m2O37MxbufawTuXD9y9MHJXTd9tC6LWzYtcVxG2fP/A6PMDXdaFJE8JqJ5ClmJJnAZAxaRczMO7+XpmdQaELw2OdeUBwh08WR7DgHCHQS6r1y3st36Ea4pEyAAyo4AgAJmInbvIbA1QUnTg3Z8uNt7/qaPlAQD663kzw+ivdszoBabw6kXb65cdrwEWfITPX7SRxzv++asDUP71vOn35x1tzQ0tD6/d+enrcydOXqj+4XL5jfOlX35e8vW5oq8+LbhwdtIXp3M+P5n12bGJZ4+knzk07tT+1ON7Rn+0M/nw1qT9AOj9YTvXx21dO2TzqkEbl0a/B4Bq+q6cG7FiZsiKGfgq48LSgCqIrQV0CY1NZOkkkbEr+bjhQLQIYteA6D4ovEIGgNQpLGDu9GAKaAEAiuuRQFswBpABB0gOgMbEhT+89X3DvetPWx78/lvTn8+b1YyIjv4hLLC9JMb+l9J58Xvz77/WtzXcamv4+dMT+0cNCg1wNh7hE74ne/flmTfOl1z8rPirTwsvnM3/4kzu5yezPzue8clHE84cGn/qwNjje0cf3TXq8LakA1vi974/fNd7sdvXDP5wZcymJdEbFvZfVxO5al7EsoqwRTP7LCwPng95eQq5cDaJq6cxIFxP89v6zoBoE8/keKaGxoBwCpsdumBh1IYhznGkhu4EyEJuq4/Shkc+uv0DBtT84Pdfm/543sxnBPHo7z/b+Zj+IQYP/v1XG0R0EF1H8z1IglcvfhIT6GynB42IzN4MuVoZzo0tvzj9x/NTLn5S8AUFdCr7HAV0GAM6wQf0wfBd62O3rwVAgzhAq6vCAdBi8APIyJCXMSA/ckWIXHrFbb0aUIYaUHInQLiJ1wBUxQAKWbAoasNg51iRTkBEQSlDQu/fuNQALtZ8//nThj+ePQHjGL34o+UFwURIYXvJWCt86c/nT561P25+fKvpwU8VUyZ0M0LeDvoeNgp3G2U3c7GlIcqPnPhV6Q8Qhgig8zxAp1lAR7aPOPBhAlbQ+rjta4dgQEujNy7q/14tAIqggBaU480OPEBe3LpHfprb/3VA+kIb3KCKaRE0JKzXre+/hBjU9uTes44GLKLf1IwYTJQUZ/SR582/P21of3IXMuCFTw73ce3iYSPz7Kp0t5G7WMp6Wsq7mUvNlKi4X97XpVfeCeggAbSbBbT5vwHqrKD/5GIAKLb7cOJizAoZl+YBEKT5YHebb84de/LwZkvDL8866gEQtt84TNqk/mL/+8dvjb+2P2p8cKP50c15UzN7mCMve71etgo3a7mLlcy5i9TJXGZrLOqiL1qSuOSrKVdO5XymC5AuFxu4YeEAbRcr0+liOhWkA9A7g3RCzxEkSLN1ECkUAZCjudTRVOxirTi0/b2Wx7iSBn9hABHDjAgmTOqZ9ifPnja0Nd5tenjz+wtnBgY4uVqKetvpedjIAVBPSykAcjST2JtITZXI08bxaNbpTyddOJH1CS8GaQfp9TRIYxdjYtC88OXaMeitQZoPyHl8iq40P0lHmseARrmPhTRPFqGZVsPSEHeqDqYSZwsZxOkFs4uaH95svH/jaetDCEN8RmpMHCzyye9PG39txfKBFnfdwlmuFkBH6dkVoo/c1UrWwwLkA2W6pKuR2MZIqpSg/LCcLwovH8s4C2n+I5LmD6QCIJzmtyXt34LTPGSxbSSLfcAE6b6rsIuFQharA4eAd50P6J1pnquDOhWKdKmsBAAFAiBaKK4d3ztbJqbbnLgwJKJhyNlSYalEo2PD71z7BsJQO4Sh9notQDoNntbWeA+Y/nzly5RBgd3NBN72+qx8ZM4W0m5mUvj58FusDKUgXlcLh4MTjp3J+R/IB9dBaSf3px7bkwKADm1NxHXQxmE7CaAtKwDQwA0LotZWR66aG750DgNoPgWkLhR7vaVQTORX0txikGarMZVpNWpoq5HrW6yQCBQSxCxFk27DylCEvcxMam8i6mVv9MlHOyETNT/++be2x8+fNr6bznMiH3DJpgc3Dny4isRmRa+uCjcbHH16WEqdukgdzPA6NwQ7iEFmShGU8pUxVZ/lff1R+mkIQAfTTu5LPbY75ciOkQe3Ju7bFL97w7Ad64ZuXT14y/KY9xcPWF8XtXY+FIphy2aHLoSWABwC3KJYo5J+S6uhq1mdTJtV/qVU2qzOIrsNpwTOMpLh1WjmUo9CaEYberJgBtWQpQJVlGQ23L0K1VBH8wMsorczev4Uy6f9yX148oOblzKTBzqbIog+7tbYubB8ujDyAS+2NBCZK+HXiYUCFOc+9GzOl0cmEP8ae3zfGByAaAqDCL0Bp7CtqwZtXgYpbMB7tf3WwF9eGb4EAwquBYeAdx1e2mT2IiIFxGtWJzLNqtZyB7sxnFwOI8sdRXi5A19rLieJDFQ6M7TWSt9EJmK2J9COjIhIDDHCwUza1UgY6Gp98dyxhrvXmutv/9r26HlHw1udq6MBy+chrn0+2rkB8rqHrczdRkHpdAfnotGHkQ/+XcYKrKCe5t0Op5/8aMLHB7F/qQPQZsjxOACRHB+Di6CFJMfPi1heGbYEKpUZwTXwfpcEVFBAb13uIBd/tBbM1BdUs7QyPVmQBkCQBeA39TB1EuM4LVCyodqMt2wGL8lKicryUhvvXnv0y49tTfewo3U0dPY1eAS+1NZ45/Gdq/dvfDd+eF8nE9SrqxLTscJ0cGwmzgXyBJFCQoDfBdkTHNxEIds48sPjEz/dj+VD/QsCEHSquzcO26EZgNZBAKqKwCkMXgK80yTHV7A5Hi+YZWheYqVXx+iCmcaS61jekivEaf52DrJRillRDLbtQ3YrCJSsiJh1e0Nm5Qw8ooel3v6ta548uAEvHqL1r4QR39eADtQBHU/uP7577cnDG5tX1bhYSCEq48DM0nHkO5ee0FQhhKgHvxF+r1wsqBm06OTEc+BcTIIfcWBLwr4PSIkIAYj41/uLB0IAWoMDUPhSGoDgnZ4aCAGIi9BcjtdYcqU7zf/7oj2O02uG9xyhtZ3DmHU0S7J45mAms9IThPRy+PLjQ033rz++e7W14c6vLQ9BL1A9gltB3IHPAVz9vesN9659/emRiN72TqYiNxsFRGUtOlbEucywcwlBsHQnqEiApkXOODXx8z2jj2D5JB/UzF9Mk8H61wrsXzgA1UwLAv+qhHednl7I0bVor16TjndKJZd9uDUz9WWfbE/dl33mR6zM8SlUSoQKQocyMmQdjTKyIcHIQoGiAtzOn9r/5P5PoCNo0CAkQTXY3nQPPkLaAgeEWH7923PJg/rYGSJXGzmgwVGZxB2OjgXOXIxzUfnoEUCFocUnJ5wD7ZDow8iHhmecv7B8sH/VRK6iTQa8u9NxAKoq8a/gInTWuy/7dLpwSNbtyREV9YVDXrkIIqoMW1oeMt/WwIps0xTwdkx1YmSKGfm72m5aVXv32jfND25AJAa91N+9hnndvQriglieMiQMmrieVnLST2DhYCc1pnREQAcylwmPjpJVUFHolOPjPwXtkOzOLAPx5YPzF/avFWwFBP7FLHRg/6Ir9vw9HvioYqcLh7xtrVwYymMvPZd0uvSMQzWIKMgmiPMy3YwMcMy2N5VC6WhtgEYNjdi4fP4XZw7evPy/X65+feuHLy58fHhlzYwwL0drJepuISdoJBwa+F74CdSzMB25Bh0wSGRzoqqOpH0M7ftWqJ4T9rzPZnem/BnILAPR8DwL569a6l9F/lg+EICycQ1dxF3zYbea0d3l5NIz3RhNNy9wWxPpxk2NvS+Ml82lR71qIlaPdh9Ht3ZobX2mjLhNMLgLMZbYGotNJYBJ4O1sOSDYfVhUwOAwL7+e1jb6yFofdTOXgUPZm+IyCp5pQ4UDdPSEWp7FGZTypkrFmmEb96YcAzpQ+2zCzrXjvaHb1rDZHeRT14+G52VsAV1dFsDkL7YCYv3LTcfmhXin0YhubuVtf8nA21/cINnnT2TaetJzsPt+p+HdU/PnhCwu71NtY9BFKkJam8T1mW1UOK9RKQEmXCKZyuCVWyiRuRxbFzmy1EN2JhJcNxHJYNUAGgOczrFw9EjJI8dRWYsO+LVQIPCy7rWbWdyA0plxLrY4pNFnLVlF5MmH1IfcUjT/wvw4emG+p3r7C7M/aBj/2FPnDVRMz1E62bucvUBGRBRcXR2xur/jQJEQdd5Fz2xTpDs4SZ3dBasJFwHWRhIbY2y25KMNdiWMD7iAQ8FzqGpINYgzOlTqejq26ON91hP9svannIS+lNChy2NbVw9iah8meamjT9100sHT+jDfh7+BqoDbeM/twlNvoOK24CV13sFJCiJSMZbwNo/jvgx+WUXo4imBs00V+mT/ne4zKfDmU48zoU5H/K4LNX3WyH/xpiGiOBPqUxgNFo4uOgKoUW0MLFfHbtyWeABqwo14fR4XPlAZQu9OnGt9Xb+11cS5WPng7I7l46exxIEvh7kx/jW6k3+xexR17wFmNtjTA4V5vfFFRE0R1cwLXzmw2yCuYnzbKRVo+uEF4y3BckzKhAjEVMkohRo8TiRD0SCdaNgfKITfmNo79ciYT3aO+Ghr4sENcTvXDtmyatCmFYQOtKacc3HNF5u8KrT6L81L8uqdwAnsdnKyy5XdBpyk3kVOGldX5sBuFhuJyEY89fmM2SELIRLZG1mLhW89lqFxmEdKT2mArAAEYxgKfgR/FXN5OxrOFGKBm7lLrEtsbkD+vKhFa4ZseT9u74ahu1cO2gyhp46sbBA63OJGTRlNXux++xyS3TX22/fMGqWxQZE51YL4x1gSO20kH6+5E5g5w4JXiCpBscCoKmzFhN65SokUO5pUoPy316b3dlP+F4O3BMKfUoqs9A09LZ1iuvfL8s2eE1ELoWdx//frIt+D0nlOGG4syrFz4cUNZoGVjT5a8tEMz4x/xQIg9ihCSicRZRIRMZs9cGtGRJTPHtRg6sag6nnhK4Z2H0YOywn+6+v8/2d6pLMxU0rI0gcy1UPm+sjSEDmb6wfbu4xwj8v3L5oZUjs3bEVFyFLcebFHNflnx0jyUlfPvP2tWkcRNM9CJb7rNAIurOkyI7ffnm4amhu+PMphALylZBVN8P+WDn/9gGwYtTOWQMkO3Uk3c7GDObI3Rz0spIH2DrEu/TK9snE0CKwFQJN9y+k5BHKYhVse097cypcPPsyiPiXPO6qqPonpqnlOle9o9CgdwwjermUxToOhdCSX7YV6/+UF/2c6TGMsohcLoPgGOtCm9LSUuVkretkoPWwVLjbCntbIw1bZx9Ep0S1ukndpoc8ccmRsCi2d07WOQ6mHe6jPHdLjUBoH6rRORNEDdVy0Zo8bskdV/SmjeXRvFfhaaq8JlnomkGUU5KChZmRlDvJqmM4H3+pZAkPe2hPQgcKyq7EEejcnQsfVSuZuI+9lq+htp/S21/dx0PeyV3h0lbjaSnzsrOJdhuf1LuOuf2me7k1XJy+efIbQE4c6z9SxRzL50ZoeydQ8zksCNjM9IAgS/4qSwNmBNv56UhE92gzBG2SlkAj1lDIDpVQhFamRQYUplxjqyfRkYniOTCSQiwXv1g67egldHvT6WDhOpPWHJs6pi4QoSA7y8bRTetnpedvrASMfRwNvRwO3rjJHC2G0U1R2r6lkZEUet3Oc37uzyWsUd/YZcSfmdZ3KfPuhXhKM8CQBtY5w4gerDIXkWpfkHtvDzNzYQM/Z1dnX09HWxso/1Dd+iJ+Ph72eTATFN6RqcyvL8Ej/+EHeLt272jl38/V2trU0pjG4s98x1ykV3F513LgBmh6WUndbqbednldXQzdrpYsVXud3sZa52sjdbOXutgr46Gor62kjt+2C+tj5ZPaawtLJ1qwMOx/qxWMqEDvQhH+ulzucwD+5CozyeMFIByN2ngCuIcv6zBrvHdfHrVd8ypDirOjgIK/07BGralJT4wOVUryiLELIsWf3adPTllckDernM2BYdFlBXJC3EzQR6iEDzJF6duWbo0OuDjiYMQpyxuuQykjn7rFufgN6uoQ72wc5Wvk7mPnYm3rbmYNz+ds5BNm7DHSKHOeWC+8xnXzGLYzxT/QyhzHVA3OGoxj+OCXNaJ3k3Ol4JjNdioxd4Bh5l9Pjz1PI0fkyXB/hETdF/oWDe/eLGRE9dlRY36jA9LwxdXNGjUsIcrcy97K16m1h4dvbo6g0dcGMhPghwRFxMePT+of5O1voS02U2A3BQ0VkBIFczF47UYosDcQ4bZkwcQeyFejF1UreAy/vK4e7Rmf6TEjrnZzqmZDSKzbZY2iKe8JYj9TxHpkZHvmZHsW0KR2rHgbDDV9QV4axzASPJDrBA4+m4KbidHI0pkHjxppw58O1GGkOX6ik7lYWWDHBZ3y/Pv0i/L2igkP6Do2JiPIaGdUnxXNQbuDYwsDMMcFJ/YZE9u/vNTTSPzgwNDzIL8E/NMUramTvyDi3kH7OPr62zs5mXawM9EyUYkM5MlLgksfCANkYC+xNsX91t5CBT7niZWxFVzPka+tUgqvB8nyfsjyvqbxJXppjF7gxMDrHd5DYPIidk8MNN1FPp4jVNfqFGePmwukoX8eACvX4jgoyQmne1MBZ+b6Ts30zwNIDJ6QFpk4KzC0NnjkrtBa6pFmh87OCs1MDR2T4j87xGzc5MK+sT/nssOrK8NqK8JqZYRVT+xRPCszI8B2d4hkHRU0/J3//rj16WVr36GLczUxBXEzcrYvYyUICXta9i0Fsj5gp+DgYf3AHvp4zkTfchB+YR7DzBLhBQtxxefVwEx1T3XjDgxJ4w4PIPDeWkSvra2S8HTMAxltrclDlVDwPqaosCAQ1b0ZQ9azg2ll4i8hC6LArwpZArzQ3dPGc0NpZoTVzwhZUhi+uilgOLUJV+Ar4BIrPyrAl8PiskOoZoVUzQudOD5lTGlxeFFiS65s7znP0SI+4eNfoOJf+w12iR7glZPTOhfeGrsPjSUueZNJSLzIex41HhzkEns7SoacvU7TG48Rw43HI5Ls41tG0BiypB7vRgJ2sqSMur2mMENKYPVXBDoNhAhN/itCs0AWzQxfNAVihiyky8pHaIugzqQHQ2SELZvbBK174rFEQNjLDq6oUTzibU4Inf1UW+83hppqxw4OKtIYHadHhTskP6zRgKZodrIzo7ETNKUKJ7GF6XmXEY0TnVZCJDHnvHkJVhDExw5bo3DLa4pYzo6hq6Cgquj1Uy+BBOqWKP6sLvh3PnsKdJzuii0znyPdmhi6SPmsKNxQP96I0Z+mm85YxZnbD6bhgPKKLPy6aN7Y1iQvY6haEYTSeDt3kBnXRq9UT2NGAnJToXECNSWaMoOayw8zwhDdcPeEXX12uaWTaGx31xs15w8Om6Jw3bnYgdOfM1MDeWDjcLLx0d40hb+x5VA3tDP+XQXhkyJuuMYH8IYrJOhixeY0dPoBDEjuxi4nc2XgA6VSt8YmUFB2ZSMe+qWcEkjl3ZayVBqqHBbKTAiu0JgXmk8sSVDUUDV7BYEbgsdMUmTGBnUeX6aYT02mUIjto8l1jODUY8UcpjqIjfzVmcNKxrYV0PhUO3uw0RW70ptaUySmdRkxqjZvUmDVJZnOCZNipnGo0rHCYoRzErbLH9Mjkhk29g84QNjB3HsapY1QpDUY6GDnyGY2lc8bVU1zJ7F8qJepxdIQrwUQmK9JRpd5qTWkPKfXjGW9gKX9aaR47rTRbPVyySMd8SZ5b8cdw6ow7fDoDeSNv6QBgpDEo2RYHo7cximMY8cebqUMSHpHsQjGxQ4Dd1EOAM3uxpDy1J93iIa3e2LDEeEZlwijFq5Q/wpWbDEwcqmCCGzMLkJ0zzZ8JPF57kOv/GR1uaDLSMUwaM4rTxUj3QGB2riuN3IzHqdXkrjUTuIiZ8UpnJZOxyLnsoORcL2LqucklZAxpidbE5IncHGAySpKHBkccLeEk8qZKkwlcuujwpm9qjd1GOoe1D9DFSGNoMjtwO5GbRd6diUqkCMhk1cQMIudPlZ5IYfUqpFNf1aO2PZmB2/STTGbyNh27XZihOXObnU7OTL+nE+9TcCKfmMxUyeNYtyIDt3lDN7mo/E7txNCh5MzI9ojOA+3tNMduq0e2j2TcjTfNPtGJuwECnvJPa24av1NZQXGkxmvPa6cDyvGLVxt5hBvcDk/G38LOjdae2t6DGW6frPYp9Zztfx1HrklnMEsnmo7+Vw/9/zdGWmPtR/LWRpj7IfDuE5GuOb5dPaacP9yenfifx4y4J9QYY3Dkqef+u6rn/rPT7DN5Y9q10KhXv4YxPXqy5tD/d9NR3xgBAEW97bYROGZ3ujGC+lYsPHej3X+8+k4j9J4R3L0ReKRI6cTcM4K9YUQaZ26skf9yN4/Ad45wpXeOyOTdOQLfkIKdYM9XTSp3uxZdbsWM/H3LuP8Y7dtGkBuPRP0f3FojTn1rDXZthB+5OY/jnI5Pitx1JL3TXUcIL3qnEZdOBqUDcyMN7XuPwI/iuPBVE6/pU3HsmC2tW/2QToK9qcZb6JB7RkSF0Duz/BsjXB+pb13T+a4+3I0k1LfZ0L4JSRJzM5/x7C1amPvW8G5Uk9HJNG5gk8zewIa9208a35uoQ+m63wgjnMEad/iJ41eDPDrRWnTorWv6ajLqfAObQdq392HcjVlC4m5Fos5x6psfjWHDk/rORwys7uP49zwaSe9GwzP+XZB03v+IjcFUMnyH4t/YhyccXTf2iXzLDVlCuJsfBVlGvIsR7wZRfHcbyFQA6pvZdMbEhSfW9VLffu+stLeY1h20xmreQUt9tyMOzVBtn1LfYET37bPeSSfYsu//BwEWV4IOMd58AAAAJXRFWHRkYXRlOmNyZWF0ZQAyMDA5LTA5LTEzVDE0OjM0OjQyKzAyOjAwSy+PdAAAACV0RVh0ZGF0ZTptb2RpZnkAMjAwOS0wOS0xM1QxNDozNDo0MiswMjowMDpyN8gAAAAASUVORK5CYII%3D";
    $rootScope.checkReadyToChangeState = null;
    vm.UserPhotoText = '';

    vm.Logout = function () {
        if (!$scope.mc.loginModel.AuthKey || $scope.mc.loginModel.AuthKey.trim().length === 0) {
            $state.go('login')
            return;
        }
        resetAllValues();

        var logoutRequest = loginService.logOutUser($scope.mc.loginModel.AuthKey);
        logoutRequest.then(function (response) {
            $scope.mc.loginModel.AuthKey = '';
            $state.go('login')
        }, function (response) {
            $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
            $state.go('login')
        });
    };

    function resetAllValues() {
        $rootScope.checkReadyToChangeState = null;
        $scope.mc.getlogDetails("Debug", 'Method:GET;URL: Logout');
        $cookies.remove('UserAuthKey');
        $cookies.remove('LoginUserId');
        $cookies.remove('toState');
        vm.selectedApp.CurrentTab = '';
        vm.selectedLibrary = '';
        $scope.selectedLibrary = '';

        $scope.mc.loginModel.UserName = '';
        $scope.mc.loginModel.Password = '';

        if (angular.isDefined($scope.mc.loginModel.UserSessionTimeOut)) {
            $interval.cancel($scope.mc.loginModel.UserSessionTimeOut);
            $scope.mc.loginModel.UserSessionTimeOut = null;
        }
        if (UserSessionTimer) {
            $timeout.cancel(UserSessionTimer);
            UserSessionTimer = null;
        }
        sessionTime = -1;
    }

    if ($scope.mc.loginModel.AuthKey == null || $scope.mc.loginModel.AuthKey.trim().length == 0) {
        $scope.mc.loginModel.AuthKey = $cookies.get('UserAuthKey');

        if ($scope.mc.loginModel.AuthKey && $scope.mc.loginModel.AuthKey.trim().length > 0) {
            $scope.mc.loginModel.UserName = $cookies.get('LoginUserId');
        }
        else {
            vm.Logout();
        }
    }

    vm.menu = {
        sections: {},

        toggleSelectSection: function (section) {
            self.openedSection = (self.openedSection === section ? null : section);
        },
        isSectionSelected: function (section) {
            return self.openedSection === section;
        },
        setSelectedSection: function (section) {
            self.selectedSection = section;

        },
        isSelectedSection: function (section) {
            return self.selectedSection === section;

        }, onTabLinkSelected: function (appsName, appsTitle, target) {
            $log.debug('Tab selected');

            $cookies.put('toState', 'home.' + target, { 'expires': updateCookieExpiary() });
            $timeout(function () {
                if (appsTitle && appsTitle != '')
                    vm.selectedApp.CurrentTab = appsTitle;
                else
                    vm.selectedApp.CurrentTab = appsName;
            });
            $scope.appsVar.selectedMetaData = appsName;

        }, toggleSidebar: function () {
            $timeout(function () {
                if ($('md-sidenav').hasClass('md-closed')) {
                    $('md-sidenav').removeClass('md-closed');
                    vm.showmask = true;
                }
                else $('md-sidenav').addClass('md-closed');
            });
        },
        watchSection: (function () {

            $scope.$watch(function () { return self.selectedSection }, function () {

                if (self.selectedSection != undefined && vm.headerNavigationMenu) {
                    var navigate = vm.headerNavigationMenu[0];
                    if (vm.headerNavigationSelectedMenu && vm.headerNavigationSelectedMenu.length > 0)
                        navigate = vm.headerNavigationSelectedMenu[0];

                    $cookies.put('toState', 'home.' + navigate.AppsTarget, { 'expires': updateCookieExpiary() });

                    $state.go('home.' + navigate.AppsTarget);

                    if (navigate.AppsTitle && navigate.AppsTitle != '')
                        vm.selectedApp.CurrentTab = navigate.AppsTitle;
                    else
                        vm.selectedApp.CurrentTab = navigate.AppsName;

                    $scope.appsVar.selectedMetaData = navigate.AppsName;
                    vm.headerNavigationSelectedMenu = undefined;
                }
            });
        })()
    };

    vm.TableScrollOptions = {
        cursorcolor: '#999',
        cursorwidth: "10px",
        cursorborder: "none",
        background: "#ccc",
        smoothscroll: true,
        autohidemode: false
    };

    vm.viewSelectedOnlyLabel = 'View selected';
    vm.filterSelected = function (selected, field) {
        return function (user) {
            if ($scope.vm.viewSelectedOnlyLabel == 'Show all') {
                if (selected.length == 0) {
                    $scope.vm.viewSelectedOnlyLabel = 'View selected';
                }
                var items = $filter('filter')(selected, user, true);
                if (items.length > 0)
                    return true;

                return false;
            } else {
                return true;
            }
        }
    };

    $scope.$state = $state;
    $scope.appsVar = homeFactory.applicationVariables;
    $scope.ScrollCounter = false;
    $scope.animationUrl = 'Images/loading.gif';

    $scope.$watch(function () { return vm.showmask }, function () {
        if (!vm.showmask) {
            $('md-sidenav').addClass('md-closed');
        }
    });

    vm.closeSideNav = function () {
        vm.isSideNavOpen = false;
    };

    var setMenuSections = function () {
        //var userPermission = ManagementService.getUserPermission(vm.selectedLibrary, $scope.mc.loginModel.UserName, $scope.mc.loginModel.AuthKey);
        //userPermission.then(function (response) {
        //	if (response.data["statusDetail"] == "Success") {
        //		if (response.data["Groups"].length > 0) {
        $scope.mc.getlogDetails("Debug", 'Method:GET;Metadata List:' + JSON.stringify($scope.metaDataList));
        // $scope.mc.setSecurityLogDetails("Info", 'Method:GET;Metadata List:' + JSON.stringify($scope.metaDataList));
        vm.selectedApp.NoAppsPermission = '';
        var promise = homeFactory.getSections($scope.metaDataList)
        promise.then(function (response) {
            $scope.mc.getlogDetails("Info", 'Response:Success');

            vm.menu.sections = response;
            redirectTOLastSection();
        }, function (response) {
            $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
        });
        //		}
        //	}
        //});
    };

    function redirectTOLastSection() {
        var activesection = null;
        var tostate = $cookies.get('toState');
        if (!tostate || tostate == 'home.MainHome') {
            tostate = 'home.' + vm.menu.sections[0].AppsTarget;
            vm.headerNavigationMenu = [];
            vm.headerNavigationMenu.push(vm.menu.sections[0]);
            vm.headerNavigationSelectedMenu = null;
            vm.setActiveSection(vm.menu.sections[0]);
        } else {
            var statetarget = tostate.split(".")[1];
            if (statetarget) {
                statetargetTabs = statetarget.split("_");
                if (statetargetTabs.length == 2)
                    activesection = $filter('filter')(vm.menu.sections, { AppsTarget: statetargetTabs[0] }, true);
                else {
                    var object = $filter('filter')(vm.menu.sections, { AppsTarget: statetargetTabs[0] }, true);
                    activesection = $filter('filter')(object[0].childMenus, { AppsTarget: statetargetTabs[0] + '_' + statetargetTabs[1] }, true);
                }
                object = $filter('filter')(activesection[0].childMenus, { AppsTarget: statetarget }, true);
            }
            vm.headerNavigationMenu = activesection[0].childMenus;
            vm.headerNavigationSelectedMenu = object;
            vm.setActiveSection(activesection[0]);
        }
    }


    function isOpen(section) {
        return vm.menu.isSectionSelected(section);
    }

    function toggleOpen(section) {
        vm.menu.toggleSelectSection(section);
    }

    $scope.PageEvents = [];
    function setActiveSection(section) {
        vm.menu.setSelectedSection(section);
        $(window).resize();
        vm.showmask = false;

    }

    function isCurrentSection(section) {
        return vm.menu.isSelectedSection(section);
    }

    var isClearSearch = false;
    vm.search = {
        Show: false,
        onSearch: function () {
            if (searchTimeout) $timeout.cancel(searchTimeout);
            $scope.$broadcast('Search_Click');
            //vm.search.Show = !vm.search.Show;
        },
        clear: function () {
            if (searchTimeout) $timeout.cancel(searchTimeout);
            $scope.appsVar.SearchText = '';
            $scope.$broadcast('Search_Click');
            isClearSearch = true;
        }
    };

    vm.FooterLinks = {
        ShowAboutUs: function () {
            var useFullScreen = ($mdMedia('sm') || $mdMedia('xs'))
					&& $scope.customFullscreen;
            $mdDialog.show({
                controller: DialogController,
                scope: $scope, // use parent scope in template
                preserveScope: true, // do not forget this if use parent scope
                templateUrl: 'Views/AboutUs.html',
                parent: angular.element(document.body),
                clickOutsideToClose: true,
                fullscreen: useFullScreen,
                escapeToClose: false
            }).then(function (answer) {
            }, function () {
            });
            $scope.$watch(function () {
                return $mdMedia('xs') || $mdMedia('sm');
            }, function (wantsFullScreen) {
                $scope.customFullscreen = (wantsFullScreen === true);
            });
        }
    }

    function DialogController($scope, $mdDialog) {
        $scope.hide = function () {
            $mdDialog.hide();
        };
        $scope.cancel = function () {
            $mdDialog.cancel();
        };
        $scope.answer = function () {
            $mdDialog.hide();
        };
        $scope.ServerVersion = '';
        $scope.BuildDate = '';

        function loadSettings() {
            //var deferred = $q.defer();
            var x2js = new X2JS();
            var todayDate = (new Date()).toJSON();

            var promise = $http.get("content/settings.xml?v=" + todayDate)
            promise.then(function (response) {
                $scope.BuildDate = '';
                if (response && response.data) {
                    var navXml = x2js.xml_str2json(response.data);
                    $scope.BuildDate = navXml.root.builddate;
                    //$scope.BuildDate = sectionsObj;
                }
                //deferred.resolve(sectionsObj);
            });
            //return deferred.promise;
        }

        function loadServerVersion() {
            var promise = HomeService.getServerVersion($scope.mc.AuthKey);
            promise.then(function (response) {
                $scope.ServerVersion = '';
                if (response && response.data && response.data.data && response.data.data.Version) {
                    $scope.ServerVersion = response.data.data.Version;
                }
            });
        }

        loadSettings();
        loadServerVersion();
    }


    var searchTimeout;
    $scope.$watch(function () { return $scope.appsVar.SearchText }, function (newVal, oldVal) {
        if (isClearSearch) {
            isClearSearch = false;
        } else {
            if (oldVal != newVal) {
                if (searchTimeout) $timeout.cancel(searchTimeout);

                searchTimeout = $timeout(function () {
                    $scope.$broadcast('Search_Click');
                }, 2000);
            }
        }
    }, true);

    $scope.searchAfterDelay = function () {
        if (scope.appsVar.SearchText.$dirty) {
            scope.$broadcast('Search_Click');
        }
    };

    (function getDBLibraries() {
        vm.selectedApp.NoAppsPermission = '';
        if ($scope.mc.loginModel.UserName === '') return;
        $scope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify($scope.mc.loginModel));
        //$scope.mc.setSecurityLogDetails("Info", 'Method:GET;URL:' + JSON.stringify($scope.mc.loginModel));
        var promise = HomeService.getDBLibraries($scope.mc.loginModel);
        promise.then(function (response) {
            if (response && response.data && response.data.data.length > 0) {
                $scope.mc.getlogDetails("Info", 'Response:Success');
                vm.DBLibraries = [];
                angular.forEach(response.data["data"], function (db) {
                    vm.DBLibraries.push(databasesFactory.getDatabaseUI(db));
                });
                $scope.SelectedDBName = vm.DBLibraries[0].DatabaseName;
                vm.selectedLibrary = vm.DBLibraries[0].DatabaseName;
            }
            else if (response && response.data && response.data.status === 401 || response.status == 401) {
                vm.selectedApp.CurrentTab = '';
                $mdDialog.show(
					   $mdDialog.alert()
						   .parent(angular.element(document.body))
						   .clickOutsideToClose(true)
						   .title('Warning')
						   .textContent('User session expired.')
						   .ariaLabel('Warning')
						   .ok('OK')
				   );
                vm.Logout();
            }
            else {
                vm.selectedApp.CurrentTab = '';
                $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                vm.selectedApp.NoAppsPermission = "You don't have permission to view any apps. Please contact administrator!!!";
                $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                vm.Logout();
            }
        }, function (response) {
            $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
        });
    })();


    //vm.getUserPhoto = function () {
    //    vm.UserPhoto = undefined;
    //    vm.UserPhotoText = '';
    //    if ($scope.mc.loginModel.UserName === '') return;

    //    var promise = HomeService.getImageData($scope.mc.loginModel);
    //    promise.then(function (response) {
    //        if (response.status === 200 && response.data && response.data.length > 0) {
    //            vm.UserPhoto = baseUrl + "api/v1/users/" + $scope.mc.loginModel.UserName + "/photo";
    //        }
    //    }, function (response) {
    //        vm.UserPhoto = undefined;
    //    });

    //    vm.UserPhotoText = '';
    //    $scope.mc.getlogDetails("Debug", 'Method:GET; Action: ViewUser ;User Id:' + $scope.mc.loginModel.UserName);
    //    var promise = userFactory.getSingleUser('GETUSER', vm.selectedLibrary, $scope.mc.loginModel.UserName, $scope.mc.loginModel.AuthKey);
    //    promise.then(function (response) {
    //        if (response && response.data && response.data.length > 0) {
    //            $scope.mc.getlogDetails("Debug", 'Response:Success');

    //            var nextChar = '';
    //            var photoText = '';
    //            var spaceFound = false;
    //            var loggedUserModel = userFactory.getUserUI(response.data[0]);

    //            vm.UserPhotoText = '';
    //            if (loggedUserModel.FullName)
    //                loggedUserModel.FullName = loggedUserModel.FullName.trim().toUpperCase();
    //            if (loggedUserModel.FullName && loggedUserModel.FullName.length > 0) {
    //                spaceFound = false;
    //                for (var iCount = 0; iCount < loggedUserModel.FullName.length; iCount++) {
    //                    nextChar = loggedUserModel.FullName.substr(iCount, 1).trim();
    //                    if (nextChar.length === 0) {
    //                        spaceFound = true;
    //                        continue;
    //                    }
    //                    if (spaceFound) {
    //                        photoText = nextChar;
    //                        spaceFound = false;
    //                    }
    //                }
    //                if (photoText.trim().length === 0) {
    //                    photoText = loggedUserModel.FullName.substr(0, 2);
    //                }
    //                else {
    //                    photoText = loggedUserModel.FullName.substr(0, 1) + photoText;
    //                }
    //            }
    //            else {
    //                photoText = loggedUserModel.UserId.trim().toUpperCase().substr(0, 2);
    //            }
    //            vm.UserPhotoText = photoText;
    //        }
    //    }, function (response) {
    //        $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
    //    });
    //};
    function getUserPhoto() {
        vm.UserPhoto = undefined;
        vm.UserPhotoText = '';
        if ($scope.mc.loginModel.UserName === '') return;

        var apiUrl = homeFactory.getUserPhotoAPI($scope.mc.loginModel.UserName);
        var promise = HomeService.getImageData(apiUrl, $scope.mc.loginModel.AuthKey);
        promise.then(function (response) {
            //if (response.status === 200 && response.data && response.data.length > 0) {
            //    vm.UserPhoto = baseUrl + "api/v1/users/" + $scope.mc.loginModel.UserName + "/photo";
            //}

            if (response.status === 200 && response.data) {
                var blob = new Blob([response.data], { type: 'application/octet-stream' });
                var URL = $window.URL || $window.webkitURL;
                vm.UserPhoto = URL.createObjectURL(blob);
            }
        }, function (response) {
            vm.UserPhoto = undefined;
        });

        vm.UserPhotoText = '';
        $scope.mc.getlogDetails("Debug", 'Method:GET; Action: ViewUser ;User Id:' + $scope.mc.loginModel.UserName);
       // var apiUrl userFactory.getSingleUser('GETUSER', vm.selectedLibrary, $scope.mc.loginModel.UserName, $scope.mc.loginModel.AuthKey);       
        var promise = userFactory.getSingleUser('GETUSER', vm.selectedLibrary, $scope.mc.loginModel.UserName, $scope.mc.loginModel.AuthKey);
        promise.then(function (response) {
            if (response && response.data && response.data.length > 0) {
                $scope.mc.getlogDetails("Debug", 'Response:Success');

                var nextChar = '';
                var photoText = '';
                var spaceFound = false;
                var loggedUserModel = userFactory.getUserUI(response.data[0]);

                vm.UserPhotoText = '';
                if (loggedUserModel.FullName)
                    loggedUserModel.FullName = loggedUserModel.FullName.trim().toUpperCase();
                if (loggedUserModel.FullName && loggedUserModel.FullName.length > 0) {
                    spaceFound = false;
                    for (var iCount = 0; iCount < loggedUserModel.FullName.length; iCount++) {
                        nextChar = loggedUserModel.FullName.substr(iCount, 1).trim();
                        if (nextChar.length === 0) {
                            spaceFound = true;
                            continue;
                        }
                        if (spaceFound) {
                            photoText = nextChar;
                            spaceFound = false;
                        }
                    }
                    if (photoText.trim().length === 0) {
                        photoText = loggedUserModel.FullName.substr(0, 2);
                    }
                    else {
                        photoText = loggedUserModel.FullName.substr(0, 1) + photoText;
                    }
                }
                else {
                    photoText = loggedUserModel.UserId.trim().toUpperCase().substr(0, 2);
                }
                vm.UserPhotoText = photoText;
            }
        }, function (response) {
            $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
        });
    }
    var seesionTimoutWatch = $scope.$watch(function () { return $cookies.sessiontimeout; }, function (newVal, oldVal) {
        if ($cookies.sessiontimeout && $cookies.sessiontimeout === 401) {
            seesionTimoutWatch();
            $cookies.sessiontimeout = null;
            resetAllValues();
            $state.go('login')
        }
        else if ($cookies.sessiontimeout) {
            $cookies.sessiontimeout = null;
        }
    });

    $scope.$watch(function () { return $scope.SelectedDBName }, function (newVal, oldVal) {
        if (newVal) {
            if ($rootScope.checkReadyToChangeState) {
                var promise = $rootScope.checkReadyToChangeState();
                promise.then(function (response) {
                    if (response && response.Status === 0) {
                        $rootScope.checkReadyToChangeState = null;
                        vm.selectedLibrary = $scope.SelectedDBName;
                        $scope.selectedLibrary = $scope.SelectedDBName;
                        if (!vm.UserPhoto) getUserPhoto();

                        getCaptins();
                        $rootScope.$broadcast('InitializeTabContents');
                    }
                }, function (response) {
                });
            }
            else {
                vm.selectedLibrary = $scope.SelectedDBName;
                $scope.selectedLibrary = $scope.SelectedDBName;
                if (!vm.UserPhoto) getUserPhoto();

                getCaptins();
                $rootScope.$broadcast('InitializeTabContents');
            }
        }
    });

    $scope.mc.loginModel.UserSessionTimeOut = $interval(function () {

        if (!UserSessionTimer && sessionTime > 0) {

            UserSessionTimer = $timeout(function () {
                $mdDialog.show(
				   $mdDialog.alert()
					   .parent(angular.element(document.body))
					   .clickOutsideToClose(true)
					   .title('Warning')
					   .textContent('User session expired.')
					   .ariaLabel('Warning')
					   .ok('OK')
			   );
                vm.Logout();
            }, sessionTime);
        }
    }, 1000 * 60);

    $(document).click(function (event) {
        if ($(event.target).parents('tr[context-menu]').length) {
            event.preventDefault();
        } else {
            $('.context-menu-container').remove();
        }
    });

    function getCaptins() {
        $rootScope.$broadcast('RegisterInitializeTabContents');
        var caprequestModel = homeFactory.requestModelInstance();
        caprequestModel.libraryName = vm.selectedLibrary;
        caprequestModel.isTotal = true;
        caprequestModel.searchText = '';
        caprequestModel.pageLength = 1000;
        caprequestModel.locale = 1033;
        var apiUrl = captionsFactory.getAPIUrl('SEARCHCAPTIONS', caprequestModel)
        $scope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(apiUrl));
        //$scope.mc.setSecurityLogDetails("Info", 'Method:GET;URL:' + JSON.stringify(apiUrl));
        var promise = CaptionService.getCaptions(apiUrl, $scope.mc.loginModel.AuthKey);
        promise.then(function (response) {
            $scope.appsVar.CaptionsList = [];
            if (response) {
                $scope.mc.getlogDetails("Info", 'Response:Success');

                angular.forEach(response.data["data"], function (caption) {
                    $scope.appsVar.CaptionsList.push(captionsFactory.getCaptionUI(caption));
                });




                $scope.metaDataList = $filter('filter')($scope.appsVar.CaptionsList, { isMetaItem: true, ParentMetaItem: "" });
                setMenuSections();
                var selectedMetaDataItem = $filter('filter')($scope.metaDataList, { MetaDataItem: $scope.appsVar.selectedMetaData });
                if (selectedMetaDataItem && selectedMetaDataItem.length > 0) {
                    vm.selectedApp.CurrentSubTab = selectedMetaDataItem[0].DisplayText;
                }
            }
        }, function (rseponse) {
            $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
        });
    }

    $scope.ClearClick = function () {
        $scope.appsVar.SearchText = '';
    }

    $scope.Metachange = function (tabName) {
        $scope.appsVar.selectedMetaData = tabName;
        var selectedAppsName = $filter('filter')($scope.appsVar.CaptionsList, { MetaDataItem: $scope.appsVar.selectedMetaData }, true);
        if (selectedAppsName.length > 0)
            vm.selectedApp.CurrentTab = selectedAppsName[0].DisplayText;
        $rootScope.$broadcast('InitializeTabContents');
    }

    $scope.filterIconClicked = function (filter) {
        $scope.appsVar.filterAllValue = $.grep($scope.appsVar.filterAllValue, function (item, index) {
            return item.FilterKey != filter.FilterKey;
        });
    }

    $scope.ClearAllFilterClicked = function () {
        $scope.appsVar.filterAllValue = [];
        $rootScope.$broadcast('onClearAllClicked');
    };

    $scope.menuClicked = function () {
        $timeout(function () {
            vm.isSideNavOpen = true;
            if ($('md-sidenav').hasClass('md-closed')) {
                $('#app-navigation-menu').removeClass('md-closed');
                $('md-sidenav').addClass('page-sidebar-full');
            }
        });
    };

    (function ($) {
        $(document).ready(function () {
            $timeout(function () {
                vm.isSideNavOpen = true;
                if ($('md-sidenav').hasClass('md-closed')) {
                    $('#app-navigation-menu').removeClass('md-closed');
                    $('md-sidenav').addClass('page-sidebar-full');
                }
                $('#app-navigation-menu > div').niceScroll({ horizrailenabled: false });
            });
            $(window).resize(function () {
                if ($('md-sidenav').hasClass('md-closed')) {
                    $('#app-navigation-menu').removeClass('md-closed');
                    $('md-sidenav').addClass('page-sidebar-full');
                }
            });
        });
    })(jQuery);

    var listner = undefined;
    var register = function () {
        listner = $scope.$watch(function () {
            if ($window.scrollY) {
                return $window.scrollY;
            }
            else {
                return $window.pageYOffset;
            }
        }, function (scrollY, oldvalue) {
            if (scrollY / $scope.maxY * 100 >= 75) {
                $scope.$broadcast('Window_Scrolled');
                listner();
            }
        });
    };
    $scope.maxY = 1;
    var destroyMaxY = $scope.$watch(function () {
        if ($window.scrollMaxY) {
            $scope.maxY = $window.scrollMaxY;
            return $window.scrollMaxY;
        } else {
            $scope.maxY = getScrollMaxY();
            return $scope.maxY;
        }

    }, function (scrollMaxY, oldmax) {
        if (oldmax != scrollMaxY) {
            if (listner) {
                listner();
            }
            register();
        }
    });

    function getScrollMaxY() {

        var innerh;

        if (window.innerHeight) {
            innerh = window.innerHeight;
        } else {
            innerh = document.body.clientHeight;
        }

        if (window.innerHeight && window.scrollMaxY) {
            // Firefox 
            yWithScroll = window.innerHeight + window.scrollMaxY;
        } else if (document.body.scrollHeight > document.body.offsetHeight) {
            // all but Explorer Mac 
            yWithScroll = document.body.scrollHeight;
        } else {
            // works in Explorer 6 Strict, Mozilla (not FF) and Safari 
            yWithScroll = document.body.offsetHeight;
        }
        return yWithScroll - innerh;
    }
}