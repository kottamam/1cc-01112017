﻿app.controller("DocTypeController", DocTypeController);
DocTypeController.$inject = ['$scope', '$rootScope', '$filter', '$timeout', '$mdDialog', '$mdMedia', 'DocTypeService', 'docTypeFactory', 'homeFactory', '$q'];

function DocTypeController($scope, $rootScope, $filter, $timeout, $mdDialog, $mdMedia, DocTypeService, docTypeFactory, homeFactory, $q) {

    $scope.DocTypeList = [];
    $scope.selected = [];
    var SelectedTypeListForFilter = [];
    var LastAddedSelectedItemTypeId = [];
    var lastAppendItemCount = 0;

    var typeListRequestModel = homeFactory.requestModelInstance();
    var FilterSearchTimeout;

    $scope.ContextMenuFunctions = {
        Edit: function () { $scope.PageEvents.Edit(); },
        Delete: function () { $scope.PageEvents.Delete(); }
    };

    function setContextMenuObject() {
        $scope.menuList = [
			{
			    Label: 'Edit',
			    Icon: 'icon-edit',
			    onClick: $scope.ContextMenuFunctions.Edit,
			    Enable: $scope.selected.length == 1,
			    IconType: 'font-icon'
			}/*,
		{
		    Label: 'Delete',
		    Icon: 'icon-delete',
		    onClick: $scope.ContextMenuFunctions.Delete,
		    Enable: false,
		    IconType: 'font-icon'
		}*/
        ];
    };

	$timeout(function() {
		$(window).scrollTop(0);
	});

    $scope.$on('Window_Scrolled', function () {
        if ($scope.query.totalCount > $scope.DocTypeList.length) {
            typeListRequestModel.pagenumber++;
            $scope.getDocTypeList();
        }
    });

    $scope.query = {
        limit: typeListRequestModel.pageLength,
        page: typeListRequestModel.pagenumber,
        totalCount: 0
    };

    $scope.onPaginate = function (page, limit) {
        isSearch = false;
        typeListRequestModel.pagenumber = page;
        typeListRequestModel.pageLength = limit;

        $scope.getDocTypeList();
        $scope.promise = $timeout(function () {
        }, 2000);
    };

    $scope.onTypedeSelect = function (typeModel) {
        setContextMenuObject();      
        if (SelectedTypeListForFilter.length > 0) {
            SelectedTypeListForFilter = $.grep(SelectedTypeListForFilter,
                                function (item, index) {
                                    return item.TAlias != typeModel.TAlias;
                                });
        }
        if (SelectedTypeListForFilter.length > 0) {
            LastAddedSelectedItemTypeId = $.grep(LastAddedSelectedItemTypeId,
								   function (item, index) {
								       return item.UserId != typeModel.UserId;
								   });
        }

    };

    $scope.onTypeSelect = function (typeModel) {

        setContextMenuObject();
        var tempListFilter = $filter('filter')(SelectedTypeListForFilter, {
            TAlias: typeModel.TAlias
        }, true);
        if (tempListFilter.length === 0) {
            SelectedTypeListForFilter.push(angular.copy(typeModel));
        }
    };

    $scope.loadStuff = function () {
        $scope.promise = $timeout(function () {
        }, 2000);
    };

    $scope.getDocTypeList = function () {
        $scope.query.totalCount = 0;

        if ($scope.vm.selectedApp.NoAppsPermission.trim().length > 0) return;
        if (!$scope.vm.selectedLibrary || $scope.vm.selectedLibrary.trim().length === 0) return;

        $scope.lastSelectedLibrary = $scope.vm.selectedLibrary;
        typeListRequestModel.libraryName = $scope.vm.selectedLibrary;
        typeListRequestModel.searchText = $scope.appsVar.SearchText;

        var searchAPIUrl = docTypeFactory.searchAPIUrl(typeListRequestModel);
        $scope.mc.getlogDetails("Debug", 'Requested Api Url:' + JSON.stringify(searchAPIUrl));

        if (isSearch) {
            // $scope.showSearchProgress = true;
            showProgressDialog();
        }
        var typeDbRequest = DocTypeService.getDocTypes(searchAPIUrl, $scope.mc.loginModel.AuthKey);

        typeDbRequest.then(function (response) {
            if (response && response.data && response.status === 200) {
                $scope.query.totalCount = response.data.total_count;
                var tempListFilter = [];
                var typeUIModel;
                var filterTempModel;
                if (lastAppendItemCount > 0) {
                    $scope.DocTypeList.splice($scope.DocTypeList.length - lastAppendItemCount, lastAppendItemCount);
                    $scope.selected.splice($scope.selected.length - lastAppendItemCount, lastAppendItemCount);
                }

                angular.forEach(response.data.data, function (typeItem) {
                    typeUIModel = docTypeFactory.getUIModel(typeItem);
                    if (SelectedTypeListForFilter.length === 0) {
                        $scope.DocTypeList.push(typeUIModel);
                    }
                    else {
                        tempListFilter = $filter('filter')(SelectedTypeListForFilter, {
                            TAlias: typeUIModel.TAlias
                        }, true);
                        if (tempListFilter.length === 0) {
                            $scope.DocTypeList.push(typeUIModel);
                        }
                        else {
                            LastAddedSelectedItemTypeId = $.grep(LastAddedSelectedItemTypeId,
							   function (item, index) {
							       return item.TAlias != typeUIModel.TAlias;
							   });
                            tempListFilter[0].TAlias = typeUIModel.TAlias;
                            tempListFilter[0].TypeDescription = typeUIModel.TypeDescription;
                            tempListFilter[0].DmsExtension = typeUIModel.DmsExtension;
                            tempListFilter[0].AppExtension = typeUIModel.AppExtension;
                            tempListFilter[0].HIPAAComplaint = typeUIModel.HIPAAComplaint;
                            filterTempModel = angular.copy(tempListFilter[0]);
                            $scope.DocTypeList.push(filterTempModel);
                            $scope.selected.push(filterTempModel);
                            filterTempModel = null;
                        }
                        tempListFilter = [];

                    }
                    typeUIModel = null;
                });
                lastAppendItemCount = 0;
                if ($scope.appsVar.SearchText.length === 0 && !isValidFilterFind()) {
                    angular.forEach(LastAddedSelectedItemTypeId, function (type) {
                        filterTempModel = angular.copy(type);
                        $scope.DocTypeList.push(filterTempModel);
                        $scope.selected.push(filterTempModel);
                        filterTempModel = null;
                        lastAppendItemCount += 1;
                    });
                }
                $timeout(function () {
                    $('td').filter(function () {
                        if (!$(this).hasClass("md-checkbox-cell")) {
                            if ($(this).text().trim().length === 0) {

                                $(this).html('&nbsp;');
                            }
                        }

                    });
                });
            }
            else {
                
                $scope.mc.getlogDetails("Error", "Server Response:" + JSON.stringify(response) + ",Mehod :GET,Api Url:" + searchAPIUrl);
            }
            $scope.showSearchProgress = false;
            if (isSearch) $mdDialog.hide();
        }, function (response) {
            //$scope.mc.getlogDetails("Error", 'Failed to retrive Types.');
            $scope.mc.getlogDetails("Error", "Server Response:" + JSON.stringify(response) + ",Mehod :GET,Api Url:" + searchAPIUrl);
            $mdDialog.show(
					$mdDialog.alert()
					.parent(angular.element(document.body))
					.clickOutsideToClose(true)
					.title('Warning!')
					.textContent('Failed to retrive Types.')
					.ariaLabel('Warning!')
					.ok('OK')
			);
            $scope.showSearchProgress = false;
            if (isSearch) $mdDialog.hide();
        });
    };
    function showProgressDialog() {
        $mdDialog.show({
            parent: angular.element(document.body),
            template: '<md-dialog ng-cloak height="100%" style="min-width: 1px !important;"><md-dialog-content><div class="md-dialog-content-clearpadding">' +
              '<md-progress-circular md-mode="indeterminate"></md-progress-circular>' +
              '</div></md-dialog-content></md-dialog>',
            controller: DialogController
        });
    }

    function isValidFilterFind() {
        var filterKeyItem = null;
        var blnResult = false;

        for (var iCount = 0; iCount < typeListRequestModel.filters.length; iCount++) {
            filterKeyItem = typeListRequestModel.filters[iCount];
            if (filterKeyItem.FilterValues && filterKeyItem.FilterValues[0] && filterKeyItem.FilterValues[0].trim().length > 0) {
                blnResult = true;
                break;
            }
            filterKeyItem = null;
        }
        return blnResult;
    }

    $scope.onTypeListTableFilter = function (value, key, isInstantFilter, disablePerformFilter) {
        if (typeListRequestModel.filters.length > 0) {
            typeListRequestModel.filters = jQuery.grep(typeListRequestModel.filters, function (filterItem) {
                return filterItem.FilterKey !== key;
            });
        }

        var filterValueList = [];
        filterValueList[0] = value;

        var filterItem = { 'FilterKey': key, 'FilterValues': filterValueList };
        typeListRequestModel.filters.push(filterItem);

        typeListRequestModel.pagenumber = 1;
        $scope.query.page = 1;
        $scope.query.totalCount = 0;

        if (FilterSearchTimeout) $timeout.cancel(FilterSearchTimeout);

        if (!disablePerformFilter) {
            if (isInstantFilter) {
                $scope.selected = [];
                $scope.DocTypeList = [];
                $scope.getDocTypeList();
            } else {
                FilterSearchTimeout = $timeout(function () {
                    $scope.selected = [];
                    $scope.DocTypeList = [];
                    $scope.getDocTypeList();
                }, 2000);
            }
        };
    };

    function DialogController($scope, $mdDialog) {
        $scope.hide = function () {
            $mdDialog.hide();
        };
        $scope.cancel = function () {
            $mdDialog.cancel();
        };
        $scope.answer = function () {
            $scope.AddSelectedUser();
            $mdDialog.hide();
        };
    }

    (function ($) {
        $(document).ready(function () {
            $('#card-more-button').attr('disabled', 'disabled');
        });
    })(jQuery);

    $scope.$on('$destroy', function () {
        $scope.PageEvents.Add = 'undefined';
        $scope.PageEvents.Edit = 'undefined';
        $scope.PageEvents.Save = 'undefined';
        $scope.PageEvents.Delete = 'undefined';
        $scope.PageEvents.CancelDialog = 'undefined';
        $scope.PageEvents.ShowSubclassList = 'undefined';
        $scope.PageEvents.AddRole = 'undefined';
        $scope.PageEvents.ResetPasswordclicked = 'undefined';
        $scope.PageEvents.ShowOnlySelected = 'undefined';
    });
    RegisterInitializeTabContents();
    var destroybroadCast;
    $scope.$on('RegisterInitializeTabContents', function () {
        if (angular.isFunction(destroybroadCast))
            destroybroadCast();

        RegisterInitializeTabContents();
    });
    function RegisterInitializeTabContents() {
	 var destroybroadCast = $scope.$on('InitializeTabContents', function () {
            $scope.selected = [];
            $scope.DocTypeList = [];
        docTypeInitalize();

        if ($scope.vm.selectedApp.NoAppsPermission.trim().length > 0)
            return;
        if (!$scope.vm.selectedLibrary || $scope.vm.selectedLibrary.trim().length == 0)
            return;
        destroybroadCast();
    });
    }

    var isSearch = false;

    $scope.$on('Search_Click', function (event, args) {
        $scope.selected = [];
        $scope.DocTypeList = [];
        isSearch = true;
        docTypeInitalize();
    });
    function search_Click() {
        lastAppendItemCount = 0;
        LastAddedSelectedItemTypeId = angular.copy(SelectedTypeListForFilter);
        $scope.selected = [];
        $scope.DocTypeList = [];
        isSearch = true;
        docTypeInitalize();
    }


    function docTypeInitalize() {

        $scope.lastSelectedLibrary = '';
        $scope.loading = true;
        $scope.haveMoreRows = true;
        typeListRequestModel.pagenumber = 1;
        $scope.query.page = 1;
        $scope.query.totalCount = 0;

        $scope.getDocTypeList();
    }

    $scope.PageEvents.CancelDialog = function () {
        $mdDialog.cancel();

        $scope.PageEvents.UserAction = '';
        $scope.FormTitle = '';
        RoleViewModel = null;
        $scope.RolesModel = rolesFactory.rolesInitialValues();
        $scope.ShowMemberUserOnly = false;
        $scope.showValidation = false;
        $scope.ShowWarning = false;
        $scope.posting = false;
        $scope.PrivilageDetails = [];
    };

    $scope.PageEvents.Add = function () {
        $scope.PageEvents.UserAction = 'Add';
        var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;

        var dialogObject = {
            controller: TypeAddEditDialogController,
            preserveScope: false,
            templateUrl: 'Views/AddDocType.html',
            parent: angular.element(document.body),
            targetEvent: null,
            clickOutsideToClose: true,
            fullscreen: useFullScreen,
            bindToController: true,
            locals: {
                parentScope: $scope
            },
            onComplete: function () {
                $("#docTypeAddEditForm input[id=typeDescription]").focus();
                $("#docTypeAddEditForm input[id=typeDescription]").select();
            }
        };
        $mdDialog.show(dialogObject)
		.then(function (answer) {
		    $scope.status = '';
		}, function () {
		    $scope.status = '';
		});
        $scope.$watch(function () {
            return $mdMedia('xs') || $mdMedia('sm');
        }, function (wantsFullScreen) {
            $scope.customFullscreen = (wantsFullScreen === true);
        });
    };

    $scope.PageEvents.Edit = function () {
        if (typeof $scope.selected === 'undefined' || $scope.selected.length === 0) {
            $mdDialog.show(
					 $mdDialog.alert()
					 .parent(angular.element(document.body))
					 .clickOutsideToClose(true)
					 .title('Warning!')
					 .textContent('Select Type to edit.')
					 .ariaLabel('Warning!')
					 .ok('OK')
			 );
            return;
        }

        $scope.PageEvents.UserAction = 'Edit';
        var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;

        var dialogObject = {
            controller: TypeAddEditDialogController,
            preserveScope: false,
            templateUrl: 'Views/AddDocType.html',
            parent: angular.element(document.body),
            targetEvent: null,
            clickOutsideToClose: true,
            fullscreen: useFullScreen,
            bindToController: true,
            locals: {
                parentScope: $scope
            },
            onComplete: function () {
                $("#docTypeAddEditForm input[id=typeDescription]").focus();
                $("#docTypeAddEditForm input[id=typeDescription]").select();
            }
        };
        $mdDialog.show(dialogObject)
		.then(function (answer) {
		    $scope.status = '';
		}, function () {
		    $scope.status = '';
		});
        $scope.$watch(function () {
            return $mdMedia('xs') || $mdMedia('sm');
        }, function (wantsFullScreen) {
            $scope.customFullscreen = (wantsFullScreen === true);
        });
    };

    function TypeAddEditDialogController($scope, $mdDialog, parentScope) {
        $scope.hide = function () {
            $mdDialog.hide();
        };
        $scope.cancel = function () {
            $mdDialog.cancel();
        };
        $scope.answer = function () {
            $scope.AddSelectedUser();
            $mdDialog.hide();
        };

        $scope.TypeTextChange = CustomTypeTextChange;

        function CustomTypeTextChange($event) {
            if ($event.keyCode === 13) {
                $event.preventDefault();
            }
        }
        $scope.TypeButtonChange = function ($event, type) {
            if ($event.keyCode === 9) {
                $event.preventDefault();
                if (type == "Add")
                    $("#docTypeAddEditForm input[id=typeDescription]").focus();
                else if (type == "Edit") {
                    $("#docTypeAddEditForm input[id=typeDescription]").focus();
                    $("#docTypeAddEditForm input[id=typeDescription]").select();
                }

            }
            return false;
        }
        $scope.dialogPopup = {
            Header: '',
            Message: '',
            CallbackFunction: null,
            Show: function () {
                $('#popup-alert-dialog-bg').slideToggle();
            },
            OK: function () {
                $('#popup-alert-dialog-bg').slideToggle();
                $scope.dialogPopup.Header = '';
                $scope.dialogPopup.Message = '';

                if ($scope.dialogPopup.CallbackFunction) {
                    $scope.dialogPopup.CallbackFunction();
                    $scope.dialogPopup.CallbackFunction = null;
                }
            }
        }

        $scope.ErrorMessage = '';
        $scope.ShowWarning = false;
        $scope.posting = false;
        $scope.PageEvents = parentScope.PageEvents;

        var selectedRowIndex = -1;

        $scope.DocTypeModel = docTypeFactory.docTypeInitialValues();
        if ($scope.PageEvents.UserAction === 'Edit') {
            if (parentScope.selected && parentScope.selected.length > 0)
                selectedRowIndex = parentScope.DocTypeList.indexOf(parentScope.selected[0]);
            angular.copy(parentScope.selected[0], $scope.DocTypeModel);
        }

        $scope.PageEvents.BindLabel = function (data) {
            if ($scope.PageEvents.UserAction === 'Add') {
                return 'Add';
            } else {
                return 'Save';
            }
        };

        $scope.PageEvents.Save = function () {
            $scope.ShowWarning = false;
            $scope.posting = false;

            if (!$scope.DocTypeModel.TypeDescription || $scope.DocTypeModel.TypeDescription == '' || $scope.DocTypeModel.TAlias == '' || $scope.DocTypeModel.DmsExtension == '' || $scope.DocTypeModel.AppExtension == '') {
                return;
            }
            $scope.posting = true;
            var apiUrl = '';
            var docTypeApiModel;

            if ($scope.PageEvents.UserAction === 'Add') {
                apiUrl = docTypeFactory.postAPIUrl();
                parentScope.mc.getlogDetails("Debug", 'Requested Api Url:' + JSON.stringify(apiUrl));
                docTypeApiModel = docTypeFactory.getAPIModel(parentScope.vm.selectedLibrary, $scope.DocTypeModel);
                var promiseAdd = DocTypeService.addDocType(apiUrl, docTypeApiModel, parentScope.mc.loginModel.AuthKey);

                promiseAdd.then(function (response) {
                    if (response && response.status === 201) {

                        $scope.PageEvents.UserAction = '';

                        $scope.dialogPopup.CallbackFunction = function () {
                            $mdDialog.hide();
                        }
                        $scope.dialogPopup.Header = 'Success';
                        $scope.dialogPopup.Message = 'Type added succesfully.';
                        parentScope.mc.setSecurityLogDetails("Info", 'Success', $scope.DocTypeModel.TAlias, " Type Add", JSON.stringify(docTypeApiModel));
                        $scope.dialogPopup.Show();
                        $timeout(function () {
                            $scope.dialogPopup.OK();
                            $scope.DocTypeModel = docTypeFactory.docTypeInitialValues();

                            parentScope.selected = [];
                            parentScope.DocTypeList = [];
                            docTypeInitalize();
                        }, 2000);
                    }
                    else {
                        $scope.ShowWarning = true;
                        // parentScope.mc.setSecurityLogDetails("Error", "Server Response:" + JSON.stringify(response) + ",Mehod :POST,Api Url:" + apiUrl + " Parameters are" + JSON.stringify(docTypeApiModel));
                        parentScope.mc.setSecurityLogDetails("Info", 'Failure', $scope.DocTypeModel.TAlias, " Type Add", JSON.stringify(docTypeApiModel));
                        if (response && response.data && response.data.details && response.data.details.message) 
                            $scope.ErrorMessage = response.data.details.message;
                        else
                            $scope.ErrorMessage = "Error in adding new type due to unknown errors.";
                    }

                    $scope.posting = false;
                }, function () {
                    $scope.posting = false;
                    $scope.ShowWarning = true;
                    $scope.ErrorMessage = "Error in adding new type due to unknown errors.";
                    //parentScope.mc.getlogDetails("Error", "Error in adding new type due to unknown errors.");
                    // parentScope.mc.setSecurityLogDetails("Error", "Server Response:" + JSON.stringify(response) + ",Mehod :POST,Api Url:" + apiUrl + " Parameters are" + JSON.stringify(docTypeApiModel));
                    parentScope.mc.setSecurityLogDetails("Info", 'Failure', $scope.DocTypeModel.TAlias, " Type Add", JSON.stringify(docTypeApiModel));
                });
            }
            else if ($scope.PageEvents.UserAction === 'Edit') {
                $scope.DocTypeModel.libraryName = parentScope.vm.selectedLibrary;
                var apiUrlExist = docTypeFactory.getAPIUrl('GETDOCTYPESEXIST', $scope.DocTypeModel);
                var promiseExist = DocTypeService.getDocTypes(apiUrlExist, parentScope.mc.loginModel.AuthKey);
                promiseExist.then(function (aresponse) {
                    if (aresponse.data.data.length == 0) {
                        $scope.posting = false;
                        $scope.ShowWarning = true;
                        $scope.ErrorMessage = " does not contain " + $scope.DocTypeModel.TAlias;
                    }
                    else {
                apiUrl = docTypeFactory.putAPIUrl($scope.DocTypeModel);
                docTypeApiModel = docTypeFactory.getAPIModel(parentScope.vm.selectedLibrary, $scope.DocTypeModel);
                parentScope.mc.getlogDetails("Debug", 'Requested Api Url:' + JSON.stringify(apiUrl));
                var promiseEdit = DocTypeService.UpdateDocType(apiUrl, docTypeApiModel, parentScope.mc.loginModel.AuthKey);

                promiseEdit.then(function (response) {
                    if (!response.data.error) {
                        $scope.dialogPopup.CallbackFunction = function () {
                            $mdDialog.hide();
                        }
                        $scope.dialogPopup.Header = 'Success';
                        $scope.dialogPopup.Message = 'Type edited succesfully.';
                        // parentScope.mc.setSecurityLogDetails("Info", parentScope.mc.loginModel.UserName + " updated new Type(" + $scope.DocTypeModel.TAlias + ")");
                        parentScope.mc.setSecurityLogDetails("Info", 'Success', $scope.DocTypeModel.TAlias, " Type Update", JSON.stringify(docTypeApiModel));
                        $scope.dialogPopup.Show();
                        $timeout(function () {
                            $scope.dialogPopup.OK();
                        }, 2000);

                        if (selectedRowIndex >= 0) {
                            parentScope.DocTypeList[selectedRowIndex].TypeDescription = $scope.DocTypeModel.TypeDescription;
                            parentScope.DocTypeList[selectedRowIndex].DmsExtension = $scope.DocTypeModel.DmsExtension;
                            parentScope.DocTypeList[selectedRowIndex].AppExtension = $scope.DocTypeModel.AppExtension;
                            parentScope.DocTypeList[selectedRowIndex].HIPAAComplaint = $scope.DocTypeModel.HIPAAComplaint;
                        }

                        var tmpList = [];
                        tmpList = angular.copy(parentScope.DocTypeList);
                        parentScope.selected = [];
                        parentScope.DocTypeList = [];
                        parentScope.DocTypeList = angular.copy(tmpList);
                        $scope.PageEvents.UserAction = '';
                        $scope.DocTypeModel = docTypeFactory.docTypeInitialValues();
                        tmpList = [];
                    }
                    else {
                        $scope.ShowWarning = true;
                        //parentScope.mc.setSecurityLogDetails("Error", "Server Response:" + JSON.stringify(response) + ",Mehod :PUT,Api Url:" + apiUrl + " Parameters are" + JSON.stringify(docTypeApiModel));
                        parentScope.mc.setSecurityLogDetails("Info", 'Failure', $scope.DocTypeModel.TAlias, " Type Update", JSON.stringify(docTypeApiModel));
                        if (response && response.data && response.data.details && response.data.details.message) {
                            $scope.ErrorMessage = response.data.details.message;
                           
                        }
                        else {
                            $scope.ErrorMessage = "Error in updating  type due to unknown errors.";
                        }


                    }


                    $scope.posting = false;
                }, function (then) {
                    $scope.posting = false;
                    $scope.ShowWarning = true;
                    $scope.ErrorMessage = 'Error in updating type due to unknown errors.'
                    parentScope.mc.setSecurityLogDetails("Info", 'Failure', $scope.DocTypeModel.TAlias, " Type Update", JSON.stringify(docTypeApiModel));
                  
                });
                    }
                },

            function (aresponse) {
                $scope.ErrorMessage = " does not contain " + $scope.DocTypeModel.TAlias;
                //$q.all(deferredarray).then(function () {
                //    resolve({ Status: -1, ErrorMessage: errorMesssage });
                //}, function () {
                //    resolve({ Status: -1, ErrorMessage: errorMesssage });
                //});
            });
            }
        };
    }

   
    $scope.PageEvents.ShowOnlySelected = function () {
        $scope.vm.viewSelectedOnlyLabel = $scope.vm.viewSelectedOnlyLabel == 'View selected' ? 'Show all' : 'View selected';
    }
    $scope.filterSelected = function (selected, field) {
        return function (type) {
            if ($scope.viewSelectedOnlyLabel == 'Show all') {
                if (selected.length == 0) {
                    $scope.viewSelectedOnlyLabel = 'View selected';
                }
                var items = $filter('filter')(selected, type, true);
                if (items.length > 0)
                    return true;

                return false;
            } else {
                return true;
            }
        }
    };

}



