﻿app.controller("DocumentsController", DocumentsController);
DocumentsController.$inject = ['$scope', '$rootScope', '$filter', '$timeout', '$mdDialog', '$mdMedia', 'DocumentsService', 'DocumentsFactory', 'homeFactory', '$q', 'CONST_HISTORY_DOCUMENTS_FILEDS', 'CONST_DOCUMENTS_FILEDS', 'FileService', 'userFactory', 'UserService'];

function DocumentsController($scope, $rootScope, $filter, $timeout, $mdDialog, $mdMedia, DocumentsService, DocumentsFactory, homeFactory, $q, CONST_HISTORY_DOCUMENTS_FILEDS, CONST_DOCUMENTS_FILEDS, FileService, userFactory, UserService) {

	$scope.DocumentsList = [];
	$scope.selected = [];
	$scope.DocumentTitle = 'Documents';
	$scope.DocumentSelectTitle = 'Document(s)';
	$scope.HideSearch = false;
	$scope.isversion = false;
	var DocumentsRequestModel = homeFactory.requestModelInstance();
	var FilterSearchTimeout;
	$scope.PageEvents.Add = undefined;
	$scope.PageEvents.Back = undefined;
	$scope.IsShowDocumentsList = false;
	$scope.DocumentSearch = {
		DocumentNumber: '',
		Version: '',
		UserID: '',
		UserType: '',
		Custom1: '',
		Custom2: ''
	};

	$scope.ContextMenuFunctions = {
		//Delete: function () { $scope.PageEvents.Delete(); },
		ViewHistory: function () { $scope.PageEvents.ViewHistory(); },
		ViewVersion: function () { $scope.PageEvents.ViewVersion(); },
		CheckinDocument: function () { $scope.CheckinDocument(); },
		CheckedOutInformation: function () { $scope.PageEvents.CheckedOutInformation(); },
		ViewSecurity: function () { $scope.PageEvents.ViewSecurity(); },
		UnlockDocument: function () {
			$scope.PageEvents.UnlockDocument();
		}
	};

	$timeout(function () {
		$('#autoContainer').removeClass('md-input-has-placeholder');
	})

	function setContextMenuObject() {
		$scope.menuList = [
			{
				Label: 'Check Effective Access',
				Icon: 'icon-view-documents-security',
				onClick: $scope.ContextMenuFunctions.ViewSecurity,
				Enable: $scope.selected.length == 1,
				IconType: 'font-icon'
			},
		{
			Label: 'History',
			Icon: 'icon-view-documents-history',
			onClick: $scope.ContextMenuFunctions.ViewHistory,
			Enable: $scope.selected.length == 1,
			IconType: 'font-icon'
		},
		{
			Label: 'Checked out Information',
			Icon: 'icon-view-checked-out-info',
			onClick: $scope.ContextMenuFunctions.CheckedOutInformation,
			Enable: $scope.selected.length == 1 && $scope.selected[0].IsCheckedOut,
			IconType: 'font-icon'
		},
		/*{
			Label: 'Checkin',
			Icon: 'icon-checkin',
			onClick: $scope.ContextMenuFunctions.CheckinDocument,
			Enable: $scope.selected.length == 1 && $scope.selected[0].IsCheckedOut,
			IconType: 'font-icon'
		},*/
		{
			Label: 'Un Lock',
			Icon: 'icon-unlock',
			onClick: $scope.ContextMenuFunctions.UnlockDocument,
			Enable: $scope.selected.length > 0 && ischeckedOutrawfn(),
			IconType: 'font-icon'
		}
		];
	};

	var ischeckedOutrawfn = function () {
		var showUnlock = true;
		angular.forEach($scope.selected, function (selectedItem) {
			if (!selectedItem.IsCheckedOut) {
				showUnlock = false;
				return showUnlock;
			}
		});
		if (showUnlock)
			return showUnlock;
	}


	$scope.query = {
		limit: DocumentsRequestModel.pageLength,
		page: DocumentsRequestModel.pagenumber,
		totalCount: 0
	};

	$scope.endScroll = function (info) {
		if ($scope.query.totalCount > $scope.DocumentsList.length) {
			DocumentsRequestModel.pagenumber++;
			getDocumentsList();
		}
	}

	$scope.onPaginate = function (page, limit) {
		isSearch = false;
		if (!$scope.isversion) {
			DocumentsRequestModel.pagenumber = page;
			DocumentsRequestModel.pageLength = limit;
			getDocumentsList();
		} else {
			subrequestModel.pagenumber = page;
			subrequestModel.pageLength = limit;
			getVersionDocumentsList();
		}
		$scope.promise = $timeout(function () {
		}, 2000);
	};
	$scope.viewSelectedOnlyLabel = 'View selected';
	$scope.filterSelected = function (selected, field) {
		return function (documents) {
			if ($scope.viewSelectedOnlyLabel == 'Show all') {
				if (selected.length == 0) {
					$scope.viewSelectedOnlyLabel = 'View selected';
				}
				var items = $filter('filter')(selected, documents, true);
				if (items.length > 0)
					return true;

				return false;
			} else {
				return true;
			}
		}
	};
	$scope.PageEvents.ShowOnlySelected = function () {
		$scope.vm.viewSelectedOnlyLabel = $scope.vm.viewSelectedOnlyLabel == 'View selected' ? 'Show all' : 'View selected';
	}


	$scope.onDocumentsdeSelect = function (DocumentsModel) {
		setContextMenuObject();
		if (SelectedDocumentListForFilter.length > 0) {
			SelectedDocumentListForFilter = $.grep(SelectedDocumentListForFilter,
								function (item, index) {
									return item.Id != DocumentsModel.Id;
								});
		}
		if (SelectedDocumentListForFilter.length > 0) {
			LastAddedSelectedItemDocumentId = $.grep(LastAddedSelectedItemDocumentId,
								   function (item, index) {
									   return item.Id != captionModel.Id;
								   });
		}

	};

	$scope.onDocumentsSelect = function (DocumentsModel) {
		setContextMenuObject();
		var tempListFilter = $filter('filter')(SelectedDocumentListForFilter, {
			Id: DocumentsModel.Id
		}, true);
		if (tempListFilter.length === 0) {
			SelectedDocumentListForFilter.push(angular.copy(DocumentsModel));
		}
	};

	//$scope.loadStuff = function () {
	//    $scope.promise = $timeout(function () {
	//    }, 2000);
	//};

	$scope.$on('Window_Scrolled', function () {
		if (!$scope.isversion) {
			if ($scope.query.totalCount > $scope.DocumentsList.length) {
				DocumentsRequestModel.pagenumber++;
				getDocumentsList();
			}
		} else {
			if ($scope.query.totalCount > $scope.DocumentsList.length) {
				subrequestModel.pagenumber++;
				getVersionDocumentsList();
			}
		}
	});

	$scope.SearchCount = 0;

	function getDocumentsList() {
		$scope.DocumentTitle = 'Documents';
		$scope.DocumentSelectTitle = 'Document(s)';
		$scope.isversion = false;
		$scope.HideSearch = false;
		$scope.PageEvents.Back = undefined;
		$scope.IsShowDocumentsList = false;
		//$scope.selected = [];

		$scope.query.totalCount = 0;
		//if ($scope.vm.selectedApp.NoAppsPermission.trim().length > 0) return;
		//if (!$scope.vm.selectedLibrary || $scope.vm.selectedLibrary.trim().length === 0) return;
		$scope.lastSelectedLibrary = $scope.vm.selectedLibrary;
		DocumentsRequestModel.libraryName = $scope.vm.selectedLibrary;
		if ($scope.selectedAuthorItem)
			$scope.DocumentSearch.UserID = $scope.selectedAuthorItem.UserId;
		else
			$scope.DocumentSearch.UserID = '';

		if ($scope.DocumentSearch.UserID.length == 0) {
			$scope.DocumentSearch.UserType = '';
		}
		else if ($scope.DocumentSearch.UserType.length == 0) {
			$scope.DocumentSearch.UserType = 'Author';
		}
		if ($scope.DocumentSearch.DocumentNumber == '' && $scope.DocumentSearch.Version == '' && $scope.DocumentSearch.UserID == ''
			&& $scope.DocumentSearch.UserType == '' && $scope.DocumentSearch.Custom1 == '' && $scope.DocumentSearch.Custom2 == '' && !$scope.DocumentSearch.IsCheckedOut) {
			$scope.DocumentsList = [];
			return;
		}
		DocumentsRequestModel.DocumentNumber = $scope.DocumentSearch.DocumentNumber;
		DocumentsRequestModel.Version = $scope.DocumentSearch.Version;
		DocumentsRequestModel.UserID = $scope.DocumentSearch.UserID;
		DocumentsRequestModel.UserType = $scope.DocumentSearch.UserType;
		DocumentsRequestModel.Custom1 = $scope.DocumentSearch.Custom1;
		DocumentsRequestModel.Custom2 = $scope.DocumentSearch.Custom2;
		DocumentsRequestModel.IsCheckedOut = null;
		if ($scope.DocumentSearch.IsCheckedOut) {
			DocumentsRequestModel.IsCheckedOut = $scope.DocumentSearch.IsCheckedOut;
		}

		$scope.SearchCount = 0;

		if (DocumentsRequestModel.DocumentNumber.length > 0) {
			$scope.SearchCount += 1;
		}
		if (DocumentsRequestModel.UserID.length > 0) {
			$scope.SearchCount += 1;
		}
		if (DocumentsRequestModel.Version.length > 0) {
			$scope.SearchCount += 1;
		}
		if (DocumentsRequestModel.Custom1.length > 0) {
			$scope.SearchCount += 1;
		}
		if (DocumentsRequestModel.Custom2.length > 0) {
			$scope.SearchCount += 1;
		}
		if (DocumentsRequestModel.IsCheckedOut) {
			$scope.SearchCount += 1;
		}
		if (isSearch) {
			//  $scope.showSearchProgress = true;
			showProgressDialog();
		}
		var searchAPIUrl = DocumentsFactory.searchAPIUrl(DocumentsRequestModel);
		$scope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(searchAPIUrl));
		var DocumentsRequest = DocumentsService.getDocuments(searchAPIUrl, $scope.mc.loginModel.AuthKey);

		DocumentsRequest.then(function (response) {
			if (response && response.data && response.status === 200) {
				$scope.mc.getlogDetails("Info", "Documents fetched.");
				$scope.query.totalCount = response.data.total_count;
				var tempListFilter = [];
				var DocumentsUIModel;
				var filterTempModel;
				if (lastAppendItemCount > 0) {
					$scope.DocumentsList.splice($scope.DocumentsList.length - lastAppendItemCount, lastAppendItemCount);
					$scope.selected.splice($scope.selected.length - lastAppendItemCount, lastAppendItemCount);
				}

				angular.forEach(response.data.data, function (typeItem) {
					DocumentsUIModel = DocumentsFactory.getUIModel(typeItem);
					DocumentsUIModel.Size = $scope.bytesToSize(DocumentsUIModel.Size, "2");
					if (SelectedDocumentListForFilter.length === 0) {
						$scope.DocumentsList.push(DocumentsUIModel);
					}
					else {
						tempListFilter = $filter('filter')(SelectedDocumentListForFilter, {
							Id: DocumentsUIModel.Id
						}, true);
						if (tempListFilter.length === 0) {
							$scope.DocumentsList.push(DocumentsUIModel);
						}
						else {
							LastAddedSelectedItemDocumentId = $.grep(LastAddedSelectedItemDocumentId,
							   function (item, index) {
								   return item.Id != DocumentsUIModel.Id;
							   });
							tempListFilter[0].Author = DocumentsUIModel.Author;
							tempListFilter[0].Class = DocumentsUIModel.Class;
							// tempListFilter[0].CreateDate = GetDate(DocumentsUIModel.CreateDate);
							tempListFilter[0].Custom1 = DocumentsUIModel.Custom1;
							tempListFilter[0].Custom2 = DocumentsUIModel.Custom2;
							tempListFilter[0].Database = DocumentsUIModel.Database;
							tempListFilter[0].DefaultSecurity = DocumentsUIModel.DefaultSecurity;
							tempListFilter[0].DocumentNumber = DocumentsUIModel.DocumentNumber;
							// tempListFilter[0].EditDate = GetDate(DocumentsUIModel.EditDate);
							tempListFilter[0].Extension = DocumentsUIModel.Extension;
							tempListFilter[0].HasAttachment = DocumentsUIModel.HasAttachment;
							tempListFilter[0].Id = DocumentsUIModel.Id;
							tempListFilter[0].InUse = DocumentsUIModel.InUse;
							tempListFilter[0].IsCheckedOut = DocumentsUIModel.IsCheckedOut;
							tempListFilter[0].IsHipaa = DocumentsUIModel.IsHipaa;
							tempListFilter[0].Iwl = DocumentsUIModel.Iwl;
							tempListFilter[0].LastUser = DocumentsUIModel.LastUser;
							tempListFilter[0].Name = DocumentsUIModel.Name;
							tempListFilter[0].Operator = DocumentsUIModel.Operator;
							tempListFilter[0].Size = $scope.bytesToSize(DocumentsUIModel.Size);
							tempListFilter[0].Type = DocumentsUIModel.Type;
							tempListFilter[0].Version = DocumentsUIModel.Version;
							tempListFilter[0].WorkSpaceId = DocumentsUIModel.WorkSpaceId;
							tempListFilter[0].WorkSpaceName = DocumentsUIModel.WorkSpaceName;
							tempListFilter[0].WsType = DocumentsUIModel.WsType;
							tempListFilter[0].TypeResolver = DocumentsUIModel.TypeResolver;
							tempListFilter[0].CheckedOutBy = DocumentsUIModel.CheckedOutBy;
							tempListFilter[0].CheckedOutDate = DocumentsUIModel.CheckedOutDate;
							filterTempModel = angular.copy(tempListFilter[0]);
							$scope.DocumentsList.push(filterTempModel);
							$scope.selected.push(filterTempModel);
							filterTempModel = null;
						}
						tempListFilter = [];

					}
					DocumentsUIModel = null;
				});
				lastAppendItemCount = 0;
				//if ($scope.appsVar.SearchText.length === 0 && !isValidFilterFind()) {
				//    angular.forEach(LastAddedSelectedItemDocumentId, function (Document) {
				//        filterTempModel = angular.copy(Document);
				//        $scope.CaptionDetails.push(filterTempModel);
				//        $scope.selected.push(filterTempModel);
				//        filterTempModel = null;
				//        lastAppendItemCount += 1;
				//    });
				//}              
				$timeout(function () {
					$('td').filter(function () {
						if (!$(this).hasClass("md-checkbox-cell")) {
							if ($(this).text().trim().length === 0) {
								$(this).html('&nbsp;');
							}
						}
					});
					$('md-checkbox').click(function (event) {
						$('.context-menu-container').remove();
					});
				});
				$scope.showSearchProgress = false;
				$scope.IsShowDocumentsList = true;
				if (isSearch) $mdDialog.hide();
			}
			else {
				$scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
				if (response.data && response.data.details && response.data.details.message) {
					$mdDialog.show(
					   $mdDialog.alert()
					   .parent(angular.element(document.body))
					   .clickOutsideToClose(true)
					   .title('Warning!')
					   .textContent(response.data.details.message)
					   .ariaLabel('')
					   .ok('OK')
			   );
					$scope.showSearchProgress = false;
					if (isSearch) $mdDialog.hide();
				}
				else {
					$mdDialog.show(
					  $mdDialog.alert()
					  .parent(angular.element(document.body))
					  .clickOutsideToClose(true)
					  .title('Warning!')
					  .textContent(response.data.error.message)
					  .ariaLabel('')
					  .ok('OK')
			  );
					$scope.showSearchProgress = false;
					if (isSearch) $mdDialog.hide();
				}
			}
		}, function (response) {
			$scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
			if (response.data && response.data.details && response.data.details.message) {
				$mdDialog.show(
				   $mdDialog.alert()
				   .parent(angular.element(document.body))
				   .clickOutsideToClose(true)
				   .title('Warning!')
				   .textContent(response.data.details.message)
				   .ariaLabel('')
				   .ok('OK')
		   );
				$scope.showSearchProgress = false;
			}
			else {
				$mdDialog.show(
				  $mdDialog.alert()
				  .parent(angular.element(document.body))
				  .clickOutsideToClose(true)
				  .title('Warning!')
				  .textContent(response.data.error.message)
				  .ariaLabel('')
				  .ok('OK')
		  );
				$scope.showSearchProgress = false;
			}
		});
	};
	function showProgressDialog() {
		$mdDialog.show({
			parent: angular.element(document.body),
			template: '<md-dialog ng-cloak height="100%" style="min-width: 1px !important;"><md-dialog-content><div class="md-dialog-content-clearpadding">' +
			  '<md-progress-circular md-mode="indeterminate"></md-progress-circular>' +
			  '</div></md-dialog-content></md-dialog>',
			controller: DialogController
		});
	}

	var selectedRowIndex = -1;

	$scope.PageEvents.UnlockDocument = function () {
		var errormessage = ' If you continue to unlock the document ' + $scope.selected[0].Name + ', ' + $scope.selected[0].Author + ' will be unable to checkin their changes to the file </br> since it was last checked out. Do you want to continue?';
		if ($scope.selected.length > 1) {
			var errormessage = ' If you continue to unlock these document(s), authors will be unable to checkin their changes to the file </br> since it was last checked out. Do you want to continue?';
		}
		var useFullScreen = ($mdMedia('sm') || $mdMedia('xs'))
			   && $scope.customFullscreen;
		var confirm = $mdDialog.confirm().title('Warning!').theme('confirm-dialog').htmlContent(errormessage)
							.ariaLabel('').ok('Yes').cancel('No');

		var deferredarray = [];
		$mdDialog.show(confirm).then(
				function () {
					angular.forEach($scope.selected, function (document) {
						var deferred = $q.defer();
						var UnlockDocumentModel = [];
						var apiUrl = DocumentsFactory.getUnlockDocumentAPIURL('UNLOCKDOCUMENT', document.Id);
						//UnlockDocumentModel.DocumentNumber = document.DocumentNumber;
						//UnlockDocumentModel.DocumentVersion = document.Version;
						//var serverModel = DocumentsFactory.getUnlockDocumentPutModel(UnlockDocumentModel, $scope.vm.selectedLibrary);

						// $scope.mc.getlogDetails("Debug", 'Method:POST;URL:' + JSON.stringify(apiUrl));
						$scope.mc.setSecurityLogDetails("Info", 'Success:', document.Id, ' Document Unlock');
						var promise = DocumentsService.UnlockDocument(apiUrl, $scope.mc.loginModel.AuthKey);
						promise.then(function (response) {
							deferred.resolve(response);
							if (response && response.data && response.status === 200) {///response.data.IsUnlocked
								selectedRowIndex = $scope.DocumentsList.indexOf(document);
								$scope.DocumentsList[selectedRowIndex].IsCheckedOut = !document.IsCheckedOut;
								$scope.mc.setSecurityLogDetails("Info", 'Failure:', document.Id, ' Document Unlock');
							} else {
								$scope.mc.setSecurityLogDetails("Info", 'Failure:', document.Id, ' Document Unlock');
								if (response && response.data && response.data.statusDetail) {
									$mdDialog.show(
													  $mdDialog.alert()
													  .parent(angular.element(document.body))
													  .clickOutsideToClose(true)
													  .title('Warning!')
													  .textContent(response.data.statusDetail)
													  .ariaLabel('')
													  .ok('OK'));
								}
							}
						}, function (response) {
							$scope.mc.setSecurityLogDetails("Info", 'Failure:', document.Id, ' Document Unlock');
						});
						deferredarray.push(deferred.promise);
					});

					$q.all(deferredarray).then(function () {
						//$scope.selected = [];
					});
				}, function () {
				});
	}

	var SelectedDocumentListForFilter = [];
	var LastAddedSelectedItemDocumentId = [];
	var lastAppendItemCount = 0;
	function isValidFilterFind() {
		var filterKeyItem = null;
		var blnResult = false;

		for (var iCount = 0; iCount < requestModel.filters.length; iCount++) {
			filterKeyItem = requestModel.filters[iCount];
			if (filterKeyItem.FilterValues && filterKeyItem.FilterValues[0] && filterKeyItem.FilterValues[0].trim().length > 0) {
				blnResult = true;
				break;
			}
			filterKeyItem = null;
		}
		return blnResult;
	}


	$scope.onDocumentsTableFilter = function (value, key, isInstantFilter, disablePerformFilter) {
		if (DocumentsRequestModel.filters.length > 0) {
			DocumentsRequestModel.filters = jQuery.grep(DocumentsRequestModel.filters, function (filterItem) {
				return filterItem.FilterKey !== key;
			});
		}

		var filterValueList = [];
		filterValueList[0] = value;

		var filterItem = { 'FilterKey': key, 'FilterValues': filterValueList };
		DocumentsRequestModel.filters.push(filterItem);
		if (DocumentsRequestModel.filters.length > 0) {
			DocumentsRequestModel.filters = jQuery.grep(DocumentsRequestModel.filters, function (filterItem) {
				if (DocumentsRequestModel.filters != "") {
					return $scope.FilterCount = filterValueList;
				}

			});
		}

		DocumentsRequestModel.pagenumber = 1;
		$scope.query.page = 1;
		$scope.query.totalCount = 0;

		if (FilterSearchTimeout) $timeout.cancel(FilterSearchTimeout);

		if (!disablePerformFilter) {
			if (isInstantFilter) {
				$scope.selected = [];
				$scope.DocumentsList = [];
				getDocumentsList();
			} else {
				FilterSearchTimeout = $timeout(function () {
					$scope.selected = [];
					$scope.DocumentsList = [];
					getDocumentsList();
				}, 2000);
			}
		};
	};

	$scope.PageEvents.ViewSecurity = function () {
		if (typeof $scope.selected !== 'undefined' && $scope.selected.length > 0) {
			$scope.Id = $scope.selected[0].Id;

			var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
			$mdDialog.show({
				controller: DocumentSecurityController,
				preserveScope: false,
				templateUrl: 'Views/DocumentSecurity.html',
				parent: angular.element(document.body),
				clickOutsideToClose: true,
				fullscreen: useFullScreen,
				onComplete: function () {
					$("#DocumentAccessForm input[id=UserId]").focus();
					$("#DocumentAccessForm input[id=UserId]").select();
				},
				locals: {
					parentScope: $scope
				}
			}).then(
					function (answer) {
						$scope.status = '.';
					}, function () {
						$scope.status = '';
					});
			$scope.$watch(function () {
				return $mdMedia('xs') || $mdMedia('sm');
			}, function (wantsFullScreen) {
				$scope.customFullscreen = (wantsFullScreen === true);
			});
		}
	}


	/*  $scope.PageEvents.ViewVersion = function () {
		  if (typeof $scope.selected !== 'undefined' && $scope.selected.length > 0) {
			  $scope.Id = $scope.selected[0].Id;
  
			  var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
			  $mdDialog.show({
				  controller: DocumentsVersionController,
				  preserveScope: false,
				  templateUrl: 'Views/ViewDocumentsVersion.html',
				  parent: angular.element(document.body),
				  clickOutsideToClose: true,
				  fullscreen: useFullScreen,
				  locals: {
					  parentScope: $scope
				  }
			  }).then(
					  function (answer) {
						  $scope.status = '.';
					  }, function () {
						  $scope.status = '';
					  });
			  $scope.$watch(function () {
				  return $mdMedia('xs') || $mdMedia('sm');
			  }, function (wantsFullScreen) {
				  $scope.customFullscreen = (wantsFullScreen === true);
			  });
		  } 
	  }*/

	$scope.PageEvents.ViewHistory = function () {
		if (typeof $scope.selected !== 'undefined' && $scope.selected.length > 0) {
			$scope.Id = $scope.selected[0].Id;

			var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
			$mdDialog.show({
				controller: DocumentsHistoryController,
				preserveScope: false,
				templateUrl: 'Views/ViewDocumentsHistory.html',
				parent: angular.element(document.body),
				clickOutsideToClose: true,
				fullscreen: useFullScreen,
				onComplete: function () {
					$("#ViewDocumentsHistoryForm input[id=btnCancel]").focus();
				},
				locals: {
					parentScope: $scope
				}
			}).then(
					function (answer) {
						$scope.status = '.';
					}, function () {
						$scope.status = '';
					});
			$scope.$watch(function () {
				return $mdMedia('xs') || $mdMedia('sm');
			}, function (wantsFullScreen) {
				$scope.customFullscreen = (wantsFullScreen === true);
			});
		}
	}

	$scope.PageEvents.CheckedOutInformation = function () {
		if (typeof $scope.selected !== 'undefined' && $scope.selected.length > 0) {
			$scope.Id = $scope.selected[0].Id;

			var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
			$mdDialog.show({
				controller: CheckedOutInformationController,
				preserveScope: false,
				templateUrl: 'Views/CheckedOutInformation.html',
				parent: angular.element(document.body),
				clickOutsideToClose: true,
				fullscreen: useFullScreen,
				locals: {
					parentScope: $scope
				}
			});
			$scope.$watch(function () {
				return $mdMedia('xs') || $mdMedia('sm');
			}, function (wantsFullScreen) {
				$scope.customFullscreen = (wantsFullScreen === true);
			});
		}
	}
	$scope.BacktoDocuments = function () {
		$scope.DocumentsList = [];
		$scope.selected = [];
		getDocumentsList();
	};
	var subrequestModel = homeFactory.requestModelInstance();
	function getVersionDocumentsList() {
		$scope.DocumentTitle = 'Versions of ' + $scope.SelectedId;
		$scope.DocumentSelectTitle = 'Version(s) of ' + $scope.SelectedId;
		$scope.isversion = true;
		$scope.HideSearch = true;

		$scope.PageEvents.Back = $scope.BacktoDocuments;
		$scope.DocumentsList = [];
		$scope.selected = [];

		subrequestModel.libraryName = $scope.vm.selectedLibrary;
		var apiUrl = DocumentsFactory.getAPIUrl('VIEWVERSIONDOCUMENTS', subrequestModel, $scope.SelectedId)
		$scope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(apiUrl));
		// $scope.mc.setSecurityLogDetails("Info", 'Method:GET;URL:' + JSON.stringify(apiUrl));
		var subDocuments = DocumentsService.getVersionDocumentsList(apiUrl, $scope.mc.loginModel.AuthKey);

		subDocuments.then(function (response) {
			if (response.data && response.status === 200) {
				$scope.mc.getlogDetails("Debug", "Document version fetched, parameters are " + JSON.stringify(subrequestModel));
				$scope.query.totalCount = response.data[CONST_DOCUMENTS_FILEDS.TotalCount];
				angular.forEach(response.data[CONST_DOCUMENTS_FILEDS.DocumentsVersionsList], function (document) {
					$scope.DocumentsList.push(DocumentsFactory.getVersionUIModel(document));
				});
			} else {
				$scope.mc.getlogDetails("Error", JSON.stringify(response) + ",parameters are " + JSON.stringify(subrequestModel));
			}
		}, function (response) {
			$scope.mc.getlogDetails("Error", JSON.stringify(response) + ",parameters are " + JSON.stringify(subrequestModel));
		});

	}

	$scope.ViewVersions = function (event, id) {
		$scope.SelectedId = id;
		getVersionDocumentsList()
		event.stopPropagation();
	};
	$scope.stopEvent = function (event) {
		event.stopPropagation();
	};
	$scope.bytesToSize = function (bytes, precision) {
		var kilobyte = 1024;
		var megabyte = kilobyte * 1024;
		var gigabyte = megabyte * 1024;
		var terabyte = gigabyte * 1024;

		if ((bytes >= 0) && (bytes < kilobyte)) {
			return bytes + ' B';

		} else if ((bytes >= kilobyte) && (bytes < megabyte)) {
			return (bytes / kilobyte).toFixed(precision) + ' KB';

		} else if ((bytes >= megabyte) && (bytes < gigabyte)) {
			return (bytes / megabyte).toFixed(precision) + ' MB';

		} else if ((bytes >= gigabyte) && (bytes < terabyte)) {
			return (bytes / gigabyte).toFixed(precision) + ' GB';

		} else if (bytes >= terabyte) {
			return (bytes / terabyte).toFixed(precision) + ' TB';

		} else {
			return bytes + ' B';
		}
	}


	function DocumentSecurityController($scope, $mdDialog, parentScope, CONST_DOCUMENTS_FILEDS, userFactory, GroupService, groupFactory, CONST_USERS, CONST_GROUPS_VIEW_DETAILS, UserService) {
		$scope.hide = function () {
			$mdDialog.hide();
		};
		$scope.cancel = function () {
			$mdDialog.cancel();
		};
		$scope.answer = function () {
			$mdDialog.hide();
		};

		$scope.DocumentAccessList = [];
		var subrequestModel = homeFactory.requestModelInstance();
		$scope.PageEvents = {
			UserAction: 'Security'
		};
		//$scope.PageEvents.UserAction = 'Security of ' + parentScope.selected[0].Name;
		$scope.ErrorMessage = '';
		$scope.IsShowErrorMsg = false;
		$scope.SelectedUserId = '';
		$scope.SearchText = '';

		$scope.DocumentsAccess = DocumentsFactory.documentsSecurityInitailValues();
		$scope.documents = angular.copy(parentScope.selected[0]);

		var subrequestModel = homeFactory.requestModelInstance();

		$scope.userQuerySearch = function (query) {
			$scope.ErrorMessage = '';
			$scope.IsShowErrorMsg = false;
			var userList = [];
			var deferred = $q.defer();

			if (parentScope.vm.selectedApp.NoAppsPermission.trim().length > 0)
				return;
			if (!parentScope.vm.selectedLibrary || parentScope.vm.selectedLibrary.trim().length == 0)
				return;

			var userRequestModel = homeFactory.requestModelInstance();
			userRequestModel.libraryName = parentScope.vm.selectedLibrary;
			userRequestModel.searchText = query;
			var apiUrl = userFactory.getAPIUrl('SEARCHUSERS', userRequestModel);
			parentScope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(apiUrl));
			//parentScope.mc.setSecurityLogDetails("Info", 'Method:GET;URL:' + JSON.stringify(apiUrl));
			var promise = UserService.getUsers(apiUrl, parentScope.mc.loginModel.AuthKey)
			promise.then(function (response) {
				if (response["status"] == 200) {
					parentScope.mc.getlogDetails("Debug", "Uses fetched, parameters are " + JSON.stringify(userRequestModel));
					deferred.resolve(userList);
					angular.forEach(response["data"]["data"], function (user) {
						userList.push(user[CONST_USERS.UserId]);
					});
				} else {
					parentScope.mc.getlogDetails("Error", JSON.stringify(response) + ",parameters are " + JSON.stringify(userRequestModel));
				}
			}, function () {
				parentScope.mc.getlogDetails("Error", JSON.stringify(response) + ",parameters are " + JSON.stringify(userRequestModel));
			});
			return deferred.promise;
		};

		$scope.UserSelected = function () {
			$scope.DocumentAccessList = [];
			$scope.IsShowErrorMsg = false;
			$scope.IsLoading = false;
			if (!$scope.SelectedUserId || $scope.SelectedUserId.trim().length == 0) {
				return;
			}
			getSecurityDocumentsList();
		};
		$scope.DocumentSecurityButtonChange = function ($event) {
			if ($event.keyCode === 9) {
				$event.preventDefault();
				$("#UserId").focus();

			}
			return false;
		}

		function getSecurityDocumentsList() {
			var DocumentsAccess = DocumentsFactory.documentsSecurityInitailValues();
			//$scope.DocumentAccessList = [];
			//$scope.subSelected = [];
			var securityItem;
			var blnUserFound = false;
			$scope.IsLoading = true;
			$scope.IsShowErrorMsg = true;

			$scope.DocumentsAccess = DocumentsFactory.documentsSecurityInitailValues();
			subrequestModel.libraryName = parentScope.vm.selectedLibrary;
			subrequestModel.UserId = $scope.SelectedUserId;
			subrequestModel.DocumentId = $scope.documents.Id;

			var apiUrl = DocumentsFactory.getAPIUrl('VIEWSECURITYDOCUMENTS', subrequestModel, parentScope.Id);
			parentScope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(apiUrl));
			
			var subSecurityDocuments = DocumentsService.getSecurityDocumentsList(apiUrl, parentScope.mc.loginModel.AuthKey);
			subSecurityDocuments.then(function (response) {
				if (response.status === 200 && response.data && response.data.data) {
					parentScope.mc.getlogDetails("Debug", "Security document list fetched.");

					var access = '';
					switch (response.data.data.access) {
						case 'no_access':
							access = 'No Access';
							break;

						case 'read':
							access = 'Read';
							break;

						case 'read_write':
							access = 'Read Write';
							break;

						case 'full_access':
							access = 'Full Access';
							break;

						default:
							access = '';
							break;
					}
					var userPromise = userFactory.getSingleUser('GETUSER', parentScope.vm.selectedLibrary, $scope.SelectedUserId, parentScope.mc.loginModel.AuthKey);
					userPromise.then(function (response) {
						if (response && response.data && response.data.length > 0) {
							parentScope.mc.getlogDetails("Debug", "User details fetched.");

							DocumentsAccess = DocumentsFactory.documentsSecurityInitailValues();
							DocumentsAccess.Name = response.data[0][CONST_USERS.FullName];
							DocumentsAccess.AllowLogin = response.data[0][CONST_USERS.IsAllowLogon];
							DocumentsAccess.AccessRight = access;
							$scope.DocumentAccessList.push(DocumentsAccess);
							blnUserFound = true;
							$scope.IsShowErrorMsg = false;
							$scope.IsLoading = false;
						} else {
							parentScope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
							$scope.IsLoading = false;
						}
					}, function (response) {
						parentScope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
						$scope.IsLoading = false;
					});
				}
				else {
					$scope.IsLoading = false;
				}
			}, function (response) {
				parentScope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
				$scope.IsLoading = false;
				$mdDialog.show($mdDialog.alert()
					.parent(angular.element(document.body))
					.clickOutsideToClose(true)
					.title('Warning!')
					.textContent('Failed to retrive workSpaces.')
					.ariaLabel('Warning!')
					.ok('OK')
				);
			});
		}
	}

	//function checkDocumentAccessForUser(response) {
	//    var groupTempList = $filter('filter')(response["data"]["data"], { type: 'group' }, true);
	//    if (typeof groupTempList != 'undefined' && groupTempList.length > 0) {

	//        var groupIdList = [];
	//        for (iCount = 0; iCount < groupTempList.length; iCount++) {
	//            groupIdList.push(groupTempList[iCount].id);
	//        }

	//        var userGroupListApiUrl = groupFactory.getAPIUrl('GETGROUPSOFUSERFROMGROUPS', groupIdList, $scope.SelectedUserId, parentScope.vm.selectedLibrary);
	//        parentScope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(userGroupListApiUrl));
	//        parentScope.mc.getlogDetails("Info", 'Method:GET;URL:' + JSON.stringify(userGroupListApiUrl));
	//        var promise = GroupService.GetGroupsOfUserFromGroups(userGroupListApiUrl, parentScope.mc.loginModel.AuthKey)
	//        promise.then(function (response) {
	//            if (response && response.status === 200 && response.data && response.data.data && response.data.data.length > 0) {
	//                parentScope.mc.getlogDetails("Info", "Groups of users fetched.");

	//                var selectedGroup = $filter('filter')(groupTempList, { id: response.data.data[0].group_id }, true);
	//                if (typeof selectedGroup != 'undefined' && selectedGroup.length > 0) {
	//                    parentScope.mc.getlogDetails("Debug", 'Method:GET;URL:' + 'GETUSER');
	//                    //parentScope.mc.setSecurityLogDetails("Info", 'Method:GET;URL:' + 'GETUSER');
	//                    var userPromise = userFactory.getSingleUser('GETUSER', parentScope.vm.selectedLibrary, $scope.SelectedUserId, parentScope.mc.loginModel.AuthKey);
	//                    userPromise.then(function (response) {
	//                        if (response && response.data && response.data.length > 0) {
	//                            parentScope.mc.getlogDetails("Info", "User details fetched.");
	//                            DocumentsAccess = DocumentsFactory.getDocumentSecurityUIModel(selectedGroup[0]);
	//                            DocumentsAccess.Id = response.data[0][CONST_USERS.UserId];
	//                            DocumentsAccess.Name = response.data[0][CONST_USERS.FullName];
	//                            DocumentsAccess.AllowLogin = response.data[0][CONST_USERS.IsAllowLogon];
	//                            blnUserFound = true;
	//                            $scope.DocumentAccessList.push(DocumentsAccess);
	//                            $scope.IsShowErrorMsg = false;
	//                        } else {
	//                            parentScope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
	//                        }
	//                    }, function (response) {
	//                        parentScope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
	//                    });
	//                }
	//            } else {
	//                parentScope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
	//            }
	//        }, function (response) {
	//            parentScope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
	//        });
	//    }
	//}

	function DocumentsHistoryController($scope, $mdDialog, parentScope) {

		$scope.TableScrollOptions = {
			cursorcolor: '#999',
			cursorwidth: "10px",
			cursorborder: "none",
			background: "#ccc",
			smoothscroll: true,
			autohidemode: false
		}

		$scope.DocHistoryListScrolled = function (info) {
			if ($scope.ViewHistoryDocumentsPagination.totalCount > $scope.HistoryDocumentsList.length) {
				subrequestModel.pagenumber++;
				getHistoryDocumentsList();
			}
		};

		$scope.hide = function () {
			$mdDialog.hide();
		};
		$scope.cancel = function () {
			$mdDialog.cancel();
		};
		$scope.answer = function () {
			$scope.AddSelectedUser();
			$mdDialog.hide();
		};

		$scope.HistoryDocumentsList = [];
		$scope.subSelected = [];
		var subrequestModel = homeFactory.requestModelInstance();
		$scope.PageEvents = {
			UserAction: 'History'
		};
		$scope.PageEvents.UserAction = 'History';
		$scope.ViewHistoryDocumentsPagination = {
			limit: subrequestModel.pageLength,
			page: subrequestModel.pagenumber,
			totalCount: 0
		};

		$scope.onHistoryDocuments = function (page, limit) {
			subrequestModel.pageLength = limit;
			subrequestModel.pagenumber = page;
			getHistoryDocumentsList();
		};

		getHistoryDocumentsList();
		$scope.DocumentHistoryButtonChange = function ($event) {
			if ($event.keyCode === 9) {
				$event.preventDefault();
				$("#btnCancel").focus();

			}
			return false;
		}

		function getHistoryDocumentsList() {
			//$scope.HistoryDocumentsList = [];
			//$scope.subSelected = [];          
			subrequestModel.libraryName = parentScope.vm.selectedLibrary;
			var apiUrl = DocumentsFactory.getAPIUrl('VIEWHISTORYDOCUMENTS', subrequestModel, parentScope.Id);
			parentScope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(apiUrl));
			//parentScope.mc.setSecurityLogDetails("Info", 'Method:GET;URL:' + JSON.stringify(apiUrl));
			var subDocuments = DocumentsService.getHistoryDocumentsList(apiUrl, parentScope.mc.loginModel.AuthKey);
			subDocuments.then(function (response) {
				if (response.data && response.status === 200) {
					parentScope.mc.getlogDetails("Info", "Document history details fetched.");
					$scope.ViewHistoryDocumentsPagination.totalCount = response.data[CONST_HISTORY_DOCUMENTS_FILEDS.TotalCount];
					angular.forEach(response.data[CONST_HISTORY_DOCUMENTS_FILEDS.DocumentsList], function (document) {
					    if (document.duration != '' && document.duration != undefined) {
					        document.duration = secondstotime(document.duration);
					    }

						$scope.HistoryDocumentsList.push(DocumentsFactory.getHistoryUIModel(document));
					});
				} else {
					parentScope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
				}
			}, function (response) {
				parentScope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
			});
		}
		secondstotime = function (secs) {

		    var t = new Date(1970, 0, 1);
		    t.setSeconds(secs);
		    var s = t.toTimeString().substr(0, 8);
		    if (secs > 86399)
		        s = Math.floor((t - Date.parse("1/1/70")) / 3600000) + s.substr(2);
		    return s;
		}


	}

	function CheckedOutInformationController($scope, $mdDialog, parentScope, CONST_DOCUMENT_ATTRS) {

		$scope.cancel = function () {
			$mdDialog.cancel();
		};

		$scope.DocumentAttributes = {
			Database: '',
			DocNum: '',
			Version: '',
			Description: '',
			DateTime: '',
			CheckoutPath: ''
		}
		var apiUrl = DocumentsFactory.getCheckedOutInformationAPIUrl(parentScope.selected[0].Id);
		parentScope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(apiUrl));
		var promise = DocumentsService.getCheckedOutInformation(apiUrl, parentScope.mc.loginModel);
		promise.then(function (response) {
			if (response.data.data) {
				parentScope.mc.getlogDetails("Info", "Checked out information fetched.");
				$scope.DocumentAttributes = DocumentsFactory.getCheckoutInfo(response.data.data);
			} else {
				parentScope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
			}
		}, function (response) {
			parentScope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
		});


	}

	$scope.$on('$destroy', function () {
		$scope.PageEvents.Add = 'undefined';
		$scope.PageEvents.Edit = 'undefined';
		$scope.PageEvents.Save = 'undefined';
		$scope.PageEvents.Delete = 'undefined';
		$scope.PageEvents.CancelDialog = 'undefined';
		$scope.PageEvents.ShowSubclassList = 'undefined';
		$scope.PageEvents.AddRole = 'undefined';
		$scope.PageEvents.ResetPasswordclicked = 'undefined';
		$scope.PageEvents.ViewVersion = 'undefined';
		$scope.PageEvents.ViewHistory = 'undefined';
		$scope.PageEvents.UnlockAccount = 'undefined';
		$scope.PageEvents.Back = undefined;
	});

	var isSearch = false;

	$scope.$on('Search_Click', function (event, args) {
		$scope.selected = [];
		$scope.DocumentsList = [];
		isSearch = true;
		DocumentsRequestModel.pagenumber = 1;
		$scope.query.page = 1;
		$scope.query.totalCount = 0;
		getDocumentsList();
	});

	$scope.SearchIconClicked = function () {
		$scope.isDocumentSearchArea = !$scope.isDocumentSearchArea;
	}

	$scope.isDocumentSearchArea = false;

	$scope.Search_Click = function () {
		$scope.isDocumentSearchArea = false;
		$scope.selected = [];
		$scope.DocumentsList = [];
		$scope.SearchCount = 0;
		isSearch = true;
		DocumentsInitalize();
	};
	RegisterInitializeTabContents();
	var destroybroadCast;
	$scope.$on('RegisterInitializeTabContents', function () {
		if (angular.isFunction(destroybroadCast))
			destroybroadCast();

		RegisterInitializeTabContents();
	});
	function RegisterInitializeTabContents() {
		var destroybroadCast = $scope.$on('InitializeTabContents', function () {
			$scope.IsShowDocumentsList = false;
			// DocumentsInitalize();
			$scope.DocumentsList = [];
			$scope.DocumentAccessList = [];
			$scope.selected = [];
			$scope.DocumentSearch.DocumentNumber = '';
			$scope.DocumentSearch.Version = '';
			$scope.DocumentSearch.UserID = '';
			$scope.DocumentSearch.UserType = '';
			$scope.DocumentSearch.Custom1 = '';
			$scope.DocumentSearch.Custom2 = '';
			$scope.SearchCount = 0;

			if ($scope.vm.selectedApp.NoAppsPermission.trim().length > 0)
				return;
			if (!$scope.vm.selectedLibrary || $scope.vm.selectedLibrary.trim().length == 0)
				return;
			destroybroadCast();
		});
	}

	function DocumentsInitalize() {
		$scope.lastSelectedLibrary = '';
		$scope.loading = true;
		$scope.haveMoreRows = true;
		DocumentsRequestModel.pagenumber = 1;
		$scope.query.page = 1;
		$scope.query.totalCount = 0;
		getDocumentsList();
	}

	$scope.CheckinDocument = function () {
		var apiUrl = DocumentsFactory.getCheckedOutInformationAPIUrl($scope.selected[0].Id);
		$scope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(apiUrl));
		//$scope.mc.setSecurityLogDetails("Info", 'Method:GET;URL:' + JSON.stringify(apiUrl));
		var promise = DocumentsService.getCheckedOutInformation(apiUrl, $scope.mc.loginModel);
		promise.then(function (response) {
			if (response.data.data) {
				$scope.mc.getlogDetails("Info", "Checked out information fetched.");
				$scope.DocumentAttributes = DocumentsFactory.getCheckoutInfo(response.data.data);

				var documentUrl = DocumentsFactory.getDocumentUrl('GETDOCUMENT', $scope.DocumentAttributes.CheckoutPath);
				$scope.mc.getlogDetails("Debug", "Requested Api:" + JSON.stringify(documentUrl));
				var data = FileService.getFile(documentUrl, $scope.mc.loginModel.AuthKey);
				data.success(function (data) {
					if (data.byteLength != 0) {
						$scope.mc.getlogDetails("Info", "File fetched, parameters are " + $scope.DocumentAttributes.CheckoutPath);
						if (typeof $scope.selected !== 'undefined' && $scope.selected.length > 0) {
							var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
							$mdDialog
									.show(
											{
												controller: CheckinDocumentDialogController,
												preserveScope: false,
												templateUrl: 'Views/CheckInDocument.html',
												parent: angular.element(document.body),
												clickOutsideToClose: true,
												fullscreen: useFullScreen,
												onComplete: function () {
													$("#userForm input[id=rdbRepalceOrginal]").focus();
												},
												locals: {
													parentScope: $scope
												}
											})
									.then(
											function (answer) {
												$scope.status = '';
											},
											function () {
												$scope.status = '';
											});
							$scope.$watch(function () { return $mdMedia('xs') || $mdMedia('sm'); },
											function (wantsFullScreen) { $scope.customFullscreen = (wantsFullScreen === true); });
						} else {
							$mdDialog.show($mdDialog.alert()
								.parent(angular.element(document.body))
								.clickOutsideToClose(true)
								.title('Warning!')
								.textContent('Select a document to checkin.')
								.ariaLabel('Warning!')
								.ok('OK')
							);
						}
					} else {
						$scope.mc.getlogDetails("Error", JSON.stringify(data) + ",parameters are " + $scope.DocumentAttributes.CheckoutPath);
						$scope.ContextMenuFunctions.UnlockDocument();
					}
				}, function (error) {
					$scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(error));
				});
			} else {
				$scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
			}
		}, function (response) {
			$scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
		});
	};
	function DialogController($scope, $mdDialog) {
		$scope.hide = function () {
			$mdDialog.hide();
		};
		$scope.cancel = function () {
			$mdDialog.cancel();
		};
		$scope.answer = function () {
			$mdDialog.hide();
		};
	}

	function CheckinDocumentDialogController($scope, $mdDialog, parentScope, docTypeFactory, DocTypeService, userFactory, UserService, metaDataFactory, MetaDataService, FileService, classFactory, ClassService) {
		$scope.hide = function () {
			$mdDialog.hide();
		};
		$scope.cancel = function () {
			$mdDialog.cancel();
		};
		$scope.answer = function () {
			$mdDialog.hide();
		};



		$scope.docInfo = angular.copy(parentScope.selected[0]);
		$scope.docInfo.replaceOrginal = true;
		$scope.docInfo.newDocument = false;
		$scope.docInfo.newVersion = false;




		/*
		  
		 * 
		 * 
		 * Area for Auto Complete
		 * 
		 * 
	  
		 * */

		/* ********     Region Type ***** */

		$scope.selectedTypeItem = {};
		$scope.searchTypeText = null;
		$scope.queryTypeSearch = queryTypeSearch;
		$scope.DocTypeListofApp = [];
		$scope.selectedTypeItem.TAlias = $scope.docInfo.Type;

		function queryTypeSearch(query) {
			var deffered = $q.defer();
			var FilterSearchTimeout;
			var typeListRequestModel = homeFactory.requestModelInstance();


			var filterValueList = [];
			filterValueList[0] = query;

			var filterItem = { 'FilterKey': 'Alias', 'FilterValues': filterValueList };
			typeListRequestModel.filters.push(filterItem);

			typeListRequestModel.pagenumber = 1;

			if (FilterSearchTimeout) $timeout.cancel(FilterSearchTimeout);
			var obj = [];
			var searchAPIUrl = docTypeFactory.searchAPIUrl(typeListRequestModel);
			parentScope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(searchAPIUrl));
			var typeDbRequest = DocTypeService.getDocTypes(searchAPIUrl, parentScope.mc.loginModel.AuthKey);

			typeDbRequest.then(function (response) {
				if (response.status === 200) {
					parentScope.mc.getlogDetails("Info", "Document types successfully fetched.");
					angular.forEach(response.data.data, function (typeItem) {
						obj.push(docTypeFactory.getUIModel(typeItem));
					});
					deffered.resolve(obj);
				} else {
					parentScope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
				}
			}, function (response) {
				parentScope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
			});

			return deffered.promise;
		}

		$scope.searchTextChange = searchTextChange;
		$scope.selectedItemChange = selectedItemChange;

		function searchTextChange(text) {
			return queryTypeSearch(text);
		}

		function selectedItemChange(item) {

			if (item)
				$scope.docInfo.Type = item.TAlias;
		}
		/* ********     Region Type ***** */


		/* ********     Region User ***** */

		$scope.selectedAuthorItem = {};
		$scope.searchAuthorText = null;
		$scope.queryAuthorSearch = queryUserSearch;
		$scope.selectedAuthorItem.UserId = $scope.docInfo.Author;

		function queryUserSearch(query) {
			var deffered = $q.defer();

			var userListRequestModel = homeFactory.requestModelInstance();


			/*var filterValueList = [];
			filterValueList[0] = query;

			var filterItem = { 'FilterKey': 'UserId', 'FilterValues': filterValueList };
			userListRequestModel.filters.push(filterItem);*/
			userListRequestModel.searchText = query;
			userListRequestModel.pagenumber = 1;


			var obj = [];
			var searchAPIUrl = userFactory.getAPIUrl('SEARCHUSERS', userListRequestModel);
			parentScope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(searchAPIUrl));
			//parentScope.mc.setSecurityLogDetails("Info", 'Method:GET;URL:' + JSON.stringify(searchAPIUrl));
			var userRequest = UserService.getUsers(searchAPIUrl, parentScope.mc.loginModel.AuthKey);

			userRequest.then(function (response) {
				if (response.status === 200) {
					parentScope.mc.getlogDetails("Info", "Users details fetched.");
					angular.forEach(response.data.data, function (userItem) {
						obj.push(userFactory.getUserUI(userItem));
					});
					deffered.resolve(obj);
				} else {
					parentScope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
				}
			}, function (response) {
				parentScope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
			});

			return deffered.promise;
		}

		$scope.searchAuthorTextChange = searchAuthorTextChange;
		$scope.selectedAuthorItemChange = selectedAuthorItemChange;

		function searchAuthorTextChange(text) {
			return queryUserSearch(text);
		}

		function selectedAuthorItemChange(item) {
			if (item)
				$scope.docInfo.Author = item.UserId;
		}
		/* ********     Region User ***** */



		/* ********     Region User ***** */

		// Custom1
		$scope.selectedCustomItem = {};
		$scope.searchCustomText = null;
		$scope.queryCustomSearch = queryCustomSearch;
		if ($scope.docInfo.Custom1)
			$scope.selectedCustomItem.Alias = $scope.docInfo.Custom1;
		else
			$scope.selectedCustomItem = null;


		$scope.searchCustomTextChange = searchCustomTextChange;
		$scope.selectedCustomItemChange = selectedCustomItemChange;

		function selectedCustomItemChange(item) {
			if (item)
				$scope.docInfo.Custom1 = item.Alias;
		}


		//Custom2
		$scope.selectedCustom2Item = {};
		$scope.searchCustom2Text = null;
		$scope.queryCustom2Search = queryCustomSearch;
		if ($scope.docInfo.Custom2)
			$scope.selectedCustomItem.Alias = $scope.docInfo.Custom2;
		else
			$scope.selectedCustom2Item = null;



		$scope.selectedCustom2ItemChange = selectedCustom2ItemChange;

		function selectedCustom2ItemChange(item) {
			if (item)
				$scope.docInfo.Custom2 = item.Alias;
		}


		$scope.searchCustomTextChange = searchCustomTextChange;
		function searchCustomTextChange(text, metatype) {
			return queryCustomSearch(text, metatype);
		}

		function queryCustomSearch(query, metaType) {
			var deffered = $q.defer();

			var customListRequestModel = homeFactory.requestModelInstance();


			var filterValueList = [];
			filterValueList[0] = query;

			var filterItem = { 'FilterKey': 'Alias', 'FilterValues': filterValueList };
			customListRequestModel.filters.push(filterItem);
			customListRequestModel.searchText = query;
			customListRequestModel.pagenumber = 1;
			var searchAPIUrl = '';
			//customListRequestModel.libraryName = $scope.vm.selectedLibrary;
			if (metaType == 'CUSTOM2' || metaType == 'CUSTOM30') {

				customListRequestModel.MetaType = metaType == 'CUSTOM2' ? "CUSTOM1" : "CUSTOM29";
				customListRequestModel.parentAlias = metaType == 'CUSTOM2' ? $scope.docInfo.Custom1 : $scope.docInfo.Custom29;
				customListRequestModel.subType = metaType;
				searchAPIUrl = metaDataFactory.getAPIUrl('SEARCHCHILDMETADATA', customListRequestModel);
			} else {
				customListRequestModel.MetaType = metaType;
				searchAPIUrl = metaDataFactory.getAPIUrl('SEARCHMETADATA', customListRequestModel);
			}




			var obj = [];
			parentScope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(searchAPIUrl));
			//parentScope.mc.setSecurityLogDetails("Info", 'Method:GET;URL:' + JSON.stringify(searchAPIUrl));
			var userRequest = MetaDataService.getMetaDataList(searchAPIUrl, parentScope.mc.loginModel.AuthKey);

			userRequest.then(function (response) {
				if (response.status === 200) {
					parentScope.mc.getlogDetails("Info", "Metadata search results received.");
					angular.forEach(response.data.data, function (userItem) {
						obj.push(metaDataFactory.getMetaDataUI(userItem));
					});
					deffered.resolve(obj);
				} else {
					parentScope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
				}
			}, function (response) {
				parentScope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
			});

			return deffered.promise;
		}

		/* ********     Region User ***** */













		/* ********     Region User ***** */

		// Class
		$scope.selectedClassItem = {};
		$scope.searchClassText = null;
		$scope.queryClassSearch = queryClassSearch;
		if ($scope.docInfo.Class1)
			$scope.selectedClassItem.Alias = $scope.docInfo.Class1;
		else
			$scope.selectedClassItem = null;


		$scope.searchClassTextChange = searchClassTextChange;
		$scope.selectedClassItemChange = selectedClassItemChange;

		function selectedClassItemChange(item) {
			if (item)
				$scope.docInfo.Class = item.Alias;
		}


		//SubClass2
		$scope.selectedSubclassItem = {};
		$scope.searchSubclassText = null;
		$scope.querySubclassSearch = queryClassSearch;
		if ($scope.docInfo.Subclass)
			$scope.selectedSubclassItem.Alias = $scope.docInfo.Subclass;
		else
			$scope.selectedSubclassItem = null;



		$scope.selectedSubclassItemChange = selectedSubclassItemChange;

		function selectedSubclassItemChange(item) {
			if (item)
				$scope.docInfo.Subclass = item.Alias;
		}


		$scope.searchClassTextChange = searchClassTextChange;
		function searchClassTextChange(text, metatype) {
			return queryClassSearch(text, metatype);
		}

		function queryClassSearch(query, metaType) {
			var deffered = $q.defer();

			var customListRequestModel = homeFactory.requestModelInstance();


			var filterValueList = [];
			filterValueList[0] = query;

			var filterItem = { 'FilterKey': 'Alias', 'FilterValues': filterValueList };
			customListRequestModel.filters.push(filterItem);
			customListRequestModel.searchText = query;
			customListRequestModel.pagenumber = 1;
			var searchAPIUrl = '';
			customListRequestModel.libraryName = parentScope.vm.selectedLibrary;
			if (metaType == 'Subclass') {
				customListRequestModel.Alias = $scope.selectedClassItem.Alias;
				//customListRequestModel.parentAlias =   metaType == 'CUSTOM2' ? $scope.docInfo.Custom1 : $scope.docInfo.Custom29;
				//customListRequestModel.subType =metaType;  
				searchAPIUrl = classFactory.getAPIUrl('SEARCHSUBCLASS', customListRequestModel);
			} else {
				customListRequestModel.MetaType = metaType;
				searchAPIUrl = classFactory.getAPIUrl('SEARCHCLASS', customListRequestModel);
			}




			var obj = [];
			parentScope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(searchAPIUrl));
			//	parentScope.mc.setSecurityLogDetails("Info", 'Method:GET;URL:' + JSON.stringify(searchAPIUrl));
			var userRequest = ClassService.getClasses(searchAPIUrl, parentScope.mc.loginModel.AuthKey);

			userRequest.then(function (response) {
				if (response.status === 200) {
					parentScope.mc.getlogDetails("Info", "Search class results received.");
					angular.forEach(response.data.data, function (userItem) {
						obj.push(classFactory.getClassUI(userItem));
					});
					deffered.resolve(obj);
				} else {
					parentScope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
				}
			}, function (response) {
				parentScope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
			});

			return deffered.promise;
		}

		/* ********     Region User ***** */


		/*
		 * 
		 * 
		 * end region auto Complete
		 * 
		 * 
		 */
		$scope.SubmitCheckinDocument = function () {
			// $scope.validation.showMessage = true;
			$scope.posting = true;
			var apiUrl = DocumentsFactory.getDocumentUrl('GETDOCUMENT', parentScope.DocumentAttributes.CheckoutPath);
			parentScope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(apiUrl));
			var data = FileService.getFile(apiUrl, parentScope.mc.loginModel.AuthKey);
			data.success(function (data) {
				parentScope.mc.getlogDetails("Info", "Document details fetched.");
				var blob = new Blob([data], {
					type: 'application/octet-stream'
				});
				$scope.docInfo.filevalue = blob;
				var checkinAPIUrl = DocumentsFactory.getCheckinAPIUrl('CHECKINDOCUMENT');
				var formdata = DocumentsFactory.getFormData($scope.docInfo, parentScope.mc.loginModel);
				parentScope.mc.getlogDetails("Debug", 'Method:POST;URL:' + JSON.stringify(checkinAPIUrl) + ';Body:' + JSON.stringify(formdata));
				//parentScope.mc.setSecurityLogDetails("Info", 'Method:POST;URL:' + JSON.stringify(checkinAPIUrl) + ';Body:' + JSON.stringify(formdata));
				var DocumentsRequest = DocumentsService.checkinDocument(checkinAPIUrl, parentScope.mc.loginModel.AuthKey, formdata);
				DocumentsRequest.then(function (response) {
					if (response.data) {
						// parentScope.mc.setSecurityLogDetails("Info", "Document checked in successfully.");

						parentScope.mc.setSecurityLogDetails("Info", 'Success:', document.Id, 'Document Checked In ');
						getDocumentsList();
					} else {
						parentScope.mc.setSecurityLogDetails("Info", "Failure:", document.Id, 'Document Checked In ');
					}
					$scope.posting = false;
					$mdDialog.cancel();
				}, function (response) {
					parentScope.mc.setSecurityLogDetails("Info", "Failure:", document.Id, 'Document Checked In ');
				});
			}).error(function (data, status) {
				parentScope.mc.setSecurityLogDetails("Info", "Failure:", document.Id, 'Document Checked In ');
			});
		}
	}


	$scope.selectedAuthorItem = {};
	$scope.searchAuthorText = null;
	$scope.queryAuthorSearch = queryUserSearch;
	$scope.docInfo = {
		Author: ''
	};
	$scope.selectedAuthorItem.UserId = $scope.docInfo.Author;

	if ($scope.docInfo.Author)
		$scope.selectedAuthorItem.Alias = $scope.docInfo.Author;
	else {
		$scope.selectedAuthorItem = null;
		$scope.docInfo.Author = '';
	}

	function queryUserSearch(query) {
		var deffered = $q.defer();

		var userListRequestModel = homeFactory.requestModelInstance();
		userListRequestModel.searchText = query;
		userListRequestModel.pagenumber = 1;
		var obj = [];
		var searchAPIUrl = userFactory.getAPIUrl('SEARCHUSERS', userListRequestModel);
		$scope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(searchAPIUrl));
		var userRequest = UserService.getUsers(searchAPIUrl, $scope.mc.loginModel.AuthKey);

		userRequest.then(function (response) {
			if (response.status === 200) {
				$scope.mc.getlogDetails("Debug", "Users details fetched.");
				angular.forEach(response.data.data, function (userItem) {
					obj.push(userFactory.getUserUI(userItem));
				});
				deffered.resolve(obj);
			} else {
				$scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
			}
		}, function (response) {
			$scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
		});

		return deffered.promise;
	}

	$scope.searchAuthorTextChange = searchAuthorTextChange;
	$scope.selectedAuthorItemChange = selectedAuthorItemChange;

	function searchAuthorTextChange(text) {
		if (text.length == 0) {
			$scope.docInfo.Author = '';
			//$scope.selectedAuthorItem.UserId = '';
		}
		return queryUserSearch(text);
	}

	function selectedAuthorItemChange(item) {
		if (item)
			$scope.docInfo.Author = item.UserId;
		else
			$scope.docInfo.Author = '';
	}



	$scope.documentNumberChange = function () {
		if ($scope.DocumentSearch.DocumentNumber.length == 0)
			$scope.DocumentSearch.Version = '';
	}


}