app.controller("masterController", masterController);
masterController.$inject = ['loginService', '$state', '$cookies', 'homeFactory', '$filter', 'loginFactory', 'masterFactory', '$interval', '$timeout', '$mdDialog', '$http', 'masterService', '$q'];

function masterController(loginService, $state, $cookies, homeFactory, $filter, loginFactory, masterFactory, $interval, $timeout, $mdDialog, $http, masterService, $q) {
    var mc = this;
    mc.loginModel = {
        UserName: '',
        Password: '',
        ApiUrl: '',
        AuthKey: '',
		ApplicationName: 'Control Center',
        networklogin: false,
        UserSessionTimeOut: null
    };
    mc.PasswordDisplayText = '';
    mc.onError = false;
    mc.message = '';
    mc.IsLoading = false;
    mc.ApplicationTitle = 'iManage Control Center';
	var ipAddress='';
	
    function Initialize() {
        var settings = masterFactory.masterInitailValues();
        settings.then(function (response) {
            baseUrl = response.apiurl;
            baseIMCCApiUrl = response.imccapiurl;
        });
    }

    Initialize(); 
    if (mc.loginModel.AuthKey == null || mc.loginModel.AuthKey.trim().length == 0) {
        mc.loginModel.AuthKey = $cookies.get('UserAuthKey');
        if (mc.loginModel.AuthKey && mc.loginModel.AuthKey.trim().length > 0) {
            mc.loginModel.UserName = $cookies.get('LoginUserId');
        }
    }
 
    mc.getlogDetails = function (level, message) {
        var apiUrl = masterFactory.getAPIUrl('SAVELOG');
        masterService.getlogDetails(apiUrl, level, message);
    };

    mc.setSecurityLogDetails = function (level, state, userAffected, activity, activityParameters) {
        //var apiUrl = masterFactory.getAPIUrl('SECURITYLOG');
        //var message = mc.loginModel.UserName + ' - ' + state + ' - ' + userAffected + ' - ' + activity;
        //if (activityParameters && activityParameters.trim().length > 0) {
        //    message += ' - ' + activityParameters.trim();
        //}
        //masterService.getlogDetails(apiUrl, level, message);
    };

    mc.passwordType = 'password';   
    mc.hideShowPassword = function () {

        if (mc.passwordType == 'password'){           
            mc.passwordType = 'text';             
            }
        else{
            mc.passwordType = 'password';          
        }
    };

    mc.validateUser = function () {
        var userAuthKeyTemp = '';
        mc.message = '';
        mc.onError = false;

        if (mc.loginModel.UserName.trim().length == 0 || mc.loginModel.Password.trim().length == 0)
            return;

        mc.IsLoading = true;
        closePreviousLoggedSession();

        mc.getlogDetails("Debug", "for Validate "+mc.loginModel.UserName+" in LogIn Page");
        //mc.setSecurityLogDetails("Info", 'for Validate ' + mc.loginModel.UserName + ' in LogIn Page');

        var promise = loginService.validateUser(mc.loginModel);
        promise.then(function (response) {

            if (response && response.status == 200 && response.data["X-Auth-Token"]) {
                userAuthKeyTemp = response.data["X-Auth-Token"];
            }
            else {
                mc.IsLoading = false;
                mc.onError = true;
                if (response && response.status == 401 && response.data.error.message) {
                    mc.message = response.data.error.message;
                }
                else {
                    mc.message = 'User ID or Password is incorrect.';
                    mc.getlogDetails("Debug", "User ID or Password is incorrect.");
                }
                $('input[name="UserId"]').focus().select();
                return;
            }
            mc.getlogDetails("Debug", 'Method:GET;Login Parameters are:' + JSON.stringify(mc.loginModel));
           // mc.setSecurityLogDetails("Info", 'Method:GET;Login Parameters are:' + JSON.stringify(mc.loginModel));

            mc.loginModel.AuthKey = userAuthKeyTemp;
            var data = loginFactory.getpremittedUser(mc.loginModel);
            data.then(function (response) {
                if (response && response.length > 0) {
                    mc.getlogDetails("Info", 'Response:Success');
                    mc.loginModel.AuthKey = userAuthKeyTemp;
                    userAuthKeyTemp = '';
                    $cookies.remove('sessiontimeout');

                    sessionTime = 1000 * 60 * 60 * 4;
                    $cookies.put('LoginUserId', mc.loginModel.UserName, { 'expires': updateCookieExpiary() });
                    $cookies.put('UserAuthKey', mc.loginModel.AuthKey, { 'expires': updateCookieExpiary() });
                                        
                    $state.go('home');
                    mc.IsLoading = false;
                } else {
                    mc.loginModel.AuthKey = '';
                     mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                    mc.IsLoading = false;
                    mc.onError = true;
                    mc.message = 'You don\'t have sufficient privilege to access IManage Control Center. Please Contact Administrator';
                    mc.getlogDetails("Debug", "You don\'t have sufficient privilege to access IManage Control Center. Please Contact Administrator");
                }
            });
        }, function (response) {
            mc.IsLoading = false;
            mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
            if (response.data) {
                mc.onError = true;
                mc.message = response.data.error.message;
            }
        });
    };
       
    function closePreviousLoggedSession() {
        var userAuthKeyTemp = $cookies.get('UserAuthKey');

        if (userAuthKeyTemp && userAuthKeyTemp.trim().length > 0) {
            mc.loginModel.AuthKey = '';
            userAuthKeyTemp = '';

            if (angular.isDefined(mc.loginModel.UserSessionTimeOut)) {
                $interval.cancel(mc.loginModel.UserSessionTimeOut);
                mc.loginModel.UserSessionTimeOut = null;
            }
            if (UserSessionTimer) {
                $timeout.cancel(UserSessionTimer);
                UserSessionTimer = null;
            }

            $cookies.remove('UserAuthKey');
            $cookies.remove('LoginUserId');
            $cookies.remove('toState');
        }
    }

    mc.onLoginKeypress = function ($event) {
        if ($event.keyCode == 13) {
            if ($($($event.target)[0]).attr('id') == "password") {
                mc.validateUser();
            } else if ($($event.target).is('input') && $($event.target).val() && $($event.target).val().length > 0) {
                $('input[id="password"]').focus();
            }
        }
    };
}