﻿app.controller("UserController", UserController);

UserController.$inject = ['$scope', '$rootScope', '$filter', '$timeout', '$log', '$mdDialog', '$mdMedia', 'UserService', 'userFactory', 'homeFactory', 'GroupService',
		'HomeService', 'DatabaseService', 'securityTemplateFactory', 'SecurityTemplateService', '$http', 'CONST_USERS', 'groupFactory', 'databasesFactory', '$q', 'CONST_ST'];

function UserController($scope, $rootScope, $filter, $timeout, $log, $mdDialog, $mdMedia, UserService, userFactory, homeFactory, GroupService, HomeService,
		DatabaseService, securityTemplateFactory, SecurityTemplateService, $http, CONST_USERS, groupFactory, databasesFactory, $q, CONST_ST) {

	$scope.selected = [];
	$scope.UserList = [];
	$scope.DBLibrariesByUser = [];
	$scope.GroupCheckedFInal = [];
	$scope.GroupDetails = [];
	$scope.GroupInUserList = [];
	$scope.GroupRemovedFInal = [];
	$scope.userGroupsList = [];
	$scope.AlreadySelectedUserGroupList = [];
	$scope.IsShowErrorMessage = false;
	$scope.ErrorMessage = '';
	$scope.user = userFactory.userInitailValues();
	$scope.validation = userFactory.validations();
	$scope.showSelectedUserDetails = false;
	var totalGroupCount = 0;
	
	var FilterSearchTimeout;
	var requestModel = homeFactory.requestModelInstance();
	var gsrequestModel = homeFactory.requestModelInstance();
	var grequestModel = homeFactory.requestModelInstance();
		
	var view_scroll_fix_top = 482;
	$(window).on('scroll', function () {
		if ($scope.showSelectedUserDetails) {
			//if ($(window).scrollTop() < 10) {
				view_scroll_fix_top = $('.view-details-tab-container md-tabs-content-wrapper').offset().top;
			//}
			if ($(window).scrollTop() >= view_scroll_fix_top - 64) {
				$('.view-details-tab-container md-tabs-content-wrapper').addClass('fix-title');
			} else {
				$('.view-details-tab-container md-tabs-content-wrapper').removeClass('fix-title');
			}
		}
	});
	$scope.$on('Window_Scrolled', function () {
		if ($scope.showSelectedUserDetails) {
			if ((userGroupListReqModel.pagenumber + userGroupListReqModel.pageLength) < totalUserGroupCount) {
				userGroupListReqModel.pagenumber += userGroupListReqModel.pageLength;
				fillUserGroupGrid();
			}
		} else {
			if ($scope.query.totalCount > $scope.UserList.length) {
				requestModel.pagenumber++;
				getUsers();
			}
		}
	});
	$timeout(function() {
		$(window).scrollTop(0);
	});
	$scope.AddUserModel = {
		PasswordValue: '',
		ConfirmPasswordValue: ''
	};

	$scope.AddRemoveGroups = {
		IsSearchTextFound: false,
		SearchText: '',
		GroupSearchTimeout: null
	};

	$scope.GroupTablePagination = {
		limit: grequestModel.pageLength,
		page: grequestModel.pagenumber,
		totalCount: 0
	};

	$scope.SelAll = {
		checked: false
	};

	$scope.dialogPopup = {
		Header: '',
		Message: '',
		CallbackFunction: null,
		Show: function () {
			$('#popup-alert-dialog-bg').slideToggle();
		},
		OK: function () {
			$('#popup-alert-dialog-bg').slideToggle();
			$scope.dialogPopup.Header = '';
			$scope.dialogPopup.Message = '';

			if ($scope.dialogPopup.CallbackFunction) {
				$scope.dialogPopup.CallbackFunction();
				$scope.dialogPopup.CallbackFunction = null;
			}
		}
	};

	var SelectedUserIdListForFilter = [];
	var LastAddedSelectedItemUserId = [];
	var lastAppendItemCount = 0;

	function getUsers() {
		if ($scope.vm.selectedApp.NoAppsPermission.trim().length > 0)
			return;
		if (!$scope.vm.selectedLibrary || $scope.vm.selectedLibrary.trim().length == 0)
			return;

		requestModel.libraryName = $scope.vm.selectedLibrary;
		requestModel.searchText = $scope.appsVar.SearchText;
		$scope.lastSelectedLibrary = $scope.vm.selectedLibrary;

		if (isSearch) {
			//$scope.showSearchProgress = true;
			showProgressDialog();
		}

		var apiUrl = userFactory.getAPIUrl('SEARCHUSERS', requestModel);
		$scope.mc.getlogDetails("Debug", 'Requested Api Url:' + JSON.stringify(apiUrl));
		var promise = UserService.getUsers(apiUrl, $scope.mc.loginModel.AuthKey)
		promise.then(function (response) {
			if (response["status"] == 200) {
				$scope.query.totalCount = response["data"]["total_count"];

				var tempListFilter = [];
				var userUIModel;
				var filterTempModel;

				if (lastAppendItemCount > 0) {
					$scope.UserList.splice($scope.UserList.length - lastAppendItemCount, lastAppendItemCount);
					$scope.selected.splice($scope.selected.length - lastAppendItemCount, lastAppendItemCount);
				}
				angular.forEach(response["data"]["data"], function (user) {
					userUIModel = userFactory.getUserUI(user);
					if (SelectedUserIdListForFilter.length === 0) {
						$scope.UserList.push(userUIModel);
					}
					else {
						tempListFilter = $filter('filter')(SelectedUserIdListForFilter, {
							UserId: userUIModel.UserId
						}, true);
						if (tempListFilter.length === 0) {
							$scope.UserList.push(userUIModel);
						}
						else {
							LastAddedSelectedItemUserId = $.grep(LastAddedSelectedItemUserId,
							   function (item, index) {
								   return item.UserId != userUIModel.UserId;
							   });

							tempListFilter[0].FullName = userUIModel.FullName;
							tempListFilter[0].Location = userUIModel.Location;
							tempListFilter[0].Email = userUIModel.Email;
							tempListFilter[0].IsAllowLogon = userUIModel.IsAllowLogon;
							tempListFilter[0].FullNamePreferredDatabase = userUIModel.PreferredDatabase;
							tempListFilter[0].IsExternalUser = userUIModel.IsExternalUser;
							tempListFilter[0].PasswordNeverExpires = userUIModel.PasswordNeverExpires;

							filterTempModel = angular.copy(tempListFilter[0]);
							$scope.UserList.push(filterTempModel);
							$scope.selected.push(filterTempModel);
							filterTempModel = null;
						}
						tempListFilter = [];
					}
					userUIModel = null;
				});
				lastAppendItemCount = 0;
				if ($scope.appsVar.SearchText.length === 0 && !isValidFilterFind()) {
					angular.forEach(LastAddedSelectedItemUserId, function (user) {
						filterTempModel = angular.copy(user);
						$scope.UserList.push(filterTempModel);
						$scope.selected.push(filterTempModel);
						filterTempModel = null;
						lastAppendItemCount += 1;
					});
				}

				if ($scope.selected.length > 0) {
					setContextMenuObject();
				}
			} else {
				$scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
			}
			if (isSearch) $mdDialog.hide();
			
			$timeout(function () {
				$('td').filter(function () {
					if (!$(this).hasClass("md-checkbox-cell")) {
						if ($(this).text().trim().length == 0) {
							$(this).html('&nbsp;');
						}
					}

				});
			});
			$scope.showSearchProgress = false;
		}, function (response) {
			$scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
			if (response && response.data && response.data.details && response.data.details.message) {
				$scope.ErrorMessage = response.data.details.message;
			}
			else {
				$scope.ErrorMessage = 'Failed to retrive users.';
			}
			if (isSearch) $mdDialog.hide();
			$mdDialog.show($mdDialog.alert()
				.parent(angular.element(document.body))
				.clickOutsideToClose(true)
				.title('Warning!')
				.textContent($scope.ErrorMessage)
				.ariaLabel('')
				.ok('OK')
			);
			$scope.showSearchProgress = false;
		});
	}
	
	$scope.FilterOptions = {
		DbList: []
	};
	function fillDBinFilter() {
		var promise = HomeService.getDBLibraries($scope.mc.loginModel);
		promise.then(function (response) {
			$scope.FilterOptions.DbList = [];

			angular.forEach(response.data.data, function (db) {
				$scope.FilterOptions.DbList.push({ 'DisplayText': db.database, 'ValueText': db.database });
			});
		});
	}
	
	function showProgressDialog() {
		$mdDialog.show({
			parent: angular.element(document.body),
			template: '<md-dialog ng-cloak height="100%" style="min-width: 1px !important;"><md-dialog-content><div class="md-dialog-content-clearpadding">' +
			  '<md-progress-circular md-mode="indeterminate"></md-progress-circular>' +
			  '</div></md-dialog-content></md-dialog>',
			controller: DialogController
		});
	}

	function isValidFilterFind() {
		var filterKeyItem = null;
		var blnResult = false;

		for (var iCount = 0; iCount < requestModel.filters.length; iCount++) {
			filterKeyItem = requestModel.filters[iCount];
			if (filterKeyItem.FilterValues && filterKeyItem.FilterValues[0] && filterKeyItem.FilterValues[0].trim().length > 0) {
				blnResult = true;
				break;
			}
			filterKeyItem = null;
		}
		return blnResult;
	}

	$scope.onTableFilter = function (value, key, isInstantFilter, disablePerformFilter) {
		if (requestModel.filters.length > 0) {
			requestModel.filters = jQuery.grep(requestModel.filters, function (filterItem) {
				return filterItem.FilterKey !== key;
			});
		}
		var filterValueList = [];
		filterValueList[0] = value;

		var filterItem = { 'FilterKey': key, 'FilterValues': filterValueList };
		requestModel.filters.push(filterItem);

		if (FilterSearchTimeout) $timeout.cancel(FilterSearchTimeout);

		if (!disablePerformFilter) {
			if (isInstantFilter) {
				search_Click();
			} else {
				FilterSearchTimeout = $timeout(function () {
					search_Click();
				}, 2000);
			}
		};
	};

	$scope.$on('Search_Click', function () {
		search_Click();
	});

	function search_Click() {
		lastAppendItemCount = 0;
		LastAddedSelectedItemUserId = angular.copy(SelectedUserIdListForFilter);
		$scope.selected = [];
		$scope.UserList = [];
		isSearch = true;
		userInitalize();
	}
	
	$scope.query = {
		limit: requestModel.pageLength,
		page: requestModel.pagenumber,
		totalCount: 0
	};

	var isSearch = false;

	$scope.onPaginate = function (page, limit) {
		isSearch = false;
		requestModel.pagenumber = page;
		requestModel.pageLength = limit;

		getUsers();
		$scope.promise = $timeout(function () {

		}, 2000);
	};

	$scope.deSelect = function (userModel) {
		setContextMenuObject();
		if (SelectedUserIdListForFilter.length > 0) {
			SelectedUserIdListForFilter = $.grep(SelectedUserIdListForFilter,
								function (item, index) {
									return item.UserId != userModel.UserId;
								});
		}
		if (SelectedUserIdListForFilter.length > 0) {
			LastAddedSelectedItemUserId = $.grep(LastAddedSelectedItemUserId,
								   function (item, index) {
									   return item.UserId != userModel.UserId;
								   });
		}
	};

	$scope.onSelect = function (userModel) {
		setContextMenuObject();
		var tempListFilter = $filter('filter')(SelectedUserIdListForFilter, {
			UserId: userModel.UserId
		}, true);
		if (tempListFilter.length === 0) {
			SelectedUserIdListForFilter.push(angular.copy(userModel));
		}
	};

	$scope.loadStuff = function () {
		$scope.promise = $timeout(function () {

		}, 2000);
	};

	function userInitalize() {
		$scope.lastSelectedLibrary = '';
		requestModel.pagenumber = 1;
		$scope.query.page = 1;
		$scope.query.totalCount = 0;
		$scope.UserList = [];
		$scope.selected = [];
		//LastAddedSelectedItemUserId = [];
		lastAppendItemCount = 0;
		fillDBinFilter();
		getUsers();
	}
	
	RegisterInitializeTabContents();
	
	var destroybroadCast;
	$scope.$on('RegisterInitializeTabContents', function () {
		if(angular.isFunction(destroybroadCast))
			destroybroadCast();
	
		RegisterInitializeTabContents();
	});
	
	function RegisterInitializeTabContents() {
		destroybroadCast = $scope.$on('InitializeTabContents', function () {

			if ($scope.vm.selectedApp.NoAppsPermission.trim().length > 0)
				return;
			if (!$scope.vm.selectedLibrary || $scope.vm.selectedLibrary.trim().length == 0)
				return;

			$scope.selected = [];
			$scope.UserList = [];
			$scope.DBLibrariesByUser = [];
			$scope.GroupCheckedFInal = [];
			$scope.GroupDetails = [];
			$scope.GroupInUserList = [];
			$scope.GroupRemovedFInal = [];
			$scope.userGroupsList = [];
			$scope.AlreadySelectedUserGroupList = [];
			$scope.IsShowErrorMessage = false;
			$scope.ErrorMessage = '';
			$scope.user = userFactory.userInitailValues();
			$scope.validation = userFactory.validations();
			$scope.showSelectedUserDetails = false;

			totalGroupCount = 0;
			lastAppendItemCount = 0;
			view_scroll_fix_top = 482;
			FilterSearchTimeout = null;
			SelectedUserIdListForFilter = [];
			LastAddedSelectedItemUserId = [];
			requestModel = homeFactory.requestModelInstance();
			gsrequestModel = homeFactory.requestModelInstance();
			grequestModel = homeFactory.requestModelInstance();

			userInitalize();
			destroybroadCast();
		});
	}

	var ContextMenuVariables = {
		LockUnlock: {
			Label: 'Lock',
			Icon: 'img/icons/lock_outline_blue.svg',
			onClick: angular.noop
		}
	}

	$scope.ContextMenuFunctions = {
		Add: function () {
			$scope.PageEvents.Add();
		},
		Edit: function () {
			editFunction();
		},
		Delete: 'undefined',
		ResetPassword: function () {
			$scope.PageEvents.ResetPasswordclicked();
		},
		AssignToGroup: function () {
			AssignGroupFunction();
		},
		ViewUser: function () {
			viewFunction();
		},
		Properties: function () {
			PropertiesFunction();
		},
		//EditUserContent: function () {
		//	EditUserContentFunction();
		//},
		ViewUserAccount: function () {
			ViewUserAccountFunction();
		},
		ViewUserAccountHistory: function () {
			ViewUserAccountHistoryFunction();
		},
		LockAccount: function () {
			lockUserAccount();
		},
		UnlockAccount: function () {
			unLockUserAccount();
		},
		AssignSecurityTemplate: function () {
			if (typeof $scope.selected !== 'undefined' && $scope.selected.length > 0) {
				openAssignSecurityTemplateDialog();
			}
		},
		RemoveGroupInView: function () {
			$scope.UserGroupRemove();
		}
	}

	function setContextMenuObject() {
		if ($scope.selected !== undefined && $scope.selected.length > 0) {
			if ($scope.selected.length == 1) {
				if ($scope.selected[0].IsAllowLogon) {
					ContextMenuVariables.LockUnlock.Label = 'Lock Account';
					ContextMenuVariables.LockUnlock.Icon = 'img/icons/lock_outline_blue.svg';
					ContextMenuVariables.LockUnlock.onClick = $scope.ContextMenuFunctions.LockAccount;
					$scope.PageEvents.LockAccount = $scope.ContextMenuFunctions.LockAccount;
					$scope.PageEvents.UnlockAccount = 'undefined';
				} else {
					ContextMenuVariables.LockUnlock.Label = 'Unlock Account';
					ContextMenuVariables.LockUnlock.Icon = 'img/icons/lock_open_blue.svg';
					ContextMenuVariables.LockUnlock.onClick = $scope.ContextMenuFunctions.UnlockAccount;
					$scope.PageEvents.LockAccount = 'undefined';
					$scope.PageEvents.UnlockAccount = $scope.ContextMenuFunctions.UnlockAccount;
				}
			} else {
				ContextMenuVariables.LockUnlock.Label = '';
				ContextMenuVariables.LockUnlock.onClick = 'undefined';
				$scope.PageEvents.LockAccount = 'undefined';
				$scope.PageEvents.UnlockAccount = 'undefined';
				var unlockedUsersInSelectedList = $filter('filter')(
						$scope.selected, {
							IsAllowLogon: true
						});
				if (unlockedUsersInSelectedList.length == $scope.selected.length) {
					ContextMenuVariables.LockUnlock.Label = 'Lock Account';
					ContextMenuVariables.LockUnlock.Icon = 'img/icons/lock_outline_blue.svg';
					ContextMenuVariables.LockUnlock.onClick = $scope.ContextMenuFunctions.LockAccount;
					$scope.PageEvents.LockAccount = $scope.ContextMenuFunctions.LockAccount;
					$scope.PageEvents.UnlockAccount = 'undefined';
				} else {
					var lockedUsersInSelectedList = $filter('filter')(
							$scope.selected, {
								IsAllowLogon: false
							});
					if (lockedUsersInSelectedList.length == $scope.selected.length) {
						ContextMenuVariables.LockUnlock.Label = 'Unlock Account';
						ContextMenuVariables.LockUnlock.Icon = 'img/icons/lock_open_blue.svg';
						ContextMenuVariables.LockUnlock.onClick = $scope.ContextMenuFunctions.UnlockAccount;
						$scope.PageEvents.LockAccount = 'undefined';
						$scope.PageEvents.UnlockAccount = $scope.ContextMenuFunctions.UnlockAccount;
					}
				}
			}
		} else {
			ContextMenuVariables.LockUnlock.Label = '';
			ContextMenuVariables.LockUnlock.onClick = 'undefined';
			$scope.PageEvents.LockAccount = 'undefined';
			$scope.PageEvents.UnlockAccount = 'undefined';
		}

		$scope.menuList = [
				//{
				//	Label: 'Edit',
				//	Icon: 'icon-edit',
				//	onClick: $scope.ContextMenuFunctions.Edit,
				//	Enable: $scope.selected.length == 1,
				//	IconType: 'font-icon'

				//},
				//{
				//	Label: 'Add/Remove Groups',
				//	Icon: 'icon-add-remove-groups',
				//	onClick: $scope.ContextMenuFunctions.AssignToGroup,
				//	Enable: $scope.selected.length == 1,
				//	IconType: 'font-icon'
				//},
				//{
				//	Label: 'Properties',
				//	Icon: 'icon-properties',
				//	onClick: $scope.ContextMenuFunctions.Properties,
				//	Enable: $scope.selected.length == 1,
				//	IconType: 'font-icon'
				//},
				//{
				//	Label: 'Edit User Content',
				//	Icon: 'icon-edit-user-content',
				//	onClick: $scope.ContextMenuFunctions.EditUserContent,
				//	Enable: $scope.selected.length == 1,
				//	IconType: 'font-icon'
				//},
				{
					Label: 'Reset Password',
					Icon: 'icon-reset-password',
					onClick: $scope.ContextMenuFunctions.ResetPassword,
					Enable: $scope.selected.length > 0,
					IconType: 'font-icon'
				},
				{
					Label: 'Assign Security Template',
					Icon: 'icon-assign-security-template',
					onClick: $scope.ContextMenuFunctions.AssignSecurityTemplate,
					Enable: $scope.selected.length == 1,
					IconType: 'font-icon'
				},
				{
					Label: 'Lock',
					Icon: 'icon-lock-account',
					onClick: ContextMenuVariables.LockUnlock.onClick,
					Enable: $scope.selected.length > 0
							&& ContextMenuVariables.LockUnlock.Label != '' && $scope.selected[0].IsAllowLogon,
					IconType: 'font-icon'
				},
				{
					Label: 'Un Lock',
					Icon: 'icon-unlock',
					onClick: ContextMenuVariables.LockUnlock.onClick,
					Enable: $scope.selected.length > 0
							&& ContextMenuVariables.LockUnlock.Label != '' && !$scope.selected[0].IsAllowLogon,
					IconType: 'font-icon'
				}
		];
	}

	$scope.$on('$destroy', function () {
		$scope.PageEvents.Add = 'undefined';
		$scope.PageEvents.Edit = 'undefined';
		$scope.PageEvents.Save = 'undefined';
		$scope.PageEvents.Delete = 'undefined';
		$scope.PageEvents.CancelDialog = 'undefined';
		$scope.PageEvents.ShowSubclassList = 'undefined';
		$scope.PageEvents.AddRole = 'undefined';
		$scope.PageEvents.ResetPasswordclicked = 'undefined';
		$scope.PageEvents.ViewAssignUser = 'undefined';
		$scope.PageEvents.AssignUser = 'undefined';
		$scope.PageEvents.AssignGroup = 'undefined';
		$scope.PageEvents.LockAccount = 'undefined';
		$scope.PageEvents.UnlockAccount = 'undefined';
		$scope.PageEvents.ViewGeneralUser = 'undefined';
		$scope.PageEvents.ViewSelected = 'undefined';
		$scope.PageEvents.ShowOnlySelected = 'undefined';
	});

	function DialogController($scope, $mdDialog) {
		$scope.hide = function () {
			$mdDialog.hide();
		};
		$scope.cancel = function () {
			$mdDialog.cancel();
		};
		$scope.answer = function () {
			$mdDialog.hide();
			$scope.selectedChipGroups = [];
		};

		$scope.UserSearchTextChange = CustomUserSearchTextChange;

		function CustomUserSearchTextChange($event) {
			if ($event.keyCode === 13) {
				$event.preventDefault();
			}
		}

		$scope.SaveButtonChange = function ($event) {
			if ($event.keyCode === 9) {
				$event.preventDefault();
			}
			$("#PasswordField").focus();
			return false;
		}

		$scope.PropertiesOkButtonChange = function ($event) {
			if ($event.keyCode === 13) {
				$mdDialog.cancel();
			}
			if ($event.keyCode === 9) {
				$event.preventDefault();
			}
			$("#userForm input[id=UserID]").focus();
			$("#userForm input[id=UserID]").select();
			return false;
		}

		$scope.AssignSecuritySaveButtonChange = function ($event) {
			if ($event.keyCode === 9) {
				$event.preventDefault();
				$("#AssigsecurityItem").focus();
			}
			return false;
		}

	}

	function lockUserAccount() {

		var alertMessage = "";
		if ($scope.selected[0] == 1) {
			alertMessage = "Are you sure you want to lock the account for " + $scope.selected[0].UserId + "?"
		} else {
			alertMessage = "Are you sure you want to lock the selected account(s)?"

		}
		var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;

		var confirm = $mdDialog.confirm()
					.title('Warning!')
					.theme('confirm-dialog')
				.textContent(alertMessage)
				.ariaLabel('Warning!').ok('Yes').cancel('No');

		$mdDialog.show(confirm).then(
				function () {
					var deferredarray = [];
					angular.forEach($scope.selected, function (user) {
						var deferred = $q.defer();
						$scope.mc.getlogDetails("Debug", 'Method:GET ;Lock Selected User:' + user.UserId);
						var promise = userFactory.getSingleUser('GETUSER',
								$scope.vm.selectedLibrary, user.UserId,
								$scope.mc.loginModel.AuthKey);
						promise.then(function (response) {
							if (response) {
								response.data[0][CONST_USERS.IsAllowLogon] = false;
								var userdata = userFactory
										.getUserUI(response.data[0]);
								
								
								var requestBody = userFactory.getUserPutModel(
												userdata,
												$scope.vm.selectedLibrary)
								var apiUrl=userFactory.getAPIUrl('PUTUSER',
												null,user.UserId);
								$scope.mc.getlogDetails("Debug", 'Method:PUT;URL:' + JSON.stringify(apiUrl) + 'Request Body:' + JSON.stringify(requestBody));
								var promise1 = UserService.editUser(requestBody
										, apiUrl,
										$scope.mc.loginModel.AuthKey);
								promise1.then(function (response) {
									if (response) {
										if (response.status === 200) {
											user.IsAllowLogon = false;
											if (response.data.Message != undefined && response.data.Message != '') {
											    $scope.mc.setSecurityLogDetails("Info", 'Failure', user.UserId, 'User Lock', '');
											}
											else {
											    $scope.mc.setSecurityLogDetails("Info", 'Success', user.UserId, 'User Lock', '');
											}

										}
										else {
										    $scope.mc.setSecurityLogDetails("Info", 'Failure', user.UserId, 'User Lock', '');
										}
										deferred.resolve(response);
									}
								}, function (response) {
								    $scope.mc.setSecurityLogDetails("Info", 'Failure', user.UserId, 'User Lock', '');
								});

							}
						}, function (response) {
						    $scope.mc.setSecurityLogDetails("Info", 'Failure', user.UserId, 'Lock User', '');
						});
						deferredarray.push(deferred.promise);
					});

					$q.all(deferredarray).then(function () {
						//getUsers();
						$scope.selected = [];
					});
				});
	}

	function unLockUserAccount() {
		var alertMessage = "";
		if ($scope.selected[0] == 1) {
			alertMessage = "Are you sure you want to unlock the account for " + $scope.selected[0].UserId + "?"
		} else {
			alertMessage = "Are you sure you want to unlock the selected account(s)?"

		}
		var useFullScreen = ($mdMedia('sm') || $mdMedia('xs'))
				&& $scope.customFullscreen;
		var confirm = $mdDialog.confirm()
					.title('Warning!')
					.theme('confirm-dialog')
				.textContent(alertMessage)
				.ariaLabel('').ok('Yes')
				.cancel('No');

		$mdDialog.show(confirm).then(
				function () {
					var deferredarray = [];
					angular.forEach($scope.selected, function (user) {
						var deferred = $q.defer();
						$scope.mc.getlogDetails("Debug", 'Unlock Selected User:' + user.UserId);
						var promise = userFactory.getSingleUser('GETUSER',
								$scope.vm.selectedLibrary, user.UserId,
								$scope.mc.loginModel.AuthKey);
						promise.then(function (response) {
							if (response) {
								response.data[0][CONST_USERS.IsAllowLogon] = true;
								var userdata = userFactory
										.getUserUI(response.data[0]);
								var requestBody = userFactory.getUserPutModel(
												userdata,
												$scope.vm.selectedLibrary)
								var apiUrl=userFactory.getAPIUrl('PUTUSER',
												null,user.UserId)
								$scope.mc.getlogDetails("Debug", 'Requested ApiUrl:' + JSON.stringify(apiUrl) + ",Parametes are" + JSON.stringify(requestBody));
								var promise1 = UserService.editUser(
										requestBody, apiUrl,
										$scope.mc.loginModel.AuthKey);
								promise1.then(function (response) {
									if (response) {
										if (response.status === 200) {
											user.IsAllowLogon = true;
											if (response.data.Message != undefined && response.data.Message != '') {
											    $scope.mc.setSecurityLogDetails("Info", 'Failure', user.UserId, 'User UnLock', '');
											}
											else {
											    $scope.mc.setSecurityLogDetails("Info", 'Success', user.UserId, 'User UnLock', '');
											}
										}
										else {

										    $scope.mc.setSecurityLogDetails("Info", 'Failure', user.UserId, 'User UnLock', '');
										}
										deferred.resolve(response);
									}
								}, function (response) {
								    $scope.mc.setSecurityLogDetails("Info", 'Failure', user.UserId, 'User UnLock', '');

								});

							}
						}, function (response) {
						    $scope.mc.setSecurityLogDetails("Info", 'Failure', user.UserId, 'User UnLock', '');
						});
						deferredarray.push(deferred.promise);
					});

					$q.all(deferredarray).then(function () {
						//getUsers();
						$scope.selected = [];
					});
				});
	}

	$scope.PageEvents.Add = function () {
		$scope.AddUserModel.PasswordValue = '';
		$scope.AddUserModel.ConfirmPasswordValue = '';
		$scope.validation.ConfirmPassword = '';
		$scope.validation.showMessage = false;
		$scope.user = userFactory.userInitailValues();

		var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;

		$mdDialog.show({
			controller: UserAddDialogController,
			preserveScope: false,
			templateUrl: 'Views/AddUser.html',
			parent: angular.element(document.body),
			clickOutsideToClose: true,
			fullscreen: useFullScreen,
			escapeToClose: false,
			locals: {
				parentScope: $scope
			},
			onComplete: function () {
				$("#userForm input[id=UserId]").focus();
			}
		}).then(function (answer) {
			$scope.status = '';
		}, function () {
			$scope.status = '';
		});
		$scope.$watch(function () {
			return $mdMedia('xs') || $mdMedia('sm');
		}, function (wantsFullScreen) {
			$scope.customFullscreen = (wantsFullScreen === true);
		});
	};

	function UserAddDialogController($scope, $mdDialog, parentScope) {
		$scope.hide = function () {
			$mdDialog.hide();
		};
		$scope.cancel = function () {
			$mdDialog.cancel();
		};
		$scope.answer = function () {
			$mdDialog.hide();
		};

		$scope.AddUserSaveButtonChange = function ($event) {
			if ($event.keyCode === 9) {
				$event.preventDefault();
			}
			$("#userForm input[id=UserId]").focus();
			return false;
		}

		$scope.AddUserSelectedTab = 0;
		$scope.ShowWarning = false;
		$scope.posting = false;
		$scope.DBList = [];
		$scope.selectedChipGroups = [];
		$scope.SelectedgroupList = [];
		$scope.AddUserModel = parentScope.AddUserModel;
		$scope.validation = userFactory.validations();
		$scope.AddUserModel.PasswordValue = '';
		$scope.AddUserModel.ConfirmPasswordValue = '';
		$scope.validation.ConfirmPassword = '';
		$scope.validation.showMessage = false;
		$scope.user = userFactory.userInitailValues();
		$scope.autocompleteDemoRequireMatch = true;
		$scope.selectedItem = null;
		$scope.searchText = null;
		$scope.GroupDetails = [];

		var groupRequestModel = homeFactory.requestModelInstance();


		$scope.$watch(function () { return $scope.AddUserModel.PasswordValue }, function () {
			if ($scope.userForm) {
				$timeout(function () {
					$scope.userForm.ConfirmPassword.$setValidity('mismatch', $scope.validation.ConfirmPassword == $scope.user.Password);
				});
			}
		})

		$scope.$watch(function () { return $scope.AddUserModel.ConfirmPasswordValue }, function () {
			if ($scope.userForm) {
				$timeout(function () {
					$scope.userForm.ConfirmPassword.$setValidity('mismatch', $scope.validation.ConfirmPassword == $scope.user.Password);
				});
			}
		})

		$scope.fillDBinUserList = function () {
			var promise = HomeService.getDBLibraries(parentScope.mc.loginModel);
			promise.then(function (response) {
				$scope.DBList = [];
				 
					
					angular.forEach(response.data.data, function (db) {
						$scope.DBList.push(databasesFactory.getDatabaseUI(db));
					});
				 

			});
		};

		$scope.dialogPopup = {
			Header: '',
			Message: '',
			CallbackFunction: null,
			Show: function () {
				$('#popup-alert-dialog-bg').slideToggle();
			},
			OK: function () {
				$('#popup-alert-dialog-bg').slideToggle();
				$scope.dialogPopup.Header = '';
				$scope.dialogPopup.Message = '';

				if ($scope.dialogPopup.CallbackFunction) {
					$scope.dialogPopup.CallbackFunction();
					$scope.dialogPopup.CallbackFunction = null;
				}
			}
		}

		$scope.addUser = function () {
			$scope.posting = false;
			$scope.validation.showMessage = true;
			$scope.ShowWarning = false;
			var UserLog = [];
			

			if ($scope.userForm.UserId.$invalid || $scope.user.Password == ''
					|| $scope.validation.ConfirmPassword != $scope.user.Password
					|| $scope.userForm.Email.$invalid) {
				if ($scope.userForm.UserId.$invalid
						|| $scope.userForm.Email.$invalid) {
					$scope.AddUserSelectedTab = 0;
				} else {
					$scope.AddUserSelectedTab = 1;
				}
				return;
			}
			$scope.posting = true;
			
			var requestBody = userFactory.getUserPostModel($scope.user, parentScope.vm.selectedLibrary)			
			var apiUrl=userFactory
					.getAPIUrl('POSTUSER', null);
			UserLog = angular.copy(requestBody);
			UserLog.user_password = "*********";
			parentScope.mc.getlogDetails("Debug", 'Requested ApiUrl:' + JSON.stringify(apiUrl) + ",Parametes are" + JSON.stringify(UserLog));
			var promise = UserService.addUser(requestBody, apiUrl, parentScope.mc.loginModel.AuthKey);
			
			promise
					.then(
							function (response) {
								$scope.posting = false;
								if (response && response.data
										&& response.data[CONST_USERS.UserNum]) {
									if (response.data[CONST_USERS.UserNum] > 0) {
										$scope.dialogPopup.CallbackFunction = function () {
											$mdDialog.hide();
										}
										$scope.dialogPopup.Header = 'Success';
										$scope.dialogPopup.Message = 'User added succesfully.';
										$scope.dialogPopup.Show();
										//parentScope.mc.setSecurityLogDetails("Info", 'Response:' + 'user ' + $scope.user.UserId + ' Details added Successfully');
										parentScope.mc.setSecurityLogDetails("Info", 'Success', $scope.user.UserId, 'User Add', JSON.stringify(UserLog));
										$timeout(function () {
											//$scope.ShowWarning = false;
											//$mdDialog.hide();
											$scope.dialogPopup.OK();
											parentScope.selected = [];
											parentScope.UserList = [];
											userInitalize();
										}, 2000);
										$scope.showValidation = false;

										AddGroupsForUser();


										$scope.user = userFactory
												.userInitailValues();
										$scope.validation = userFactory
												.validations();

										$scope.AddUserModel.PasswordValue = '';
										$scope.AddUserModel.ConfirmPasswordValue = '';
									}
								} else {
								    //UserLog = [];
									UserLog = JSON.parse(angular.copy(response.config.data));
									UserLog.user_password = "*********"
									$scope.ShowWarning = true;
								    //parentScope.mc.setSecurityLogDetails("Error", "Response:" + JSON.stringify(UserLog));
									parentScope.mc.setSecurityLogDetails("Info", 'Failure', $scope.user.UserId, 'User Add', JSON.stringify(UserLog));
									if (response && response.data && response.data.details && response.data.details.message) {
										$scope.ErrorMessage = response.data.details.message;
										
									}
									else {
										$scope.ErrorMessage = "Posting user failed due to unknown errors.";
										
									}
								}
							}, function (response) {
							    //UserLog = [];
								//UserLog = JSON.parse(angular.copy(response.config.data));
								//UserLog.user_password = "*********"
								$scope.posting = false;
								$scope.ShowWarning = true;
							    //parentScope.mc.setSecurityLogDetails("Error", "Response:" + JSON.stringify(UserLog));
								parentScope.mc.setSecurityLogDetails("Info", 'Failure', $scope.user.UserId, 'User Add', JSON.stringify(UserLog));
								$scope.ErrorMessage = "Posting user failed due to unknown errors.";
							});
		};


		function AddGroupsForUser() {

			angular.forEach($scope.SelectedgroupList, function (group) {
				/////
				var requestBody = {
					database: parentScope.vm.selectedLibrary,
					data_type: "users",
					data: [],
					action: "add"
				};
				requestBody.data.push($scope.user.UserId);

				var requestUrl=groupFactory.getAPIUrl('ADDUSERINGROUP', group, $scope.user.UserId, parentScope.vm.selectedLibrary, 'add');
				parentScope.mc.getlogDetails("Debug", 'Requested ApiUrl:' + JSON.stringify(requestUrl));
				var promise = GroupService.AddUserToGroup(requestUrl, requestBody, parentScope.mc.loginModel.AuthKey);
				promise.then(function (response) {
				    if (response) {
				        if (response.status === 200) {
				            parentScope.mc.setSecurityLogDetails("Info", 'Success', $scope.user.UserId, 'User Add Group', 'Group Name=\"' + group.GroupName + '\"');
				        } else {
				            $scope.ShowWarning = true;
				            $scope.ErrorMessage = response.statusDetail;
				            parentScope.mc.setSecurityLogDetails("Info", 'Failure', $scope.user.UserId, 'User Add Group', 'Group Name=\"' + group.GroupName + '\"');
				        }
				    }
				}, function (response) {
				    parentScope.mc.setSecurityLogDetails("Info", 'Failure', $scope.user.UserId, 'User Add Group', 'Group Name=\"' + group.GroupName + '\"');

				});
			});

			$scope.SelectedgroupList = [];

		}

		$scope.transformChip = function (chip) {
			if (angular.isObject(chip)) {
				return chip;
			}
			return { GroupName: chip, GroupFullName: 'new' }
		};

		$scope.querySearch = function (query) {
			if (groupRequestModel.filters.length > 0) {
				groupRequestModel.filters = jQuery.grep(groupRequestModel.filters, function (filterItem) {
					return filterItem.FilterKey !== 'GroupName';
				});
			}
			var filterValueList = [];
			filterValueList[0] = query;

			var filterItem = { 'FilterKey': 'GroupName', 'FilterValues': filterValueList };
			groupRequestModel.filters.push(filterItem);

			if (groupRequestModel.filters.length == 0) {
				filterItem = { 'FilterKey': 'GroupEnabled', 'FilterValues': ['Y'] };
				groupRequestModel.filters.push(filterItem);
			}
			groupRequestModel.pagenumber = 1;
			groupRequestModel.pagelength = 20;
			return getAllGroupList();
		};

		function getAllGroupList() {
			if (!parentScope.vm.selectedLibrary || parentScope.vm.selectedLibrary.trim().length == 0)
				return;
			$scope.lastSelectedLibrary = parentScope.vm.selectedLibrary;
			groupRequestModel.libraryName = parentScope.vm.selectedLibrary;

			var deffered = $q.defer();
			/////
			var apiUrl =groupFactory.getAPIUrl('SEARCHGROUPS', groupRequestModel);
			parentScope.mc.getlogDetails("Debug", 'Requested ApiUrl:' + JSON.stringify(apiUrl));
			var Group = GroupService.getGroups(apiUrl, parentScope.mc.loginModel.AuthKey);
			Group.then(
							function (response) {
								if (response["status"] == 200) {
									$scope.GroupDetails = [];
									angular.forEach(response["data"]["data"], function (group) {
										$scope.GroupDetails.push(groupFactory.getGroupUI(group));
									});
									deffered.resolve($scope.GroupDetails);
								}
								else {
									parentScope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
								}
							});
			return deffered.promise;
		}

		$scope.fillDBinUserList();
	}
	
		
	var editFunction = function (event) {

		$scope.ShowWarning = false;
		$scope.PageEvents.UserAction = 'Edit';
		$scope.DisableViewUserContent = false;
		$scope.ShowSaveButton = false;
		$scope.posting = false;
		$scope.SelectedUserIndexList = [];

		$scope.SelectedUserIndexList.push($scope.UserList.indexOf($scope.selected[0]));
		$scope.originaluser = userFactory.userInitailValues();
		angular.copy($scope.user, $scope.originaluser);
		var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
		$mdDialog
				.show(
						{
							controller: EditUserContentDialogController,
							preserveScope: false,
							templateUrl: 'Views/EditUser.html',
							parent: angular.element(document.body),
							clickOutsideToClose: true,
							fullscreen: useFullScreen,
							onComplete: function () {
								$("#userForm input[id=fullName]").focus();
								$("#userForm input[id=fullName]").select();
							},
							locals: {
								parentScope: $scope
							}
						})
				.then(
						function (answer) {
							$scope.status = '';
						},
						function () {
							$scope.status = '';
						});
		$scope
				.$watch(
						function () {
							return $mdMedia('xs') || $mdMedia('sm');
						},
						function (wantsFullScreen) {
							$scope.customFullscreen = (wantsFullScreen === true);
						});

	};

	function FillUserScope(selectedUser) {
		$scope.user.UserId = selectedUser.UserId;
		$scope.user.FullName = selectedUser.FullName;
		$scope.user.Location = selectedUser.Location;
		$scope.user.Phone = selectedUser.Phone;
		$scope.user.Ext = selectedUser.Ext;
		$scope.user.Fax = selectedUser.Fax;
		$scope.user.Email = selectedUser.Email == null ? '' : selectedUser.Email;
		$scope.user.IsExternalUser = selectedUser.IsExternalUser;
		$scope.user.Password = '';
		$scope.user.UserMustChangePassword = selectedUser.UserMustChangePassword;
		$scope.user.PasswordNeverExpires = selectedUser.PasswordNeverExpires;
		$scope.user.IsAllowLogon = selectedUser.IsAllowLogon;
		$scope.user.PreferredDatabase = selectedUser.PreferredDatabase;
		$scope.user.FileServer = selectedUser.FileServer;
		$scope.user.SecuredDocServer = selectedUser.SecuredDocServer;
		$scope.user.UserNos = selectedUser.UserNos;
		$scope.user.UserNum = selectedUser.UserNum;
		$scope.user.UserIdEx = selectedUser.UserIdEx;
		$scope.user.PasswordChangeDate = selectedUser.PasswordChangeDate;
	}

	function validateEmail(emailAddress) {
		var EMAIL_REGEXP = /^(([^<>()\[\]\\.,;:\s@" ]+(\.[^><>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
		if (!EMAIL_REGEXP.test(emailAddress)) {
			return false;
		}
		return true;
	}

	$scope.$watch(function () { return $scope.AddUserModel.PasswordValue }, function () {
		if ($scope.userForm) {
			$timeout(function () {
				$scope.userForm.ConfirmPassword.$setValidity('mismatch', $scope.validation.ConfirmPassword == $scope.user.Password);
			});
		}
	})

	$scope.$watch(function () { return $scope.AddUserModel.ConfirmPasswordValue }, function () {
		if ($scope.userForm) {
			$timeout(function () {
				$scope.userForm.ConfirmPassword.$setValidity('mismatch', $scope.validation.ConfirmPassword == $scope.user.Password);
			});
		}
	})

	$scope.PageEvents.ResetPasswordclicked = function () {
		if ($("#contextmenunode"))
			$("#contextmenunode").remove();

		$scope.posting = false;
		$scope.SelectedUserIndexList = [];
		if (typeof $scope.selected !== 'undefined' && $scope.selected.length > 0) {
			angular.forEach($scope.selected, function (userModelTemp) {
				$scope.SelectedUserIndexList.push($scope.UserList.indexOf(userModelTemp));
			});
			$scope.ShowWarning = false;
			$scope.validation.ConfirmPassword = '';
			$scope.AddUserModel.PasswordValue = '';
			$scope.validation.showMessage = false;
			$scope.user = userFactory.userInitailValues();

			var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
			$mdDialog.show({
				controller: DialogController,
				scope: $scope,
				preserveScope: true,
				templateUrl: 'Views/ResetPassword.html',
				parent: angular.element(document.body),
				clickOutsideToClose: true,
				fullscreen: useFullScreen,
				onComplete: function () {
					$("#PasswordField").focus();
				}
			}).then(
					function (answer) {
						$scope.status = '';
					}, function () {
						$scope.status = '';
					});
			$scope.$watch(function () {
				return $mdMedia('xs') || $mdMedia('sm');
			}, function (wantsFullScreen) {
				$scope.customFullscreen = (wantsFullScreen === true);
			});
		} else {
			$mdDialog.show($mdDialog.alert()
				.parent(angular.element(document.body))
				.clickOutsideToClose(true)
				.title('Warning!')
				.textContent('Select User(s) to reset password.')
				.ariaLabel('Warning!')
				.ok('OK')
			);
			return false;
		}
	};

	$scope.ResetPassword = function () {
		$scope.posting = false;
		$scope.validation.showMessage = true;
		var requestBody = "";
		var requestUrl = "";

		if ($scope.user.Password == ''
				|| $scope.validation.ConfirmPassword != $scope.user.Password) {
			$scope.posting = false;
			return;
		} else {
			var resetPwdSuccessfully = true;
			$scope.posting = true;
			$scope.ErrorMessage = '';
			$scope.ResetPasswordUsers = $scope.selected;
			var deferredarray = [];
			if ($scope.ResetPasswordUsers.length > 0) {
				angular
						.forEach(
								$scope.ResetPasswordUsers,
								function (temp) {

									var deferred = $q.defer();

									temp.UserMustChangePassword = $scope.user.UserMustChangePassword;
									temp.PasswordNeverExpires = $scope.user.PasswordNeverExpires;
									temp.Password = '****************';

									requestUrl = userFactory.getAPIUrl('PUTUSER', null, temp.UserId);
									requestBody = userFactory.getUserPutModel(temp, $scope.vm.selectedLibrary);
									//temp.Password = $scope.user.Password;

									$scope.mc.getlogDetails("Debug", 'Method:POST;URL:' + JSON.stringify(requestUrl) + 'Request Body:' + JSON.stringify(requestBody));

									temp.Password = $scope.user.Password;
									requestBody.user_password = temp.Password;
									var promise = UserService.editUser(requestBody, requestUrl, $scope.mc.loginModel.AuthKey);
									promise.then(function (response) {
										$scope.posting = false;
										requestBody.user_password = '**********';
										deferred.resolve(response);
										if (response && response.status && response.status == 200) {
											if (resetPwdSuccessfully)
												resetPwdSuccessfully = true;
										    //	$scope.mc.setSecurityLogDetails("Info", 'Response: password changed by ' + $scope.mc.loginModel.UserName + ' succesfully of user ' + temp.UserId + '.');
											$scope.mc.setSecurityLogDetails("Info", 'Success', temp.UserId, 'User Reset Passsword', 'User Must Change Next Login= ' + $scope.user.UserMustChangePassword);

										} else {
											$scope.ErrorMessage += response.data.Message;
											resetPwdSuccessfully = false;
											$scope.mc.setSecurityLogDetails("Info", 'Failure', temp.UserId, 'User Reset Passsword', 'User Must Change Next Login= ' + $scope.user.UserMustChangePassword);
										}
									}, function (response) {
									    $scope.mc.setSecurityLogDetails("Info", 'Failure', temp.UserId, 'User Reset Passsword', 'User Must Change Next Login= ' + $scope.user.UserMustChangePassword);
										$scope.posting = false;
									});

									deferredarray.push(deferred.promise);
								});


				$q.all(deferredarray).then(function () {
					if (resetPwdSuccessfully) {
						$scope.dialogPopup.CallbackFunction = function () {
							$mdDialog.hide();
						}
						$scope.dialogPopup.Header = 'Success';
						$scope.dialogPopup.Message = 'User password changed succesfully.';
						$scope.dialogPopup.Show();
						$timeout(function () {
							$scope.dialogPopup.OK();
						}, 2000);

						var selecteduserModel;
						for (iCount = 0; iCount < $scope.SelectedUserIndexList.length; iCount++) {
							selecteduserModel = $scope.UserList[$scope.SelectedUserIndexList[iCount]];
							if (selecteduserModel) {
								selecteduserModel.UserMustChangePassword = $scope.user.UserMustChangePassword;
								selecteduserModel.PasswordNeverExpires = $scope.user.PasswordNeverExpires;
							}
							selecteduserModel = null;
						}
						var tempList = [];
						tempList = angular.copy($scope.UserList);
						$scope.selected = [];
						$scope.UserList = [];
						$scope.UserList = angular.copy(tempList);
						tempList = [];
					}
					else {
						$scope.ShowWarning = true;
						$scope.ErrorMessage = "Reset password failed due to unknown errors.";
					    //	$scope.mc.getlogDetails("Error", "Reset password failed due to unknown errors.");
						$scope.mc.setSecurityLogDetails("Info", 'Failure', temp.UserId, 'Reset Password', '');
					}

				});

			} else {
				$scope.mc.getlogDetails("Error", "Please select a User.");
				$mdDialog.show($mdDialog.alert().parent(
						angular.element(document
								.querySelector(angular.element(document.body))
						.clickOutsideToClose(true).title('Warning!').textContent(
								'Please select a User.').ariaLabel(
								'Warning!').ok('OK'))));
			}
		}
	};
	
	$scope.PageEvents.ShowOnlySelected = function () {
		$scope.vm.viewSelectedOnlyLabel = $scope.vm.viewSelectedOnlyLabel == 'View selected' ? 'Show all' : 'View selected';
	}

	var viewFunction = function () {
		$scope.ShowWarning = false;
		$scope.PageEvents.UserAction = 'View';
		$scope.DisableSaveButton = true;

		if (typeof $scope.selected !== 'undefined' && $scope.selected.length > 0) {
			FillUserScope($scope.selected[0]);

			var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
			$mdDialog.show({
				controller: DialogController,
				scope: $scope,
				preserveScope: true,
				templateUrl: 'Views/EditUser.html',
				parent: angular.element(document.body),
				clickOutsideToClose: true,
				fullscreen: useFullScreen,
				onComplete: function () {
					$("#userForm input[id=UserID]").focus();
					$("#userForm input[id=UserID]").Select();
				}
			}).then(
					function (answer) {
						$scope.status = '';
					}, function () {
						$scope.status = '';
					});
			$scope.$watch(function () {
				return $mdMedia('xs') || $mdMedia('sm');
			}, function (wantsFullScreen) {
				$scope.customFullscreen = (wantsFullScreen === true);
			});
		} else {
			parentScope.mc.setSecurityLogDetails("Error", "Select User to view details.");
			$mdDialog.show($mdDialog.alert()
			   .parent(angular.element(document.body))
			   .clickOutsideToClose(true)
			   .title('Warning!')
			   .textContent('Select User to view details.')
			   .ariaLabel('Warning!')
			   .ok('OK')
		   );
		}
	};
	
	var PropertiesFunction = function () {
		$scope.ShowWarning = false;
		$scope.PageEvents.UserAction = 'View User Content';
		$scope.DisableViewUserContent = true;
		$scope.ShowSaveButton = false;

		if (typeof $scope.selected !== 'undefined' && $scope.selected.length > 0) {
			getDatabaseByUser($scope.selected[0].UserId, $scope.selected[0].Password);
			$scope.mc.getlogDetails("Debug", 'Method:GET ;Lock Selected User:' + $scope.selected[0].UserId);
			var promise = userFactory.getSingleUser('GETUSER',
					$scope.vm.selectedLibrary, $scope.selected[0].UserId, $scope.mc.loginModel.AuthKey);
			promise
					.then(
							function (response) {
								if (response) {
									$scope.mc.getlogDetails("Debug", 'Response:Success');

									$scope.user = userFactory
											.getUserUI(response.data[0]);

									var useFullScreen = ($mdMedia('sm') || $mdMedia('xs'))
											&& $scope.customFullscreen;
									$mdDialog
											.show(
													{
														controller: DialogController,
														scope: $scope,
														preserveScope: true,
														templateUrl: 'Views/ViewUser.html',
														parent: angular.element(document.body),
														clickOutsideToClose: true,
														fullscreen: useFullScreen,
														onComplete: function () {
															$("#userForm input[id=UserID]").focus();
															$("#userForm input[id=UserID]").select();
														}
													})
											.then(
													function (answer) {
														$scope.status = '';
													},
													function () {
														$scope.status = '';
													});
									$scope
											.$watch(
													function () {
														return $mdMedia('xs') || $mdMedia('sm');
													},
													function (wantsFullScreen) {
														$scope.customFullscreen = (wantsFullScreen === true);
													});

								}
								else {
									$scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
								}
							}, function (response) {
								$scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));

							});

		} else {
			parentScope.mc.getlogDetails("Error", "Select User to view user content.");
			$mdDialog.show($mdDialog.alert()
			  .parent(angular.element(document.body))
			  .clickOutsideToClose(true)
			  .title('Warning!')
			  .textContent('Select User to view user content.')
			  .ariaLabel('Warning!')
			  .ok('OK')
		  );
		}
	};
	
	function getDatabaseByUser(userID, Password) {
		var promise = HomeService.getDBLibraries($scope.mc.loginModel);
		promise.then(function (response) {
			
			$scope.DBLibrariesByUser = [];
			angular.forEach(response.data.data, function (db) {
				$scope.DBLibrariesByUser.push(databasesFactory.getDatabaseUI(db));
			});

		});
	}

	var ViewUserAccountFunction = function () {
		$scope.ShowWarning = false;
		$scope.PageEvents.UserAction = 'View User Account';

		if (typeof $scope.selected !== 'undefined' && $scope.selected.length > 0) {
			FillUserScope($scope.selected[0]);

			var useFullScreen = ($mdMedia('sm') || $mdMedia('xs'))
					&& $scope.customFullscreen;
			$mdDialog.show({
				controller: DialogController,
				scope: $scope, // use parent scope in template
				preserveScope: true,
				templateUrl: 'Views/ViewUserAccount.html',
				parent: angular.element(document.body),
				clickOutsideToClose: true,
				fullscreen: useFullScreen
			}).then(
					function (answer) {
						$scope.status = '';
					}, function () {
						$scope.status = '';
					});
			$scope.$watch(function () {
				return $mdMedia('xs') || $mdMedia('sm');
			}, function (wantsFullScreen) {
				$scope.customFullscreen = (wantsFullScreen === true);
			});
		} else {
			parentScope.mc.getlogDetails("Error", "Select User to view account details.");
			$mdDialog.show($mdDialog.alert()
			  .parent(angular.element(document.body))
			  .clickOutsideToClose(true)
			  .title('Warning!')
			  .textContent('Select User to view account details.')
			  .ariaLabel('Warning!')
			  .ok('OK')
		  );
		}
	};
	
	$scope.editViewUserContent = function () {
		$scope.validation.showMessage = true;
		$scope.posting = true;
		var requestBody = userFactory.getUserPutModel($scope.user, $scope.vm.selectedLibrary)
		var requestUrl = userFactory.getAPIUrl('PUTUSER', null, $scope.user.UserId)
		$scope.mc.getlogDetails("Deubug", 'Method:POST;URL:' + JSON.stringify(requestUrl) + 'Request Body:' + JSON.stringify(requestBody));		
		var promise = UserService.editUser(
				requestBody,
				requestUrl,
				$scope.mc.loginModel.AuthKey);

		promise.then(function (response) {
			$scope.posting = false;
			if (response && response.status && response.status == 200) {
				$mdDialog.hide();
				getUsers();
				$scope.showValidation = false;
				//$scope.mc.setSecurityLogDetails("Info", $scope.user.UserId + ' Details Changed');
				$scope.user = userFactory.userInitailValues();
				$scope.validation = userFactory.validations();
				$scope.ShowWarning = false;
			} else {
				$scope.ShowWarning = true;
				$scope.ErrorMessage = response.data.Message;
				$scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
			}
		}, function (response) {
			$scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
			$scope.posting = false;
		});
	};
	
	function openAssignSecurityTemplateDialog() {
		var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;

		var dialogObject = {
			controller: AssignSecurityTemplateDialogController,
			scope: $scope,
			preserveScope: true,
			templateUrl: 'Views/AssignGroupSecurityTemplate.html',
			parent: angular.element(document.body),
			targetEvent: null,
			clickOutsideToClose: true,
			fullscreen: useFullScreen,
			onComplete: function () {
				$("#AssignSecurityItem").focus();
			},
			locals: {
				parentScope: $scope
			}
		};
		$mdDialog.show(dialogObject).then(function (answer) {
			$scope.status = '';
		}, function () {
			$scope.status = '';
		});
		$scope.$watch(function () {
			return $mdMedia('xs') || $mdMedia('sm');
		}, function (wantsFullScreen) {
			$scope.customFullscreen = (wantsFullScreen === true);
		});
	}

	function AssignSecurityTemplateDialogController($scope, $mdDialog, parentScope) {
		$scope.hide = function () {
			$mdDialog.hide();
		};
		$scope.cancel = function () {
			$mdDialog.cancel();
		};
		$scope.answer = function () {
			$mdDialog.hide();
		};

		$scope.EditUserSaveButtonChange = function ($event) {
			if ($event.keyCode === 9) {
				$event.preventDefault();
			}
			$("#AssignSecurityItem").focus();
			return false;
		};

		$scope.IsLoading = false;

		var selectedUserId = parentScope.selected[0].UserId
		var oldTemplateName = '';

		$scope.IsShowErrorMsg = false;
		$scope.IsShowSuccessMsg = false;
		$scope.ErrorMessage = '';
		$scope.TemplateModel = securityTemplateFactory.templateInitailValues();


		$scope.dialogPopup = {
			Header: '',
			Message: '',
			CallbackFunction: null,
			Show: function () {
				$('#popup-alert-dialog-bg').slideToggle();
			},
			OK: function () {
				$('#popup-alert-dialog-bg').slideToggle();
				$scope.dialogPopup.Header = '';
				$scope.dialogPopup.Message = '';

				if ($scope.dialogPopup.CallbackFunction) {
					$scope.dialogPopup.CallbackFunction();
					$scope.dialogPopup.CallbackFunction = null;
				}
			}
		}

		function transformTemplateChip(chip) {
			if (angular.isObject(chip)) {
				return chip;
			}
			return { name: chip, description: 'new' }
		}

		function querySecuritySearch(query) {
			var results = $filter('filter')($scope.SearchFormObject.TableItemList, {
				TemplateName: query
			}, false);

			return results;
		}

		$scope.selectedSecurityChipGroups = [];
		$scope.autocompleteSecurityMatch = true;
		$scope.selectedSecurityItem = null;
		$scope.searchSecurityText = null;
		$scope.querySecuritySearch = querySecuritySearch;
		$scope.transformTemplateChip = transformTemplateChip;
		$scope.SearchFormObject = {
			RequestModel: homeFactory.requestModelInstance(),
			TableItemList: []
		};

		$scope.searchTextChange = searchTextChange;
		$scope.selectedItemChange = selectedItemChange;

		function searchTextChange(text) {

		}

		function selectedItemChange(item) {

			if (item != undefined) {
				if (item['Database'] !== undefined) {
					$scope.selectedSecurityItem = item['TemplateName'];
					$scope.TemplateModel.Description = item['Description'];
					$scope.TemplateModel.DefaultSecurity = item['DefaultSecurity'];
				}
				else {
					$scope.selectedSecurityItem = item;
				}
			}
			else {
				$scope.searchSecurityText = '';
				//$scope.selectedSecurityItem = '';
				$scope.TemplateModel.Description = '';
				$scope.TemplateModel.DefaultSecurity = '';
			}
		}

		function getSecurityTemplateList() {
			$scope.SearchFormObject = {
				RequestModel: homeFactory.requestModelInstance(),
				TableItemList: []
			};
			$scope.SearchFormObject.RequestModel.libraryName = parentScope.vm.selectedLibrary;
			$scope.SearchFormObject.RequestModel.pagenumber = 1;

			var apiUrl = securityTemplateFactory.getAPIUrl('GETSECURITYTEMPLATES', $scope.SearchFormObject.RequestModel);
			parentScope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(apiUrl));
			var TemplateList = SecurityTemplateService.getTemplateList(apiUrl, parentScope.mc.loginModel.AuthKey);
			TemplateList.then(function (response) {
				if (response.data.data.length > 0 && response.data.total_count > 0) {
					parentScope.mc.getlogDetails("Debug", 'Response:Success');
					var UIModel;
					$scope.SearchFormObject.TableItemList = [];
					angular.forEach(response.data.data, function (item) {
						UIModel = securityTemplateFactory.getSTUI(item);
						$scope.SearchFormObject.TableItemList.push(UIModel);
						UIModel = null;
					});
				}
				else {
					parentScope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));

				}
				$scope.IsLoading = false;
			}, function (response) {
				parentScope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
				$scope.IsLoading = false;
			});
		}

		function getAssignedSecurityTemplateObject() {

			oldTemplateName = '';
			$scope.TemplateModel = securityTemplateFactory.templateInitailValues();
			$scope.selectedSecurityChipGroups = [];

			var apiUrl = securityTemplateFactory.getAPIUrl('GETSECURITYTEMPLATEOFUSER', null, selectedUserId);
			parentScope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(apiUrl));
			var dbReader = SecurityTemplateService.getUserTemplate(apiUrl, parentScope.mc.loginModel.AuthKey);
			dbReader.then(function (response) {
				parentScope.mc.getlogDetails("Debug", 'Response:Success');
				var UIModel = securityTemplateFactory.getSTUI(response.data.data[0]);
				oldTemplateName = UIModel.TemplateName;
				$scope.TemplateModel = UIModel;
				$scope.selectedSecurityItem = UIModel.TemplateName;
			}, function (response) {
				parentScope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
			}

			);
		}

		$scope.AssignTemplate = function () {
			$scope.IsPosting = false;
			if ($scope.selectedSecurityItem == '' || $scope.selectedSecurityItem == null || $scope.selectedSecurityItem == undefined) {
				if (oldTemplateName == '') {
					$scope.IsShowErrorMsg = true;
					$scope.ErrorMessage = "Please select security template.";
					return;
				}
			}
			$scope.IsPosting = true;
			var dbWriter = null;
			var taskName = '';
			var taskParam = '';
			var requestBody = {};
			requestBody[CONST_ST.Database] = $scope.vm.selectedLibrary;
			var apiUrl ="";
			if (oldTemplateName == '') {
			    taskName = 'SetUserSecurityTemplate';
			    taskParam = 'TemplateName=\"' + $scope.selectedSecurityItem + '\"';
				apiUrl =securityTemplateFactory.getAPIUrl('SETSECURITYTEMPLATEOFUSER', null,
						selectedUserId, oldTemplateName,
						$scope.selectedSecurityItem, parentScope.vm.selectedLibrary)
				dbWriter = SecurityTemplateService.SetSecurityTemplate(apiUrl, parentScope.mc.loginModel.AuthKey, requestBody);
			} else if ($scope.selectedSecurityItem == '' || $scope.selectedSecurityItem == null || $scope.selectedSecurityItem == undefined) {
			    taskName = 'DeleteUserSecurityTemplate';
			    taskParam = 'TemplateName=\"' + oldTemplateName + '\"';

				apiUrl =securityTemplateFactory.getAPIUrl('DELETESECURITYTEMPLATEOFUSER', null,
						selectedUserId, oldTemplateName,
						$scope.selectedSecurityItem, parentScope.vm.selectedLibrary)
				$scope.selectedSecurityItem = '';
				dbWriter = SecurityTemplateService.DeleteSecurityTemplate(apiUrl, parentScope.mc.loginModel.AuthKey, requestBody);
			} else {
			    taskName = 'UpdateUserSecurityTemplate';
			    taskParam = 'TemplateName=\"' + $scope.selectedSecurityItem + '\"';

				apiUrl=securityTemplateFactory.getAPIUrl('UPDATESECURITYTEMPLATEOFUSER', null,
						selectedUserId, oldTemplateName,
						$scope.selectedSecurityItem, parentScope.vm.selectedLibrary)
				requestBody[CONST_ST.TemplateName] = $scope.selectedSecurityItem;
				dbWriter = SecurityTemplateService.UpdateSecurityTemplate(apiUrl, parentScope.mc.loginModel.AuthKey, requestBody);
			}	        
			$scope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(apiUrl));
			dbWriter.then(function (response) {
				$scope.IsPosting = false;
				if (response && response.data && response.status == 200) {
					$scope.dialogPopup.CallbackFunction = function () {
						$mdDialog.hide();
					}
					$scope.mc.setSecurityLogDetails("Info", 'Success', selectedUserId, taskName, taskParam);
					$scope.dialogPopup.Header = 'Success';
					$scope.dialogPopup.Message = 'Security template successfully updated.';
					$scope.dialogPopup.Show();
					$timeout(function () {
						$scope.dialogPopup.OK();
					}, 2000);
				}
				else {
					$scope.ShowWarning = true;
					$scope.mc.setSecurityLogDetails("Info", 'Failure', selectedUserId, taskName, taskParam);
					if (response.data.Message && response.data.Message.trim().length > 0) {
						$scope.ErrorMessage = response.data.Message;
					}
					else {
						$scope.ErrorMessage = "Security template posting failed due to unknown errors.";
					}
				}

			}, function (response) {
			    $scope.mc.setSecurityLogDetails("Info", 'Failure', selectedUserId, taskName, taskParam);
				$scope.IsPosting = false;
				$scope.ShowWarning = true;
				$scope.ErrorMessage = "Security template posting failed due to unknown errors.";
			});
		}

		getSecurityTemplateList();
		getAssignedSecurityTemplateObject();
	}

	$scope.UserSearchTextChange = CustomUserSearchTextChange;

	function CustomUserSearchTextChange($event) {
		if ($event.keyCode === 13) {
			$event.preventDefault();
		}
	}

	function getAllGroupList() {
		$scope.AlreadySelectedUserGroupList = [];
		grequestModel.libraryName = $scope.vm.selectedLibrary;
		grequestModel.searchText = $scope.AddRemoveGroups.SearchText;

		if (!$scope.vm.selectedLibrary || $scope.vm.selectedLibrary.trim().length == 0)
			return;

		$scope.lastSelectedLibrary = $scope.vm.selectedLibrary;
		$scope.showSearchProgressInDialog = true;
		var deffered = $q.defer();
		var apiUrl = groupFactory.getAPIUrl('SEARCHGROUPS', grequestModel);
		$scope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(apiUrl));
		var Group = GroupService.getGroups(apiUrl, $scope.mc.loginModel.AuthKey);
		Group
				.then(
						function (response) {

							if (response["status"] == 200) {
								$scope.mc.getlogDetails("Debug", 'Response:Success');
								$scope.GroupDetails = [];
								$scope.GroupTablePagination.totalCount = response["data"]["total_count"];
								angular.forEach(response["data"]["data"], function (group) {
									$scope.GroupDetails.push(groupFactory.getGroupUI(group));
								});
								deffered.resolve($scope.GroupDetails);
								$scope.loading = false;
								var groupschecklist = [];
								angular.forEach($scope.GroupDetails,
										function (item) {
											groupschecklist
													.push(item.GroupName);
										});

								;

								var requestModelTemp = homeFactory.requestModelInstance();
								requestModelTemp.pagenumber = 1;
								requestModelTemp.pageLength = 200;
								requestModelTemp.libraryName = $scope.vm.selectedLibrary;
								requestModelTemp.searchText = $scope.AddRemoveGroups.SearchText;
								var apiUrl =groupFactory.getAPIUrl('GETGROUPFROMUSER', requestModelTemp, $scope.user.UserId, '', '')
								$scope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(apiUrl));

								var promiseOne = GroupService.GetGroupsOfUserFromGroups(apiUrl, $scope.mc.loginModel.AuthKey);
								promiseOne
									.then(
											function (response) {
												$scope.mc.getlogDetails("Debug", 'Response:Success');
												angular.forEach(response.data.Groups, function (groupTemp) {
													var groupUITempItem = groupFactory.getGroupViewUI(groupTemp);
													groupUITempItem.Checked = true;
													groupUITempItem.Selected = true;
													$scope.AlreadySelectedUserGroupList.push(groupUITempItem);
													$scope.GroupInUserList.push(groupUITempItem);
												});

												if ($scope.GroupCheckedFInal != null
														&& $scope.GroupCheckedFInal.length > 0) {
													angular
															.forEach(
																	$scope.GroupCheckedFInal,
																	function (
																			GroupCheckedModel) {
																		var filterGroupList = $filter(
																				'filter')
																				(
																						$scope.GroupDetails,
																						{
																							GroupName: GroupCheckedModel.GroupName
																						},
																						true);
																		if (typeof filterGroupList != 'undefined'
																				&& filterGroupList.length > 0) {
																			filterGroupList[0].Checked = true;
																		}
																	});
												}

												if ($scope.GroupInUserList != null
														&& $scope.GroupInUserList.length > 0) {
													angular
															.forEach(
																	$scope.GroupInUserList,
																	function (
																			GroupCheckedModel) {
																		var filterGroupList = $filter(
																				'filter')
																				(
																						$scope.GroupDetails,
																						{
																							GroupName: GroupCheckedModel.GroupName
																						},
																						true);
																		if (typeof filterGroupList != 'undefined'
																				&& filterGroupList.length > 0) {
																			filterGroupList[0].Checked = true;
																		}
																	});
												}

												if ($scope.GroupRemovedFInal != null
														&& $scope.GroupRemovedFInal.length > 0) {
													angular
															.forEach(
																	$scope.GroupRemovedFInal,
																	function (
																			GroupCheckedModel) {
																		var filterGroupList = $filter(
																				'filter')
																				(
																						$scope.GroupDetails,
																						{
																							GroupName: GroupCheckedModel.GroupName
																						},
																						true);
																		if (typeof filterGroupList != 'undefined'
																				&& filterGroupList.length > 0) {
																			filterGroupList[0].Checked = false;
																		}
																	});
												}

												if ($scope.CheckedGroupSelection) {
													var groupsCheckedList = [];
													var CheckedExternalList = [];
													if ($scope.External) {
														if ($scope.GroupCheckedFInal.length > 0) {
															angular
																	.forEach(
																			$scope.GroupCheckedFInal,
																			function (
																					item) {
																				if (item.GroupIsExternal)
																					CheckedExternalList
																							.push(item);
																			});
															var start = (grequestModel.pagenumber - 1)
																	* grequestModel.pageLength;
															for (i = start; i < (grequestModel.pageLength * grequestModel.pagenumber) ; i++) {
																if (CheckedExternalList[i] != undefined)
																	groupsCheckedList
																			.push(CheckedExternalList[i]);
															}
															$scope.GroupDetails = groupsCheckedList;
															$scope.GroupTablePagination.totalCount = CheckedExternalList.length;
														} else {
															$scope.GroupDetails = '';
														}
													} else {
														var start = (grequestModel.pagenumber - 1)
																* grequestModel.pageLength;
														for (i = start; i < (grequestModel.pageLength * grequestModel.pagenumber) ; i++) {
															if ($scope.GroupCheckedFInal[i] != undefined)
																groupsCheckedList
																		.push($scope.GroupCheckedFInal[i]);
														}
														$scope.GroupDetails = groupsCheckedList;
														$scope.GroupTablePagination.totalCount = $scope.GroupCheckedFInal.length;
													}
												}

											},
												function (response) {
													$scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
													$scope.showSearchProgressInDialog = false;
												});

							}
							else {
								$scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
							}
							$scope.showSearchProgressInDialog = false;
						}, function (response) {
							$scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
							$scope.showSearchProgressInDialog = false;
						});
		return deffered.promise;

	}

	$scope.onPaginateGroupList = function (page, limit) {
		grequestModel.pageLength = limit;
		grequestModel.pagenumber = page;
		//getAllGroupList();

		if (!$scope.CheckedGroupSelection) {
			getAllGroupList();
		}
		else {
			$scope.CheckedGroupSelectionChanged();
		}

	};

	$scope.AddSelectedGroup = function () {
		var deferredarray = [];
		$scope.ErrorMessage = '';
		angular.forEach($scope.GroupCheckedFInal, function (group) {
			var deferred = $q.defer();
		   

			var apiUrl=groupFactory.getAPIUrl('ADDUSERINGROUP', group.GroupName, $scope.user.UserId, $scope.vm.selectedLibrary, 'add');
			$scope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(apiUrl));

			$scope.posting = true;
			var promise = GroupService.AddUserToGroup(apiUrl, $scope.mc.loginModel.AuthKey);
			promise.then(function (response) {
				if (response) {

					deferred.resolve(response);
					
						 
					  if (response && response.details && response.details.message.trim().length > 0) {
						  $scope.ErrorMessage =  response.details.message;
						  $scope.mc.getlogDetails("Error", "Response:" + JSON.stringify(response));
						//$scope.mc.setSecurityLogDetails("Info", 'Success', $scope.user.UserId, 'add user to group', '');
					} else {
						
						$scope.ErrorMessage ='';
					    //$scope.mc.setSecurityLogDetails("Info", 'Response:Success,' + $scope.user.UserId + ' is member of ' + group.GroupName);
						$scope.mc.setSecurityLogDetails("Info", 'Success', $scope.user.UserId, 'add user to group', '');
					}
				}


			}, function (response) {
				$scope.mc.getlogDetails("Error", "Response:" + JSON.stringify(response));
				if (response && response.details && response.details.message.trim().length > 0) {
					  $scope.ErrorMessage =  response.details.message;
				   
				} else {
					
					$scope.ErrorMessage ='User action failed due to unknown errors';
					  
				}
				deferred.resolve(response);
				//$scope.posting = false;
			});

			deferredarray.push(deferred.promise);
		});

		angular.forEach($scope.GroupRemovedFInal, function (group) {
			var deferred = $q.defer();
			$scope.posting = true;
			var requestUrl = groupFactory.getAPIUrl('REMOVEUSERFROMGROUP', group.GroupName, $scope.user.UserId, $scope.vm.selectedLibrary, 'remove')
			$scope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(requestUrl));

			var promise = GroupService.RemoveUserFromGroup(requestUrl, $scope.mc.loginModel.AuthKey);
			promise.then(function (response) {
				if (response) {
					deferred.resolve(response);
					 
					  if (response && response.details && response.details.message.trim().length > 0) {
						  $scope.ErrorMessage =  response.details.message;
						  $scope.mc.getlogDetails("Error", "Response:" + JSON.stringify(response));
					} else {
						
						$scope.ErrorMessage ='';
					    //$scope.mc.setSecurityLogDetails("Info", 'Response:Success,' + $scope.user.UserId + ' removed from ' + group.GroupName);
						$scope.mc.setSecurityLogDetails("Info", 'Success', $scope.user.UserId, 'Remove Group In User', '');
					}
				}


			}, function (response) {
				$scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
				if (response && response.details && response.details.message.trim().length > 0) {
					  $scope.ErrorMessage =  response.details.message;
				   
				} else {
					
					$scope.ErrorMessage ='User action failed due to unknown errors';
					  
				}
				deferred.resolve(response);
			});
			deferredarray.push(deferred.promise);
		});

		$q.all(deferredarray).then(function () {
			if ($scope.ErrorMessage == "") {

				$scope.showValidation = false;
				$mdDialog.hide();
				$scope.ShowWarning = false;
				$scope.posting = false;
			} else {
				$scope.posting = false;
				$scope.ShowWarning = true;
				alert($scope.ErrorMessage);
			}
		});
	};

	$scope.ClearUserClick = function () {
		if ($scope.AddRemoveGroups.GroupSearchTimeout)
			$timeout.cancel($scope.AddRemoveGroups.GroupSearchTimeout);

		$scope.AddRemoveGroups.SearchText = '';
		$scope.GroupTablePagination.page = 1;
		grequestModel.pagenumber = 1;

		if (!$scope.CheckedGroupSelection) {
			getAllGroupList();
		}
		else {
			$scope.CheckedGroupSelectionChanged();
		}
	};

	$scope.onGroupSearch = function () {
		if ($scope.AddRemoveGroups.GroupSearchTimeout)
			$timeout.cancel($scope.AddRemoveGroups.GroupSearchTimeout);

		$scope.GroupTablePagination.page = 1;
		grequestModel.pagenumber = 1;

		if (!$scope.CheckedGroupSelection) {
			getAllGroupList();
		}
		else {
			$scope.CheckedGroupSelectionChanged();
		}
	};

	$scope.SelectAll = function () {
		angular.forEach($scope.GroupDetails, function (GroupModel) {

			var isDisabled = false;
			var filterGroupList = $filter('filter')($scope.GroupInUserList, {
				GroupName: GroupModel.GroupName
			}, true);
			if (typeof filterGroupList != 'undefined'
					&& filterGroupList.length > 0) {
				isDisabled = true;
			}

			GroupModel.Checked = $scope.SelAll.checked;

			if (isDisabled) {

				if (GroupModel.Checked) {
					$scope.GroupRemovedFInal = $.grep($scope.GroupRemovedFInal,
							function (item, index) {
								return item.GroupName != GroupModel.GroupName;
							});

				} else {
					var filterUserListpush = $filter('filter')(
							$scope.GroupRemovedFInal, {
								GroupName: GroupModel.GroupName
							}, true);
					if (typeof filterUserListpush == 'undefined'
							|| filterUserListpush.length == 0) {
						$scope.GroupRemovedFInal.push(GroupModel);
					}

				}

			} else {
				if (GroupModel.Checked) {
					var filterUserListpush = $filter('filter')(
							$scope.GroupCheckedFInal, {
								GroupName: GroupModel.GroupName
							}, true);
					if (typeof filterUserListpush == 'undefined'
							|| filterUserListpush.length == 0) {
						$scope.GroupCheckedFInal.push(GroupModel);
					}
				} else {

					$scope.GroupCheckedFInal = $.grep($scope.GroupCheckedFInal,
							function (item, index) {
								return item.GroupName != GroupModel.GroupName;
							});

				}
			}

		});
		var promise = getTotalSelectedGroupCount();
		promise.then(function (groupCount) {
			if (groupCount > 0) {
				$scope.Title = groupCount.toString() + ' group(s) selected.';
			}
			else {
				$scope.Title = $scope.user.UserId + ' is not a member of any groups.';
			}
		}, function (reason) {
			$scope.Title = $scope.user.UserId + ' is not a member of any groups.';
		});
	}

	$scope.ExternalChanged = function () {
		grequestModel.pagenumber = 1;
		$scope.GroupTablePagination.page = 1;

		if ($scope.External) {
			var filterItem = {
				'FilterKey': 'GroupIsExternal',
				'FilterValues': ['Y']
			};
			grequestModel.filters.push(filterItem);
		} else {
			angular.forEach(grequestModel.filters, function (reqModel) {
				if (reqModel.FilterKey == 'GroupIsExternal') {
					grequestModel.filters.pop(reqModel);
				}
			});
		}
		getAllGroupList();

	};

	$scope.CheckedGroupSelectionChanged = function () {
		if (!$scope.vm.selectedLibrary || $scope.vm.selectedLibrary.trim().length == 0)
			return;

		var selectedGroupListTemp = [];
		$scope.GroupDetails = [];

		if ($scope.AlreadySelectedUserGroupList.length == 0) {
			$scope.GroupTablePagination.page = 1;//limit
			grequestModel.pagenumber = 1;

			var requestModelTemp = homeFactory.requestModelInstance();
			requestModelTemp.pagenumber = 1;
			requestModelTemp.pageLength = 200;
			requestModelTemp.libraryName = $scope.vm.selectedLibrary;
			requestModelTemp.searchText = $scope.AddRemoveGroups.SearchText;

			var apiUrl = groupFactory.getAPIUrl('GETGROUPFROMUSER', requestModelTemp, $scope.user.UserId, '', '');
			$scope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(apiUrl));

			var groupListPromise = GroupService.GetGroupsOfUserFromGroups(apiUrl, $scope.mc.loginModel.AuthKey);

			groupListPromise.then(function (response) {
				if (response.status == 200 && response.data && response.data.Groups) {
					$scope.mc.getlogDetails("Debug", 'Response:Success');
					angular.forEach(response.data.Groups, function (groupTemp) {
						var groupUITempItem = groupFactory.getGroupViewUI(groupTemp);
						groupUITempItem.Checked = true;
						groupUITempItem.Selected = true;
						$scope.AlreadySelectedUserGroupList.push(groupUITempItem);
					});
					selectedGroupListTemp = angular.copy($scope.AlreadySelectedUserGroupList);

					if ($scope.AddRemoveGroups.SearchText.trim().length > 0)
						selectedGroupListTemp = $filter('filter')(selectedGroupListTemp, { GroupName: $scope.AddRemoveGroups.SearchText }, false);

					angular.forEach($scope.GroupRemovedFInal, function (removeGroupTemp) {
						selectedGroupListTemp = $.grep(selectedGroupListTemp,
							function (item, index) {
								return item.GroupName != removeGroupTemp.GroupName;
							});
					});

					angular.forEach($scope.GroupCheckedFInal, function (seletcedGroupTemp) {

						var tempGroupViewUIModel = groupFactory.groupViewUIInitialValueSettings();
						tempGroupViewUIModel.GroupName = seletcedGroupTemp.GroupName;
						tempGroupViewUIModel.GroupFullName = seletcedGroupTemp.GroupFullName;
						tempGroupViewUIModel.GroupEnabled = seletcedGroupTemp.GroupEnabled;
						tempGroupViewUIModel.GroupIsExternal = seletcedGroupTemp.GroupIsExternal;
						tempGroupViewUIModel.GroupNOS = seletcedGroupTemp.GroupNOS;
						tempGroupViewUIModel.GroupNum = seletcedGroupTemp.GroupNum;
						tempGroupViewUIModel.Checked = true;
						tempGroupViewUIModel.Selected = true;

						selectedGroupListTemp.push(tempGroupViewUIModel);
						tempGroupViewUIModel = null;
					});
					selectedGroupListTemp = $filter('orderBy')(selectedGroupListTemp, 'GroupName', false);
					$scope.GroupTablePagination.totalCount = selectedGroupListTemp.length;

					var endIndex = grequestModel.pageLength <= selectedGroupListTemp.length ? grequestModel.pageLength : selectedGroupListTemp.length;
					$scope.GroupDetails = [];
					for (intCount = 0; intCount < endIndex; intCount++) {
						$scope.GroupDetails.push(selectedGroupListTemp[intCount]);
					}
					// $scope.GroupTablePagination.totalCount = $scope.GroupDetails.length;
				}
				else {
					$scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
				}
			},function(response){
				$scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
			})
		}
		else {
			selectedGroupListTemp = angular.copy($scope.AlreadySelectedUserGroupList);

			if ($scope.AddRemoveGroups.SearchText.trim().length > 0)
				selectedGroupListTemp = $filter('filter')(selectedGroupListTemp, { GroupName: $scope.AddRemoveGroups.SearchText }, false);

			angular.forEach($scope.GroupRemovedFInal, function (removeGroupTemp) {
				selectedGroupListTemp = $.grep(selectedGroupListTemp,
					function (item, index) {
						return item.GroupName != removeGroupTemp.GroupName;
					});
			});

			angular.forEach($scope.GroupCheckedFInal, function (seletcedGroupTemp) {

				var tempGroupViewUIModel = groupFactory.groupViewUIInitialValueSettings();
				tempGroupViewUIModel.GroupName = seletcedGroupTemp.GroupName;
				tempGroupViewUIModel.GroupFullName = seletcedGroupTemp.GroupFullName;
				tempGroupViewUIModel.GroupEnabled = seletcedGroupTemp.GroupEnabled;
				tempGroupViewUIModel.GroupIsExternal = seletcedGroupTemp.GroupIsExternal;
				tempGroupViewUIModel.GroupNOS = seletcedGroupTemp.GroupNOS;
				tempGroupViewUIModel.GroupNum = seletcedGroupTemp.GroupNum;
				tempGroupViewUIModel.Checked = true;
				tempGroupViewUIModel.Selected = true;

				selectedGroupListTemp.push(tempGroupViewUIModel);
				tempGroupViewUIModel = null;
			});
			selectedGroupListTemp = $filter('orderBy')(selectedGroupListTemp, 'GroupName', false);
			$scope.GroupTablePagination.totalCount = selectedGroupListTemp.length;

			var startIndex = (grequestModel.pagenumber - 1) * grequestModel.pageLength;
			var endIndex = grequestModel.pageLength * grequestModel.pagenumber;

			endIndex = endIndex <= selectedGroupListTemp.length ? endIndex : selectedGroupListTemp.length
			$scope.GroupDetails = [];
			for (intCount = startIndex; intCount < endIndex; intCount++) {
				$scope.GroupDetails.push(selectedGroupListTemp[intCount]);
			}

		}
	}

	function getTotalSelectedGroupCount() {

		var deffered = $q.defer();

		var totalGroupCount = 0;
		var selectedGroupListTemp = [];

		if ($scope.AlreadySelectedUserGroupList.length == 0) {
			$scope.GroupTablePagination.page = 1;//limit
			grequestModel.pagenumber = 1;

			var requestModelTemp = homeFactory.requestModelInstance();
			requestModelTemp.pagenumber = 1;
			requestModelTemp.pageLength = 200;
			requestModelTemp.libraryName = $scope.vm.selectedLibrary;
			requestModelTemp.searchText = $scope.AddRemoveGroups.SearchText;

			var apiUrl = groupFactory.getAPIUrl('GETGROUPFROMUSER', requestModelTemp, $scope.user.UserId, '', '');

			$scope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(apiUrl));
			var groupListPromise = GroupService.GetGroupsOfUserFromGroups(apiUrl, $scope.mc.loginModel.AuthKey);

			groupListPromise.then(function (response) {
				if (response.status == 200 && response.data && response.data.Groups) {
					$scope.mc.getlogDetails("Debug", 'Response:Success');
					angular.forEach(response.data.Groups, function (groupTemp) {
						var groupUITempItem = groupFactory.getGroupViewUI(groupTemp);
						groupUITempItem.Checked = true;
						$scope.AlreadySelectedUserGroupList.push(groupUITempItem);
					});
					selectedGroupListTemp = angular.copy($scope.AlreadySelectedUserGroupList);

					angular.forEach($scope.GroupRemovedFInal, function (removeGroupTemp) {
						selectedGroupListTemp = $.grep(selectedGroupListTemp,
							function (item, index) {
								return item.GroupName != removeGroupTemp.GroupName;
							});
					});

					angular.forEach($scope.GroupCheckedFInal, function (seletcedGroupTemp) {

						var tempGroupViewUIModel = groupFactory.groupViewUIInitialValueSettings();
						tempGroupViewUIModel.GroupName = seletcedGroupTemp.GroupName;
						tempGroupViewUIModel.GroupFullName = seletcedGroupTemp.GroupFullName;
						tempGroupViewUIModel.GroupEnabled = seletcedGroupTemp.GroupEnabled;
						tempGroupViewUIModel.GroupIsExternal = seletcedGroupTemp.GroupIsExternal;
						tempGroupViewUIModel.GroupNOS = seletcedGroupTemp.GroupNOS;
						tempGroupViewUIModel.GroupNum = seletcedGroupTemp.GroupNum;
						tempGroupViewUIModel.Checked = true;

						selectedGroupListTemp.push(tempGroupViewUIModel);
						tempGroupViewUIModel = null;
					});

					totalGroupCount = selectedGroupListTemp.length;
					deffered.resolve(totalGroupCount);
				}
				else {
					$scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
				}
			}, function (response) {
				$scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
			})
		}
		else {
			selectedGroupListTemp = angular.copy($scope.AlreadySelectedUserGroupList);

			if ($scope.AddRemoveGroups.SearchText.trim().length > 0)
				selectedGroupListTemp = $filter('filter')(selectedGroupListTemp, { GroupName: $scope.AddRemoveGroups.SearchText }, false);

			angular.forEach($scope.GroupRemovedFInal, function (removeGroupTemp) {
				selectedGroupListTemp = $.grep(selectedGroupListTemp,
					function (item, index) {
						return item.GroupName != removeGroupTemp.GroupName;
					});
			});

			angular.forEach($scope.GroupCheckedFInal, function (seletcedGroupTemp) {

				var tempGroupViewUIModel = groupFactory.groupViewUIInitialValueSettings();
				tempGroupViewUIModel.GroupName = seletcedGroupTemp.GroupName;
				tempGroupViewUIModel.GroupFullName = seletcedGroupTemp.GroupFullName;
				tempGroupViewUIModel.GroupEnabled = seletcedGroupTemp.GroupEnabled;
				tempGroupViewUIModel.GroupIsExternal = seletcedGroupTemp.GroupIsExternal;
				tempGroupViewUIModel.GroupNOS = seletcedGroupTemp.GroupNOS;
				tempGroupViewUIModel.GroupNum = seletcedGroupTemp.GroupNum;
				tempGroupViewUIModel.Checked = true;

				selectedGroupListTemp.push(tempGroupViewUIModel);
				tempGroupViewUIModel = null;
			});
			totalGroupCount = selectedGroupListTemp.length;
			deffered.resolve(totalGroupCount);
		}
		return deffered.promise;
	}

	$scope.SelectCurrentGroup = function (GroupModel, $event) {
		$scope.GroupSelected(GroupModel, $event)
	};

	$scope.getAllSelectedGroups = function (GroupModel) {

		var selectedGroupList = $filter('filter')($scope.GroupDetails, {
			Selected: true
		});
		angular.forEach(selectedGroupList, function (tempItemModel) {
			tempItemModel.Selected = false;
		});
		GroupModel.Selected = true;
	};
	
	$scope.GroupSelected = function (GroupModel, $event) {
		var isDisabled = false;

		$scope.GroupInUserList = angular.copy($scope.AlreadySelectedUserGroupList);

		var filterGroupList = $filter('filter')($scope.GroupInUserList, {
			GroupName: GroupModel.GroupName
		}, true);
		if (typeof filterGroupList != 'undefined' && filterGroupList.length > 0) {
			isDisabled = true;
		}

		if (isDisabled) {

			if (GroupModel.Checked) {
				$scope.GroupRemovedFInal = $.grep($scope.GroupRemovedFInal,
						function (item, index) {
							return item.GroupName != GroupModel.GroupName;
						});

			} else {
				var filterUserListpush = $filter('filter')(
						$scope.GroupRemovedFInal, {
							GroupName: GroupModel.GroupName
						}, true);
				if (typeof filterUserListpush == 'undefined'
						|| filterUserListpush.length == 0) {
					$scope.GroupRemovedFInal.push(GroupModel);
				}

			}

		} else {


			if (GroupModel.Checked) {
				var filterUserListpush = $filter('filter')(
						$scope.GroupCheckedFInal, {
							GroupName: GroupModel.GroupName
						}, true);
				if (typeof filterUserListpush == 'undefined'
						|| filterUserListpush.length == 0) {
					$scope.GroupCheckedFInal.push(GroupModel);
				}
			} else {

				$scope.GroupCheckedFInal = $.grep($scope.GroupCheckedFInal,
						function (item, index) {
							return item.GroupName != GroupModel.GroupName;
						});

			}
		}

		var promise = getTotalSelectedGroupCount();
		promise.then(function (groupCount) {
			if (groupCount > 0) {
				$scope.Title = groupCount.toString() + ' group(s) selected';
			}
			else {
				$scope.Title = $scope.user.UserId + ' is not a member of any groups';
			}
		}, function (reason) {
			$scope.Title = $scope.user.UserId + ' is not a member of any groups';
		});
	};

	$scope.getAllCheckedGroups = function (GroupModel) {
		GroupModel.Checked = !GroupModel.Checked;
	};
	
	$scope.$watch(function () {
		return $scope.AddRemoveGroups.SearchText;
	}, function (val) {
		if ($scope.AddRemoveGroups.SearchText.length > 0) {
			$scope.AddRemoveGroups.IsSearchTextFound = true;
		}
		if ($scope.AddRemoveGroups.GroupSearchTimeout)
			$timeout.cancel($scope.AddRemoveGroups.GroupSearchTimeout);

		$scope.AddRemoveGroups.GroupSearchTimeout = $timeout(function () {
			if ($scope.AddRemoveGroups.IsSearchTextFound) {
				$scope.GroupTablePagination.page = 1;
				grequestModel.pagenumber = 1;

				if (!$scope.CheckedGroupSelection) {
					getAllGroupList();
				}
				else {
					$scope.CheckedGroupSelectionChanged();
				}
			}
		}, 2000);
	}, true);

	
	var userGroupListReqModel = homeFactory.requestModelInstance();
	var totalUserGroupCount = 0;
	var isSetGroupListHeaderText = false;
	var userGroupListSearchTimeOut = null;
	var isUserGroupListSearchTextDirty = false;
	var isUserGroupListInstantSearch = false;
	var SelectedUserGroupListForFilter = [];
	var LastAddedSelectedItemUserGroupId = [];
	var lastAppendUserGroupItemCount = 0;

	$scope.ViewUserModel = userFactory.userInitailValues();
	$scope.scrollTop = 0;
	$scope.UserSecurityTemplateName = '';
	$scope.GroupListHeaderText = '';
	$scope.IsViewUserGroupListErrorMsg = false;
	$scope.UserGroupListErrorMsg = '';
	$scope.userGroupsList = [];
	$scope.selectedGroups = [];
	$scope.NewAddUserGroupList = [];
	$scope.RemovedUserGroupList = [];
	$scope.RemovedUserGroupModelList = [];
	$scope.SelectedUserIndexList = [];
	
	$scope.UserGroupList = {
		SearchText: ''
	};

	$scope.userViewMenuList = [
			{
				Label: 'Remove From Groups',
				Icon: 'icon-delete',
				onClick: $scope.ContextMenuFunctions.RemoveGroupInView,
				Enable: true,
				IconType: 'font-icon'
			}];

	$scope.selectedSecurityTemplateItem = {
		DisplayValue: ''
	};
	$scope.PageEvents.ViewSelected = function (selectedRow, $event) {
		if (!$event.ctrlKey) {
			$scope.selected = [];
			$scope.SelectedUserIndexList = [];

			$scope.SelectedUserIndexList.push($scope.UserList.indexOf(selectedRow));

			$scope.scrollTop = $(window).scrollTop();
			$scope.ViewUserModel = userFactory.userInitailValues();
			$scope.user = userFactory.userInitailValues();
			$scope.NewAddUserGroupList = [];
			$scope.RemovedUserGroupList = [];
			$scope.RemovedUserGroupModelList = [];
			$scope.originaluser = userFactory.userInitailValues();
			$scope.selectedSecurityItem = null;
			$scope.selectedSecurityTemplateItem.DisplayValue = '';
			$scope.UserSecurityTemplateName = null;
			GetSecurityTemplates();
			$scope.IsPosting = false;
			
			$rootScope.checkReadyToChangeState = function () {
				return $q(function (resolve, reject) {
					if (!isUserEdited()) {
						resolve({ Status: 0 });
						return;
					}
					var confirm = $mdDialog.confirm()
							.title('Warning!')
							.theme('confirm-dialog')
							.textContent('Do you want to save the changes?')
							.ariaLabel('Warning!').ok('Yes').cancel('No');

					$mdDialog.show(confirm).then(function () {
						var userSavePromise = saveUserDetail();
						userSavePromise.then(function (response) {
							if (response && response.Status === 0 && response.ErrorMessage.length === 0) {
								resolve({ Status: 0 });
							}
							else if (response && response.ErrorMessage) {
								$mdDialog.show($mdDialog.alert()
											.parent(angular.element(document.body))
											.clickOutsideToClose(true)
											.title('Warning!')
											.textContent(response.ErrorMessage)
											.ariaLabel('Warning!')
											.ok('OK')
										);
								resolve({ Status: -1 });
							}

						});
					}, function () {
						resolve({ Status: 0 });
					});
				});
			};

			if (typeof selectedRow !== 'undefined' && selectedRow != null) {
				getDatabaseByUser(selectedRow.UserId, selectedRow.Password);
				$scope.mc.getlogDetails("Debug", 'Method:GET; Action: ViewSelected ;User Id:' + selectedRow.UserId);
				var promise = userFactory.getSingleUser('GETUSER', $scope.vm.selectedLibrary, selectedRow.UserId, $scope.mc.loginModel.AuthKey);
				promise.then(function (response) {
					if (response) {
						$scope.mc.getlogDetails("Debug", 'Response:Success');
						$scope.ViewUserModel = userFactory.getUserUI(response.data[0]);
						if ($scope.ViewUserModel.Email === null || $scope.ViewUserModel.Email === undefined) {
							$scope.ViewUserModel.Email = '';
						}
						$scope.user = $scope.ViewUserModel;// angular.copy($scope.ViewUserModel);
						angular.copy($scope.user, $scope.originaluser);

						$scope.initializeUserGroupList();
						$scope.showSelectedUserDetails = true;
						$('.view-details-tab-container md-tabs-content-wrapper').removeClass('fix-title');
					}
				}, function (response) {
					$scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
				});
			}

			$scope.selectedSecurityItem = '';
			$scope.UserSecurityTemplateName = '';
			var requestUrl = securityTemplateFactory.getAPIUrl('GETSECURITYTEMPLATEOFUSER', null, selectedRow.UserId);
			$scope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(requestUrl));

			var dbReader = SecurityTemplateService.getUserTemplate(requestUrl, $scope.mc.loginModel.AuthKey);
			dbReader.then(function (response) {
				if (response && response.data && response.data.data && response.data.data.length > 0) {
					$scope.mc.getlogDetails("Debug", 'Response:Success');
					var UIModel = securityTemplateFactory.getSTUI(response.data.data[0]);
					$scope.UserSecurityTemplateName = UIModel.TemplateName;
					$scope.selectedSecurityTemplateItem.DisplayValue = UIModel.TemplateName;
					$scope.selectedSecurityItem = UIModel.TemplateName;
				}
				else {
					$scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
				}
			},
			function(response){
				$scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
			})

			$timeout(function () {
				$(window).scrollTop(0);
			});
		}
	};

	$scope.initializeUserGroupList = function () {
		$scope.GroupListHeaderText = 'Group Membership';
		$scope.IsViewUserGroupListErrorMsg = true;
		isSetGroupListHeaderText = true;
		$scope.UserGroupListErrorMsg = 'User is not a part of any group.';
		$scope.UserGroupList.SearchText = '';
		userGroupListReqModel = homeFactory.requestModelInstance();
		userGroupListReqModel.pagenumber = 0;
		totalUserGroupCount = 0;
		$scope.userGroupsList = [];
		$scope.selectedGroups = [];
		SelectedUserGroupListForFilter = [];
		LastAddedSelectedItemUserGroupId = [];
		lastAppendUserGroupItemCount = 0;
		userGroupListSearchTimeOut = null;
		isUserGroupListSearchTextDirty = false;
		isUserGroupListInstantSearch = false;

		addNewAddedToGrid();
		fillUserGroupGrid();
	};
	
	$scope.viewSelectedGroupsOnlyLabel='View selected'
	$scope.ShowOnlySelectedGroups = function() {
		$scope.viewSelectedGroupsOnlyLabel = $scope.viewSelectedGroupsOnlyLabel == 'View selected' ? 'Show all'
				: 'View selected';

	}

	$scope.filterSelectedGroups = function(selected, field) {
		return function(selectedGroups) {
			if ($scope.viewSelectedGroupsOnlyLabel == 'Show all') {
				if (selected.length == 0) {
					$scope.viewSelectedGroupsOnlyLabel = 'View selected';
				}
				var items = $filter('filter')(selected, selectedGroups, true);
				if (items.length > 0)
					return true;

				return false;
			} else {
				return true;
			}
		}
	};

	function getUserGroupList() {
		return $q(function (resolve, reject) {
			userGroupListReqModel.libraryName = $scope.vm.selectedLibrary;
			userGroupListReqModel.searchText = $scope.UserGroupList.SearchText;

			var apiUrl = userFactory.getUserGroupsAPI(userGroupListReqModel, $scope.user.UserId);
			$scope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(apiUrl));
			var promise = UserService.getUsers(apiUrl, $scope.mc.loginModel.AuthKey);
			promise.then(function (response) {
				if (response.status === 200) {
					$scope.mc.getlogDetails("Debug", 'Response:Success');
					var groupUIModel;
					var filterListTempIndex = -1;
					var totalGroupCount = response.data.total_count;
					var groupList = [];

					angular.forEach(response.data.data, function (groupItem) {
						groupUIModel = groupFactory.getGroupUI(groupItem);
						filterListTempIndex = $scope.RemovedUserGroupList.indexOf(groupUIModel.GroupName);
						if (filterListTempIndex === -1) {
							groupList.push(groupUIModel);
						}
						filterListTempIndex = -1;
						groupUIModel = null;
					});
					resolve({ Status: 1, GroupList: groupList, TotalGroupCount: totalGroupCount });
				}
				else {
					resolve({ Status: -1 });
					$scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
				}
			});
		});
	}

	function fillUserGroupGrid() {
		var promise = getUserGroupList();
		promise.then(function (response) {
			if (response.Status === 1) {
				totalUserGroupCount = response.TotalGroupCount;

				if (lastAppendUserGroupItemCount > 0) {
					$scope.userGroupsList.splice($scope.userGroupsList.length - lastAppendUserGroupItemCount, lastAppendUserGroupItemCount);
					$scope.selectedGroups.splice($scope.selectedGroups.length - lastAppendUserGroupItemCount, lastAppendUserGroupItemCount);
				}
				if (isSetGroupListHeaderText && ((totalUserGroupCount - $scope.RemovedUserGroupList.length) + $scope.NewAddUserGroupList.length) > 0) {
					$scope.GroupListHeaderText = $scope.user.UserId + ' is member of ' +
						((totalUserGroupCount - $scope.RemovedUserGroupList.length) + $scope.NewAddUserGroupList.length).toString() + ' Groups';
					$scope.IsViewUserGroupListErrorMsg = false;
					isSetGroupListHeaderText = false;
				}
				
				var tempListFilter = [];
				var filterTempModel;

				angular.forEach(response.GroupList, function (groupItem) {
					tempListFilter = $filter('filter')(SelectedUserGroupListForFilter, {
						GroupName: groupItem.GroupName
					}, true);
					if (tempListFilter.length === 0) {
						$scope.userGroupsList.push(groupItem);
					}
					else {
						LastAddedSelectedItemUserGroupId = $.grep(LastAddedSelectedItemUserGroupId,
							   function (item, index) {
								   return item.GroupName != groupItem.GroupName;
							   });

						filterTempModel = angular.copy(tempListFilter[0]);
						$scope.userGroupsList.push(filterTempModel);
						$scope.selectedGroups.push(filterTempModel);
						filterTempModel = null;
					}
					tempListFilter = [];
				});
				if ($scope.userGroupsList.length <= 25 && (userGroupListReqModel.pagenumber + userGroupListReqModel.pageLength) < totalUserGroupCount) {
					userGroupListReqModel.pagenumber += userGroupListReqModel.pageLength;
					fillUserGroupGrid();
				}
				lastAppendUserGroupItemCount = 0;
				if ($scope.UserGroupList.SearchText.length === 0) {
					angular.forEach(LastAddedSelectedItemUserGroupId, function (group) {
						filterTempModel = angular.copy(group);
						$scope.userGroupsList.push(filterTempModel);
						$scope.selectedGroups.push(filterTempModel);

						filterTempModel = null;
						lastAppendUserGroupItemCount += 1;
					});
				}
				if ($scope.UserGroupList.SearchText.length > 0 && $scope.userGroupsList.length === 0) {
					$scope.IsViewUserGroupListErrorMsg = true;
					$scope.UserGroupListErrorMsg = 'Groups not found, based on search.';
				}
				response.GroupList = [];
			}
		});
	}

	function addNewAddedToGrid() {
		var filterTempList = [];
		var filterSelectedList = [];
		var tempListFilter = [];
		var filterTempModel = null;

		if ($scope.NewAddUserGroupList.length === 0) return;

		if ($scope.UserGroupList.SearchText.length === 0) {
			angular.forEach($scope.NewAddUserGroupList, function (groupItem) {

				tempListFilter = $filter('filter')(SelectedUserGroupListForFilter, {
					GroupName: groupItem.GroupName
				}, true);
				if (tempListFilter.length === 0) {
					$scope.userGroupsList.push(groupItem);
				}
				else {
					filterTempModel = angular.copy(tempListFilter[0]);
					$scope.userGroupsList.push(filterTempModel);
					$scope.selectedGroups.push(filterTempModel);
					filterTempModel = null;
				}
				tempListFilter = [];
			});
		}
		else {
			filterTempList = $filter('filter')($scope.NewAddUserGroupList, {
				GroupName: $scope.UserGroupList.SearchText
			}, false);
			angular.forEach(filterTempList, function (groupItem) {
				tempListFilter = $filter('filter')(SelectedUserGroupListForFilter, {
					GroupName: groupItem.GroupName
				}, true);
				if (tempListFilter.length === 0) {
					$scope.userGroupsList.push(groupItem);
				}
				else {
					filterTempModel = angular.copy(tempListFilter[0]);
					$scope.userGroupsList.push(filterTempModel);
					$scope.selectedGroups.push(filterTempModel);
					filterTempModel = null;
				}
				tempListFilter = [];
			});

			filterTempList = [];
		}
	}

	$scope.ShowOnlySelectedGroupList = function () {
		$scope.PageEvents.ShowOnlySelected();
	};

	$scope.UserGroupList_SearchClick = function () {
		if (userGroupListSearchTimeOut) $timeout.cancel(userGroupListSearchTimeOut);
		$scope.IsViewUserGroupListErrorMsg = false;
		lastAppendUserGroupItemCount = 0;
		LastAddedSelectedItemUserGroupId = angular.copy(SelectedUserGroupListForFilter);
		userGroupListReqModel = homeFactory.requestModelInstance();
		userGroupListReqModel.pagenumber = 0;
		totalUserGroupCount = 0;
		$scope.userGroupsList = [];
		$scope.selectedGroups = [];

		addNewAddedToGrid();
		fillUserGroupGrid();
	};

	$scope.UserGroupList_ClearSearchClick = function () {
		isUserGroupListInstantSearch = true;
		$scope.UserGroupList.SearchText = '';
	};

	$scope.$watch(function () { return $scope.UserGroupList.SearchText; }, function (val) {
		if ($scope.UserGroupList.SearchText.length > 0) {
			isUserGroupListSearchTextDirty = true;
		}
		if (userGroupListSearchTimeOut) $timeout.cancel(userGroupListSearchTimeOut);

		if (isUserGroupListInstantSearch) {
			isUserGroupListInstantSearch = false;
			$scope.UserGroupList_SearchClick();
		}
		else {
			userGroupListSearchTimeOut = $timeout(function () {
				if (isUserGroupListSearchTextDirty) {
					$scope.UserGroupList_SearchClick();
				}
			}, 2000);
		}
	}, true);

	$scope.UserGroupRemove = function () {
		var confirm = $mdDialog.confirm()
						.title('Warning!')
						.theme('confirm-dialog')
						.textContent('Are you sure you want to remove the selected Group(s)?')
						.ariaLabel('')
						.ok('Yes')
						.cancel('No');
		$mdDialog.show(confirm).then(function () {

			var tempList = angular.copy($scope.selectedGroups);
			var filterTempList = [];
			angular.forEach(tempList, function (group) {
				filterTempList = $filter('filter')($scope.NewAddUserGroupList, {
					GroupName: group.GroupName
				}, true);
				if (filterTempList.length > 0) {
					$scope.NewAddUserGroupList = $.grep($scope.NewAddUserGroupList,
										function (item, index) {
											return item.GroupName != group.GroupName;
										});
				}
				else {
				    $scope.RemovedUserGroupList.push(group.GroupName);
				    $scope.RemovedUserGroupModelList.push(angular.copy(group));
				}
				$scope.selectedGroups = $.grep($scope.selectedGroups,
										function (item, index) {
											return item.GroupName != group.GroupName;
										});

				$scope.userGroupsList = $.grep($scope.userGroupsList,
										function (item, index) {
											return item.GroupName != group.GroupName;
										});
				SelectedUserGroupListForFilter = $.grep(SelectedUserGroupListForFilter,
										function (item, index) {
											return item.GroupName != group.GroupName;
										});
				LastAddedSelectedItemUserGroupId = $.grep(LastAddedSelectedItemUserGroupId,
										function (item, index) {
											return item.GroupName != group.GroupName;
										});
				lastAppendUserGroupItemCount = 0;
				filterTempList = [];
			});
			tempList = [];
			$scope.selectedGroups = [];
			if ($scope.userGroupsList.length === 0) {
				$scope.initializeUserGroupList();
			}
			else {
				if (((totalUserGroupCount - $scope.RemovedUserGroupList.length) + $scope.NewAddUserGroupList.length) > 0) {
					$scope.GroupListHeaderText = $scope.ViewUserModel.UserId + ' is member of ' +
						   ((totalUserGroupCount - $scope.RemovedUserGroupList.length) + $scope.NewAddUserGroupList.length).toString() + ' Groups';
				}
				else {
					$scope.GroupListHeaderText = 'Group Membership';
					$scope.IsViewUserGroupListErrorMsg = true;
					$scope.UserGroupListErrorMsg = 'User is not a part of any group.';
				}
			}
		});
	};

	$scope.onUserGroupSelect = function (groupModel) {
		var tempListFilter = $filter('filter')(SelectedUserGroupListForFilter, {
			GroupName: groupModel.GroupName
		}, true);
		if (tempListFilter.length === 0) {
			SelectedUserGroupListForFilter.push(angular.copy(groupModel));
		}
		tempListFilter = [];
	};

	$scope.onUserGroupDeselect = function (groupModel) {
		if (SelectedUserGroupListForFilter.length > 0) {
			SelectedUserGroupListForFilter = $.grep(SelectedUserGroupListForFilter,
										function (item, index) {
											return item.GroupName != groupModel.GroupName;
										});
		}
		if (LastAddedSelectedItemUserGroupId.length > 0) {
			LastAddedSelectedItemUserGroupId = $.grep(LastAddedSelectedItemUserGroupId,
										function (item, index) {
											return item.GroupName != groupModel.GroupName;
										});
		}
	};

	$scope.HideViewSelected = function () {
		if (!isUserEdited()) {
			closeViewWindow();
			return;
		}
		var confirm = $mdDialog.confirm()
				.title('Warning!')
				.theme('confirm-dialog')
				.textContent('Do you want to save the changes?')
				.ariaLabel('Warning!').ok('Yes').cancel('No');

		$mdDialog.show(confirm).then(function () {
			var userSavePromise = saveUserDetail();
			userSavePromise.then(function (response) {
				if (response && response.Status === 0 && response.ErrorMessage.length === 0) {
					closeViewWindow();
				}
				else if (response && response.ErrorMessage) {
					$mdDialog.show($mdDialog.alert()
								.parent(angular.element(document.body))
								.clickOutsideToClose(true)
								.title('Warning!')
								.textContent(response.ErrorMessage)
								.ariaLabel('Warning!')
								.ok('OK')
							);
				}
			});
		}, function () {
			closeViewWindow();
		});
	};

	function isUserEdited() {
		var result = angular.equals($scope.user, $scope.originaluser);
		if (!result) {
			return true;
		}
		if ($scope.selectedSecurityItem !== $scope.UserSecurityTemplateName) {
			return true;
		}
		if ($scope.NewAddUserGroupList.length > 0 || $scope.RemovedUserGroupList.length > 0) {
			return true;
		}
		return false;
	}

	function closeViewWindow() {
		$scope.UserSecurityTemplateName = '';
		$scope.ViewUserModel = userFactory.userInitailValues();
		$scope.user = userFactory.userInitailValues();
		$scope.IsViewUserGroupListErrorMsg = true;
		$scope.UserGroupListErrorMsg = '';
		$scope.UserGroupList.SearchText = '';
		$scope.userGroupsList = [];
		$scope.selectedGroups = [];
		$scope.selected = [];
		$scope.NewAddUserGroupList = [];
		$scope.RemovedUserGroupList = [];
		$scope.RemovedUserGroupModelList = [];
		if (userGroupListSearchTimeOut) $timeout.cancel(userGroupListSearchTimeOut);
		isUserGroupListSearchTextDirty = false;
		isUserGroupListInstantSearch = false;
		$scope.showSelectedUserDetails = false;
		$scope.originaluser = userFactory.userInitailValues();
		$scope.selectedSecurityChipGroups = [];
		$scope.autocompleteSecurityMatch = true;
		$scope.searchSecurityText = null;
		$scope.selectedSecurityItem = null;
		$scope.UserSecurityTemplateName = null;
		SelectedUserGroupListForFilter = [];
		LastAddedSelectedItemUserGroupId = [];
		lastAppendUserGroupItemCount = 0;

		$scope.SearchFormObject = {
			RequestModel: homeFactory.requestModelInstance(),
			TableItemList: []
		};
		$scope.IsPosting = false;

		$timeout(function () {
			$(window).scrollTop($scope.scrollTop);
		});
	}

	var AssignGroupFunction = function () {
		if ($scope.vm.selectedApp.NoAppsPermission.trim().length > 0)
			return;
		if (!$scope.vm.selectedLibrary || $scope.vm.selectedLibrary.trim().length == 0)
			return;

		var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
		$mdDialog.show({
			controller: AddRemoveGroupDialogController,
			preserveScope: false,
			templateUrl: 'Views/AddRemoveGroups.html',
			parent: angular.element(document.body),
			clickOutsideToClose: true,
			fullscreen: useFullScreen,
			bindToController: true,
			locals: { ParentScope: $scope },
			onComplete: function () {
				$("#AddRemoveGroup input[id=searchGroup]").focus();
			}
		}).then(
				function (answer) {
					$scope.status = '';
				}, function () {
					$scope.status = '';
				});
		$scope.$watch(function () {
			return $mdMedia('xs') || $mdMedia('sm');
		}, function (wantsFullScreen) {
			$scope.customFullscreen = (wantsFullScreen === true);
		});
	};

	function AddRemoveGroupDialogController($scope, $mdDialog, ParentScope) {
		$scope.hide = function () {
			$mdDialog.hide();
		};
		$scope.cancel = function () {
			$mdDialog.cancel();
		};
		$scope.answer = function () {
			$mdDialog.hide();
		};

		$scope.SaveButtonChange = function ($event) {
			if ($event.keyCode === 9) {
				$event.preventDefault();
			}
			$("#PasswordField").focus();
			return false;
		};

		$scope.UserSearchTextChange = CustomUserSearchTextChange;

		function CustomUserSearchTextChange($event) {
			if ($event.keyCode === 13) {
				$event.preventDefault();
			}
		}

		$scope.viewSelectedOnlyLabel = 'View selected';
		$scope.filterSelected = function (selected, field) {
			return function (group) {
				if ($scope.viewSelectedOnlyLabel == 'Show all') {
					if (selected.length == 0) {
						$scope.viewSelectedOnlyLabel = 'View selected';
					}
					var items = $filter('filter')(selected, group, true);
					if (items.length > 0)
						return true;

					return false;
				} else {
					return true;
				}
			}
		};

		//$scope.filterGridSelected = ParentScope.vm.filterSelected;
		$scope.SelectedUser = ParentScope.user;
		$scope.PageTitle = 'Add Groups';
		$scope.ShowErrorMsg = false;
		$scope.ErrorMessage = '';
		$scope.AllGroupList = [];
		$scope.SelectedGroupList = [];
		$scope.ViewSelectAllText = ParentScope.vm.viewSelectedOnlyLabel;
		$scope.AddRemoveGroupsSearch = {
			AllGroupPageSearchText: ''
		};

		var allGroupListReqModel = homeFactory.requestModelInstance();
		var totalGroupsCount = 0;
		var loadedGroupCount = 0;
		var isAllGroupPageSearchTextDirty = false;
		var allGroupPageSearchTimeOut;
		var IsInstantSearch = false;
		var SelectedGroupListForFilter = [];
		var LastAddedSelectedItemGroupId = [];
		var lastAppendGroupItemCount = 0;

		function fillRemovedGroupList() {
		    var groupModel = null;
		    var filterTempModel = null;
		    var tempList = [];

		    for (var iCount = 0; iCount < ParentScope.RemovedUserGroupModelList.length; iCount++) {
		        groupModel = ParentScope.RemovedUserGroupModelList[iCount];

		        if ($scope.AddRemoveGroupsSearch.AllGroupPageSearchText.trim().length > 0) {
		            if (groupModel.GroupName.indexOf($scope.AddRemoveGroupsSearch.AllGroupPageSearchText) === -1) {
		                groupModel = null;
		                continue;
		            }
		        }
		        if (SelectedGroupListForFilter.length === 0) {
		            $scope.AllGroupList.push(angular.copy(groupModel));
		        }
		        else {
		            tempList = $filter('filter')(SelectedGroupListForFilter, {
		                GroupName: groupModel.GroupName
		            }, true);
		            if (tempList.length === 0) {
		                $scope.AllGroupList.push(angular.copy(groupModel));
		            }
		            else {
		                LastAddedSelectedItemGroupId = $.grep(LastAddedSelectedItemGroupId,
                           function (item, index) {
                               return item.GroupName != groupModel.GroupName;
                           });
		                filterTempModel = angular.copy(tempList[0]);
		                $scope.AllGroupList.push(filterTempModel);
		                $scope.SelectedGroupList.push(filterTempModel);
		                filterTempModel = null;
		            }
		        }
		        filterTempModel = null;
		    }
		}

		function getAllGroupList(offset) {
			return $q(function (resolve, reject) {
				var groupList = [];
				var groupNameList = [];
				var totalCount = 0;

				var groupListReqModelTemp = homeFactory.requestModelInstance();
				groupListReqModelTemp.libraryName = ParentScope.vm.selectedLibrary;
				groupListReqModelTemp.searchText = $scope.AddRemoveGroupsSearch.AllGroupPageSearchText;
				groupListReqModelTemp.pagenumber = offset;

				var apiUrl = userFactory.getNonUserGroupsAPI(groupListReqModelTemp, $scope.SelectedUser.UserId);
				ParentScope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(apiUrl));
				var groupPromise = UserService.getUserOutOfGroups(apiUrl, ParentScope.mc.loginModel.AuthKey);
				groupPromise.then(function (response) {
					if (response && response.status === 200) {
						ParentScope.mc.getlogDetails("Debug", 'Response:Success');
						var groupUIModel;
						//var filterItemIndex = -1;
						totalCount = response.data.total_count;
						loadedGroupCount += response.data.data.length;

						angular.forEach(response.data.data, function (group) {
							groupUIModel = groupFactory.getGroupUI(group);
							groupUIModel.Selected = false;
							groupUIModel.Checked = false;

							groupList.push(groupUIModel);
							//filterItemIndex = ParentScope.RemovedUserGroupList.indexOf(groupUIModel.GroupName);
							//if (filterItemIndex === -1) {
							//	groupNameList.push(groupUIModel.GroupName);
							//}
							//filterItemIndex = -1;
							groupUIModel = null;

						});
					}
					else {
						ParentScope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
					}
					resolve({ Status: 1, GroupList: groupList, GroupNameList: groupNameList, TotalGroupCount: totalCount });
				}, function (response) {
					resolve({ Status: -1 });
					ParentScope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
				});
			});
		}

		function fillGroupList() {
		    fillRemovedGroupList();
			var promise = getAllGroupList(allGroupListReqModel.pagenumber);
			promise.then(function (response) {
				if (response.Status === 1) {
					totalGroupsCount = response.TotalGroupCount;
					if (response.GroupList.length === 0) return;

					if (lastAppendGroupItemCount > 0) {
						$scope.AllGroupList.splice($scope.AllGroupList.length - lastAppendGroupItemCount, lastAppendGroupItemCount);
						$scope.SelectedGroupList.splice($scope.SelectedGroupList.length - lastAppendGroupItemCount, lastAppendGroupItemCount);
						lastAppendGroupItemCount = 0;
					}
					var addedItemCount = 0;
					var filterTempModel;
					var filterTempList = [];
					var tempList = [];

					angular.forEach(response.GroupList, function (groupCheckItem) {
					    filterTempList = $filter('filter')(ParentScope.NewAddUserGroupList, {
					        GroupName: groupCheckItem.GroupName
					    }, true);

					    if (filterTempList.length === 0) {
					        tempList = [];
					        filterTempModel = angular.copy(groupCheckItem);

					        if (SelectedGroupListForFilter.length === 0) {
					            $scope.AllGroupList.push(filterTempModel);
					        }
					        else {
					            tempList = $filter('filter')(SelectedGroupListForFilter, {
					                GroupName: groupCheckItem.GroupName
					            }, true);
					            if (tempList.length === 0) {
					                $scope.AllGroupList.push(filterTempModel);
					            }
					            else {
					                LastAddedSelectedItemGroupId = $.grep(LastAddedSelectedItemGroupId,
                                       function (item, index) {
                                           return item.GroupName != groupCheckItem.GroupName;
                                       });
					                filterTempModel = angular.copy(tempList[0]);
					                $scope.AllGroupList.push(filterTempModel);
					                $scope.SelectedGroupList.push(filterTempModel);
					                filterTempModel = null;
					            }
					        }
					        filterTempModel = null;
					        addedItemCount += 1;
					    }
					    tempList = [];
					    filterTempList = [];
					});
					if (addedItemCount < allGroupListReqModel.pageLength && (allGroupListReqModel.pagenumber + allGroupListReqModel.pageLength) < totalGroupsCount) {
					    allGroupListReqModel.pagenumber += allGroupListReqModel.pageLength;
					    fillGroupList(allGroupListReqModel.pagenumber);
					}
					if ($scope.AddRemoveGroupsSearch.AllGroupPageSearchText.length === 0) {
					    angular.forEach(LastAddedSelectedItemGroupId, function (group) {
					        filterTempModel = angular.copy(group);
					        $scope.AllGroupList.push(filterTempModel);
					        $scope.SelectedGroupList.push(filterTempModel);
					        filterTempModel = null;
					        lastAppendGroupItemCount += 1;
					    });
					}
					if ($scope.SelectedGroupList.length > 0) {
					    $scope.PageTitle = $scope.SelectedGroupList.length.toString() + ' Groups Selected.';
					}

				}
			}, function (response) {
			});
		}

		$scope.onAllGroupPaginate = function () {
			if (loadedGroupCount < totalGroupsCount) {
				allGroupListReqModel.pagenumber += allGroupListReqModel.pageLength;
				fillGroupList();
			}
		};

		$scope.AllGroupSearch_Click = function () {
			lastAppendGroupItemCount = 0;
			LastAddedSelectedItemGroupId = angular.copy(SelectedGroupListForFilter);
			$scope.PageTitle = 'Add Groups';
			allGroupListReqModel.pagenumber = 0;
			loadedGroupCount = 0;
			$scope.AllGroupList = [];
			$scope.SelectedGroupList = [];
			fillGroupList();
		};

		$scope.AllGroupSearch_Clear = function () {
			IsInstantSearch = true;
			$scope.AddRemoveGroupsSearch.AllGroupPageSearchText = '';
		};

		$scope.$watch(function () { return $scope.AddRemoveGroupsSearch.AllGroupPageSearchText; }, function (val) {
			if ($scope.AddRemoveGroupsSearch.AllGroupPageSearchText.length > 0) {
				isAllGroupPageSearchTextDirty = true;
			}
			if (allGroupPageSearchTimeOut) $timeout.cancel(allGroupPageSearchTimeOut);

			if (IsInstantSearch) {
				IsInstantSearch = false;
				$scope.AllGroupSearch_Click();
			}
			else {
				allGroupPageSearchTimeOut = $timeout(function () {
					if (isAllGroupPageSearchTextDirty) {
						$scope.AllGroupSearch_Click();
					}
				}, 2000);
			}
		}, true);

		$scope.ViewSelectedMembers = function () {
			$scope.viewSelectedOnlyLabel = $scope.viewSelectedOnlyLabel == 'View selected' ? 'Show all' : 'View selected';
		};

		$scope.onGroupSelect = function (groupItem) {
			$scope.PageTitle = $scope.SelectedGroupList.length.toString() + ' Groups Selected.';
			var tempListFilter = $filter('filter')(SelectedGroupListForFilter, {
				GroupName: groupItem.GroupName
			}, true);
			if (tempListFilter.length === 0) {
				SelectedGroupListForFilter.push(angular.copy(groupItem));
			}
			tempListFilter = [];
		};

		$scope.onGroupDeselect = function (groupItem) {
			if ($scope.SelectedGroupList.length === 0) {
				$scope.PageTitle = 'Add Groups';
			}
			else {
				$scope.PageTitle = $scope.SelectedGroupList.length.toString() + ' Groups Selected.';
			}
			
			if (SelectedGroupListForFilter.length > 0) {
				SelectedGroupListForFilter = $.grep(SelectedGroupListForFilter,
									function (item, index) {
										return item.GroupName != groupItem.GroupName;
									});
			}
			if (SelectedGroupListForFilter.length > 0) {
				LastAddedSelectedItemGroupId = $.grep(LastAddedSelectedItemGroupId,
									   function (item, index) {
										   return item.GroupName != groupItem.GroupName;
									   });
			}
		};

		$scope.AddSelectedGroup = function () {
			var filterListTempIndex = -1;
			angular.forEach(SelectedGroupListForFilter, function (group) {
				filterListTempIndex = ParentScope.RemovedUserGroupList.indexOf(group.GroupName);
				if (filterListTempIndex > -1) {
					ParentScope.RemovedUserGroupList.splice(filterListTempIndex, 1);
				}
				else {
					ParentScope.NewAddUserGroupList.push(angular.copy(group));
				}
			});
			if (ParentScope.showSelectedUserDetails) {
				ParentScope.initializeUserGroupList();
			}
			$mdDialog.hide();
		};

		$scope.dialogPopup = {
			Header: '',
			Message: '',
			CallbackFunction: null,
			Show: function () {
				$('#popup-alert-dialog-bg').slideToggle();
			},
			OK: function () {
				$('#popup-alert-dialog-bg').slideToggle();
				$scope.dialogPopup.Header = '';
				$scope.dialogPopup.Message = '';

				if ($scope.dialogPopup.CallbackFunction) {
					$scope.dialogPopup.CallbackFunction();
					$scope.dialogPopup.CallbackFunction = null;
				}
			}
		};

		allGroupListReqModel.libraryName = ParentScope.vm.selectedLibrary;
		allGroupListReqModel.pagenumber = 0;
		loadedGroupCount = 0;
		fillGroupList();
	}

	$scope.SaveCurrentUserEditContent = function () {
		var userSavePromise = saveUserDetail();
		userSavePromise.then(function (response) {
			if (response && response.Status === 0 && response.ErrorMessage.length === 0) {
				$mdDialog.show($mdDialog.alert()
						   .parent(angular.element(document.body))
						   .clickOutsideToClose(true)
						   .title('Success')
						   .textContent('User details succesfully updated.')
						   .ariaLabel('Success')
						   .ok('OK')
					   );

				$scope.NewAddUserGroupList = [];
				$scope.RemovedUserGroupList = [];
				$scope.mc.getlogDetails("Debug", 'Method:GET;ACTION: Save Current User:' + $scope.user.UserId);

				var getUserPromise = userFactory.getSingleUser('GETUSER', $scope.vm.selectedLibrary, $scope.user.UserId, $scope.mc.loginModel.AuthKey);
				getUserPromise.then(function (userResponse) {
					$scope.mc.getlogDetails("Debug", 'Response:Success');
					if (userResponse && userResponse.data && userResponse.data.length > 0) {
						$scope.ViewUserModel = userFactory.getUserUI(userResponse.data[0]);
						$scope.user = $scope.ViewUserModel;
						angular.copy($scope.user, $scope.originaluser);
					}
				});
				$scope.initializeUserGroupList();
			}
			else if (response && response.ErrorMessage) {
				$scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
				$mdDialog.show($mdDialog.alert()
							.parent(angular.element(document.body))
							.clickOutsideToClose(true)
							.title('Warning!')
							.textContent(response.ErrorMessage)
							.ariaLabel('Warning!')
							.ok('OK')
						);
			}
		}, function (response) {
			$scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
			if (response && response.ErrorMessage) {
				$mdDialog.show($mdDialog.alert()
							.parent(angular.element(document.body))
							.clickOutsideToClose(true)
							.title('Warning!')
							.textContent(response.ErrorMessage)
							.ariaLabel('Warning!')
							.ok('OK')
						);
			}
		});
	};

	function saveUserDetail() {
		return $q(function (resolve, reject) {
			if ($scope.user.Email === null || $scope.user.Email === undefined) {
				resolve({ Status: -1, ErrorMessage: 'Invalid Email.' });
				return;
			}

			var deferredarray = [];
			var errorMesssage = '';
			var deferredUser = $q.defer();
			var apiUrl = userFactory.getAPIUrl('PUTUSER', null,$scope.user.UserId)
			$scope.IsPosting = true;
			
			$scope.user.IsAllowLogon = $scope.user.IsAllowLogon === true || $scope.user.IsAllowLogon === "true";
			$scope.user.IsExternalUser = $scope.user.IsExternalUser === true || $scope.user.IsExternalUser === "true";
			$scope.user.PasswordNeverExpires = $scope.user.PasswordNeverExpires === true || $scope.user.PasswordNeverExpires === "true";
			
			var RequestBody = userFactory.getUserPutModel($scope.user, $scope.vm.selectedLibrary)
			var promise = UserService.editUser(RequestBody, apiUrl, $scope.mc.loginModel.AuthKey);
			$scope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(apiUrl) + 'Parametrs are' + JSON.stringify(RequestBody));

			promise.then(function (response) {
				deferredUser.resolve(response);
				if (response && response.status && response.status == 200) {
					$scope.result = angular.equals($scope.user, $scope.originaluser);
					if (!$scope.result) {
					    $scope.mc.setSecurityLogDetails("Info", 'Success', $scope.user.UserId, 'User Update', JSON.stringify(RequestBody));
						if (!$scope.vm.UserPhoto) $scope.vm.getUserPhoto();
					}

					if ($scope.SelectedUserIndexList && $scope.SelectedUserIndexList.length > 0) {
						var selecteduser = $scope.UserList[$scope.SelectedUserIndexList[0]];
						if (selecteduser) {
							selecteduser.Email = $scope.user.Email;
							selecteduser.Ext = $scope.user.Ext;
							selecteduser.Fax = $scope.user.Fax;
							selecteduser.FileServer = $scope.user.FileServer;
							selecteduser.FullName = $scope.user.FullName;
							selecteduser.IsAllowLogon = $scope.user.IsAllowLogon;
							selecteduser.IsExternalUser = $scope.user.IsExternalUser;
							selecteduser.Location = $scope.user.Location;
							selecteduser.PasswordNeverExpires = $scope.user.PasswordNeverExpires;
							selecteduser.Phone = $scope.user.Phone;
							selecteduser.PreferredDatabase = $scope.user.PreferredDatabase;
							selecteduser.SecuredDocServer = $scope.user.SecuredDocServer;
							selecteduser.UserDomain = $scope.user.UserDomain;
							selecteduser.ExchAutoDiscover = $scope.user.ExchAutoDiscover;
							selecteduser.DistName = $scope.user.DistName;
							selecteduser = null;
						}
					}
					var tempList = [];
					tempList = angular.copy($scope.UserList);
					$scope.selected = [];
					$scope.UserList = [];
					$scope.UserList = angular.copy(tempList);
					tempList = [];
				}
				else {
					if (response && response.statusText && response.statusText != '') {
						resolve({ Status: -1, ErrorMessage: response.statusText })
					}
					else {
						resolve({ Status: -1, ErrorMessage: 'Updating user failed.' });
					}				    		   
					errorMesssage = response.statusText;
					$scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.user.UserId, 'User Update', JSON.stringify(RequestBody));
				}
			}, function (response) {
				deferredUser.resolve(response);
				$scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.user.UserId, 'User Update', JSON.stringify(RequestBody));
				if (response && response.data  &&  response.data.details &&  response.data.details.message) {                   
					$scope.ErrorMessage = response.data.details.message;
				}
				else {
					
					errorMesssage = "Posting user failed due to unknown errors.";
				}
			});
			deferredarray.push(deferredUser.promise);

			var deferredSecTemplate = $q.defer();
			var templatePromise = assignTemplate();
			templatePromise.then(function (templateResponse) {
				deferredSecTemplate.resolve(templateResponse);
				if (templateResponse && templateResponse.Status === 0) {
					$scope.UserSecurityTemplateName = '';

					if ($scope.selectedSecurityItem !== '' && $scope.selectedSecurityItem !== null && $scope.selectedSecurityItem !== undefined) {
						if ($scope.selectedSecurityItem.TemplateName) {
							$scope.UserSecurityTemplateName = $scope.selectedSecurityItem.TemplateName;
						}
						else {
							$scope.UserSecurityTemplateName = $scope.selectedSecurityItem;
						}
					}
				}
				else {
					errorMesssage = templateResponse.StatusText;
				}
			}, function (templateResponse) {
				deferredSecTemplate.resolve(templateResponse);
				if (templateResponse && templateResponse.StatusText) {
					errorMesssage = templateResponse.StatusText;
				}
			});
			deferredarray.push(deferredSecTemplate.promise);

			angular.forEach($scope.RemovedUserGroupList, function (groupName) {
				var deferredRemoveGroup = $q.defer();
				var apiUrl = groupFactory.getAPIUrl('REMOVEUSERFROMGROUP', { GroupName: groupName }, $scope.user.UserId, $scope.vm.selectedLibrary, 'remove');
				var requestBody = {
					database: $scope.vm.selectedLibrary,
					data_type: "users",
					data: [],
					action: "delete"
				};
				requestBody.data.push($scope.user.UserId);

				$scope.mc.getlogDetails("Debug", 'Method:Delete;URL:' + JSON.stringify(apiUrl));

				var promise = GroupService.RemoveUserFromGroup(apiUrl, requestBody, $scope.mc.loginModel.AuthKey);
				promise.then(function (response) {
				    if (response) {
				        deferredRemoveGroup.resolve(response);
				        if (response.status === 200) {
				            $scope.mc.setSecurityLogDetails("Info", 'Success', $scope.user.UserId, 'User Remove Group', 'Group Name=\"' + groupName + '\"');
				        } else {
				            $scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.user.UserId, 'User Remove Group', 'Group Name=\"' + groupName + '\"');
				            if (response && response.data && response.data.details && response.data.details.message) {
				                errorMesssage = response.data.statusDetail;
				            }
				            else {
				                errorMesssage = "Posting user failed due to unknown errors.";
				            }
				        }
				    }
				}, function (response) {
				    $scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.user.UserId, 'User Remove Group', 'GroupName=\"' + groupName + '\"');
					deferredRemoveGroup.resolve(response);
				});
				deferredarray.push(deferredRemoveGroup.promise);
			});

			angular.forEach($scope.NewAddUserGroupList, function (group) {
				var deferredAddGroup = $q.defer();

				var requestBody = {
					database: $scope.vm.selectedLibrary,
					data_type: "users",
					data: [],
					action: "add"
				};
				requestBody.data.push($scope.user.UserId);

				var apiUrl = groupFactory.getAPIUrl('ADDUSERINGROUP', group, $scope.user.UserId, $scope.vm.selectedLibrary, 'add' + group.GroupName);
				var promise = GroupService.AddUserToGroup(apiUrl, requestBody, $scope.mc.loginModel.AuthKey);
				promise.then(function (response) {
					if (response) {
						deferredAddGroup.resolve(response);
						if (response.status === 200) {
						    $scope.mc.setSecurityLogDetails("Info", 'Success', $scope.user.UserId, 'User Add Group', 'GroupName=\"' + group.GroupName + '\"');
						} else {
						    $scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.user.UserId, 'User Add Group', 'GroupName=\"' + group.GroupName + '\"');
							errorMesssage = response.data.statusDetail;
						}
					}
				}, function (response) {
				    $scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.user.UserId, 'User Add Group', 'GroupName=\"' + group.GroupName + '\"');
					deferredAddGroup.resolve(response);
				});
				deferredarray.push(deferredAddGroup.promise);
			});

			$q.all(deferredarray).then(function () {
				$scope.IsPosting = false;
				resolve({ Status: 0, ErrorMessage: "" });
				  return;
			}, function () {
				$scope.IsPosting = false;
				resolve({ Status: -1, ErrorMessage: errorMesssage });
				  return;
			});
		});
	}

	function assignTemplate() {
		return $q(function (resolve, reject) {

			if ($scope.selectedSecurityItem === '' || $scope.selectedSecurityItem == null || $scope.selectedSecurityItem == undefined) {
				if ($scope.UserSecurityTemplateName == '') {
					resolve({ Status: 0, StatusText: 'OK' });
					return;
				}
			}
			//if ($scope.selectedSecurityItem && ($scope.selectedSecurityItem === $scope.UserSecurityTemplateName || $scope.selectedSecurityItem.TemplateName === $scope.UserSecurityTemplateName)) {
			if ($scope.selectedSecurityItem && $scope.selectedSecurityItem === $scope.UserSecurityTemplateName) {
				resolve({ Status: 0, StatusText: 'OK' });
				return;
			}

			var taskName = '';
			var taskParam = '';
			var dbWriter;
			var apiUrl = '';
			var requestBody = {};
			requestBody[CONST_ST.Database] = $scope.vm.selectedLibrary;

			if ($scope.UserSecurityTemplateName == '') {
			    taskName = 'SetUserSecurityTemplate';
			    taskParam = 'TemplateName=\"' + $scope.selectedSecurityItem + '\"';

				dbWriter = SecurityTemplateService
				.SetSecurityTemplate(securityTemplateFactory.getAPIUrl('SETSECURITYTEMPLATEOFUSER', null,
						$scope.user.UserId, $scope.UserSecurityTemplateName, $scope.selectedSecurityItem,
						$scope.vm.selectedLibrary), $scope.mc.loginModel.AuthKey, requestBody);
			} else if ($scope.selectedSecurityItem == '' || $scope.selectedSecurityItem == null || $scope.selectedSecurityItem == undefined) {
			    taskName = 'DeleteUserSecurityTemplate';
			    taskParam = 'TemplateName=\"' + UserSecurityTemplateName + '\"';

				dbWriter = SecurityTemplateService
				.DeleteSecurityTemplate(securityTemplateFactory.getAPIUrl('DELETESECURITYTEMPLATEOFUSER', null,
						$scope.user.UserId, $scope.UserSecurityTemplateName, '',
						$scope.vm.selectedLibrary), $scope.mc.loginModel.AuthKey, requestBody);
			} else {
			    taskName = 'UpdateUserSecurityTemplate';
			    taskParam = 'TemplateName=\"' + $scope.selectedSecurityItem + '\"';

				requestBody[CONST_ST.TemplateName] = $scope.selectedSecurityItem;
				dbWriter = SecurityTemplateService
				.UpdateSecurityTemplate(securityTemplateFactory.getAPIUrl('UPDATESECURITYTEMPLATEOFUSER', null,
						$scope.user.UserId, $scope.UserSecurityTemplateName, $scope.selectedSecurityItem,
						$scope.vm.selectedLibrary), $scope.mc.loginModel.AuthKey, requestBody);
			}
			if (dbWriter) {
				dbWriter.then(
					function (response) {
					    if (response && response.data && response.status == 200) {
					        $scope.mc.setSecurityLogDetails("Info", 'Success', $scope.user.UserId, taskName, taskParam);
							resolve({ Status: 0, StatusText: 'OK' });
						}
						else {
					        $scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.user.UserId, taskName, taskParam);
							if (response && response.data && response.data.details && response.data.details.message) {
								resolve({ Status: -1, StatusText: response.data.details.message });
							}
							else {
								resolve({ Status: -1, StatusText: response.statusText });
							}
						}
					}, function (response) {
					    $scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.user.UserId, taskName, taskParam);
						$scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
						reject({ Status: -1, StatusText: '' });
					});
			}
		});
	}

	$scope.transformTemplateChip = function (chip) {
		if (angular.isObject(chip)) {
			return chip;
		}
		return { name: chip, description: 'new' }
	};

	$scope.querySecuritySearch = function (query) {
		var results = $scope.SearchFormObject.TableItemList;
		return results;
	};
	
	$scope.searchTextChange = function (text) {

	};

	$scope.selectedItemChange = function (item) {
		if (item != undefined) {
			if (item['Database'] !== undefined) {
				$scope.selectedSecurityItem = item['TemplateName'];
			}
			else {
				$scope.selectedSecurityItem = item;
			}
		}
		else {
			$scope.searchSecurityText = '';
			$scope.selectedSecurityItem = '';
		}
	};

	function GetSecurityTemplates() {
		$scope.SearchFormObject = {
			RequestModel: homeFactory.requestModelInstance(),
			TableItemList: []
		};
		$scope.SearchFormObject.RequestModel.libraryName = $scope.selectedLibrary;
		$scope.SearchFormObject.RequestModel.pagenumber = 1;
		var apiUrl = securityTemplateFactory.getAPIUrl('GETSECURITYTEMPLATES', $scope.SearchFormObject.RequestModel);
		$scope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(apiUrl));
		var TemplateList = SecurityTemplateService.getTemplateList(apiUrl, $scope.mc.loginModel.AuthKey);
		TemplateList.then(function (response) {
			if (response.data && response.data.data && response.data.data.length > 0 && response.data.total_count > 0) {
				$scope.mc.getlogDetails("Debug", 'Response:Success');
				var UIModel;
				$scope.SearchFormObject.TableItemList = [];
				angular.forEach(response.data.data, function (item) {
					UIModel = securityTemplateFactory.getSTUI(item);
					$scope.SearchFormObject.TableItemList.push(UIModel.TemplateName);
					UIModel = null;
				});
			}
			$scope.IsLoading = false;
		}, function (response) {
			$scope.mc.Debug("Error", 'Response:' + JSON.stringify(response));
			$scope.IsLoading = false;
			////alert('Failed to fetch security template fetching.');
		});
	}

	$scope.selectedSecurityChipGroups = [];
	$scope.autocompleteSecurityMatch = true;
	$scope.selectedSecurityItem = null;
	$scope.searchSecurityText = null;
	
	$scope.SearchFormObject = {
		RequestModel: homeFactory.requestModelInstance(),
		TableItemList: []
	};

}