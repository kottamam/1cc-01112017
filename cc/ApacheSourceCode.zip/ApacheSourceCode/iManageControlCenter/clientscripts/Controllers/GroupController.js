﻿app.controller("GroupController", GroupController);
GroupController.$inject = ['$scope', '$rootScope', 'GroupService', 'groupFactory', '$filter', '$mdDialog', '$mdMedia', '$timeout', 'homeFactory', 'UserService', 'CONST_GROUPS', 'userFactory', '$q'];

function GroupController($scope, $rootScope, GroupService, groupFactory, $filter, $mdDialog, $mdMedia, $timeout, homeFactory, UserService, CONST_GROUPS, userFactory, $q) {

    $scope.loading = true;
    $scope.showValidation = false;
    $scope.ShowWarning = false;
    $scope.ErrorMessage = '';
    $scope.SearchValue = null;
    $scope.appsVar.SearchText = '';
    $scope.lastSelectedLibrary = '';
    $scope.UserListHeaderText = '';
    $scope.GroupDetails = [];

    $scope.GroupModel = groupFactory.groupInitialValues();

    var userrequestModel = homeFactory.requestModelInstance();
    var requestModel = homeFactory.requestModelInstance();
    var gurequestModel = homeFactory.requestModelInstance();

    var FilterSearchTimeout;
    var UsersSearchTimeout;
    var ViewAssignUsersSearchTimeout;
    var tempSelected = [];
    var appenditems = [];
    $scope.PageEvents.ViewAssignUser = 'undefined';
    $scope.PageEvents.AssignUser = 'undefined';
    $scope.PageEvents.Edit = 'undefined';
    $scope.PageEvents.Delete = 'undefined';
    $scope.UsersModel = {
        IsSearchTextFound: false,
        SearchText: '',
        ViewAssignUserSearchText: ''
    };

    $timeout(function () {
        $(window).scrollTop(0);
    });

    RegisterInitializeTabContents();

    var destroybroadCast;
    $scope.$on('RegisterInitializeTabContents', function () {
        if (angular.isFunction(destroybroadCast))
            destroybroadCast();

        RegisterInitializeTabContents();
    });

    function RegisterInitializeTabContents() {
        destroybroadCast = $scope.$on('InitializeTabContents', function () {

            if ($scope.vm.selectedApp.NoAppsPermission.trim().length > 0)
                return;
            if (!$scope.vm.selectedLibrary || $scope.vm.selectedLibrary.trim().length == 0)
                return;

            $scope.showSelectedGroupDetails = false;
            $scope.loading = true;
            $scope.showValidation = false;
            $scope.ShowWarning = false;
            $scope.ErrorMessage = '';
            $scope.SearchValue = null;
            $scope.appsVar.SearchText = '';
            $scope.lastSelectedLibrary = '';
            $scope.UserListHeaderText = '';
            
            $scope.GroupModel = groupFactory.groupInitialValues();
            userrequestModel = homeFactory.requestModelInstance();
            requestModel = homeFactory.requestModelInstance();
            gurequestModel = homeFactory.requestModelInstance();

            FilterSearchTimeout = null;
            UsersSearchTimeout = null;
            ViewAssignUsersSearchTimeout = null;
            $scope.GroupDetails = [];
            $scope.selected = [];
            tempSelected = [];
            appenditems = [];
            $scope.PageEvents.ViewAssignUser = 'undefined';
            $scope.PageEvents.AssignUser = 'undefined';
            $scope.PageEvents.Edit = 'undefined';
            $scope.PageEvents.Delete = 'undefined';
            $scope.UsersModel = {
                IsSearchTextFound: false,
                SearchText: '',
                ViewAssignUserSearchText: ''
            };
            tempSelected = [];
            Initalize();
            destroybroadCast();
        });
    }

    var ContextMenuVariables = {
        EnableDisable: {
            Label: 'Enable',
            Icon: 'img/icons/delete.svg',
            onClick: function () {
            },
            IconType: 'font-icon'
        }
    }

    $scope.ContextMenuFunctions = {
        Edit: function () {
            GroupEditFunction();
        },
        Delete: function () {
            GroupDeleteFunction();
        },
        EnableGroup: function (event) {
            var selectedGroupList = $scope.selected;
            var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
            var confirm = $mdDialog.confirm().title('Warning!').theme('confirm-dialog').textContent('Are you sure you want to enable the selected Group(s)?').ariaLabel('').targetEvent(event).ok('Yes').cancel('No');

            $mdDialog.show(confirm).then(function () {
                var deferredarray = [];
                angular.forEach(selectedGroupList, function (Groups) {
                    var deferred = $q.defer();

                    Groups.GroupEnabled = true;
                    var groupModelPut = groupFactory.getGroupPutModel(Groups, $scope.vm.selectedLibrary);
                    var apiUrl = groupFactory.getAPIUrl('PUTGROUPS', Groups);

                    $scope.mc.getlogDetails("Debug", 'Method:PUT;URL:' + JSON.stringify(apiUrl) + ';Body:' + JSON.stringify(groupModelPut));

                    var promise = GroupService.EditGroup(groupModelPut, apiUrl, $scope.mc.loginModel.AuthKey);
                    promise.then(function (response) {
                        if (response) {
                            if (response.status === 200) {
                                Groups.GroupEnabled = true;
                                $scope.mc.setSecurityLogDetails("Info", 'Success', Groups.GroupName, ' Group Enable', '');

                            } else {
                                $scope.mc.setSecurityLogDetails("Info", 'Failure', Groups.GroupName, ' Group Enable', '');

                            }
                            deferred.resolve(response);
                        }
                    }, function (response) {
                        $scope.mc.setSecurityLogDetails("Info", 'Failure', Groups.GroupName, ' Group Enable', '');

                    });
                    deferredarray.push(deferred.promise);
                });
                $q.all(deferredarray).then(function () {
                    $scope.selected = [];
                });
            });


        },
        DisableGroup: function (event) {
            var selectedGroupList = $scope.selected;


            var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
            var confirm = $mdDialog.confirm().title('Warning!').theme('confirm-dialog').textContent('Are you sure you want to disable the selected Group(s)?').ariaLabel('').targetEvent(event).ok('Yes').cancel('No');

            $mdDialog.show(confirm).then(function () {
                var deferredarray = [];
                angular.forEach(selectedGroupList, function (Groups) {
                    var deferred = $q.defer();

                    Groups.GroupEnabled = false;
                    var groupModelPut = groupFactory.getGroupPutModel(Groups, $scope.vm.selectedLibrary);
                    var apiUrl = groupFactory.getAPIUrl('PUTGROUPS', Groups);

                    $scope.mc.getlogDetails("Debug", 'Method:PUT;URL:' + JSON.stringify(apiUrl) + ';Body:' + JSON.stringify(groupModelPut));

                    var promise = GroupService.EditGroup(groupModelPut, apiUrl, $scope.mc.loginModel.AuthKey);
                    promise.then(function (response) {
                        if (response) {
                            if (response.status === 200) {
                                Groups.GroupEnabled = false;
                                $scope.mc.setSecurityLogDetails("Info", 'Success', Groups.GroupName, ' Group Disable', '');

                            } else {
                                $scope.mc.setSecurityLogDetails("Info", 'Success', Groups.GroupName, ' Group Disable', '');
                            }
                            deferred.resolve(response);
                        }
                    }, function (response) {
                        $scope.mc.setSecurityLogDetails("Info", 'Success', Groups.GroupName, ' Group Disable', '');
                    });
                    deferredarray.push(deferred.promise);
                });
                $q.all(deferredarray).then(function () {
                    $scope.selected = [];
                });
            });


        },
        AssignToUser: function () {
            AssignUserFunction();
        },
        CopyGroup: function () {
            var selectedGroup = $scope.selected;
            if (selectedGroup && selectedGroup.length > 0) {
                $scope.CopyGroupModel.showDialog(selectedGroup[0].GroupName);
            }
        },
        ReassignGroupSecurity: function () {
            var selectedGroup = $scope.selected;
            if (selectedGroup && selectedGroup.length > 0) {
                $scope.ReassignGroupSecurityObject.showDialog(selectedGroup[0].GroupName);
            }
        },
        RemoveMembersInView: function () {
            $scope.RemoveSelectedUser();
        }
    }

    function setContextMenuObject() {
        var selectedGroups = $scope.selected;
        if (selectedGroups !== undefined && selectedGroups.length > 0) {
            if (selectedGroups.length == 1) {
                if (selectedGroups[0].GroupEnabled) {
                    ContextMenuVariables.EnableDisable.Label = 'Disable';
                    ContextMenuVariables.EnableDisable.Icon = 'icon-disable';
                    ContextMenuVariables.EnableDisable.IconType = 'font-icon';
                    ContextMenuVariables.EnableDisable.onClick = $scope.ContextMenuFunctions.DisableGroup;
                    $scope.PageEvents.Enable = 'undefined';
                    $scope.PageEvents.Disable = $scope.ContextMenuFunctions.DisableGroup;
                } else {
                    ContextMenuVariables.EnableDisable.Label = 'Enable';
                    ContextMenuVariables.EnableDisable.Icon = 'icon-enable';
                    ContextMenuVariables.EnableDisable.onClick = $scope.ContextMenuFunctions.EnableGroup;
                    $scope.PageEvents.Enable = $scope.ContextMenuFunctions.EnableGroup;
                    $scope.PageEvents.Disable = 'undefined';
                }
            } else {
                ContextMenuVariables.EnableDisable.Label = '';
                ContextMenuVariables.EnableDisable.onClick = 'undefined';
                $scope.PageEvents.Enable = 'undefined';
                $scope.PageEvents.Disable = 'undefined';
                var enabledGroupsInSelectedList = $filter('filter')(selectedGroups, {
                    GroupEnabled: true
                });
                if (enabledGroupsInSelectedList.length == selectedGroups.length) {
                    ContextMenuVariables.EnableDisable.Label = 'Disable';
                    ContextMenuVariables.EnableDisable.Icon = 'icon-disable';
                    ContextMenuVariables.EnableDisable.IconType = 'font-icon';
                    ContextMenuVariables.EnableDisable.onClick = $scope.ContextMenuFunctions.DisableGroup;
                    $scope.PageEvents.Enable = 'undefined';
                    $scope.PageEvents.Disable = $scope.ContextMenuFunctions.DisableGroup;
                } else {
                    var disabledGroupsInSelectedList = $filter('filter')(selectedGroups, {
                        GroupEnabled: false
                    });
                    if (disabledGroupsInSelectedList.length == selectedGroups.length) {
                        ContextMenuVariables.EnableDisable.Label = 'Enable';
                        ContextMenuVariables.EnableDisable.Icon = 'icon-enable';
                        ContextMenuVariables.EnableDisable.IconType = 'font-icon';
                        ContextMenuVariables.EnableDisable.onClick = $scope.ContextMenuFunctions.EnableGroup;
                        $scope.PageEvents.Enable = $scope.ContextMenuFunctions.EnableGroup;
                        $scope.PageEvents.Disable = 'undefined';
                    }
                }
            }
        } else {
            ContextMenuVariables.EnableDisable.Label = '';
            ContextMenuVariables.EnableDisable.onClick = 'undefined';
            $scope.PageEvents.Enable = 'undefined';
            $scope.PageEvents.Disable = 'undefined';
        }
        $scope.menuList = [
		/*{
			Label : 'Delete',
			Icon : '  icon-delete',
			onClick : $scope.ContextMenuFunctions.Delete,
			Enable : $scope.selected.length == 1,
			IconType : 'font-icon'
		},*/
		{
		    Label: ContextMenuVariables.EnableDisable.Label,
		    Icon: ContextMenuVariables.EnableDisable.Icon,
		    onClick: ContextMenuVariables.EnableDisable.Label == '' ? 'undefined' : ContextMenuVariables.EnableDisable.onClick,
		    Enable: $scope.selected.length > 0 && ContextMenuVariables.EnableDisable.Label != '',
		    IconType: 'font-icon'
		}, {
		    Label: 'Clone',
		    Icon: 'icon-clone',
		    onClick: $scope.ContextMenuFunctions.CopyGroup,
		    Enable: $scope.selected.length == 1,
		    IconType: 'font-icon'
		}
		/*,{
			Label : 'Reassign Group Security',
			Icon : 'icon-reassign-group-security',
			onClick : $scope.ContextMenuFunctions.ReassignGroupSecurity,
			Enable : $scope.selected.length == 1,
			IconType : 'font-icon'
		}*/ ];
    }

    function Initalize() {
        $scope.loading = true;
        $scope.GroupDetails = [];
        $scope.selected = [];
        requestModel.pagenumber = 1;
        $scope.query.page = 1;
        $scope.query.totalCount = 0;
        getGroups();
    }

    $scope.$on('Window_Scrolled', function () {
        if ($scope.showSelectedGroupDetails) {
            if ($scope.groupMembersQuery.totalCount > $scope.groupMembers.length) {
                groupMembersReqModel.pagenumber++;
                getGroupMembers();
            }
        } else {
            if ($scope.query.totalCount > $scope.GroupDetails.length) {
                requestModel.pagenumber++;
                getGroups();
            }
        }
    });

    function getGroups() {
        if (!$scope.vm.selectedLibrary || $scope.vm.selectedLibrary.trim().length == 0)
            return;
        requestModel.libraryName = $scope.vm.selectedLibrary;
        requestModel.searchText = $scope.appsVar.SearchText;

        if ($scope.selected.length > 0 && requestModel.pagenumber == 1) {
            angular.forEach($scope.selected, function (group) {
                tempSelected.push(angular.copy(group));
            });
            $scope.selected = [];
        }
        if (isSearch) {
            //$scope.showSearchProgress = true;
            showProgressDialog();   
        }
        var apiUrl = groupFactory.getAPIUrl('SEARCHGROUPS', requestModel)
        $scope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(apiUrl));
        var Group = GroupService.getGroups(apiUrl, $scope.mc.loginModel.AuthKey);
        Group.then(function (response) {
            $scope.appsVar.initialLoading = false;
            if (response) {

                if (response["status"] == 200) {
                    $scope.mc.getlogDetails("Info", 'Response:Success');
                    if (appenditems.length > 0) {

                        $scope.GroupDetails.splice($scope.GroupDetails.length - appenditems.length, appenditems.length);
                        $scope.selected.splice($scope.selected.length - appenditems.length, appenditems.length);
                        tempSelected = angular.copy(appenditems);
                        appenditems = [];

                    }
                    $scope.query.totalCount = response["data"]["total_count"];
                    angular.forEach(response["data"]["data"], function (group) {
                        var newgroup = groupFactory.getGroupUI(group);
                        $scope.GroupDetails.push(newgroup);
                        if (tempSelected.length > 0) {
                            var existsInSelected = $filter('filter')(tempSelected, {
                                GroupName: newgroup.GroupName
                            }, true);
                            if (existsInSelected.length > 0) {
                                var index = tempSelected.indexOf(existsInSelected[0]);
                                if (index != -1) {
                                    tempSelected.splice(index, 1);
                                    $scope.selected.push(newgroup);
                                }
                            }
                        }
                    });

                    if ($scope.appsVar.SearchText.length === 0 && !isValidFilterFind()) {
                        if (tempSelected.length > 0) {

                            angular.forEach(tempSelected, function (group) {
                                $scope.GroupDetails.push(group);
                                $scope.selected.push(group);
                            });
                            appenditems = angular.copy(tempSelected);
                            tempSelected = [];
                        }

                    }

                    if ($scope.selected.length > 0) {
                        setContextMenuObject();
                    }
                } else {
                    $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                }
                if (isSearch) $mdDialog.hide();
                $scope.showSearchProgress = false;
            }
            $scope.vm.selectedApp.ResponseCount = $scope.GroupDetails.length;

        }, function (response) {
            $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
            $mdDialog.show($mdDialog.alert().parent(angular.element(document.body)).clickOutsideToClose(true).title('Warning!').textContent('Failed to retrieve Groups.').ariaLabel('Warning!').ok('OK'));
            $scope.showSearchProgress = false;
            if (isSearch) $mdDialog.hide();
        });
    }

    function isValidFilterFind() {
        var filterKeyItem = null;
        var blnResult = false;

        for (var iCount = 0; iCount < requestModel.filters.length; iCount++) {
            filterKeyItem = requestModel.filters[iCount];
            if (filterKeyItem.FilterValues && filterKeyItem.FilterValues[0] && filterKeyItem.FilterValues[0].trim().length > 0) {
                blnResult = true;
                break;
            }
            filterKeyItem = null;
        }
        return blnResult;
    }

    $scope.addGroup = function () {
        $scope.showValidation = true;
        $scope.posting = false;
        $scope.ShowWarning = false;
        if ($scope.GroupModel.GroupName == '') {
            $scope.posting = false;
            return;
        }
        $scope.posting = true;
        $scope.lastSelectedLibrary = $scope.vm.selectedLibrary;
        var requestBody = groupFactory.getGroupPostModel($scope.GroupModel, $scope.vm.selectedLibrary)
        var requestUrl = groupFactory.getAPIUrl('POSTGROUPS', null);
        $scope.mc.getlogDetails("Debug", 'Method:POST;URL:' + JSON.stringify(requestUrl) + 'Request Body:' + JSON.stringify(requestBody));

        var addGroup = GroupService.addGroups(requestBody, requestUrl, $scope.mc.loginModel.AuthKey);
        addGroup.then(function (response) {
            if (response && response.data && response.data[CONST_GROUPS.GroupNumResponse]) {
                if (response.data[CONST_GROUPS.GroupNumResponse] > 0) {
                    $scope.showValidation = false;
                    $scope.dialogPopup.CallbackFunction = function () {
                        $mdDialog.hide();
                    }
                    $scope.dialogPopup.Header = 'Success';
                    $scope.dialogPopup.Message = 'Group added succesfully';
                    //  $scope.mc.setSecurityLogDetails("Info", "Response: Success, added new Group(" + $scope.GroupModel.GroupName + "[Group Num " + response.data[CONST_GROUPS.GroupNumResponse] + "])");
                    $scope.mc.setSecurityLogDetails("Info", 'Success', $scope.GroupModel.GroupName, ' Group Add', JSON.stringify(requestBody));
                    $scope.dialogPopup.Show();
                    $timeout(function () {
                        $scope.dialogPopup.OK();
                        $scope.ShowWarning = false;
                        $scope.GroupModel = groupFactory.groupInitialValues();
                        $scope.selected = [];
                        $scope.GroupDetails = [];
                        Initalize();
                    }, 2000);
                }
            } else {
                // $scope.mc.setSecurityLogDetails("Error", 'Response:' + JSON.stringify(response));
                $scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.GroupModel.GroupName, ' Group Add', JSON.stringify(requestBody));

                if (response && response.data && response.data.details && response.data.details.message) {
                    $scope.ErrorMessage = response.data.details.message;

                } else {
                    $scope.ErrorMessage = "Posting group failed due to unknown errors.";
                }
                $scope.ShowWarning = true;
            }
            $scope.posting = false;
        }, function (response) {
            $scope.posting = false;
            $scope.ShowWarning = true;
            $scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.GroupModel.GroupName, ' Group Add', JSON.stringify(requestBody));

            if (response && response.data && response.data.details && response.data.details.message) {
                $scope.ErrorMessage = response.data.details.message;

            } else {
                $scope.ErrorMessage = "Posting group failed due to unknown errors.";
            }
            ;
        });
    }

    var isSearch = false;

    $scope.$on('Search_Click', function (event, args) {
        $scope.loading = true;
        $scope.GroupDetails = [];
        requestModel.pagenumber = 1;
        $scope.query.page = 1;
        $scope.query.totalCount = 0;
        isSearch = true;
        getGroups();
    });

    /*
	 * $scope.$on('Refresh_Click', function (event, args) { Initalize(); });
	 */

    $scope.singleDeleteClick = function () {
        var s = $scope.appsVar.selectedRecordId;
        var getGroup = GroupService.DeleteGroup(s);

        getGroup.then(function (response) {
            if (response.data == "success") {
                $scope.appsVar.selectedRecordId = '';

                $scope.lastSelectedLibrary = '';
                getGroups();
                $scope.showAlertMessage("Selected group(s) deleted successfully.");
            } else {
                $scope.showAlertMessage('Failed to delete selected group(s).');
            }
        }, function () {
            $scope.showAlertMessage('Failed to delete selected group(s).');
        });

    };

    $rootScope.$on('onGroupValidateBulkDeleteClick', function () {
        $scope.ValidateGroups = [];
        GroupValidateBulkDeleteClick();
    })

    function GroupValidateBulkDeleteClick() {
        $scope.ValidateGroups = $scope.selected;
        if (typeof $scope.ValidateGroups !== 'undefined' && $scope.ValidateGroups.length > 0) {
            $scope.showConfirmMessage('Are you sure to delete selected group(s)?');
            return true;
        } else {
            $scope.showAlertMessage('Select group(s) to delete.');
            return false;
        }
    }

    $rootScope.$on('onGroupBulkDeleteClick', function () {
        $scope.Groups = [];
        GroupBulkDeleteClick();
    })

    function GroupBulkDeleteClick() {
        $scope.Groups = $scope.selected;
        var getGroup = GroupService.DeleteGroup($scope.Groups);

        getGroup.then(function (response) {
            if (response.data == "success") {
                $scope.appsVar.selectedRecordId = '';

                $scope.lastSelectedLibrary = '';
                getGroups();
                $scope.showAlertMessage("Selected group(s) deleted successfully.");
            } else {
                $scope.showAlertMessage('Failed to delete selected group(s).');
            }
        }, function () {
            $scope.showAlertMessage('Failed to delete selected group(s).');
        });

    }

    $scope.singleGroupDeleteConfirmMessageClick = function () {
        $scope.showSingleGroupDeleteConfirmMessage('Are you sure to delete ' + $scope.appsVar.selectedRecordId + '?');
    };

    $scope.showSingleGroupDeleteConfirmMessage = function (message) {
        $("#singlegroupconfirm_popup").find('#singlegroupconfirmMsgText').text(message);
        $("#singlegroupconfirm_popup").modal();
    }

    $scope.validation = {
        showMessage: false
    }
    function showProgressDialog() {
        $mdDialog.show({
            parent: angular.element(document.body),
            template: '<md-dialog ng-cloak height="100%" style="min-width: 1px !important;"><md-dialog-content><div class="md-dialog-content-clearpadding">' +
              '<md-progress-circular md-mode="indeterminate"></md-progress-circular>' +
              '</div></md-dialog-content></md-dialog>',
            controller: DialogController
        });
    }

    $scope.PageEvents.Add = function (event) {
        $scope.PageEvents.UserAction = 'Add';
        $scope.GroupModel = groupFactory.groupInitialValues();
        $scope.ShowWarning = false;
        $scope.validation.showMessage = false;
        var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
        $mdDialog.show({
            // controller: UserController,
            controller: DialogController,
            scope: $scope, // use parent scope in template
            preserveScope: true, // do not forget this if use parent scope
            templateUrl: 'Views/AddGroup.html',
            parent: angular.element(document.body),
            targetEvent: event,
            clickOutsideToClose: true,
            fullscreen: useFullScreen,
            onComplete: function () {
                $("#GroupForm input[id=GroupName]").focus();
            }

        }).then(function (answer) {
            $scope.status = '';
        }, function () {
            $scope.status = '';
        });
        $scope.$watch(function () {
            return $mdMedia('xs') || $mdMedia('sm');
        }, function (wantsFullScreen) {
            $scope.customFullscreen = (wantsFullScreen === true);
        });
    };

    $scope.dialogPopup = {
        Header: '',
        Message: '',
        CallbackFunction: null,
        Show: function () {
            $('#popup-alert-dialog-bg').slideToggle();
        },
        OK: function () {
            $('#popup-alert-dialog-bg').slideToggle();
            $scope.dialogPopup.Header = '';
            $scope.dialogPopup.Message = '';

            if ($scope.dialogPopup.CallbackFunction) {
                $scope.dialogPopup.CallbackFunction();
                $scope.dialogPopup.CallbackFunction = null;
            }
        }
    }

    $scope.PageEvents.Save = function () {

        return $scope.addGroup();

    }

    var GroupDeleteFunction = function () {
        var selectedGroupList = $scope.selected;
        if (typeof selectedGroupList !== 'undefined' && selectedGroupList.length > 0) {

            var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
            var confirm = $mdDialog.confirm().title('Warning!').theme('confirm-dialog').textContent('Are you sure you want to delete the selected Group(s)?').ariaLabel('').ok('Yes').cancel('No');

            $mdDialog.show(confirm).then(function () {

                $mdDialog.show($mdDialog.alert().parent(angular.element(document.body)).clickOutsideToClose(true).title('').textContent('Are you sure you want to delete the selected Group(s)?').ariaLabel('').ok('OK')).then(function () {
                    $mdDialog.show($mdDialog.alert().parent(angular.element(document.body)).clickOutsideToClose(true).title('Warning!').textContent('Failed to delete selected Group(s).').ariaLabel('').ok('OK'));
                });
            });
        } else {
            $scope.mc.getlogDetails("Debug", "Select User to edit.");
            $mdDialog.show($mdDialog.alert().parent(angular.element(document.body)).clickOutsideToClose(true).title('Warning!').textContent('Select Group(s) to delete.').ariaLabel('').ok('OK'));

        }
    }

    $scope.PageEvents.CancelDialog = function () {
        $scope.GroupModel = groupFactory.groupInitialValues();
        $scope.showValidation = false;
        $scope.ShowWarning = false;
        $('#virtual_group').modal('hide');
    }

    function DialogController($scope, $mdDialog) {
        $scope.hide = function () {
            $mdDialog.hide();
        };
        $scope.cancel = function () {
            $mdDialog.cancel();
        };
        $scope.answer = function () {
            $mdDialog.hide();
        };

        $scope.AddGroupSaveButtonChange = function ($event, type) {
            if ($event.keyCode === 9) {
                $event.preventDefault();
                if (type == "Add")
                    $("#GroupForm input[id=GroupName]").focus();
                else if (type == "Edit") {
                    $("#GroupForm input[id=GroupFullName]").focus();
                    $("#GroupForm input[id=GroupFullName]").select();
                } else if (type == "Copy") {
                    $("#CopyGroupForm input[id=GroupName]").focus();
                } else if (type == "ViewGroup") {
                    $("#viewGroupDetailForm input[id=UserID]").focus();
                    $("#viewGroupDetailForm input[id=UserID]").select();
                } else if (type == "ReAssign") {
                    $("#ReassignGroupSecurityForm input[id=GroupName]").focus();
                }
            }
            return false;
        }

        $scope.UserGroupSearchTextChange = CustomUserGroupSearchTextChange;

        function CustomUserGroupSearchTextChange($event) {
            if ($event.keyCode === 13) {
                $event.preventDefault();
            }
        }
    }

    $scope.$on('$destroy', function () {
        $scope.PageEvents.Add = 'undefined';
        $scope.PageEvents.Edit = 'undefined';
        $scope.PageEvents.Save = 'undefined';
        $scope.PageEvents.Delete = 'undefined';
        $scope.PageEvents.CancelDialog = 'undefined';
        $scope.PageEvents.ShowSubclassList = 'undefined';
        $scope.PageEvents.AddRole = 'undefined';
        $scope.PageEvents.ResetPasswordclicked = 'undefined';
        $scope.PageEvents.Enable = 'undefined';
        $scope.PageEvents.Disable = 'undefined';
        $scope.PageEvents.ViewAssignUser = 'undefined';
        $scope.PageEvents.AssignUser = 'undefined';
        $scope.PageEvents.AssignGroup = 'undefined';
    });

    var AssignUserFunction = function () {


        var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
        $mdDialog.show({
            controller: AssignGroupDialogController,
            preserveScope: false,
            templateUrl: 'Views/AddRemoveUsers.html',
            parent: angular.element(document.body),
            clickOutsideToClose: true,
            fullscreen: useFullScreen,
            bindToController: true,
            escapeToClose: false,
            locals: {
                parentScope: $scope
            },
            onComplete: function () {
                $("#AddRemoveUsersForm input[id=searchUser]").focus();
            }
        });
        $scope.$watch(function () {
            return $mdMedia('xs') || $mdMedia('sm');
        }, function (wantsFullScreen) {
            $scope.customFullscreen = (wantsFullScreen === true);
        });

    }

    $scope.CopyGroupModel = {
        FromGroupId: '',
        ToGroupModel: groupFactory.groupInitialValues(),
        IsShowErrorMsg: false,
        IsPosting: false,
        IsShowSuccessMsg: false,
        ErrorMessage: '',

        showDialog: function (fromGroupName) {
            var apiUrl = groupFactory.getAPIUrl('VIEWGROUPDETAILS', { GroupName: fromGroupName }, null, $scope.vm.selectedLibrary);

            $scope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(apiUrl));
            var readGroup = GroupService.getGroupDetails(apiUrl, $scope.mc.loginModel.AuthKey);
            readGroup.then(function (response) {
                if (response && response.data && response.data.data) {
                    $scope.mc.getlogDetails("Info", 'Successfully retrived group from the URL:' + JSON.stringify(apiUrl));

                    var tempModel = groupFactory.getGroupUI(response.data.data);
                    $scope.CopyGroupModel.ToGroupModel.GroupFullName = tempModel.GroupFullName;
                    $scope.CopyGroupModel.ToGroupModel.GroupName = '';// tempModel.GroupName;
                    $scope.CopyGroupModel.ToGroupModel.GroupIsExternal = tempModel.GroupIsExternal;
                    $scope.CopyGroupModel.ToGroupModel.GroupEnabled = tempModel.GroupEnabled;
                    $scope.CopyGroupModel.ToGroupModel.GroupNOS = tempModel.GroupNOS;
                    $scope.CopyGroupModel.ToGroupModel.GroupNum = tempModel.GroupNum;

                    $scope.CopyGroupModel.FromGroupId = tempModel.GroupName;
                    tempModel = null;

                    var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;

                    var dialogObject = {
                        controller: DialogController,
                        scope: $scope,
                        preserveScope: true,
                        templateUrl: 'Views/CopyGroup.html',
                        parent: angular.element(document.body),
                        targetEvent: null,
                        clickOutsideToClose: true,
                        fullscreen: useFullScreen,
                        onComplete: function () {
                            $("#CopyGroupForm input[id=GroupName]").focus();
                        }
                    };
                    $mdDialog.show(dialogObject).then(function (answer) {
                        $scope.status = '';
                    }, function () {
                        $scope.status = '';
                    });
                    $scope.$watch(function () {
                        return $mdMedia('xs') || $mdMedia('sm');
                    }, function (wantsFullScreen) {
                        $scope.customFullscreen = (wantsFullScreen === true);
                    });
                } else {
                    $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response) + 'Method:GET;URL:' + JSON.stringify(apiUrl));
                    $mdDialog.show($mdDialog.alert().parent(angular.element(document.body)).clickOutsideToClose(true).title('Warning!').textContent('Due to some unknown errors we are not getting the groupdetails.').ariaLabel('').ok('OK'));
                }
            }, function (response) {
                $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response) + 'Method:GET;URL:' + JSON.stringify(apiUrl));
                $mdDialog.show($mdDialog.alert().parent(angular.element(document.body)).clickOutsideToClose(true).title('Warning!').textContent('Due to some unknown errors we are not getting the groupdetails.').ariaLabel('').ok('OK'));

            });
        },

        closeDialog: function () {
            $mdDialog.cancel();
            $scope.CopyGroupModel.ToGroupModel = groupFactory.groupInitialValues();
            $scope.CopyGroupModel.IsShowErrorMsg = false;
            $scope.CopyGroupModel.IsPosting = false;
            $scope.CopyGroupModel.IsShowSuccessMsg = false;
            $scope.CopyGroupModel.ErrorMessage = '';
            $scope.CopyGroupModel.FromGroupId = '';
        },

        copy: function () {
            $scope.CopyGroupModel.ErrorMessage = '';
            $scope.CopyGroupModel.IsShowErrorMsg = false;

            if ($scope.CopyGroupModel.ToGroupModel.GroupName.trim().length == 0) {
                // $scope.CopyGroupModel.IsShowErrorMsg = true;
                return;
            }

            $scope.CopyGroupModel.IsPosting = true;
            var reqBody = groupFactory.getGroupPostModel($scope.CopyGroupModel.ToGroupModel, $scope.vm.selectedLibrary);
            var PostUrl = groupFactory.getAPIUrl('POSTGROUPS', null);
            $scope.mc.getlogDetails("Debug", 'URL:' + JSON.stringify(PostUrl) + ",Body" + JSON.stringify(reqBody));

            var addGroup = GroupService.addGroups(reqBody, PostUrl, $scope.mc.loginModel.AuthKey);
            addGroup.then(function (response) {
                if (response && response.data && response.data[CONST_GROUPS.GroupNumResponse]) {
                    if (response.data[CONST_GROUPS.GroupNumResponse] > 0) {
                        $scope.mc.getlogDetails("Info", "Response:" + response.data[CONST_GROUPS.GroupNumResponse]);

                        var apiUrl = groupFactory.getAPIUrl('COPYGROUPS', null, $scope.CopyGroupModel.ToGroupModel.GroupName, null);
                        $scope.mc.getlogDetails("Debug", 'Requested Api Url:' + JSON.stringify(apiUrl));
                        var obj = {};
                        obj.database = $scope.vm.selectedLibrary;
                        obj.data_type = "groups";
                        obj.data = [];
                        obj.data.push($scope.CopyGroupModel.FromGroupId);
                        var copyGroups = GroupService.copyGroup(obj, apiUrl, $scope.mc.loginModel.AuthKey);
                        copyGroups.then(function (response1) {
                            if (response1) {
                                //  $scope.mc.setSecurityLogDetails("Info", 'Response:Group' + $scope.CopyGroupModel.ToGroupModel.GroupName + ' Copied successfully');
                                $scope.mc.setSecurityLogDetails("Info", 'Success', $scope.CopyGroupModel.FromGroupId, ' Group Clone', ' New Group=' + $scope.CopyGroupModel.ToGroupModel.GroupName);

                                $scope.CopyGroupModel.IsShowSuccessMsg = true;
                                $scope.dialogPopup.CallbackFunction = function () {
                                    $mdDialog.hide();
                                }
                                $scope.dialogPopup.Header = 'Success';
                                $scope.dialogPopup.Message = 'Group copied successfully.';
                                $scope.dialogPopup.Show();
                                $timeout(function () {
                                    Initalize();
                                    $scope.dialogPopup.OK();

                                }, 2000);
                                $scope.CopyGroupModel.IsPosting = false;
                            }

                        }, function (response) {

                            $scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.CopyGroupModel.FromGroupId, ' Group Clone', ' New Group=' + $scope.CopyGroupModel.ToGroupModel.GroupName);
                            $scope.CopyGroupModel.IsPosting = false;
                            if (response && response.data && response.data.details && response.data.details.message) {
                                $scope.ErrorMessage = response.data.details.message;

                            } else {
                                $scope.IsShowErrorMsg = true;
                                $scope.ErrorMessage = "Group was created but the members could not be added or was partially added.";

                            }
                        });
                    }
                } else {
                    //$scope.mc.setSecurityLogDetails("Error", 'Method:POST;URL:' + JSON.stringify(PostUrl) + ",Body:" + JSON.stringify(reqBody) + ",Response:" + JSON.stringify(response));
                    $scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.CopyGroupModel.FromGroupId, ' Group Clone', ' New Group=' + $scope.CopyGroupModel.ToGroupModel.GroupName);
                    $scope.CopyGroupModel.IsPosting = false;
                    $scope.ErrorMessage = "Copying group  failed due to unknown errors";
                    $scope.CopyGroupModel.IsShowErrorMsg = true;
                    $scope.CopyGroupModel.ErrorMessage = "Copying group failed due to unknown errors.";

                }
            }, function (response) {
                //  $scope.mc.setSecurityLogDetails("Error", 'Method:POST;URL:' + JSON.stringify(PostUrl) + ",Body:" + JSON.stringify(reqBody) + ",Response:" + JSON.stringify(response));
                $scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.CopyGroupModel.FromGroupId, ' Group Clone', ' New Group=' + $scope.CopyGroupModel.ToGroupModel.GroupName);

                $scope.CopyGroupModel.IsPosting = false;
                $scope.ErrorMessage = "Copying group failed due to unknown errors.";

            });
        }
    };
	
    $scope.ClearGroupClick = function () {
        $scope.UsersModel.SearchText = '';
        $scope.UsersModel.ViewAssignUserSearchText = '';
    }

    $scope.ReassignGroupSecurityObject = {
        IsPosting: false,
        IsShowErrorMsg: false,
        IsShowSuccessMsg: false,
        ErrorMessage: '',
        NewGroupId: '',
        SelectedGroupId: '',

        showDialog: function (fromGroupName) {
            $scope.ReassignGroupSecurityObject.SelectedGroupId = fromGroupName;
            $scope.ReassignGroupSecurityObject.NewGroupId = '';

            var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;

            var dialogObject = {
                controller: DialogController,
                scope: $scope,
                preserveScope: true,
                templateUrl: 'Views/ReassignGroupSecurity.html',
                parent: angular.element(document.body),
                targetEvent: null,
                clickOutsideToClose: true,
                fullscreen: useFullScreen,
                onComplete: function () {
                    $("#ReassignGroupSecurityForm input[id=GroupName]").focus();
                }
            };
            $mdDialog.show(dialogObject).then(function (answer) {
                $scope.status = '';
            }, function () {
                $scope.status = '';
            });
            $scope.$watch(function () {
                return $mdMedia('xs') || $mdMedia('sm');
            }, function (wantsFullScreen) {
                $scope.customFullscreen = (wantsFullScreen === true);
            });
        },

        closeDialog: function () {
            $mdDialog.cancel();
            $scope.ReassignGroupSecurityObject.SelectedGroupId = '';
            $scope.ReassignGroupSecurityObject.NewGroupId = '';
            $scope.ReassignGroupSecurityObject.IsShowErrorMsg = false;
            $scope.ReassignGroupSecurityObject.IsPosting = false;
            $scope.ReassignGroupSecurityObject.IsShowSuccessMsg = false;
            $scope.ReassignGroupSecurityObject.ErrorMessage = '';
            $scope.ReassignGroupSecurityObject.FromGroupId = '';
        },
        Reassign: function () {
            if ($scope.ReassignGroupSecurityObject.NewGroupId.trim().length == 0) {
                return;
            }

            $scope.ReassignGroupSecurityObject.SelectedGroupId.IsPosting = true;
            $scope.ReassignGroupSecurityObject.IsShowErrorMsg = true;
            $scope.ReassignGroupSecurityObject.ErrorMessage = "Group Security  reassigning Failed"

        }
    };

    $scope.selected = [];

    $scope.query = {
        order: 'name',
        limit: requestModel.pageLength,
        page: requestModel.pagenumber,
        totalCount: 0
    };
    $scope.deSelect = function (item) {
        setContextMenuObject();
    };

    $scope.onSelect = function (item) {
        setContextMenuObject();
    };

    $scope.UserTablePagination = {
        order: 'UserID',
        limit: gurequestModel.pageLength,
        page: gurequestModel.pagenumber,
        totalCount: 0
    };

    $scope.onTableFilter = function (value, key, isInstantFilter, disablePerformFilter) {
        if (requestModel.filters.length > 0) {
            requestModel.filters = jQuery.grep(requestModel.filters, function (filterItem) {
                return filterItem.FilterKey !== key;
            });
        }

        var filterValueList = [];
        filterValueList[0] = value;

        var filterItem = {
            'FilterKey': key,
            'FilterValues': filterValueList
        };
        requestModel.filters.push(filterItem);

        requestModel.pagenumber = 1;
        $scope.query.page = 1;
        $scope.query.totalCount = 0;

        if (FilterSearchTimeout)
            $timeout.cancel(FilterSearchTimeout);

        if (!disablePerformFilter) {
            if (isInstantFilter) {
                // $scope.selected = [];
                $scope.GroupDetails = [];
                getGroups();
            } else {
                FilterSearchTimeout = $timeout(function () {
                    // $scope.selected = [];
                    $scope.GroupDetails = [];
                    getGroups();
                }, 2000);
            }
        }
        ;
    };
    // properties Page variables ///
    $scope.ViewGroupModel = groupFactory.groupInitialValues();
    $scope.scrollTop = 0;
    var totalMembersCount = 0;

    $scope.viewSelectedMembersOnlyLabel = 'View selected';
    $scope.selectedMembers = [];

    $scope.groupMembers = [];
    var tempMembersSelected = [];
    var appendMembers = [];
    var groupMembersReqModel = homeFactory.requestModelInstance();
    $scope.groupMembersList = {
        SearchText: '',
        SearchClick: MembersSearchClick,
        ClearSearchClick: MembersClearSearchClick
    };
    $scope.newMembers = [];
    $scope.removedMembers = [];
    var newMembersBaseTemp = [];
    var removedMembersBaseTemp = [];
    var GroupIndex = -1;
    var groupMembersSearchTimeOut = null;
    var isgroupMembersSearchTextDirty = false;
    var isgroupMembersInstantSearch = false;

    $scope.groupMembersQuery = {
        order: 'name',
        limit: groupMembersReqModel.pageLength,
        page: groupMembersReqModel.pagenumber,
        totalCount: 0
    };

    $scope.PageEvents.ViewSelected = function (selectedRow, $event) {
        if (!$event.ctrlKey) {
            $scope.selectedMembers = [];
            tempMembersSelected = [];
            appendMembers = [];
            $scope.scrollTop = $(window).scrollTop();
            $scope.ViewGroupModel = groupFactory.groupInitialValues();
            $scope.GroupModel = groupFactory.groupInitialValues();
            $scope.groupMembersList.SearchText = '';
            groupMembersReqModel = homeFactory.requestModelInstance();
            totalMembersCount = 0;
            $scope.groupMembers = [];
            newMembersBaseTemp = [];
            removedMembersBaseTemp = [];
            $scope.newMembers = [];
            $scope.removedMembers = [];
			
			$rootScope.checkReadyToChangeState = function () {
                return $q(function (resolve, reject) {
                    if (!isGroupEdited()) {
                        resolve({ Status: 0 });
                        return;
                    }
                    var confirm = $mdDialog.confirm()
                            .title('Warning!')
                            .theme('confirm-dialog')
                            .textContent('Do you want to save the changes?')
                            .ariaLabel('Warning!').ok('Yes').cancel('No');

                    $mdDialog.show(confirm).then(function () {
                        var userSavePromise = $scope.SaveGroupDetails();
                        userSavePromise.then(function (response) {
                            if (response && response.statusText == "OK") {
                                resolve({ Status: 0 });
                            }
                            else if ($scope.ErrorMessage.trim().length > 0) {
                                $mdDialog.show($mdDialog.alert()
                                            .parent(angular.element(document.body))
                                            .clickOutsideToClose(true)
                                            .title('Warning!')
                                            .textContent($scope.ErrorMessage)
                                            .ariaLabel('Warning!')
                                            .ok('OK')
                                        );
                                resolve({ Status: -1 });
                            }

                        });
                    }, function () {
                        resolve({ Status: 0 });
                    });
                });
            };
			
            GroupIndex = $scope.GroupDetails.indexOf(selectedRow);
            var apUrl = groupFactory.getAPIUrl('VIEWGROUPDETAILS', selectedRow, null, $scope.vm.selectedLibrary);
            $scope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(apUrl));
            var promise = GroupService.getGroupDetails(apUrl, $scope.mc.loginModel.AuthKey);
            promise.then(function (response) {
                if (response && response.data && response.data.data) {
                    $scope.ViewGroupModel = groupFactory.getGroupViewUI(response.data.data);
                    $scope.GroupModel = angular.copy($scope.ViewGroupModel);
                    getGroupMembers();

                    $('.view-details-tab-container md-tabs-content-wrapper').removeClass('fix-title');
                    $scope.showSelectedGroupDetails = true;

                    $timeout(function () {
                        $(window).scrollTop(0);
                    });
                }
                else {
                    //$scope.mc.getlogDetails("Error", 'Method:GET;URL:' + JSON.stringify(apUrl) + ",Response:" + JSON.stringify(response));
                    $scope.mc.getlogDetails("Error", 'Method:GET;URL:' + JSON.stringify(apUrl) + ",Response:" + JSON.stringify(response));

                    $mdDialog.show($mdDialog.alert().parent(angular.element(document.body)).clickOutsideToClose(true).title('Warning!').textContent('Failed to retrieve Group Details.').ariaLabel('Warning!').ok('OK'));
                }
            }, function (response) {

                $scope.mc.getlogDetails("Error", 'Method:GET;URL:' + JSON.stringify(apUrl) + ",Response:" + JSON.stringify(response));

                $mdDialog.show($mdDialog.alert().parent(angular.element(document.body)).clickOutsideToClose(true).title('Warning!').textContent('Failed to retrieve Group Details.').ariaLabel('Warning!').ok('OK'));

            });

            
        }
    };

    function getGroupMembers() {
        groupMembersReqModel.libraryName = $scope.vm.selectedLibrary;
        groupMembersReqModel.searchText = $scope.groupMembersList.SearchText;

        if ($scope.selectedMembers.length > 0 && groupMembersReqModel.pagenumber == 1) {
            angular.forEach($scope.selectedMembers, function (user) {
                tempMembersSelected.push(angular.copy(user));
            });
            $scope.selectedMembers = [];
        }

        if (newMembersBaseTemp.length > 0) {
            angular.forEach(newMembersBaseTemp, function (userItem) {
                var memberUIModel = angular.copy(userItem);
                $scope.groupMembers.push(memberUIModel);
                if (tempMembersSelected.length > 0) {
                    var existsInSelected = $filter('filter')(tempMembersSelected, {
                        UserId: memberUIModel.UserId
                    }, true);
                    if (existsInSelected.length > 0) {
                        var index = tempMembersSelected.indexOf(existsInSelected[0]);
                        if (index != -1) {
                            tempMembersSelected.splice(index, 1);
                            $scope.selectedMembers.push(memberUIModel);
                        }
                    }
                }

            });
        }
        newMembersBaseTemp = [];

        var apiUrl = groupFactory.getGroupUsersAPI(groupMembersReqModel, $scope.ViewGroupModel.GroupName);
        $scope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(apiUrl));

        var promise = GroupService.getGroups(apiUrl, $scope.mc.loginModel.AuthKey);
        promise.then(function (response) {
            if (response.status === 200) {
                if ($scope.groupMembersList.SearchText == '' || totalMembersCount == 0) {
                    totalMembersCount = response.data.total_count - $scope.removedMembers.length + $scope.newMembers.length;
                    if (totalMembersCount > 0) {
                        $scope.GroupMembersHeaderText = $scope.ViewGroupModel.GroupName + " have " + totalMembersCount + " members";
                    } else {
                        $scope.GroupMembersHeaderText = "Group Members"
                    }
                }
                $scope.groupMembersQuery.totalCount = response.data.total_count - $scope.removedMembers.length + $scope.newMembers;
                if (appendMembers.length > 0) {

                    $scope.groupMembers.splice($scope.groupMembers.length - appendMembers.length, appendMembers.length);
                    $scope.selectedMembers.splice($scope.selectedMembers.length - appendMembers.length, appendMembers.length);
                    tempMembersSelected = angular.copy(appendMembers);
                    appendMembers = [];

                }

                angular.forEach(response.data.data, function (userItem) {
                    var memberUIModel = userFactory.getUserUI(userItem);

                    $scope.groupMembers.push(memberUIModel);
                    if (tempMembersSelected.length > 0) {
                        var existsInSelected = $filter('filter')(tempMembersSelected, {
                            UserId: memberUIModel.UserId
                        }, true);
                        if (existsInSelected.length > 0) {
                            var index = tempMembersSelected.indexOf(existsInSelected[0]);
                            if (index != -1) {
                                tempMembersSelected.splice(index, 1);
                                $scope.selectedMembers.push(memberUIModel);
                            }
                        }
                    }

                });
                FilterRemovedUsers()
                if ($scope.groupMembersList.SearchText.length === 0) {
                    if (tempMembersSelected.length > 0) {

                        angular.forEach(tempMembersSelected, function (user) {
                            $scope.groupMembers.push(user);
                            $scope.selectedMembers.push(user);
                        });
                        appendMembers = angular.copy(tempMembersSelected);
                        tempMembersSelected = [];
                    }

                }

            } else {
                $scope.mc.getlogDetails("Error", 'Method:GET;URL:' + JSON.stringify(apiUrl) + ",Response:" + JSON.stringify(response));

            }
        }, function (response) {
            $scope.mc.getlogDetails("Error", 'Method:GET;URL:' + JSON.stringify(apiUrl) + ",Response:" + JSON.stringify(response));

        });
    }

    $scope.ShowOnlySelectedMembers = function () {
        $scope.viewSelectedMembersOnlyLabel = $scope.viewSelectedMembersOnlyLabel == 'View selected' ? 'Show all' : 'View selected';

    }

    $scope.filterSelectedMembers = function (selected, field) {
        return function (selectedUser) {
            if ($scope.viewSelectedMembersOnlyLabel == 'Show all') {
                if (selected.length == 0) {
                    $scope.viewSelectedMembersOnlyLabel = 'View selected';
                }
                var items = $filter('filter')(selected, selectedUser, true);
                if (items.length > 0)
                    return true;

                return false;
            } else {
                return true;
            }
        }
    };

    var view_scroll_fix_top = 482;
    $(window).on('scroll', function () {
        if ($scope.showSelectedGroupDetails) {
            view_scroll_fix_top = $('.view-details-tab-container md-tabs-content-wrapper').offset().top;
            if ($(window).scrollTop() >= view_scroll_fix_top - 64) {
                $('.view-details-tab-container md-tabs-content-wrapper').addClass('fix-title');
            } else {
                $('.view-details-tab-container md-tabs-content-wrapper').removeClass('fix-title');
            }
        }
    });
    function FilterRemovedUsers() {
        angular.forEach(removedMembersBaseTemp, function (user) {
            var existsInnewMembersTemp = $filter('filter')($scope.groupMembers, {
                UserId: user.UserId
            }, true);
            if (existsInnewMembersTemp.length > 0) {
                var index = $scope.groupMembers.indexOf(existsInnewMembersTemp[0]);
                if (index != -1) {
                    $scope.groupMembers.splice(index, 1);
                    $scope.groupMembersQuery.totalCount--;
                }
            }

        });
        removedMembersBaseTemp = [];
    }
    function MembersSearchClick() {
        if (groupMembersSearchTimeOut)
            $timeout.cancel(groupMembersSearchTimeOut);
        groupMembersReqModel = homeFactory.requestModelInstance();
        groupMembersReqModel.pagenumber = 1;
        $scope.groupMembers = [];
        if ($scope.groupMembersList.SearchText != "") {
            newMembersBaseTemp = $filter('filter')($scope.newMembers, {
                UserId: $scope.groupMembersList.SearchText
            }, false);
        } else {
            newMembersBaseTemp = angular.copy($scope.newMembers);
        }
        removedMembersBaseTemp = angular.copy($scope.removedMembers);
        getGroupMembers();
    }
    
    function MembersClearSearchClick() {
        isgroupMembersInstantSearch = true;
        $scope.groupMembersList.SearchText = '';
    }
    $scope.$watch(function () {
        return $scope.groupMembersList.SearchText;
    }, function (val) {
        if ($scope.groupMembersList.SearchText.length > 0) {
            isgroupMembersSearchTextDirty = true;
        }
        if (groupMembersSearchTimeOut)
            $timeout.cancel(groupMembersSearchTimeOut);

        if (isgroupMembersInstantSearch) {
            isgroupMembersInstantSearch = false;
            $scope.groupMembersList.SearchClick();
        } else {
            groupMembersSearchTimeOut = $timeout(function () {
                if (isgroupMembersSearchTextDirty) {
                    $scope.groupMembersList.SearchClick();
                }
            }, 2000);
        }
    }, true);

    $scope.RemoveSelectedUser = function () {
        var errorMsg = '';
        var deferredarray = [];

        var confirm = $mdDialog.confirm().title('Warning!').theme('confirm-dialog').textContent('Are you sure you want to remove the selected Member(s)?').ariaLabel('').ok('Yes').cancel('No');
        $mdDialog.show(confirm).then(function () {

            totalMembersCount = totalMembersCount + $scope.removedMembers.length - $scope.newMembers.length;

            angular.forEach($scope.selectedMembers, function (user) {

                removedMembersBaseTemp.push(angular.copy(user));
                if ($scope.newMembers.length > 0) {
                    var existsInSelected = $filter('filter')($scope.newMembers, {
                        UserId: user.UserId
                    }, true);
                    if (existsInSelected.length > 0) {
                        var index = $scope.newMembers.indexOf(existsInSelected[0]);
                        if (index != -1) {
                            $scope.newMembers.splice(index, 1);

                        } else {
                            $scope.removedMembers.push(angular.copy(user));

                        }
                    } else {
                        $scope.removedMembers.push(angular.copy(user));

                    }
                } else {
                    $scope.removedMembers.push(angular.copy(user));

                }

            });
            $scope.selectedMembers = [];
            FilterRemovedUsers();
            totalMembersCount = totalMembersCount - $scope.removedMembers.length + $scope.newMembers.length;
            $scope.GroupMembersHeaderText = $scope.ViewGroupModel.GroupName + " have " + totalMembersCount + " members";



        });

    };

    $scope.HideViewSelected = function () {
        if (!isGroupEdited()) {
            closeView();
            return;
        }
        var confirm = $mdDialog.confirm().title('Warning!').theme('confirm-dialog').textContent('Do you want to save the changes?').ariaLabel('Warning!').ok('Yes').cancel('No');

        $mdDialog.show(confirm).then(function () {
            var Promise = $scope.SaveGroupDetails();
            Promise.then(function (response) {
                if (response.statusText == "OK") {
                    closeView();
                }

            });
        }, function () {
            closeView();
        });
    };

    function isGroupEdited() {
        var result = angular.equals($scope.GroupModel, $scope.ViewGroupModel);
        if (!result) {
            return true;
        }

        if ($scope.newMembers.length > 0 || $scope.removedMembers.length > 0) {
            return true;
        }
        return false;
    }

    function closeView() {
        $scope.viewSelectedGroupUserSearch = '';
        $scope.groupUsersList = [];
        $scope.selected = [];
        $scope.selectedUsers = [];
        tempSelected = []
        $scope.ViewGroupModel = groupFactory.groupInitialValues();
        $scope.GroupModel = groupFactory.groupInitialValues();
        $scope.showSelectedGroupDetails = false;
        $timeout(function () {
            $(window).scrollTop($scope.scrollTop);
        });

    }

    $scope.PageEvents.ShowOnlySelected = function () {
        $scope.vm.viewSelectedOnlyLabel = $scope.vm.viewSelectedOnlyLabel == 'View selected' ? 'Show all' : 'View selected';
    }
    //
    function UpdateGroupList() {

        if (GroupIndex != -1) {

            $scope.GroupDetails[GroupIndex].GroupFullName = $scope.ViewGroupModel.GroupFullName;
            $scope.GroupDetails[GroupIndex].GroupIsExternal = $scope.ViewGroupModel.GroupIsExternal == "true" ? true : false;
            $scope.GroupDetails[GroupIndex].GroupEnabled = $scope.ViewGroupModel.GroupEnabled == "true" ? true : false;
            $scope.GroupDetails[GroupIndex].Domain = $scope.ViewGroupModel.Domain;

        }
        $scope.GroupModel = angular.copy($scope.ViewGroupModel);
    }
    $scope.SaveGroupDetails = function () {

        var defered = $q.defer();
        var deferedarry = [];
        $scope.ErrorMessage = '';
        $scope.IsPosting = true;
        var promise = updateGroupPrimaryInfo();
        promise.then(function (response) {
            if (response.statusText == "OK") {

                UpdateGroupList();
                defered.resolve(response);

            } else {
                $scope.ErrorMessage += response.statusText;
                defered.resolve(response);

            }
        }, function (response) {
            $scope.ErrorMessage += response.statusText;
            defered.resolve(response);

        });
        deferedarry.push(defered.promise);
        if ($scope.removedMembers.length > 0) {

            var removedefered = $q.defer();
            var removepromise = removeMembersFromGroup();
            removepromise.then(function (response) {

                if (response.statusText == "OK") {

                    removedefered.resolve(response);
                } else {
                    $scope.ErrorMessage += response.statusText;
                    removedefered.resolve(response);

                }
            }, function (response) {
                $scope.ErrorMessage += response.statusText;
                removedefered.resolve(response);

            });
            deferedarry.push(removedefered.promise);

        }
        if ($scope.newMembers.length > 0) {

            var adddefered = $q.defer();
            var addpromise = addNewMembersToGroup();
            addpromise.then(function (response) {

                if (response.statusText == "OK") {

                    adddefered.resolve(response);

                } else {
                    $scope.ErrorMessage += response.statusText;
                    adddefered.resolve(response);

                }
            }, function (response) {
                $scope.ErrorMessage += response.statusText;
                adddefered.resolve(response);

            });
            deferedarry.push(adddefered.promise);
        }
        var finaldefered = $q.defer();
        $q.all(deferedarry).then(function () {
            if ($scope.ErrorMessage === '') {

                finaldefered.resolve({
                    statusText: "OK"
                });
                $mdDialog.show($mdDialog.alert().parent(angular.element(document.body)).clickOutsideToClose(true).title('Success').textContent('Group details succesfully updated.').ariaLabel('Success').ok('OK'));
            } else {
                finaldefered.resolve({
                    statusText: "Failed"
                });
                $mdDialog.show($mdDialog.alert().parent(angular.element(document.body)).clickOutsideToClose(true).title('Warning!').textContent($scope.ErrorMessage).ariaLabel('Warning!').ok('OK'));

            }
            $scope.IsPosting = false;
        });

        return finaldefered.promise;

    };

    function removeMembersFromGroup() {
        var deferredarray = [];
        var statusText = 'OK';
        var fdeferred = $q.defer();
        var apiUrl = groupFactory.getAPIUrl('REMOVEUSERFROMGROUP', $scope.ViewGroupModel);
        $scope.mc.getlogDetails("Debug", 'Method:PUT;URL:' + JSON.stringify(apiUrl));
        
        angular.forEach($scope.removedMembers, function (user) {
            var deferred = $q.defer();
            var removeGroupUserModel = {
                "database": $scope.vm.selectedLibrary,
                "data_type": "users",
                "data": [],
                "action": "delete"
            };
            removeGroupUserModel.data.push(user.UserId);

            var promise = GroupService.RemoveUserFromGroup(apiUrl, removeGroupUserModel, $scope.mc.loginModel.AuthKey);
            promise.then(function (response) {
                deferred.resolve(response);
                if (response && response.status && response.status === 200) {
                    //  $scope.mc.setSecurityLogDetails("Info", "Response:" +  JSON.stringify(removeGroupUserModel) + "is removed from the group " + $scope.ViewGroupModel.GroupName);
                    $scope.mc.setSecurityLogDetails("Info", 'Success', $scope.ViewGroupModel.GroupName, ' Group Remove User', 'User=' + user.UserId);
                }
                else {
                    $scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.ViewGroupModel.GroupName, ' Group Remove User', 'User=' + user.UserId);
                    if (response && response.details && response.details.message.trim().length > 0) {
                        statusText = response.details.message + ":" + user.UserId;
                    }
                    else {
                        statusText = "Posting user failed due to unknown errors.";
                    }
                }

            }, function (response) {
                $scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.ViewGroupModel.GroupName, ' Group Rmove User', 'User=' + user.UserId);
                deferred.resolve(response);
            });
            deferredarray.push(deferred.promise);
        });
        $q.all(deferredarray).then(function () {
       	 fdeferred.resolve({statusText:statusText}); 
       	$scope.removedMembers=[];
       }, function () {
       	 fdeferred.resolve({statusText:statusText});  
       });
       return fdeferred.promise;
    }

    function addNewMembersToGroup() {
        var statusText = 'OK';
        var deferredarray = [];
        var fdeferred = $q.defer();

        var apiUrl = groupFactory.getAPIUrl('ADDUSERINGROUP', $scope.ViewGroupModel);
        $scope.mc.getlogDetails("Debug", 'Method:PUT;URL:' + JSON.stringify(apiUrl));
        //$scope.mc.setSecurityLogDetails("Info", 'Method:PUT;URL:' + JSON.stringify(apiUrl));

        angular.forEach($scope.newMembers, function (user) {
            var deferred = $q.defer();

            var groupUserModel = {
                "database": $scope.vm.selectedLibrary,
                "data_type": "users",
                "data": [],
                "action": "add"
            };
            groupUserModel.data.push(user.UserId);

            var promise = GroupService.AddUserToGroup(apiUrl, groupUserModel, $scope.mc.loginModel.AuthKey);
            promise.then(function (response) {
                deferred.resolve(response);
                if (response && response.status && response.status === 200) {
                    // $scope.mc.setSecurityLogDetails("Info", "Response:"+ JSON.stringify(groupUserModel) + "is added to the group " + $scope.ViewGroupModel.GroupName);
                    $scope.mc.setSecurityLogDetails("Info", 'Success', $scope.ViewGroupModel.GroupName, ' Group Add User', user.UserId);
                }
                else {
                    //$scope.mc.getlogDetails("Error", "Response:" + JSON.stringify(response));
                    $scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.ViewGroupModel.GroupName, ' Group Add User', user.UserId);
                    if (response && response.details && response.details.message.trim().length > 0) {
                        statusText = response.details.message + ":" + user.UserId;
                    }
                    else {
                        statusText = "Posting user failed due to unknown errors.";
                    }
                }
            }, function (response) {
                deferred.resolve(response);
                $scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.ViewGroupModel.GroupName, ' Group Add User', user.UserId);
            });
            deferredarray.push(deferred.promise);
        });
        $q.all(deferredarray).then(function () {
        	$scope.newMembers=[];
        	 fdeferred.resolve({statusText:statusText});  
        }, function () {
        	 fdeferred.resolve({statusText:statusText});  
        });
        return fdeferred.promise;
    }

    function updateGroupPrimaryInfo() {

        var deferred = $q.defer();
        $scope.result = angular.equals($scope.GroupModel, $scope.ViewGroupModel);
        if (!$scope.result) {
            var groupModelPut = groupFactory.getGroupPutModel($scope.ViewGroupModel, $scope.vm.selectedLibrary);
            var apiUrl = groupFactory.getAPIUrl('PUTGROUPS', $scope.ViewGroupModel);

            $scope.mc.getlogDetails("Debug", 'Method:PUT;URL:' + JSON.stringify(apiUrl) + ';Body:' + JSON.stringify(groupModelPut));
            //$scope.mc.setSecurityLogDetails("Info", 'Method:PUT;URL:' + JSON.stringify(apiUrl) + ';Body:' + JSON.stringify(groupModelPut));

            var UpdateData = GroupService.EditGroup(groupModelPut, apiUrl, $scope.mc.loginModel.AuthKey);
            UpdateData.then(function (response) {
                if (response.statusText == 'OK') {
                    $scope.mc.setSecurityLogDetails("Info", 'Success', $scope.ViewGroupModel.GroupName, ' Group Update', JSON.stringify(groupModelPut));
                } else {
                    $scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.ViewGroupModel.GroupName, ' Group Update', JSON.stringify(groupModelPut));

                    if (response && response.data && response.data.details && response.data.details.message) {
                        $scope.ErrorMessage = response.data.details.message;
                    } else {
                        $scope.ErrorMessage = "Posting group failed due to unknown errors.";
                    }
                    $scope.ShowWarning = true;
                }
                $scope.posting = false;
                deferred.resolve(response);
            }, function (response) {
                $scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.ViewGroupModel.GroupName, ' Group Update', JSON.stringify(groupModelPut));
                $scope.ErrorMessage = "Posting group failed due to unknown errors.";
                if (response && response.data && response.data.details && response.data.details.message) {
                    deferred.resolve({
                        statusText: response.data.details.message
                    });
                } else {
                    deferred.resolve({
                        statusText: "Posting group failed due to unknown errors."
                    });
                }
            });

        } else {
            deferred.resolve({
                statusText: "OK"
            });
        }
        return deferred.promise;
    }

    $scope.groupMembersMenuList = [{
        Label: 'Remove From Members',
        Icon: 'icon-delete',
        onClick: $scope.ContextMenuFunctions.RemoveMembersInView,
        Enable: true,
        IconType: 'font-icon'
    }];

    function AssignGroupDialogController($scope, $mdDialog, parentScope) {
        $scope.hide = function () {
            $mdDialog.hide();
        };
        $scope.cancel = function () {
            $mdDialog.cancel();
        };
        $scope.answer = function () {
            $mdDialog.hide();
        };

        $scope.SaveButtonChange = function ($event) {
            if ($event.keyCode === 9) {
                $event.preventDefault();
            }
            $("#PasswordField").focus();
            return false;
        };

        $scope.UserSearchTextChange = CustomUserSearchTextChange;

        function CustomUserSearchTextChange($event) {
            if ($event.keyCode === 13) {
                $event.preventDefault();
            }
        }

        $scope.NewUsersSearch = {
            SearchText: '',
            SerachClick: SerachClick,
            ClearSerach: ClearSerach
        }

        $scope.SelectedGroup = parentScope.ViewGroupModel;
        $scope.PageTitle = 'Add Users';
        $scope.ViewSelectedButtonText = 'View Selected';

        // /-------------------All Groups
        $scope.NonMembersList = [];
        $scope.SelectedNonMembers = [];
        $scope.NonMembersQuery = {
            totalCount: 0

        }
        var tempNonMembersSelected = [];
        var appendNonMembers = [];
        $scope.NewUsersSearch.SearchText = '';

        var NonMembersListReqModel = homeFactory.requestModelInstance();

        var removedMembersTemp = angular.copy(parentScope.removedMembers);
        var newMembersTemp = angular.copy(parentScope.newMembers);
        var isNewUsersSearchTextDirty = false;
        var NewUsersSearchTimeOut;
        var IsInstantSearch = false;

        function getAllNonMembers() {
            return $q(function (resolve, reject) {

                NonMembersListReqModel.libraryName = parentScope.vm.selectedLibrary;
                NonMembersListReqModel.searchText = $scope.NewUsersSearch.SearchText;

                if ($scope.SelectedNonMembers.length > 0 && NonMembersListReqModel.pagenumber == 1) {
                    angular.forEach($scope.SelectedNonMembers, function (user) {
                        tempNonMembersSelected.push(angular.copy(user));
                    });
                    $scope.SelectedNonMembers = [];
                }
                if (removedMembersTemp.length > 0) {
                    angular.forEach(removedMembersTemp, function (userItem) {
                        memberUIModel = angular.copy(userItem);
                        $scope.NonMembersList.push(memberUIModel);
                        if (tempNonMembersSelected.length > 0) {
                            var existsInSelected = $filter('filter')(tempNonMembersSelected, {
                                UserId: memberUIModel.UserId
                            }, true);
                            if (existsInSelected.length > 0) {
                                var index = tempNonMembersSelected.indexOf(existsInSelected[0]);
                                if (index != -1) {
                                    tempNonMembersSelected.splice(index, 1);
                                    $scope.SelectedNonMembers.push(memberUIModel);
                                }
                            }
                        }

                    });
                }
                removedMembersTemp = [];

                var apiUrl = groupFactory.getGroupNonMemberAPI(NonMembersListReqModel, $scope.SelectedGroup.GroupName);
                parentScope.mc.getlogDetails("Debug", 'URL:' + JSON.stringify(apiUrl));

                var groupPromise = GroupService.GetGroupNonMembers(apiUrl, parentScope.mc.loginModel.AuthKey);
                groupPromise.then(function (response) {
                    if (response && response.status == 200) {
                        var UserList = []; // must remove after api Updates

                        $scope.NonMembersQuery.totalCount = response.data.total_count + parentScope.removedMembers.length - parentScope.newMembers.length;

                        if (appendNonMembers.length > 0) {

                            $scope.NonMembersList.splice($scope.NonMembersList.length - appendNonMembers.length, appendNonMembers.length);
                            $scope.SelectedNonMembers.splice($scope.SelectedNonMembers.length - appendNonMembers.length, appendNonMembers.length);
                            tempNonMembersSelected = angular.copy(appendNonMembers);
                            appendNonMembers = [];
                        }

                        angular.forEach(response.data.data, function (userItem) {

                            var addUser = true;
                            var memberUIModel = userFactory.getUserUI(userItem);
                            if (newMembersTemp.length > 0) {
                                var existsInnewMembersTemp = $filter('filter')(newMembersTemp, {
                                    UserId: memberUIModel.UserId
                                }, true);
                                if (existsInnewMembersTemp.length > 0) {
                                    var index = newMembersTemp.indexOf(existsInnewMembersTemp[0]);
                                    if (index != -1) {
                                        newMembersTemp.splice(index, 1);
                                        addUser = false;
                                    }
                                }
                            }
                            // must remove after
                            // new APi
                            var existsInRemoved = $filter('filter')(parentScope.removedMembers, {
                                UserId: memberUIModel.UserId
                            }, true);
                            if (existsInRemoved.length > 0) {
                                addUser = false;
                            }
                            if (addUser) {
                                UserList.push(memberUIModel.UserId);
                                $scope.NonMembersList.push(memberUIModel);
                                if (tempNonMembersSelected.length > 0) {
                                    var existsInSelected = $filter('filter')(tempNonMembersSelected, {
                                        UserId: memberUIModel.UserId
                                    }, true);
                                    if (existsInSelected.length > 0) {
                                        var index = tempNonMembersSelected.indexOf(existsInSelected[0]);
                                        if (index != -1) {
                                            tempNonMembersSelected.splice(index, 1);
                                            $scope.SelectedNonMembers.push(memberUIModel);
                                        }
                                    }
                                }
                            }

                        });
                        //FilterMembers(angular.copy(UserList)); // must remove after api Updates
                        UserList = []; // must remove after api Updates

                        if ($scope.NewUsersSearch.SearchText.length === 0) {
                            if (tempNonMembersSelected.length > 0) {

                                angular.forEach(tempNonMembersSelected, function (user) {
                                    $scope.NonMembersList.push(user);
                                    $scope.SelectedNonMembers.push(user);
                                });
                                appendNonMembers = angular.copy(tempNonMembersSelected);
                                tempNonMembersSelected = [];
                            }

                        }

                    }
                    resolve({
                        Status: 1,
                        UserList: $scope.NonMembersList
                    });
                }, function (response) {
                    parentScope.mc.getlogDetails("Error", "Response:" + JSON.stringify(response) + 'URL:' + JSON.stringify(apiUrl));

                    resolve({
                        Status: -1,
                        UserList: null
                    });
                });
            });
        }

        // Must remove after the new API
        function FilterMembers(UsersList) {

            // totalGroupsCount = response.TotalGroupCount;
            // if (response.GroupList.length === 0) return;

            var apiUrl = userFactory.getAPIUrl('GETUSERSOFGROUPFROMUSER', UsersList, parentScope.ViewGroupModel.GroupName, NonMembersListReqModel.libraryName, '');
            parentScope.mc.getlogDetails("Debug", 'Requested Api Url:' + JSON.stringify(apiUrl));

            var Promise = UserService.getUsers(apiUrl, parentScope.mc.loginModel.AuthKey);
            Promise.then(function (response) {
				if (response && response.data && response.data.data) {
			        angular.forEach(response.data.data, function (user) {
			            var existsInnewMembersTemp = $filter('filter')($scope.NonMembersList, {
			                UserId: user.user_id_ex
			            }, true);
			            if (existsInnewMembersTemp.length > 0) {
			                var index = $scope.NonMembersList.indexOf(existsInnewMembersTemp[0]);
			                if (index != -1) {
			                    $scope.NonMembersList.splice(index, 1);
			                    $scope.NonMembersQuery.totalCount--;
			                }
			            }
			        });
			    }
            }, function (response) {

                parentScope.mc.getlogDetails("Error", 'Requested Api Url:' + JSON.stringify(apiUrl) + ' Response:' + JSON.stringify(response));


            });

        }

        $scope.ViewSelectedNonMembers = function () {
            $scope.ViewSelectedButtonText = $scope.ViewSelectedButtonText == 'View selected' ? 'Show all' : 'View selected';
        };

        $scope.ViewSelectedButtonText = 'View selected';
        $scope.filterSelectedNonMembers = function (selected, field) {
            return function (user) {
                if ($scope.ViewSelectedButtonText == 'Show all') {
                    if (selected.length == 0) {
                        $scope.ViewSelectedButtonText = 'View selected';
                    }
                    var items = $filter('filter')(selected, user, true);
                    if (items.length > 0)
                        return true;

                    return false;
                } else {
                    return true;
                }
            }
        };

        $scope.$watch(function () {
            return $scope.NewUsersSearch.SearchText;
        }, function (val) {
            if ($scope.NewUsersSearch.SearchText.length > 0) {
                isNewUsersSearchTextDirty = true;
            }
            if (NewUsersSearchTimeOut)
                $timeout.cancel(NewUsersSearchTimeOut);

            if (IsInstantSearch) {
                IsInstantSearch = false;
                $scope.NewUsersSearch.SerachClick();
            } else {
                NewUsersSearchTimeOut = $timeout(function () {
                    if (isNewUsersSearchTextDirty) {
                        $scope.NewUsersSearch.SerachClick();
                    }
                }, 2000);
            }
        }, true);

        function SerachClick() {
            if ($scope.NewUsersSearch.SearchText != "") {
                removedMembersTemp = $filter('filter')(parentScope.removedMembers, {
                    UserId: $scope.NewUsersSearch.SearchText
                }, false);
            } else {
                removedMembersTemp = angular.copy(parentScope.removedMembers);
            }

            newMembersTemp = angular.copy(parentScope.newMembers);

            $scope.NonMembersList = [];
            NonMembersListReqModel.pagenumber = 1;
            getAllNonMembers();
        }
        ;

        function ClearSerach() {
            IsInstantSearch = true;
            $scope.NewUsersSearch.SearchText = '';
        }
        ;

        $scope.onAllUserScroll = function () {
            if ($scope.NonMembersQuery.totalCount > $scope.NonMembersList.length) {
                NonMembersListReqModel.pagenumber++;

                getAllNonMembers();
            }
        };

        $scope.AddToMembers = function () {

            $scope.ErrorMessage = '';
            $scope.posting = true;
            $scope.ShowWarning = false;
            totalMembersCount = totalMembersCount + parentScope.removedMembers.length - parentScope.newMembers.length;

            angular.forEach($scope.SelectedNonMembers, function (useritem) {

                if (parentScope.removedMembers.length > 0) {
                    var existsInSelected = $filter('filter')(parentScope.removedMembers, {
                        UserId: useritem.UserId
                    }, true);
                    if (existsInSelected.length > 0) {
                        var index = parentScope.removedMembers.indexOf(existsInSelected[0]);
                        if (index != -1) {
                            parentScope.removedMembers.splice(index, 1);

                        } else {
                            parentScope.newMembers.push(angular.copy(useritem));

                        }
                    } else {
                        parentScope.newMembers.push(angular.copy(useritem));

                    }
                } else {
                    parentScope.newMembers.push(angular.copy(useritem));

                }
                parentScope.groupMembers.push(angular.copy(useritem));
            });

            totalMembersCount = totalMembersCount - parentScope.removedMembers.length + parentScope.newMembers.length;

            parentScope.GroupMembersHeaderText = parentScope.ViewGroupModel.GroupName + " have " + totalMembersCount + " members";

            $scope.dialogPopup.CallbackFunction = function () {
                $mdDialog.hide();
            }

            $timeout(function () {
                $scope.showValidation = false;
                $scope.ShowWarning = false;
                $scope.posting = false;
                $scope.dialogPopup.OK();
            }, 1500);

        };

        $scope.dialogPopup = {
            Header: '',
            Message: '',
            CallbackFunction: null,
            Show: function () {
                $('#popup-alert-dialog-bg').slideToggle();
            },
            OK: function () {
                $('#popup-alert-dialog-bg').slideToggle();
                $scope.dialogPopup.Header = '';
                $scope.dialogPopup.Message = '';

                if ($scope.dialogPopup.CallbackFunction) {
                    $scope.dialogPopup.CallbackFunction();
                    $scope.dialogPopup.CallbackFunction = null;
                }
            }
        };
        getAllNonMembers();
    }

}