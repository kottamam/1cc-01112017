﻿app.controller("RolesController", RolesController);
RolesController.$inject = ['$scope', '$rootScope', 'RolesService', '$filter', '$timeout', '$mdDialog', '$mdMedia',
						   'rolesFactory', 'homeFactory', 'UserService', 'userFactory', '$q'];

function RolesController($scope, $rootScope, RolesService, $filter, $timeout, $mdDialog, $mdMedia, rolesFactory,
		homeFactory, UserService, userFactory, $q) {

    var roleListRequestModel = homeFactory.requestModelInstance();

    $scope.FormTitle = 'Role';
    $scope.loading = false;
    $scope.lastSelectedLibrary = '';
    $scope.RoleModelList = [];
    $scope.UserCheckedFinal = [];
    $scope.selected = [];
    var FilterSearchTimeout;
    var selectedRoleIndex;
    $scope.RoleUserList = [];
    $scope.selectedMembers = [];
    $scope.searchRole = {
        SearchText: ''
    };

    $timeout(function () {
        $(window).scrollTop(0);
    });
    $scope.ContextMenuFunctions = {
        Delete: function () { deleteRole(); },
        CopyRole: function () {
            var selectedRoleList = $scope.selected;//= $filter('filter')($scope.RoleModelList, { Selected: true });
            if (selectedRoleList && selectedRoleList.length > 0) {
                $scope.CopyRoleObject.showDialog(selectedRoleList[0].RoleName);
            }
        },
        AssignUsers: function () { $scope.PageEvents.AddRole(); },
        RemoveUsersInView: function () { $scope.RemoveSelectedUser(); }
    };

    function setContextMenuObject() {
        $scope.menuList = [
						   /*{
						       Label: 'Delete',
						       Icon: 'icon-delete',
						       onClick: $scope.ContextMenuFunctions.Delete,
						       Enable: $scope.selected.length > 0,
						       IconType: 'font-icon'
						   },*/
						   {
						       Label: 'Copy',
						       Icon: 'icon-copy',
						       onClick: $scope.ContextMenuFunctions.CopyRole,
						       Enable: $scope.selected.length === 1,
						       IconType: 'font-icon'
						   }
        ];
    }

    $scope.filterSelected = function (selected, field) {
        return function (role) {
            if ($scope.viewSelectedOnlyLabel == 'Show all') {
                if (selected.length == 0) {
                    $scope.viewSelectedOnlyLabel = 'View selected';
                }
                var items = $filter('filter')(selected, role, true);
                if (items.length > 0)
                    return true;

                return false;
            } else {
                return true;
            }
        }
    };

    var view_scroll_fix_top = 359;
    $(window).on('scroll', function () {
        if ($scope.showSelectedRoleDetails) {
            view_scroll_fix_top = $('.view-details-tab-container md-tabs-content-wrapper').offset().top;
            console.log('Scoll pint is: ' + view_scroll_fix_top);
            if ($(window).scrollTop() >= view_scroll_fix_top - 64) {
                $('.view-details-tab-container md-tabs-content-wrapper').addClass('fix-title');
            } else {
                $('.view-details-tab-container md-tabs-content-wrapper').removeClass('fix-title');
            }
        }
    });

    $scope.$on('Window_Scrolled', function () {

        if ($scope.showSelectedRoleDetails) {
            if ($scope.groupMembersQuery.totalCount > $scope.RoleUserList.length) {
                roleUserListReqModel.pagenumber++;
                getRoleUserList();
            }
        } else {
            if ($scope.query.totalCount > $scope.RoleModelList.length) {
                roleListRequestModel.pagenumber++;
                getRoleList();
            }
        }


    });
    function showProgressDialog() {
        $mdDialog.show({
            parent: angular.element(document.body),
            template: '<md-dialog ng-cloak height="100%" style="min-width: 1px !important;"><md-dialog-content><div class="md-dialog-content-clearpadding">' +
              '<md-progress-circular md-mode="indeterminate"></md-progress-circular>' +
              '</div></md-dialog-content></md-dialog>',
            controller: DialogController
        });
    }

    function isValidFilterFind() {
        var filterKeyItem = null;
        var blnResult = false;

        for (var iCount = 0; iCount < roleListRequestModel.filters.length; iCount++) {
            filterKeyItem = roleListRequestModel.filters[iCount];
            if (filterKeyItem.FilterValues && filterKeyItem.FilterValues[0] && filterKeyItem.FilterValues[0].trim().length > 0) {
                blnResult = true;
                break;
            }
            filterKeyItem = null;
        }
        return blnResult;
    }

    function getRoleList() {
        $scope.query.totalCount = 0;

        if ($scope.vm.selectedApp.NoAppsPermission.trim().length > 0) return;
        if (!$scope.vm.selectedLibrary || $scope.vm.selectedLibrary.trim().length === 0) return;

        $scope.lastSelectedLibrary = $scope.vm.selectedLibrary;
        roleListRequestModel.libraryName = $scope.vm.selectedLibrary;
        roleListRequestModel.searchText = $scope.appsVar.SearchText;

        if (isSearch) {
            //$scope.showSearchProgress = true;
            showProgressDialog();
        }
        var searchAPIUrl = rolesFactory.searchAPIUrl(roleListRequestModel);
        $scope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(searchAPIUrl));
        var roleDbRequest = RolesService.getRoles(searchAPIUrl, $scope.mc.loginModel.AuthKey);

        roleDbRequest.then(function (response) {
            if (response && response.data && response.status === 200) {
                $scope.mc.getlogDetails("Debug", 'Response:Success');
                $scope.query.totalCount = response.data.total_count;

                var tempListFilter = [];
                var roleUIModel;
                var filterTempModel;

                if (lastAppendItemCount > 0) {
                    $scope.RoleModelList.splice($scope.RoleModelList.length - lastAppendItemCount, lastAppendItemCount);
                    $scope.selected.splice($scope.selected.length - lastAppendItemCount, lastAppendItemCount);
                }

                angular.forEach(response.data.data, function (roleItem) {
                    roleUIModel = rolesFactory.getUIModel(roleItem);
                    if (SelectedRoleNameListForFilter.length === 0) {
                        $scope.RoleModelList.push(roleUIModel);
                    }
                    else {
                        tempListFilter = $filter('filter')(SelectedRoleNameListForFilter, {
                            RoleName: roleUIModel.RoleName
                        }, true);
                        if (tempListFilter.length === 0) {
                            $scope.RoleModelList.push(roleUIModel);
                        }
                        else {
                            LastAddedSelectedItemRoleName = $.grep(LastAddedSelectedItemRoleName,
							   function (item, index) {
							       return item.RoleName != roleUIModel.RoleName;
							   });

                            tempListFilter[0].Description = roleUIModel.Description;
                            tempListFilter[0].Privileges = roleUIModel.Privileges;

                            filterTempModel = angular.copy(tempListFilter[0]);
                            $scope.RoleModelList.push(filterTempModel);
                            $scope.selected.push(filterTempModel);
                            filterTempModel = null;
                        }
                        tempListFilter = [];
                    }
                    roleUIModel = null;
                });

                $timeout(function () {
                    $('td').filter(function () {
                        if (!$(this).hasClass("md-checkbox-cell")) {
                            if ($(this).text().trim().length === 0) {

                                $(this).html('&nbsp;');
                            }
                        }

                    });
                });
                $scope.showSearchProgress = false;
                if (isSearch) $mdDialog.hide();
                lastAppendItemCount = 0;
                if ($scope.appsVar.SearchText.length === 0 && !isValidFilterFind()) {
                    angular.forEach(LastAddedSelectedItemRoleName, function (role) {
                        filterTempModel = angular.copy(role);
                        $scope.RoleModelList.push(filterTempModel);
                        $scope.selected.push(filterTempModel);
                        filterTempModel = null;
                        lastAppendItemCount += 1;
                    });
                }
            }
            else {
                $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
            }
        }, function (response) {
            $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
            if (response["data"]["details"]["message"]) {
                $scope.ErrorMessage = response["data"]["details"]["message"];
            }
            else {
                $scope.ErrorMessage = 'Failed to retrive Roles';
            }
            $mdDialog.show(
					$mdDialog.alert()
					.parent(angular.element(document.body))
					.clickOutsideToClose(true)
					.title('Warning!')
					.textContent($scope.ErrorMessage)
					.ariaLabel('Warning!')
					.ok('OK')
			);
            $scope.showSearchProgress = false;
            if (isSearch) $mdDialog.hide();
        });
    }



    var isSearch = false;

    $scope.$on('Search_Click', function (event, args) {
        $scope.selected = [];
        $scope.RoleModelList = [];
        isSearch = true;
        initializeRoleList();
    });
    RegisterInitializeTabContents();
    var destroybroadCast;
    $scope.$on('RegisterInitializeTabContents', function () {
        if (angular.isFunction(destroybroadCast))
            destroybroadCast();

        RegisterInitializeTabContents();
    });

    function RegisterInitializeTabContents() {
        var destroybroadCast = $scope.$on('InitializeTabContents', function () {
            if ($scope.vm.selectedApp.NoAppsPermission.trim().length > 0)
                return;
            if (!$scope.vm.selectedLibrary || $scope.vm.selectedLibrary.trim().length == 0)
                return;

            roleListRequestModel = homeFactory.requestModelInstance();

            $scope.selected = [];
            $scope.FormTitle = 'Role';
            $scope.loading = false;
            $scope.lastSelectedLibrary = '';
            $scope.RoleModelList = [];
            $scope.UserCheckedFinal = [];
            $scope.selected = [];
            $scope.RoleUserList = [];
            $scope.selectedMembers = [];
            FilterSearchTimeout = null;
            selectedRoleIndex = null;
            $scope.searchRole = {
                SearchText: ''
            };
            SelectedRoleNameListForFilter = [];
            LastAddedSelectedItemRoleName = [];
            lastAppendItemCount = 0;
            $scope.showSelectedRoleDetails = false;

            initializeRoleList();
            destroybroadCast();
        });
    }

    function initializeRoleList() {
        $scope.loading = true;
        $scope.RoleModelList = [];
        $scope.selected = [];

        roleListRequestModel.libraryName = $scope.vm.selectedLibrary;
        roleListRequestModel.searchText = $scope.appsVar.SearchText;
        roleListRequestModel.pagenumber = 1;
        roleListRequestModel.isTotal = true;

        getRoleList();
    }

    //Add_Edit_Role
    var RoleViewModel = null;
    $scope.RolesModel = null;

    $scope.PageEvents.BindLabel = function (data) {
        if ($scope.PageEvents.UserAction === 'Add') {
            return 'Add';
        } else {
            return 'Save';
        }
    };

    $scope.PageEvents.CancelDialog = function () {
        $mdDialog.cancel();

        $scope.PageEvents.UserAction = '';
        $scope.FormTitle = '';
        RoleViewModel = null;
        $scope.RolesModel = rolesFactory.rolesInitialValues();
        $scope.ShowMemberUserOnly = false;
        $scope.showValidation = false;
        $scope.ShowWarning = false;
        $scope.posting = false;
        $scope.PrivilageDetails = [];
    };

    $scope.PageEvents.Add = function () {

        RoleViewModel = null;
        $scope.RolesModel = rolesFactory.rolesInitialValues();
        $scope.showValidation = false;
        $scope.ShowWarning = false;
        $scope.posting = false;
        $scope.PageEvents.UserAction = 'Add';
        fillPrivilages();

        var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;

        var dialogObject = {
            controller: DialogController,
            scope: $scope,
            preserveScope: true,
            templateUrl: 'Views/RolesForm.html',
            parent: angular.element(document.body),
            targetEvent: null,
            clickOutsideToClose: true,
            fullscreen: useFullScreen,
            onComplete: function () {
                $("#roleAddEditForm input[id=roleName]").focus();
            }

        };
        $mdDialog.show(dialogObject)
		.then(function (answer) {
		    $scope.status = '';
		}, function () {
		    $scope.status = '';
		});
        $scope.$watch(function () {
            return $mdMedia('xs') || $mdMedia('sm');
        }, function (wantsFullScreen) {
            $scope.customFullscreen = (wantsFullScreen === true);
        });
    };


    function deleteRole() {

        var selectedRoleList = $scope.selected;//= $filter('filter')($scope.RoleModelList, { Selected: true });

        if (typeof selectedRoleList !== 'undefined' && selectedRoleList.length > 0) {
            var confirm = $mdDialog.confirm()
					.title('Warning!')
					.theme('confirm-dialog')
			.textContent('Are you sure you want to delete the selected role(s)?')
			.ariaLabel('')
			.ok('Yes')
			.cancel('No');
            $mdDialog.show(confirm).then(function () {
                $mdDialog.show(
						$mdDialog.alert()
						.parent(angular.element(document.body))
						.clickOutsideToClose(true)
						.title('Warning!')
						.textContent('Are you sure you want to delete the selected role(s)?')
						.ariaLabel('Warning!')
						.ok('OK')
				).then(function () {

				    $mdDialog.show(
							$mdDialog.alert()
							.parent(angular.element(document.body))
							.clickOutsideToClose(true)
							.title('Warning!')
							.textContent('Failed to delete selected role(s).')
							.ariaLabel('Warning!')
							.ok('OK')
					);
				});
            });
        }
        else {
            $mdDialog.show(
					$mdDialog.alert()
					.parent(angular.element(document.body))
					.clickOutsideToClose(true)
					.title('Warning!')
					.textContent('Please select role(s) to delete.')
					.ariaLabel('Warning!')
					.ok('OK')
			);
        }
    }

    function fillPrivilages() {
        $scope.PrivilageDetails = [
								   { value: 'CO', Text: 'Import / Create', Selected: false, TagValue: 1 },
								   { value: 'CO', Text: 'Checkout Documents', Selected: false, TagValue: 2 },
								   { value: 'CO', Text: 'Unlock Documents', Selected: false, TagValue: 4 },
								   { value: 'CO', Text: 'Delete', Selected: false, TagValue: 8 },
								   { value: 'CO', Text: 'Allow Full Text Search', Selected: false, TagValue: 2048 },
								   { value: 'CO', Text: 'Read Only', Selected: false, TagValue: 16 },
								   { value: 'FO', Text: 'Create Public Folder', Selected: false, TagValue: 32 },
								   { value: 'FO', Text: 'Create Public Searches', Selected: false, TagValue: 64 },
								   { value: 'AO', Text: 'User Work Site import', Selected: false, TagValue: 1 },
								   { value: 'AO', Text: 'User Work Site Monitor', Selected: false, TagValue: 2 },
								   { value: 'AO', Text: 'User Work Site Administration', Selected: false, TagValue: 4 },
								   { value: 'AO', Text: 'View Documents', Selected: false, TagValue: 8 },
								   { value: 'WO', Text: 'Search Via Web', Selected: false, TagValue: 2 },
								   { value: 'WO', Text: 'Create WorkSpaces', Selected: false, TagValue: 4 },
								   { value: 'WO', Text: 'Create Public WorkSpaces', Selected: false, TagValue: 8 },
								   { value: 'WO', Text: 'Create system WorkSpaces', Selected: false, TagValue: 64 },
								   { value: 'WO', Text: 'Delete WorkSpaces', Selected: false, TagValue: 128 },
        ];

        var searchListTemp;
        if ($scope.PageEvents.UserAction === 'Add') {
            angular.forEach($scope.PrivilageDetails, function (PrivilegeType) {
                PrivilegeType.Selected = !(PrivilegeType.value === 'CO' && PrivilegeType.TagValue === 16);
            });
        }
        else if ($scope.PageEvents.UserAction === 'Edit' && privilegeRoleViewModel !== null) {

            if (privilegeRoleViewModel.ContentAndFolderOperationList) {
                angular.forEach(privilegeRoleViewModel.ContentAndFolderOperationList, function (tempItem) {

                    searchListTemp = $filter('filter')($scope.PrivilageDetails, { value: 'CO', TagValue: tempItem });
                    if (searchListTemp && searchListTemp.length > 0) {
                        searchListTemp[0].Selected = true;
                        searchListTemp = null;
                    }
                    else {
                        searchListTemp = $filter('filter')($scope.PrivilageDetails, { value: 'FO', TagValue: tempItem });
                        if (searchListTemp && searchListTemp.length > 0) {
                            searchListTemp[0].Selected = true;
                            searchListTemp = null;
                        }
                    }
                });
            }

            if (privilegeRoleViewModel.AdministrativeOperationList) {
                angular.forEach(privilegeRoleViewModel.AdministrativeOperationList, function (tempItem) {
                    searchListTemp = $filter('filter')($scope.PrivilageDetails, { value: 'AO', TagValue: tempItem });
                    if (searchListTemp && searchListTemp.length > 0) {
                        searchListTemp[0].Selected = true;
                        searchListTemp = null;
                    }
                });
            }
            if (privilegeRoleViewModel.WebOperationsList) {
                angular.forEach(privilegeRoleViewModel.WebOperationsList, function (tempItem) {
                    searchListTemp = $filter('filter')($scope.PrivilageDetails, { value: 'WO', TagValue: tempItem });
                    if (searchListTemp && searchListTemp.length > 0) {
                        searchListTemp[0].Selected = true;
                        searchListTemp = null;
                    }
                });
            }
        }
    }

    $scope.dialogPopup = {
        Header: '',
        Message: '',
        CallbackFunction: null,
        Show: function () {
            $('#popup-alert-dialog-bg').slideToggle();
        },
        OK: function () {
            $('#popup-alert-dialog-bg').slideToggle();
            $scope.dialogPopup.Header = '';
            $scope.dialogPopup.Message = '';

            if ($scope.dialogPopup.CallbackFunction) {
                $scope.dialogPopup.CallbackFunction();
                $scope.dialogPopup.CallbackFunction = null;
            }
        }
    }


    function DialogController($scope, $mdDialog) {
        $scope.hide = function () {
            $mdDialog.hide();
        };
        $scope.cancel = function () {
            $mdDialog.cancel();
        };
        $scope.answer = function () {
            $scope.AddSelectedUser();
            $mdDialog.hide();
        };

        $scope.RoleButtonChange = function ($event, type) {
            if ($event.keyCode === 9) {
                $event.preventDefault();
                if (type == "Add")
                    $("#roleAddEditForm input[id=roleName]").focus();
                else if (type == "Edit") {
                    $("#roleAddEditForm input[id=roleDescription]").focus();
                    $("#roleAddEditForm input[id=roleDescription]").select();
                }
                else if (type == "Copy") {
                    $("#CopyRoleForm input[id=RoleName]").focus();
                }
            }
            return false;
        }

        $scope.UserGroupSearchTextChange = CustomUserGroupSearchTextChange;

        function CustomUserGroupSearchTextChange($event) {
            if ($event.keyCode === 13) {
                $event.preventDefault();
            }
        }
    }



    $scope.$on('$destroy', function () {
        $scope.PageEvents.Add = 'undefined';
        $scope.PageEvents.Edit = 'undefined';
        $scope.PageEvents.Save = 'undefined';
        $scope.PageEvents.Delete = 'undefined';
        $scope.PageEvents.CancelDialog = 'undefined';
        $scope.PageEvents.ShowSubclassList = 'undefined';
        $scope.PageEvents.AddRole = 'undefined';
        $scope.PageEvents.ResetPasswordclicked = 'undefined';

    });


    $scope.CopyRoleObject = {
        FromRoleName: '',
        ToRoleName: '',
        IsShowErrorMsg: false,
        IsPosting: false,
        IsShowSuccessMsg: false,
        ErrorMessage: '',

        showDialog: function (fromRoleName) {

            $scope.CopyRoleObject.FromRoleName = fromRoleName;
            $scope.CopyRoleObject.ToRoleName = '';

            var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;

            var dialogObject = {
                controller: DialogController,
                scope: $scope,
                preserveScope: true,
                templateUrl: 'Views/CopyRole.html',
                parent: angular.element(document.body),
                targetEvent: null,
                clickOutsideToClose: true,
                fullscreen: useFullScreen,
                onComplete: function () {
                    $("#CopyRoleForm input[id=RoleName]").focus();
                }
            };
            $mdDialog.show(dialogObject)
			.then(function (answer) {
			    $scope.status = '';
			}, function () {
			    $scope.status = '';
			});
            $scope.$watch(function () {
                return $mdMedia('xs') || $mdMedia('sm');
            }, function (wantsFullScreen) {
                $scope.customFullscreen = (wantsFullScreen === true);
            });
        },

        closeDialog: function () {
            $mdDialog.cancel();
            $scope.CopyRoleObject.FromRoleName = '';
            $scope.CopyRoleObject.IsShowErrorMsg = false;
            $scope.CopyRoleObject.IsPosting = false;
            $scope.CopyRoleObject.IsShowSuccessMsg = false;
            $scope.CopyRoleObject.ErrorMessage = '';
            $scope.CopyRoleObject.ToRoleName = '';
        },

        copy: function () {
            $scope.CopyRoleObject.ErrorMessage = '';
            $scope.CopyRoleObject.IsShowErrorMsg = false;

            if ($scope.CopyRoleObject.ToRoleName.trim().length === 0) {
                return;
            }
            var apiUrl = rolesFactory.getSingleRoleAPIUrl($scope.vm.selectedLibrary, $scope.CopyRoleObject.FromRoleName);
            $scope.mc.getlogDetails("Debug", 'Method : GET, Requested Api Url :' + JSON.stringify(apiUrl));
            var roleModelService = RolesService.getRole(apiUrl, $scope.mc.loginModel.AuthKey);

            roleModelService.then(function (response) {
                RoleViewModel = null;

                if (response.status === 200 && response.data) {
                    RoleViewModel = rolesFactory.getUIModelWithAllInfo(response.data.data[0]);
                    RoleViewModel.RoleName = $scope.CopyRoleObject.ToRoleName;
                    RoleViewModel.Description = '';

                    var apiModel = rolesFactory.getAPIModel(RoleViewModel, $scope.vm.selectedLibrary);
                    apiUrl = rolesFactory.postAPIUrl();
                    $scope.mc.getlogDetails("Debug", 'Method : POST, Requested Api Url :' + JSON.stringify(apiUrl) + 'Parameters are :' + JSON.stringify(apiModel));
                    var roleSave = RolesService.addRoles(apiModel, apiUrl, $scope.mc.loginModel.AuthKey);
                    roleSave.then(function (response) {
                        if (response && response.data && response.status === 201) {
                            $scope.mc.setSecurityLogDetails("Info", 'Success', $scope.CopyRoleObject.FromRoleName, ' Role Copy', 'New Role= ' + RoleViewModel.RoleName);
                            $mdDialog.cancel();
                            initializeRoleList();
                        }
                        else {
                            $scope.CopyRoleObject.ErrorMessage = 'Role copied failed.';
                            $scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.CopyRoleObject.FromRoleName, ' Role Copy', 'New Role= ' + RoleViewModel.RoleName);
                            $scope.CopyRoleObject.IsShowErrorMsg = true;
                        }
                    }, function (response) {
                        $scope.CopyRoleObject.ErrorMessage = 'Role copied failed.';
                        $scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.CopyRoleObject.FromRoleName, ' Role Copy', 'New Role= ' + RoleViewModel.RoleName);
                        $scope.CopyRoleObject.IsShowSuccessMsg = true;
                    });
                }
            }, function () {
                $scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.CopyRoleObject.FromRoleName, ' Role Copy', 'New Role= ' + RoleViewModel.RoleName);
                $scope.mc.setSecurityLogDetails("Error", "Response:" + JSON.stringify(response));
                $scope.CopyRoleObject.IsShowSuccessMsg = true;
            });
        }
    };

    $scope.PageEvents.AddRole = function () {





        var useFullScreen = ($mdMedia('sm') || $mdMedia('xs'))
                && $scope.customFullscreen;
        $mdDialog.show({
            controller: AssignRoleUserDialogController,
            preserveScope: false,
            templateUrl: 'Views/AddRemoveRole.html',
            parent: angular.element(document.body),
            clickOutsideToClose: true,
            fullscreen: useFullScreen,
            escapeToClose: false,
            //bindToController: true,
            locals: {
                parentScope: $scope
            },
            onComplete: function () {
                $("#AddRemoveUserToRoleForm input[id=searchUser]").focus();
            }
        });
        $scope.$watch(function () {
            return $mdMedia('xs') || $mdMedia('sm');
        }, function (wantsFullScreen) {
            $scope.customFullscreen = (wantsFullScreen === true);
        });
        return true;

    }

    $scope.isAlreadyAvilable = function (userId) {
        var resultText = false;
        var filterUserList = $filter('filter')($scope.UserInRoleList, { UserId: userId }, true);
        if (typeof filterUserList !== 'undefined' && filterUserList.length > 0) {
            resultText = true;
            var selectedUserList = $filter('filter')($scope.UserList, { UserId: userId }, true);
            angular.forEach(selectedUserList, function (tempItemModel) {
                tempItemModel.Checked = true;
            });
        }


        return resultText;
    };


    $scope.query = {
        order: 'name',
        limit: roleListRequestModel.pageLength,
        page: roleListRequestModel.pagenumber,
        totalCount: 0
    };



    var SelectedRoleNameListForFilter = [];
    var LastAddedSelectedItemRoleName = [];
    var lastAppendItemCount = 0;

    $scope.deSelect = function (roleModel) {
        setContextMenuObject();

        if (SelectedRoleNameListForFilter.length > 0) {
            SelectedRoleNameListForFilter = $.grep(SelectedRoleNameListForFilter,
								function (item, index) {
								    return item.RoleName != roleModel.RoleName;
								});
        }
        if (SelectedRoleNameListForFilter.length > 0) {
            LastAddedSelectedItemRoleName = $.grep(LastAddedSelectedItemRoleName,
								   function (item, index) {
								       return item.RoleName != roleModel.RoleName;
								   });
        }

    };

    $scope.onSelect = function (roleModel) {
        setContextMenuObject();
        var tempListFilter = $filter('filter')(SelectedRoleNameListForFilter, {
            RoleName: roleModel.RoleName
        }, true);
        if (tempListFilter.length === 0) {
            SelectedRoleNameListForFilter.push(angular.copy(roleModel));
        }
    };

    $scope.onTableFilter = function (value, key, isInstantFilter, disablePerformFilter) {
        if (roleListRequestModel.filters.length > 0) {
            roleListRequestModel.filters = jQuery.grep(roleListRequestModel.filters, function (filterItem) {
                return filterItem.FilterKey !== key;
            });
        }
        var filterValueList = [];
        filterValueList[0] = value;

        var filterItem = { 'FilterKey': key, 'FilterValues': filterValueList };
        roleListRequestModel.filters.push(filterItem);

        roleListRequestModel.pagenumber = 1;
        $scope.query.page = 1;
        $scope.query.totalCount = 0;

        if (FilterSearchTimeout) $timeout.cancel(FilterSearchTimeout);

        if (!disablePerformFilter) {
            if (isInstantFilter) {
                $scope.selected = [];
                $scope.RoleModelList = [];
                getRoleList();
            } else {
                FilterSearchTimeout = $timeout(function () {
                    $scope.selected = [];
                    $scope.RoleModelList = [];
                    getRoleList();
                }, 2000);
            }
        };
    };

    $scope.HideViewSelected = function () {

        if (!isRoleEdited()) {
            closeView();
            return;
        }
        var confirm = $mdDialog.confirm().title('Warning!').theme('confirm-dialog').textContent('Do you want to save the changes?').ariaLabel('Warning!').ok('Yes').cancel('No');

        $mdDialog.show(confirm).then(function () {
            var Promise = $scope.SaveRoleDetails();
            Promise.then(function (response) {
                if (response.statusText == "OK") {
                    closeView();
                }

            });
        }, function () {
            closeView();
        });

    };

    function isRoleEdited() {
        var result = angular.equals($scope.role, $scope.ViewRoleModel);
        if (!result) {
            return true;
        }

        if ($scope.newMembers.length > 0 || $scope.removedMembers.length > 0) {
            return true;
        }
        return false;
    }

    function closeView() {
        $scope.RoleUserList = [];
        $scope.selected = [];
        $scope.ViewRoleModel = rolesFactory.rolesInitialValues();
        $scope.role = rolesFactory.rolesInitialValues();
        $scope.showSelectedRoleDetails = false;
        $timeout(function () {
            $(window).scrollTop($scope.scrollTop);
        });

    }

    function addRoles() {
        $scope.posting = true;
        setRoleViewModelToSave();

        var apiModel = rolesFactory.getAPIModel(RoleViewModel, $scope.vm.selectedLibrary);
        var apiUrl = rolesFactory.postAPIUrl();
        $scope.mc.getlogDetails("Debug", 'Requested Api Url:' + JSON.stringify(apiUrl));
        var roleSave = RolesService.addRoles(apiModel, apiUrl, $scope.mc.loginModel.AuthKey);
        roleSave.then(function (response) {
            if (response && response.status === 201) {
                $scope.dialogPopup.CallbackFunction = function () {
                    $mdDialog.hide();
                }
                $scope.dialogPopup.Header = 'Success';
                $scope.dialogPopup.Message = 'Role added succesfully';
                // $scope.mc.setSecurityLogDetails("Info", "Response:" + $scope.mc.loginModel.UserName + " added new Role(" + apiModel.id + ")");
                $scope.mc.setSecurityLogDetails("Info", 'Success', apiModel.id, ' Role Add', JSON.stringify(apiModel));
                $scope.dialogPopup.Show();
                $timeout(function () {
                    $scope.dialogPopup.OK();
                    $scope.ShowWarning = false;
                    $scope.selected = [];
                    $scope.RoleModelList = [];
                    initializeRoleList();
                    $scope.RolesModel = rolesFactory.rolesInitialValues();
                    $scope.showValidation = false;
                }, 2000);
            }
            else {
                $scope.ErrorMessage = 'Failed to create new Role.';
                $scope.ShowWarning = true;
                //$scope.mc.setSecurityLogDetails("Error", 'Method:POST;Response:' + JSON.stringify(response));
                $scope.mc.setSecurityLogDetails("Info", 'Failure', apiModel.id, ' Role Add', JSON.stringify(apiModel));
            }
            $scope.posting = false;
        }, function (response) {
            $scope.ErrorMessage = 'Failed to create new Role.';
            $scope.ShowWarning = true;
            $scope.posting = false;
            $scope.mc.setSecurityLogDetails("Info", 'Failure', apiModel.id, ' Role Add', JSON.stringify(apiModel));
        });
    }

    function setRoleViewModelToSave() {
        RoleViewModel = rolesFactory.dbRoleModelInitialValues();

        RoleViewModel.RoleName = $scope.RolesModel.RoleName;
        RoleViewModel.Description = $scope.RolesModel.Description;
        RoleViewModel.IsExternal = $scope.RolesModel.RoleIsExternal;

        var searchListTemp = $filter('filter')($scope.PrivilageDetails, { Selected: true });

        angular.forEach(searchListTemp, function (PrivilegeType) {
            if (PrivilegeType.value === 'CO' || PrivilegeType.value === 'FO') {
                RoleViewModel.ContentAndFolderOperationList.push(PrivilegeType.TagValue);
            }
            else if (PrivilegeType.value === 'AO') {
                RoleViewModel.AdministrativeOperationList.push(PrivilegeType.TagValue);
            }
            else if (PrivilegeType.value === 'WO') {
                RoleViewModel.WebOperationsList.push(PrivilegeType.TagValue);
            }
        });
        searchListTemp = null;

    }

    $scope.PageEvents.Save = function () {
        $scope.posting = false;
        $scope.ShowWarning = false;
        $scope.showValidation = false;

        if ($scope.roleAddEditForm.roleName.$invalid) {
            return;
        }

        if ($scope.RolesModel.RoleName === '') {
            $scope.showValidation = true;
            return;
        }
        else {
            if ($scope.PageEvents.UserAction === 'Add') {
                return addRoles();
            } else {
                return editRole();
            }
        }
    };

    var totalMembersCount = 0;
    var privilegeRoleViewModel = null;
    $scope.ViewSelectedPrivilageDetails = [];

    $scope.PageEvents.ViewSelected = function (selectedRow, $event) {
        if (!$event.ctrlKey) {
            totalMembersCount = 0;
            $scope.searchRole.SearchText = '';
            $scope.selected = [];
            $scope.RoleUserList = [];
            $scope.SelectedRoleIndexList = [];
            $scope.SelectedRoleIndexList.push($scope.RoleModelList.indexOf(selectedRow));
            $scope.scrollTop = $(window).scrollTop();
            $scope.ViewRoleModel = rolesFactory.rolesInitialValues();
            $scope.role = rolesFactory.rolesInitialValues();
            $scope.NewAddRoleGroupList = [];
            $scope.RemovedRoleGroupList = [];
            $scope.newMembers = [];
            $scope.removedMembers = [];
            $scope.originalrole = rolesFactory.rolesInitialValues();
            RoleIndex = $scope.RoleModelList.indexOf(selectedRow);
            $scope.IsPosting = false;

            $rootScope.checkReadyToChangeState = function () {
                return $q(function (resolve, reject) {
                    if (!isRoleEdited()) {
                        resolve({ Status: 0 });
                        return;
                    }
                    var confirm = $mdDialog.confirm()
                            .title('Warning!')
                            .theme('confirm-dialog')
                            .textContent('Do you want to save the changes?')
                            .ariaLabel('Warning!').ok('Yes').cancel('No');

                    $mdDialog.show(confirm).then(function () {
                        var userSavePromise = $scope.SaveRoleDetails();
                        userSavePromise.then(function (response) {
                            if (response && response.statusText === "OK") {
                                resolve({ Status: 0 });
                            }
                            else {
                                resolve({ Status: -1 });
                            }

                        });
                    }, function () {
                        resolve({ Status: 0 });
                    });
                });
            };

            var apiUrl = rolesFactory.getSingleRoleAPIUrl($scope.vm.selectedLibrary, selectedRow.RoleName);
            $scope.mc.getlogDetails("Debug", 'Method : GET, URL :' + JSON.stringify(apiUrl));
            var roleModelService = RolesService.getRole(apiUrl, $scope.mc.loginModel.AuthKey);
            roleModelService.then(function (response) {
                if (response.status === 200 && response.data) {
                    $scope.ViewRoleModel = rolesFactory.getUIModelWithAllInfo(response.data.data[0]);
                    privilegeRoleViewModel = null;
                    privilegeRoleViewModel = rolesFactory.getUIModelWithAllInfo(response.data.data[0]);

                    $scope.role = angular.copy($scope.ViewRoleModel);
                    $scope.RoleUserList = [];

                    var promise = getRoleUserList();
                    promise.then(function (response) {
                        $scope.showSelectedRoleDetails = true;
                    });
                    $scope.PageEvents.UserAction = 'Edit';
                    $scope.RolesModel = rolesFactory.rolesInitialValues();
                    $scope.RolesModel.RoleName = privilegeRoleViewModel.RoleName;
                    $scope.RolesModel.Description = privilegeRoleViewModel.Description;

                    $scope.ShowMemberUserOnly = false;
                    $scope.showValidation = false;
                    $scope.ShowWarning = false;
                    $scope.posting = false;
                    fillPrivilages();
                    $scope.ViewSelectedPrivilageDetails = angular.copy($scope.PrivilageDetails);
                }
                else {
                    $scope.mc.getlogDetails("Error", 'Method:GET;URL:' + JSON.stringify(apiUrl) + ",Response:" + JSON.stringify(response));
                }

            }, function (response) {
                $scope.mc.getlogDetails("Error", 'Method:GET;URL:' + JSON.stringify(apiUrl) + ",Response:" + JSON.stringify(response));
            });

            $timeout(function () {
                $(window).scrollTop(0);
            });
        }
    };

    var roleUserListReqModel = homeFactory.requestModelInstance();
    var totalRoleUserCount = 0;
    var isRoleUserListInstantSearch = false;
    var RoleUserListSearchTimeOut = null;
    var isRoleUserListSearchTextDirty = false;

    function FilterRemovedUsers() {
        angular.forEach(removedMembersBaseTemp, function (user) {
            var existsInnewMembersTemp = $filter('filter')($scope.RoleUserList, {
                UserId: user.UserId
            }, true);
            if (existsInnewMembersTemp.length > 0) {
                var index = $scope.RoleUserList.indexOf(existsInnewMembersTemp[0]);
                if (index != -1) {
                    $scope.RoleUserList.splice(index, 1);
                    $scope.groupMembersQuery.totalCount--;
                }
            }

        });
        removedMembersBaseTemp = [];
    }

    $scope.groupMembersQuery = {
        order: 'name',
        limit: roleUserListReqModel.pageLength,
        page: roleUserListReqModel.pagenumber,
        totalCount: 0
    };

    function getRoleUserList() {
        var defered = $q.defer();
        roleUserListReqModel.libraryName = $scope.vm.selectedLibrary;
        roleUserListReqModel.searchText = $scope.searchRole.SearchText;

        if ($scope.selectedMembers.length > 0 && groupMembersReqModel.pagenumber == 1) {
            angular.forEach($scope.selectedMembers, function (user) {
                tempMembersSelected.push(angular.copy(user));
            });
            $scope.selectedMembers = [];
        }

        if (newMembersBaseTemp.length > 0) {
            angular.forEach(newMembersBaseTemp, function (userItem) {
                var memberUIModel = angular.copy(userItem);
                $scope.RoleUserList.push(memberUIModel);
                if (tempMembersSelected.length > 0) {
                    var existsInSelected = $filter('filter')(tempMembersSelected, {
                        UserId: memberUIModel.UserId
                    }, true);
                    if (existsInSelected.length > 0) {
                        var index = tempMembersSelected.indexOf(existsInSelected[0]);
                        if (index != -1) {
                            tempMembersSelected.splice(index, 1);
                            $scope.selectedMembers.push(memberUIModel);
                        }
                    }
                }

            });
        }
        newMembersBaseTemp = [];

        var apiUrl = rolesFactory.getUsersInRoleUrl(roleUserListReqModel, $scope.ViewRoleModel.RoleName);
        $scope.mc.getlogDetails("Debug", 'Method : GET, URL :' + JSON.stringify(apiUrl));
        var promise = UserService.getAllUsersInRole(apiUrl, $scope.mc.loginModel.AuthKey);
        promise.then(function (response) {
            defered.resolve(response)
            if (response.status === 200) {
                //if ($scope.groupMembersList.SearchText === '' || totalMembersCount === 0) {
                if (totalMembersCount === 0) {
                    totalMembersCount = response.data.total_count - $scope.removedMembers.length + $scope.newMembers.length;
                    $scope.groupMembersQuery.totalCount = totalMembersCount;// response.data.total_count - $scope.removedMembers.length + $scope.newMembers;
                    if (totalMembersCount > 0) {
                        $scope.RoleMembersHeaderText = totalMembersCount + ' users have the role ' + $scope.ViewRoleModel.RoleName;
                    } else {
                        $scope.RoleMembersHeaderText = "Users"
                    }
                }

                if (appendMembers.length > 0) {

                    $scope.RoleUserList.splice($scope.RoleUserList.length - appendMembers.length, appendMembers.length);
                    $scope.selectedMembers.splice($scope.selectedMembers.length - appendMembers.length, appendMembers.length);
                    tempMembersSelected = angular.copy(appendMembers);
                    appendMembers = [];
                }

                angular.forEach(response.data.data, function (userItem) {
                    var memberUIModel = userFactory.getUserUI(userItem);

                    $scope.RoleUserList.push(memberUIModel);
                    if (tempMembersSelected.length > 0) {
                        var existsInSelected = $filter('filter')(tempMembersSelected, {
                            UserId: memberUIModel.UserId
                        }, true);
                        if (existsInSelected.length > 0) {
                            var index = tempMembersSelected.indexOf(existsInSelected[0]);
                            if (index != -1) {
                                tempMembersSelected.splice(index, 1);
                                $scope.selectedMembers.push(memberUIModel);
                            }
                        }
                    }

                });
                FilterRemovedUsers()

                if ($scope.groupMembersList.SearchText.length === 0) {
                    if (tempMembersSelected.length > 0) {

                        angular.forEach(tempMembersSelected, function (user) {
                            $scope.RoleUserList.push(user);
                            $scope.selectedMembers.push(user);
                        });
                        appendMembers = angular.copy(tempMembersSelected);
                        tempMembersSelected = [];
                    }
                }
            }
            else {
                $scope.mc.getlogDetails("Error", 'Method:GET;URL:' + JSON.stringify(apiUrl) + ",Response:" + JSON.stringify(response));
            }
        }, function (response) {
            defered.resolve(response)
            $scope.mc.getlogDetails("Error", 'Method:GET;URL:' + JSON.stringify(apiUrl) + ",Response:" + JSON.stringify(response));
        });

        return defered.promise;
    }

    $scope.RoleUserList_ClearSearchClick = function () {
        isRoleUserListInstantSearch = true;
        $scope.searchRole.SearchText = '';
    };

    $scope.RoleUserList_SearchClick = function () {
        if (RoleUserListSearchTimeOut) $timeout.cancel(RoleUserListSearchTimeOut);
        roleUserListReqModel = homeFactory.requestModelInstance();
        roleUserListReqModel.pagenumber = 1;
        $scope.RoleUserList = [];

        if ($scope.searchRole.SearchText != "") {
            newMembersBaseTemp = $filter('filter')($scope.newMembers, {
                UserId: $scope.searchRole.SearchText
            }, false);
        } else {
            newMembersBaseTemp = angular.copy($scope.newMembers);
        }
        removedMembersBaseTemp = angular.copy($scope.removedMembers);
        getRoleUserList();
    };

    $scope.$watch(function () { return $scope.searchRole.SearchText; }, function (val) {
        if ($scope.searchRole.SearchText && $scope.searchRole.SearchText.length > 0) {
            isRoleUserListSearchTextDirty = true;
        }
        if (RoleUserListSearchTimeOut) $timeout.cancel(RoleUserListSearchTimeOut);

        if (isRoleUserListInstantSearch) {
            isRoleUserListInstantSearch = false;
            $scope.RoleUserList_SearchClick();
        }
        else {
            RoleUserListSearchTimeOut = $timeout(function () {
                if (isRoleUserListSearchTextDirty) {
                    $scope.RoleUserList_SearchClick();
                }
            }, 2000);
        }
    }, true);

    $scope.PageEvents.ShowOnlySelected = function () {
        $scope.vm.viewSelectedOnlyLabel = $scope.vm.viewSelectedOnlyLabel == 'View selected' ? 'Show all' : 'View selected';
    }

    $scope.RemoveSelectedUser = function () {
        var errorMsg = '';
        var deferredarray = [];

        var confirm = $mdDialog.confirm()
                        .title('Warning!')
                        .theme('confirm-dialog')
                        .textContent('Are you sure you want to remove the selected Member(s)?')
                        .ariaLabel('')
                        .ok('Yes')
                        .cancel('No');
        $mdDialog.show(confirm).then(function () {



            totalMembersCount = totalMembersCount + $scope.removedMembers.length - $scope.newMembers.length;

            angular.forEach($scope.selectedMembers, function (user) {



                removedMembersBaseTemp.push(angular.copy(user));
                if ($scope.newMembers.length > 0) {
                    var existsInSelected = $filter('filter')($scope.newMembers, {
                        UserId: user.UserId
                    }, true);
                    if (existsInSelected.length > 0) {
                        var index = $scope.newMembers.indexOf(existsInSelected[0]);
                        if (index != -1) {
                            $scope.newMembers.splice(index, 1);

                        } else {
                            $scope.removedMembers.push(angular.copy(user));

                        }
                    } else {
                        $scope.removedMembers.push(angular.copy(user));

                    }
                } else {
                    $scope.removedMembers.push(angular.copy(user));

                }

            });
            $scope.selectedMembers = [];
            FilterRemovedUsers();
            totalMembersCount = totalMembersCount - $scope.removedMembers.length + $scope.newMembers.length;
            $scope.RoleMembersHeaderText = totalMembersCount + ' users have the role ' + $scope.ViewRoleModel.RoleName;



        });


    };

    $scope.filterSelected = function (selected, field) {
        return function (currentRole) {
            if ($scope.vm.viewSelectedOnlyLabel == 'Show all') {
                if (selected.length == 0) {
                    $scope.vm.viewSelectedOnlyLabel = 'View selected';
                }

                var found = false;
                angular.forEach(selected, function (role) {
                    if (angular.equals(role, currentRole)) {
                        found = true;
                    }
                });

                return found;
            } else {
                return true;
            }
        }
    };

    $scope.viewSelectedMembersOnlyLabel = 'View selected';
    $scope.selectedMembers = [];

    $scope.groupMembers = [];
    var tempMembersSelected = [];
    var appendMembers = [];
    var groupMembersReqModel = homeFactory.requestModelInstance();
    $scope.groupMembersList = {
        SearchText: '',
        SearchClick: MembersSearchClick,
        ClearSearchClick: MembersClearSearchClick
    };

    function MembersClearSearchClick() {
        isgroupMembersInstantSearch = true;
        $scope.searchRole.SearchText = '';
    };

    $scope.newMembers = [];
    var newMembersBaseTemp = [];
    var removedMembersBaseTemp = [];

    var groupMembersSearchTimeOut = null;
    var isgroupMembersSearchTextDirty = false;
    var isgroupMembersInstantSearch = false;

    function MembersSearchClick() {
        if (groupMembersSearchTimeOut) $timeout.cancel(groupMembersSearchTimeOut);
        groupMembersReqModel = homeFactory.requestModelInstance();
        groupMembersReqModel.pagenumber = 1;
        $scope.groupMembers = [];
        newMembersBaseTemp = angular.copy($scope.newMembers);
        removedMembersBaseTemp = angular.copy($scope.removedMembers);
        getGroupMembers();
    };

    $scope.roleUsersMenuList = [{
        Label: 'Remove Users From Role',
        Icon: 'icon-delete',
        onClick: $scope.ContextMenuFunctions.RemoveUsersInView,
        Enable: true,
        IconType: 'font-icon'
    }];

    function AssignRoleUserDialogController($scope, $mdDialog, parentScope) {
        $scope.hide = function () {
            $mdDialog.hide();
        };
        $scope.cancel = function () {
            $mdDialog.cancel();
        };
        $scope.answer = function () {
            $mdDialog.hide();
        };

        $scope.SaveButtonChange = function ($event) {
            if ($event.keyCode === 9) {
                $event.preventDefault();
            }
            $("#PasswordField").focus();
            return false;
        };

        $scope.UserSearchTextChange = CustomUserSearchTextChange;

        function CustomUserSearchTextChange($event) {
            if ($event.keyCode === 13) {
                $event.preventDefault();
            }
        }

        $scope.NewUsersSearch = {
            SearchText: '',
            SerachClick: SerachClick,
            ClearSerach: ClearSerach
        }


        $scope.SelectedRole = parentScope.ViewRoleModel;
        $scope.PageTitle = 'Add Users';
        $scope.ViewSelectedButtonText = 'View Selected';

        ///-------------------All Groups
        $scope.NonMembersList = [];
        $scope.SelectedNonMembers = [];
        $scope.NonMembersQuery =
	    {
	        totalCount: 0

	    }
        var tempNonMembersSelected = [];
        var appendNonMembers = [];
        $scope.NewUsersSearch.SearchText = '';


        var NonMembersListReqModel = homeFactory.requestModelInstance();


        //  totalMembersCount = totalMembersCount+parentScope.removedMembers.length-parentScope.newMembers.length;

        var removedMembersTemp = angular.copy(parentScope.removedMembers);
        var newMembersTemp = angular.copy(parentScope.newMembers);
        var isNewUsersSearchTextDirty = false;
        var NewUsersSearchTimeOut;
        var IsInstantSearch = false;


        function getAllNonMembers() {
            return $q(function (resolve, reject) {

                NonMembersListReqModel.libraryName = parentScope.vm.selectedLibrary;
                NonMembersListReqModel.searchText = $scope.NewUsersSearch.SearchText;

                if ($scope.SelectedNonMembers.length > 0 && NonMembersListReqModel.pagenumber == 1) {
                    angular.forEach($scope.SelectedNonMembers, function (user) {
                        tempNonMembersSelected.push(angular.copy(user));
                    });
                    $scope.SelectedNonMembers = [];
                }
                if (removedMembersTemp.length > 0) {
                    angular.forEach(removedMembersTemp, function (userItem) {
                        memberUIModel = angular.copy(userItem);
                        $scope.NonMembersList.push(memberUIModel);
                        if (tempNonMembersSelected.length > 0) {
                            var existsInSelected = $filter('filter')(tempNonMembersSelected, {
                                UserId: memberUIModel.UserId
                            }, true);
                            if (existsInSelected.length > 0) {
                                var index = tempNonMembersSelected.indexOf(existsInSelected[0]);
                                if (index != -1) {
                                    tempNonMembersSelected.splice(index, 1);
                                    $scope.SelectedNonMembers.push(memberUIModel);
                                }
                            }
                        }

                    });
                }
                removedMembersTemp = [];


                var apiUrl = userFactory.getRoleLessUsers(NonMembersListReqModel);
                parentScope.mc.getlogDetails("Debug", 'Requested Api Url :' + JSON.stringify(apiUrl));
                var groupPromise = UserService.getRoleLessUsers(apiUrl, parentScope.mc.loginModel.AuthKey);
                groupPromise.then(function (response) {
                    if (response && response.status == 200) {
                        var UserList = []; // must remove after api Updates

                        $scope.NonMembersQuery.totalCount = response.data.total_count + parentScope.removedMembers.length - parentScope.newMembers.length;

                        if (appendNonMembers.length > 0) {

                            $scope.NonMembersList.splice($scope.NonMembersList.length - appendNonMembers.length, appendNonMembers.length);
                            $scope.SelectedNonMembers.splice($scope.SelectedNonMembers.length - appendNonMembers.length, appendNonMembers.length);
                            tempNonMembersSelected = angular.copy(appendNonMembers);
                            appendNonMembers = [];

                        }

                        angular.forEach(response.data.data, function (userItem) {
                            //  totalMembersCount = totalMembersCount+parentScope.removedMembers.length-parentScope.newMembers.length;


                            var addUser = true;
                            var memberUIModel = userFactory.getUserUI(userItem);
                            if (newMembersTemp.length > 0) {
                                var existsInnewMembersTemp = $filter('filter')(newMembersTemp, {
                                    UserId: memberUIModel.UserId
                                }, true);
                                if (existsInnewMembersTemp.length > 0) {
                                    var index = newMembersTemp.indexOf(existsInnewMembersTemp[0]);
                                    if (index != -1) {
                                        newMembersTemp.splice(index, 1);
                                        addUser = false;
                                    }
                                }
                            }
                            // must remove after new APi
                            var existsInRemoved = $filter('filter')(parentScope.removedMembers, {
                                UserId: memberUIModel.UserId
                            }, true);
                            if (existsInRemoved.length > 0) {
                                addUser = false;
                            }
                            if (addUser) {
                                UserList.push(memberUIModel.UserId); // must remove after api Updates
                                $scope.NonMembersList.push(memberUIModel);
                                if (tempNonMembersSelected.length > 0) {
                                    var existsInSelected = $filter('filter')(tempNonMembersSelected, {
                                        UserId: memberUIModel.UserId
                                    }, true);
                                    if (existsInSelected.length > 0) {
                                        var index = tempNonMembersSelected.indexOf(existsInSelected[0]);
                                        if (index != -1) {
                                            tempNonMembersSelected.splice(index, 1);
                                            $scope.SelectedNonMembers.push(memberUIModel);
                                        }
                                    }
                                }
                            }

                        });

                        if ($scope.NewUsersSearch.SearchText.length === 0) {
                            if (tempNonMembersSelected.length > 0) {

                                angular.forEach(tempNonMembersSelected, function (user) {
                                    $scope.NonMembersList.push(user);
                                    $scope.SelectedNonMembers.push(user);
                                });
                                appendNonMembers = angular.copy(tempNonMembersSelected);
                                tempNonMembersSelected = [];
                            }


                        }




                    }
                    else {
                        parentScope.mc.getlogDetails("Error", 'Method:GET;URL:' + JSON.stringify(apiUrl) + ",Response:" + JSON.stringify(response));
                    }
                    resolve({ Status: 1, UserList: $scope.NonMembersList });
                }, function (response) {
                    parentScope.mc.getlogDetails("Error", 'Method:GET;URL:' + JSON.stringify(apiUrl) + ",Response:" + JSON.stringify(response));
                    resolve({ Status: -1, UserList: null });
                });
            });
        }

        $scope.ViewSelectedNonMembers = function () {
            $scope.ViewSelectedButtonText = $scope.ViewSelectedButtonText == 'View selected' ? 'Show all' : 'View selected';
        };

        $scope.ViewSelectedButtonText = 'View selected';
        $scope.filterSelectedNonMembers = function (selected, field) {
            return function (user) {
                if ($scope.ViewSelectedButtonText == 'Show all') {
                    if (selected.length == 0) {
                        $scope.ViewSelectedButtonText = 'View selected';
                    }
                    var items = $filter('filter')(selected, user, true);
                    if (items.length > 0)
                        return true;

                    return false;
                } else {
                    return true;
                }
            }
        };

        $scope.$watch(function () { return $scope.NewUsersSearch.SearchText; }, function (val) {
            if ($scope.NewUsersSearch.SearchText.length > 0) {
                isNewUsersSearchTextDirty = true;
            }
            if (NewUsersSearchTimeOut) $timeout.cancel(NewUsersSearchTimeOut);

            if (IsInstantSearch) {
                IsInstantSearch = false;
                $scope.NewUsersSearch.SerachClick();
            }
            else {
                NewUsersSearchTimeOut = $timeout(function () {
                    if (isNewUsersSearchTextDirty) {
                        $scope.NewUsersSearch.SerachClick();
                    }
                }, 2000);
            }
        }, true);

        function SerachClick() {
            removedMembersTemp = angular.copy(parentScope.removedMembers);
            newMembersTemp = angular.copy(parentScope.newMembers);

            $scope.NonMembersList = [];
            NonMembersListReqModel.pagenumber = 1;
            getAllNonMembers();
        };

        function ClearSerach() {
            IsInstantSearch = true;
            $scope.NewUsersSearch.SearchText = '';
        };

        $scope.onAllUserScroll = function () {
            if ($scope.NonMembersQuery.totalCount > $scope.NonMembersList.length) {
                NonMembersListReqModel.pagenumber++;

                getAllNonMembers();
            }
        };


        $scope.AddSelectedMembers = function () {

            $scope.ErrorMessage = '';
            $scope.posting = true;
            $scope.ShowWarning = false;
            totalMembersCount = totalMembersCount + parentScope.removedMembers.length - parentScope.newMembers.length;

            angular.forEach($scope.SelectedNonMembers, function (useritem) {

                if (parentScope.removedMembers.length > 0) {
                    var existsInSelected = $filter('filter')(parentScope.removedMembers, {
                        UserId: useritem.UserId
                    }, true);
                    if (existsInSelected.length > 0) {
                        var index = parentScope.removedMembers.indexOf(existsInSelected[0]);
                        if (index != -1) {
                            parentScope.removedMembers.splice(index, 1);

                        } else {
                            parentScope.newMembers.push(angular.copy(useritem));

                        }
                    } else {
                        parentScope.newMembers.push(angular.copy(useritem));

                    }
                } else {
                    parentScope.newMembers.push(angular.copy(useritem));

                }
                parentScope.RoleUserList.push(angular.copy(useritem));
            });
            //   = [];

            totalMembersCount = totalMembersCount - parentScope.removedMembers.length + parentScope.newMembers.length;

            parentScope.RoleMembersHeaderText = totalMembersCount + ' users have the role ' + parentScope.ViewRoleModel.RoleName;


            $scope.dialogPopup.CallbackFunction = function () {
                $mdDialog.hide();
            }

            $timeout(function () {
                $scope.showValidation = false;
                $scope.ShowWarning = false;
                $scope.posting = false;
                $scope.dialogPopup.OK();
            }, 1500);


        };


        $scope.dialogPopup = {
            Header: '',
            Message: '',
            CallbackFunction: null,
            Show: function () {
                $('#popup-alert-dialog-bg').slideToggle();
            },
            OK: function () {
                $('#popup-alert-dialog-bg').slideToggle();
                $scope.dialogPopup.Header = '';
                $scope.dialogPopup.Message = '';

                if ($scope.dialogPopup.CallbackFunction) {
                    $scope.dialogPopup.CallbackFunction();
                    $scope.dialogPopup.CallbackFunction = null;
                }
            }
        };
        getAllNonMembers();
    }

    var RoleIndex = -1;

    function UpdateRoleList() {

        if (RoleIndex != -1) {
            $scope.RoleModelList[RoleIndex].Description = $scope.ViewRoleModel.Description;
            $scope.RoleModelList[RoleIndex].Privileges = $scope.ViewRoleModel.Privileges;
        }
        $scope.role = angular.copy($scope.ViewRoleModel);
    }

    $scope.SaveRoleDetails = function () {

        var defered = $q.defer();
        var deferedarry = [];
        var ErrorMessage = '';
        $scope.IsPosting = true;
        var promise = updateRolePrimaryInfo();
        promise.then(function (response) {
            if (response.statusText == "OK") {
                UpdateRoleList();
                defered.resolve(response);

            }
            else {
                ErrorMessage += response.statusText;
                defered.resolve(response);

            }
        }, function (response) {
            ErrorMessage += response.statusText;
            defered.resolve(response);

        });
        deferedarry.push(defered.promise);
        if ($scope.removedMembers.length > 0) {
            var removedefered = $q.defer();
            var removepromise = removeMembersFromRole();
            removepromise.then(function (response) {


                if (response.statusText == "OK") {

                    removedefered.resolve(response);
                }
                else {
                    ErrorMessage += response.statusText;
                    removedefered.resolve(response);

                }
            }, function (response) {
                ErrorMessage += response.statusText;
                removedefered.resolve(response);

            });
            deferedarry.push(removedefered.promise);

        }
        if ($scope.newMembers.length > 0) {
            var adddefered = $q.defer();
            var addpromise = addNewMembersToRole();
            addpromise.then(function (response) {


                if (response.statusText == "OK") {

                    adddefered.resolve(response);



                }
                else {
                    ErrorMessage += response.statusText;
                    adddefered.resolve(response);

                }
            }, function (response) {
                ErrorMessage += response.statusText;
                adddefered.resolve(response);

            });
            deferedarry.push(adddefered.promise);
        }
        var finaldefered = $q.defer();
        $q.all(deferedarry).then(function () {
            if (ErrorMessage === '') {

                finaldefered.resolve({ statusText: "OK" });
                $mdDialog.show($mdDialog.alert()
                           .parent(angular.element(document.body))
                           .clickOutsideToClose(true)
                           .title('Success')
                           .textContent('Role details succesfully updated.')
                           .ariaLabel('Success')
                           .ok('OK')
                       );
            } else {
                finaldefered.resolve({ statusText: "Failed" });
                $mdDialog.show($mdDialog.alert()
                            .parent(angular.element(document.body))
                            .clickOutsideToClose(true)
                            .title('Warning!')
                            .textContent(ErrorMessage)
                            .ariaLabel('Warning!')
                            .ok('OK')
                        );


            }
            $scope.IsPosting = false;
        });

        return finaldefered.promise;

    };

    function addNewMembersToRole() {
        var commondeferred = $q.defer();
        var deferredarray = [];
        angular.forEach($scope.newMembers, function (user) {
            var deferred = $q.defer();
            var apiUrl = rolesFactory.getAddRoleUserUrl($scope.ViewRoleModel.RoleName, user.UserId, $scope.vm.selectedLibrary);
            $scope.mc.getlogDetails("Debug", 'Method:PUT;URL:' + JSON.stringify(apiUrl));
            var promise = RolesService.AddUsersToRole(apiUrl, $scope.mc.loginModel.AuthKey);
            promise.then(function (response) {
                if (response) {
                    deferred.resolve(response);
                    if (response.status === 200) {
                        $scope.ErrorMessage = '';
                        $scope.mc.setSecurityLogDetails("Info", 'Success', $scope.ViewRoleModel.RoleName, ' Role Add User  ' + 'User=' + user.UserId)

                    } else {
                        $scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.ViewRoleModel.RoleName, ' Role Add User  ' + 'User=' + user.UserId)

                        if (response.data && response.data.message) {
                            $scope.ErrorMessage = response.data.message;
                        }
                        else {
                            $scope.ErrorMessage = $scope.ViewRoleModel.RoleName + " saving failed due to unknown reason.";
                        }
                    }
                }
            }, function (response) {
                $scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.ViewRoleModel.RoleName, ' Role Add User  ' + 'User=' + user.UserId)
                deferred.resolve(response);
            });
            deferredarray.push(deferred.promise);
        });

        $q.all(deferredarray).then(function () {
            $scope.newMembers = [];
            if ($scope.ErrorMessage === '') {
                commondeferred.resolve({ statusText: 'OK' })
            } else {

                commondeferred.resolve({ statusText: $scope.ErrorMessage })
            }
        });

        return commondeferred.promise
    }

    var errorMsg = '';

    function removeMembersFromRole() {
        var commondeferred = $q.defer();
        var deferredarray = [];

        angular.forEach($scope.removedMembers, function (user) {
            var deferred = $q.defer();
            var apiUrl = rolesFactory.getRemoveRoleUserUrl($scope.ViewRoleModel.RoleName, user.UserId, $scope.vm.selectedLibrary);
            $scope.mc.getlogDetails("Debug", 'Method:DELETE;URL:' + JSON.stringify(apiUrl));
            var promise = RolesService.RemoveUsersToRole(apiUrl, $scope.mc.loginModel.AuthKey);
            promise.then(function (response) {
                if (response) {
                    deferred.resolve(response);
                    if (response.status === 200) {
                        $scope.ErrorMessage = '';
                        $scope.mc.setSecurityLogDetails("Info", 'Success', $scope.ViewRoleModel.RoleName, ' Role Remove User', 'User=' + user.UserId);

                    } else {
                        $scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.ViewRoleModel.RoleName, ' Role Remove User', 'User=' + user.UserId);

                        if (response.data && response.data.message) {
                            $scope.ErrorMessage = response.data.message;
                        }
                        else {
                            $scope.ErrorMessage = 'Remove user from ' + $scope.ViewRoleModel.RoleName + ' failed due to unknown reason.';
                        }
                    }
                }
            }, function (response) {
                $scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.ViewRoleModel.RoleName, '  Role Remove User', 'User=' + user.UserId);
                deferred.resolve(response);
            });
            deferredarray.push(deferred.promise);
        });


        $q.all(deferredarray).then(function () {
            if ($scope.ErrorMessage === '') {
                $scope.removedMembers = [];
                commondeferred.resolve({ statusText: 'OK' })
            } else {

                commondeferred.resolve({ statusText: $scope.ErrorMessage })
            }
            $scope.removedMembers = [];
        });

        return commondeferred.promise
    }

    function updateRolePrimaryInfo() {
        var deferred = $q.defer();
        $scope.result = angular.equals($scope.role, $scope.ViewRoleModel);
        $scope.isPrivilege = angular.equals($scope.ViewSelectedPrivilageDetails, $scope.PrivilageDetails);

        if (!$scope.result || !$scope.isPrivilege) {
            setRoleViewModelToSave();
            RoleViewModel.Description = $scope.ViewRoleModel.Description;
            RoleViewModel.IsExternal = $scope.ViewRoleModel.IsExternal;

            var apiModel = rolesFactory.getAPIModel(RoleViewModel, $scope.vm.selectedLibrary);
            var apiUrl = rolesFactory.putAPIUrl(RoleViewModel.RoleName);
            $scope.mc.getlogDetails("Debug", 'Method:PUT;URL:' + JSON.stringify(apiUrl));
            var UpdateData = RolesService.editRole(apiModel, apiUrl, $scope.mc.loginModel.AuthKey);
            UpdateData.then(function (response) {
                if (response.status === 200) {
                    $scope.ErrorMessage = '';
                    $scope.mc.setSecurityLogDetails("Info", 'Success', $scope.ViewRoleModel.RoleName, '  Role Update', JSON.stringify(apiModel));

                } else {
                    $scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.ViewRoleModel.RoleName, ' Role Update', JSON.stringify(apiModel));
                    if (response && response.data && response.data.details && response.data.details.message) {
                        $scope.ErrorMessage = response.data.details.message;
                    }
                    else {
                        $scope.ErrorMessage = "Posting role failed due to unknown errors.";
                    }
                    $scope.ShowWarning = true;
                }
                $scope.posting = false;
                deferred.resolve(response);
            }, function (response) {
                $scope.mc.setSecurityLogDetails("Info", 'Failure', $scope.ViewRoleModel.RoleName, ' Role Update', JSON.stringify(apiModel));
                $scope.ErrorMessage = "Posting role failed due to unknown errors.";
                if (response.data.details.message) {
                    deferred.resolve({ statusText: response.data.details.message });
                } else {
                    deferred.resolve({ statusText: "Posting role failed due to unknown errors." });
                }
            });

        } else {
            deferred.resolve({ statusText: "OK" });
        }
        return deferred.promise;
    }

    $scope.ShowOnlySelectedMembers = function () {
        $scope.viewSelectedMembersOnlyLabel = $scope.viewSelectedMembersOnlyLabel == 'View selected' ? 'Show all' : 'View selected';
    }

    $scope.filterSelectedMembers = function (selected, field) {
        return function (selectedUser) {
            if ($scope.viewSelectedMembersOnlyLabel == 'Show all') {
                if (selected.length == 0) {
                    $scope.viewSelectedMembersOnlyLabel = 'View selected';
                }
                var items = $filter('filter')(selected, selectedUser, true);
                if (items.length > 0)
                    return true;

                return false;
            } else {
                return true;
            }
        }
    };

}