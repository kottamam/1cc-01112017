﻿app.factory('masterFactory', masterFactory);
masterFactory.$inject = ['$http', '$q', 'HomeService', 'groupFactory', 'GroupService', 'WRSU_MASTER'];
function masterFactory($http, $q, homeService, groupFactory, GroupService, WRSU_MASTER) {

    var sectionsObj = {
        groupprefix: '',
        apiurl: ''
    };

    function loadsettings() {
        var deferred = $q.defer();
        var x2js = new X2JS();
        var todayDate = (new Date()).toJSON();
        var promise = $http.get("content/settings.xml?v=" + todayDate)

        promise.then(function (response) {
            var navXml = x2js.xml_str2json(response.data);
            sectionsObj.groupprefix = navXml.root.groupprefix;
            sectionsObj.apiurl = navXml.root.apiurl;
            sectionsObj.imccapiurl = navXml.root.imccapiurl;
            deferred.resolve(sectionsObj);
        });
        return deferred.promise;
        //return sectionsObj;
    }

    var returnAPIUrl = function (APIFOR) {
        var ApiUrl = baseIMCCApiUrl + WRSU_MASTER[APIFOR];
        return ApiUrl;

    }

    var returnmasterInitailValues = function () {
        return loadsettings();
    }

    return {
        masterInitailValues: returnmasterInitailValues,
        getAPIUrl: returnAPIUrl
    }

}