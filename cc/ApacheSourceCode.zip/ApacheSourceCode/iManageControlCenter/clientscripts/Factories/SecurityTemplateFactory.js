﻿app.factory('securityTemplateFactory', securityTemplateFactory);
securityTemplateFactory.$inject = ['WRSU_ST','CONST_ST'];

function securityTemplateFactory(WRSU_ST,CONST_ST) {

    var templateInitialValueSettings = {
        TemplateName: '',
        Description: '',
        DefaultSecurity: '',
        Database: '',
        PermissionList: []
    };
    
    function getSTUIModel(stApiModel) {
        var stModel = angular.copy(templateInitialValueSettings);
        if (stApiModel) {
            stModel.TemplateName = stApiModel[CONST_ST.TemplateName];//.user_id_ex;
            stModel.Description = stApiModel[CONST_ST.Description];
            stModel.DefaultSecurity = stApiModel[CONST_ST.DefaultSecurity];
            stModel.Database = stApiModel[CONST_ST.Database];
        }
        return stModel;
    }
    
  
    
    var validationSettings = {
        showMessage: false
    }

    var returnTemplateInitialValueSettings = function () {
        return angular.copy(templateInitialValueSettings);
    }

    var returnTemplateValidationSettings = function () {
        return angular.copy(validationSettings);
    }
    
    var returnAPIUrl=function(APIFOR,requestModel,userId,OldTemplate,NewTemplate,dbName)
    {
        var ApiUrl = baseUrl + WRSU_ST[APIFOR];
    	if(APIFOR=="GETSECURITYTEMPLATEOFUSER"){
    		ApiUrl=	ApiUrl.replace("{USERID}", userId); 
    	}else if(APIFOR=="SETSECURITYTEMPLATEOFUSER"|| APIFOR=="UPDATESECURITYTEMPLATEOFUSER" || APIFOR=="DELETESECURITYTEMPLATEOFUSER")
    	{
    		ApiUrl=	ApiUrl.replace("{USERID}", userId); 
    		ApiUrl=	ApiUrl.replace("{STOLDNAME}", OldTemplate); 
    		ApiUrl=	ApiUrl.replace("{STNEWNAME}", NewTemplate); 
    		
    	}
    	else if (APIFOR == "GETSECURITYTEMPLATES") {
    	    ApiUrl = prepareUrl(ApiUrl, requestModel);
    	}
    	else if(requestModel!=null)
    	{
    		ApiUrl=prepareUrl(ApiUrl,requestModel);
    		
    	}
    	return ApiUrl;
    	
    }
    
    function prepareUrl(URL,requestModel)
    { 
    	return URL+"?database="+requestModel.libraryName+'&offset='+((requestModel.pagenumber-1)*requestModel.pageLength)+'&limit='+requestModel.pageLength+'&total='+requestModel.isTotal;
        
    }

    var returnSTUIModel=function(stApiModel)
    {
    	return getSTUIModel(stApiModel);
    	
    }

    return {
        templateInitailValues: returnTemplateInitialValueSettings,
        getAPIUrl:returnAPIUrl,
        getSTUI:returnSTUIModel,
        validations: returnTemplateValidationSettings
    }
}