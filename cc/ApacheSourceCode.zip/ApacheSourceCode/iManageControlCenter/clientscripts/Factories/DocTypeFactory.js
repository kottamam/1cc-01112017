﻿app.factory('docTypeFactory', docTypeFactory);

docTypeFactory.$inject = ['WRSU_DOCTYPE', 'CONST_TYPE_FILEDS', 'CONST_TYPE_FILTER'];

function docTypeFactory(WRSU_DOCTYPE, CONST_TYPE_FILEDS, CONST_TYPE_FILTER) {

	var docTypeInitialValueSettings = {
		TAlias: '',
		TypeDescription: '',
		AutoDetect: true,
		DmsExtension: '',
		AppExtension: '',
		Indexable: 0,
		HIPAAComplaint: false
	};

	var returnDocTypeInitialValueSettings = function () {
		return angular.copy(docTypeInitialValueSettings);
	};

	var returnSearchAPIUrl = function (requestModel) {
	    var apiURL = baseUrl + WRSU_DOCTYPE['SEARCH_TYPES'];
		var offset = (requestModel.pagenumber - 1) * requestModel.pageLength;

		apiURL += "?database=" + requestModel.libraryName +
		'&offset=' + offset + '&limit=' + requestModel.pageLength + '&total=' + requestModel.isTotal;

		if (requestModel.searchText != null && requestModel.searchText != '')
		    apiURL += '&query=*' + requestModel.searchText + '*'
		if (requestModel.filters.length > 0) {
		    angular.forEach(requestModel.filters, function (filterItem) {
		        if (filterItem.FilterValues[0] != null && filterItem.FilterValues[0] != '') {
		            if (filterItem.FilterKey == 'HIPAAComplaint') {
		                apiURL += '&' + CONST_TYPE_FILTER[filterItem.FilterKey] + '=' + (filterItem.FilterValues[0] == "Y" ? 'true' : 'false');
		            } else {
		                apiURL += '&' + CONST_TYPE_FILTER[filterItem.FilterKey] + '=*' + filterItem.FilterValues[0] + '*'
		            }
		        }
		    });
		}
		return apiURL;
	};
	function prepareUrl(URL, requestmodel, APIFOR) {
	    var ApiUrl = URL;
	    ApiUrl += "?" + CONST_TYPE_FILEDS.Database + "="
					+ requestmodel.libraryName + '&alias' + '=' + requestmodel.TAlias
	    return ApiUrl;
	}
	var returnAPIUrl = function (APIFOR, modelObject) {
	    var ApiUrl = baseUrl + WRSU_DOCTYPE[APIFOR]
	    if (modelObject != null) {
	        ApiUrl = prepareUrl(ApiUrl, modelObject, APIFOR);

	    }
	    return ApiUrl;

	}

	function getTypeUIModel(typeAPIModel) {
		var typeTempModel = angular.copy(docTypeInitialValueSettings);

		typeTempModel.TAlias = typeAPIModel[CONST_TYPE_FILEDS.TAlias];
		typeTempModel.TypeDescription = typeAPIModel[CONST_TYPE_FILEDS.Description];
		typeTempModel.DmsExtension = typeAPIModel[CONST_TYPE_FILEDS.DmsExtension];
		typeTempModel.AppExtension = typeAPIModel[CONST_TYPE_FILEDS.AppExtension];
		typeTempModel.HIPAAComplaint = typeAPIModel[CONST_TYPE_FILEDS.HIPAAComplaint];

		return typeTempModel;
	};

	var returnTypeUIModel = function (typeAPIModel) {
		return getTypeUIModel(typeAPIModel);
	};

	function getTypeAPIModel(dbName, typeUIModel) {
	    var typeTempModel = {};

	    typeTempModel[CONST_TYPE_FILEDS.TAlias] = typeUIModel.TAlias;
	    typeTempModel[CONST_TYPE_FILEDS.Description] = typeUIModel.TypeDescription;
	    typeTempModel[CONST_TYPE_FILEDS.DmsExtension] = typeUIModel.DmsExtension;
	    typeTempModel[CONST_TYPE_FILEDS.AppExtension] = typeUIModel.AppExtension;
	    typeTempModel[CONST_TYPE_FILEDS.HIPAAComplaint] = typeUIModel.HIPAAComplaint;
	    typeTempModel[CONST_TYPE_FILEDS.Database] = dbName;

	    return typeTempModel;
	};

	var returnTypAPIModel = function (dbName, typeUIModel) {
	    return getTypeAPIModel(dbName, typeUIModel);
	};

	var returnPostAPIUrl = function () {
	    var apiURL = baseUrl + WRSU_DOCTYPE['POST_TYPE'];

	    return apiURL;
	};

	var returnPutAPIUrl = function (docObject) {
	    var apiURL = baseUrl + WRSU_DOCTYPE['PUT_TYPE'];
	    apiURL = apiURL.replace('{ALIAS}', docObject.TAlias);
	    return apiURL;
	};
	return {
		docTypeInitialValues: returnDocTypeInitialValueSettings,
		searchAPIUrl: returnSearchAPIUrl,
		postAPIUrl: returnPostAPIUrl,
		putAPIUrl: returnPutAPIUrl,
		getUIModel: returnTypeUIModel,
		getAPIModel: returnTypAPIModel,
	    getAPIUrl:returnAPIUrl
	};
}