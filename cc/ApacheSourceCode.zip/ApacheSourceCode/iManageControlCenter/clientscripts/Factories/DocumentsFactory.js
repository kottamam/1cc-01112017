﻿app.factory('DocumentsFactory', DocumentsFactory);

DocumentsFactory.$inject = ['WRSU_DOCUMENTS', 'CONST_DOCUMENTS_FILEDS', 'CONST_HISTORY_DOCUMENTS_FILEDS', 'CONST_DOCUMENTS_SECURITY', 'CONST_UNLOCK_DOCUMENTS_FILEDS', 'CONST_CHECKOUT_FILEDS', 'DocumentTypeResolver'];

function DocumentsFactory(WRSU_DOCUMENTS, CONST_DOCUMENTS_FILEDS, CONST_HISTORY_DOCUMENTS_FILEDS, CONST_DOCUMENTS_SECURITY, CONST_UNLOCK_DOCUMENTS_FILEDS, CONST_CHECKOUT_FILEDS, DocumentTypeResolver) {

    var DocumentsInitialValueSettings = {
        Author: '',
        Class: '',
        CreateDate: '',
        Custom1: '',
        Custom2: '',
        Database: '',
        DefaultSecurity: '',
        DocumentNumber: '',
        EditDate: '',
        Extension: '',
        HasAttachment: '',
        Id: '',
        InUse: '',
        IsCheckedOut: '',
        IsHipaa: '',
        Iwl: '',
        LastUser: '',
        Name: '',
        Operator: '',
        Size: '',
        Type: '',
        Version: '',
        WorkSpaceId: '',
        WorkSpaceName: '',
        WsType: '',
        TypeResolver: '',
        CheckedOutBy: '',
        CheckedOutDate: ''
    };

    var HistoryDocumentsInitialValueSettings = {
        Activity: '',
        ActivityCode: '',
        ActivityDate: '',
        ApplicationName: '',
        DocumentNumber: '',
        Location: '',
        User: '',
        Version: '',
        DocumentsList: '',
        Duration: '',
        PagesPrinted: '',
        Comments: ''
    };

    var documentsSecurityUIModel = {
        Id: '',
        Type: '',
        Name: '',
        AllowLogin: false,
        AccessRight: ''
    };

    var returndocumentsSecurityUIModelSettings = function () {
        return angular.copy(documentsSecurityUIModel);
    };

    var UnlockDocumentsInitialValueSettings = {
        Database: '',
        DocumentNumber: '',
        Version: '',
        DocumentVersion: ''
    };


    var returnDocumentsInitialValueSettings = function () {
        return angular.copy(DocumentsInitialValueSettings);
    };

    function GetMonthName(monthNumber) {
        var month = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        return month[monthNumber - 1];
    }

    var returnSearchAPIUrl = function (requestModel) {
        var apiURL = baseUrl + WRSU_DOCUMENTS['SEARCH_DOCUMENTS'];
        var offset = (requestModel.pagenumber - 1) * requestModel.pageLength;
        var isURL = false;

        apiURL += "?database=" + requestModel.libraryName + '&additional_fields=checkout_date' +
					'&offset=' + offset + '&limit=' + requestModel.pageLength + '&total=' + requestModel.isTotal;

        if (requestModel.DocumentNumber.length > 0 || requestModel.Version.length > 0 || requestModel.UserID.length > 0 ||
			requestModel.Custom1.length > 0 || requestModel.Custom2.length > 0 || requestModel.IsCheckedOut != null) {

            if (requestModel.DocumentNumber.length > 0) {
                apiURL += '&document_number=' + requestModel.DocumentNumber;
            }
            if (requestModel.Version.length > 0) {
                apiURL += '&document_version=' + requestModel.Version;
            }
            if (requestModel.UserID.length > 0 && requestModel.UserType.length > 0) {
                switch (requestModel.UserType) {
                    case 'Author':
                        apiURL += '&author=*' + requestModel.UserID + '*';
                        break;
                    case 'Operator':
                        apiURL += '&operator=*' + requestModel.UserID + '*';
                        break;
                    case 'Checkedoutby':
                        apiURL += '&in_use_by=*' + requestModel.UserID + '*';
                        break;
                    case 'Lastmodifiedby':
                        apiURL += '&last_user=*' + requestModel.UserID + '*';
                        break;
                }

            }
            if (requestModel.Version.length > 0) {
                apiURL += '&version=' + requestModel.Version;
            }
            if (requestModel.Custom1.length > 0) {
                apiURL += '&custom1=*' + requestModel.Custom1 + '*';
            }
            if (requestModel.Custom2.length > 0) {
                apiURL += '&custom2=*' + requestModel.Custom2 + '*';
            }
            if (requestModel.IsCheckedOut != null) {
                apiURL += '&checked_out=' + requestModel.IsCheckedOut;
            }
        }
        //else {
        //        apiURL += '&name=*'
        //    }

        if (requestModel.filters.length > 0) {
            angular.forEach(requestModel.filters, function (filterItem) {
                if (filterItem.FilterValues[0] != null && filterItem.FilterValues[0] != '') {
                    isURL = true;
                    //if (filterItem.FilterKey == 'DocumentNumber') {
                    //    //apiURL += '&' + CONST_USERS[filterItem.FilterKey + 'Filter'] + '=' + (filterItem.FilterValues[0] == "Y" ? 'true' : 'false');
                    //    apiURL += '&' + CONST_DOCUMENTS_FILEDS[filterItem.FilterKey + 'Filter'] + '=' + filterItem.FilterValues[0]
                    //} else {
                    apiURL += '&' + CONST_DOCUMENTS_FILEDS[filterItem.FilterKey + 'Filter'] + '=*' + filterItem.FilterValues[0] + '*'
                    //}
                }
            });
            if (!isURL) {
                apiURL += '&name=*'
            }
        }
        //else {
        //    apiURL += '&name=*'
        //}

        return apiURL;
    };

    var returnCheckedOutInformationAPIUrl = function (docId) {
        var apiUrl = baseUrl + WRSU_DOCUMENTS['CHECKEDOUT_INFORMATION'];
        return apiUrl.replace('{DOCID}', docId);
    }

    function getDocumentsUIModel(DocumentsAPIModel) {
        var DocumentsTempModel = angular.copy(DocumentsInitialValueSettings);


        DocumentsTempModel.Author = DocumentsAPIModel[CONST_DOCUMENTS_FILEDS.Author];
        DocumentsTempModel.Class = DocumentsAPIModel[CONST_DOCUMENTS_FILEDS.Class];
        DocumentsTempModel.CreateDate = GetDate(DocumentsAPIModel[CONST_DOCUMENTS_FILEDS.CreateDate]);
        DocumentsTempModel.Custom1 = DocumentsAPIModel[CONST_DOCUMENTS_FILEDS.Custom1];
        DocumentsTempModel.Custom2 = DocumentsAPIModel[CONST_DOCUMENTS_FILEDS.Custom2];
        DocumentsTempModel.Database = DocumentsAPIModel[CONST_DOCUMENTS_FILEDS.Database];
        DocumentsTempModel.DefaultSecurity = DocumentsAPIModel[CONST_DOCUMENTS_FILEDS.DefaultSecurity];
        DocumentsTempModel.DocumentNumber = DocumentsAPIModel[CONST_DOCUMENTS_FILEDS.DocumentNumber];
        DocumentsTempModel.EditDate = GetDate(DocumentsAPIModel[CONST_DOCUMENTS_FILEDS.EditDate]);
        DocumentsTempModel.Extension = DocumentsAPIModel[CONST_DOCUMENTS_FILEDS.Extension];
        DocumentsTempModel.HasAttachment = DocumentsAPIModel[CONST_DOCUMENTS_FILEDS.HasAttachment];
        DocumentsTempModel.Id = DocumentsAPIModel[CONST_DOCUMENTS_FILEDS.Id];
        DocumentsTempModel.InUse = DocumentsAPIModel[CONST_DOCUMENTS_FILEDS.InUse];
        DocumentsTempModel.IsCheckedOut = DocumentsAPIModel[CONST_DOCUMENTS_FILEDS.IsCheckedOut];
        DocumentsTempModel.IsHipaa = DocumentsAPIModel[CONST_DOCUMENTS_FILEDS.IsHipaa];
        DocumentsTempModel.Iwl = DocumentsAPIModel[CONST_DOCUMENTS_FILEDS.Iwl];
        DocumentsTempModel.LastUser = DocumentsAPIModel[CONST_DOCUMENTS_FILEDS.LastUser];
        DocumentsTempModel.Name = DocumentsAPIModel[CONST_DOCUMENTS_FILEDS.Name];
        DocumentsTempModel.Operator = DocumentsAPIModel[CONST_DOCUMENTS_FILEDS.Operator];
        DocumentsTempModel.Size = DocumentsAPIModel[CONST_DOCUMENTS_FILEDS.Size];
        DocumentsTempModel.Type = DocumentsAPIModel[CONST_DOCUMENTS_FILEDS.Type];
        DocumentsTempModel.Version = DocumentsAPIModel[CONST_DOCUMENTS_FILEDS.Version];
        DocumentsTempModel.WorkSpaceId = DocumentsAPIModel[CONST_DOCUMENTS_FILEDS.WorkSpaceId];
        DocumentsTempModel.WorkSpaceName = DocumentsAPIModel[CONST_DOCUMENTS_FILEDS.WorkSpaceName];
        DocumentsTempModel.WsType = DocumentsAPIModel[CONST_DOCUMENTS_FILEDS.WsType];
        DocumentsTempModel.CheckedOutBy = DocumentsAPIModel[CONST_DOCUMENTS_FILEDS.CheckedOutBy];
        DocumentsTempModel.CheckedOutDate = GetDate(DocumentsAPIModel[CONST_DOCUMENTS_FILEDS.CheckedOutDate]);
        var typeExtensionResolver = DocumentTypeResolver.getDocType(DocumentsAPIModel[CONST_DOCUMENTS_FILEDS.Type], 'type');
        if (!typeExtensionResolver) {
            typeExtensionResolver = DocumentTypeResolver.getDocType(DocumentsAPIModel[CONST_DOCUMENTS_FILEDS.Extension], 'extension');
        }
        if (!typeExtensionResolver)
            typeExtensionResolver = '';
        DocumentsTempModel.TypeResolver = typeExtensionResolver;
        return DocumentsTempModel;
    };


    function getHistoryDocumentsUIModel(DocumentsHistoryAPIModel) {
        var HistoryDocumentsTempModel = angular.copy(HistoryDocumentsInitialValueSettings);

        HistoryDocumentsTempModel.Activity = DocumentsHistoryAPIModel[CONST_HISTORY_DOCUMENTS_FILEDS.Activity];
        HistoryDocumentsTempModel.ActivityCode = DocumentsHistoryAPIModel[CONST_HISTORY_DOCUMENTS_FILEDS.ActivityCode];
        HistoryDocumentsTempModel.ActivityDate = GetDate(DocumentsHistoryAPIModel[CONST_HISTORY_DOCUMENTS_FILEDS.ActivityDate]);
        HistoryDocumentsTempModel.ApplicationName = DocumentsHistoryAPIModel[CONST_HISTORY_DOCUMENTS_FILEDS.ApplicationName];
        HistoryDocumentsTempModel.DocumentNumber = DocumentsHistoryAPIModel[CONST_HISTORY_DOCUMENTS_FILEDS.DocumentNumber];
        HistoryDocumentsTempModel.Location = DocumentsHistoryAPIModel[CONST_HISTORY_DOCUMENTS_FILEDS.Location];
        HistoryDocumentsTempModel.User = DocumentsHistoryAPIModel[CONST_HISTORY_DOCUMENTS_FILEDS.User];
        HistoryDocumentsTempModel.Version = DocumentsHistoryAPIModel[CONST_HISTORY_DOCUMENTS_FILEDS.Version];

        HistoryDocumentsTempModel.Duration = DocumentsHistoryAPIModel[CONST_HISTORY_DOCUMENTS_FILEDS.Duration];
        HistoryDocumentsTempModel.PagesPrinted = DocumentsHistoryAPIModel[CONST_HISTORY_DOCUMENTS_FILEDS.PagesPrinted];
        HistoryDocumentsTempModel.Comments = DocumentsHistoryAPIModel[CONST_HISTORY_DOCUMENTS_FILEDS.Comments];

        return HistoryDocumentsTempModel;
    };
    function getUnlockDocumentApiPutModel(UnlockUIModel, dbName) {
        var DocumentUnlockModel = {};
        DocumentUnlockModel[CONST_UNLOCK_DOCUMENTS_FILEDS.Database] = dbName;
        DocumentUnlockModel[CONST_UNLOCK_DOCUMENTS_FILEDS.DocumentNumber] = UnlockUIModel.DocumentNumber;
        DocumentUnlockModel[CONST_UNLOCK_DOCUMENTS_FILEDS.DocumentVersion] = UnlockUIModel.DocumentVersion;
        DocumentUnlockModel.TimeZoneOffset = 0;
        DocumentUnlockModel.Version = 2;
        return DocumentUnlockModel;

    }
    function GetDate(dateString) {
        var dateObj = new Date(dateString);
        if (dateObj != 'Invalid Date') {
            var monthNumber = dateObj.getMonth() + 1;
            var monthName = GetMonthName(monthNumber);
            return monthName + " " + dateObj.getDate() + ", " + dateObj.getFullYear();
        }
        else {
            return '';

        }
    }

    var returnDocumentsUIModel = function (DocumentsAPIModel) {
        return getDocumentsUIModel(DocumentsAPIModel);
    };

    var returnHistoryDocumentsUIModel = function (DocumentsHistoryAPIModel) {
        return getHistoryDocumentsUIModel(DocumentsHistoryAPIModel);
    };

    var returnVersionDocumentsUIModel = function (DocumentsVersionAPIModel) {
        return getDocumentsUIModel(DocumentsVersionAPIModel);
    };

    var returnDocumentSecurityUIModel = function (securityApiModel) {
        return getDocumentSecurityUIModel(securityApiModel);
    };

    var returnUnlockDocumentApiPutModel = function (group, dbName) {
        return getUnlockDocumentApiPutModel(group, dbName);
    }

    function getDocumentSecurityUIModel(securityApiModel) {
        var securityTempModel = angular.copy(documentsSecurityUIModel);

        securityTempModel.Id = securityApiModel[CONST_DOCUMENTS_SECURITY.Id];

        switch (securityApiModel[CONST_DOCUMENTS_SECURITY.Type]) {
            case 'user':
                securityTempModel.Type = 'User';
                break;

            case 'group':
                securityTempModel.Type = 'Group';
                break;

            default:
                securityTempModel.Type = '';
                break;
        }

        switch (securityApiModel[CONST_DOCUMENTS_SECURITY.Access]) {
            case 0:
                securityTempModel.AccessRight = 'No Access';
                break;

            case 1:
                securityTempModel.AccessRight = 'Read';
                break;

            case 2:
                securityTempModel.AccessRight = 'Read Write';
                break;

            case 3:
                securityTempModel.AccessRight = 'Full Access';
                break;

            default:
                securityTempModel.AccessRight = '';
                break;
        }
        return securityTempModel;
    }

    function prepareUrl(URL, requestmodel, APIFOR, Id) {
        var ApiUrl = URL;
        switch (APIFOR) {
            case 'VIEWHISTORYDOCUMENTS':
                ApiUrl = ApiUrl.replace("{CUSTOMID}", Id);
                break;
            case 'VIEWVERSIONDOCUMENTS':
                ApiUrl = ApiUrl.replace("{CUSTOMID}", Id);
                break;
            case 'VIEWSECURITYDOCUMENTS':
                ApiUrl = ApiUrl.replace("<user_id>", requestmodel.UserId);
                ApiUrl = ApiUrl.replace("<doc_id>", requestmodel.DocumentId);
                break;
        }
        return ApiUrl;
    }

    var returnAPIUrl = function (APIFOR, modelObject, Id) {
        var ApiUrl = baseUrl + WRSU_DOCUMENTS[APIFOR];
        
        if (APIFOR != 'VIEWSECURITYDOCUMENTS') {
            var offset = (modelObject.pagenumber - 1) * modelObject.pageLength;
            ApiUrl += "?database=" + modelObject.libraryName +
			'&offset=' + offset + '&limit=' + modelObject.pageLength + '&total=' + modelObject.isTotal;
        }

        if (modelObject != null) {
            ApiUrl = prepareUrl(ApiUrl, modelObject, APIFOR, Id);

        }
        return ApiUrl;

    }

    var returnUnlockDocumentAPIUrl = function (APIFOR, docId) {
        var ApiUrl = baseUrl + WRSU_DOCUMENTS[APIFOR];
        ApiUrl = ApiUrl.replace('<docId>', docId);
        return ApiUrl;
    };

    var returnCheckinAPIUrl = function (APIFOR) {
        var ApiUrl = baseUrl + WRSU_DOCUMENTS[APIFOR]
        return ApiUrl;
    }

    var returnGetDocumentAPIUrl = function (APIFOR, checkoutPath) {
        var ApiUrl = baseUrl + WRSU_DOCUMENTS[APIFOR]
        ApiUrl = ApiUrl.replace("{FILEPATH}", checkoutPath);
        return ApiUrl;
    }

    var returnCheckoutInfo = function (apiResponse) {
        var checkoutObject = {};
        checkoutObject.Database = apiResponse[CONST_CHECKOUT_FILEDS.Database],
        checkoutObject.DocNum = apiResponse[CONST_CHECKOUT_FILEDS.DocNum],
        checkoutObject.Version = apiResponse[CONST_CHECKOUT_FILEDS.Version],
        checkoutObject.Description = apiResponse[CONST_CHECKOUT_FILEDS.CheckoutDescription],
        checkoutObject.DateTime = GetDate(apiResponse[CONST_CHECKOUT_FILEDS.CheckoutDate]),
        checkoutObject.CheckoutPath = apiResponse[CONST_CHECKOUT_FILEDS.CheckoutPath]
        return checkoutObject;


    }

    var returnFormData = function (docinfo, loginmodel) {
        var formdata = new FormData();
        var checkinKind = 0;
        var refile = 0;
        if (docinfo.replaceOrginal)
            checkinKind = 2;

        if (docinfo.newDocument)
            checkinKind = 1;



        formdata.append("GeneralJson", "{\"AppName\":\"iManage Control Center\",\"Authentication\":{\"appUuid\":\"5a2c0c3a-39bb-45aa-9628-69e46cf3689c\",\"authType\":\"worksite\",\"domain\":\"\",\"password\":\"" + loginmodel.Password + "\",\"token\":null,\"userID\":\"" + loginmodel.UserName + "\"},\"CheckinKind\":" + checkinKind + ",\"Checksum\":\"\",\"Comment\":\"\",\"DatabaseName\":\"" + docinfo.Database + "\",\"DocNum\":" + docinfo.DocumentNumber + ",\"DocVer\":" + docinfo.Version + ",\"FolderID\":30,\"HistoryEvent\":0,\"Location\":\"\",\"Refile\":" + refile + ",\"SupervisedUpload\":true,\"SuppressHistory\":false,\"SystemEditDate\":0,\"TimeZoneOffset\":0,\"Version\":2}");

        formdata.append("ProfileJson", "{\"3\":\"" + docinfo.Name + "\",\"7\":\"" + docinfo.Type + "\", \"8\":\"" + docinfo.Class + "\",\"5\":\"" + docinfo.Author + "\",\"13\":\"" + docinfo.Size + "\",\"6\":\"" + docinfo.Operator + "\",\"18\":\"" + docinfo.LastUser + "\",\"25\":\"" + docinfo.Custom1 + "\",\"9\":\"" + docinfo.SubClass + "\",\"26\":\"" + docinfo.Custom2 + "\"}");
        formdata.append("APJson", "{}");
        formdata.append("file0", docinfo.filevalue);
        return formdata;
    }

    return {
        DocumentsInitialValues: returnDocumentsInitialValueSettings,
        searchAPIUrl: returnSearchAPIUrl,
        getUIModel: returnDocumentsUIModel,
        getAPIUrl: returnAPIUrl,
        getCheckinAPIUrl: returnCheckinAPIUrl,
        getFormData: returnFormData,
        getHistoryUIModel: returnHistoryDocumentsUIModel,
        getVersionUIModel: returnVersionDocumentsUIModel,
        getDocumentSecurityUIModel: returnDocumentSecurityUIModel,
        getUnlockDocumentAPIURL: returnUnlockDocumentAPIUrl,
        getUnlockDocumentPutModel: returnUnlockDocumentApiPutModel,
        getCheckedOutInformationAPIUrl: returnCheckedOutInformationAPIUrl,
        documentsSecurityInitailValues: returndocumentsSecurityUIModelSettings,
        getCheckoutInfo: returnCheckoutInfo,
        getDocumentUrl: returnGetDocumentAPIUrl
    };
}