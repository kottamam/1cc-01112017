﻿////app.factory('datatableSettingsFactory', datatableSettingsFactory);
////datatableSettingsFactory.$inject = ['DTOptionsBuilder', 'DTColumnDefBuilder'];

//function datatableSettingsFactory(DTOptionsBuilder, DTColumnDefBuilder) {

//    var dtOptionSettings = DTOptionsBuilder.newOptions()
//					.withOption('responsive', true)
//					.withOption('bAutoWidth', true)
//					//.withOption('retrieve', true)
//					.withOption('paging', false)
//					.withOption('sorting', false)
//					.withOption('searching', false)
//					.withOption('info', false)
//                    .withOption('destroy', true)
//					//.withOption('scrollY', '48vh')
//					.withDOM('frtip');

//    var dtUserTableColumnDef = [
//        DTColumnDefBuilder.newColumnDef(0).notSortable(),
//        DTColumnDefBuilder.newColumnDef(1).notSortable(),
//        DTColumnDefBuilder.newColumnDef(2).notSortable(),
//        DTColumnDefBuilder.newColumnDef(3).notSortable(),
//        DTColumnDefBuilder.newColumnDef(4).notSortable(),
//        DTColumnDefBuilder.newColumnDef(5).notSortable(),
//        DTColumnDefBuilder.newColumnDef(6).notSortable(),
//        DTColumnDefBuilder.newColumnDef(7).notSortable()
//    ];

//    var dtGroupTableColumnDef = [
//       DTColumnDefBuilder.newColumnDef(0).notSortable(),
//       DTColumnDefBuilder.newColumnDef(1).notSortable(),
//       DTColumnDefBuilder.newColumnDef(2).notSortable(),
//       DTColumnDefBuilder.newColumnDef(3).notSortable(),
//       DTColumnDefBuilder.newColumnDef(4).notSortable()
//    ];

//    var dtRoleTableColumnDef = [
//       DTColumnDefBuilder.newColumnDef(0).notSortable(),
//       DTColumnDefBuilder.newColumnDef(1).notSortable(),
//       DTColumnDefBuilder.newColumnDef(2).notSortable()
//    ];

//    var dtTypeTableColumnDef = [
//       DTColumnDefBuilder.newColumnDef(0).notSortable(),
//       DTColumnDefBuilder.newColumnDef(1).notSortable(),
//       DTColumnDefBuilder.newColumnDef(2).notSortable(),
//       DTColumnDefBuilder.newColumnDef(3).notSortable(),
//       DTColumnDefBuilder.newColumnDef(4).notSortable()
//    ];

//    var dtAppSetupTableColumnDef = [
//       DTColumnDefBuilder.newColumnDef(0).notSortable(),
//       DTColumnDefBuilder.newColumnDef(1).notSortable(),
//       DTColumnDefBuilder.newColumnDef(2).notSortable(),
//       DTColumnDefBuilder.newColumnDef(3).notSortable(),
//       DTColumnDefBuilder.newColumnDef(4).notSortable(),
//       DTColumnDefBuilder.newColumnDef(5).notSortable(),
//       DTColumnDefBuilder.newColumnDef(6).notSortable(),
//       DTColumnDefBuilder.newColumnDef(7).notSortable(),
//       DTColumnDefBuilder.newColumnDef(8).notSortable(),
//       DTColumnDefBuilder.newColumnDef(9).notSortable(),
//       DTColumnDefBuilder.newColumnDef(10).notSortable(),
//       DTColumnDefBuilder.newColumnDef(11).notSortable()
//    ];

//    var dtSecurityTemplateTableColumnDef = [
//       DTColumnDefBuilder.newColumnDef(0).notSortable(),
//       DTColumnDefBuilder.newColumnDef(1).notSortable()
//    ];

//    var dtDatabaseTableColumns = [
//     DTColumnDefBuilder.newColumnDef(0).notSortable(),
//     DTColumnDefBuilder.newColumnDef(1).notSortable()
//    ];

//    var dtClassTableColumnDef = [
//        DTColumnDefBuilder.newColumnDef(0).notSortable(),
//        DTColumnDefBuilder.newColumnDef(1).notSortable(),
//        DTColumnDefBuilder.newColumnDef(2).notSortable(),
//        DTColumnDefBuilder.newColumnDef(3).notSortable(),
//        DTColumnDefBuilder.newColumnDef(4).notSortable(),
//        DTColumnDefBuilder.newColumnDef(5).notSortable(),
//        DTColumnDefBuilder.newColumnDef(6).notSortable(),
//        DTColumnDefBuilder.newColumnDef(7).notSortable()
//    ];

//	var dtMetaDataTableColumnDef = [
//     DTColumnDefBuilder.newColumnDef(0).notSortable(),
//     DTColumnDefBuilder.newColumnDef(1).notSortable(),
//     DTColumnDefBuilder.newColumnDef(2).notSortable(),
//     DTColumnDefBuilder.newColumnDef(3).notSortable()
//    ];

//    var tableSettingsObj = {
//        scrollTop: 0,
//        scrollBarTop: '0px'
//    }

//    var returnTableSettings = function () {
//        return angular.copy(tableSettingsObj);
//    }

//    return {
//        dtOptions: dtOptionSettings,
//        dtUserTableColumns: dtUserTableColumnDef,
//        dtGroupTableColumns: dtGroupTableColumnDef,
//        dtRoleTableColumns: dtRoleTableColumnDef,
//        dtTypeTableColumns: dtTypeTableColumnDef,
//        dtAppSetupTableColumns: dtAppSetupTableColumnDef,
//		dtMetaDataTableColumns:dtMetaDataTableColumnDef,
//        dtSecurityTemplateTableColumns: dtSecurityTemplateTableColumnDef,
//        dtDatabaseTableColumns: dtDatabaseTableColumns,
//		dtClassTableColumns: dtClassTableColumnDef,
//        tableSettings: returnTableSettings
//    }
//}