﻿app.factory('TemplateFactory', TemplateFactory);
TemplateFactory.$inject = ['TSU_TEMPLATES', 'CONST_WORKSPACE', '$q','CONST_TEMPLATE_FOLDER'];
function TemplateFactory(TSU_TEMPLATES, CONST_WORKSPACE, $q, CONST_TEMPLATE_FOLDER) {

    var workSpaceUIModel = {
        Id: '',
        Author: '',
        Class: '',
        CreateDate: '',
        Custom1: '',
        Custom2: '',
        Custom3: '',
        Database: '',
        DefaultSecurity: '',
        DocumentNumber: 0,
        EditDate: '',
        EditProfileDate: '',
        FileCreateDate: '',
        FileEditDate: '',
        Iwl: '',
        LastUser: '',
        Location: '',
        Name: '',
        Operator: '',
        Owner: '',
        RetainDays: 0,
        Size: 0,
        Subtype: '',
        Type: '',
        Version: 0,
        Wstype: '',
        HasAttachment: false,
        HasSubfolders: false,
        InUse: false,
        Indexable: false,
        IsCheckedOut: false,
        IsContainerSavedSearch: false,
        IsContentSavedSearch: false,
        IsExternal: false,
        IsExternalAsNormal: false,
        IsHidden: false,
        IsHipaa: false
    };

    var folderUIModel = {
        Database: '',
        DefaultSecurity: '',
        EditDate: '',
        FolderType: '',
        HasSubfolders: '',
        Id: '',
        IsContainerSavedSearch: '',
        IsContentSavedSearch: '',
        IsExternalAsNormal: '',
        IsHidden: '',
        Name: '',
        Owner: '',
        ParentId: '',
        SubType: '',
        ViewType: '',
        Wstype: ''
    };

    var returnWorkSpaceInitialValueSettings = function () {
        return angular.copy(workSpaceUIModel);
    };

    function getWorkSpaceUIModel(workSpaceApiModel) {
        var workSpaceModel = angular.copy(workSpaceUIModel);
        workSpaceModel.Author = workSpaceApiModel[CONST_WORKSPACE.Author];//.user_id_ex;
        workSpaceModel.Class = workSpaceApiModel[CONST_WORKSPACE.Class];
        workSpaceModel.CreateDate = GetDate(workSpaceApiModel[CONST_WORKSPACE.CreateDate]);
        workSpaceModel.Custom1 = workSpaceApiModel[CONST_WORKSPACE.Custom1];
        workSpaceModel.Custom2 = workSpaceApiModel[CONST_WORKSPACE.Custom2];
        workSpaceModel.Custom3 = workSpaceApiModel[CONST_WORKSPACE.Custom3];
        workSpaceModel.Database = workSpaceApiModel[CONST_WORKSPACE.Database];
        workSpaceModel.DefaultSecurity = workSpaceApiModel[CONST_WORKSPACE.DefaultSecurity];
        workSpaceModel.DocumentNumber = workSpaceApiModel[CONST_WORKSPACE.DocumentNumber];
        workSpaceModel.EditDate = GetDate(workSpaceApiModel[CONST_WORKSPACE.EditDate]);
        workSpaceModel.EditProfileDate = GetDate(workSpaceApiModel[CONST_WORKSPACE.EditProfileDate]);
        workSpaceModel.FileCreateDate = GetDate(workSpaceApiModel[CONST_WORKSPACE.FileCreateDate]);
        workSpaceModel.FileEditDate = GetDate(workSpaceApiModel[CONST_WORKSPACE.FileEditDate]);
        workSpaceModel.HasAttachment = workSpaceApiModel[CONST_WORKSPACE.HasAttachment];
        workSpaceModel.HasSubfolders = workSpaceApiModel[CONST_WORKSPACE.HasSubfolders];
        workSpaceModel.Id = workSpaceApiModel[CONST_WORKSPACE.Id];

        workSpaceModel.Owner = workSpaceApiModel[CONST_WORKSPACE.Owner];
        workSpaceModel.RetainDays = workSpaceApiModel[CONST_WORKSPACE.RetainDays];
        workSpaceModel.Size = workSpaceApiModel[CONST_WORKSPACE.Size];
        workSpaceModel.Subtype = workSpaceApiModel[CONST_WORKSPACE.Subtype];
        workSpaceModel.Type = workSpaceApiModel[CONST_WORKSPACE.Type];
        workSpaceModel.Version = workSpaceApiModel[CONST_WORKSPACE.Version];
        workSpaceModel.Wstype = workSpaceApiModel[CONST_WORKSPACE.Wstype];

        workSpaceModel.InUse = workSpaceApiModel[CONST_WORKSPACE.InUse];
        workSpaceModel.Operator = workSpaceApiModel[CONST_WORKSPACE.Operator];
        workSpaceModel.Name = workSpaceApiModel[CONST_WORKSPACE.Name];
        workSpaceModel.Location = workSpaceApiModel[CONST_WORKSPACE.Location];
        workSpaceModel.LastUser = workSpaceApiModel[CONST_WORKSPACE.LastUser];
        workSpaceModel.Iwl = workSpaceApiModel[CONST_WORKSPACE.Iwl];
        workSpaceModel.IsHipaa = workSpaceApiModel[CONST_WORKSPACE.IsHipaa];
        workSpaceModel.IsHidden = workSpaceApiModel[CONST_WORKSPACE.IsHidden];
        workSpaceModel.IsExternalAsNormal = workSpaceApiModel[CONST_WORKSPACE.IsExternalAsNormal];
        workSpaceModel.IsExternal = workSpaceApiModel[CONST_WORKSPACE.IsExternal];
        workSpaceModel.IsContentSavedSearch = workSpaceApiModel[CONST_WORKSPACE.IsContentSavedSearch];

        workSpaceModel.Indexable = workSpaceApiModel[CONST_WORKSPACE.Indexable];
        workSpaceModel.IsCheckedOut = workSpaceApiModel[CONST_WORKSPACE.IsCheckedOut];
        workSpaceModel.IsContainerSavedSearch = workSpaceApiModel[CONST_WORKSPACE.IsContainerSavedSearch];

        return workSpaceModel;
    }

    function GetMonthName(monthNumber) {
        var month = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        return month[monthNumber - 1];
    }

    function GetDate(dateString) {
        var dateObj = new Date(dateString);
        if (dateObj != 'Invalid Date') {
            var monthNumber = dateObj.getMonth() + 1;
            var monthName = GetMonthName(monthNumber);
            return monthName + " " + dateObj.getDate() + ", " + dateObj.getFullYear();

        }
        else {
            return '';
        }
    }

    var returnWorkSpaceUIModel = function (workSpaceApiModel) {
        return getWorkSpaceUIModel(workSpaceApiModel);
    };

    var returngetFolderUI = function (folderApiModel) {
        return getFolderUIModel(folderApiModel);
    }

    function getFolderUIModel(folderApiModel) {
        var folderModel = angular.copy(folderUIModel);
        folderModel.Database = folderApiModel[CONST_TEMPLATE_FOLDER.Database];
        folderModel.DefaultSecurity = folderApiModel[CONST_TEMPLATE_FOLDER.DefaultSecurity];
        folderModel.EditDate = GetDate(folderApiModel[CONST_TEMPLATE_FOLDER.EditDate]);
        folderModel.FolderType = folderApiModel[CONST_TEMPLATE_FOLDER.FolderType];
        folderModel.HasSubfolders = folderApiModel[CONST_TEMPLATE_FOLDER.HasSubfolders];
        folderModel.Id = folderApiModel[CONST_TEMPLATE_FOLDER.Id];
        folderModel.IsContainerSavedSearch = folderApiModel[CONST_TEMPLATE_FOLDER.IsContainerSavedSearch];
        folderModel.IsContentSavedSearch = folderApiModel[CONST_TEMPLATE_FOLDER.IsContentSavedSearch];
        folderModel.IsExternalAsNormal = folderApiModel[CONST_TEMPLATE_FOLDER.IsExternalAsNormal];
        folderModel.IsHidden = folderApiModel[CONST_TEMPLATE_FOLDER.IsHidden];
        folderModel.Name = folderApiModel[CONST_TEMPLATE_FOLDER.Name];
        folderModel.Owner = folderApiModel[CONST_TEMPLATE_FOLDER.Owner];
        folderModel.ParentId = folderApiModel[CONST_TEMPLATE_FOLDER.ParentId];
        folderModel.SubType = folderApiModel[CONST_TEMPLATE_FOLDER.SubType];
        folderModel.ViewType = folderApiModel[CONST_TEMPLATE_FOLDER.ViewType];
        folderModel.Wstype = folderApiModel[CONST_TEMPLATE_FOLDER.Wstype];       
        return folderModel;
    }

    function prepareFolderGetUrl(URL, requestModel) {
        var apiGetUrl = URL + '?offset=' + ((requestModel.pagenumber - 1) * requestModel.pageLength).toString();
        apiGetUrl += '&limit=' + requestModel.pageLength.toString() + '&total=' + requestModel.isTotal;
        requestModel.searchText = requestModel.searchText.trim();
        if (requestModel.searchText.length > 0) {
            apiGetUrl += '&name=*' + requestModel.searchText + '*';
        }
        return apiGetUrl;
    }

    var returnAPIUrl = function (APIFOR, requestModel) {
        var ApiUrl = baseUrl + TSU_TEMPLATES[APIFOR];

        //if (APIFOR == 'CHECKUSERACCESS') {
        //    ApiUrl = ApiUrl.replace('{WS_ID}', requestModel.Id); 
        //}
        if (APIFOR === 'SEARCHWORKSPACE' && requestModel !== null) {
            ApiUrl = prepareGetUrl(ApiUrl, requestModel);
        }
        else if (APIFOR == 'GETFOLDERSFROMWORKSPCE') {
            ApiUrl = ApiUrl.replace('{WS_ID}', requestModel.Id);
            ApiUrl = prepareFolderGetUrl(ApiUrl, requestModel);
        }
        else if (APIFOR == 'GETSUBFOLDERFROMFOLDER') {
            ApiUrl = ApiUrl.replace('{FOLDER_ID}', requestModel.Id);
            ApiUrl = prepareFolderGetUrl(ApiUrl, requestModel);
        }
        return ApiUrl;
    };

    function prepareGetUrl(URL, requestModel) {
        var apiGetUrl = URL + '?offset=' + ((requestModel.pagenumber - 1) * requestModel.pageLength).toString();
        apiGetUrl += '&limit=' + requestModel.pageLength.toString() + '&total=' + requestModel.isTotal;       
        requestModel.searchText = requestModel.searchText.trim();
        if (requestModel.searchText.length > 0) {
            //apiGetUrl += '&anywhere=*' + requestModel.searchText + '*';
            apiGetUrl += '&name=*' + requestModel.searchText + '*';
            //apiGetUrl += '&database=*' + requestModel.searchText + '*';
            //apiGetUrl += '&custom1=*' + requestModel.searchText + '*';
            //apiGetUrl += '&custom2=*' + requestModel.searchText + '*';
        }
        return apiGetUrl;
    }


    return {
        workSpaceInitailValues: returnWorkSpaceInitialValueSettings,
        getworkSpaceUI: returnWorkSpaceUIModel,
        getAPIUrl: returnAPIUrl,
        getFolderUI: returngetFolderUI
    }
}