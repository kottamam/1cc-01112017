﻿app.factory('userFactory', userFactory);
userFactory.$inject = ['WRSU_USERS','CONST_USERS','$q','UserService'];
function userFactory(WRSU_USERS, CONST_USERS, $q, UserService) {

    var userUIModel = {
        UserId: '',
        FullName: '',
        Location: '',
        Phone: '',
        Ext: '',
        Fax: '',
        Email: '',
        IsExternalUser: false,
        Password: '',
        UserMustChangePassword: true,
        PasswordNeverExpires: false,
        IsAllowLogon: true,
        PreferredDatabase: '',
        FileServer: '',
        SecuredDocServer: '',
        UserNos: 0,
        UserNum: 0,
        UserIdEx: '',
        FailedLogin: '',
        DistName: '',
        UserDomain: '',
        ExchAutoDiscover: '',
        LastEdited: '',
        PasswordChangeDate: '',
        LastSyncDate: '',
        DateAccountLocked: '',
        PasswordChangeDate: ''
    }


    var userApiModel = {
        user_id_ex: '',
        full_name: '',
        location: '',
        phone: '',
        extension: '',
        fax: '',
        email: '',
        is_external: true,
        user_password: '',
        force_password_change: true,
        pwd_never_expire: true,
        login: true,
        preferred_database: '',
        doc_server: '',
        secure_docserver: '',
        user_nos: 0,
        user_num: 0,
        pwd_changed_ts: '',
        last_sync_ts: '',
        lockout_ts: '',
        pwd_changed_ts: '',
    }


    var validationSettings = {
        showMessage: false,
        confirmationPassword: ''
    }

    var returnUserInitialValueSettings = function () {
        return angular.copy(userUIModel);
    }

    var returnUserValidationSettings = function () {
        return angular.copy(validationSettings);
    }

    function getUserUIModel(userApiModel) {
        var userModel = angular.copy(userUIModel);
        userModel.UserId = userApiModel[CONST_USERS.UserIdEx];//.user_id_ex;
        userModel.FullName = userApiModel[CONST_USERS.FullName];
        userModel.Location = userApiModel[CONST_USERS.Location];
        userModel.Phone = userApiModel[CONST_USERS.Phone];
        userModel.Ext = userApiModel[CONST_USERS.Ext];
        userModel.Fax = userApiModel[CONST_USERS.Fax];
        userModel.Email = userApiModel[CONST_USERS.Email] ? userApiModel[CONST_USERS.Email] : '';
        userModel.IsExternalUser = userApiModel[CONST_USERS.IsExternalUser];
        userModel.Password = userApiModel[CONST_USERS.Password];
        userModel.UserMustChangePassword = userApiModel[CONST_USERS.UserMustChangePassword];
        userModel.PasswordNeverExpires = userApiModel[CONST_USERS.PasswordNeverExpires];
        userModel.IsAllowLogon = userApiModel[CONST_USERS.IsAllowLogon];
        userModel.PreferredDatabase = userApiModel[CONST_USERS.PreferredDatabase];
        userModel.FileServer = userApiModel[CONST_USERS.FileServer];
        userModel.SecuredDocServer = userApiModel[CONST_USERS.SecuredDocServer];
        userModel.UserNos = GetUserNosDisplay(userApiModel[CONST_USERS.UserNos]);
        userModel.UserNum = userApiModel[CONST_USERS.UserNum];
        userModel.UserIdEx = userApiModel[CONST_USERS.UserId];
        userModel.FailedLogin = userApiModel[CONST_USERS.FailedLogin];
        userModel.DistName = userApiModel[CONST_USERS.DistName];
        userModel.UserDomain = userApiModel[CONST_USERS.UserDomain];
        userModel.ExchAutoDiscover = userApiModel[CONST_USERS.ExchAutoDiscover];
        userModel.LastEdited = GetDate(userApiModel[CONST_USERS.LastEdited]);
        userModel.PasswordChangeDate = GetDate(userApiModel[CONST_USERS.PasswordChangeDate]);
        userModel.LastSyncDate = GetDate(userApiModel[CONST_USERS.LastSyncDate]);
        userModel.DateAccountLocked = GetDate(userApiModel[CONST_USERS.DateAccountLocked]);
        userModel.PasswordChangeDate = GetDate(userApiModel[CONST_USERS.PasswordChangeDate]);
        //SecurityTemplate
        return userModel;

    }


    function getUserInGroupUIModel(userApiModel) {
        var userModel = angular.copy(userUIModel);
        userModel.UserId = userApiModel[CONST_USERS.UserIDForUserInGroup];
        userModel.FullName = userApiModel[CONST_USERS.FullName];
        userModel.Location = userApiModel[CONST_USERS.Location];
        userModel.Phone = userApiModel[CONST_USERS.Phone];
        userModel.Ext = userApiModel[CONST_USERS.Ext];
        userModel.Fax = userApiModel[CONST_USERS.Fax];
        userModel.Email = userApiModel[CONST_USERS.Email];
        userModel.IsExternalUser = userApiModel[CONST_USERS.IsExternalUser];
        userModel.Password = userApiModel[CONST_USERS.Password];
        userModel.UserMustChangePassword = userApiModel[CONST_USERS.UserMustChangePassword];
        userModel.PasswordNeverExpires = userApiModel[CONST_USERS.PasswordNeverExpires];
        userModel.IsAllowLogon = userApiModel[CONST_USERS.IsAllowLogon];
        userModel.PreferredDatabase = userApiModel[CONST_USERS.PreferredDatabase];
        userModel.FileServer = userApiModel[CONST_USERS.FileServer];
        userModel.SecuredDocServer = userApiModel[CONST_USERS.SecuredDocServer];
        userModel.UserNos = GetUserNosDisplay(userApiModel[CONST_USERS.UserNos]);
        userModel.UserNum = userApiModel[CONST_USERS.UserNum];
        userModel.UserIdEx = userApiModel[CONST_USERS.UserIdEx];
        userModel.FailedLogin = userApiModel[CONST_USERS.FailedLogin];
        userModel.DistName = userApiModel[CONST_USERS.DistName];
        userModel.UserDomain = userApiModel[CONST_USERS.UserDomain];
        userModel.ExchAutoDiscover = userApiModel[CONST_USERS.ExchAutoDiscover];
        userModel.LastEdited = GetDate(userApiModel[CONST_USERS.LastEdited]);
        userModel.PasswordChangeDate = GetDate(userApiModel[CONST_USERS.PasswordChangeDate]);
        userModel.LastSyncDate = GetDate(userApiModel[CONST_USERS.LastSyncDate]);
        userModel.DateAccountLocked = GetDate(userApiModel[CONST_USERS.DateAccountLocked]);
        userModel.PasswordChangeDate = GetDate(userApiModel[CONST_USERS.PasswordChangeDate]);
        return userModel;

    }

    function GetUserNosDisplay(nos) {
        if (nos == 2) {
            return 'VIRTUAL';
        } else {
            return '';
        }

    }

    function GetApiUserNos(nos) {
        if (nos == 'VIRTUAL') {
            return 2;
        } else {
            return 2;
        }

    }

    function GetMonthName(monthNumber) {
        var month = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        return month[monthNumber - 1];
    }

    function GetDate(dateString) {
    	var dateObj = new Date(dateString);
    	 if (dateObj != 'Invalid Date') {
    	var monthNumber = dateObj.getMonth() + 1;
        var monthName = GetMonthName(monthNumber);
        return monthName + " " + dateObj.getDate() + ", " + dateObj.getFullYear();
    	 }else
    	{ return '';}
      /*  var dateObj = new Date(dateString * 1000);
        if (dateObj != 'Invalid Date') {
            var monthNumber = dateObj.getMonth() + 1;
            var monthName = GetMonthName(monthNumber);
            return monthName + " " + dateObj.getDate() + ", " + dateObj.getFullYear();

        } else {
            return '';

        }*/
    }

    function getUserApiPostModel(userUIModel, dbName) {
        var userModelApi = {}; //angular.copy(userApiModel);
        userModelApi[CONST_USERS.DataBase] = dbName
        userModelApi[CONST_USERS.IsExternalUser] = userUIModel.IsExternalUser;
        userModelApi[CONST_USERS.Password] = userUIModel.Password;
        userModelApi[CONST_USERS.UserMustChangePassword] = userUIModel.UserMustChangePassword;
        userModelApi[CONST_USERS.PasswordNeverExpires] = userUIModel.PasswordNeverExpires;
        userModelApi[CONST_USERS.IsAllowLogon] = userUIModel.IsAllowLogon;
        //userModelApi.user_id_ex=userUIModel.UserId;
        userModelApi[CONST_USERS.UserId] = userUIModel.UserId;
        userModelApi[CONST_USERS.UserIdEx] = userUIModel.UserId;
        userModelApi[CONST_USERS.FullName] = userUIModel.FullName;
        userModelApi[CONST_USERS.Location] = userUIModel.Location;
        userModelApi[CONST_USERS.Phone] = userUIModel.Phone;
        userModelApi[CONST_USERS.Ext] = userUIModel.Ext;
        userModelApi[CONST_USERS.Fax] = userUIModel.Fax;
        userModelApi[CONST_USERS.Email] = userUIModel.Email;
        userModelApi[CONST_USERS.UserNos] = GetApiUserNos(userUIModel.UserNos);
        userModelApi[CONST_USERS.UserDomain] = "";
        if (userUIModel.PreferredDatabase != null && userUIModel.PreferredDatabase.length > 0)
            userModelApi[CONST_USERS.PreferredDatabase] = userUIModel.PreferredDatabase; // / user.PreferredDatabase
        if (userUIModel.FileServer != null && userUIModel.FileServer.length > 0)
            userModelApi[CONST_USERS.FileServer] = userUIModel.FileServer;

        if (userUIModel.SecuredDocServer != null && userUIModel.SecuredDocServer.length > 0)
            userModelApi[CONST_USERS.SecuredDocServer] = userUIModel.SecuredDocServer;


        return userModelApi;

    }



    function getUserApiPutModel(userUIModel, dbName) {

    	 

        var userModelApi = {}; //angular.copy(userApiModel);
        userModelApi[CONST_USERS.DataBase] = dbName
        userModelApi[CONST_USERS.UserNum] = userUIModel.UserNum;
        userModelApi[CONST_USERS.PasswordNeverExpires] = userUIModel.PasswordNeverExpires;
        userModelApi[CONST_USERS.UserMustChangePassword] = userUIModel.UserMustChangePassword;
        userModelApi[CONST_USERS.IsAllowLogon] = userUIModel.IsAllowLogon;
        userModelApi[CONST_USERS.IsExternalUser] = userUIModel.IsExternalUser;
        userModelApi[CONST_USERS.UserId] = userUIModel.UserId;
        userModelApi[CONST_USERS.UserIdEx] = userUIModel.UserId;
        userModelApi[CONST_USERS.FullName] = userUIModel.FullName;
        userModelApi[CONST_USERS.Location] = userUIModel.Location;
        userModelApi[CONST_USERS.Phone] = userUIModel.Phone;
        userModelApi[CONST_USERS.Ext] = userUIModel.Ext;
        userModelApi[CONST_USERS.Fax] = userUIModel.Fax;
        if (userUIModel.DistName != null && userUIModel.DistName.length > 0)
            userModelApi[CONST_USERS.DistName] = userUIModel.DistName;
        userModelApi[CONST_USERS.Email] = userUIModel.Email;
        if (userUIModel.PreferredDatabase != null && userUIModel.PreferredDatabase.length > 0)
            userModelApi[CONST_USERS.PreferredDatabase] = userUIModel.PreferredDatabase;//   userUIModel.PreferredDatabase

        userModelApi[CONST_USERS.UserNos] = GetApiUserNos(userUIModel.UserNos);
        if (userUIModel.UserDomain != null && userUIModel.UserDomain.length > 0)
           userModelApi[CONST_USERS.UserDomain] = userUIModel.UserDomain;
        
        if (userUIModel.ExchAutoDiscover != null && userUIModel.ExchAutoDiscover.length > 0)
            userModelApi[CONST_USERS.ExchAutoDiscover]= userUIModel.ExchAutoDiscover;
       
        if (userUIModel.Password != null && userUIModel.Password.length > 0)
            userModelApi[CONST_USERS.Password] = userUIModel.Password;

        if (userUIModel.FileServer != null && userUIModel.FileServer.length > 0)
            userModelApi[CONST_USERS.FileServer] = userUIModel.FileServer;

        if (userUIModel.SecuredDocServer != null && userUIModel.SecuredDocServer.length > 0)
            userModelApi[CONST_USERS.SecuredDocServer] = userUIModel.SecuredDocServer;


        return userModelApi;

    }



    var returnSingleUser = function (APIFOR, dbName, alias, key) {
        var deferred = $q.defer();
        var ApiUrl = baseUrl + WRSU_USERS[APIFOR]
        ApiUrl += '?' + CONST_USERS.DataBase + '=' + dbName + '&' + CONST_USERS.Alias + '=' + alias;
        var promise = UserService.getSingleUser(ApiUrl, key);
        promise.then(function (response) {

            deferred.resolve(response.data);

        });

        return deferred.promise;
    }

    var returnUserUIModel = function (userApiModel) {
        return getUserUIModel(userApiModel);

    }

    var returnUserInGroupUIModel = function (userApiModel) {
        return getUserInGroupUIModel(userApiModel);

    }

    var returnUserApiPostModel = function (user, dbName) {
        return getUserApiPostModel(user, dbName);

    }

    var returnUserApiPutModel = function (user, dbName) {
        return getUserApiPutModel(user, dbName);

    }

    var returnAPIUrl = function (APIFOR, requestModel, userId, dbName, action) {
        var ApiUrl = '';
       
            ApiUrl = baseUrl + WRSU_USERS[APIFOR];
       
            ApiUrl=	ApiUrl.replace("{ALIAS}", userId);
        if (APIFOR == 'GETUSERSOFGROUPFROMUSER') {
             
            ApiUrl = prepareUrluserOfGroups(ApiUrl, requestModel, userId, dbName);
        } 
        else if (requestModel != null) {
            ApiUrl = prepareUrl(ApiUrl, requestModel);

        }

        return ApiUrl;

    }
    function prepareAssignGroupUrl(URL, group, User, dbName, action) {
        //var ApiUrl = URL;
        //if (user.Action == "add")
        //	return URL + "?dbName=" + user.DbName + '&groupName='
        //			+ user.GroupName + '&user=' + user.userName + '&action=addUser';				 
        //else if (user.Action == "remove")
        //	return URL + "?dbName=" + user.DbName + '&groupName='
        //			+ user.GroupName + '&user=' + user.userName + '&action=deleteUser';
        var ApiUrl = URL;
        if (action == "add")
            return URL + "?dbName=" + dbName + '&user=' + User + '&groupName=' + group + '&action=addUser';
        else if (action == "remove")
            return URL + "?dbName=" + dbName + '&user=' + User + '&groupName=' + group + '&action=deleteUser';
        else if (action == "enable")
            return URL + "?dbName=" + dbName + '&groupName=' + group + '&action=enableGroup';
        else if (action == "disable")
            return URL + "?dbName=" + dbName + '&groupName=' + group + '&action=disableGroup';

    }

    function prepareUrluserOfGroups(URL, groups, groupName, dbName) {
        var apiUrl = URL.replace("<groupId>", groupName);
        apiUrl = apiUrl.replace("<dbName>", dbName);

        var aliasString = '';
        if (groups.length > 0) {
            angular.forEach(groups, function (grp) {
                if (aliasString.trim().length > 0) {
                    aliasString += ',';
                }
                aliasString += grp;
            });
        }
        apiUrl = apiUrl.replace("<alias>", aliasString);
        return apiUrl;

        //var ApiUrl = URL + "?dbName=" + dbName + '&groupName=' + groupName + '&UserName=';
        //if (groups.length > 0) {
        //    angular.forEach(groups, function (grp) {
        //        if (ApiUrl.indexOf('=', ApiUrl.length - 1) !== -1) {
        //            ApiUrl += grp;
        //        } else {
        //            ApiUrl += ',' + grp;
        //        }
        //    });
        //}
        //return ApiUrl;
    }

    //function prepareUrluserOfGroups(URL, requestModel) {

    //	var ApiUrl = URL + "?dbName=" + requestModel.DbName + '&groupName='
    //			+ requestModel.GroupName + '&UserName=';
    //	if (requestModel.Users.length > 0) {
    //		angular.forEach(requestModel.Users, function(grp) {
    //			if (ApiUrl.indexOf('=', ApiUrl.length - 1) !== -1) {
    //				ApiUrl += grp;
    //			} else {
    //				ApiUrl += ',' + grp;
    //			}
    //		});
    //	}
    //	return ApiUrl;
    //}

    function prepareUserListUrlOnOffset(URL, requestModel) {
        var ApiUrl = URL + "?database=" + requestModel.libraryName + '&offset=' + requestModel.pagenumber + '&limit=' + requestModel.pageLength + '&total=' + requestModel.isTotal;
        if (requestModel.searchText != null && requestModel.searchText != '')
            ApiUrl += '&query=*' + requestModel.searchText + '*'
        if (requestModel.filters.length > 0) {
            angular.forEach(requestModel.filters, function (filterItem) {
                if (filterItem.FilterValues[0] != null && filterItem.FilterValues[0] != '') {
                    if (filterItem.FilterKey == 'IsAllowLogon' || filterItem.FilterKey == 'IsExternalUser' || filterItem.FilterKey == 'PasswordNeverExpires') {
                        ApiUrl += '&' + CONST_USERS[filterItem.FilterKey + 'Filter'] + '=' + (filterItem.FilterValues[0] == "Y" ? 'true' : 'false');


                    } else {
                        ApiUrl += '&' + CONST_USERS[filterItem.FilterKey + 'Filter'] + '=*' + filterItem.FilterValues[0] + '*'

                    }
                }
            });
        }
        return ApiUrl;
    }

    function prepareUrl(URL, requestModel) {
        var ApiUrl = URL + "?database=" + requestModel.libraryName + '&offset=' + ((requestModel.pagenumber - 1) * requestModel.pageLength) + '&limit=' + requestModel.pageLength + '&total=' + requestModel.isTotal;
        if (requestModel.searchText != null && requestModel.searchText != '')
            ApiUrl += '&query=*' + requestModel.searchText + '*'
        if (requestModel.filters.length > 0) {
            angular.forEach(requestModel.filters, function (filterItem) {
                if (filterItem.FilterValues[0] != null && filterItem.FilterValues[0] != '') {
                    if (filterItem.FilterKey == 'IsAllowLogon' || filterItem.FilterKey == 'IsExternalUser' || filterItem.FilterKey == 'PasswordNeverExpires') {
                        ApiUrl += '&' + CONST_USERS[filterItem.FilterKey + 'Filter'] + '=' + (filterItem.FilterValues[0] == "Y" ? 'true' : 'false');


                    } else {
                        ApiUrl += '&' + CONST_USERS[filterItem.FilterKey + 'Filter'] + '=*' + filterItem.FilterValues[0] + '*'

                    }
                }
            });
        }
        return ApiUrl;
    }

    function prepareRoleLessUsersUrl(requestModel) {
        var apiUrl = baseUrl + WRSU_USERS['GETROLELESSUSERS'];
        apiUrl += '?database=' + requestModel.libraryName;
        apiUrl += '&offset=' + ((requestModel.pagenumber - 1) * requestModel.pageLength);
        apiUrl += '&limit=' + requestModel.pageLength;
        apiUrl += '&total=' + requestModel.isTotal;
        apiUrl += '&query=*' + requestModel.searchText + '*';

        return apiUrl;
    }

    var returnUserGroupsAPI = function (requestModel, userId) {
        var apiUrl = baseUrl + WRSU_USERS['GETUSERGROUPS'];
        apiUrl += "/" + userId + "/groups?database=" + requestModel.libraryName + '&offset=' + requestModel.pagenumber +
                    '&limit=' + requestModel.pageLength + '&total=' + requestModel.isTotal;

        if (requestModel.searchText.trim().length > 0)
            apiUrl += '&alias=*' + requestModel.searchText.trim() + '*';

        return apiUrl;
    };

    var returnNonUserGroupsAPI = function (requestModel, userId) {
        var apiUrl = baseUrl + WRSU_USERS['GET_OUT_OF_GROUPS'];
        apiUrl = apiUrl.replace("<userid>", userId);

        apiUrl += '?database=' + requestModel.libraryName + '&offset=' + requestModel.pagenumber +
                    '&limit=' + requestModel.pageLength + '&total=' + requestModel.isTotal;

        if (requestModel.searchText.trim().length > 0)
            apiUrl += '&alias=*' + requestModel.searchText.trim() + '*';

        return apiUrl;
    };

    return {
        userInitailValues: returnUserInitialValueSettings,
        validations: returnUserValidationSettings,
        getUserUI: returnUserUIModel,
        getUserInGroupUI: returnUserInGroupUIModel,
        getUserPostModel: returnUserApiPostModel,
        getUserPutModel: returnUserApiPutModel,
        getAPIUrl: returnAPIUrl,
        getSingleUser: returnSingleUser,
        getRoleLessUsers: prepareRoleLessUsersUrl,
        getUserGroupsAPI: returnUserGroupsAPI,
        getNonUserGroupsAPI: returnNonUserGroupsAPI
    }
}