﻿app.factory('loginFactory', loginFactory);
loginFactory.$inject = ['$http', '$q', 'HomeService', 'groupFactory', 'GroupService','WRSU_MASTER'];

function loginFactory($http, $q, homeService, groupFactory, GroupService, WRSU_MASTER) {
    
    function loadsettings() {
        var deferred = $q.defer();
        var x2js = new X2JS();
        var todayDate = (new Date()).toJSON();
        var promise = $http.get("content/settings.xml?v=" + todayDate)

        promise.then(function (response) {
            var navXml = x2js.xml_str2json(response.data);
            var sectionsObj = navXml.root.groupprefix;
            deferred.resolve(sectionsObj);
        });
        return deferred.promise;
    }

    function premittedUser(loginmodel) {
        var deferred = $q.defer();
        var x2js = new X2JS();

        var promise = homeService.getDBLibraries(loginmodel);
        promise.then(function (responsedb) {

            if (responsedb && responsedb.data && responsedb.data.data && responsedb["data"]["data"].length) {
                angular.forEach(responsedb["data"]["data"], function (db) {
                    var dbname = db.database;

                    var promiseOne = homeService.getData(getAPIUrl('GETGROUPSOFUSERFROMGROUPS', ['NRTADMIN'], loginmodel.UserName, dbname), loginmodel.AuthKey)
                    promiseOne.then(function (responsegroups) {
                        deferred.resolve(responsegroups.data.data);
                    });
                });
            } else {
                deferred.resolve();
            }
        });
        return deferred.promise;
    }
    function getAPIUrl(APIFOR, requestModel, userId, dbName, action) {
        var ApiUrl = '';
        ApiUrl = baseUrl + WRSU_MASTER[APIFOR];

        if (APIFOR == 'GETGROUPSOFUSERFROMGROUPS') {
            ApiUrl = prepareUrlGroupsOfUser(ApiUrl, requestModel, userId, dbName);

        }
        return ApiUrl;
    };
    function prepareUrlGroupsOfUser(URL, groups, User, dbName) {
        var apiUrl = URL.replace("<userId>", User);
        apiUrl = apiUrl.replace("<dbName>", dbName);

        var aliasString = '';
        if (groups.length > 0) {
            angular.forEach(groups, function (grp) {
                if (aliasString.trim().length > 0) {
                    aliasString += ',';
                }
                aliasString += grp;
            });
        }
        apiUrl = apiUrl.replace("<alias>", aliasString);
        return apiUrl;
    }



    var returnrequestModelDef = function (loginmodel) {
        return premittedUser(loginmodel);
    };

    return {
        getpremittedUser: premittedUser
    };
};