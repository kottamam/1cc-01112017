app.factory('workSpaceFactory', workSpaceFactory);
workSpaceFactory.$inject = ['WRSU_WORKSPACE', 'CONST_WORKSPACE', 'CONST_WORKSPACE_SECURITY', '$q'];
function workSpaceFactory(WRSU_WORKSPACE, CONST_WORKSPACE, CONST_WORKSPACE_SECURITY, $q) {

    var workSpaceUIModel = {
        Id: '',
        Author: '',
        Class: '',
        CreateDate: '',
        Custom1: '',
        Custom2: '',
        Custom3: '',
        Database: '',
        DefaultSecurity: '',
        DocumentNumber: 0,
        EditDate: '',
        EditProfileDate: '',
        FileCreateDate: '',
        FileEditDate: '',
        Iwl: '',
        LastUser: '',
        Location: '',
        Name: '',
        Operator: '',
        Owner: '',
        RetainDays: 0,
        Size: 0,
        Subtype: '',
        Type: '',
        Version: 0,
        Wstype: '',
        HasAttachment: false,
        HasSubfolders: false,
        InUse: false,
        Indexable: false,
        IsCheckedOut: false,
        IsContainerSavedSearch: false,
        IsContentSavedSearch: false,
        IsExternal: false,
        IsExternalAsNormal: false,
        IsHidden: false,
        IsHipaa: false
    };

    var workspaceSecurityUIModel = {
        Id: '',
        Type: '',
        Name: '',
        AllowLogin: false,
        AccessRight: ''
    };

    var returnWorkspaceSecurityUIModelSettings = function () {
        return angular.copy(workspaceSecurityUIModel);
    };

    function getWorkSpaceSecurityUIModel(securityApiModel) {
        var securityTempModel = angular.copy(workspaceSecurityUIModel);

        securityTempModel.Id = securityApiModel[CONST_WORKSPACE_SECURITY.Id];

        switch (securityApiModel[CONST_WORKSPACE_SECURITY.Type]) {
            case 'user':
                securityTempModel.Type = 'User';
                break;

            case 'group':
                securityTempModel.Type = 'Group';
                break;

            default:
                securityTempModel.Type = '';
                break;
        }

        switch (securityApiModel[CONST_WORKSPACE_SECURITY.Access]) {
            case 'no_access':
                securityTempModel.AccessRight = 'No Access';
                break;

            case 'read':
                securityTempModel.AccessRight = 'Read';
                break;

            case 'read_write':
                securityTempModel.AccessRight = 'Read Write';
                break;

            case 'full_access':
                securityTempModel.AccessRight = 'Full Access';
                break;

            default:
                securityTempModel.AccessRight = '';
                break;
        }
        return securityTempModel;
    }

    var returnWorkSpaceSecurityUIModel = function (securityApiModel) {
        return getWorkSpaceSecurityUIModel(securityApiModel);
    };

    var returnWorkSpaceInitialValueSettings = function () {
        return angular.copy(workSpaceUIModel);
    };

    function getWorkSpaceUIModel(workSpaceApiModel) {
        var workSpaceModel = angular.copy(workSpaceUIModel);
        workSpaceModel.Author = workSpaceApiModel[CONST_WORKSPACE.Author];//.user_id_ex;
        workSpaceModel.Class = workSpaceApiModel[CONST_WORKSPACE.Class];
        workSpaceModel.CreateDate = GetDate(workSpaceApiModel[CONST_WORKSPACE.CreateDate]);
        workSpaceModel.Custom1 = workSpaceApiModel[CONST_WORKSPACE.Custom1];
        workSpaceModel.Custom2 = workSpaceApiModel[CONST_WORKSPACE.Custom2];
        workSpaceModel.Custom3 = workSpaceApiModel[CONST_WORKSPACE.Custom3];
        workSpaceModel.Database = workSpaceApiModel[CONST_WORKSPACE.Database];
        workSpaceModel.DefaultSecurity = workSpaceApiModel[CONST_WORKSPACE.DefaultSecurity];
        workSpaceModel.DocumentNumber = workSpaceApiModel[CONST_WORKSPACE.DocumentNumber];
        workSpaceModel.EditDate = GetDate(workSpaceApiModel[CONST_WORKSPACE.EditDate]);
        workSpaceModel.EditProfileDate = GetDate(workSpaceApiModel[CONST_WORKSPACE.EditProfileDate]);
        workSpaceModel.FileCreateDate = GetDate(workSpaceApiModel[CONST_WORKSPACE.FileCreateDate]);
        workSpaceModel.FileEditDate = GetDate(workSpaceApiModel[CONST_WORKSPACE.FileEditDate]);
        workSpaceModel.HasAttachment = workSpaceApiModel[CONST_WORKSPACE.HasAttachment];
        workSpaceModel.HasSubfolders = workSpaceApiModel[CONST_WORKSPACE.HasSubfolders];
        workSpaceModel.Id = workSpaceApiModel[CONST_WORKSPACE.Id];

        workSpaceModel.Owner = workSpaceApiModel[CONST_WORKSPACE.Owner];
        workSpaceModel.RetainDays = workSpaceApiModel[CONST_WORKSPACE.RetainDays];
        workSpaceModel.Size = workSpaceApiModel[CONST_WORKSPACE.Size];
        workSpaceModel.Subtype = workSpaceApiModel[CONST_WORKSPACE.Subtype];
        workSpaceModel.Type = workSpaceApiModel[CONST_WORKSPACE.Type];
        workSpaceModel.Version = workSpaceApiModel[CONST_WORKSPACE.Version];
        workSpaceModel.Wstype = workSpaceApiModel[CONST_WORKSPACE.Wstype];

        workSpaceModel.InUse = workSpaceApiModel[CONST_WORKSPACE.InUse];
        workSpaceModel.Operator = workSpaceApiModel[CONST_WORKSPACE.Operator];
        workSpaceModel.Name = workSpaceApiModel[CONST_WORKSPACE.Name];
        workSpaceModel.Location = workSpaceApiModel[CONST_WORKSPACE.Location];
        workSpaceModel.LastUser = workSpaceApiModel[CONST_WORKSPACE.LastUser];
        workSpaceModel.Iwl = workSpaceApiModel[CONST_WORKSPACE.Iwl];
        workSpaceModel.IsHipaa = workSpaceApiModel[CONST_WORKSPACE.IsHipaa];
        workSpaceModel.IsHidden = workSpaceApiModel[CONST_WORKSPACE.IsHidden];
        workSpaceModel.IsExternalAsNormal = workSpaceApiModel[CONST_WORKSPACE.IsExternalAsNormal];
        workSpaceModel.IsExternal = workSpaceApiModel[CONST_WORKSPACE.IsExternal];
        workSpaceModel.IsContentSavedSearch = workSpaceApiModel[CONST_WORKSPACE.IsContentSavedSearch];

        workSpaceModel.Indexable = workSpaceApiModel[CONST_WORKSPACE.Indexable];
        workSpaceModel.IsCheckedOut = workSpaceApiModel[CONST_WORKSPACE.IsCheckedOut];
        workSpaceModel.IsContainerSavedSearch = workSpaceApiModel[CONST_WORKSPACE.IsContainerSavedSearch];

        return workSpaceModel;
    }

    function GetMonthName(monthNumber) {
        var month = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        return month[monthNumber - 1];
    }

    function GetDate(dateString) {
        var dateObj = new Date(dateString);
        if (dateObj != 'Invalid Date') {
            var monthNumber = dateObj.getMonth() + 1;
            var monthName = GetMonthName(monthNumber);
            return monthName + " " + dateObj.getDate() + ", " + dateObj.getFullYear();

        }
        else {
            return '';
        }
    }

    function getWorkSpacePostModel(workSpaceModel, dbName) {
        var workSpaceApiModel = {}; //angular.copy(workSpaceApiModel);
        workSpaceApiModel[CONST_WORKSPACE.Author] = workSpaceModel.Author//.user_id_ex;
        workSpaceApiModel[CONST_WORKSPACE.Class] = workSpaceModel.Class;
        workSpaceApiModel[CONST_WORKSPACE.CreateDate] = workSpaceModel.CreateDate;
        workSpaceApiModel[CONST_WORKSPACE.Custom1] = workSpaceModel.Custom1;
        workSpaceApiModel[CONST_WORKSPACE.Custom2] = workSpaceModel.Custom2;
        workSpaceApiModel[CONST_WORKSPACE.Custom3] = workSpaceModel.Custom3;
        workSpaceApiModel[CONST_WORKSPACE.Database] = workSpaceModel.Database;
        workSpaceApiModel[CONST_WORKSPACE.DefaultSecurity] = workSpaceModel.DefaultSecurity;
        workSpaceApiModel[CONST_WORKSPACE.DocumentNumber] = workSpaceModel.DocumentNumber;
        workSpaceApiModel[CONST_WORKSPACE.EditDate] = workSpaceModel.EditDate;
        workSpaceApiModel[CONST_WORKSPACE.EditProfileDate] = workSpaceModel.EditProfileDate;
        workSpaceApiModel[CONST_WORKSPACE.FileCreateDate] = workSpaceModel.FileCreateDate;
        workSpaceApiModel[CONST_WORKSPACE.FileEditDate] = workSpaceModel.FileEditDate;
        workSpaceApiModel[CONST_WORKSPACE.HasAttachment] = workSpaceModel.HasAttachment;
        workSpaceApiModel[CONST_WORKSPACE.HasSubfolders] = workSpaceModel.HasSubfolders;
        workSpaceApiModel[CONST_WORKSPACE.Id] = workSpaceModel.Id;

        workSpaceApiModel[CONST_WORKSPACE.Owner] = workSpaceModel.Owner;
        workSpaceApiModel[CONST_WORKSPACE.RetainDays] = workSpaceModel.RetainDays;
        workSpaceApiModel[CONST_WORKSPACE.Size] = workSpaceModel.Size;
        workSpaceApiModel[CONST_WORKSPACE.Subtype] = workSpaceModel.Subtype;
        workSpaceApiModel[CONST_WORKSPACE.Type] = workSpaceModel.Type;
        workSpaceApiModel[CONST_WORKSPACE.Version] = workSpaceModel.Version;
        workSpaceApiModel[CONST_WORKSPACE.Wstype] = workSpaceModel.Wstype;

        workSpaceApiModel[CONST_WORKSPACE.InUse] = workSpaceModel.InUse;
        workSpaceApiModel[CONST_WORKSPACE.Operator] = workSpaceModel.Operator;
        workSpaceApiModel[CONST_WORKSPACE.Name] = workSpaceModel.Name;
        workSpaceApiModel[CONST_WORKSPACE.Location] = workSpaceModel.Location;
        workSpaceApiModel[CONST_WORKSPACE.LastUser] = workSpaceModel.LastUser;
        workSpaceApiModel[CONST_WORKSPACE.Iwl] = workSpaceModel.Iwl;
        workSpaceApiModel[CONST_WORKSPACE.IsHipaa] = workSpaceModel.IsHipaa;
        workSpaceApiModel[CONST_WORKSPACE.IsHidden] = workSpaceModel.IsHidden;
        workSpaceApiModel[CONST_WORKSPACE.IsExternalAsNormal] = workSpaceModel.IsExternalAsNormal;
        workSpaceApiModel[CONST_WORKSPACE.IsExternal] = workSpaceModel.IsExternal;
        workSpaceApiModel[CONST_WORKSPACE.IsContentSavedSearch] = workSpaceModel.IsContentSavedSearch;

        workSpaceApiModel[CONST_WORKSPACE.Indexable] = workSpaceModel.Indexable;
        workSpaceApiModel[CONST_WORKSPACE.IsCheckedOut] = workSpaceModel.IsCheckedOut;
        workSpaceApiModel[CONST_WORKSPACE.IsContainerSavedSearch] = workSpaceModel.IsContainerSavedSearch;

        return workSpaceApiModel;
    }

    function getWorkSpaceApiPutModel(workSpaceModel, dbName) {
        var workSpaceApiModel = {}; //angular.copy(workSpaceApiModel);
        workSpaceApiModel[CONST_WORKSPACE.Author] = workSpaceModel.Author//.user_id_ex;
        workSpaceApiModel[CONST_WORKSPACE.Class] = workSpaceModel.Class;
        workSpaceApiModel[CONST_WORKSPACE.CreateDate] = workSpaceModel.CreateDate;
        workSpaceApiModel[CONST_WORKSPACE.Custom1] = workSpaceModel.Custom1;
        workSpaceApiModel[CONST_WORKSPACE.Custom2] = workSpaceModel.Custom2;
        workSpaceApiModel[CONST_WORKSPACE.Custom3] = workSpaceModel.Custom3;
        workSpaceApiModel[CONST_WORKSPACE.Database] = workSpaceModel.Database;
        workSpaceApiModel[CONST_WORKSPACE.DefaultSecurity] = workSpaceModel.DefaultSecurity;
        workSpaceApiModel[CONST_WORKSPACE.DocumentNumber] = workSpaceModel.DocumentNumber;
        workSpaceApiModel[CONST_WORKSPACE.EditDate] = workSpaceModel.EditDate;
        workSpaceApiModel[CONST_WORKSPACE.EditProfileDate] = workSpaceModel.EditProfileDate;
        workSpaceApiModel[CONST_WORKSPACE.FileCreateDate] = workSpaceModel.FileCreateDate;
        workSpaceApiModel[CONST_WORKSPACE.FileEditDate] = workSpaceModel.FileEditDate;
        workSpaceApiModel[CONST_WORKSPACE.HasAttachment] = workSpaceModel.HasAttachment;
        workSpaceApiModel[CONST_WORKSPACE.HasSubfolders] = workSpaceModel.HasSubfolders;
        workSpaceApiModel[CONST_WORKSPACE.Id] = workSpaceModel.Id;

        workSpaceApiModel[CONST_WORKSPACE.Owner] = workSpaceModel.Owner;
        workSpaceApiModel[CONST_WORKSPACE.RetainDays] = workSpaceModel.RetainDays;
        workSpaceApiModel[CONST_WORKSPACE.Size] = workSpaceModel.Size;
        workSpaceApiModel[CONST_WORKSPACE.Subtype] = workSpaceModel.Subtype;
        workSpaceApiModel[CONST_WORKSPACE.Type] = workSpaceModel.Type;
        workSpaceApiModel[CONST_WORKSPACE.Version] = workSpaceModel.Version;
        workSpaceApiModel[CONST_WORKSPACE.Wstype] = workSpaceModel.Wstype;

        workSpaceApiModel[CONST_WORKSPACE.InUse] = workSpaceModel.InUse;
        workSpaceApiModel[CONST_WORKSPACE.Operator] = workSpaceModel.Operator;
        workSpaceApiModel[CONST_WORKSPACE.Name] = workSpaceModel.Name;
        workSpaceApiModel[CONST_WORKSPACE.Location] = workSpaceModel.Location;
        workSpaceApiModel[CONST_WORKSPACE.LastUser] = workSpaceModel.LastUser;
        workSpaceApiModel[CONST_WORKSPACE.Iwl] = workSpaceModel.Iwl;
        workSpaceApiModel[CONST_WORKSPACE.IsHipaa] = workSpaceModel.IsHipaa;
        workSpaceApiModel[CONST_WORKSPACE.IsHidden] = workSpaceModel.IsHidden;
        workSpaceApiModel[CONST_WORKSPACE.IsExternalAsNormal] = workSpaceModel.IsExternalAsNormal;
        workSpaceApiModel[CONST_WORKSPACE.IsExternal] = workSpaceModel.IsExternal;
        workSpaceApiModel[CONST_WORKSPACE.IsContentSavedSearch] = workSpaceModel.IsContentSavedSearch;

        workSpaceApiModel[CONST_WORKSPACE.Indexable] = workSpaceModel.Indexable;
        workSpaceApiModel[CONST_WORKSPACE.IsCheckedOut] = workSpaceModel.IsCheckedOut;
        workSpaceApiModel[CONST_WORKSPACE.IsContainerSavedSearch] = workSpaceModel.IsContainerSavedSearch;

        return workSpaceApiModel;
    }

    var returnWorkSpaceUIModel = function (workSpaceApiModel) {
        return getWorkSpaceUIModel(workSpaceApiModel);
    };

    var returnWorkSpaceApiPostModel = function (workSpaceModel, dbName) {
        return getWorkSpacePostModel(workSpaceModel, dbName);
    };

    var returnWorkSpaceApiPutModel = function (workSpaceModel, dbName) {
        return getWorkSpacePutModel(workSpaceModel, dbName);
    };

    var returnAPIUrl = function (APIFOR, requestModel) {
        var ApiUrl = baseUrl + WRSU_WORKSPACE[APIFOR];

        if (APIFOR == 'CHECKUSERACCESS') {
            ApiUrl = ApiUrl.replace('<workspace_id>', requestModel.WorkspaceId);
            ApiUrl = ApiUrl.replace('<user_id>', requestModel.UserId);
        }
        else if (APIFOR === 'SEARCHWORKSPACE' && requestModel !== null) {
            ApiUrl = prepareGetUrl(ApiUrl, requestModel);
        }
        return ApiUrl;
    };

    function prepareGetUrl(URL, requestModel) {
        var apiGetUrl = URL + '?offset=' + ((requestModel.pagenumber - 1) * requestModel.pageLength).toString();
        apiGetUrl += '&limit=' + requestModel.pageLength.toString() + '&total=' + requestModel.isTotal;

        if (requestModel.Custom1SearchText.length > 0) {
            apiGetUrl += '&custom1=*' + requestModel.Custom1SearchText + '*';
        }
        if (requestModel.Custom2SearchText.length > 0) {
            apiGetUrl += '&custom2=*' + requestModel.Custom2SearchText + '*';
        }
        if (requestModel.DescriptionSearchText.length > 0) {
            apiGetUrl += '&name=*' + requestModel.DescriptionSearchText + '*';
        }



        //requestModel.searchText = requestModel.searchText.trim();
        //if (requestModel.searchText.length > 0) {
        //    //apiGetUrl += '&anywhere=*' + requestModel.searchText + '*';

        //    apiGetUrl += '&name=*' + requestModel.searchText + '*';
        //    //apiGetUrl += '&database=*' + requestModel.searchText + '*';
        //    //apiGetUrl += '&custom1=*' + requestModel.searchText + '*';
        //    //apiGetUrl += '&custom2=*' + requestModel.searchText + '*';
        //}
        return apiGetUrl;
    }


    return {
        workSpaceInitailValues: returnWorkSpaceInitialValueSettings,
        getWorkSpacePostModel: returnWorkSpaceApiPostModel,
        getWorkSpacePutModel: returnWorkSpaceApiPutModel,
        getworkSpaceUI: returnWorkSpaceUIModel,
        getAPIUrl: returnAPIUrl,
        getWorkspaceSecurityUIModel: returnWorkSpaceSecurityUIModel,
        workSpaceSecurityInitailValues: returnWorkspaceSecurityUIModelSettings,
    }
}