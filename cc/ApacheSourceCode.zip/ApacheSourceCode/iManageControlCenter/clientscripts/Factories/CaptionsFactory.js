app.factory('captionsFactory', captionsFactory);
captionsFactory.$inject = ['$q','WRSU_CAPTIONS','CONST_CAPTIONS'];
function captionsFactory($q,WRSU_CAPTIONS,CONST_CAPTIONS) {

	var captionUIModel = {
		DisplayText : '',
		MetaDataItem : '',
		isMetaItem : true,
		isallowedCreateProfile : true,
		isallowedSearchProfile : true,
		ParentMetaItem : '',
		MetaType : '',
		TagValue : 0
	};
	var captionApiModel = {
			id : '',
			label : '',
			type : ''	
		}

	 
	var returnCaptionInitialValueSettings = function() {
		return angular.copy(captionUIModel);
	}
	 function prepareUrl(URL,requestModel)
	    {   
	    	 var ApiUrl=URL+"?database="+requestModel.libraryName+'&offset='+((requestModel.pagenumber-1)*requestModel.pageLength)+'&limit='+requestModel.pageLength+'&total='+requestModel.isTotal+'&locale=' + requestModel[CONST_CAPTIONS.Locale];
	        if(requestModel.searchText!=null && requestModel.searchText!='')
	         ApiUrl+='&query=*'+requestModel.searchText+'*'         
	         if (requestModel.filters.length > 0) {
	      	   angular.forEach(requestModel.filters, function (filterItem) {
	  				if(filterItem.FilterValues[0]!=null && filterItem.FilterValues[0]!=''){

	  						ApiUrl+='&'+CONST_CAPTIONS[filterItem.FilterKey+'Filter']+'=*'+filterItem.FilterValues[0]+'*'
	  		  						
	  				
	  				}
	  	          });			 
	         }	         
	       
	         return ApiUrl;
	    }
	 var returnAPIUrl=function(APIFOR,requestModel,userId,dbName,action)
	    {
	     var ApiUrl = baseUrl + WRSU_CAPTIONS[APIFOR];
	    	if( APIFOR=='POSTCAPTIONS')
	    		{
	    		ApiUrl+=   requestModel.MetaDataItem;
	    		}
	    	else if(requestModel!=null)
	    	{
	    		ApiUrl=prepareUrl(ApiUrl,requestModel);
	    		
	    	}
	    	return ApiUrl;
	    }	
	function getCaptionUIModel(captionApiModel) {
		var captionModel = angular.copy(captionUIModel)
		captionModel.DisplayText = captionApiModel[CONST_CAPTIONS.DisplayText];
		captionModel.MetaDataItem = captionApiModel[CONST_CAPTIONS.MetaDataItem].toUpperCase();
		captionModel.isMetaItem = IsMetaItem(captionApiModel.id.toUpperCase());		
		captionModel.ParentMetaItem = GetParentItem(captionApiModel.id.toUpperCase());		
		captionModel.Locale = (!captionApiModel[CONST_CAPTIONS.Locale])?1033:captionApiModel[CONST_CAPTIONS.Locale];
		captionModel.CaptionNum=captionApiModel[CONST_CAPTIONS.CaptionNum];	 
		captionModel.CaptionSS_Num=captionApiModel[CONST_CAPTIONS.CaptionSS_Num]; 
		 
		return captionModel;// angular.copy(captionModel);
	}
	var returnCaptionUIModel = function(captionApiModel) {
		return getCaptionUIModel(captionApiModel);

	}
	var returnCaptionApiPostModel = function(group, dbName) {
		return getCaptionApiPostModel(group, dbName);

	}
	function getCaptionApiPostModel(captionUIModel,dbName) {
		var captionModelApi={};
		captionModelApi[CONST_CAPTIONS.DataBase]=dbName;
		captionModelApi[CONST_CAPTIONS.DisplayText] = captionUIModel.DisplayText;
		captionModelApi[CONST_CAPTIONS.MetaDataItem]= captionUIModel.MetaDataItem.toUpperCase();
		captionModelApi[CONST_CAPTIONS.Locale]= captionUIModel.Locale;
		captionModelApi[CONST_CAPTIONS.CaptionNum]= captionUIModel.CaptionNum;
		captionModelApi[CONST_CAPTIONS.CaptionSS_Num]= captionUIModel.CaptionSS_Num;
		//captionModelApi.num = 1;
		//captionModelApi.ss_num= 1;
		 


		return  captionModelApi;
	}

	/*
	 * function setSubItem(item) { switch (item) { case "CUSTOM2": case
	 * "CUSTOM30": case "SUBCLASS": return true; default: return false; } }
	 */

	function IsMetaItem(item) {
		switch (item) {
		case "CUSTOM1":
		case "CUSTOM2":
		case "CUSTOM3":
		case "CUSTOM4":
		case "CUSTOM5":
		case "CUSTOM6":
		case "CUSTOM7":
		case "CUSTOM8":
		case "CUSTOM9":
		case "CUSTOM10":
		case "CUSTOM11":
		case "CUSTOM12":
		case "CUSTOM29":
		case "CUSTOM30":
		case "CLASS":
		case "SUBCLASS":

			return true;
		default:
			return false;
		}

	}

	function GetParentItem(item) {
		switch (item) {
		case "CUSTOM2":
			return "CUSTOM1";
		case "CUSTOM30":
			return "CUSTOM29";
		case "SUBCLASS":
			return "CLASS";
		default:
			return "";
		}

	}

	return {
		captionInitialValues:returnCaptionInitialValueSettings,
		getCaptionUI : returnCaptionUIModel,
		getCaptionPostModel : returnCaptionApiPostModel,
		getAPIUrl:returnAPIUrl
	}

	

}