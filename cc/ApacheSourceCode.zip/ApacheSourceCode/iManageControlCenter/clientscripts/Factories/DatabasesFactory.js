﻿app.factory('databasesFactory', databasesFactory);
databasesFactory.$inject = ['WRSU_DB','CONST_DB','$q'];

function databasesFactory(WRSU_DB,CONST_DB,$q) {

    var databasesUIModel = {
        DatabaseName: '',
        Description: '',
        
    }

    function getDatabaseUIModel(dataBaseApiModel)
    {
    	var dbModel=angular.copy(databasesUIModel);   
    	dbModel.DatabaseName= dataBaseApiModel[CONST_DB.DatabaseName];//.user_id_ex;
    	dbModel.Description=dataBaseApiModel[CONST_DB.Description];
    	return dbModel;   
    	
    }
    var returnDatabaseUIModel=function(databaseApiModel)
    {
    	return getDatabaseUIModel(databaseApiModel);
    	
    }
    
    var returnDatabasesInitialValueSettings = function () {
        return angular.copy(databasesUIModel);
    }
    
    var returnAPIUrl=function(APIFOR,requestModel)
    {
    	var ApiUrl=WRSU_DB[APIFOR]
    	if(requestModel!=null)
    	{
    		ApiUrl=prepareUrl(ApiUrl,requestModel);
    		
    	}
    	return ApiUrl;
    	
    }
    
    function prepareUrl(URL,requestModel)
    {
    	 var ApiUrl=URL+"?database="+requestModel.libraryName;//+'&offset='+((requestModel.pagenumber-1)*requestModel.pageLength)+'&limit='+requestModel.pageLength+'&total='+requestModel.isTotal;
        /* if(requestModel.searchText!=null && requestModel.searchText!='')
         ApiUrl+='&query=*'+requestModel.searchText+'*'         
         if (requestModel.filters.length > 0) {
      	   angular.forEach(requestModel.filters, function (filterItem) {
  				if(filterItem.FilterValues[0]!=null && filterItem.FilterValues[0]!=''){
  					if(filterItem.FilterKey=='IsAllowLogon' || filterItem.FilterKey=='IsExternalUser'  || filterItem.FilterKey=='PasswordNeverExpires')
  					{
  						ApiUrl+='&'+CONST_USERS[filterItem.FilterKey+'Filter']+'='+(filterItem.FilterValues[0]=="Y"?'true':'false');
  	  					
  						
  					}else
  					{
  						ApiUrl+='&'+CONST_USERS[filterItem.FilterKey+'Filter']+'=*'+filterItem.FilterValues[0]+'*'
  		  						
  					} 
  				}
  	          });			 
  		}*/
         return ApiUrl;
    }

  

    return {
        databasesInitialValues: returnDatabasesInitialValueSettings,
        getDatabaseUI:returnDatabaseUIModel,
        getAPIUrl:returnAPIUrl
    }
}