﻿app.factory('classFactory', classFactory);
classFactory.$inject = ['WRSU_CLASS','CONST_CLASS'];
function classFactory(WRSU_CLASS,CONST_CLASS) {

	var classUIModel = {
		Description : '',
		Alias : '',
		RetainDays : 365,
		Security : 'PUBLIC',
		SubclassRequired : false,
		HIPAACompliant : false, 
		Echo : false,
		ParentClass : '',
		FieldRequired : 0
	}

	function getClassUIModel(ClassApiModel) {
		var classModel = angular.copy(classUIModel);
		classModel.Alias = ClassApiModel[CONST_CLASS.Alias];
		classModel.Echo = ClassApiModel[CONST_CLASS.Echo];
		classModel.Description = ClassApiModel[CONST_CLASS.Description];
		classModel.RetainDays = ClassApiModel[CONST_CLASS.RetainDays];
		classModel.Security = ClassApiModel[CONST_CLASS.Security];
		classModel.SubclassRequired = ClassApiModel[CONST_CLASS.SubclassRequired];
		classModel.HIPAACompliant = ClassApiModel[CONST_CLASS.HIPAACompliant];
		if(ClassApiModel[CONST_CLASS.ParentAlias]){
		classModel.ParentClass = ClassApiModel[CONST_CLASS.ParentAlias][CONST_CLASS.Alias];}
		classModel.FieldRequired = ClassApiModel[CONST_CLASS.FieldRequired];
		return classModel;

	}

	var returnAPIUrl = function(APIFOR, modelObject) {
	    var ApiUrl = baseUrl + WRSU_CLASS[APIFOR]
		if (modelObject != null) {
			ApiUrl = prepareUrl(ApiUrl, modelObject, APIFOR);

		}
		return ApiUrl;

	}

	function prepareUrl(URL, requestmodel, APIFOR) {
		var ApiUrl = URL;
		switch (APIFOR) {
		case 'POSTSUBCLASS':
			ApiUrl = ApiUrl.replace("{CLASSALIAS}", requestmodel.ParentClass
					.toLowerCase());
			break;
		case 'PUTSUBCLASS':
			ApiUrl = ApiUrl.replace("{CLASSALIAS}", requestmodel.ParentClass
					.toLowerCase());
			ApiUrl = ApiUrl.replace("{SUBCLASSALIAS}", requestmodel.Alias
					.toLowerCase());
			break;	
		case 'PUTCLASS':
			ApiUrl = ApiUrl.replace("{CLASSALIAS}", requestmodel.Alias
					.toLowerCase());
			break;
		/*
		 * case 'PUTClass': ApiUrl= ApiUrl.replace("{CUSTOMTYPE}",
		 * requestmodel.ClassType.toLowerCase()); break;
		 */
		case 'SEARCHCLASS':

			ApiUrl += "?" + CONST_CLASS.DataBase + "="
					+ requestmodel.libraryName + '&offset='
					+ ((requestmodel.pagenumber - 1) * requestmodel.pageLength)
					+ '&limit=' + requestmodel.pageLength + '&total='
					+ requestmodel.isTotal;
			if (requestmodel.searchText != null
					&& requestmodel.searchText != '')
				ApiUrl += '&query=*' + requestmodel.searchText + '*'
			if (requestmodel.filters.length > 0) {
				angular
						.forEach(
								requestmodel.filters,
								function(filterItem) {
									if (filterItem.FilterValues[0] != null
											&& filterItem.FilterValues[0] != '') {
										if (filterItem.FilterKey == 'HIPAACompliant'
												|| filterItem.FilterKey == 'SubclassRequired' ||filterItem.FilterKey == 'Echo') {
											ApiUrl += '&'
													+ CONST_CLASS[filterItem.FilterKey
															+ 'Filter']
													+ '='
													+ (filterItem.FilterValues[0] == "Y" ? 'true'
															: 'false');

										} else {
											ApiUrl += '&'
													+ CONST_CLASS[filterItem.FilterKey
															+ 'Filter']
													+ '=*'
													+ filterItem.FilterValues[0]
													+ '*'
										}
									}
								});
			}
			break;
		case 'SEARCHSUBCLASS':
			ApiUrl = ApiUrl.replace("{CLASSALIAS}", requestmodel.Alias
					.toLowerCase());
			ApiUrl += "?" + CONST_CLASS.DataBase + "="
					+ requestmodel.libraryName + '&offset='
					+ ((requestmodel.pagenumber - 1) * requestmodel.pageLength)
					+ '&limit=' + requestmodel.pageLength + '&total='
					+ requestmodel.isTotal;
			if (requestmodel.searchText != null
					&& requestmodel.searchText != '')
				ApiUrl += '&query=*' + requestmodel.searchText + '*'
			if (requestmodel.filters.length > 0) {
				angular
						.forEach(
								requestmodel.filters,
								function(filterItem) {
									if (filterItem.FilterValues[0] != null
											&& filterItem.FilterValues[0] != '') {
										if (filterItem.FilterKey == 'Echo'
												|| filterItem.FilterKey == 'HIPAACompliant' || filterItem.FilterKey == 'IsHipaa') {
											ApiUrl += '&'
													+ CONST_CLASS[filterItem.FilterKey
															+ 'Filter']
													+ '='
													+ (filterItem.FilterValues[0] == "Y" ? 'true'
															: 'false');

										} else {
											ApiUrl += '&'
													+ CONST_CLASS[filterItem.FilterKey
															+ 'Filter']
													+ '=*'
													+ filterItem.FilterValues[0]
													+ '*'
										}
									}
								});
			}
			break;
		    case 'GETCLASSEXIST':
		        ApiUrl += "?" + CONST_CLASS.DataBase + "="
					+ requestmodel.libraryName + '&alias' + '=' + requestmodel.Alias

		}

		return ApiUrl;
	}

	var returnClassUIModel = function(classApiModel) {
		return getClassUIModel(classApiModel);

	}

	var returnClassAPIPOSTModel = function(classUIModel, dbName) {
		return getClassAPIPOSTModel(classUIModel, dbName);

	}

	var returnClassAPIPUTModel = function(classUIModel, dbName) {
		return getClassAPIPUTModel(classUIModel, dbName);

	}

	function getClassAPIPOSTModel(ClassUIModel, dbName) {
		var ClassApiModel = {};
		ClassApiModel[CONST_CLASS.Alias] = ClassUIModel.Alias;
		ClassApiModel[CONST_CLASS.FieldRequired] = ClassUIModel.FieldRequired;
		ClassApiModel[CONST_CLASS.HIPAACompliant] = ClassUIModel.HIPAACompliant; 
		ClassApiModel[CONST_CLASS.Description] = ClassUIModel.Description;
		ClassApiModel[CONST_CLASS.RetainDays] = ClassUIModel.RetainDays;
		ClassApiModel[CONST_CLASS.Echo] = ClassUIModel.Echo;
		ClassApiModel[CONST_CLASS.Security] = ClassUIModel.Security;
		ClassApiModel[CONST_CLASS.SubclassRequired] = ClassUIModel.SubclassRequired;

		// ClassApiModel[CONST_CLASS.ParentClass] = classModel.ParentClass;
		ClassApiModel[CONST_CLASS.DataBase] = dbName;
		if (ClassUIModel.ParentClass) {
			if (ClassUIModel.ParentClass != '') {
				ClassApiModel[CONST_CLASS.ParentAlias] = {};
				ClassApiModel[CONST_CLASS.ParentAlias][CONST_CLASS.Alias] = ClassUIModel.ParentClass;
			}
		}
		return ClassApiModel;

	}

	function getClassAPIPUTModel(ClassUIModel, dbName) {
		var ClassApiModel = {};
		ClassApiModel[CONST_CLASS.Alias] = ClassUIModel.Alias;
		ClassApiModel[CONST_CLASS.FieldRequired] = ClassUIModel.FieldRequired;
		ClassApiModel[CONST_CLASS.HIPAAComplaint] = ClassUIModel.HIPAAComplaint;
		ClassApiModel[CONST_CLASS.Description] = ClassUIModel.Description;
		ClassApiModel[CONST_CLASS.RetainDays] = ClassUIModel.RetainDays;
		ClassApiModel[CONST_CLASS.Echo] = ClassUIModel.Echo;
		ClassApiModel[CONST_CLASS.Security] = ClassUIModel.Security;
		ClassApiModel[CONST_CLASS.SubclassRequired] = ClassUIModel.SubclassRequired;

		// ClassApiModel[CONST_CLASS.ParentClass] = classModel.ParentClass;
		ClassApiModel[CONST_CLASS.DataBase] = dbName;
		if (ClassUIModel.ParentClass) {
			if (ClassUIModel.ParentClass != '') {
				ClassApiModel[CONST_CLASS.ParentAlias] = {};
				ClassApiModel[CONST_CLASS.ParentAlias][CONST_CLASS.Alias] = ClassUIModel.ParentClass;
			}
		}
		return ClassApiModel;
			

	}
	
	var classGeneralValuesSettings = {
		PopupTitle : ''
	}

	var validationSettings = {
		showMessage : false,
		showInformationMessage : false,
		serverResponse : false
	}

	var returnClassInitialValueSettings = function() {
		return angular.copy(classUIModel);
	}

	var returnUserValidationSettings = function() {
		return angular.copy(validationSettings);
	}

	var returnBindClassValues = function(classValues) {
		return angular.copy({
			Description : classValues.Description,
			Alias : classValues.Alias,
			RetainDays : classValues.RetainDays,
			Security : classValues.Security,
			SubclassRequired : classValues.SubclassRequired,
			HIPAACompliant : classValues.HIPAACompliant,
			Echo : classValues.Echo,
			FieldRequired : classValues.FieldRequired
		})
	}

	var initializeModelTabFun = function() {
		$("#addClassModelBody>.nav-tabs>li").removeClass("active in");
		$("#addClassModelBody>.tab-content>.tab-pane").removeClass("active in");
		$("#addClassModelBody>.nav-tabs>li:first").addClass("active in");
		$('#defaults_tab').addClass("active in");
		$('#cboSecurity').selectpicker('val', 'Public');
	}

	return {
		classInitailValues : returnClassInitialValueSettings,
		validations : returnUserValidationSettings,
		generalSettings : classGeneralValuesSettings,
		bindClassValues : returnBindClassValues,
		getAPIUrl : returnAPIUrl,
		getClassUI : returnClassUIModel,
		getClassAPIPostModel : returnClassAPIPOSTModel,
		getClassAPIPUTModel : returnClassAPIPUTModel,
		initializeModelTab : initializeModelTabFun
	}
}