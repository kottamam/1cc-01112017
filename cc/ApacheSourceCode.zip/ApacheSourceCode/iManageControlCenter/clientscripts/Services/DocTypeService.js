﻿app.service("DocTypeService", DocTypeService);
DocTypeService.$inject = ['$http'];
function DocTypeService($http) {

    this.getDocTypes = function (apiUrl, authKey) {
        var response = $http({
            url: apiUrl,
            method: "GET",
            headers: {
                'cookie': 'X-Auth-Token=' + authKey
            }
        });
        return response;
    };

    this.addDocType = function (apiUrl, docTypeModel, authKey) {
       
        
        var response = $http({
            url: apiUrl,
            method: "POST",
            data: JSON.stringify(docTypeModel),
            headers: {
                'cookie': 'X-Auth-Token=' + authKey
            }
        });
        return response;
    };

    this.DeleteDocType = function (DocTypeName) {
        var response = $http({
            url: apiUrl,
            method: "POST",
            headers: {
                'cookie': 'X-Auth-Token=' + authKey
            }
        });
        return response;
    };

    this.UpdateDocType = function (apiUrl, docTypeModel, authKey) {
        var response = $http({
            url: apiUrl,
            method: "PUT",
            headers: {
                'cookie': 'X-Auth-Token=' + authKey
            },
            data: JSON.stringify(docTypeModel) 
        });
        return response;
    };
}