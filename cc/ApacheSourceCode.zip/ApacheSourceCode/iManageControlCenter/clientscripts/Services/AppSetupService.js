﻿app.service("AppSetupService", AppSetupService);
AppSetupService.$inject = ['$http'];

function AppSetupService($http) {
    this.getAppSetupList = function (URL, key) {
        var promise = $http({
            url: URL,
            method: "GET",
            headers: {
            	 'X-Auth-Token': key,
              	 'X-Auth-Type': 'unified'
            }
        });
        return promise;
    }


    this.addAppSetup = function (apiUrl, authKey, apiModel) {
        var promise = $http({
            url: apiUrl,
            method: "POST",
            headers: {
            	 'X-Auth-Token': authKey,
              	 'X-Auth-Type': 'unified'
            },
            data: JSON.stringify(apiModel)
        });
        return promise;
    };
    this.EditAppSetup = function (apiUrl, authKey, apiModel) {
        var promise = $http({
        	url: apiUrl,
            method: "PUT",
            headers: {
            	 'X-Auth-Token': authKey,
              	 'X-Auth-Type': 'unified'
            },
            data: JSON.stringify(apiModel)
        });
        return promise;

    }

}