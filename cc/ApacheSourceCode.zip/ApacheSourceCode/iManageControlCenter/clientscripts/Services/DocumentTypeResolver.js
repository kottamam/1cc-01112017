﻿app.service("DocumentTypeResolver", DocumentTypeResolver);
DocumentTypeResolver.$inject = ['$http'];

function DocumentTypeResolver($http) {
    var documentTypeMap, documentExtensionMap;

    this.getDocType = function getDocType(identifier, type) {
        var docType;
        if (identifier) {
            switch (type) {
                case "extension":
                    docType = documentExtensionMap[identifier.toLowerCase()];
                    break;
                case "type":
                    docType = documentTypeMap[identifier];
                    break;
                default:
                    break;
            }
        }
        return docType;
    };

    documentTypeMap = {
        "WORD": "doc",
        "WORDX": "doc",
        "WORDXT": "doc",
        "DOCX": "doc",
        "EXCEL": "spreadsheet",
        "EXCELX": "spreadsheet",
        "EXCELXT": "spreadsheet",
        "PPT": "presentation",
        "PPTX": "presentation",
        "PPTXT": "presentation",
        "ACROBAT": "pdf",
        "MIME": "email",
        "FOLDER": "folder",
        "ALL": "all"
    };

    documentExtensionMap = {
        "3g2": "video",
        "3pg": "video",
        "7z": "compressed",
        "aiff": "audio",
        "asf": "video",
        "au": "audio",
        "avi": "video",
        "bmp": "image",
        "doc": "doc",
        "docb": "doc",
        "docm": "doc",
        "docx": "doc",
        "dot": "doc",
        "dotx": "doc",
        "dxl": "email",
        "eml": "email",
        "flac": "audio",
        "flv": "video",
        "gif": "image",
        "gz": "compressed",
        "jpeg": "image",
        "jpg": "image",
        "ldoc": "latest-doc",
        "leml": "latest-email",
        "lwsp": "latest-workspace",
        "m2v": "video",
        "m4a": "audio",
        "mkv": "video",
        "mov": "video",
        "mp2": "video",
        "mp3": "audio",
        "m4p": "video",
        "m4v": "video",
        "mp4": "video",
        "mpeg": "video",
        "mpg": "video",
        "msg": "email",
        "oga": "audio",
        "ogv": "video",
        "one": "onenote",
        "pdf": "pdf",
        "png": "image",
        "pot": "presentation",
        "potm": "presentation",
        "potx": "presentation",
        "ppam": "presentation",
        "pps": "presentation",
        "ppsm": "presentation",
        "ppsx": "presentation",
        "ppt": "presentation",
        "pptm": "presentation",
        "pptx": "presentation",
        "qt": "video",
        "rar": "compressed",
        "rm": "video",
        "sldm": "text",
        "sldx": "text",
        "tar": "compressed",
        "tar.gz": "compressed",
        "txt": "text",
        "tif": "image",
        "tiff": "image",
        "vdx": "visio",
        "vsd": "visio",
        "vsdm": "visio",
        "vsdx": "visio",
        "vss": "visio",
        "vssm": "visio",
        "vssx": "visio",
        "vst": "visio",
        "vstm": "visio",
        "vstx": "visio",
        "vsw": "visio",
        "vtx": "visio",
        "wav": "audio",
        "webm": "video",
        "wma": "audio",
        "wmv": "video",
        "xlm": "spreadsheet",
        "xls": "spreadsheet",
        "xlsm": "spreadsheet",
        "xlsx": "spreadsheet",
        "xlt": "spreadsheet",
        "xltm": "spreadsheet",
        "xltx": "spreadsheet",
        "zip": "compressed"
        //TODO: add the icon for the GroupWise Email, probably need to depend on the Document Class and subClass types.
    };



}