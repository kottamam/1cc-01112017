﻿app.service("TemplateService", TemplateService);
TemplateService.$inject = ['$http'];

function TemplateService($http) {

    this.getWorkSpaces = function (URL, key) {
        var promise = $http({
            url: URL,
            method: "GET",
            headers: {
                'X-Auth-Token': key,
                'X-Auth-Type': 'unified'
            }
        });
        return promise;
    };

    this.getFoldersFromWorkspace = function (URL, key) {
        var promise = $http({
            url: URL,
            method: "GET",
            headers: {
                'X-Auth-Token': key,
                'X-Auth-Type': 'unified'
            }
        });
        return promise;
    };

}