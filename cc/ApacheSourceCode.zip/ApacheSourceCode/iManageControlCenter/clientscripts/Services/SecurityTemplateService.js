﻿app.service("SecurityTemplateService", SecurityTemplateService);
SecurityTemplateService.$inject = ['$http'];

function SecurityTemplateService($http) {

	  this.getUserTemplate = function (URL,key) {//libName, userId
	        var response = $http({
	            url: URL,
	            method: "GET",
	            headers: {
	            	  'cookie': 'X-Auth-Token='+key  	         
	            }
	        });
	        return response;
	    }
	  
	   this.getTemplateList = function (URL,key) {//requestModel
	        var response = $http({
	            url: URL,
	            method: "GET",
	            headers: {
	            	  'cookie': 'X-Auth-Token='+key  	         
	            }
	        });
	        return response;
	    }
	   
	   
	   this.SetSecurityTemplate = function (URL,key,body) {//libName, userId, oldTemplateName, newTemplateName
	        var response = $http({
	            method: "POST",
	            url: URL,
	            headers: {
	            	  'cookie': 'X-Auth-Token='+key  	         
	            },
	            data:JSON.stringify(body)
	        });
	        return response;
	    }
	   
	   
	   this.UpdateSecurityTemplate = function (URL,key,body) {
	        var response = $http({
	            method: "PUT",
	            url: URL,
	            headers: {
	            	  'cookie': 'X-Auth-Token='+key  	         
	            },
	            data:JSON.stringify(body)
	        });
	        return response;
	    }
	   
	   this.DeleteSecurityTemplate = function (URL,key,body) {
	        var response = $http({
	            method: "DELETE",
	            url: URL,
	            headers: {
	            	  'cookie': 'X-Auth-Token='+key  	         
	            },
	            data:JSON.stringify(body)
	        });
	        return response;
	    }
	
    this.getSecurityTemplateServiceList = function (libName, cursor_val, limit_val, search) {
        var response = $http({
            url: "SecurityTemplate/GetList",
            method: "GET",
            params: { libraryName: libName, cursor: cursor_val, pageLength: limit_val, searchText: search }
        });
        return response;
    }

 

    this.getByTemplateName = function (libName, templateName) {
        var response = $http({
            url: "SecurityTemplate/GetByName",
            method: "GET",
            params: { libraryName: libName, templateName: templateName }
        });
        return response;
    }

    this.save = function (libName, securityTemplateModel, isEditMode) {
        var response = $http({
            url: "SecurityTemplate/Save",
            method: "POST",
            data: { 'libraryName': libName, 'templateModel': securityTemplateModel, 'isEditMode': isEditMode }
        });
        return response;
    }

  
}