﻿app.service("ClassService", ClassService);
ClassService.$inject = ['$http'];
function ClassService($http) {

    this.getClasses = function (URL, key) {//requestModel, MetaType
        var response = $http({
            url: URL,
            method: "GET",
            headers: {
                'X-Auth-Token': key,
                'X-Auth-Type': 'unified'
            }
        });
        return response;
    }

    this.addClass = function (Url, key, classModel) {
        var response = $http({
            url: Url,
           method: "POST",
           headers: {
               'X-Auth-Token': key,
               'X-Auth-Type': 'unified'
           },
           data:JSON.stringify(classModel)
        });
        return response;
    }

    this.addSubClass = function (Url, key, classModel) {
        var response = $http({
            url: Url,
            method: "POST",
            headers: {
                'X-Auth-Token': key,
                'X-Auth-Type': 'unified'
             },
             data:JSON.stringify(classModel)
        });
        return response;
    }

    this.editClass = function (Url, key, classModel) {
    	 var response = $http({
             url: Url,
             method: "PUT",
             headers: {
                 'X-Auth-Token': key,
                 'X-Auth-Type': 'unified'
              },
              data:JSON.stringify(classModel)
         });
         return response;
    }

    this.editSubClass = function (Url, key, classModel) {
    	 var response = $http({
             url: Url,
             method: "PUT",
             headers: {
                 'X-Auth-Token': key,
                 'X-Auth-Type': 'unified'
              },
              data:JSON.stringify(classModel)
         });
         return response;
    }

    this.getSubClasses = function (requestModel, classAlias) {
        var promise = $http({
            url: "Class/SubClassList",
            method: "POST",
            dataType: "json",
            params: { searchModelJSONString: JSON.stringify(requestModel), classAlias: classAlias }
        });
        return promise;
    }

    this.deleteClass = function (libName, classModel) {
        var promise = $http({
            url: "Class/Delete",
            method: "POST",
            data: { 'libraryName': libName, 'classModel': classModel }
        });
        return promise;
    }

    this.deleteSubClass = function (libName, classModel,ParentClass) {
        var promise = $http({
            url: "Class/SubClassDelete",
            method: "POST",
            data: { 'libraryName': libName, 'classModel': classModel, 'ParentClass': ParentClass }
        });
        return promise;
    }

}