app.constant('WRSU_DB',{
						GETDATABASE:	'../admin-api/v1/databases'					 
						  }
			);

app.constant('CONST_DB',{	
    DatabaseName: 'database',
	Description:'description'
  }
);