app.constant('WRSU_GROUPS', {
	SEARCHGROUPS: 'api/v1/groups/search',
	POSTGROUPS: 'api/v1/groups',
	PUTGROUPS: 'api/v1/groups/',
	GETGROUPSOFUSERFROMGROUPS: 'admin-api/v1/users/<userId>/groups?dbName=<dbName>&total=true&alias=<alias>',
	ADDUSERINGROUP: 'api/v1/groups/<group_alias>/members',
	REMOVEUSERFROMGROUP: 'api/v1/groups/<group_alias>/members',
	ENABLEDISABLEGROUP: 'api/v1/groups/',
	VIEWGROUPDETAILS: 'api/v1/groups/',
	COPYGROUPS: 'api/v1/groups/',	 	 
	GETGROUPUSERS: 'api/v1/groups/<group_alias>/members',
	GETNONGROUPMEMBERS: 'api/v1/groups/<group_alias>/non-members',
});

app.constant('CONST_GROUPS', {
	GroupName: 'group_id',
	GroupNameFilter: 'alias',
	GroupFullName: 'full_name',
	GroupFullNameFilter: 'full_name',
	GroupEnabled: 'enabled',
	GroupEnabledFilter: 'enabled',
	GroupIsExternal: 'is_external',
	GroupIsExternalFilter: 'external',
	GroupNOS: 'group_nos',
	GroupNumResponse: 'group_number',
	GroupNum: 'group_number',
	DataBase: 'database',
	Domain: 'group_domain',
	SyncId: "sync_id",
	DistinguishedName: "distinguished_name"
});

app.constant('CONST_GROUPS_VIEW_DETAILS', {
    GroupName: 'group_id',
    GroupFullName: 'full_name',
    GroupEnabled: 'enabled',
    GroupIsExternal: 'is_external',
    GroupNOS: 'group_nos',
    GroupNum: 'group_number',
    DataBase: 'database',
	Domain: 'group_domain'
});
