app.constant('WRSU_ST',{
						GETSECURITYTEMPLATES:	'admin-api/v1/security-templates',
						GETSECURITYTEMPLATEOFUSER:	'admin-api/v1/users/{USERID}/security-template',
						SETSECURITYTEMPLATEOFUSER:	'admin-api/v1/users/{USERID}/security-template/{STNEWNAME}',
						UPDATESECURITYTEMPLATEOFUSER:	'admin-api/v1/users/{USERID}/security-template/{STOLDNAME}',
						DELETESECURITYTEMPLATEOFUSER:	'admin-api/v1/users/{USERID}/security-template/{STOLDNAME}'
												
						}
			);

app.constant('CONST_ST', {
    TemplateName: 'name',
    Description: 'description',
    DefaultSecurity: 'default_security',
    TotalCount: 'total_count',
    TemplateList: 'data',
    Database: 'database'
});