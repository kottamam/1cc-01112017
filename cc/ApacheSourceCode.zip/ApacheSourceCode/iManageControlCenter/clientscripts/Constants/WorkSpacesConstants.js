app.constant('WRSU_WORKSPACE', {
    SEARCHWORKSPACE: 'api/v1/workspaces/search',
    CHECKUSERACCESS: 'api/v1/workspaces/<workspace_id>/users/<user_id>/security'
});

app.constant('CONST_WORKSPACE', {
    Author: "author",
    Class: "class",
    CreateDate: 'create_date',
    Custom1: "custom1",
    Custom2: "custom2",
    Custom3: "custom3",
    Database: "database",
    DefaultSecurity: "default_security",
    DocumentNumber: 'document_number',
    EditDate: 'edit_date',
    EditProfileDate: 'edit_profile_date',
    FileCreateDate: 'file_create_date',
    FileEditDate: 'file_edit_date',
    HasAttachment: 'has_attachment',
    HasSubfolders: 'has_subfolders',
    Id: "id",
    InUse: 'in_use',
    Indexable: 'indexable',
    IsCheckedOut: 'is_checked_out',
    IsContainerSavedSearch: 'is_container_saved_search',
    IsContentSavedSearch: 'is_content_saved_search',
    IsExternal: 'is_external',
    IsExternalAsNormal: 'is_external_as_normal',
    IsHidden: 'is_hidden',
    IsHipaa: 'is_hipaa',
    Iwl: 'iwl',
    LastUser: 'last_user',
    Location: 'location',
    Name: 'name',
    Operator: 'operator',
    Owner: 'owner',
    RetainDays: 'retain_days',
    Size: 'size',
    Subtype: 'subtype',
    Type: 'type',
    Version: 'version',
    Wstype: 'wstype'
});

app.constant('CONST_WORKSPACE_SECURITY', {
    Id: 'id',
    Access: 'access_level',
    Type: 'type'
});
