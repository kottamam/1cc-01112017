﻿app.constant('WRSU_MASTER', {
    SAVELOG: 'imcc-api/v1/log',
    SECURITYLOG: 'imcc-api/v1/securelog',
    GET_USER_PHOTO: 'api/v1/users/<userid>/photo',
    GETGROUPSOFUSERFROMGROUPS: 'admin-api/v1/users/<userId>/groups?dbName=<dbName>&total=true&alias=<alias>'

});