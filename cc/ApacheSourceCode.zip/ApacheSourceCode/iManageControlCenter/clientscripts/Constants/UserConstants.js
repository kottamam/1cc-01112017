app.constant('WRSU_USERS',{
							SEARCHUSERS		:'admin-api/v1/users/search',
							POSTUSER		:'admin-api/v1/users',
							PUTUSER			:'admin-api/v1/users/{ALIAS}',
							GETUSER			:'admin-api/v1/users/search',
							GETUSERSOFGROUPFROMUSER: 'api/v1/groups/<groupId>/members?dbName=<dbName>&total=true&alias=<alias>',
							GETROLELESSUSERS: 'admin-api/v1/users/roleless/search',
							GETUSERGROUPS: 'admin-api/v1/users',
							GET_OUT_OF_GROUPS: 'api/v1/users/<userid>/groups/out-of'
						  }
			);

app.constant('CONST_USERS',{	
    							UserId: 'user_id',
    							UserIdPut:'alias',
    							Alias: 'alias',//GetSingleUser for UserId
    							FullName: 'full_name',
    							Location: 'location',
    							LocationFilter: 'location',
							    Phone: 'phone',
							    Ext: 'extension',
							    Fax: 'fax',
							    Email: 'email',
							    IsExternalUser: 'is_external',
							    IsExternalUserPut: 'external',
							    IsExternalUserFilter: 'external',
							    Password: 'user_password',
							    UserMustChangePassword: 'force_password_change',
							    PasswordNeverExpires: 'pwd_never_expire',
							    PasswordNeverExpiresFilter: 'password_never_expire',
							    IsAllowLogon:'login',
							    IsAllowLogonFilter:'allow_logon',
							    PreferredDatabase:'preferred_database',
							    PreferredDatabaseFilter:'preferred_database',
							    FileServer:'doc_server',
							    SecuredDocServer:'secure_docserver',
							    UserNos:'user_nos',
							    UserNosPut:'nos',
							    UserNum:'user_num',//Success value checking after postUser,PUTUSER
							    UserIdEx: 'user_id_ex',
							    AddFormUserId:'useridex',    
							    FailedLogin: 'failed_logins',
							    DistName: 'dist_name',
							    UserDomain: 'user_domain',
							    ExchAutoDiscover: 'exch_autodiscover',
							    LastEdited: 'edit_date',
							    UserDomain:'user_domain',
							    PasswordChangeDate: 'pwd_changed_ts',
							    LastSyncDate: 'last_sync_ts',
							    DateAccountLocked: 'lockout_ts',							    
							    DataBase: 'database', //GetSingleUser for UserId
                                UserIDForUserInGroup: 'UserID'
  						}
			);