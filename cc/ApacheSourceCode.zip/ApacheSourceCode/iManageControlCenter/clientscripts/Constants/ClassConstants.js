app.constant('WRSU_CLASS',{
							SEARCHCLASS			:'admin-api/v1/classes/search',
							SEARCHSUBCLASS		:'admin-api/v1/classes/{CLASSALIAS}/subclasses/search',
							POSTCLASS			:'admin-api/v1/classes',
							POSTSUBCLASS			:'admin-api/v1/classes/{CLASSALIAS}/subclasses',
							PUTCLASS			:'admin-api/v1/classes/{CLASSALIAS}',
							PUTSUBCLASS			:'admin-api/v1/classes/{CLASSALIAS}/subclasses/{SUBCLASSALIAS}',							
							GETCLASS			:'admin-api/v1/users',
							GETCLASSEXIST: 'admin-api/v1/classes/search',
						  }
			);

app.constant('CONST_CLASS',{
     //  public int[] RequiredFields { get; set; }
      
       Alias: 'id', //add ,edit,list 
       AliasFilter: 'alias',
     
     Description:'description', //add ,edit,list
     DescriptionFilter:'description',
     
     RetainDays: 'retain', //add ,edit,list
     RetainDaysFilter: 'retain',
     
     Security: 'secname', //add ,edit,list
     SecurityFilter: 'secname',  
     
     SubclassRequired: 'subclass_required',  //add ,edit as object
     SubclassRequiredFilter: 'subclass_required',  
     
     HIPAACompliant: 'hipaa',
     HIPAACompliantFilter: 'hipaa',
     
     FieldRequired:'field_required', // //add ,edit
     
     Echo:'shadow',
     EchoFilter:'echo',
     
     
     ParentAlias:'parent',
     DataBase: 'database',
     ClassList: 'data',					    
     TotalCount: 'total_count'
  						}
			);