app.constant('WRSU_CAPTIONS', {
	SEARCHCAPTIONS : 'api/v1/captions/search',	
	POSTCAPTIONS : 'api/v1/captions/',
	
});

app.constant('CONST_CAPTIONS', {
	// public int[] RequiredFields { get; set; }

	MetaDataItem: 'id', // add ,edit,list
	MetaDataItemFilter : 'alias',
	Locale:'locale',

	CaptionType : 'type', // add ,edit,list
	CaptionTypeFilter : 'type',

	DisplayText : 'label',
	DisplayTextFilter : 'label',
	
	DataBase : 'database',
		
	CaptionNum:'num',	 
	CaptionSS_Num:'ss_num'  
	 
	      
		

});