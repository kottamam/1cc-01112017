app.constant('WRSU_METADATA', {
    SEARCHMETADATA: 'admin-api/v1/customs/{CUSTOMTYPE}/search',
    SEARCHCHILDMETADATA: 'admin-api/v1/customs/{CUSTOMTYPE}/{PALIAS}/{CHILDCUSTOM}/search',
    POSTMETADATA: 'admin-api/v1/customs/{CUSTOMTYPE}',
    PUTMETADATA: 'admin-api/v1/customs/{CUSTOMTYPE}',
    GETMETADATA: 'admin-api/v1/users',
    DELETEMETADATA: 'admin-api/v1/customs/{CUSTOMTYPE}',
    GETMETADATAEXIST: 'admin-api/v1/customs/{CUSTOMTYPE}/search'
}
			);

app.constant('CONST_METADATA', {
    Alias: 'id', //add ,edit,list 
    AliasFilter: 'alias',
    AliasQuery: 'alias',
    ParentAliasQuery: 'parentAlias',

    Description: 'description', //add ,edit,list
    DescriptionFilter: 'description',

    HIPAAComplaint: 'hipaa', //add ,edit,list
    HIPAAComplaintFilter: 'hipaa',

    EnableFlag: 'enabled', //add ,edit,list
    EnableFlagFilter: 'enabled',

    ParentAlias: 'parent',  //add ,edit as object
    GrandParentAlias: '',

    MetaType: 'wstype', // //add ,edit

    DataBase: 'database',
    MetaDataList: 'data',
    TotalCount: 'total_count'
}
			);