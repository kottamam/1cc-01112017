﻿app.filter('customLabel', customLabel);
    customLabel.$inject = ['$filter'];
 
    function customLabel($filter) {

        return function (list, alias) {
            var capList = $filter('filter')(list, { MetaDataItem: alias.toUpperCase() }, true);
            if (capList.length ==1)
                return capList[0].DisplayText;

            return alias;
        }
    }

    app.filter('nospace', nospace);
    nospace.$inject = ['$filter'];
    function nospace($filter) {
        return function (value) {
            return (!value) ? '' : value.replace(/ /g, '');
        };
    }

    app.filter('humanizeDoc', humanizeDoc);
    humanizeDoc.$inject = ['$filter'];
    function humanizeDoc($filter) {
        return function (doc) {
            if (!doc) return;
            if (doc.type === 'directive') {
                return doc.name.replace(/([A-Z])/g, function ($1) {
                    return '-' + $1.toLowerCase();
                });
            }

            return doc.label || doc.name || doc.AppsName;
        };
    }

 
 
 