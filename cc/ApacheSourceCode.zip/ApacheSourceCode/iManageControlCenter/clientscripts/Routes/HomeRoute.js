﻿(function () {   

    // Declare app level module which depends on filters, and services
     app.config(['$stateProvider', '$urlRouterProvider', '$logProvider',
        function ($stateProvider, $urlRouterProvider,$logProvider) { 
    	 //$locationProvider.html5Mode(true)
            $urlRouterProvider.otherwise("/");

            $stateProvider
            .state('login', {
                url: '/login',
                templateUrl : ((window.location.pathname).indexOf('networklogin')>0)?'Views/networklogin.html':  'Views/login.html'               
                	
            })
            .state('home', {
                url: '/',
                templateUrl :  'Views/Home.html',
                controller: 'HomeController as vm'
            }) .state('networklogin', {
                url: '/networklogin',
                templateUrl :  'Views/networklogin.html'               
                	
            })
            .state('home.management', {
                url: 'management',
                abstract: true
            })
            .state('home.privacy', {
                url: 'privacy',
                views: {
                    'content@home': {
                        templateUrl: 'Views/PrivacyStatement.html'
                    }
                }
            });
        }]);

})();
