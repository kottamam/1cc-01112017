﻿app.directive('appsIcon', function () {
    return {
        restrict: 'E',
        scope: {
            appInfo: '=info'
        },
        templateUrl: function (elem, attr) {
            return NgTemplatesUrl;
        }
    };
});

app.directive('whenScrolled', function () {
    return {
        restrict: "A",
        link: function (scope, element, attr) {
            $(element).bind('scroll', function () {
                var scrollHeight = (($(this).scrollTop() + $(this).innerHeight()) / $(this)[0].scrollHeight) * 100.0;
                if (scrollHeight >= 75) {
                    //scope.ScrollCounter = true;
                    scope.$apply(attr.whenScrolled);
                }
            })
        }
    }
});

app.directive("onDatatableScroll", function ($timeout) {
    return {
        restrict: "A",
        link: function (scope, element, attrs) {
            scope.$watch(attrs.onDatatableRenderComplete, function () {
                $timeout(function () {
                    $('.dataTables_scrollBody').on('scroll', function () {
                        if ($(this).scrollTop() > scope.tableSettings.scrollTop) {
                            scope.tableSettings.scrollTop = $(this).scrollTop();
                            scope.tableSettings.scrollBarTop = $('.dataTables_scroll div.slimScrollDiv div.slimScrollBar').position().top + 'px';
                        }
                        var scrollHeight = (($(this).scrollTop() + $(this).innerHeight()) / $(this)[0].scrollHeight) * 100.0;
                        if (scrollHeight >= 75) {
                            scope.$apply(attrs.onDatatableScroll);
                        }
                    });
                });
            });
        }
    }
});

app.directive("onSelectPickerRenderComplete", function ($timeout) {
    return {
        restrict: "A",
        require: '?ngModel',
        link: function (scope, element, attrs, ngModel) {
            scope.$watch(attrs.onSelectPickerRenderComplete, function () {
                $timeout(function () {
                    $('#cbo-db-selection').selectpicker('refresh');
                    $('[data-id="cbo-db-selection"]').siblings('div').find('ul > li:has("span.text:empty")').remove();
                });
            });
        }
    }
});

app.directive("onDatatableRenderComplete", function ($timeout) {
    return {
        restrict: "A",
        link: function (scope, element, attrs) {
            scope.$watch(attrs.onDatatableRenderComplete, function () {
                $timeout(function () {
                    var modifierTop = 0;
                    //$('#idDataTable').dataTable().resize();
                    //$('#idDataTableTypeappSetup').dataTable().resize();
                    //$('#idDataTableType').dataTable().resize();
                    //$('tbody tr').hover(function () {
                    //    scope.appsVar.selectedRecordId = $(this).find("td:nth-child(1)").text().trim();
                    //    modifierTop = $(this).find("td:nth-child(1)").position().top + 115;
                    //    var right = $(this).find("td:nth-child(2)").position().left - 25;
                    //    if (attrs.rowModifierId) {
                    //        $('#' + attrs.rowModifierId).removeClass('hide');
                    //        $('#' + attrs.rowModifierId).show();
                    //        $('#' + attrs.rowModifierId).css('position', 'absolute');
                    //        $('#' + attrs.rowModifierId).css('top', modifierTop);
                    //        $('#' + attrs.rowModifierId).css('left', right);
                    //    } else {
                    //        $('#row_modifier').show();
                    //        $('#row_modifier').css('top', modifierTop);
                    //        $('#row_modifier').css('left', right);
                    //    }
                    //}, function () {
                    //    if (attrs.rowModifierId) {
                    //        $('#' + attrs.rowModifierId).hide();
                    //        $('#' + attrs.rowModifierId).mouseenter(function () {
                    //            $('#' + attrs.rowModifierId).show();
                    //        }).mouseleave(function () {
                    //            $('#' + attrs.rowModifierId).hide();
                    //        });
                    //    } else {
                    //        $('#row_modifier').hide();
                    //        $('#row_modifier').mouseenter(function () {
                    //            $('#row_modifier').show();
                    //        }).mouseleave(function () {
                    //            $('#row_modifier').hide();
                    //        });
                    //    }
                    //});

                    //$('.dataTables_scrollBody').slimScroll({
                    //    height: '297px',
                    //    allowPageScroll: true,
                    //    wheelStep: 20,
                    //    alwaysVisible: true,
                    //    railVisible: true,
                    //    size: '8px'
                    //});
                    //$('.dataTables_scrollBody').scrollTop(scope.tableSettings.scrollTop);
                    //$('.dataTables_scroll div.slimScrollDiv div.slimScrollBar').css({ top: scope.tableSettings.scrollBarTop });
                });
            });
        }
    }
});

app.directive("onStaticTableRenderComplete", function ($timeout) {
    return {
        restrict: "A",
        link: function (scope, element, attrs) {
            scope.$watch(attrs.onStaticTableRenderComplete, function () {
                $timeout(function () {
                    var modifierTop = 0;
                    element.hover(function () {
                        scope.appsVar.selectedRecordId = $(this).find("td:nth-child(1)").text().trim();
                        modifierTop = $(this).offset().top - ($(this).height() / 2);
                        var right = $(this).find("td:nth-child(2)").position().left - 15;
                        if (attrs.rowModifierId) {
                            $('#' + attrs.rowModifierId).removeClass('hide');
                            $('#' + attrs.rowModifierId).show();
                            $('#' + attrs.rowModifierId).css('position', 'absolute');
                            $('#' + attrs.rowModifierId).css('top', modifierTop);
                            $('#' + attrs.rowModifierId).css('left', right);
                        }
                    }, function () {
                        if (attrs.rowModifierId) {
                            $('#' + attrs.rowModifierId).hide();
                            $('#' + attrs.rowModifierId).mouseenter(function () {
                                $('#' + attrs.rowModifierId).show();
                            }).mouseleave(function () {
                                $('#' + attrs.rowModifierId).hide();
                            });
                        }
                    });
                });
            });
        }
    }
});

app.directive("onDbListRenderComplete", function ($timeout) {
    return {
        restrict: "A",
        require: '?ngModel',
        link: function (scope, element, attrs, ngModel) {
            scope.$watch(attrs.onDbListRenderComplete, function () {
                $timeout(function () {
                    element.selectpicker('refresh');
                    element.click();
                    element.siblings('div').find('ul > li:has("span.text:empty")').remove();
                });
            });
        }
    }
});

app.directive('selectPickerRender', function ($timeout) {
    return {
        restrict: 'C',
        link: function ($scope, elem, attrs) {
            elem.ready(function () {
                $timeout(function () {
                    elem.selectpicker();
                    elem.selectpicker('refresh');
                    elem.siblings('div').find('ul > li:has("span.text:empty")').remove();
                    elem.remove('click');
                    elem.on('click', function () {
                        elem.selectpicker('refresh');
                        elem.siblings('div').find('ul > li:has("span.text:empty")').remove();
                    });
                });
            })
        }
    }
});

app.directive('onEditClick', function () {
    return {
        restrict: 'A',
        link: function ($scope, elem, attrs) {
            elem.ready(function () {
                elem.unbind('click');
                elem.click(function (eve, cntrl) {
                    openEditForm();
                });

            })
        }
    }
});

app.directive('toogleAddClassNavTab', function () {
    return {
        restrict: 'A',
        link: function (scope, elem, attr) {
            elem.on('click', function () {
                $("#addClassModelBody>.nav-tabs>li").removeClass("active in");
                $("#addClassModelBody>.tab-content>.tab-pane").removeClass("active in");
                elem.parent().addClass("active in");

                if (attr.rel == 'defaults_tab') {
                    $('#defaults_tab').addClass("active in");
                } else {
                    $('#req_field_tab').addClass("active in");
                }
            })
        }
    };
});

app.directive('toogleAddRoleNavTab', function () {
    return {
        restrict: 'A',
        link: function (scope, elem, attr) {
            elem.on('click', function () {
                $("#addClassModelBody>.nav-tabs>li").removeClass("active in");
                $("#addClassModelBody>.tab-content>.tab-pane").removeClass("active in");
                elem.parent().addClass("active in");

                if (attr.rel == 'defaults_tab') {
                    $('#defaults_tab').addClass("active in");
                } else {
                    $('#req_field_tab').addClass("active in");
                }
            })
        }
    };
});

app.directive('numericSpinner', function () {
    return {
        restrict: 'E',
        scope: {
            dirModel: '='
        },
        controller: function ($scope) {
            $scope.numericup = function () {
                $scope.dirModel = parseInt($scope.dirModel) + 1;
            };
            $scope.numericdown = function () {
                $scope.dirModel = parseInt($scope.dirModel) - 1;
            };
            return $scope;
        },
        templateUrl: 'Views/DirectiveTemplates/NumericSpinner.html'
    }
});

app.directive("onSecTemplatePermissionTableRender", function ($timeout) {
    return {
        restrict: "A",
        link: function (scope, element, attrs) {
            scope.$watch(attrs.onSecTemplatePermissionTableRender, function (arg) {
                $timeout(function () {
                    angular.forEach(arg, function (argItem) {
                        $('#' + argItem.PermissionDDLId).selectpicker();
                        $('#' + argItem.PermissionDDLId).selectpicker('val', argItem.AccessRight);
                    });
                });
            });
        }
    }
});

app.directive('rowModifier', function () {
    return {
        restrict: 'E',
        scope: {
            onEdit: '&onEdit',
            onDelete: '&?'
        },
        replace: true,
        templateUrl: 'Views/DirectiveTemplates/RowModifier.html',
        link: function (scope, element, attrs) {
            //if (attrs.onDelete) {
            //    $('#delete-icon').css('display', 'inline');
            //} else {
            //    $('#delete-icon').css('display', 'none');
            //}
        }
    }
});

app.directive('tablePagination', function () {
    return {
        restrict: 'E',
        scope: {
            onPrevClick: '&onPrev',
            onNextClick: '&onNext',
            isPrevDisabled: '=isPrevDisabled',
            isNextDisabled: '=isNextDisabled'
        },
        replace: true,
        templateUrl: 'Views/DirectiveTemplates/TablePagination.html'
    }
});

app.directive('toogleAddRolesNavTab', function () {
    return {
        restrict: 'A',
        link: function (scope, elem, attr) {
            elem.on('click', function () {

                $(".collapse").collapse('hide');
                $("#" + attr.rel).collapse('toggle');
                $(".panel-title i.indicator").removeClass("icon-arrow-down").addClass("icon-arrow-top");
                elem.parent().find("i.indicator").toggleClass("icon-arrow-down icon-arrow-top");

            })
        }
    };
});

app.directive('toogleAddRolesPriTab', function () {
    return {
        restrict: 'A',
        link: function (scope, elem, attr) {
            elem.on('click', function () {
                $("#collapseOne div div ul.nav-tabs li").removeClass("active");
                $("#collapseOne div div div div").removeClass("active");
                elem.parent().addClass("active");
                $('#' + attr.rel).addClass("active");

            })
        }
    };
});

app.directive('capitalize', function () {
    return {
        require: 'ngModel',
        link: function (scope, element, attrs, modelCtrl) {
            var capitalize = function (inputValue) {
                if (inputValue == undefined) inputValue = '';
                var capitalized = inputValue.toUpperCase();
                if (capitalized !== inputValue) {
                    modelCtrl.$setViewValue(capitalized);
                    modelCtrl.$render();
                }
                return capitalized;
            }
            modelCtrl.$parsers.push(capitalize);
            capitalize(scope[attrs.ngModel]);  // capitalize initial value
        }
    };
});

app.directive('sortableColumn', function ($templateRequest, $compile) {
    return {
        restrict: 'C',
        //scope: {
        //    onPrevClick: '&onPrev',
        //    onNextClick: '&onNext',
        //    isPrevDisabled: '=isPrevDisabled',
        //    isNextDisabled: '=isNextDisabled'
        //},
        scope: {
            isAssending: '=?',
            onSorting: '&?'
        },
        controller: function ($scope, $element, $rootScope) {

            $scope.sortColumn = function () {
                if ($scope.$parent.appsVar.sortField == $($element[0]).attr('sort-value')) {
                    $scope.isAssending = !$scope.isAssending;
                } else {
                    $scope.isAssending = true;
                }

                $($element[0]).siblings('th').removeClass('sorted-column');
                $($element[0]).addClass('sorted-column');
                $scope.$parent.appsVar.sortField = $($element[0]).attr('sort-value');
                console.log('sorting...with column ' + $scope.$parent.appsVar.sortField);
                if ($scope.onSorting) {
                    $scope.onSorting();
                } else {
                    $rootScope.$broadcast('onTableSorting', $($element[0]).attr('sort-value'));
                }
            }

        },
        //scope: true,
        link: function (scope, element, attrs) {
            if (scope.isAssending == undefined) {
                scope.isAssending = true;
            }
            $templateRequest("Views/DirectiveTemplates/TableSortButton.html").then(function (html) {
                element.append($compile(html)(scope));
            });
        }
    }
});

app.directive('filterColumn', function ($templateRequest, $compile, $timeout) {
    return {
        restrict: 'C',
        scope: {
            FilterText: '=?',
            onFiltering: '=?',
            FIlterType: '=?',
            checkboxFilter: '=?'

        },
        controller: function ($scope, $element, $rootScope) {
            $scope.FIlterType = $($element[0]).attr('filter-type');
            $scope.FilterClass = $($element[0]).attr('filter-class');
            $scope.onFiltering = $($element[0]).attr('filter-sub');
            $scope.checkboxFilter = {};
            $scope.checkboxFilter.Yes = false;
            $scope.checkboxFilter.No = false;
            $scope.checkboxFilter.FilterText = '';
            $scope.checkboxFilter.FilterKey = $($element[0]).attr('filter-key');


            var searchTimeout;
            var isClearSearch = false;
            $scope.$watch(function () { return $scope.checkboxFilter.FilterText }, function (newVal, oldVal) {
                if (isClearSearch) {
                    isClearSearch = false;
                } else {
                    if (oldVal != newVal) {
                        if (searchTimeout) $timeout.cancel(searchTimeout);

                        searchTimeout = $timeout(function () {
                            if ($scope.onFiltering) {
                                $rootScope.$broadcast('onsubTableFiltering', $scope.checkboxFilter.FilterText, $($element[0]).attr('filter-key'), $scope.onFiltering);
                            } else {
                                $rootScope.$broadcast('onTableFiltering', $scope.checkboxFilter.FilterText, $($element[0]).attr('filter-key'));
                            }
                        }, 2000);
                    }
                }
            }, true);
            $scope.applyFilter = function ($mdOpenMenu, event) {


                $mdOpenMenu(event);
            }

            $scope.FilterTextIconClick = function () {
                if (searchTimeout) $timeout.cancel(searchTimeout);
                $scope.checkboxFilter.FilterText = '';
                if ($scope.onFiltering) {
                    $rootScope.$broadcast('onsubTableFiltering', $scope.checkboxFilter.FilterText, $($element[0]).attr('filter-key'), $scope.onFiltering);
                } else {
                    $rootScope.$broadcast('onTableFiltering', $scope.checkboxFilter.FilterText, $($element[0]).attr('filter-key'));
                }
                isClearSearch = true;
            }

            $scope.applyCheckBox = function (scope) {
                if ($scope.checkboxFilter.Yes && $scope.checkboxFilter.No)
                    $scope.checkboxFilter.FilterText = '';
                else if ($scope.checkboxFilter.Yes && !$scope.checkboxFilter.No)
                    $scope.checkboxFilter.FilterText = 'Y';
                else if ($scope.checkboxFilter.No && !$scope.checkboxFilter.Yes)
                    $scope.checkboxFilter.FilterText = 'N';
                else $scope.checkboxFilter.FilterText = '';
            }
        },
        link: function (scope, element, attrs) {
            $templateRequest("Views/DirectiveTemplates/FilterInput.html").then(function (html) {
                element.append($compile(html)(scope));
            });
        }
    }
});

app.directive('contextMenu', function ($templateRequest, $compile, $timeout, $filter) {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            $templateRequest("Views/DirectiveTemplates/ContextMenu.html");
            element.on("contextmenu", function (e) {
                e.preventDefault(); // default context menu is disabled lScope
                //if (element.children().find('md-checkbox').attr('checked') != 'checked')
                //    element.children().find('md-checkbox').click();
                $timeout(function () {
                    if (attrs.menuListSource) {
                        scope.contextMenuList = scope.$eval(attrs.menuListSource);
                    } else {
                        scope.contextMenuList = scope.menuList;
                    }
                    if ($('.context-menu-container').length == 0) {
                        //  The customized context menu is defined in the main controller. To function the ng-click functions the, contextmenu HTML should be compiled.
                        $templateRequest("Views/DirectiveTemplates/ContextMenu.html").then(function (html) {
                            if (($filter('filter')(scope.contextMenuList, { Enable: true })).length > 0) {
                                element.parents('tbody').append($compile(html)(scope));
                                //$('.context-menu-container').css("visibility", 'hidden');
                                $('.context-menu-container').css("left", e.clientX);
                                $('.context-menu-container').css("top", e.clientY);
                            }
                        });
                    };
                });
            });
        }
    }
});

app.directive('popOver', function ($http) {
    return {
        restrict: 'C',
        link: function (scope, element, attr) {
            element.tooltip();
            element.bind('mouseover', function (e) {
                $http.get("test").success(function (data) {
                    attr.$set('originalTitle', scope.appsVar.tooltipValue);
                    element.tooltip('show');
                });
            });
        }
    }
});

app.directive('ngFiles', ['$parse', function ($parse) {

    function fn_link(scope, element, attrs) {
        var onChange = $parse(attrs.ngFiles);
        element.on('change', function (event) {
            onChange(scope, { $files: event.target.files });
        });
    };

    return {
        link: fn_link
    }
}]);

app.directive('changeValue', function () {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            scope.$watch(attrs.ngModel, function (v) {
                if (v == null || v == '')
                    //$(element[0]).siblings('md-icon').first().hide();
                    $(element[0]).siblings('md-icon').children().first().hide();
                else
                    //$(element[0]).siblings('md-icon').first().show();
                    $(element[0]).siblings('md-icon').children().first().show();
            });
        }
    };
});

//passwordCharView
(function () {
    app.directive('passwordCharView', function ($timeout) {
        return {
            restrict: 'A',
            require: 'ngModel',
            scope: {
                modelValue: '=',
                ngModel: '='
            },
            link: function (scope, element, attr) {
                var lastCaretPosition = 0;
                $(element).attr('autocomplete', 'off');
                $timeout(function () {
                    scope.$apply(function () {
                        $(element).val('');
                        scope.modelValue = '';
                    });
                });
                var searchTimeout;
                element.bind("cut copy paste", function (event) {
                    event.preventDefault();
                });
                element.bind("focus", function (event) {
                    if (scope.modelValue == undefined || scope.modelValue.length != $(element).val().length) {
                        $(element).val('');
                        scope.modelValue = '';
                    }
                })
                element.bind("keypress", function (event) {
                    lastCaretPosition = $(element).caret().begin + 1;
                    if (event.which >= 32 && event.which <= 126) {
                        $(element).attr('type', 'text');
                        if (searchTimeout) {
                            $timeout.cancel(searchTimeout);
                            var str = '';
                            for (var i = 0, len = $(element).val().length; i < len; i++) {
                                str += '\u25CF';
                            }
                            scope.$apply(function () {
                                scope.ngModel = str;
                            });
                            if ($(element).caret().begin == $(element).caret().end)
                                $(element).caret(lastCaretPosition - 1);
                        }
                        if ($(element).val() == undefined) {
                            $(element).val('');
                        }
                        if (scope.modelValue == undefined) scope.modelValue = '';

                        if ($(element).val().length == $(element).caret().begin) {
                            $(element).val($(element).val() + String.fromCharCode(event.charCode));
                            scope.modelValue += String.fromCharCode(event.charCode);
                        } else {
                            scope.modelValue = scope.modelValue.substring(0, $(element).caret().begin) + String.fromCharCode(event.charCode) + scope.modelValue.substring($(element).caret().end, scope.modelValue.length);
                            var newVal = $(element).val().substring(0, $(element).caret().begin) + String.fromCharCode(event.charCode) + $(element).val().substring($(element).caret().end, $(element).val().length);
                            $(element).val(newVal);
                        }
                        $(element).caret(lastCaretPosition);
                        event.preventDefault();

                        searchTimeout = $timeout(function () {
                            var str = '';
                            for (var i = 0, len = $(element).val().length; i < len; i++) {
                                str += '\u25CF';
                            }
                            scope.$apply(function () {
                                scope.ngModel = str;
                            });
                            $(element).caret(lastCaretPosition);
                        }, 1000);
                    } else if (event.which == 8) {
                        if ($(element).val().length == $(element).caret().begin) {
                            scope.modelValue = scope.modelValue.slice(0, -1);
                        } else {
                            scope.modelValue = scope.modelValue.substring(0, $(element).caret().begin) + scope.modelValue.substring($(element).caret().end, scope.modelValue.length);
                        }
                    } else if (event.which == 0) {
                        if ($(element).val().length == $(element).caret().begin) {
                        } else if ($(element).caret().begin == $(element).caret().end) {
                            scope.modelValue = scope.modelValue.substring(0, $(element).caret().begin) + scope.modelValue.substring($(element).caret().end + 1, scope.modelValue.length);
                        } else {
                            scope.modelValue = scope.modelValue.substring(0, $(element).caret().begin) + scope.modelValue.substring($(element).caret().end, scope.modelValue.length);
                        }
                    }
                });
                var ua = window.navigator.userAgent;
                var msie = ua.indexOf("MSIE ");

                if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) {
                    element.bind("keydown", function (event) {
                        if (event.keyCode == 8) {
                            scope.$apply(function () {
                                if ($(element).val().length == $(element).caret().begin) {
                                    scope.modelValue = scope.modelValue.slice(0, -1);
                                } else {
                                    scope.modelValue = scope.modelValue.substring(0, $(element).caret().begin) + scope.modelValue.substring($(element).caret().end, scope.modelValue.length);
                                }
                            });
                        }
                    });
                }
            }
        }
    });
})();

//tableFilter
(function () {
    app.directive('tableFilter', function ($templateRequest, $compile, $window, $timeout, $log) {
        return {
            restrict: 'E',
            scope: {
                isFilterShowing: '=',
                onFilter: '&',
                isHidden: '=?'
            },
            link: function (scope, element, attr) {
                $templateRequest("Views/DirectiveTemplates/TableFilter.html").then(function (html) {
                    //var elem = $('table > thead > tr')
                    //element.children().find(elem).append($compile(html)(scope));

                    var elem = $('table.clone > thead > tr > th:last-child');
                    element.parent().find(elem).append($compile(html)(scope));
                });
                $templateRequest("Views/DirectiveTemplates/FilterClearFields.html").then(function (html) {
                    var elem = $('table > tbody > tr.filter-row > td:last-child')
                    element.children().find(elem).append($compile(html)(scope));
                });
            },
            controller: function ($scope, $element) {
                if ($scope.isHidden == undefined) {
                    $scope.isHidden = true;
                }
                var isInstantFilter = false;
                var disablePerformFilter = false;
                var lastFilterText = null;
                var lastFilterKey = null;
                $scope.FilterCount = 0;
                $scope.filterClicked = function () {
                    $scope.isFilterShowing = !$scope.isFilterShowing;
                    if ($scope.isFilterShowing) {
                        $("html").animate({ scrollTop: "0px" });
                        $window.scrollTo(0, 0);
                    }
                };

                $scope.onMouseLeave = function () {
                    if ($window.navigator.userAgent.indexOf('Chrome') > 0) {
                        $('table-filter>table.md-table').css('overflow', 'auto');
                        $timeout(function () {
                            $('table-filter>table.md-table').css('overflow', 'hidden');
                        });
                    }
                };

                $scope.clearFilter = function () {
                    isInstantFilter = true;
                    disablePerformFilter = true;
                    var combobox_elements = [].slice.call($element[0].querySelectorAll('.filter-combo-container'), 0);
                    var combobox_controllers = combobox_elements.map(function (el) {
                        return angular.element(el).scope();
                    });
                    combobox_controllers.forEach(function (scope) {
                        scope.clearFilter()
                    });

                    var textbox_elements = [].slice.call($element[0].querySelectorAll('.filterTextbox'), 0);
                    var textbox_controllers = textbox_elements.map(function (el) {
                        return angular.element(el).scope();
                    });
                    textbox_controllers.forEach(function (scope) {
                        scope.clearFilter()
                    });
                    $timeout(function () {
                        disablePerformFilter = false;
                        $scope.onFilter('', '', isInstantFilter, disablePerformFilter);
                        calculateFilterCount();
                        isInstantFilter = false;
                    });
                };

                var calculateFilterCount = function () {
                    $scope.FilterCount = 0;
                    var combobox_elements = [].slice.call($element[0].querySelectorAll('.filter-combo-container'), 0);
                    var combobox_controllers = combobox_elements.map(function (el) {
                        return angular.element(el).scope();
                    });
                    combobox_controllers.forEach(function (scope) {
                        $scope.FilterCount = $scope.FilterCount + (scope.isFilterApplied() ? 1 : 0)
                    });

                    var textbox_elements = [].slice.call($element[0].querySelectorAll('.filterTextbox'), 0);
                    var textbox_controllers = textbox_elements.map(function (el) {
                        return angular.element(el).scope();
                    });
                    textbox_controllers.forEach(function (scope) {
                        $scope.FilterCount = $scope.FilterCount + (scope.isFilterApplied() ? 1 : 0)
                    });
                }

                $scope.onFilter = $scope.onFilter();
                this.performFilter = function (filterText, filterKey) {
                    if (!(lastFilterText == filterText && lastFilterKey == filterKey)) {
                        $scope.onFilter(filterText, filterKey, isInstantFilter, disablePerformFilter);
                        calculateFilterCount();
                        lastFilterText = filterText;
                        lastFilterKey = filterKey
                    }
                }
                this.setInstantFilterFlag = function (isInstantFilterValue) {
                    isInstantFilter = isInstantFilterValue;
                }
            }
        }
    });
})();

//tableWrapper
(function () {
    app.directive('tableWrapper', function ($filter) {
        return {
            restrict: 'E',
            //transclude: true,
            templateUrl: 'Views/DirectiveTemplates/TableWrapper.html',
            link: function (scope, element, attr) {
                scope.tableLabels = {
                    title: '',
                    searchHint: '',
                    selectTitle: ''
                }
                scope.tableOptions = {
                    disablePagination: false,
                    hideSearch: false,
                    showSearchProgress: false,
                    showSearchFields: false
                }
                if (attr.tableTitle) {
                    scope.$watch(function () { return scope.$eval(attr.tableTitle) }, function () {
                        scope.tableLabels.title = scope.$eval(attr.tableTitle) ? scope.$eval(attr.tableTitle) : attr.tableTitle;

                    });
                }
                if (attr.selectTitle) {
                    scope.$watch(function () { return scope.$eval(attr.selectTitle) }, function () {
                        scope.tableLabels.selectTitle = scope.$eval(attr.selectTitle) ? scope.$eval(attr.selectTitle) : attr.selectTitle;

                    });

                }
                if (attr.searchHint) {

                    scope.tableLabels.searchHint = scope.$eval(attr.searchHint) ? scope.$eval(attr.searchHint) : attr.searchHint;
                }
                if (attr.disablePagination) {
                    scope.$watch(function () { return scope.$eval(attr.disablePagination) }, function () {
                        //scope.$apply(function () {
                        scope.tableOptions.disablePagination = scope.$eval(attr.disablePagination);
                        //? (scope.$eval(attr.disablePagination) == true) : attr.disablePagination
                        //})
                    });
                }
                if (attr.hideSearch) {
                    scope.$watch(function () { return scope.$eval(attr.hideSearch) }, function () {
                        //scope.$apply(function () {
                        scope.tableOptions.hideSearch = scope.$eval(attr.hideSearch);
                        //? (scope.$eval(attr.disablePagination) == true) : attr.disablePagination
                        //})
                    });
                }
                if (attr.showSearchProgress) {
                    scope.$watch(function () { return scope.$eval(attr.showSearchProgress) }, function () {
                        scope.tableOptions.showSearchProgress = scope.$eval(attr.showSearchProgress);
                    });
                }
                if (attr.showSearchFields) {
                    scope.$watch(function () { return scope.$eval(attr.showSearchFields) }, function () {
                        scope.tableOptions.showSearchFields = scope.$eval(attr.showSearchFields);
                    });
                }
            }
        }
    });
})();

//filterTextbox
(function () {
    app.directive('filterTextbox', function ($timeout, $log) {
        return {
            restrict: 'E',
            require: ['^tableFilter'],
            scope: true,
            templateUrl: 'Views/DirectiveTemplates/FilterTextbox.html',
            link: function (scope, element, attr, ctrl) {
                scope.filterText = '';
                scope.filterKeyName = '';
                var tableFilterCtrl = ctrl[0];
                if (!attr.filterKey) {
                    $log.error('Filter key attribute is missing.');
                }
                scope.showEditField = true;
                scope.filterKeyName = attr.placeholderLabel ? attr.placeholderLabel : attr.filterKey;
                scope.onEditFieldLeave = function () {
                    if (scope.filterText != '' && scope.filterText != undefined)
                        scope.showEditField = false;
                }

                scope.onDisplayFieldClicked = function () {
                    scope.showEditField = true;
                    $timeout(function () {
                        element.children()[0].focus()
                    });
                }

                scope.onDisplayCloseClicked = function () {
                    scope.showEditField = true;
                    scope.filterText = '';
                    tableFilterCtrl.setInstantFilterFlag(true);
                    tableFilterCtrl.performFilter(scope.filterText, attr.filterKey);
                    tableFilterCtrl.setInstantFilterFlag(false);
                }
                //var searchTimeout;
                scope.$watch(function () { return scope.filterText }, function (newVal, oldVal) {
                    if (oldVal != newVal) {
                        tableFilterCtrl.performFilter(scope.filterText, attr.filterKey);
                    }
                }, true);
            },
            controller: function ($scope) {
                $scope.clearFilter = function () {
                    $scope.showEditField = true;
                    $scope.filterText = '';
                }

                $scope.isFilterApplied = function () {
                    return $scope.filterText != '';
                }
            }
        }
    });
})();

//filterCombobox
(function () {
    app.directive('filterCombobox', function ($timeout, $log) {
        return {
            restrict: 'E',
            require: ['^tableFilter'],
            scope: true,
            templateUrl: 'Views/DirectiveTemplates/FilterCombobox.html',
            link: function (scope, element, attr, ctrl) {
                var tableFilterCtrl = ctrl[0];
                scope.filter = {
                    selected: ''
                }
                if (!attr.filterKey) {
                    $log.error('Filter key attribute is missing.');
                }
                if (attr.options) {
                    scope.options = scope.$eval(attr.options);
                    if (attr.watchOptions) {
                        scope.$watch(function () { return scope.$eval(attr.options) }, function (newVal, oldVal) {
                            if (oldVal != newVal) {
                                scope.options = scope.$eval(attr.options);
                            }
                        });
                    }
                } else {
                    scope.options = [{ 'DisplayText': 'Yes', 'ValueText': 'Y' }, { 'DisplayText': 'No', 'ValueText': 'N' }];
                }
                scope.showEditField = true;
                scope.elementName = attr.filterKey;
                scope.onEditFieldChange = function () {
                    if (scope.filter.selected != '' && scope.filter.selected != undefined)
                        scope.showEditField = false;
                }

                scope.onDisplayFieldClicked = function () {
                    scope.showEditField = true;
                }

                scope.onDisplayCloseClicked = function ($event) {
                    scope.showEditField = true;
                    scope.filter.selected = '';
                    tableFilterCtrl.setInstantFilterFlag(true);
                    tableFilterCtrl.performFilter(scope.filter.selected.ValueText, attr.filterKey);
                    tableFilterCtrl.setInstantFilterFlag(false);
                    $event.stopPropagation();
                }

                var searchTimeout;
                scope.$watch(function () { return scope.filter.selected.ValueText }, function (newVal, oldVal) {
                    if (oldVal != newVal) {
                        tableFilterCtrl.performFilter(scope.filter.selected.ValueText, attr.filterKey);
                    }
                }, true);
            },
            controller: function ($scope) {
                $scope.clearFilter = function () {
                    $scope.showEditField = true;
                    $scope.filter.selected = '';
                }

                $scope.isFilterApplied = function () {
                    return $scope.filter.selected != '';
                }
            }
        }
    });
})();

//responsiveTabs
(function () {
    app.directive('responsiveTabs', function ($timeout, $compile) {
        return {
            restrict: 'C',
            link: function (scope, element, attrs) {
                if (scope.$last) {
                    $('nav.tabs-bar').removeClass("tabs-center");
                    var tabbar = $(".tabs-bar"),
                    tabList = tabbar.children(".tabs-list-container").children(".tabs-list"),
                    tabListItem = tabList.children("md-list-item"),

                    dropdownToggle = $("#dropdown-toggle"),
                    dropdown = $(".dropdown"),
                    dropdownToBeToggled = $(".dropdown,#dropdown-toggle"),
                    dropdownList = dropdown.children("md-list");

                    var tabsToList = function () {
                        $('nav.tabs-bar').removeClass("tabs-center")
                        dropdownToBeToggled.removeClass("show");
                        var tabbarWidth = tabbar.width() - 97;
                        tabListItem.each(function (index) {
                            var dropdownListItem = dropdownList.children("md-list-item:eq(" + index + ")"),
                                tabListItemOffset = $(this).position().left + $(this).outerWidth();

                            if (tabListItemOffset >= tabbarWidth) {
                                $(this).addClass("hide");
                                dropdownListItem.addClass("show");
                            } else {
                                $(this).removeClass("hide");
                                dropdownListItem.removeClass("show");
                            }
                        });
                        $timeout(function () {
                            tabList.children(".hide").length != 0 ?
                            $('nav.tabs-bar').removeClass("tabs-center") : $('nav.tabs-bar').addClass("tabs-center");
                            $timeout(function () {
                                var width = 80;
                                $.each(tabList.children("md-list-item.hide:first").prevAll(), function (index, value) {
                                    width += $(value).width();

                                });
                                var rightmargin = tabbar.width() - width + 15;

                                tabList.children(".hide").length != 0 ?
                                dropdownToBeToggled.addClass("show") : dropdownToBeToggled.removeClass("show");
                                dropdownToBeToggled.css("margin-right", rightmargin);
                            });
                        }, 1000);
                    };
                    $(function () {
                        tabListItem.on("hover click touchstart", function (e) { if ($(this).is(".hide")) e.preventDefault() });
                        dropdownList.on("hover click touchstart", function (e) { if ($(this).parent().not(".open")) e.preventDefault() });
                        //tabListItem.clone().appendTo(dropdownList);
                        //dropdownList.click(function (e) { e.stopPropagation() });

                        if (dropdownToggle.click) {
                            dropdownToggle.off('click');
                        }
                        dropdownToggle.click(function (e) {
                            e.stopPropagation();
                            if (dropdownToBeToggled.is(".show")) dropdownToBeToggled.toggleClass("open");
                        });
                        $(document).on("click ", function () {
                            if (dropdownToBeToggled.is(".show")) dropdownToBeToggled.removeClass("open");
                        });
                    });
                    $(window).on("load resize", tabsToList);
                    $timeout(function () {
                        tabsToList();
                    });
                }
            }
        }
    });
})();

//selectRows
(function () {
    app.directive('selectRows', function ($timeout) {
        return {
            restrict: 'C',
            link: function (scope, element, attrs) {
                $(element).on('mouseup', function (event) {
                    if ($(event.target).parents('tr[md-on-select]').length) {
                        event.preventDefault();
                        event.stopPropagation();
                        $timeout(function () {
                            if (!event.ctrlKey && !event.shiftKey) {
                                var elementScope = angular.element($(event.target).parents('tr').children().find('md-checkbox')).scope();
                                if (!(event.button == 2 && elementScope.$mdSelect.isSelected())) {
                                    var keepCurrentRowSelection = false;
                                    if (!$(event.target).parent().is('md-checkbox')) {
                                        var checked_elements = [].slice.call($(event.target).parents('tbody').find('md-checkbox[checked=checked]').not($(event.target).parents('tr').children().find('md-checkbox')), 0);
                                        if (checked_elements.length) {
                                            keepCurrentRowSelection = ($(event.target).parent().is('md-checkbox') && !elementScope.$mdSelect.isSelected()) || (!$(event.target).parent().is('md-checkbox') && elementScope.$mdSelect.isSelected());
                                            var combobox_controllers = checked_elements.map(function (el) {
                                                return angular.element(el).scope();
                                            });
                                            if (combobox_controllers.length) {
                                                combobox_controllers.forEach(function (ctrlScope) {
                                                    ctrlScope.$apply(function () { ctrlScope.$mdSelect.toggle() });
                                                });
                                            };
                                        };
                                    }
                                    $timeout(function () {
                                        if (keepCurrentRowSelection) {
                                            if ($(event.target).parent().is('md-checkbox')) {
                                                elementScope.$apply(function () { elementScope.$mdSelect.toggle(); });
                                            }
                                        } else {
                                            if (!$(event.target).parent().is('md-checkbox') || event.button == 2) {
                                                elementScope.$apply(function () { elementScope.$mdSelect.toggle(); });
                                            }
                                        }
                                        if (elementScope.$mdSelect.isSelected()) {
                                            scope.lastSelectedRow = $(event.target).parents('tr');
                                        }
                                    });
                                };
                            } else if (event.ctrlKey) {
                                $timeout(function () {
                                    var elementScope = angular.element($(event.target).parents('tr').children().find('md-checkbox')).scope();
                                    if (!$(event.target).parent().is('md-checkbox') || event.button == 2) {
                                        elementScope.$apply(function () { elementScope.$mdSelect.toggle(); });
                                    }
                                    if (elementScope.$mdSelect.isSelected()) {
                                        scope.lastSelectedRow = $(event.target).parents('tr');
                                    }
                                });
                            } else if (event.shiftKey) {
                                var elementScope = angular.element($(event.target).parents('tr').children().find('md-checkbox')).scope();
                                if (scope.lastSelectedRow && angular.element(scope.lastSelectedRow.children().find('md-checkbox')).scope().$mdSelect.isSelected()) {
                                    var traversalRow = $(scope.lastSelectedRow);
                                    var lastSelectedRowIndex = $(scope.lastSelectedRow).index();
                                    var currentRowIndex = $(event.target).parents('tr').index();
                                    if (lastSelectedRowIndex < currentRowIndex) {
                                        //traverse to down
                                        while (traversalRow.index() < currentRowIndex) {
                                            traversalRow = traversalRow.next('tr');
                                            var traversalRowScope = angular.element(traversalRow.children().find('md-checkbox')).scope();
                                            if (!traversalRowScope.$mdSelect.isSelected()) {
                                                traversalRowScope.$apply(function () { traversalRowScope.$mdSelect.toggle(); });
                                            }
                                        }
                                    } else if (lastSelectedRowIndex > currentRowIndex) {
                                        //traverse to up
                                        while (traversalRow.index() > currentRowIndex) {
                                            traversalRow = traversalRow.prev('tr');
                                            var traversalRowScope = angular.element(traversalRow.children().find('md-checkbox')).scope();
                                            if (!traversalRowScope.$mdSelect.isSelected()) {
                                                traversalRowScope.$apply(function () { traversalRowScope.$mdSelect.toggle(); });
                                            }
                                        }
                                    }
                                }
                                if (elementScope.$mdSelect.isSelected()) {
                                    scope.lastSelectedRow = $(event.target).parents('tr');
                                }
                            }
                            if (event.button == 2) {
                                $(event.target).contextmenu();
                                $timeout(function () {
                                    $('.context-menu-container').css("left", event.clientX);
                                    $('.context-menu-container').css("top", event.clientY);
                                });
                            } else {
                                $('.context-menu-container').remove();
                            }
                        });
                    }
                });
            }
        }
    });
})();

//setFocus
(function () {
    app.directive('setFocus', function ($timeout) {
        return {
            restrict: 'A',
            link: function (scope, element, attrs) {
                $timeout(function () {
                    element.focus();
                })
            }
        }
    });
})();

//setDialogFocus
(function () {
    app.directive('setDialogFocus', function ($timeout) {
        return {
            restrict: 'A',
            link: function (scope, element, attrs) {
                var dialogLoadListener = scope.$watch(function () {
                    var input = document.querySelectorAll('md-dialog')
                    if (!input) return;
                    $timeout(function () {
                        element.focus();
                        $timeout(function () {
                            dialogLoadListener();
                        }, 1000);
                    });
                });
            }
        }
    });
})();

//clearAutoFocus
(function () {
    app.directive('clearAutoFocus', function ($timeout) {
        return {
            restrict: 'A',
            link: function (scope, element, attrs) {
                $timeout(function () {
                    $(function () {
                        $(element).blur();
                    })
                }, 2000);
            }
        }
    });
})();


//toolTip
(function () {
    app.directive('toolTip', function ($timeout, $log, $templateRequest, $compile) {
        return {
            restrict: 'A',
            scope: {
                displayText: '=',
                displayTooltip: '=',
                customstyle: '=',
                contentClickParam: '=',
                contentClick: '&?'
            },
            templateUrl: 'Views/DirectiveTemplates/ToolTip.html',
            controller: function ($scope) {
                $scope.contentClicked = function ($event) {
                    if ($event.which != 2 && $scope.contentClick) {
                        $scope.$eval($scope.contentClick)($scope.contentClickParam, $event);
                    }
                }
                $scope.stopPropagation = function (event) {
                    var isRightButtonClick = false;

                    if (event.which) {
                        isRightMB = event.which == 3;
                    }
                    else if (event.button) {
                        isRightMB = event.button == 2;
                    }
                    if (isRightButtonClick && $scope.contentClick) {
                        event.stopPropagation();
                    }
                };
            },
            link: function (scope, element, attr, ctrl) {
                scope.displayTooltip = "tooltiptextnone";
                scope.changeleave = function (event) {
                    scope.displayTooltip = "tooltiptextnone";
                }

                scope.change = function (event) {

                    var $e = $(event.target.parentElement), h = $(event.target).height();
                    $e.css({ 'overflow': 'visible', 'white-space': 'normal', 'word-break': 'break-all' });
                    if ($(event.target).height() > h || event.target.parentElement.scrollWidth > event.target.parentElement.clientWidth) {
                        var left = 0;
                        var top = 0;
                        if (!$('#app-navigation-menu').is(":visible")) {
                            left = event.originalEvent.pageX;
                            top = event.originalEvent.pageY - 210;
                            if ($(event.target.parentElement).is("th"))
                                top = -5;



                        } else if ($('#app-navigation-menu').hasClass('page-sidebar-full')) {
                            left = event.originalEvent.pageX - parseInt($('.page-content').css('padding-left')) - 5;
                            top = event.originalEvent.pageY - 160;
                            if ($(event.target.parentElement).is("th"))
                                top = -5;


                        } else {
                            left = event.originalEvent.pageX - 80;
                            top = event.originalEvent.pageY - 160;
                            if ($(event.target.parentElement).is("th"))
                                top = -5;


                        }

                        scope.customstyle = "left:" + left + "px;top:" + top + "px;";
                        $(event.target.parentElement).children('span.eletooltip').css({ "left": left + "px", "top": +top + "px" });
                        scope.displayTooltip = "tooltiptext";
                    }
                    $e.css({ 'overflow': 'hidden', 'white-space': 'nowrap', 'word-break': '' });


                }

            }
        }
    });
})();

//fixTitle
(function (window, angular, undefined) {
    'use strict';

    app.directive('fixTitle', fixTitle);

    function fixTitle($compile, $window) {

        function compile(tElement) {
            var table = {
                clone: tElement.clone().empty(),
                original: tElement
            };

            var header = {
                clone: tElement.clone(),
                original: tElement
            };

            // prevent recursive compilation
            header.clone.removeAttr('fix-title').removeAttr('ng-if');

            header.clone.css({ display: 'block', overflow: 'hidden' }).addClass('clone');
            header.clone.css('display', 'block');

            return function postLink(scope) {
                var scrollContainer = $(header.original.parent()[0]);

                // insert the element so when it is compiled it will link
                // with the correct scope and controllers
                header.original.after(header.clone);

                $compile(header.clone)(scope);

                header.original.on('$destroy', function () {
                    header.clone.remove();
                });
            };
        }

        return {
            compile: compile
        };
    }

    fixTitle.$inject = ['$compile', '$window'];

})(window, angular);

app.directive('myEnter', function () {
    return {
        link: function (scope, elem, attrs) {
            elem.bind("keydown keypress", function (event) {
                if (event.which === 13) {
                    scope.$apply(function () {
                        scope.$eval(attrs.myEnter);
                    });

                    event.preventDefault();
                }
            });
        }
    };
});
