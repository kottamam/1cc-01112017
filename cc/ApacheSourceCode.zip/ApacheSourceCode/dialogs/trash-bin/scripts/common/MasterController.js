(function() {
    'use strict';

   
        angular.module('iManage.Trashbin').controller("masterController", masterController);
     

    masterController.$inject = ['$state', '$cookies', 'homeFactory', '$interval', '$timeout', 'homeService', '$location', '$localStorage'];

    function masterController($state, $cookies, homeFactory, $interval, $timeout, homeService, $location, $localStorage) {
        var mc = this;
        mc.$storage = $localStorage;

        if (mc.$storage.maxAge && mc.$storage.LastActiveTime) {
            if (new Date().getTime() > mc.$storage.LastActiveTime + (mc.$storage.maxAge * 1000)) {
                $localStorage.$reset();
            }
        }
        mc.loginModel = {
            UserName: '',
            Password: '',
            ApiUrl: '',
            AuthKey: '',
            ApplicationName: 'Control Center',
            networklogin: false,
            UserSessionTimeOut: null
        };

        mc.PasswordDisplayText = '';
        mc.onError = false;
        mc.message = '';
        mc.IsLoading = false;
        mc.ApplicationTitle = 'Trash';
        mc.passwordType = 'password';
        mc.objectDet = {
            name: ''
        };
        mc.maxAge = undefined;

        mc.getlogDetails = getlogDetails;
        mc.setSecurityLogDetails = setSecurityLogDetails;








        function getlogDetails(level, message) {
            //var apiUrl = homeFactory.getIMCCAPIUrl('SAVELOG');
            //homeService.getlogDetails(apiUrl, level, message);
        }

        function setSecurityLogDetails(level, state, userAffected, activity, activityParam) {

        }

    }
})();