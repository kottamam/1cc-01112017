﻿(function() {
    'use strict';

    angular.module('iManage.Trashbin').constant('TSU_TRANSLATE', {
        GET_TRANSLATE: 'startup/strings',
        GET_STARTUP_INIT_DATA: 'startup/init-data',
        WEB_SETTINGS_URL: 'config/Web/files/websettings',
        GET_DB_LIST: 'libraries',
        GET_SYSTEM_CONFIG: 'system/config?include_databases=true'
    });

})();