(function() {
    'use strict';
    
    angular.module('iManage.Trashbin', ['ngMaterial', 'ngAnimate', 'ui.router', 'ngCookies', 'ngStorage', 'md.data.table', 'material.svgAssetsCache', 'pascalprecht.translate', 'angularMoment']);
       // angular.module('iManage.Trashbin', ['ngMaterial', 'ngAnimate', 'ui.router', 'ngAria',  'ngMessages', 'ngCookies', 'ngSanitize', 'fixed.table.header',  'ngStorage']);
         
     
})();

(function() {
    'use strict';

    
        angular.module('iManage.Trashbin').factory('sessionTimeoutInterceptor', sessionTimeoutInterceptor);
    
    sessionTimeoutInterceptor.$inject = ['$window', '$timeout', '$cookies', '$localStorage'];

    function sessionTimeoutInterceptor($window, $timeout, $cookies, $localStorage) {
        return {
            request: function(config) {
                return config;
            },
            response: function(response) {
                // if (UserSessionTimer) {
                //     $timeout.cancel(UserSessionTimer);
                //     UserSessionTimer = null;
                // }
                return response;
            },
            responseError: function(response) {
                $cookies.sessiontimeout = response.status;
                return response;
            }
        };
    }
})();

(function() {
    'use strict';

    
        angular.module('iManage.Trashbin').config(httpProviderConfig);
    
    httpProviderConfig.$inject = ['$httpProvider'];

    function httpProviderConfig($httpProvider) {
        $httpProvider.defaults.withCredentials = true;
        $httpProvider.defaults.useXDomain = true;
        return $httpProvider.interceptors.push('sessionTimeoutInterceptor');
    }
})();

(function() {
    'use strict';

    
        angular.module('iManage.Trashbin').config(homeRoute);
     
    homeRoute.$inject = ['$stateProvider', '$urlRouterProvider', '$logProvider'];

    function homeRoute($stateProvider, $urlRouterProvider, $logProvider) {
        $urlRouterProvider.otherwise("/");

        $stateProvider
            .state('home', {
                url: '/?dbname&server&userid&protocol',
                templateUrl: 'scripts/trashbin/filelist.html',
                controller: 'TrashbinController as vmTrashbinCtrl'
            })
            .state('home.management', {
                url: 'management',
                abstract: true
            })
    };
})();

(function() {
    'use strict';

    
        angular.module('iManage.Trashbin').filter('customLabel', customLabel);
     
    customLabel.$inject = ['$filter'];

    function customLabel($filter) {
        return function(list, alias) {
            var capList = $filter('filter')(list, { MetaDataItem: (alias ? alias : '').toUpperCase() }, true);
            if (capList != null && capList.length > 0) {
                return capList[0].DisplayText;
            }
            return alias;
        }
    };
})();

(function () {
    'use strict';

   
    angular.module('iManage.Trashbin').config(translateProviderConfig);

    translateProviderConfig.$inject = ['$translateProvider'];
    function translateProviderConfig($translateProvider) {
        $translateProvider.addInterpolation('$translateMessageFormatInterpolation');
        $translateProvider.useLoader('translateFactory');
        $translateProvider.preferredLanguage('en-Us');
		$translateProvider.useSanitizeValueStrategy('escapeParameters');
    }

})();
 
