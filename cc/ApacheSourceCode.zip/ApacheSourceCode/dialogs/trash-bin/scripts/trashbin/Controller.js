(function() {
    'use strict';


    angular.module('iManage.Trashbin').controller("TrashbinController", trashbinController);
    trashbinController.$inject = ['$scope', '$log', '$state', '$location', '$rootScope', '$timeout', '$cookies',
        '$interval', '$filter', '$stateParams', '$mdDialog', '$q', '$compile', '$window',
        'homeService', 'homeFactory', 'TrashbinFactory', '$translate'
    ];

    function trashbinController($scope, $log, $state, $location, $rootScope, $timeout, $cookies,
        $interval, $filter, $stateParams, $mdDialog, $q, $compile, $window,
        homeService, homeFactory, TrashbinFactory, $translate) {

        var vmTrashbinCtrl = this;
        var loadDocumentOnScrollWin = false;
        var FilterSearchTimeout;
        var isAutoSearchDisabled = false;
        var baseV2Url = '';

        vmTrashbinCtrl.DocumentsRequestModel = {};
        vmTrashbinCtrl.IsDBListHidden = false;
        vmTrashbinCtrl.IsHideDocumentListWindow = false;
        vmTrashbinCtrl.IsShowRestoreMessageWindow = false;
        vmTrashbinCtrl.IsShowRestoreSuccessMsg = undefined;
        vmTrashbinCtrl.IsShowRestoreErrorMsg = false;
        vmTrashbinCtrl.IsShowNoDocFound = false;
        vmTrashbinCtrl.SelectedLibrary = '';
        vmTrashbinCtrl.SelectedDocument = null;
        vmTrashbinCtrl.TypeFilterSelectedItem = null;
        vmTrashbinCtrl.TypeFilterSearchText = null;
        vmTrashbinCtrl.DBList = [];
        vmTrashbinCtrl.FileList = [];
        vmTrashbinCtrl.FolderPathList = [];
        vmTrashbinCtrl.versionList = [];
        vmTrashbinCtrl.CurrentDate = new Date();

        vmTrashbinCtrl.SelectClicked = false;
        vmTrashbinCtrl.IsShowDeleteDocWindow = false;
        vmTrashbinCtrl.IsShowDeleteDocSuccessMsg = false;
        vmTrashbinCtrl.IsShowDeleteDocErrorMsg = false;
        vmTrashbinCtrl.DeleteErrorMessage = '';
        vmTrashbinCtrl.HideFilter = true;
        vmTrashbinCtrl.isLearnMore = false;
        vmTrashbinCtrl.isSingleRestore = true;
        vmTrashbinCtrl.isExternalWindow=false;
        vmTrashbinCtrl.ShowTimeLine= ShowTimeLine;
        vmTrashbinCtrl.CurrentTab = 'TRASH'

        /*vmTrashbinCtrl.DontShowPurgeConfirm = undefined;
        var isJobCancelled = false;
        var isErrorFoundInDeleteDoc = false;
        vmTrashbinCtrl.purgeSelected = [];
        vmTrashbinCtrl.multiPurge = [];
        var currentPurge = [];
        var successCount = 0;
        vmTrashbinCtrl.isDeleteAll = false;
        vmTrashbinCtrl.isPurgeCancel = false;
        vmTrashbinCtrl.isPurging = false;
        var deleteallindex = 0;
        var reloadDocs = false;
        var lastAppendItemCount = 0;
        var SelectedDocIdListForFilter = [];
        var LastAddedSelectedItemId = [];*/

        vmTrashbinCtrl.menuList = [{
                Label: 'trashBin.restore',
                Enable: true,
                IconType: 'font-icon',
                Icon: 'ic-restore-page',
                onClick: checkVersionExist
            }
            /*,
                        {
                            Label: 'delete',
                            Enable: true,
                            IconType: 'font-icon',
                            Icon: 'ic-delete-page',
                            onClick: openDeleteDocWindow
                        }*/
        ];

        vmTrashbinCtrl.OpenDeleteDocWindow = openDeleteDocWindow;
        vmTrashbinCtrl.CloseDeleteDocWindow = closeDeleteDocWindow;
        vmTrashbinCtrl.DeleteSelectedDoc = deleteSelectedDoc;
        vmTrashbinCtrl.CloseWindow = closeWindow;
        vmTrashbinCtrl.SelectedDB_Change = selectedDB_Change;
        vmTrashbinCtrl.CloseRestoreMessageWindow = closeRestoreMessageWindow;
        vmTrashbinCtrl.CalculateDate = calculateDate;
        vmTrashbinCtrl.SearchClick = searchClick;
        vmTrashbinCtrl.ResetSearchClick = resetSearchClick;
        vmTrashbinCtrl.ExpandPath = expandPath;
        //vmTrashbinCtrl.RestoreDocument = restoreDocument;
        vmTrashbinCtrl.MultipleRestoreDocument = multipleRestoreDocument;
        vmTrashbinCtrl.CheckVersionExist = checkVersionExist;
        vmTrashbinCtrl.GetCurrentDateTime = getCurrentDateTime;
        vmTrashbinCtrl.ResetFilters = ResetFilters;
        vmTrashbinCtrl.PerformInstantSearch = performInstantSearch;
        vmTrashbinCtrl.ScrollEvent = ScrollEvent;
        vmTrashbinCtrl.OpenDBList = OpenDBList;
        vmTrashbinCtrl.LearnMoreFn = learnMoreFn;
        vmTrashbinCtrl.RetryClick = retryClick;
        vmTrashbinCtrl.VersionChanged = versionChanged;
        vmTrashbinCtrl.TypeQuerySearch = typeQuerySearch;
        vmTrashbinCtrl.TypeFilter_Change = typeFilter_Change;
        /*vmTrashbinCtrl.DeletePermanently = deletePermanently;
        vmTrashbinCtrl.ClosePurgeConfirm = ClosePurgeConfirm;
        vmTrashbinCtrl.DeleteSelectedDocs = DeleteSelectedDocs;
        vmTrashbinCtrl.deleteAllDocs = DeleteAllDocs;
        vmTrashbinCtrl.cancelJobs = CancelJobs;
        vmTrashbinCtrl.cancelPurgeItem = CancelPurgeItem;*/
        vmTrashbinCtrl.onTabChanges = onTabChanges;

        $scope.startDate = null;
        $scope.endDate = null;
        $scope.currentDate = new Date();
        vmTrashbinCtrl.FilterCount = 0;

        getParams();

        $(window).scroll(function() {
            var scrollHeight = $(window).scrollTop() + $(window).height() - $(document).height();

            if (scrollHeight > -400) {
                ScrollEvent();
            }

        });

        function ResetFilters() {
            isAutoSearchDisabled = true;
            $timeout(function() {
                vmTrashbinCtrl.DocumentsRequestModel.DocNum = '';
                vmTrashbinCtrl.DocumentsRequestModel.DocVersion = '';
                $scope.startDate = $scope.endDate = null;
                vmTrashbinCtrl.DocumentsRequestModel.DocName = '';
                vmTrashbinCtrl.DocumentsRequestModel.DocType = '';
                vmTrashbinCtrl.DocumentsRequestModel.DeleteDate = '';
                vmTrashbinCtrl.TypeFilterSelectedItem = null;
                vmTrashbinCtrl.TypeFilterSearchText = '';
                searchClick();
                $timeout(function() {
                    isAutoSearchDisabled = false;
                }, 1000);
            });
        }

        function learnMoreFn() {
            vmTrashbinCtrl.isLearnMore = !vmTrashbinCtrl.isLearnMore;
        }

        $scope.$watch(function() { return vmTrashbinCtrl.DocumentsRequestModel.DocNum }, function(newVal, oldVal) {
            if (oldVal != newVal) {
                if (vmTrashbinCtrl.DocumentsRequestModel.DocNum.length == 0) {
                    if (vmTrashbinCtrl.DocumentsRequestModel.DocVersion.length > 0) {
                        vmTrashbinCtrl.DocumentsRequestModel.DocVersion = '';
                    }
                }
                performTableFilter();
            }
        }, true);

        $scope.$watch(function() { return vmTrashbinCtrl.DocumentsRequestModel.DocVersion }, function(newVal, oldVal) {
            if (oldVal != newVal) {
                performTableFilter();
            }
        }, true);

        $scope.$watch(function() { return vmTrashbinCtrl.DocumentsRequestModel.DocName }, function(newVal, oldVal) {
            if (oldVal != newVal) {
                performTableFilter();
            }
        }, true);

        $scope.$watch(function() {
            return $scope.startDate;
        }, function(newVal, oldVal) {
            if (oldVal != newVal && (oldVal != null || newVal != null)) {
                performTableFilter();
            }
        }, true);

        $scope.$watch(function() {
            return $scope.endDate;
        }, function(newVal, oldVal) {
            if (oldVal != newVal && (oldVal != null || newVal != null)) {
                performTableFilter();
            }
        }, true);

        function performTableFilter() {
            if (FilterSearchTimeout) $timeout.cancel(FilterSearchTimeout);
            if (!isAutoSearchDisabled) {
                FilterSearchTimeout = $timeout(function() {
                    searchClick();
                }, 2000);
            }
        }

        function performInstantSearch() {
            if (FilterSearchTimeout) $timeout.cancel(FilterSearchTimeout);
            searchClick();
        }

        function closeWindow(actionType) {
            angular.element($window).off("scroll");
            if ($location.search() && $location.search().protocol && $location.search().protocol === 'postmessage') {
                var message = {
                    type: 'cancel',
                    data: JSON.stringify("")
                };
                if ($window.parent)
                    $window.parent.postMessage(message, '*');
            } else {
                try {
                    closewin();
                } catch (err) {}
            }
            $scope.mc.onError = false;
        }

        function resizeWindow(dimensions) {
            if ($location.search() && $location.search().protocol && $location.search().protocol === 'postmessage') {
                var message = {
                    type: 'resize',
                    data: JSON.stringify(dimensions)
                };
                if ($window.parent)
                    $window.parent.postMessage(message, '*');
            } else {
                resizewin(dimensions.width + ';' + dimensions.height);
            }
        }

        function ScrollEvent() {
            userScrollWindow();
        }

        function registerSessionTimeOut() {
            var sessionTimoutWatch = $scope.$watch(function() { return $cookies.sessiontimeout; }, function(newVal, oldVal) {
                if ($cookies.sessiontimeout && $cookies.sessiontimeout === 401) {
                    sessionTimoutWatch();
                    $cookies.sessiontimeout = null;
                    logoutAPICall();
                } else if ($cookies.sessiontimeout) {
                    $cookies.sessiontimeout = null;
                }
            });
        }

        function logoutAPICall() {
            var stateURL = baseIMCCApiUrl + "dialogs/trash-bin";
            var parameters = "/login/oauth2/authorize?response_type=token&scope=user&state=" + stateURL + "&client_id=fbwc";

            var apiUrl = homeFactory.getLogoutAPI('');
            var logoutRequest = homeService.getData(apiUrl);
            logoutRequest.then(function(response) {
                resetAllValues();
                window.location.href = baseIMCCApiUrl + "login/terminate?return_to=" + encodeURIComponent(parameters);
            }, function(response) {
                resetAllValues();
                window.location.href = baseIMCCApiUrl + "login/terminate?return_to=" + encodeURIComponent(parameters);
            });
        }

        function resetAllValues() {
            delete $scope.mc.$storage.LoginUserId;
            delete $scope.mc.$storage.toState;
            vmTrashbinCtrl.SelectedLibrary = '';
            vmTrashbinCtrl.IsDBListHidden = false;

            $scope.mc.loginModel.UserName = '';
            $scope.mc.loginModel.Password = '';
            if (angular.isDefined($scope.mc.loginModel.UserSessionTimeOut)) {
                $interval.cancel($scope.mc.loginModel.UserSessionTimeOut);
                $scope.mc.loginModel.UserSessionTimeOut = null;
            }
            if (UserSessionTimer) {
                $timeout.cancel(UserSessionTimer);
                UserSessionTimer = null;
            }
            sessionTime = -1;
        }

        function getParams() {
			vmTrashbinCtrl.isExternalWindow= $location.search() && $location.search().protocol && $location.search().protocol === 'postmessage'  

            vmTrashbinCtrl.SelectedLibrary = '';
            var actualUserName = $location.search().userid;
            if ($scope.mc.loginModel.UserName && $scope.mc.loginModel.UserName !== '') {
                actualUserName = $scope.mc.loginModel.UserName;
            }
            $scope.mc.$storage.IsVirtualUserLogin = "redirected";
            if (!$scope.mc.$storage.maxAge)
                $scope.mc.$storage.maxAge = '14400';

            vmTrashbinCtrl.SelectedLibrary = $location.search().dbname;
            vmTrashbinCtrl.IsDBListHidden = $location.search().dbhidden;
            if (vmTrashbinCtrl.IsDBListHidden == null) {
                vmTrashbinCtrl.IsDBListHidden = false;
            }
            initialize();
        }

        function initialize() {
            showProgressDialog();
            registerSessionTimeOut();

            $(document).click(function(event) {
                if ($(event.target).parents('tr[context-menu]').length) {
                    event.preventDefault();
                } else {
                    $('.context-menu-container').remove();
                }
            });
            if ($('#mdToolBarMain').hasClass('selected')) {
                $('#mdToolBarMain.selected').removeClass('selected');
            }
            vmTrashbinCtrl.DocumentsRequestModel.DocType = '';
            vmTrashbinCtrl.TypeFilterSelectedItem = null;
            vmTrashbinCtrl.TypeFilterSearchText = '';

            angular.forEach(vmTrashbinCtrl.menuList, function(item) {
                $translate(item.Label).then(function(translatedValue) {
                    item.Label = translatedValue;
                });
            });
            getCustomerId().then(function(response) {
                var dbListPromise = getDBLibraries();
                dbListPromise.then(function(response) {
                    if (response.Status === -1) {
                        logoutAPICall();
                    } else {
                        baseV2Url = homeFactory.getApiV2BaseUrl(vmTrashbinCtrl.SelectedLibrary);
                        var userPromise = getUserDetails();
                        userPromise.then(function(response) {
                            initalizePageData();
                        });
                    }
                });
            });
        }

        function showProgressDialog(progressMessage) {
            if (!progressMessage) progressMessage = '';
            if ($('#dvProgressContent').length > 0) {
                if (progressMessage.trim().length > 0) {
                    $('#dvProgressContent').html('<span id="spanProgressContent" class="apply-progress-msg">' + progressMessage + '</span>');
                }
            } else {
                $mdDialog.show({
                    parent: angular.element(document.body),
                    template: '<md-dialog ng-cloak height="100%" style="min-width: 1px !important;"><md-dialog-content class="apply-progress-dialog">' +
                        '<div id="dvProgressContent" class="md-dialog-content-clearpadding"><md-progress-circular md-mode="indeterminate"></md-progress-circular>' +
                        (progressMessage.trim().length > 0 ? ('<span id="spanProgressContent" class="apply-progress-msg">' + progressMessage + '</span>') : '') +
                        '</div></md-dialog-content></md-dialog>'
                }).then(function() {});
            }
        }

        function getUserDetails() {
            var defer = $q.defer();
            $scope.mc.loginModel.FullName = '';

            $scope.mc.getlogDetails("Debug", 'Method:GET; Action: ViewUser ;');
            var apiUrl = baseV2Url + homeFactory.getSingleUserAPI();
            var promise = homeService.getData(apiUrl);
            promise.then(function(response) {
                if (response && response.data && response.data.data) {
                    $scope.mc.getlogDetails("Debug", 'Response:Success');

                    var loggedUserModel = homeFactory.getUserUI(response.data.data);
                    $scope.mc.loginModel.UserName = loggedUserModel.UserId;
                    $scope.mc.$storage.LoginUserId = loggedUserModel.UserId;
                    if (loggedUserModel.FullName)
                        $scope.mc.loginModel.FullName = loggedUserModel.FullName.trim();
                }
                defer.resolve($scope.mc.loginModel.UserName);
            }, function(response) {
                defer.resolve(response);
                $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
            });
            return defer.promise;
        }

        function getDBLibraries() {
            var deferred = $q.defer();
            var baseV2UrlWithoutDbName = homeFactory.getApiV2BaseUrl();
            var apiUrl = baseV2UrlWithoutDbName + homeFactory.getDBListAPI();
            $scope.mc.getlogDetails("Debug", 'Method:GET;URL:' + apiUrl);

            var promise = homeService.getData(apiUrl);
            promise.then(function(response) {
                if (response && response.data && response.data.data && response.data.data.length > 0) {
                    $scope.mc.getlogDetails("Info", 'Response:Success');

                    var promiseDB = getPrimaryDatabase();
                    promiseDB.then(function(responseDB) {
                        var tempDBModel;

                        vmTrashbinCtrl.DBList = [];
                        angular.forEach(response.data.data, function(db) {
                            tempDBModel = homeFactory.getDatabaseUI(db);
                            if (vmTrashbinCtrl.SelectedLibrary && vmTrashbinCtrl.SelectedLibrary.trim().length > 0) {
                                if (tempDBModel.DatabaseName.toUpperCase() === vmTrashbinCtrl.SelectedLibrary.toUpperCase()) {
                                    vmTrashbinCtrl.SelectedLibrary = tempDBModel.DatabaseName;
                                }
                            }
                            vmTrashbinCtrl.DBList.push(tempDBModel);
                            tempDBModel = null;
                        });
                        if (!vmTrashbinCtrl.SelectedLibrary || vmTrashbinCtrl.SelectedLibrary.trim().length === 0) {
                            if (responseDB && responseDB.Status === 0 && responseDB.PrimaryDBName) {
                                vmTrashbinCtrl.SelectedLibrary = responseDB.PrimaryDBName;
                            } else if (vmTrashbinCtrl.DBList.length > 0) {
                                vmTrashbinCtrl.SelectedLibrary = vmTrashbinCtrl.DBList[0].DatabaseName;
                            }
                        }
                        deferred.resolve({ Status: 0 });
                    });

                    // var tempDBModel;
                    // vmTrashbinCtrl.DBList = [];
                    // angular.forEach(response.data.data, function(db) {
                    //     tempDBModel = homeFactory.getDatabaseUI(db);
                    //     if (vmTrashbinCtrl.SelectedLibrary && vmTrashbinCtrl.SelectedLibrary.trim().length > 0) {
                    //         if (tempDBModel.DatabaseName.toUpperCase() === vmTrashbinCtrl.SelectedLibrary.toUpperCase()) {
                    //             vmTrashbinCtrl.SelectedLibrary = tempDBModel.DatabaseName;
                    //         }
                    //     }
                    //     vmTrashbinCtrl.DBList.push(tempDBModel);
                    //     tempDBModel = null;
                    // });
                    // if (!vmTrashbinCtrl.SelectedLibrary || vmTrashbinCtrl.SelectedLibrary.trim().length === 0) {
                    //     setUserDBToCombo();
                    // } else {
                    //     initalizePageData();
                    // }
                } else if (response && response.data && response.data.status === 401 || response.status === 401) {
                    $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                    deferred.resolve({ Status: -1 });
                }
            }, function(response) {
                $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                deferred.resolve({ Status: -1 });
            });
            return deferred.promise;
        }

        // function setUserDBToCombo() {
        //     var promiseDB = getPrimaryDatabase();
        //     promiseDB.then(function(responseDB) {
        //         var blnPrimaryDbFound = false;

        //         if (responseDB && responseDB.Status === 0 && responseDB.PrimaryDBName && vmTrashbinCtrl.DBList) {
        //             var tempListFilter = $filter('filter')(vmTrashbinCtrl.DBList, {
        //                 DatabaseName: responseDB.PrimaryDBName
        //             }, true);
        //             if (tempListFilter.length > 0) {
        //                 vmTrashbinCtrl.SelectedLibrary = responseDB.PrimaryDBName;
        //                 blnPrimaryDbFound = true;
        //             }
        //             tempListFilter = null;
        //         }
        //         if (!blnPrimaryDbFound && vmTrashbinCtrl.DBList && vmTrashbinCtrl.DBList.length > 0) {
        //             vmTrashbinCtrl.SelectedLibrary = vmTrashbinCtrl.DBList[0].DatabaseName;
        //         }
        //         initalizePageData();
        //     }, function(responseDB) {
        //         if (vmTrashbinCtrl.DBList && vmTrashbinCtrl.DBList.length > 0) {
        //             vmTrashbinCtrl.SelectedLibrary = vmTrashbinCtrl.DBList[0].DatabaseName;
        //         }
        //         initalizePageData();
        //     });
        // }

        function getPrimaryDatabase() {
            var deferred = $q.defer();
            var baseV2UrlWithoutDbName = homeFactory.getApiV2BaseUrl();
            var apiUrl = baseV2UrlWithoutDbName + homeFactory.getPrimaryDBNameAPI();
            $scope.mc.getlogDetails("Debug", 'Method:GET;URL:' + apiUrl);

            var promise = homeService.getData(apiUrl);
            promise.then(function(response) {
                if (response && response.data && response.data.data) {
                    $scope.mc.getlogDetails("Info", 'Response:Success');

                    if (response.data.data.databases && response.data.data.databases.length > 0) {
                        var tempListFilter = $filter('filter')(response.data.data.databases, {
                            Primary: 'Y'
                        }, true);
                        if (tempListFilter.length > 0) {
                            deferred.resolve({ Status: 0, PrimaryDBName: tempListFilter[0].id });
                        } else {
                            deferred.resolve({ Status: -1 });
                        }
                    } else {
                        deferred.resolve({ Status: -1 });
                    }
                } else {
                    deferred.resolve({ Status: -1 });
                }
            }, function(response) {
                deferred.resolve({ Status: -1 });
            });
            return deferred.promise;
        }

        function selectedDB_Change() {
            showProgressDialog();
            initalizePageData();
        }

        function initalizePageData() {
            loadDocumentOnScrollWin = false;
            if ($('#mdToolBarMain').hasClass('selected')) {
                $('#mdToolBarMain.selected').removeClass('selected');
            }
            vmTrashbinCtrl.IsShowNoDocFound = false;
            vmTrashbinCtrl.FileList = [];
            vmTrashbinCtrl.FolderPathList = [];
            vmTrashbinCtrl.SelectedDocument = null;
            vmTrashbinCtrl.DocumentsRequestModel.Pagination = homeFactory.requestModelInstance();
            vmTrashbinCtrl.DocumentsRequestModel.Cursor = '';

            baseV2Url = homeFactory.getApiV2BaseUrl(vmTrashbinCtrl.SelectedLibrary);
            getDocumentList();
        }

        function calculateDate(startDate, endDate) {
            var millisecondsPerDay = 1000 * 60 * 60 * 24;

            if (startDate != null) {
                var millisBetween = startDate.getTime() - new Date().getTime();
                var Fromdays = millisBetween / millisecondsPerDay;
            } else {
                Fromdays = 0;
            }

            if (endDate != null) {
                var millisBetween = endDate.getTime() - new Date().getTime();
                var Todays = millisBetween / millisecondsPerDay;
            } else {
                Todays = 0;
            }

            return (Math.floor(Fromdays) + ":" + Math.ceil(Todays) + "d");
        }

        function checkVersionExist() {
            vmTrashbinCtrl.versionList = [];

            var reqModel = homeFactory.requestModelInstance();
            reqModel.libraryName = vmTrashbinCtrl.SelectedLibrary;
            reqModel.limit = 50;
            reqModel.DocNum = vmTrashbinCtrl.SelectedDocument.DocumentNumber;
            var apiUrl = baseV2Url + TrashbinFactory.getVersionsAPI('GET_ALL_VERSIONS', reqModel);
            homeService.getData(apiUrl).then(function(response) {
                if (response.status == 200) {
                    if (response && response.data && response.data.data && response.data.data.length == 1) {
                        vmTrashbinCtrl.isShowVersion = false;
                        vmTrashbinCtrl.versionList = response.data.data;
                        restoreDocument();
                    } else if (response && response.data && response.data.data && response.data.data.length > 1) {
                        vmTrashbinCtrl.versionList = response.data.data;
                        vmTrashbinCtrl.isShowVersion = true;
                        vmTrashbinCtrl.IsShowRestoreMessageWindow = true;
                        vmTrashbinCtrl.IsHideDocumentListWindow = true;
                        $timeout(function() {
                            resizeWindow({ width: '650', height: '500' });
                        });

                    }
                }
            });
        }

        $scope.documentRestore = {
            versions: 2
        };
        //var retry=false;

        vmTrashbinCtrl.errorList = [];
        vmTrashbinCtrl.isFormSubmitted = false;
        vmTrashbinCtrl.completeFailure = true;

        function multipleRestoreFn(pendingList) {
            var deferedArray = [];

            angular.forEach(pendingList, function(versionItem) {
                /*if (retry) {
                    if (versionItem.version == 3) {
                        versionItem.id = "iManageNew!" + versionItem.document_number + ".3";
                    }
                }
                else {
                    if (versionItem.version != 1) {
                        versionItem.id = "35";
                    }
                }*/
                var deferedrestore = $q.defer();
                deferedArray.push(deferedrestore.promise);
                var apiUrl = baseV2Url + TrashbinFactory.getDocRestoreAPI(versionItem.id);
                $scope.mc.getlogDetails("Debug", 'Method:GET;URL:' + apiUrl);
                var requestBody = { for_user: $scope.mc.$storage.LoginUserId };
                var promise = homeService.postDataUsingBody(apiUrl, requestBody);

                promise.then(function(restoreActionResp) {
                    if (restoreActionResp.status == 200) {
                        $mdDialog.hide();
                        deferedrestore.resolve({ status: 200 });
                    } else {
                        $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(restoreActionResp));
                        vmTrashbinCtrl.RestoreErrorMessage = restoreActionResp.data.code_message;
                        var item = {
                            id: versionItem.id,
                            version: versionItem.version,
                            message: restoreActionResp.data.code_message,
                            document_number: versionItem.document_number
                        };
                        vmTrashbinCtrl.errorList.push(item);
                        deferedrestore.resolve({ status: 101 });
                    }
                });

            });
            $q.all(deferedArray).then(function(Response) {
                var successCount = $filter('filter')(Response, {
                    status: 200
                }, true);

                var errorCount = $filter('filter')(Response, {
                    status: 101
                }, true);

                if (errorCount && errorCount.length > 0 && successCount && successCount.length > 0)
                    vmTrashbinCtrl.completeFailure = false;
                else
                    vmTrashbinCtrl.completeFailure = true;

                if (errorCount && errorCount.length > 0)
                    showRestoreErrorWindow(vmTrashbinCtrl.RestoreErrorMessage);
                else
                    showRestoreSuccessWindow();

            });
        }

        function multipleRestoreDocument() {
            vmTrashbinCtrl.errorList = [];
            if ($scope.documentRestore.versions == 2) {
                restoreDocument();
            } else if ($scope.documentRestore.versions == 1) {
                vmTrashbinCtrl.isFormSubmitted = true;
                multipleRestoreFn(vmTrashbinCtrl.versionList);
            }
        }

        function restoreDocument() {
            vmTrashbinCtrl.isFormSubmitted = true;
            showProgressDialog();
            vmTrashbinCtrl.isSingleRestore = true;
            loadDocumentOnScrollWin = false;
            var apiUrl = baseV2Url + TrashbinFactory.getDocRestoreAPI(vmTrashbinCtrl.SelectedDocument.Id);
            $scope.mc.getlogDetails("Debug", 'Method:GET;URL:' + apiUrl);

            var requestBody = { for_user: $scope.mc.$storage.LoginUserId };
            var promise = homeService.postDataUsingBody(apiUrl, requestBody);
            promise.then(function(response) {
                if (response.status === 200) {
                    $scope.mc.getlogDetails("Info", 'Response:Success');
                    $mdDialog.hide();
                    showRestoreSuccessWindow();
                } else {
                    var errorMsg = '';
                    $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                    if (response && response.data && response.data.code_message)
                        errorMsg = response.data.code_message;
                    showRestoreErrorWindow(errorMsg);
                    vmTrashbinCtrl.completeFailure = true;
                }
            }, function(response) {
                var errorMsg = '';
                $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                if (response && response.data && response.data.code_message)
                    errorMsg = response.data.code_message;
                showRestoreErrorWindow(errorMsg);
                vmTrashbinCtrl.completeFailure = true;
            });
        }

        function retryClick() {
            vmTrashbinCtrl.IsShowRestoreSuccessMsg = undefined;
            if (vmTrashbinCtrl.isShowVersion && $scope.documentRestore.versions == 1) {
                //retry=true;
                var pendingList = angular.copy(vmTrashbinCtrl.errorList);
                vmTrashbinCtrl.errorList = [];
                multipleRestoreFn(pendingList);
            } else {
                restoreDocument();
            }
        }

        function versionChanged() {
            if ($scope.documentRestore.versions == 1 && vmTrashbinCtrl.isShowVersion && vmTrashbinCtrl.IsShowRestoreSuccessMsg == false) {
                var reqModel = homeFactory.requestModelInstance();
                reqModel.libraryName = vmTrashbinCtrl.SelectedLibrary;
                reqModel.limit = 50;
                reqModel.DocNum = vmTrashbinCtrl.SelectedDocument.DocumentNumber;
                var apiUrl = baseV2Url + TrashbinFactory.getVersionsAPI('GET_ALL_VERSIONS', reqModel);
                homeService.getData(apiUrl).then(function(response) {
                    if (response.status == 200) {
                        if (response && response.data && response.data.data && response.data.data.length == 1) {
                            vmTrashbinCtrl.isShowVersion = false;
                            vmTrashbinCtrl.errorList = response.data.data;
                        } else if (response && response.data && response.data.data && response.data.data.length > 1) {
                            vmTrashbinCtrl.errorList = response.data.data;
                            vmTrashbinCtrl.isShowVersion = true;
                        }
                    }
                });

            }
        }

        function showRestoreSuccessWindow() {
            vmTrashbinCtrl.FolderPathList = [];
            vmTrashbinCtrl.IsHideDocumentListWindow = true;
            vmTrashbinCtrl.IsShowRestoreMessageWindow = true;
            vmTrashbinCtrl.IsShowRestoreSuccessMsg = true;
            getLocationPath();
        }

        function getLocationPath() {
            showProgressDialog();
            var apiUrl = baseV2Url + TrashbinFactory.getDocPathAPI(vmTrashbinCtrl.SelectedDocument.Id);
            $scope.mc.getlogDetails("Debug", 'Method:GET;URL:' + apiUrl);

            var promise = homeService.getData(apiUrl);
            promise.then(function(response) {
                vmTrashbinCtrl.FolderPathList = [];
                if (response.status === 200 && response.data && response.data.data && response.data.data.length > 0) {
                    $scope.mc.getlogDetails("Info", 'Response:Success');

                    angular.forEach(response.data.data, function(doc) {
                        vmTrashbinCtrl.FolderPathList.push(doc);
                    });
                } else {
                    $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                }
                $timeout(function() {
                    resizeWindow({ width: '500', height: '600' });
                    $mdDialog.hide();
                });
            }, function(response) {
                $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                $timeout(function() {
                    resizeWindow({ width: '500', height: '600' });
                    $mdDialog.hide();
                });
            });
        }

        function showRestoreMultipleErrorWindow() {
            $timeout(function() {
                resizeWindow({ width: '650', height: '500' });
                $mdDialog.hide();
            });
        }

        function showRestoreErrorWindow(errorMsg) {
            vmTrashbinCtrl.RestoreErrorMessage = errorMsg;
            vmTrashbinCtrl.IsHideDocumentListWindow = true;
            vmTrashbinCtrl.IsShowRestoreMessageWindow = true;
            vmTrashbinCtrl.IsShowRestoreSuccessMsg = false;
            if (vmTrashbinCtrl.completeFailure == false && vmTrashbinCtrl.isShowVersion) {
                getLocationPath();
            }
            $timeout(function() {
                resizeWindow({ width: '650', height: '500' });
                $mdDialog.hide();
            });
        }

        function closeRestoreMessageWindow() {
            resizeWindow({ width: '800', height: '700' });
            vmTrashbinCtrl.IsHideDocumentListWindow = false;
            vmTrashbinCtrl.IsShowRestoreMessageWindow = false;
            if (vmTrashbinCtrl.IsShowRestoreSuccessMsg) {
                searchClick();

            } else {
                $timeout(function() {
                    loadDocumentOnScrollWin = true;
                });
            }
            vmTrashbinCtrl.IsShowRestoreSuccessMsg = undefined;
            vmTrashbinCtrl.isFormSubmitted = false;
        }

        function searchClick() {
            showProgressDialog();
            vmTrashbinCtrl.FilterCount = 0;
            if (vmTrashbinCtrl.DocumentsRequestModel.DocName && vmTrashbinCtrl.DocumentsRequestModel.DocName.length > 0)
                vmTrashbinCtrl.FilterCount++;

            if (vmTrashbinCtrl.DocumentsRequestModel.DocVersion && vmTrashbinCtrl.DocumentsRequestModel.DocVersion.length > 0)
                vmTrashbinCtrl.FilterCount++;

            if (vmTrashbinCtrl.DocumentsRequestModel.DocNum && vmTrashbinCtrl.DocumentsRequestModel.DocNum.length > 0)
                vmTrashbinCtrl.FilterCount++;

            if (vmTrashbinCtrl.DocumentsRequestModel.DocType && vmTrashbinCtrl.DocumentsRequestModel.DocType.length > 0)
                vmTrashbinCtrl.FilterCount++;

            if (vmTrashbinCtrl.DocumentsRequestModel.DeleteDate && vmTrashbinCtrl.DocumentsRequestModel.DeleteDate.length > 0)
                vmTrashbinCtrl.FilterCount++;

            initalizePageData();
        }

        function resetSearchClick() {
            vmTrashbinCtrl.DocumentsRequestModel.DocNum = '';
            vmTrashbinCtrl.DocumentsRequestModel.DocVersion = '';
            vmTrashbinCtrl.DocumentsRequestModel.DocName = '';
            vmTrashbinCtrl.DocumentsRequestModel.DocType = '';
            $scope.startDate = $scope.endDate = null;
            vmTrashbinCtrl.DocumentsRequestModel.DeleteDate = '';
        }

        function userScrollWindow() {
            if (loadDocumentOnScrollWin === false || vmTrashbinCtrl.DocumentsRequestModel.Cursor.trim().length === 0) return;

            //var scrollMaxY = getScrollMaxY();
            //var scrollHeight = (($(this).scrollTop() + $(this).innerHeight()) / scrollMaxY) * 100.0;

            //if (scrollHeight >= 75) {
            loadDocumentOnScrollWin = false;
            showProgressDialog();
            getDocumentList();
            //}
        }

        function getScrollMaxY() {
            var innerh;
            var yWithScroll;

            if (window.innerHeight) {
                innerh = window.innerHeight;
            } else {
                innerh = document.body.clientHeight;
            }
            if (window.innerHeight && window.scrollMaxY) {
                // Firefox
                yWithScroll = window.innerHeight + window.scrollMaxY;
            } else if (document.body.scrollHeight > document.body.offsetHeight) {
                // all but Explorer Mac
                yWithScroll = document.body.scrollHeight;
            } else {
                // works in Explorer 6 Strict, Mozilla (not FF) and Safari
                yWithScroll = document.body.offsetHeight;
            }
            return (yWithScroll - innerh);
        }

        function getDocumentList() {
            if ($scope.startDate != null || $scope.endDate != null)
                vmTrashbinCtrl.DocumentsRequestModel.DeleteDate = calculateDate($scope.startDate, $scope.endDate);

            vmTrashbinCtrl.DocumentsRequestModel.Pagination.libraryName = vmTrashbinCtrl.SelectedLibrary;

            var apiUrl = baseV2Url + TrashbinFactory.getDocumentSearchAPIUrl(vmTrashbinCtrl.DocumentsRequestModel);
            $scope.mc.getlogDetails("Debug", 'Method:GET;URL' + JSON.stringify(apiUrl));

            var promise = homeService.getData(apiUrl);
            promise.then(function(response) {
                $scope.mc.getlogDetails("Info", 'Response:Success');

                if (response.status === 200 && response.data && response.data.data) {
                    if (response.data.cursor != null) {
                        vmTrashbinCtrl.DocumentsRequestModel.Cursor = response.data.cursor;
                    } else {
                        vmTrashbinCtrl.DocumentsRequestModel.Cursor = '';
                    }
                    angular.forEach(response.data.data, function(doc) {
                        vmTrashbinCtrl.FileList.push(TrashbinFactory.getDocumentUIModel(doc));
                    });
                    vmTrashbinCtrl.IsShowNoDocFound = vmTrashbinCtrl.FileList.length === 0;
                    $timeout(function() {
                        loadDocumentOnScrollWin = true;
                        $mdDialog.hide();
                    });
                } else {
                    $mdDialog.hide();
                    $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                    if (response.data && response.data.code_message && response.data.code_message.trim().length > 0) {
                        $mdDialog.show($mdDialog.alert()
                            .parent(angular.element(document.body))
                            .clickOutsideToClose(true)
                            .title('Warning!')
                            .textContent(response.data.code_message)
                            .ariaLabel('')
                            .ok('OK'));
                    }
                    loadDocumentOnScrollWin = true;
                }
            }, function(response) {
                $timeout(function() {
                    loadDocumentOnScrollWin = true;
                    $mdDialog.hide();
                });
                $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
            });
        }

        function expandPath(paths) {
            if (paths && paths.isExpanded) {
                paths.isExpanded = !paths.isExpanded;
            } else {
                paths['isExpanded'] = true;
            }
        }

        function getCurrentDateTime() {
            var dateTimeValue = new Date().toString();
            return TrashbinFactory.getFormatedDateTime(dateTimeValue);
        }

        function OpenDBList() {
            $('#db-select').click();
        }

        function openDeleteDocWindow() {
            loadDocumentOnScrollWin = false;
            resizeWindow({ width: '600', height: '280' });

            vmTrashbinCtrl.IsShowDeleteDocWindow = true;
            vmTrashbinCtrl.IsHideDocumentListWindow = true;
            vmTrashbinCtrl.IsShowDeleteDocSuccessMsg = false;
            vmTrashbinCtrl.IsShowDeleteDocErrorMsg = false;
            vmTrashbinCtrl.DeleteErrorMessage = '';
        }

        function closeDeleteDocWindow() {
            vmTrashbinCtrl.IsHideDocumentListWindow = false;
            vmTrashbinCtrl.IsShowDeleteDocWindow = false;
            resizeWindow({ width: '800', height: '700' });
            vmTrashbinCtrl.DeleteErrorMessage = '';
            if (vmTrashbinCtrl.IsShowDeleteDocSuccessMsg) {
                searchClick();
            } else {
                $timeout(function() {
                    loadDocumentOnScrollWin = true;
                });
            }
        }

        function deleteSelectedDoc() {
            showProgressDialog();

            var apiUrl = baseV2Url + TrashbinFactory.getDocDeleteAPI(vmTrashbinCtrl.SelectedDocument.Id);
            $scope.mc.getlogDetails("Debug", 'Method:GET;URL:' + apiUrl);

            var promise = homeService.deleteData(apiUrl);
            promise.then(function(response) {

                resizeWindow({ width: '650', height: '350' });
                if (response.status === 200) {
                    $scope.mc.getlogDetails("Info", 'Response:Success');
                    vmTrashbinCtrl.IsShowDeleteDocSuccessMsg = true;
                    $mdDialog.hide();
                } else {
                    var errorMsg = '';
                    $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                    if (response && response.data && response.data.code_message)
                        errorMsg = response.data.code_message;
                    else if (response && response.statusText)
                        errorMsg = response.statusText;

                    $mdDialog.hide();
                    vmTrashbinCtrl.DeleteErrorMessage = errorMsg;
                    vmTrashbinCtrl.IsShowDeleteDocErrorMsg = true;
                }
            }, function(response) {
                var errorMsg = '';
                $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                if (response && response.data && response.data.code_message)
                    errorMsg = response.data.code_message;
                else if (response && response.statusText)
                    errorMsg = response.statusText;

                $mdDialog.hide();
                vmTrashbinCtrl.DeleteErrorMessage = errorMsg;
                vmTrashbinCtrl.IsShowDeleteDocErrorMsg = true;
            });
        }

        function typeQuerySearch() {
            var deffered = $q.defer();
            var typeListRequestModel = homeFactory.requestModelInstance();
            typeListRequestModel.pagenumber = 1;
            typeListRequestModel.searchText = vmTrashbinCtrl.TypeFilterSearchText;

            var searchAPIUrl = baseV2Url + TrashbinFactory.getTypeSearchAPI(typeListRequestModel);
            $scope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(searchAPIUrl));
            var typeDbRequest = homeService.getData(searchAPIUrl);

            typeDbRequest.then(function(response) {
                var typeList = [];
                if (response.status === 200) {
                    $scope.mc.getlogDetails("Info", "Document types successfully fetched.");
                    angular.forEach(response.data.data, function(typeItem) {
                        typeList.push(TrashbinFactory.getTypeUIModel(typeItem));
                    });
                } else {
                    $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                }
                deffered.resolve(typeList);
            }, function(response) {
                $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                deffered.resolve([]);
            });
            return deffered.promise;
        }

        function typeFilter_Change() {
            vmTrashbinCtrl.DocumentsRequestModel.DocType = '';
            if (vmTrashbinCtrl.TypeFilterSelectedItem != null) {
                vmTrashbinCtrl.DocumentsRequestModel.DocType = vmTrashbinCtrl.TypeFilterSelectedItem.TypeId;
                performInstantSearch();
            }
        }

        function getCustomerId() {
            var deferred = $q.defer();
            var apiUrl;

            var baseUrlWithoutAPIV2 = homeFactory.getApiV2BaseUrl('', true, true);
            if (baseUrlWithoutAPIV2.indexOf('imcc/') != -1) {
                apiUrl = baseUrlWithoutAPIV2 + TrashbinFactory.getInitDataAPI();
            } else {
                apiUrl = baseUrlWithoutAPIV2 + TrashbinFactory.getStartupInitDataAPI();
            }

            var promise = homeService.getData(apiUrl);
            promise.then(function(response) {
                customerName = '1'; // undefined;
                if (response.status === 200 && response.data) {
                    if (response.data.customer_id && response.data.customer_id.toString().trim().length > 0) {
                        customerName = response.data.customer_id.toString();
                    } else if (response.data.data && response.data.data.customer_id && response.data.data.customer_id.toString().trim().length > 0) {
                        customerName = response.data.data.customer_id.toString();
                    }
                }
                deferred.resolve();
            });
            return deferred.promise;
        }
		
		/*
        $scope.onFileSelect = function(trashModel) {
            var tempListFilter = $filter('filter')(SelectedDocIdListForFilter, {
                Id: trashModel.Id
            }, true);
            if (tempListFilter.length === 0) {
                SelectedDocIdListForFilter.push(angular.copy(trashModel));
            }
        };


        $scope.onFileDeselect = function(trashModel) {
            if (SelectedDocIdListForFilter.length > 0) {
                SelectedDocIdListForFilter = $.grep(SelectedDocIdListForFilter,
                    function(item, index) {
                        return item.Id != trashModel.Id;
                    });
            }
            if (SelectedDocIdListForFilter.length > 0) {
                LastAddedSelectedItemId = $.grep(LastAddedSelectedItemId,
                    function(item, index) {
                        return item.Id != trashModel.Id;
                    });
            }
        };

        function deletePermanently() {
            if (vmTrashbinCtrl.selected.length === 0 && vmTrashbinCtrl.FileList.length > 0) {
                vmTrashbinCtrl.isDeleteAll = true;
                if ($localStorage['purgeAllConfirmShow'] === true) {
                    DeleteAllDocs();
                } else {
                    vmTrashbinCtrl.IsShowPurgeConfirm = true;
                    vmTrashbinCtrl.IsHideDocumentListWindow = true;
                }

            } else {
                if ($localStorage['purgeConfirmShow'] === true) {
                    DeleteSelectedDocs();
                } else {
                    vmTrashbinCtrl.IsShowPurgeConfirm = true;
                    vmTrashbinCtrl.IsHideDocumentListWindow = true;
                }
            }


        }

        function ClosePurgeConfirm() {
            vmTrashbinCtrl.IsShowPurgeConfirm = false;
            vmTrashbinCtrl.IsHideDocumentListWindow = false;
            vmTrashbinCtrl.isDeleteAll = false;
        }

        function DeleteSelectedDocs() {
            vmTrashbinCtrl.IsShowPurgeConfirm = false;
            vmTrashbinCtrl.IsHideDocumentListWindow = false;
            vmTrashbinCtrl.IsShowPurgeDialog = true;

            vmTrashbinCtrl.purgePercentage = 0;
            if (vmTrashbinCtrl.DontShowPurgeConfirm === true)
                $localStorage['purgeConfirmShow'] = true;
            vmTrashbinCtrl.isPurgeCancel = false;

            vmTrashbinCtrl.purgeSelected = angular.copy(vmTrashbinCtrl.selected);
            var purgeIndex = 0;
            currentPurge = [];
            currentPurge.successCount = 0;
            currentPurge.count = vmTrashbinCtrl.purgeSelected.length;
            currentPurge.percentage = 0;
            currentPurge.status = "purging";
            currentPurge.code_message = "";
            currentPurge.isCancel = false;
            currentPurge.isErrorFoundInDeleteDoc = false;
            currentPurge.selected = angular.copy(vmTrashbinCtrl.purgeSelected);
            vmTrashbinCtrl.multiPurge.push(currentPurge);
            vmTrashbinCtrl.isPurging = true;

            if (vmTrashbinCtrl.multiPurge.length > 0)
                purgeIndex = vmTrashbinCtrl.multiPurge.length - 1;
            deleteDoc(0, vmTrashbinCtrl.multiPurge[purgeIndex]).then(function(purge) {
                vmTrashbinCtrl.IsShowNoDocFound = vmTrashbinCtrl.FileList.length === 0;
                vmTrashbinCtrl.isPurging = false;
                if (purge.isCancel == true && vmTrashbinCtrl.isPurgeCancel == true) {
                    purge.status = "canceled";
                } else {
                    if (purge.isErrorFoundInDeleteDoc) {
                        purge.status = "failed";
                    } else {
                        purge.status = "completed";
                    }
                    vmTrashbinCtrl.DocumentsRequestModel.Pagination.pageLength = 20;
                    getDocumentList();
                }

            });
        }

        function DeleteAllDocs() {
            vmTrashbinCtrl.IsShowPurgeConfirm = false;
            vmTrashbinCtrl.IsHideDocumentListWindow = false;
            vmTrashbinCtrl.IsShowPurgeDialog = true;
            if (vmTrashbinCtrl.DontShowPurgeAllConfirm === true)
                $localStorage['purgeAllConfirmShow'] = true;
            deleteallindex = 0;
            vmTrashbinCtrl.isPurgeCancel = false;
            vmTrashbinCtrl.isPurging = true;
            vmTrashbinCtrl.DocumentsRequestModel.Pagination.pageLength = 20;
            currentPurge = [];
            currentPurge.successCount = 0;
            currentPurge.count = vmTrashbinCtrl.FileList.length;
            currentPurge.percentage = 0;
            currentPurge.status = "purging";
            currentPurge.code_message = "";
            currentPurge.isCancel = false;
            currentPurge.isErrorFoundInDeleteDoc = false;
            currentPurge.selected = angular.copy(vmTrashbinCtrl.FileList);
            vmTrashbinCtrl.multiPurge.push(currentPurge);
            getAllDocsDelete();

        }


        function gelAlldocs(multiPurgeIndex) {
            if (reloadDocs == false) {
                getDocumentList().then(function(response) {
                    if (response && response.length > 0) {
                        angular.forEach(response, function(docItem) {
                            vmTrashbinCtrl.multiPurge[multiPurgeIndex].selected.push(TrashbinFactory.getDocumentUIModel(docItem));
                        });
                        gelAlldocs(multiPurgeIndex);
                    } else {
                        $timeout(function() {
                            reloadDocs = true;
                        });

                    }
                });
            }
        }

        function getAllDocsDelete() {
            if (vmTrashbinCtrl.isPurgeCancel === true) {
                vmTrashbinCtrl.isDeleteAll = false;
                vmTrashbinCtrl.isPurging = false;
                return;
            }
            if (vmTrashbinCtrl.multiPurge.length > 0)
                deleteallindex = vmTrashbinCtrl.multiPurge.length - 1;
            gelAlldocs(deleteallindex);
            deleteDoc(0, vmTrashbinCtrl.multiPurge[deleteallindex]).then(function(purge) {
                vmTrashbinCtrl.IsShowNoDocFound = vmTrashbinCtrl.FileList.length === 0;
                if (purge.isCancel == true || vmTrashbinCtrl.isPurgeCancel == true) {
                    purge.status = "canceled";
                    vmTrashbinCtrl.isDeleteAll = false;
                    vmTrashbinCtrl.isPurging = false;
                } else {
                    vmTrashbinCtrl.isPurging = false;
                    if (purge.isErrorFoundInDeleteDoc) {
                        purge.status = "failed";
                        vmTrashbinCtrl.isDeleteAll = false;
                    } else {
                        purge.status = "completed";
                    }
                }
            });

        }

        function deleteDoc(doc_current_index, currentPurge) {
            var deferred = $q.defer();
            var apiUrl = baseV2Url + TrashbinFactory.getDocDeleteAPI(currentPurge.selected[doc_current_index].Id);

            if (vmTrashbinCtrl.isPurgeCancel === true || currentPurge.isCancel) {
                deferred.resolve(currentPurge);
                return deferred.promise;
            }
            var promise = homeService.deleteData(apiUrl);
            promise.then(function(response) {
                if (response.status !== 200) {
                    $scope.mc.getlogDetails("Error", 'Method:Delete;URL:' + JSON.stringify(apiUrl));
                    currentPurge.isErrorFoundInDeleteDoc = true;
                    currentPurge.code_message = response.data.code_message;
                } else {
                    vmTrashbinCtrl.FileList.shift(currentPurge.selected[doc_current_index]);
                    vmTrashbinCtrl.selected.shift(currentPurge.selected[doc_current_index]);
                    currentPurge.successCount = currentPurge.successCount + 1;
                    currentPurge.percentage = parseInt(((currentPurge.successCount) / currentPurge.selected.length) * 100);

                    $scope.mc.getlogDetails("Info", currentPurge.selected[doc_current_index].Id + ' successfully deleted.');
                }

                doc_current_index += 1;
                if ((vmTrashbinCtrl.isPurgeCancel === false || currentPurge.isCancel === false) && doc_current_index < currentPurge.selected.length) {
                    var nextPromise = deleteDoc(doc_current_index, currentPurge);
                    nextPromise.then(function(responseNext) {
                        deferred.resolve(currentPurge);
                    });
                } else {
                    deferred.resolve(currentPurge);
                }
            });

            return deferred.promise;
        }

        function CancelJobs() {
            vmTrashbinCtrl.isPurgeCancel = true;
        }

        function CancelPurgeItem(PurgeItem) {
            PurgeItem.isCancel = true;
        }

        window.onbeforeunload = function(event) {
            if (vmTrashbinCtrl.isPurging === true) {
                return 'Do you want to reload this page???';
            } else {
                return;
            }
        };*/

           function ShowTimeLine(){
                vmTrashbinCtrl.journalUrl ="";
                vmTrashbinCtrl.journalModel =undefined;
        if(vmTrashbinCtrl.MDocNum  && vmTrashbinCtrl.MDocNum !="" && vmTrashbinCtrl.MDocVersion  && vmTrashbinCtrl.MDocVersion !="" ){      
      getDocument().then(function(response){

          if(response.documentObject){
          var webLocation = window.location.href.split('dialogs/');
        vmTrashbinCtrl.journalUrl = webLocation[0] + 'dialogs/document-timeline/?id='+response.documentObject.Id;
        vmTrashbinCtrl.journalModel =response.documentObject;
          }else{
            vmTrashbinCtrl.ErrorMsg=response.Error;
          }
          $mdDialog.hide();
      });
        }else{
            vmTrashbinCtrl.ErrorMsg="trashBin.docvermandatory"
        }
        }

        function getDocument() {
        var defered=$q.defer();

        var DocumentsRequestModel={};
       
       
 
        DocumentsRequestModel.DocumentNumber = vmTrashbinCtrl.MDocNum;
        DocumentsRequestModel.Version = vmTrashbinCtrl.MDocVersion;
        
              
        showProgressDialog();
        var searchAPIUrl =  baseV2Url  + TrashbinFactory.getSearchAPIUrl(DocumentsRequestModel);
        $scope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(searchAPIUrl));

        var DocumentsRequest = homeService.getData(searchAPIUrl);
        DocumentsRequest.then(function(response) {
            
            if (response && response.status === 200 && response.data && response.data.data && response.data.data.length == 1) {
                $scope.mc.getlogDetails("Info", "Documents fetched."); 
                 
                defered.resolve({documentObject:TrashbinFactory.getDocumentUIModel(response.data.data[0])});
                    
                 
                
              
            } else if(response.data.data.length >1) {
                 
                  defered.resolve({documentObject:undefined,Error:"trashBin.refineSearch"});
            }else  {
                 
                  defered.resolve({documentObject:undefined,Error:"trashBin.invalidSearch"});
            }
            
        });

        return defered.promise;
     
    }

    function onTabChanges(currentTab){
        vmTrashbinCtrl.CurrentTab = currentTab;
    }


    }
})();