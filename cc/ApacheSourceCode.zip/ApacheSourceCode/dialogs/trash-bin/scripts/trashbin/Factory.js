(function() {
    'use strict';


    angular.module('iManage.Trashbin').factory('TrashbinFactory', trashbinFactory);
    trashbinFactory.$inject = ['API_URL_Trashbin', 'CONST_DOCUMENTS_FILEDS', 'CONST_TYPE_FILEDS'];

    function trashbinFactory(API_URL_Trashbin, CONST_DOCUMENTS_FILEDS, CONST_TYPE_FILEDS) {
        var documentUIModel = {};
        var typeUIModel = {};

        //Initialize Model objects
        (function() {

            documentUIModel = {
                Database: '',
                DocumentNumber: '',
                Id: '',
                Type: '',
                Version: '',
                WsType: '',
                Name: '',
                DeletedDate: '',
                DeletedBy: ''
            };

            typeUIModel = {
                TypeId: '',
                Description: ''
            };
        })();

        var returnObject = {
            getDocRestoreAPI: returnDocRestoreAPI,
            getDocumentSearchAPIUrl: returnDocumentAPIUrl,
            getDocumentUIModel: returnDocumentUIModel,
            getDocPathAPI: returnDocPathAPI,
            getDocDeleteAPI: returnDocDeleteAPI,
            getFormatedDateTime: returnDateTime,
            getVersionsAPI: returnVersionsAPI,
            getTypeSearchAPI: returnTypeSearchAPI,
            getTypeUIModel: returnTypeUIModel,
            getInitDataAPI: returnInitDataAPI,
			getStartupInitDataAPI: returnStartupInitDataAPI,
            getSearchAPIUrl:returnSearchAPIUrl
        };
        return returnObject;

        function returnInitDataAPI() {
            var apiUrl = API_URL_Trashbin.GET_INIT_DATA;
            return apiUrl;
        }
		
		function returnStartupInitDataAPI() {
            var apiUrl = API_URL_Trashbin.GET_STARTUP_INIT_DATA;
            return apiUrl;
        }

        function returnVersionsAPI(apiFor, requestmodel) {
            var apiUrl = API_URL_Trashbin[apiFor];
            apiUrl += '?limit=' + requestmodel.limit.toString() +
                '&document_number=' + requestmodel.DocNum + '&document_version=>0';

            return apiUrl;
        }

        function returnDocRestoreAPI(docId) {
            var apiUrl = API_URL_Trashbin.RESTORE_DOC;
            apiUrl = apiUrl.replace('<doc_id>', docId);
            return apiUrl;
        }

        function returnDocDeleteAPI(docId) {
            var apiUrl = API_URL_Trashbin.DELETE_DOCUMENT;
            apiUrl = apiUrl.replace('<doc_id>', docId);
            return apiUrl;
        }

        function returnDocumentAPIUrl(requestModel) {
            var apiUrl = API_URL_Trashbin.SEARCH_DOCUMENT;
            apiUrl += '?limit=' + requestModel.Pagination.pageLength.toString();
            if (requestModel.Cursor && requestModel.Cursor.trim().length > 0) {
                apiUrl += '&cursor=' + requestModel.Cursor;
            }
            if (requestModel.DocNum && requestModel.DocNum.trim().length > 0) {
                apiUrl += '&document_number=' + requestModel.DocNum;
            }
            if (requestModel.DocVersion && requestModel.DocVersion.trim().length > 0) {
                apiUrl += '&document_version=' + requestModel.DocVersion;
            } else {
                apiUrl += '&latest=false';
            }
            if (requestModel.DocName && requestModel.DocName.trim().length > 0) {
                apiUrl += '&name=*' + requestModel.DocName + '*';
            }
            if (requestModel.DocType && requestModel.DocType.trim().length > 0) {
                apiUrl += '&type=' + requestModel.DocType;
                if (requestModel.DocType == 'MIME,NOTES') {
                    apiUrl += '&class=EMAIL';
                }
            }
            if (requestModel.DeleteDate && requestModel.DeleteDate.trim().length > 0) {
                apiUrl += '&edit_date=' + requestModel.DeleteDate;
            }
            return apiUrl;
        }

         function returnSearchAPIUrl(requestModel) {
        
        var apiURL = API_URL_Trashbin.SEARCH_JNDOCUMENTS;
        apiURL += '?document_number=' + requestModel.DocumentNumber;
        apiURL += '&document_version=' + requestModel.Version;
       
        return apiURL;
         }

        function returnDocPathAPI(docId) {
            var apiUrl = API_URL_Trashbin.FOLDER_PATH;
            apiUrl = apiUrl.replace('<doc_id>', docId);
            return apiUrl;
        }

        function returnTypeSearchAPI(requestModel) {
            var apiURL = API_URL_Trashbin.SEARCH_TYPES;
            var offset = (requestModel.pagenumber - 1) * requestModel.pageLength;

            apiURL += '?offset=' + offset + '&limit=' + requestModel.pageLength + '&total=false';

            if (requestModel.searchText != null && requestModel.searchText != '')
                apiURL += '&query=' + requestModel.searchText;

            return apiURL;
        }

        function returnDocumentUIModel(docAPIModel) {
            var docModel = angular.copy(documentUIModel);
            docModel.Database = docAPIModel[CONST_DOCUMENTS_FILEDS.Database];
            docModel.DocumentNumber = docAPIModel[CONST_DOCUMENTS_FILEDS.DocumentNumber];
            docModel.DeletedDate = docAPIModel[CONST_DOCUMENTS_FILEDS.EditProfileDate];
            docModel.Id = docAPIModel[CONST_DOCUMENTS_FILEDS.Id];
            docModel.SubClass = docAPIModel[CONST_DOCUMENTS_FILEDS.WsType];
            docModel.Type = docAPIModel[CONST_DOCUMENTS_FILEDS.Type];
            docModel.Version = docAPIModel[CONST_DOCUMENTS_FILEDS.Version];
            docModel.DeletedBy = docAPIModel[CONST_DOCUMENTS_FILEDS.LastUser];
            docModel.LastUser = docAPIModel[CONST_DOCUMENTS_FILEDS.LastUser];
            docModel.CreateDate = docAPIModel[CONST_DOCUMENTS_FILEDS.CreateDate];
            docModel.Name = docAPIModel[CONST_DOCUMENTS_FILEDS.Name];
            return docModel;
        }

        function returnDateTime(dateString) {
            var dateObj = new Date(dateString);
            if (dateObj === 'Invalid Date') {
                return '';
            }
            return dateObj.toLocaleString();
        }

        function returnTypeUIModel(typeAPIModel) {
            var typeModel = angular.copy(typeUIModel);
            typeModel.TypeId = typeAPIModel[CONST_TYPE_FILEDS.Id];
            typeModel.Description = typeAPIModel[CONST_TYPE_FILEDS.Description];
            return typeModel;
        }
    }

})();