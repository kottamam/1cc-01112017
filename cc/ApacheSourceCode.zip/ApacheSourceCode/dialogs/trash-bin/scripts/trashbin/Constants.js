(function() {
    'use strict';


    angular.module('iManage.Trashbin').constant('API_URL_Trashbin', {
        RESTORE_DOC: 'trash-bin/documents/<doc_id>/restore',
        FOLDER_PATH: 'documents/<doc_id>/path',
        SEARCH_DOCUMENT: 'trash-bin/user/documents',
        DELETE_DOCUMENT: 'trash-bin/documents/<doc_id>',
        GET_ALL_VERSIONS: 'trash-bin/user/documents',
        SEARCH_TYPES: 'types/search',
        GET_INIT_DATA: 'init-data',
		GET_STARTUP_INIT_DATA: 'startup/init-data',
        SEARCH_JNDOCUMENTS: 'documents/search/paginated/database',
    });

    angular.module('iManage.Trashbin').constant('CONST_DOCUMENTS_FILEDS', {
        Database: 'database',
        DocumentNumber: 'document_number',
        EditProfileDate: 'edit_profile_date',
        CreateDate: 'create_date',
        Id: 'id',
        LastUser: 'last_user',
        Type: 'type',
        Version: 'version',
        WsType: 'wstype',
        Name: 'name'
    });

    angular.module('iManage.Trashbin').constant('CONST_TYPE_FILEDS', {
        Id: 'id',
        Description: 'description'
    });

})();