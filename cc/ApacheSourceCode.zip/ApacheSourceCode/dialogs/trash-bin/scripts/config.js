require.config({
    paths: {
        jquery: "../lib/vendor/jquery/dist/jquery.min",
        angular: "../lib/vendor/angular/angular.min",
        libraryConfig: '../lib/config',
        iManageGeneralConfig: 'common/config',
        pluggableViews: "pluggableViewsProvider",
        iManageTrashBinConfig: 'trashbin/config'
    },
    shim: {
        angular: { exports: 'angular', deps: ['jquery'] },
        jquery: { exports: '$' },
        iManageGeneralConfig: { deps: ["libraryConfig"] },
        pluggableViews: { deps: ["iManageGeneralConfig", "common/imModule"] },
        iManageTrashBinConfig: { deps: ["iManageGeneralConfig"] }
    },
    urlArgs: "bust=" + (new Date()).getTime(),
    waitSeconds: 0
});

require([
    'angular',
    'libraryConfig',
    'iManageGeneralConfig',
    'pluggableViews',
    'iManageTrashBinConfig'
], function(angular) {
    angular.element(document).ready(function() {
        angular.bootstrap(document, ['iManage.Trashbin']);
    });
});