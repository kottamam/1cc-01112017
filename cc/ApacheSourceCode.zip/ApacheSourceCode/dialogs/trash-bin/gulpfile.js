﻿/*
This file in the main entry point for defining Gulp tasks and using Gulp plugins.
Click here to learn more. http://go.microsoft.com/fwlink/?LinkId=518007
*/
var version = '1.2';
var gulp        = require('gulp');
var gulp_inject = require('gulp-inject');
var del 		= require('del');
var runSequence = require('run-sequence');
var jshint 		= require('gulp-jshint');
var gutil 		= require('gulp-util');
var debug 	    = require('gulp-debug');
var gulpif 		= require('gulp-if');
var flatmap     = require('gulp-flatmap');
var flatten     = require('gulp-flatten');
var uglify      = require('gulp-uglify');
var cleanCSS    = require('gulp-clean-css');
var minifyJson      = require('gulp-jsonminify');


// gulp configuration file path
var files = require('./gulp/gulp.config.js');
var minFramework = true;

/**
 * @description
 *
 * default task (runs the build task)
 *
 */
gulp.task('default', function(callback) {
    gutil.log(gutil.colors.magenta('TASK: default'));
    runSequence('build', callback);
});

/**
 * @description
 *
 * Runs various tasks in sequence to create a working web root (build)
 *
 */
gulp.task('build', function(callback){
    gutil.log(gutil.colors.magenta('TASK: build'));
    runSequence('clean',
        'copy-build',
        callback);
});

/**
 * @description
 *
 * Cleans build folder
 *
 */
gulp.task('clean', function(){
    return del([files.build_dir], {force: true});
});

/**
 * @description
 *
 * Assembles files and output from app,assets, and lib folders to produce a working web root (build)
 *'copy-flexible-assets', 'copy-core-flexible-html', 'copy-flexible-assets-styles', 'copy-flexible-app-html', 'copy-flexible-vendor-js', 'copy-flexible-lib-config', 'copy-flexible-app-js', 'copy-flexible-app-styles', 'copy-flexible-scripts', 'copy-core-adhoc-ws-html', 'copy-adhoc-ws-assets', 'copy-adhoc-ws-assets-styles', 'copy-adhoc-ws-app-js', 'copy-adhoc-ws-app-styles', 'copy-adhoc-ws-app-html', 'copy-adhoc-ws-vendor-js', 'copy-adhoc-ws-scripts', 'copy-adhoc-ws-lib-config',
 *
 */
gulp.task('copy-build',function(callback) {
    runSequence('copy-core-html', 'copy-app-js', 'copy-app-html', 'copy-script-app-styles', 'copy-script-app-assets', 'copy-app-assets', 'copy-app-styles', 'copy-vendor-js', 'copy-scripts', 'copy-lib-config', 'copy-fonts', 'copy-images', 'copy-non-css', callback);
    gutil.log(gutil.colors.magenta('TASK: copy-build'))
});

/**
 * @description
 *
 * Copies application html files from project directory to build/<folder>
 *
 */
gulp.task('copy-core-html', function(){
    gutil.log(gutil.colors.magenta('TASK: copy-core-html'));
    return gulp.src(files.core_files_html)
        .pipe(flatmap(function(stream, file){
            return stream
                .pipe(gulpif(files.debug,debug({title:'source'})))
                .pipe(gulp.dest(files.build_dir))
                .pipe(gulpif(files.debug,debug({title:'target'})));
        }));

});

/**
 * @description
 *
 * Copies application javascript from plugin_root/<folder> to build/<folder>
 *
 */
gulp.task('copy-app-js', function(){
    gutil.log(gutil.colors.magenta('TASK: copy-app-js'));
    return gulp.src(files.app_files.app_js)
        .pipe(flatmap(function(stream, file){
            return stream
                .pipe(gulpif(files.debug, debug({ title: 'source' })))
                .pipe(gulpif(files.releaseBuild, uglify()))
                .pipe(gulp.dest(files.build_dir + '/scripts/'))
                .pipe(gulpif(files.debug,debug({title:'target'})));
        }));
});

/**
 * @description
 *
 * Copies core application html files from plugin_root/<folder> to build/<folder>
 *
 */
gulp.task('copy-app-html', function () {
    gutil.log(gutil.colors.magenta('TASK: copy-app-html'));
    return gulp.src(files.app_files.app_html)
        .pipe(flatmap(function (stream, file) {
            return stream
                .pipe(gulpif(files.debug, debug({ title: 'source' })))
                .pipe(gulp.dest(files.build_dir + '/scripts/'))
                .pipe(gulpif(files.debug, debug({ title: 'target' })));
        }));

});

/**
 * @description
 *
 * Copies application styles files from plugin_root/<folder> to build/<folder>
 *
 */
gulp.task('copy-script-app-styles', function(){
    gutil.log(gutil.colors.magenta('TASK: copy-script-app-styles'));
    return gulp.src(files.app_files.app_script_styles)
        .pipe(flatmap(function(stream, file){
            return stream
                .pipe(gulpif(files.debug, debug({ title: 'source' })))
                .pipe(gulpif(files.releaseBuild, cleanCSS()))
                .pipe(gulp.dest(files.build_dir + '/scripts/'))
                .pipe(gulpif(files.debug, debug({ title: 'target' })));
        }));
});

/**
 * @description
 *
 * Copies application assets files from plugin_root/<folder> to build/<folder>
 *
 */
gulp.task('copy-script-app-assets', function () {
    gutil.log(gutil.colors.magenta('TASK: copy-script-app-assets'));
    return gulp.src(files.app_files.app_scripts_asset)
        .pipe(flatmap(function (stream, file) {
            return stream
                .pipe(gulpif(files.debug, debug({ title: 'source' })))
                .pipe(gulp.dest(files.build_dir + '/scripts/'))
                .pipe(gulpif(files.debug, debug({ title: 'target' })));
        }));
});

/**
 * @description
 *
 * Copies application assets files from plugin_root/<folder> to build/<folder>
 *
 */
gulp.task('copy-app-assets', function () {
    gutil.log(gutil.colors.magenta('TASK: copy-app-assets'));
    return gulp.src(files.app_files.app_assets)
        .pipe(flatmap(function (stream, file) {
            return stream
                .pipe(gulpif(files.debug, debug({ title: 'source' })))
                .pipe(gulp.dest(files.build_dir + '/assets/'))
                .pipe(gulpif(files.debug, debug({ title: 'target' })));
        }));
});

/**
 * @description
 *
 * Copies application styles files from plugin_root/<folder> to build/<folder>
 *
 */
gulp.task('copy-app-styles', function(){
    gutil.log(gutil.colors.magenta('TASK: copy-app-styles'));
    return gulp.src(files.app_files.app_styles)
        .pipe(flatmap(function(stream, file){
            return stream
                .pipe(gulpif(files.debug, debug({ title: 'source' })))
                .pipe(gulpif(files.releaseBuild, cleanCSS()))
                .pipe(gulp.dest(files.build_dir + '/styles/'))
                .pipe(gulpif(files.debug,debug({title:'target'})));
        }));
});

/**
 * @description
 *
 * Copies third party js files from lib/ to build/vendor
 *
 */
gulp.task('copy-vendor-js', function () {
    gutil.log(gutil.colors.magenta('TASK: copy-vendor-js'));
    return gulp.src('./lib/vendor/**/*.js')
        .pipe(flatmap(function (stream, file) {
            return stream
                .pipe(gulpif(files.debug, debug({ title: 'source' })))
                .pipe(gulp.dest(files.build_dir + '/lib/vendor/'))
                .pipe(gulpif(files.debug, debug({ title: 'target' })));
        }));
});

gulp.task('copy-scripts', function () {
    gutil.log(gutil.colors.magenta('TASK: copy-scripts'));
    return gulp.src('./lib/scripts/**/*.js')
        .pipe(flatmap(function (stream, file) {
            return stream
                .pipe(gulpif(files.debug, debug({ title: 'source' })))
                .pipe(gulpif(files.releaseBuild, uglify()))
                .pipe(gulp.dest(files.build_dir + '/lib/scripts/'))
                .pipe(gulpif(files.debug, debug({ title: 'target' })));
        }));
});

gulp.task('copy-lib-config', function () {
    gutil.log(gutil.colors.magenta('TASK: copy-lib-config'));
    return gulp.src('./lib/config.js')
        .pipe(flatmap(function (stream, file) {
            return stream
                .pipe(gulpif(files.debug, debug({ title: 'source' })))
                .pipe(gulpif(files.releaseBuild, uglify()))
                .pipe(gulp.dest(files.build_dir + '/lib/'))
                .pipe(gulpif(files.debug, debug({ title: 'target' })));
        }));
});

gulp.task('copy-fonts', function () {
    gutil.log(gutil.colors.magenta('TASK: copy-fonts'));
    return gulp.src('./styles/fonts/**/*')
        .pipe(flatmap(function (stream, file) {
            return stream
                .pipe(gulpif(files.debug, debug({ title: 'source' })))
                .pipe(gulp.dest(files.build_dir + '/styles/fonts/'))
                .pipe(gulpif(files.debug, debug({ title: 'target' })));
        }));
});

gulp.task('copy-images', function () {
    gutil.log(gutil.colors.magenta('TASK: copy-images'));
    return gulp.src('./styles/images/**/*')
        .pipe(flatmap(function (stream, file) {
            return stream
                .pipe(gulpif(files.debug, debug({ title: 'source' })))
                .pipe(gulp.dest(files.build_dir + '/styles/images/'))
                .pipe(gulpif(files.debug, debug({ title: 'target' })));
        }));
});

gulp.task('copy-non-css', function () {
    gutil.log(gutil.colors.magenta('TASK: copy-non-css'));
    return gulp.src(['./styles/css/**/*', '!./styles/css/**/*.css'])
        .pipe(flatmap(function (stream, file) {
            return stream
                .pipe(gulpif(files.debug, debug({ title: 'source' })))
                .pipe(gulp.dest(files.build_dir + '/styles/css/'))
                .pipe(gulpif(files.debug, debug({ title: 'target' })));
        }));
});