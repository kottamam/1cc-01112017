module.exports = {

    debug: true,
    releaseBuild: false,
    build_dir: 'build',
    core_files_html: './*.html',
    app_files: {
        app_js: [
            './scripts/**/*.js'
        ],
        app_html: [
            './scripts/**/*.html'
        ],
        app_script_styles: [
            './scripts/**/*.css',
            './scripts/**/*.scss'
        ],
        app_scripts_asset: [
            './scripts/**/*.jpg',
            './scripts/**/*.png',
            './scripts/**/*.gif',
            './scripts/**/*.ico',
            './scripts/**/*.svg',
            './scripts/**/*.pk',
            './scripts/**/*.ttf',
            './scripts/**/*.woff',
            './scripts/**/*.json'
        ],
        app_styles: [
            './styles/**/*.css',
            './styles/**/*.scss'
        ],
		app_assets: [
            './assets/**/*.*'
        ]
    }
}