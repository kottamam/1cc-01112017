(function() {
    'use strict';


    angular.module('iManage.WebSettings').factory('WebSettingsFactory', WebSettingsFactory);
    WebSettingsFactory.$inject = ['$q', 'API_URL_WebSettings', 'WebSettings_FILE', 'CONST_GROUPS', 'WRSU_HOME', 'CONST_LOCALE'];

    function WebSettingsFactory($q, WRSU_CONFIG, CONST_FILE, CONST_GROUPS, WRSU_HOME, CONST_LOCALE) {

        var configUIModel = {
            CategoryName: '',
            FileNumber: 0,
            FCategoryName: ''
        };

        var FileUIModel = {
            FileName: '',
            Lastupdated: '',
            TYPE: '',
            URL: '',
            CategoryName: ''
        };

        var groupUIModel = {
            ItemId: '',
            FullName: '',
            Type: '',
            IsFullNameFound: false,
            IsAdded: false
        };

        var SystemConfigUIModel = {
            HTML5PolicyPreventDataLeakage: ''
        };
		
		var localeUIModel = {
            Id: '',
            Name: ''
        };

        var returnObject = {
            configInitialValues: returnConfigInitialValues,
            fileInitialValues: returnFileInitialValues,
            getSearchAPIUrl: returngetSearchAPIUrl,
            getConfigUI: returnConfigUIModel,
            getPostCategoryAPIUrl: returngetPostCategoryAPIUrl,
            getPutCategoryAPIUrl: returngetPutCategoryAPIUrl,
            getDeleteCategoryAPIUrl: returngetDeleteCategoryAPIUrl,
            getPostFileAPIUrl: returngetPostFileAPIUrl,
            getSearchFileAPIUrl: returngetSearchFileAPIUrl,
            getConfigFileUI: returngetConfigFileUI,
            getDeleteFilesAPIUrl: returngetDeleteFilesAPIUrl,
            downloadFile: downloadFileAPIUrl,
            getPutFileAPIUrl: returngetPutFileAPIUrl,
            getRequestBodyPutFile: returngetRequestBodyPutFile,
            getGroupSearchAPI: returnGroupSearchAPI,
            getGroupUI: getGroupUIModel,
            getWebSettings: getWebSettingsURL,
            getRegistryWebSettings : getRegistryWebSettingsURL,
            geRegistryFields:geRegistryFields,
            getCaptionsAPI: returngetCaptionsAPI,
            getAPIUrl: returnAPIUrl,
            getInitDataAPI: returnInitDataAPI,
			getStartupInitDataAPI: returnStartupInitDataAPI,
			getLocaleUIModel: returnLocaleUIModel
        };
        return returnObject;

        function returnInitDataAPI() {
            var apiUrl = WRSU_CONFIG.GET_INIT_DATA;
            return apiUrl;
        }
		
		function returnStartupInitDataAPI() {
            var apiUrl = WRSU_CONFIG.GET_STARTUP_INIT_DATA;
            return apiUrl;
        }

        function returngetCaptionsAPI(requestModel) {
            var ApiUrl = WRSU_CONFIG['SEARCHCAPTIONS'];
            ApiUrl += "?offset=" + ((requestModel.pagenumber - 1) * requestModel.pageLength).toString() +
                '&limit=' + requestModel.pageLength.toString() + '&total=' + requestModel.isTotal;

            return ApiUrl;
        }

        function getWebSettingsURL() {
            var ApiUrl = WRSU_CONFIG['WEB_SETTINGS_URL'];
            return ApiUrl;
        }

        function getRegistryWebSettingsURL() {
            var ApiUrl = WRSU_CONFIG['REGISTRY_WEB_SETTINGS'];
            return ApiUrl;
        }

        function geRegistryFields(systemConfigApiModel) {
            var systemConfigModel = angular.copy(SystemConfigUIModel);
            systemConfigModel.HTML5PolicyPreventDataLeakage = systemConfigApiModel['HTML5 Policy Prevent Data Leakage'];
            systemConfigModel.fileToFolder = systemConfigApiModel['File To Folder'];
            systemConfigModel.usageTracking = systemConfigApiModel['Usage Tracking'];
            systemConfigModel.hTML5PolicyGroupAccessList = systemConfigApiModel['HTML5 Policy Group Access List'];            
            systemConfigModel.customViewMetadataField  = systemConfigApiModel['Custom View Metadata Field']; 
            systemConfigModel.localeDefault  = systemConfigApiModel['Locale Default']; 
            return systemConfigModel;
        }

        function returnConfigInitialValues() {
            return angular.copy(configUIModel);
        }

        function downloadFileAPIUrl(modelData) {
            var ApiUrl = WRSU_CONFIG['DOWNLOAD_FILE'];
            ApiUrl = ApiUrl.replace('{CAT_NAME}', modelData.Category);
            ApiUrl = ApiUrl.replace('{FILE_NAME}', modelData.File);

            return ApiUrl;
        }

        function returnFileInitialValues() {
            return angular.copy(FileUIModel);
        }

        function returngetRequestBodyPutFile(old_category_name, new_category_name, old_file_name, new_file_name) {
            var apiModel = {};
            apiModel["oldfield"] = old_category_name;
            apiModel["newfield"] = new_category_name;
            apiModel["oldfilename"] = old_file_name;
            apiModel["newfilename"] = new_file_name;
            return apiModel;
        }

        function returngetConfigFileUI(configFileApiModel) {
            var configDataModel = [];
            angular.forEach(configFileApiModel, function(file) {
                var configFileModel = angular.copy(FileUIModel);
                configFileModel.CategoryName = file['filename'];
                configDataModel.push(configFileModel);
            });
            return configDataModel;
        }

        function returnConfigUIModel(configApiModel) {
            var configDataModel = [];
            angular.forEach(configApiModel, function(value, key) {
                var configModel = angular.copy(configUIModel);
                configModel.FileNumber = value.length;
                configModel.CategoryName = key;
                configDataModel.push(configModel);
            });
            return configDataModel;
        }

        function returngetSearchAPIUrl() {
            var ApiUrl = WRSU_CONFIG['SEARCH_CATEGORY'];
            return ApiUrl;
        }

        function returngetSearchFileAPIUrl(cat_Name) {
            var ApiUrl = WRSU_CONFIG['SEARCH_FILES'];
            ApiUrl = ApiUrl.replace('{CAT_NAME}', cat_Name);
            return ApiUrl;
        }

        function returngetPostCategoryAPIUrl(cat_Name) {
            var ApiUrl = WRSU_CONFIG['POST_CATEGORY'];
            ApiUrl = ApiUrl.replace('{CAT_NAME}', cat_Name);
            return ApiUrl;
        }

        function returngetPutFileAPIUrl() {
            var ApiUrl = WRSU_CONFIG['EDIT_CONFIG_FILE'];
            return ApiUrl;
        }

        function returngetPostFileAPIUrl(cat_Name) {
            var ApiUrl = WRSU_CONFIG['POST_FILE'];
            ApiUrl = ApiUrl.replace('{CAT_NAME}', cat_Name);
            return ApiUrl;
        }

        function returngetPutCategoryAPIUrl(old_cat_Name, new_cat_Name) {
            var ApiUrl = WRSU_CONFIG['PUT_CATEGORY'];
            ApiUrl = ApiUrl.replace('{OLD_CAT_NAME}', old_cat_Name);
            ApiUrl = ApiUrl.replace('{NEW_CAT_NAME}', new_cat_Name);
            return ApiUrl;
        }

        function returngetDeleteCategoryAPIUrl(cat_Name) {
            var ApiUrl = WRSU_CONFIG['DELETE_CATEGORY'];
            ApiUrl = ApiUrl.replace('{CAT_NAME}', cat_Name);
            return ApiUrl;
        }

        function returngetDeleteFilesAPIUrl(cat_Name, file_name) {
            var ApiUrl = WRSU_CONFIG['DELETE_FILE'];
            ApiUrl = ApiUrl.replace('{CAT_NAME}', cat_Name);
            ApiUrl = ApiUrl.replace('{FILE_NAME}', file_name);
            return ApiUrl;
        }

        function returnGroupSearchAPI(requestModel) {
            var ApiUrl = WRSU_CONFIG['SEARCH_GROUPS'];
            ApiUrl += "?enabled=true&database=" + requestModel.libraryName +
                '&offset=' + ((requestModel.pagenumber - 1) * requestModel.pageLength).toString() +
                '&limit=' + requestModel.pageLength.toString() + '&total=' + requestModel.isTotal;

            if (requestModel.searchText != null && requestModel.searchText != '')
                ApiUrl += '&query=*' + requestModel.searchText + '*';

            return ApiUrl;
        }

        function getGroupUIModel(groupApiModel) {
            var groupModel = angular.copy(groupUIModel);

            groupModel.ItemId = groupApiModel[CONST_GROUPS.GroupName];
            groupModel.FullName = groupApiModel[CONST_GROUPS.GroupFullName];
            groupModel.Type = 'Group';
            groupModel.IsFullNameFound = groupApiModel[CONST_GROUPS.GroupFullName] != undefined && groupApiModel[CONST_GROUPS.GroupFullName].toString().length > 0;
            return groupModel;
        };

        function returnAPIUrl(APIFOR, requestModel) {
            var ApiUrl = WRSU_HOME[APIFOR];
            if (requestModel)
                ApiUrl = prepareUrl(ApiUrl, requestModel);
            return ApiUrl;
        }

        function prepareUrl(URL, requestModel) {
            var ApiUrl = URL + '?offset=' + ((requestModel.pagenumber - 1) * requestModel.pageLength).toString() +
                '&limit=' + requestModel.pageLength.toString() + '&total=' + requestModel.isTotal + '&language=' + requestModel.language;

            return ApiUrl;
        }
		
		function returnLocaleUIModel(localeApiModel) {
            var templocaleUIModel = angular.copy(localeUIModel);
            templocaleUIModel.Id = localeApiModel[CONST_LOCALE.Id]
            templocaleUIModel.Name = localeApiModel[CONST_LOCALE.Name]
            return templocaleUIModel;
        }
    }
})();