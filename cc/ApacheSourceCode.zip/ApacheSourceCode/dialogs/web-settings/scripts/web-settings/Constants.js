(function() {
    'use strict';

    angular.module('iManage.WebSettings').constant('API_URL_WebSettings', {
        SEARCH_CATEGORY: 'config/fields',
        POST_CATEGORY: 'config/{CAT_NAME}',
        DELETE_CATEGORY: 'config/{CAT_NAME}',
        PUT_CATEGORY: 'config/{OLD_CAT_NAME}/{NEW_CAT_NAME}',
        POST_FILE: 'config/{CAT_NAME}/files',
        SEARCH_FILES: 'config/{CAT_NAME}/files',
        DELETE_FILE: 'config/{CAT_NAME}/files/{FILE_NAME}',
        DOWNLOAD_FILE: 'config/{CAT_NAME}/files/{FILE_NAME}',
        EDIT_CONFIG_FILE: 'config/field/files',
        SEARCH_GROUPS: 'groups/search',
        WEB_SETTINGS_URL: 'web/customizations',
        SEARCHCAPTIONS: "captions/search",
        GET_INIT_DATA: 'init-data',
		GET_STARTUP_INIT_DATA: 'startup/init-data',
        REGISTRY_WEB_SETTINGS:'system/config'
    });

    angular.module('iManage.WebSettings').constant('WebSettings_FILE', {
        FileName: 'filename',
        Lastupdated: 'lastupdated',
        TYPE: 'type',
        URL: 'uri'
    });
	
    angular.module('iManage.WebSettings').constant('CONST_GROUPS', {
        GroupName: 'group_id',
        GroupNameFilter: 'alias',
        GroupFullName: 'full_name',
        GroupFullNameFilter: 'full_name',
        GroupEnabled: 'enabled',
        GroupEnabledFilter: 'enabled',
        GroupIsExternal: 'is_external',
        GroupIsExternalFilter: 'external',
        GroupNOS: 'group_nos',
        GroupNumResponse: 'group_number',
        GroupNum: 'group_number',
        DataBase: 'database',
        Domain: 'group_domain',
        SyncId: "sync_id",
        DistinguishedName: "distinguished_name"
    });
	
	angular.module('iManage.WebSettings').constant('CONST_LOCALE', {
        Id: 'id',
        Name: 'name'
    });
})();