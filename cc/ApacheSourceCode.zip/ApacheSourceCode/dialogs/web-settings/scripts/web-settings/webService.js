﻿(function() {
    'use strict';


angular.module('iManage.WebSettings').service("WebSettingsService", WebSettingsService);
WebSettingsService.$inject = ['$http'];

function WebSettingsService($http) {

    this.getData = function (URL) {
        var promise = $http({
            url: URL,
            method: "GET"
        });
        return promise;
    };

    this.UploadFile = function (formdata,URL) {
        var response = $http({
            url: URL,
            method: "POST",
            headers: {
                'Content-Type': undefined
            },
            data: formdata
        });
        return response;
    };

    this.putWithOutBody = function (URL) {
        var promise = $http({
            url: URL,
            method: "PUT"
        });
        return promise;
    };

    this.putWithBody = function (URL, body) {
        var promise = $http({
            url: URL,
            method: "PUT",
            data: JSON.stringify(body)
        });
        return promise;
    };

    this.postWithOutBody = function (apiUrl) {
        var promise = $http({
            url: apiUrl,
            method: "POST"
        });
        return promise;
    };

    this.postWithBody = function (body, apiUrl) {
        var promise = $http({
            url: apiUrl,
            method: "POST",
            data: JSON.stringify(body)
        });
        return promise;
    };

    this.DeleteMethod = function (URL) {
        var promise = $http({
            url: URL,
            method: "DELETE"
        });
        return promise;
    };

    this.DownLoadData = function (URL) {

        var promise = $http.get(URL, { responseType: 'arraybuffer' })
      
        return promise;
    };
    
}
})();