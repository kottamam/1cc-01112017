angular.module('iManage.WebSettings').controller("WebSettingsController", WebSettingsController);
WebSettingsController.$inject = ['$scope', '$filter', '$timeout', '$mdDialog', '$mdMedia', '$q', '$translate', '$window', '$location',
    'homeFactory', 'homeService', 'WebSettingsFactory', 'WebSettingsService'
];

function WebSettingsController($scope, $filter, $timeout, $mdDialog, $mdMedia, $q, $translate, $window, $location,
    homeFactory, homeService, WebSettingsFactory, WebSettingsService) {

    var webSettingCtrl = this;
    var requestModel = homeFactory.requestModelInstance();
    var baseV2Url = '';

    $scope.Metadata = [];
    $scope.Filters = [];
    $scope.customizedLogo = undefined;

    $scope.ChangeLogo = ChangeLogo;
    $scope.ReadLogo = ReadLogo;
    $scope.ResetLogo = ResetLogo;
    $scope.HaveLogo = false;
    $scope.invalidFile = false;
    $scope.showReset = false;
    $scope.isAccept = true;
    $scope.isRestoringData = false;
    $scope.UserLocales = [];

    var groupLastSearchText = undefined;
    var QuerriedGroups = [];
    var CheckedGroups = [];
    $scope.selectedGroups = [];
    $scope.groupSearchText = null;
    var isViewSelected = false;
    var totalGroupCount = 0;
    var isGroupsFetching = false;
    $scope.SelctedGroups = {}
    $scope.SelctedGroups.isViewSelected = false;
    var toastTimeout;
    var lblConfirmation, lblWarning, lblYes, lblNo, lblSuccess, lblOk;
    var previousLogo;
    $scope.IsPostingData = false;
    $scope.SelectGroup = SelectGroup;
    $scope.QuerySearchGroup = QuerySearchGroup;
    $scope.updateSelectAllGroupsListCheckbox = updateSelectAllGroupsListCheckbox;
    $scope.getSelectedGroupsCount = getSelectedGroupsCount;
    $scope.selectedOnlyChecked = selectedOnlyChecked;
    $scope.selectedOnlyunChecked = selectedOnlyunChecked;
    $scope.addAllSelectedGroup = addAllSelectedGroup;
    $scope.selectAllGroups = selectAllGroups;
    $scope.isAddedGroupsListInIntermediate = isAddedGroupsListInIntermediate;
    $scope.isGroupsListInIntermediate = isGroupsListInIntermediate;
    $scope.getAddedGroupsCount = getAddedGroupsCount;
    $scope.removeFromSelectedGroups = removeFromSelectedGroups;
    $scope.removeAllAddedGroup = removeAllAddedGroup;
    $scope.removeAllSelectedGroup =removeAllSelectedGroup;
    $scope.selectAllAddedGroups = selectAllAddedGroups;
    $scope.updateAddedSelectAllGroupsListCheckbox = updateAddedSelectAllGroupsListCheckbox;
    $scope.viewSelected = viewSelected;
    $scope.viewSelectedStatus = viewSelectedStatus;
    $scope.getQuerriedGroupsCount = getQuerriedGroupsCount;
    $scope.yesEnableGoogleCLick = yesEnableGoogleCLick;
    $scope.Access = {};
    $scope.Features = {};
    $scope.General = {};
    $scope.RestoreDefaults = RestoreToDefaults;
    $scope.SaveWebSettings = SaveWebSettings;
    $scope.EnableAdditionalTabClicked = enableAdditionalTabClicked;
    $scope.ActiveTab = "GENERAL";
    var PreviousModel = {
        General: {},
        Features: {},
        Access: {}
    };

    $timeout(function() {
        $(window).scrollTop(0);
    });

    initalize();

    function initalize() {
        $(window).scrollTop(0);
        getTranslate();
        getParams().then(function(response) {
            getCaptions().then(function() {
                //RestoreToDefaults(true);
                Download();
                GetWebSettings().then(function(response) {
                    if (response.status == 200) {
                        SetCustmizedSettings(response.data);
                        if(response.data && response.data.lisence_accept){
                            if(response.data.lisence_accept=='true')
                                $scope.isAccept = false;
                            else 
                                $scope.isAccept = true;
                        }
                        if(!response.data.features || !response.data.access || !response.data.general){
                            getValuesFromRegistry(); 
                        }
                    }
                    else {
                        getValuesFromRegistry();                    
                    }
                });
            });
        });

    }

    function getValuesFromRegistry() {        
        var baseUrl = homeFactory.getApiV2BaseUrl('', false, false);
        var apiUrl = baseUrl + WebSettingsFactory.getRegistryWebSettings();
        var promise = WebSettingsService.getData(apiUrl);
        var RegistryFields = [];
        promise.then(function (response) {
            if (response && response.data) {
                angular.forEach(response.data, function (systemconfig) {
                    var systemConfigUIModel = WebSettingsFactory.geRegistryFields(systemconfig);
                    RegistryFields.push(systemConfigUIModel);
                    if (RegistryFields && RegistryFields[0]) {
                        if (RegistryFields[0].localeDefault && !$scope.General.Language)
                            $scope.General.Language = RegistryFields[0].localeDefault;
                         /*if (RegistryFields[0].HTML5PolicyPreventDataLeakage && !$scope.Features.DataLeakagePolicy)
                            $scope.Features.DataLeakagePolicy = RegistryFields[0].HTML5PolicyPreventDataLeakage.toLowerCase();
                       if (RegistryFields[0].fileToFolder)
                            $scope.Features.EmailFolder = RegistryFields[0].fileToFolder.toLowerCase();*/

                        if (RegistryFields[0].usageTracking && !$scope.Features.EnableGoogleTracking) {
                            if (RegistryFields[0].usageTracking.toLowerCase() == 'on')
                                $scope.Features.EnableGoogleTracking = 'true';
                            else
                                $scope.Features.EnableGoogleTracking = 'false';
                        }
                        else
                            $scope.Features.EnableGoogleTracking = 'false';

                        if (RegistryFields[0].hTML5PolicyGroupAccessList && !$scope.Access.EnableGroupsAccess) {
                            if (RegistryFields[0].hTML5PolicyGroupAccessList.toLowerCase() == 'y')
                                $scope.Access.EnableGroupsAccess = 'true';
                            else
                                $scope.Access.EnableGroupsAccess = 'false';
                        }
                        else
                            $scope.Access.EnableGroupsAccess = 'true';


                        if (RegistryFields[0].customViewMetadataField && (!$scope.Features.EnableAdditionalTab || !$scope.Features.Metadata)) {
                            $scope.Features.EnableAdditionalTab = 'true';
                            $scope.Features.Metadata = RegistryFields[0].customViewMetadataField.toLowerCase();
                        }
                        PreviousModel['Features'] = angular.copy($scope.Features);
                        PreviousModel['General'] = angular.copy($scope.General);
                        PreviousModel['Access'] = angular.copy($scope.Access);
                    }
                    defaultValues();
                });
            }
            else{
                defaultValues();
            }
        }, function (response) {
            defaultValues();
        });
    }

    function defaultValues(){
        if(!$scope.General.Language)
            $scope.General.Language = 'en-US';
        //if(!$scope.Features.DataLeakagePolicy)
            //$scope.Features.DataLeakagePolicy = 'low';
        //if(!$scope.Features.EmailFolder)
            //$scope.Features.EmailFolder = 'cc';
        if(!$scope.Features.EnableGoogleTracking)
            $scope.Features.EnableGoogleTracking = 'false';
        if(!$scope.Access.EnableGroupsAccess)
            $scope.Access.EnableGroupsAccess = 'true';
        if(!$scope.Features.EnableAdditionalTab){
            $scope.Features.EnableAdditionalTab = 'true';
            $scope.Features.Metadata = 'custom1';
            $scope.Features.IconNumber = '1';
        }
        PreviousModel['Features'] = angular.copy($scope.Features);
        PreviousModel['General'] = angular.copy($scope.General);
        PreviousModel['Access'] = angular.copy($scope.Access);
    }

    function getTranslate() {
        $translate('WebSettings.doYouWantToSaveTheChanges').then(function(translatedValue) {
            lblConfirmation = translatedValue;
        });

        $translate('WebSettings.warning').then(function(translatedValue) {
            lblWarning = translatedValue;
        });
        $translate('yes').then(function(translatedValue) {
            lblYes = translatedValue;
        });

        $translate('no').then(function(translatedValue) {
            lblNo = translatedValue;
        });

        $translate('success').then(function(translatedValue) {
            lblSuccess = translatedValue;
        });

        $translate('ok').then(function(translatedValue) {
            lblOk = translatedValue;
        });
    }

    function enableAdditionalTabClicked() {
        if ($scope.Features && $scope.Features.EnableAdditionalTab == 'true') {
            if (!$scope.Features.Metadata) {
                $scope.Features.Metadata = 'custom1';
            }
            if (!$scope.Features.IconNumber) {
                $scope.Features.IconNumber = '1';
            }
        }
    }

    function getDefaultLocale() {
        var deferred = $q.defer();

        if ($location.search().locale && $location.search().locale.toString().trim().length > 0) {
            deferred.resolve({ Status: 0, LocaleDefault: $location.search().locale });
            return deferred.promise;
        }

        if (localStorage.getItem('locale') && localStorage.getItem('locale').toString().trim().length > 0) {
            deferred.resolve({ Status: 0, LocaleDefault: localStorage.getItem('locale') });
            return deferred.promise;
        }

        var promiseWebSetting = GetWebSettings();
        promiseWebSetting.then(function(responseWebSettings) {
            if (responseWebSettings.status === 200 && responseWebSettings.data && responseWebSettings.data.general &&
                responseWebSettings.data.general.language && responseWebSettings.data.general.language.trim().length > 0) {
                deferred.resolve({ Status: 0, LocaleDefault: responseWebSettings.data.general.language });
            } else {
                var baseURL = homeFactory.getApiV2BaseUrl();
                var apiUrl = homeFactory.getServerVersionAPI();
                var promise = homeService.getData(baseURL + apiUrl);
                promise.then(function(response) {
                    if (response && response.data && response.data.data && response.data.data['Locale Default']) {
                        deferred.resolve({ Status: 0, LocaleDefault: response.data.data['Locale Default'] });
                    } else {
                        deferred.resolve({ Status: 0, LocaleDefault: 'en-US' });
                    }
                });
            }
        });
        return deferred.promise;
    }

    function getCaptions() {
        var defred = $q.defer();
        var promise = getDefaultLocale();
        promise.then(function(localeLanguage) {
            var caprequestModel = homeFactory.requestModelInstance();
            caprequestModel.libraryName = $scope.SelectedLibrary;
            caprequestModel.isTotal = true;
            caprequestModel.searchText = '';
            caprequestModel.pageLength = 1000;
            caprequestModel.language = localeLanguage.LocaleDefault;
            var apiUrl = WebSettingsFactory.getAPIUrl('SEARCHCAPTIONS', caprequestModel);
            //$scope.mc.getlogDetails("Debug", 'Requested Api Url:' + JSON.stringify(apiUrl));
            var promise = homeService.getData(baseV2Url + apiUrl);
            promise.then(function(response) {
                $scope.CaptionsList = [];

                angular.forEach(response.data["data"], function(caption) {
                    $scope.CaptionsList.push(homeFactory.getCaptionUIModel(caption));
                });
                defred.resolve();
            });
        });
        return defred.promise;
    }

    function changeExist(previousTab) {
        var promiseSave = $q.defer();
        var confirmDocumentSave = $mdDialog.confirm()
            .title(lblWarning)
            .theme('confirm-dialog')
            .textContent(lblConfirmation)
            .ariaLabel(lblConfirmation)
            .ok(lblYes)
            .cancel(lblNo);
        $mdDialog.show(confirmDocumentSave).then(function() {
            SaveWebSettings(false, previousTab).then(function(){
                promiseSave.resolve();
            });
        }, function() {
            if (previousTab == 'GENERAL') {
                $scope.General = angular.copy(PreviousModel['General']);
                if ($scope.isChangeLogo || $scope.isResetLogo){
                    // $scope.customizedLogo = previousLogo;
                    Download();
                }
                $scope.isChangeLogo = false;
            } else if (previousTab == 'ACCESS') {
                $scope.Access = angular.copy(PreviousModel['Access']);
            } else if (previousTab == 'FEATURE') {
                $scope.Features = angular.copy(PreviousModel['Features']);
            }
            promiseSave.resolve();
        });
        return promiseSave.promise;
    }

    $scope.removeToast = function() {
        $('div#toastPopup').removeClass('show');
    }
    
    bindEvent(window, 'message', function (e) {
         if(e.data  != "RELOAD"){
             TabChanged('').then(function(){
            sendMessage(true);
        });
            }else if(e.data == "RELOAD"){
               initalize(); 
            }
       
    });

    $scope.onTabChanges = TabChanged;
    
    function TabChanged(currentTabIndex) {
        var promiseSave = $q.defer();
        if ($scope.ActiveTab == 'GENERAL') {
            if (!angular.equals($scope.General, PreviousModel['General']) || $scope.isChangeLogo || $scope.isResetLogo) {
                changeExist('GENERAL').then(function(){
                    promiseSave.resolve();
                });
            }else{
                promiseSave.resolve();
            }
        } else if ($scope.ActiveTab == 'ACCESS') {
            if (!angular.equals($scope.Access, PreviousModel['Access'])) {
                changeExist('ACCESS').then(function(){
                    promiseSave.resolve();
                });
            }else{
                promiseSave.resolve();
            }
        } else if ($scope.ActiveTab == 'FEATURE') {
            if (!angular.equals($scope.Features, PreviousModel['Features'])) {
                changeExist('FEATURE').then(function(){
                    promiseSave.resolve();
                });
            }else{
                promiseSave.resolve();
            }
        }else{
            promiseSave.resolve();
        }
        $scope.ActiveTab = currentTabIndex;
        return promiseSave.promise;
    }

    function GetWebSettings() {
        var deferred = $q.defer();
        var baseUrl = homeFactory.getApiV2BaseUrl($scope.SelectedLibrary, false, true);
        var apiUrl = baseUrl + WebSettingsFactory.getWebSettings();
        var promise = WebSettingsService.getData(apiUrl);
        promise.then(function(response) {

            deferred.resolve(response);
        }, function(response) {

            deferred.resolve(response);
        });
        return deferred.promise;

    }

    function PostWebSettings(Body, previousTab) {
        var deferred = $q.defer();
        var baseUrl = homeFactory.getApiV2BaseUrl($scope.SelectedLibrary, false, true);
        var apiUrl = baseUrl + WebSettingsFactory.getWebSettings();
        var promise = WebSettingsService.postWithBody(Body, apiUrl);
        promise.then(function(response) {
            if ($scope.IsPostingData) {
                $('div#toastPopup').addClass('show');
                $timeout(function() {
                    $('div#toastPopup').removeClass('show');
                }, 2000);
                $timeout(function() {
                    $scope.isRestoringData = false;
                }, 2500);
            }
            $scope.IsPostingData = false;
            deferred.resolve(response);
        }, function(response) {

            deferred.resolve(response);
        });
        return deferred.promise;

    }

    function SaveWebSettings(defaultValue, previousTab) {
        var promiseSave = $q.defer();
        if (defaultValue === true) {
            RestoreToDefaults();
            $scope.isRestoringData = true;
        }
        $scope.IsPostingData = true;
        var defaultSettings = {};
        GetWebSettings().then(function(response) {
            if (response.status == 200) {
                defaultSettings = response.data;
            }
            if ($scope.ActiveTab === 'FEATURE' || previousTab == 'FEATURE') {
                defaultSettings.features = {};
                //
                defaultSettings.features.additional_tab = {}
                defaultSettings.features.additional_tab.enable_additional_tab = $scope.Features.EnableAdditionalTab === 'true';
                if (defaultSettings.features.additional_tab.enable_additional_tab) {
                    defaultSettings.features.additional_tab.metadata = $scope.Features.Metadata;
                    defaultSettings.features.additional_tab.image_number = $scope.Features.IconNumber;
                }
                //defaultSettings.features.file_emails_to_folder = $scope.Features.EmailFolder;
                if(defaultSettings.features.file_emails_to_folder)
                    delete defaultSettings.features.file_emails_to_folder;

                 if(defaultSettings.features.data_leakage_policy)
                    delete defaultSettings.features.data_leakage_policy;
                //defaultSettings.features.data_leakage_policy = $scope.Features.DataLeakagePolicy;
                defaultSettings.features.enable_google_tracking = $scope.Features.EnableGoogleTracking === 'true';
                defaultSettings.features.defaultTab = $scope.Features.defaultTab;
                defaultSettings.features.username_format = $scope.Features.username_format;
                PreviousModel['Features'] = angular.copy($scope.Features);
            }
            if ($scope.ActiveTab === 'ACCESS' || previousTab == 'ACCESS') {
                defaultSettings.access = {};
                defaultSettings.access.enable_access_to_specific_groups = $scope.Access.EnableGroupsAccess === 'true';
                defaultSettings.access.groups = [];
                if (defaultSettings.access.enable_access_to_specific_groups) {
                    angular.forEach($scope.selectedGroups, function(item) {
                        defaultSettings.access.groups.push(item.ItemId);
                    });
                } else {
                    QuerriedGroups = [];
                    $scope.groupSearchText = '';
                    groupLastSearchText = '';
                    $scope.selectedGroups = [];
                }
                PreviousModel['Access'] = angular.copy($scope.Access);
            }
            if ($scope.ActiveTab === 'GENERAL' || previousTab == 'GENERAL') {
                defaultSettings.general = {};
                defaultSettings.general.language = $scope.General.Language;
                if ($scope.isChangeLogo) {
                    SubmitFile();
                    /*if ($scope.HaveLogo) {
                        DeleteLogo().then(function() {
                            SubmitFile();
                        });
                    } else {
                        SubmitFile();
                    }*/
                    $scope.isChangeLogo = false;
                } else if ($scope.isResetLogo) {
                    DeleteLogo();
                }
                $scope.isResetLogo = false;
                PreviousModel['General'] = angular.copy($scope.General);
            }
            PostWebSettings(defaultSettings, previousTab).then(function(){
                promiseSave.resolve();
                if($scope.ActiveTab === 'FEATURE' || previousTab == 'FEATURE'){ 
                    var msg = {
                        Type: "Feature_Change",
                        Format: $scope.Features.username_format
                    }                   
                    sendMessage(msg);
                }
            });



        });
        return promiseSave.promise;
    }

    function SetCustmizedSettings(responseData) {
        if (responseData.features) {
            // defaultSettings.features.additional_tab
            if (responseData.features.additional_tab) {
                if (responseData.features.additional_tab.enable_additional_tab != undefined)
                    $scope.Features.EnableAdditionalTab = responseData.features.additional_tab.enable_additional_tab ? 'true' : 'false';
                if (responseData.features.additional_tab.metadata != undefined)
                    $scope.Features.Metadata = responseData.features.additional_tab.metadata;

                if (responseData.features.additional_tab.image_number != undefined)
                    $scope.Features.IconNumber = responseData.features.additional_tab.image_number;
            }
            /*if (responseData.features.file_emails_to_folder != undefined)
                $scope.Features.EmailFolder = responseData.features.file_emails_to_folder;
            if (responseData.features.data_leakage_policy != undefined)
                $scope.Features.DataLeakagePolicy = responseData.features.data_leakage_policy;*/
            if (responseData.features.enable_google_tracking != undefined)
                $scope.Features.EnableGoogleTracking = responseData.features.enable_google_tracking ? 'true' : 'false';
            if (responseData.features.defaultTab != undefined)
                $scope.Features.defaultTab = responseData.features.defaultTab;
            if (responseData.features.username_format)
                $scope.Features.username_format = responseData.features.username_format;
            PreviousModel['Features'] = angular.copy($scope.Features);
        }
        if (responseData.access) {
            if (responseData.access.enable_access_to_specific_groups != undefined)
                $scope.Access.EnableGroupsAccess = responseData.access.enable_access_to_specific_groups ? 'true' : 'false';
            if ($scope.Access.EnableGroupsAccess === 'true') {
                $scope.selectedGroups = [];
                angular.forEach(responseData.access.groups, function(item) {
                    $scope.selectedGroups.push({
                        FullName: item,
                        IsAdded: false,
                        IsFullNameFound: false,
                        ItemId: item,
                        Type: "Group",
                        UserPhotoText: "Wi",
                        isAdded: false,
                        isSelected: false
                    });
                });
            }
            PreviousModel['Access'] = angular.copy($scope.Access);
        }
        if (responseData.general && responseData.general.language) {
            $scope.General.Language = responseData.general.language;
            PreviousModel['General'] = angular.copy($scope.General);
        }
    }

    function RestoreToDefaults(restoreAllTabs) {
        if (restoreAllTabs || $scope.ActiveTab === 'FEATURE') {
            $scope.Features = {};
            $scope.Features.EnableAdditionalTab = 'true';
            $scope.Features.Metadata = 'custom1';
            $scope.Features.IconNumber = '1';
            //$scope.Features.EmailFolder = 'cc';
            //$scope.Features.DataLeakagePolicy = 'low';
            $scope.Features.EnableGoogleTracking = 'false';
            $scope.Features.username_format = "userid_fullname";
            PreviousModel['Features'] = angular.copy($scope.Features);
        }
        if (restoreAllTabs || $scope.ActiveTab === 'ACCESS') {
            $scope.Access.EnableGroupsAccess = 'true';
            QuerriedGroups = [];
            $scope.selectedGroups = [];
            $scope.groupSearchText = '';
            groupLastSearchText = '';
            PreviousModel['Access'] = angular.copy($scope.Access);
        }
        if (restoreAllTabs || $scope.ActiveTab === 'GENERAL') {
            $scope.General.Language = 'en-US'
            PreviousModel['General'] = angular.copy($scope.General);
        }
    }

    function getParams() {
        var deferred = $q.defer();
        $scope.SelectedLibrary = $location.search().library;
        getCustomerId().then(function(response) {
            baseV2Url = homeFactory.getApiV2BaseUrl($scope.SelectedLibrary);
            deferred.resolve();
        });
        return deferred.promise;
    }

    function ChangeLogo() {
        $('#Uploadlogo').click();
    }

    function ReadLogo($files) {
        $scope.isChangeLogo = false;
        $scope.invalidFile = false;
        var blob, URL;
        $scope.ErrorMsg = "Seems to be invalid File";
        if ($files[0] === undefined) {
            $scope.invalidFile = true;
            $timeout(function() { $scope.$apply(); });
            return;
        } else if ($files[0].name.substr($files[0].name.lastIndexOf('.') + 1) == 'svg') {
            $scope.extension = $files[0].name.substr($files[0].name.lastIndexOf('.') + 1);
            $scope.filevalue = $files[0];
            $scope.isChangeLogo = true;
            $scope.isResetLogo = false;
            $scope.showReset = false;
            $scope.ErrorMsg = "";
            if ($scope.customizedLogo)
                previousLogo = angular.copy($scope.customizedLogo);
            $scope.customizedLogo = undefined;
            var blob = new Blob([$files[0]], { type: 'image/svg+xml' });
            URL = $window.URL || $window.webkitURL;
            $scope.customizedLogo = URL.createObjectURL(blob);
            $timeout(function() { $scope.$apply(); });
        } else {
            $scope.invalidFile = true;
            $timeout(function() { $scope.$apply(); });
        }

    }

    function DeleteLogo() {
        var defered = $q.defer();
        var apiUrl = baseV2Url + WebSettingsFactory.getDeleteFilesAPIUrl('Web', 'Logo');
        var promise = WebSettingsService.DeleteMethod(apiUrl);
        promise.then(function(response) {
            $scope.HaveLogo = false;
            defered.resolve(response);
        }, function(response) {
            defered.resolve(response);
        });
        return defered.promise;
    }

    function SubmitFile() {
        $scope.showReset = false;
        var defered = $q.defer();

        var apiUrl = baseV2Url + WebSettingsFactory.getPostFileAPIUrl('Web');

        var formdata = new FormData();
        var jsonData = {};
        jsonData.doc_profile = {};
        jsonData.doc_profile.name = 'Logo';
        jsonData.warnings_for_required_and_disabled_fields = true;
        jsonData.doc_profile.extension = $scope.extension;


        formdata.append("json", new Blob([JSON.stringify(jsonData)], { type: "application/json" }));
        formdata.append('Logo', $scope.filevalue);
        var promise = WebSettingsService.UploadFile(formdata, apiUrl);

        promise.then(function(response) {
            if (response && response.statusText == 'CREATED' && response.status == 201) {
                $scope.HaveLogo = true;
                defered.resolve(response);
            } else {

                defered.resolve(response);
            }
            $scope.posting = false;
        }, function(response) {
            defered.resolve(response);
        });
        return defered.promise;
    }

    function downLoadDefaultLogo() {
        $scope.showReset = true;
        var defered = $q.defer();
        var promise = WebSettingsService.DownLoadData('scripts/web-settings/images/iManageWork_Logo.svg');
        promise.then(function(response) {
            var blob1 = new Blob([response.data], { type: 'image/svg+xml' });
            URL = $window.URL || $window.webkitURL;
            if ($scope.customizedLogo)
                previousLogo = angular.copy($scope.customizedLogo);
            $scope.customizedLogo = URL.createObjectURL(blob1);
            defered.resolve();

        });
        return defered.promise;
    }

    function Download() {

        $scope.isResetLogo = false;
        $scope.showReset = false;
        var deferred = $q.defer();
        var model = { File: 'Logo', Category: 'Web' };

        var apiUrl = baseV2Url + WebSettingsFactory.downloadFile(model);
        var promise = WebSettingsService.DownLoadData(apiUrl);
        promise.then(function(response) {
            if (response.status === 200) {
                $scope.HaveLogo = true;
                if ($scope.customizedLogo)
                    previousLogo = angular.copy($scope.customizedLogo);
                $scope.customizedLogo = undefined;
                var headerdata = response.headers();
                try {
                    var blob;
                    try {
                        blob = new Blob([response.data], { type: headerdata['content-type'] || 'image/svg+xml' }); // || 'application/octet-stream'
                    } catch (e) {
                        window.BlobBuilder = window.BlobBuilder || window.WebKitBlobBuilder || window.MozBlobBuilder || window.MSBlobBuilder;
                        if (window.BlobBuilder) {
                            var bb = new BlobBuilder();

                            bb.append(response.data);
                            blob = bb.getBlob(headerdata['content-type'] || 'image/svg+xml'); // || 'application/octet-stream'
                        }
                    }

                    URL = $window.URL || $window.webkitURL;
                    $scope.customizedLogo = URL.createObjectURL(blob);

                    deferred.resolve();
                } catch (ex) {
                    downLoadDefaultLogo().then(function() {
                        deferred.resolve();
                    });
                }
            } else {
                $scope.customizedLogo = undefined;
                downLoadDefaultLogo().then(function() {
                    deferred.resolve();
                });
            }
        }, function(response) {
            $scope.customizedLogo = undefined;
            downLoadDefaultLogo().then(function() {
                deferred.resolve();
            });
        });
        return deferred.promise;

    }

    function ResetLogo() {
        $scope.customizedLogo = undefined;
        $scope.isResetLogo = true;
        $scope.isChangeLogo = false;
        downLoadDefaultLogo();
    }

    function getCustomerId() {
        var deferred = $q.defer();
        var apiUrl;

        var baseUrlWithoutAPIV2 = homeFactory.getApiV2BaseUrl('', true, true);
        if (baseUrlWithoutAPIV2.indexOf('imcc/') != -1) {
            apiUrl = baseUrlWithoutAPIV2 + WebSettingsFactory.getInitDataAPI();
        } else {
            apiUrl = baseUrlWithoutAPIV2 + WebSettingsFactory.getStartupInitDataAPI();
        }

        var promise = homeService.getData(apiUrl);
        promise.then(function(response) {
            customerName = '1'; 
            if (response.status === 200 && response.data) {
                if (response.data.customer_id && response.data.customer_id.toString().trim().length > 0) {
                    customerName = response.data.customer_id.toString();
                } else if (response.data.data && response.data.data.customer_id && response.data.data.customer_id.toString().trim().length > 0) {
                    customerName = response.data.data.customer_id.toString();
                }
				
				var locales;
                $scope.UserLocales = [];
                if (response.data.locales && response.data.locales.length > 0) {
                    locales = response.data.locales;
                } else if (response.data.data && response.data.data.app_settings && response.data.data.app_settings.locales && response.data.data.app_settings.locales.length > 0) {
                    locales = response.data.data.app_settings.locales;
                }
                if (locales && locales.length > 0) {
                    angular.forEach(locales, function(item) {
                        $scope.UserLocales.push(WebSettingsFactory.getLocaleUIModel(item));
                    });
                }
            }
            deferred.resolve();
        });
        return deferred.promise;
    }

    function updateSelectAllGroupsListCheckbox(item) {
        $timeout(function() {
            if (item.isSelected) {
                CheckedGroups.push(item);
            } else {
                var index = -1;
                var removeItem = $filter('filter')(CheckedGroups, {
                    ItemId: item.ItemId
                }, true);

                if (removeItem && removeItem.length > 0) {
                    index = CheckedGroups.indexOf(removeItem[0]);
                }

                if (index > -1) {
                    CheckedGroups.splice(index, 1);
                }
            }
            $scope.isSelectAllGroups = isViewSelected || getSelectedGroupsCount() >= QuerriedGroups.length - 1;

            if (CheckedGroups.length > 0 && QuerriedGroups.length > 0 && !QuerriedGroups[0].IsListHeader) {
                // QuerriedGroups.unshift({
                //     IsListHeader: true,  
                //     isSelected: false
                // });
            } else if (CheckedGroups.length == 0 && QuerriedGroups.length > 0 && QuerriedGroups[0].IsListHeader) {
                // QuerriedGroups.shift();
                isViewSelected = false;
                angular.forEach(QuerriedGroups, function(item) {
                    item.isSelected = false;
                })
            }

            if (isViewSelected) {
                var checkedItem = $filter('filter')(QuerriedGroups, {
                    ItemId: item.ItemId
                }, true);
                if (checkedItem.length > 0) {
                    checkedItem[0].isSelected = item.isSelected;
                }
            }
        });
    }

    function getSelectedGroupsCount() {
        return CheckedGroups.length;
    }

    function selectedOnlyChecked() {
        return CheckedGroups.length == $filter('filter')(CheckedGroups, { isAdded: true }, true).length &&  $filter('filter')(CheckedGroups, { isAdded: false }, true).length==0;
    }

     function selectedOnlyunChecked() {
       return CheckedGroups.length == $filter('filter')(CheckedGroups, { isAdded: false || undefined }, true).length &&  $filter('filter')(CheckedGroups, { isAdded: true }, true).length==0;
    }

    function SelectGroup(item, event) {
        if (event) event.stopPropagation();
        if (item == null) {
            $scope.SelectedGroup = null;
            document.getElementById("autoCompleteUserSearch").blur();
            return;
        }
        item.isSelected = false;
        updateSelectAllGroupsListCheckbox(item);
        var selectedObj = angular.copy(item);
        $scope.selectedGroups.push(selectedObj);
        $scope.groupSearchText = '';
        item = null;
        $scope.SelectedGroup = null;
        $scope.lastAddedGroupName = selectedObj.FullName;
        $scope.isLastActionAdd = true;
        $('div#toast').addClass('shown');
        $timeout.cancel(toastTimeout);
        $timeout(function() {
            $('div#toast').removeClass('shown');
        }, 2000);
    }

    function QuerySearchGroup() {
        var deffered = $q.defer();

        if (groupLastSearchText == $scope.groupSearchText) {
            $timeout(function() {
                if (isViewSelected) {
                    $timeout(function() {
                        var tempCheckedGroups = angular.copy(CheckedGroups);
                        if (QuerriedGroups.length > 0 && QuerriedGroups[0].IsListHeader && tempCheckedGroups.length > 0 && !tempCheckedGroups[0].IsListHeader) {
                            tempCheckedGroups.unshift(QuerriedGroups[0]);
                        }
                        $scope.isSelectAllGroups = isGroupsListAllSelected();
                        deffered.resolve(tempCheckedGroups);
                    });
                } else {
                    if ($scope.selectedGroups && $scope.selectedGroups.length > 0) {
                        var tempQuerriedGroups = [];
                        angular.forEach(QuerriedGroups, function(item) {
                            var selectedItems = [];
                            if (item.ItemId != undefined) {
                                selectedItems = $filter('filter')($scope.selectedGroups, {
                                    ItemId: item.ItemId
                                }, true);
                            }
                            item.isAdded = selectedItems.length > 0;
                            tempQuerriedGroups.push(item);
                        });
                        QuerriedGroups = angular.copy(tempQuerriedGroups);
                    }
                    $timeout(function() {
                        $scope.isSelectAllGroups = isGroupsListAllSelected();
                    });
                    if (QuerriedGroups.length > 0 && !QuerriedGroups[0].IsListHeader) {
                        QuerriedGroups.unshift({
                            IsListHeader: true,
                            isSelected: false
                        });
                    }
                    deffered.resolve(QuerriedGroups);
                }
            })
        } else {
            isViewSelected = false;
            QuerriedGroups = [];
            var deferredarray = [];
            groupLastSearchText = $scope.groupSearchText;
            requestModel.pagenumber = 1;

            var deferredGroups = getGroups();
            deferredarray.push(deferredGroups);

            $q.all(deferredarray).then(function(response) {
                var itemList = [];
                QuerriedGroups = [];

                if (response.length > 0 && response[0] != null && response[0].length > 0)
                    itemList = itemList.concat(angular.copy(response[0]));

                if (response.length > 0 && response[1] != null && response[1].length > 0)
                    itemList = itemList.concat(angular.copy(response[1]));

                if (itemList.length > 0)
                    QuerriedGroups = $filter('orderBy')(itemList, 'ItemId', false);



                if (QuerriedGroups.length > 0 && !QuerriedGroups[0].IsListHeader) {
                    QuerriedGroups.unshift({
                        IsListHeader: true,
                        isSelected: false
                    });
                }
                $scope.isSelectAllGroups = isGroupsListAllSelected();

                $timeout(function() {
                    $('.md-virtual-repeat-container .md-virtual-repeat-scroller').off("scroll");
                    $('.md-virtual-repeat-container .md-virtual-repeat-scroller').on("scroll", groupCompleteList_Scroll);
                    $('.md-virtual-repeat-container .md-virtual-repeat-scroller').scrollTop(0);
                })

                deffered.resolve(QuerriedGroups);
            });
        }
        return deffered.promise;
    }

    function isGroupsListAllSelected() {
        var selectedCount = $filter('filter')(QuerriedGroups, {
            isSelected: true
        }, true).length;
        return selectedCount > 0 && QuerriedGroups.length - 1 <= selectedCount;
    }

    function groupCompleteList_Scroll() {
        if (!isGroupsFetching) {
            var scrollHeight = (($(this).scrollTop() + $(this).innerHeight()) / $(this)[0].scrollHeight) * 100.0;
            if (scrollHeight > 75) {
                isGroupsFetching = true;
                requestModel.pagenumber++;
                var deferredarray = [];
                if (totalGroupCount > 0 && ((requestModel.pagenumber - 1) * requestModel.pageLength) < totalGroupCount) {
                    var deferredGroups = getGroups();
                    deferredarray.push(deferredGroups);
                }

                $q.all(deferredarray).then(function(response) {
                    var itemList = [];

                    if (response.length > 0 && response[0] != null && response[0].length > 0)
                        itemList = itemList.concat(angular.copy(response[0]));

                    if (response.length > 0 && response[1] != null && response[1].length > 0)
                        itemList = itemList.concat(angular.copy(response[1]));

                    if (itemList.length > 0) {
                        itemList = $filter('orderBy')(itemList, 'ItemId', false);

                        angular.forEach(itemList, function(item) {
                            QuerriedGroups.push(item);
                        })
                    }

                    isGroupsFetching = false;
                });

                if (deferredarray.length == 0) {
                    isGroupsFetching = false;
                }
            }
        }
    }


    function getGroups() {
        var deffered = $q.defer();
        $scope.SelectedLibrary = $location.search().library;
        if (!$scope.SelectedLibrary || $scope.SelectedLibrary.trim().length == 0) {
            deffered.resolve([]);
            return deffered.promise;
        }
        requestModel.libraryName = $scope.SelectedLibrary;
        requestModel.searchText = $scope.groupSearchText;

        var apiUrl = baseV2Url + WebSettingsFactory.getGroupSearchAPI(requestModel);
        $scope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(apiUrl));
        var promise = homeService.getData(apiUrl, $scope.mc.loginModel.AuthKey);
        promise.then(function(response) {
            if (response["status"] == 200) {
                totalGroupCount = response["data"]["total_count"];
                var GroupList = [];
                angular.forEach(response["data"]["data"], function(group) {
                    var groupModel = WebSettingsFactory.getGroupUI(group);
                    var selectedItems = $filter('filter')($scope.selectedGroups, {
                        ItemId: groupModel.ItemId
                    }, true);
                    if (selectedItems && selectedItems != '')
                        groupModel.isAdded = selectedItems.length > 0;
                    var checkedItems = $filter('filter')(CheckedGroups, {
                        ItemId: groupModel.ItemId
                    }, true);
                    groupModel.isSelected = checkedItems.length > 0;
                    GroupList.push(groupModel);
                });
                angular.forEach(GroupList, function(group) {
                    var photoPromise = getUserPhoto(group);
                });
                deffered.resolve(GroupList);
            } else {
                $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                deffered.resolve([]);
            }
        }, function(response) {
            $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
            deffered.resolve([]);
        });
        return deffered.promise;
    }

    function getUserPhoto(tempUserModel) {
        var deferred = $q.defer();
        var userId = '';
        var fullName = '';

        if (tempUserModel.ItemId != null && tempUserModel.ItemId.trim().length > 0) {
            userId = tempUserModel.ItemId;
        }
        if (userId.trim().length === 0) {
            deferred.resolve({ Status: -1 });
            return deferred.promise;
        }
        if (tempUserModel.IsFullNameFound && tempUserModel.FullName) {
            fullName = tempUserModel.FullName.trim();
        } else if (tempUserModel.Name != null && tempUserModel.Name.trim().length > 0) {
            fullName = tempUserModel.Name.trim();
        }
        var photoText = '';
        if (fullName.length > 0) {
            var nextChar = '';
            var spaceFound = false;

            for (var iCount = 0; iCount < fullName.length; iCount++) {
                nextChar = fullName.substr(iCount, 1).trim();
                if (nextChar.length === 0) {
                    spaceFound = true;
                    continue;
                }
                if (spaceFound) {
                    photoText = nextChar;
                    spaceFound = false;
                }
            }
            if (photoText.trim().length === 0) {
                photoText = fullName.substr(0, 2);
            } else {
                photoText = fullName.substr(0, 1) + photoText;
            }
        } else {
            photoText = userId.trim().substr(0, 2);
        }
        tempUserModel.UserPhotoText = photoText;
        return deferred.promise;
    }

    function addAllSelectedGroup() {

        angular.forEach(CheckedGroups, function(item) {
            item.isSelected = false;
            if (!item.isAdded) {
                var selectedObj = angular.copy(item);
                selectedObj.isSelected = false;
                $scope.selectedGroups.push(selectedObj);
            }
            item.isSelected = false;
            updateSelectAllGroupsListCheckbox(item);
        });
       $scope.groupSearchText = '';
        $scope.SelectedGroup = null;
        if (CheckedGroups.length == 1) {
            $scope.lastAddedGroupName = CheckedGroups[0].FullName;
        } else if (CheckedGroups.length > 1) {
            $scope.lastAddedGroupName = String(CheckedGroups.length) + ' groups';
        }
       
        $scope.isLastActionAdd = true;
        $('div#toast').addClass('shown');
        $timeout.cancel(toastTimeout);
        $timeout(function() {
            $('div#toast').removeClass('shown');
        }, 2000);
    }

    function selectAllGroups() {
        $scope.isSelectAllGroups = !$scope.isSelectAllGroups;
        isViewSelected = false;
        angular.forEach(QuerriedGroups, function(item) {
            if (item.ItemId) {
                item.isSelected = $scope.isSelectAllGroups;

                var checkedItem = $filter('filter')(CheckedGroups, {
                    ItemId: item.ItemId
                }, true);
                if (item.isSelected) {
                    if (checkedItem.length == 0) {
                        CheckedGroups.push(item);
                    }
                } else {
                    var index = -1;

                    if (checkedItem && checkedItem.length > 0) {
                        index = CheckedGroups.indexOf(checkedItem[0]);
                    }

                    if (index > -1) {
                        CheckedGroups.splice(index, 1);
                    }
                }
            }
        });

    }

    function removeAllSelectedGroup(){
        var count = 0;
        angular.forEach(angular.copy(CheckedGroups), function(item) {
            if (item.isSelected) {
                
                removeFromSelectedGroups(item, false);

                item.isSelected=false;
                updateSelectAllGroupsListCheckbox(item);
            }
        });       
        
        $scope.isLastActionAdd = false;
        $('div#toast').addClass('shown');
         $('div#toast').click();
        $timeout.cancel(toastTimeout);
        $timeout(function() {
            $('div#toast').removeClass('shown');
        }, 2000);
        $scope.SelctedGroups.isViewSelected = false;
       $scope.groupSearchText = '';

    }

    function removeAllAddedGroup() {
        var count = 0;
        angular.forEach(angular.copy($scope.selectedGroups), function(item) {
            if (item.isSelected) {
                if (count == 0) {
                    $scope.lastAddedGroupName = item.FullName;
                }
                count++;
                removeFromSelectedGroups(item, false);
            }
        });
        if (count > 1) {
            $scope.lastAddedGroupName = String(count) + ' groups';
        }

        $scope.isLastActionAdd = false;
        $('div#toast').addClass('shown');
        $timeout.cancel(toastTimeout);
        $timeout(function() {
            $('div#toast').removeClass('shown');
        }, 2000);
        $scope.SelctedGroups.isViewSelected = false;
       $scope.groupSearchText = '';
    }

    function removeFromSelectedGroups(item, isSingleRemove) {

        if (isSingleRemove == undefined)
            isSingleRemove = true
        var index = -1;
        var removeItem = $filter('filter')($scope.selectedGroups, {
            ItemId: item.ItemId
        }, true);

        if (removeItem && removeItem.length > 0) {
            index = $scope.selectedGroups.indexOf(removeItem[0]);
        }

        if (index > -1) {
            $scope.selectedGroups.splice(index, 1);
            if (isSingleRemove) {
                $scope.lastAddedGroupName = removeItem[0].FullName;
                $scope.isLastActionAdd = false;
                $('div#toast').addClass('shown');
                $timeout.cancel(toastTimeout);
                $timeout(function() {
                    $('div#toast').removeClass('shown');
                }, 2000);
               $scope.groupSearchText = '';
            }
        }

        var selectedItems = $filter('filter')(QuerriedGroups, {
            ItemId: item.ItemId
        }, true);

        if (selectedItems.length == 0) {
            item.isSelected = false;
            if (QuerriedGroups.length > 0 && QuerriedGroups[0].IsListHeader) {
                QuerriedGroups.splice(1, 0, item);
            } else {
                QuerriedGroups.unshift(item);
            }
        } else {
            selectedItems[0].isAdded = false;
        }
        var selectedItemsInCheckedList = $filter('filter')(CheckedGroups, {
            ItemId: item.ItemId
        }, true);
        if (selectedItemsInCheckedList.length > 0) {
            selectedItemsInCheckedList[0].isAdded = false;
        }
    }

    function getAddedGroupsCount() {
        var selectedItems = $filter('filter')($scope.selectedGroups, {
            isSelected: true
        }, true);
        return selectedItems != undefined ? selectedItems.length : 0;
    }

    function isAddedGroupsListInIntermediate() {
        var selectedCount = getAddedGroupsCount();
        return selectedCount > 0 && $scope.selectedGroups.length > selectedCount && !$scope.SelctedGroups.isViewSelected;
    }

    function isGroupsListInIntermediate() {
        var selectedCount = $filter('filter')(QuerriedGroups, {
            isSelected: true
        }, true).length;
        return selectedCount > 0 && QuerriedGroups.length - 1 > selectedCount;
    }

    function selectAllAddedGroups() {
        if ($scope.SelctedGroups.isViewSelected) {
            $scope.SelctedGroups.isViewSelected = false;
            $scope.isSelectAllAddedGroups = false;
        } else {
            $scope.isSelectAllAddedGroups = !$scope.isSelectAllAddedGroups;
        }
        angular.forEach($scope.selectedGroups, function(item) {
            item.isSelected = $scope.isSelectAllAddedGroups;
        });
    }

    function updateAddedSelectAllGroupsListCheckbox() {
        $timeout(function() {
            $scope.isSelectAllAddedGroups = getAddedGroupsCount() == $scope.selectedGroups.length;
            if (getAddedGroupsCount() == 0) {
                $scope.SelctedGroups.isViewSelected = false;
            }
        });
    }

    function viewSelected() {
        if (isViewSelected) {
            isViewSelected = false;
            $scope.isSelectAllGroups = getSelectedGroupsCount() >= QuerriedGroups.length - 1;
        } else {
            isViewSelected = true;
            $scope.isSelectAllGroups = true;
        }
    }

    function viewSelectedStatus() {
        return isViewSelected;
    }

    function getQuerriedGroupsCount() {
        return QuerriedGroups.length - 1;
    }

    function bindEvent(element, eventName, eventHandler) {
        if (element.addEventListener) {
            element.addEventListener(eventName, eventHandler, false);
        } else if (element.attachEvent) {
            element.attachEvent('on' + eventName, eventHandler);
        }
    }

    var sendMessage = function(msg) {
        window.parent.postMessage(msg, '*');
    };

    $scope.getLisenceAgreement = function(){
         var webLocation = window.location.href.split('imcc/');
            var location = webLocation[0] + 'dialogs/web-settings/scripts/web-settings/views/LincenseAgreement.html';
            var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;

            var dialogObject = {
                controller: DialogController,
                scope: $scope,
                preserveScope: true,
                templateUrl: location,
                parent: angular.element(document.body),
                targetEvent: null,
                clickOutsideToClose: false,
                fullscreen: useFullScreen,
                locals: {
                    parentScope: $scope
                }
            };
            $mdDialog.show(dialogObject)
                .then(function (answer) {
                    $scope.status = '';
                }, function () {
                    $scope.status = '';
                });
    }

    function yesEnableGoogleCLick() {
        if ($scope.Features.EnableGoogleTracking == 'true' && $scope.isAccept == true) {
            $scope.getLisenceAgreement();
        }
    }

    DialogController.$inject = ['$scope', '$mdDialog','parentScope','$q','homeFactory','WebSettingsFactory','WebSettingsService'];

    function DialogController($scope, $mdDialog,parentScope,$q,homeFactory,WebSettingsFactory,WebSettingsService) {

        var lisenceSettings = {
            lisence_accept:false
        };

        $scope.hide = function() {
            $mdDialog.hide();
        };
        $scope.cancel = function() {
            $mdDialog.cancel();
            parentScope.Features.EnableGoogleTracking = 'false';
        };

        $scope.acceptClick = function(){
            parentScope.Features.EnableGoogleTracking = 'true';
            lisenceSettings.lisence_accept = 'true';
            PostLisence(lisenceSettings);
            $mdDialog.hide();
        }

        function PostLisence(Body) {
            var deferred = $q.defer();
            var baseUrl = homeFactory.getApiV2BaseUrl($scope.SelectedLibrary, false, true);
            var apiUrl = baseUrl + WebSettingsFactory.getWebSettings();
            var promise = WebSettingsService.postWithBody(Body, apiUrl);
            promise.then(function (response) {               
                parentScope.isAccept = false;
                deferred.resolve(response);
            }, function (response) {

                deferred.resolve(response);
            });
            return deferred.promise;

        }

    }


}