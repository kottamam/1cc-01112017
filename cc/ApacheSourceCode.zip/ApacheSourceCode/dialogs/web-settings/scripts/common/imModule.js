(function() {
    'use strict';

    angular.module('iManage.WebSettings', ['ngMaterial', 'ngAnimate', 'ui.router', 'ngCookies', 'ngStorage', 'md.data.table', 'material.svgAssetsCache', 'pascalprecht.translate', 'angularMoment','ui.sortable', 'angular-sortable-view']);
    // angular.module('iManage.WebSettings', ['ngMaterial', 'ngAnimate', 'ui.router', 'ngAria',  'ngMessages', 'ngCookies', 'ngSanitize', 'fixed.table.header',  'ngStorage']);


})();

(function() {
    'use strict';


    angular.module('iManage.WebSettings').factory('sessionTimeoutInterceptor', sessionTimeoutInterceptor);

    sessionTimeoutInterceptor.$inject = ['$window', '$timeout', '$cookies', '$localStorage'];

    function sessionTimeoutInterceptor($window, $timeout, $cookies, $localStorage) {
        return {
            request: function(config) {
                return config;
            },
            response: function(response) {
                // if (UserSessionTimer) {
                //     $timeout.cancel(UserSessionTimer);
                //     UserSessionTimer = null;
                // }
                return response;
            },
            responseError: function(response) {
                $cookies.sessiontimeout = response.status;
                return response;
            }
        };
    }
})();

(function() {
    'use strict';


    angular.module('iManage.WebSettings').config(httpProviderConfig);

    httpProviderConfig.$inject = ['$httpProvider'];

    function httpProviderConfig($httpProvider) {
        $httpProvider.defaults.withCredentials = true;
        $httpProvider.defaults.useXDomain = true;
        return $httpProvider.interceptors.push('sessionTimeoutInterceptor');
    }
})();

(function() {
    'use strict';


    angular.module('iManage.WebSettings').config(homeRoute);

    homeRoute.$inject = ['$stateProvider', '$urlRouterProvider', '$logProvider'];

    function homeRoute($stateProvider, $urlRouterProvider, $logProvider) {
        $urlRouterProvider.otherwise("/");

        $stateProvider
            .state('home', {
                url: '/?dbname&server&userid&protocol',
                templateUrl: 'scripts/web-settings/index.html',
                controller: 'WebSettingsController as vmWebSettingsCtrl'
            })
            .state('advanced', {
                url: '/advanced?dbname&server&userid&protocol',
                templateUrl: 'scripts/web-advanced/index.html',
                controller: 'WebSettingsAdvancedController as vmWebAdvancedCtrl'
            })
			.state('contextmenu', {
                url: '/contextmenu?dbname&server&userid&protocol',
                templateUrl: 'scripts/web-contextmenu/web.html',
                controller: 'WebContextController as vmContextCtrl'               
            })
            .state('filters', {
                url: '/filters?dbname&server&userid&protocol',
                templateUrl: 'scripts/web-filters/index.html',
                controller: 'WebFiltersController as vmWebFiltersCtrl'
            })
            .state('home.management', {
                url: 'management',
                abstract: true
            })
    };
})();

(function() {
    'use strict';


    angular.module('iManage.WebSettings').filter('customLabel', customLabel);

    customLabel.$inject = ['$filter'];

    function customLabel($filter) {
        return function(list, alias) {
            var capList = $filter('filter')(list, { MetaDataItem: (alias ? alias : '').toUpperCase() }, true);
            if (capList != null && capList.length > 0) {
                return capList[0].DisplayText;
            }
            return alias;
        }
    };
})();

(function() {
    'use strict';


    angular.module('iManage.WebSettings').filter('isItemInList', isItemInList);

    isItemInList.$inject = ['$filter'];

    function isItemInList($filter) {
        return function(list, alias) {
            var capList = $filter('filter')(list, { MetaDataItem: (alias ? alias : '').toUpperCase() }, true);
            if (capList != null && capList.length > 0) {
                return true;
            }
            return false;
        }
    };
})();

(function() {
    'use strict';


    angular.module('iManage.WebSettings').config(translateProviderConfig);

    translateProviderConfig.$inject = ['$translateProvider'];

    function translateProviderConfig($translateProvider) {
        $translateProvider.addInterpolation('$translateMessageFormatInterpolation');
        $translateProvider.useLoader('translateFactory');
        $translateProvider.preferredLanguage('en-Us');
        $translateProvider.useSanitizeValueStrategy('escapeParameters');
    }

})();