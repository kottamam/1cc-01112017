﻿(function() {
    'use strict';

    //define(['angular'], function () {
    angular.module('iManage.WebSettings').constant('TSU_TRANSLATE', {
        GET_TRANSLATE: 'startup/strings',
        GET_SYSTEM_CONFIG: 'system/config?include_databases=true',
        GET_INIT_DATA: 'init-data',
        GET_STARTUP_INIT_DATA: 'startup/init-data',
        WEB_SETTINGS_URL: 'web/customizations',
        GET_DB_LIST: 'libraries'
    });
    //});
})();