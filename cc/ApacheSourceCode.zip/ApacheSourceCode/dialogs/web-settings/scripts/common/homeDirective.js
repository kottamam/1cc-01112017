//appsIcon
(function() {
    'use strict';


    angular.module('iManage.WebSettings').directive('appsIcon', appsIcon);


    function appsIcon() {
        return {
            restrict: 'E',
            scope: {
                appInfo: '=info'
            },
            templateUrl: function(elem, attr) {
                return NgTemplatesUrl;
            }
        };
    }
})();

//whenScrolled
(function() {
    'use strict';


    angular.module('iManage.WebSettings').directive('whenScrolled', whenScrolled);


    function whenScrolled() {
        return {
            restrict: "A",
            link: function(scope, element, attr) {
                $(element).bind('scroll', function() {
                    var scrollHeight = (($(this).scrollTop() + $(this).innerHeight()) / $(this)[0].scrollHeight) * 100.0;
                    if (scrollHeight >= 75) {
                        //scope.ScrollCounter = true;
                        scope.$apply(attr.whenScrolled);
                    }
                })
            }
        }
    }
})();

//selectRows
(function() {
    'use strict';

    angular.module('iManage.WebSettings').directive('selectRows', selectRows);

    selectRows.$inject = ['$timeout'];

    function selectRows($timeout) {
        return {
            restrict: 'C',
            link: function(scope, element, attrs) {
                $(element).on('mouseup', function(event) {
                    event.preventDefault();
                    event.stopPropagation();
                    $timeout(function() {
                        if (event.button == 2) {
                            $(event.target).contextmenu();
                            $timeout(function() {
                                $('.context-menu-container').css("left", event.clientX);
                                if (event.clientY > event.view.innerHeight / 2) {
                                    $('.context-menu-container').css("top", event.clientY - $('.context-menu-container').height());
                                } else {
                                    $('.context-menu-container').css("top", event.clientY);
                                }
                            });
                        } else {
                            $('.context-menu-container').remove();
                        }
                        scope.vmWebSettingsCtrl.SelectedDocument = scope.$eval(attrs.meta)
                        if ($(element).hasClass('selected') && event.button != 2) {
                            scope.vmWebSettingsCtrl.SelectedDocument = null;
                        }
                        $('.selected').removeClass('selected');
                        if (scope.vmWebSettingsCtrl.SelectedDocument) {
                            $(element).addClass('selected');
                            $('#mdToolBarMain').addClass('selected');
                        }
                    });

                });
            }
        }
    }
})();

//contextMenu
(function() {
    'use strict';


    angular.module('iManage.WebSettings').directive('contextMenu', contextMenu);

    contextMenu.$inject = ['$templateRequest', '$compile', '$timeout', '$filter', 'FRAMEWORK_PATHS'];

    function contextMenu($templateRequest, $compile, $timeout, $filter, FRAMEWORK_PATHS) {
        return {
            restrict: 'A',
            link: function(scope, element, attrs) {
                $templateRequest(FRAMEWORK_PATHS.DIRECTIVE_TEMPLATES + "ContextMenu.html");
                element.on("contextmenu", function(e) {
                    e.preventDefault();
                    $timeout(function() {
                        if (attrs.menuListSource) {
                            scope.contextMenuList = scope.$eval(attrs.menuListSource);
                        } else {
                            scope.contextMenuList = scope.menuList;
                        }
                        if ($('.context-menu-container').length === 0) {
                            $templateRequest(FRAMEWORK_PATHS.DIRECTIVE_TEMPLATES + "ContextMenu.html").then(function(html) {
                                if (($filter('filter')(scope.contextMenuList, { Enable: true })).length > 0) {
                                    element.parents('tbody').append($compile(html)(scope));
                                    $('.context-menu-container').css("left", e.clientX);
                                    $('.context-menu-container').css("top", e.clientY);
                                }
                            });
                        };
                    });
                });
            }
        }
    }
})();

//toolTip
(function() {
    'use strict';


    angular.module('iManage.WebSettings').directive('toolTip', toolTip);


    toolTip.$inject = ['$timeout', '$log', '$templateRequest', '$compile', 'FRAMEWORK_PATHS'];

    function toolTip($timeout, $log, $templateRequest, $compile, FRAMEWORK_PATHS) {
        return {
            restrict: 'A',
            scope: {
                displayText: '=',
                displayTooltip: '=',
                customstyle: '=',
                contentClickParam: '=',
                contentClick: '&?'
            },
            templateUrl: FRAMEWORK_PATHS.DIRECTIVE_TEMPLATES + 'ToolTip.html',
            controller: ['$scope', function($scope) {
                $scope.contentClicked = function($event) {
                    if ($event.which != 2 && $scope.contentClick) {
                        $scope.$eval($scope.contentClick)($scope.contentClickParam, $event);
                    }
                }
                $scope.stopPropagation = function(event) {
                    var isRightButtonClick = false;
                    var isRightMB = false;
                    if (event.which) {
                        isRightMB = event.which == 3;
                    } else if (event.button) {
                        isRightMB = event.button == 2;
                    }
                    if (isRightButtonClick && $scope.contentClick) {
                        event.stopPropagation();
                    }
                };
            }],
            link: function(scope, element, attr, ctrl) {
                scope.displayTooltip = "tooltiptextnone";
                scope.changeleave = function(event) {
                    scope.displayTooltip = "tooltiptextnone";
                }

                scope.change = function(event) {

                    var $e = $(event.target.parentElement),
                        h = $(event.target).height();
                    $e.css({ 'overflow': 'visible', 'white-space': 'normal', 'word-break': 'break-all' });
                    if ($(event.target).height() > h || event.target.parentElement.scrollWidth > event.target.parentElement.clientWidth) {
                        var left = 0;
                        var top = 0;
                        if (!$('#app-navigation-menu').is(":visible")) {
                            left = event.originalEvent.pageX;
                            top = event.originalEvent.pageY - 180;
                            if ($(event.target.parentElement).is("th"))
                                top = -5;
                            if ($(window).width() <= 600) {
                                top = event.originalEvent.pageY - 430;
                            }
                            if ($('.web-filters-container').is(":visible")) {
                                left = 0;
                                top = -$(event.target).height();
                            }



                        } else if ($('#app-navigation-menu').hasClass('page-sidebar-full')) {
                            left = event.originalEvent.pageX - parseInt($('.page-content').css('padding-left')) - 5;
                            top = event.originalEvent.pageY - 160;
                            if ($(event.target.parentElement).is("th"))
                                top = -5;


                        } else {
                            left = event.originalEvent.pageX - 80;
                            top = event.originalEvent.pageY - 160;
                            if ($(event.target.parentElement).is("th"))
                                top = -5;


                        }

                        scope.customstyle = "left:" + left + "px;top:" + top + "px;";
                        $(event.target.parentElement).children('span.eletooltip').css({ "left": left + "px", "top": +top + "px" });
                        scope.displayTooltip = "tooltiptext";
                    }
                    $e.css({ 'overflow': 'hidden', 'white-space': 'nowrap', 'word-break': '' });


                }

            }
        }
    }
})();

//ngFiles
(function() {
    'use strict';
    angular.module('iManage.WebSettings').directive('ngFiles', ngFiles);

    ngFiles.$inject = ['$parse'];

    function ngFiles($parse) {

        function fn_link(scope, element, attrs) {
            var onChange = $parse(attrs.ngFiles);
            element.on('change', function(event) {
                onChange(scope, { $files: event.target.files });
                event.currentTarget.value = null;
            });
        };

        return {
            link: fn_link
        }
    }
})();

//droppable
(function() {
    'use strict';

    angular.module('iManage.WebSettings').directive('droppable', droppable);
    droppable.$inject = ['$timeout'];

    function droppable($timeout) {
        var linkFn = function($scope, $element, $attrs, accept) {
            var extractFiles = function(e) {
                var files = e.dataTransfer.files;
                var filesArray = [];

                for (var i = 0, len = files.length; i < len; i++) {
                    filesArray.push(files[i]);
                }

                return filesArray;
            };

            var handleDragOver = function(e) {
                e.preventDefault();
                $element.find('.droppable-border').css("border-color", "#3B69F2");
            };

            var handleDragLeave = function(e) {
                e.preventDefault();
                $element.find('.droppable-border').css("border-color", "rgba(0, 0, 0, 0.4)");
            };

            var handleDrop = function(e) {
                e.preventDefault();
                $element.find('.droppable-border').css("border-color", "rgba(0, 0, 0, 0.4)");
                var files = extractFiles(e.originalEvent);
                $scope.dropFiles({ $files: files });
            };

            $element.on("dragover", handleDragOver);
            $element.on("dragleave", handleDragLeave);
            $element.on("drop", handleDrop);

            $scope.$on("$destroy", function() {
                $element.off("dragover", handleDragOver);
                $element.off("drop", handleDrop);
            });
        };
        return {
            restrict: "E",
            scope: {
                accepts: "&",
                dropFiles: "&",
            },
            link: linkFn,
        };
    }
}());