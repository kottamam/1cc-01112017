﻿(function() {
    'use strict';

    //define(['angular'], function (angular) {
    angular.module('iManage.WebSettings').factory('translateFactory', translateFactory);
    //});

    translateFactory.$inject = ["$q", "$timeout", "$location", "translateService", 'TSU_TRANSLATE', 'homeFactory', 'homeService'];

    function translateFactory($q, $timeout, $location, translateService, TSU_TRANSLATE, homeFactory, homeService) {

        return function(options) {
            var deferred = $q.defer(),
                translations;

            var webLocation = window.location.href.split('dialogs/');
            baseUrl = webLocation[0];
            var basePath = webLocation[0].split('imanage/');
            basePath = basePath[0].split('imcc/');
            baseIMCCApiUrl = basePath[0];
            var customerName = '1';

            getCustomerId().then(function() {
                var SystemConfig = getLocaleDefault();
                SystemConfig.then(function(responseConfig) {
                    var apiUrl = basePath[0] + 'imanage/' + TSU_TRANSLATE.GET_TRANSLATE;
                    if (responseConfig.LocaleDefault) {
                        apiUrl += "?locale=" + responseConfig.LocaleDefault;
                    }
                    var promise = translateService.getJson(apiUrl);
                    promise.then(function(response) {
                        if (response && response.data) {
                            translations = response.data;
                        }
                        deferred.resolve(translations);
                    });
                });
            });
            return deferred.promise;
        };

        function getCustomerId() {
            var deferred = $q.defer();
            var apiUrl;

            var baseUrlWithoutAPIV2 = homeFactory.getApiV2BaseUrl('', true, true);
            if (baseUrlWithoutAPIV2.indexOf('imcc/') != -1) {
                apiUrl = baseUrlWithoutAPIV2 + TSU_TRANSLATE.GET_INIT_DATA;
            } else {
                apiUrl = baseUrlWithoutAPIV2 + TSU_TRANSLATE.GET_STARTUP_INIT_DATA;
            }

            var promise = homeService.getData(apiUrl);
            promise.then(function(response) {
                if (response.status === 200 && response.data) {
                    if (response.data.customer_id && response.data.customer_id.toString().trim().length > 0) {
                        customerName = response.data.customer_id.toString();
                    } else if (response.data.data && response.data.data.customer_id && response.data.data.customer_id.toString().trim().length > 0) {
                        customerName = response.data.data.customer_id.toString();
                    }
                }
                deferred.resolve();
            });
            return deferred.promise;
        }

        function getLocaleDefault() {
            var deferred = $q.defer();

            if ($location.search().locale && $location.search().locale.toString().trim().length > 0) {
                deferred.resolve({ Status: 0, LocaleDefault: $location.search().locale });
                return deferred.promise;
            }

            if (localStorage.getItem('locale') && localStorage.getItem('locale').toString().trim().length > 0) {
                deferred.resolve({ Status: 0, LocaleDefault: localStorage.getItem('locale') });
                return deferred.promise;
            }

            var promiseDb = getPrimaryDatabase();
            promiseDb.then(function(response) {
                var apiUrl = homeFactory.getApiV2BaseUrl((response.PrimaryDB || ''), false, true);
                apiUrl += TSU_TRANSLATE.WEB_SETTINGS_URL;

                var promiseWebSetting = translateService.getJson(apiUrl);
                promiseWebSetting.then(function(responseWebSetting) {
                    var localeDefault = 'en-US';
                    if (response.LocaleDefault && response.LocaleDefault.length > 0) {
                        localeDefault = response.LocaleDefault;
                    }
                    if (responseWebSetting.status === 200 && responseWebSetting.data) {
                        if (responseWebSetting.data.general && responseWebSetting.data.general.language &&
                            responseWebSetting.data.general.language.trim().length > 0) {
                            localeDefault = responseWebSetting.data.general.language;
                        }
                    }
                    deferred.resolve({ Status: 0, LocaleDefault: localeDefault });
                });
            });
            return deferred.promise;
        }

        function getPrimaryDatabase() {
            var deferred = $q.defer();

            var baseV2Url = homeFactory.getApiV2BaseUrl('', false, false);
            var dbListUrl = baseV2Url + TSU_TRANSLATE.GET_DB_LIST;
            var promiseDataBase = translateService.getJson(dbListUrl);
            promiseDataBase.then(function(responsedb) {

                var usesrDbList = [];
                angular.forEach(responsedb.data.data, function(db) {
                    usesrDbList.push(db.id);
                });

                var apiUrl = baseV2Url + TSU_TRANSLATE.GET_SYSTEM_CONFIG;
                var promise = translateService.getJson(apiUrl);
                promise.then(function(response) {
                    var primarydbName;
                    var localeDefault = 'en-US';

                    if (response && response.data && response.data.data) {
                        if (response.data.data['Locale Default'] && response.data.data['Locale Default'].toString().trim().length > 0) {
                            localeDefault = response.data.data['Locale Default'];
                        }

                        if (response.data.data.databases && response.data.data.databases.length > 0) {
                            angular.forEach(response.data.data.databases, function(db) {
                                if (db.Primary === 'Y') {
                                    if (usesrDbList.indexOf(db.id) > -1) {
                                        primarydbName = db.id;
                                    }
                                }
                            });
                        }
                    }
                    if (!primarydbName && usesrDbList.length > 0) {
                        primarydbName = usesrDbList[0];
                    }
                    deferred.resolve({ PrimaryDB: primarydbName, LocaleDefault: localeDefault });
                }, function(response) {
                    deferred.resolve({ PrimaryDB: undefined, LocaleDefault: 'en-US' });
                });
            });
            return deferred.promise;
        }
    }

})();