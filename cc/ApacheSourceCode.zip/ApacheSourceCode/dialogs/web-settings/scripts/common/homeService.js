(function() {
    'use strict';


    angular.module('iManage.WebSettings').service("homeService", homeService);

    homeService.$inject = ['$http'];

    function homeService($http) {

        this.getData = function(apiUrl) {
            apiUrl = apiUrl + (apiUrl.indexOf('?') === -1 ? '?' : '&') + 'v=' + ((new Date()).getTime().toString());
            var promise = $http({
                url: apiUrl,
                method: "GET"
            });
            return promise;
        };

        this.putData = function(apiUrl) {
            var promise = $http({
                url: apiUrl,
                method: "PUT"
            });
            return promise;
        };

        this.putDataUsingBody = function(apiUrl, requestBody) {
            var response = $http({
                method: "PUT",
                url: apiUrl,
                data: JSON.stringify(requestBody)
            });
            return response;
        };

        this.postData = function(apiUrl) {
            var response = $http({
                method: "POST",
                url: apiUrl
            });
            return response;
        };

        this.postDataUsingBody = function(apiUrl, requestBody) {
            var response = $http({
                method: "POST",
                url: apiUrl,
                data: JSON.stringify(requestBody)
            });
            return response;
        };

        this.deleteData = function(apiUrl) {
            var response = $http({
                method: "DELETE",
                url: apiUrl
            });
            return response;
        };

        this.deleteDataUsingBody = function(apiUrl, requestBody) {
            var response = $http({
                method: "DELETE",
                url: apiUrl,
                data: JSON.stringify(requestBody)
            });
            return response;
        };

        this.patchDataUsingBody = function(apiUrl, requestBody) {
            var response = $http({
                method: "PATCH",
                url: apiUrl,
                data: JSON.stringify(requestBody)
            });
            return response;
        };

        this.getImageData = function(apiUrl) {
            var promise = $http({
                url: apiUrl,
                method: "GET",
                responseType: "blob"
            });
            return promise;
        };

        this.getJson = function(apiUrl) {
            var promise = $http({
                url: apiUrl,
                method: "GET"
            });
            return promise;
        }

        this.getlogDetails = function(URL, level, message) {
            var promise = $http({
                url: URL,
                method: "PUT",
                data: { 'Level': level, 'Message': message },
                dataType: "json"
            });
        }
    }
})();