(function() {
    'use strict';


    angular.module('iManage.WebSettings').factory('homeFactory', homeFactory);


    homeFactory.$inject = ['$http', '$q', '$state', '$filter', 'WRSU_HOME', 'CONST_HOME_CAPTIONS', 'CONST_DB', 'CONST_USERS_HOME',
        'CONST_PERMISSIONS', 'homeService'
    ];

    function homeFactory($http, $q, $state, $filter, WRSU_HOME, CONST_HOME_CAPTIONS, CONST_DB, CONST_USERS_HOME, CONST_PERMISSIONS, homeService) {
        //Management
        var selectedAppSettings = {};
        var appsVar = {};
        var requestModelDef = {};
        var requestModelDe = {};
        var captionUIModel = {};
        var databasesUIModel = {};
        var userUIModel = {};
        var userPermissionsModel = {};
        var userAreaDef = [];

        (function() {
            userAreaDef = [{ AppTypeName: "Management", visibility: true },
                { AppTypeName: "Content", visibility: true },
                { AppTypeName: "System", visibility: true }
            ];

            selectedAppSettings = {
                appType: '',
                CurrentTab: '',
                CurrentSubTab: '',
                NoAppsPermission: 'Error',
                TotalRowCount: 0,
                CurrentPageIndex: 1,
                ResponseCount: 50,
                MetaDataItem: ''
            }

            appsVar = {
                initialLoading: true,
                selectedRecordId: '',
                SearchText: '',
                CaptionsList: [],
                selectedMetaData: 'CUSTOM1',
                sortField: '',
                rightClickMenuID: '',
                tooltipValue: ''
            }

            requestModelDef = {
                libraryName: '',
                pagenumber: 1,
                pageLength: 50,
                isTotal: true,
                IsMoreRowsFound: false,
                Cursor: '',
                searchText: '',
                sortKey: '',
                sortValue: '', //,DESC
                filters: [] //[{'Key1',[{'Value1', 'Value2',etc}] },{'Key1',[{'Value1', 'Value2',etc}] }]
            }

            requestModelDe = {
                libraryName: '',
                pagenumber: 1,
                pageLength: 50,
                isTotal: true,
                IsMoreRowsFound: false,
                Cursor: '',
                searchText: '',
                sortKey: '',
                sortValue: '', //,DESC
                filters: [] //[{'Key1',[{'Value1', 'Value2',etc}] },{'Key1',[{'Value1', 'Value2',etc}] }]
            }

            captionUIModel = {
                DisplayText: '',
                MetaDataItem: '',
                isMetaItem: true,
                isallowedCreateProfile: true,
                isallowedSearchProfile: true,
                ParentMetaItem: '',
                MetaType: '',
                TagValue: 0
            };

            databasesUIModel = {
                DatabaseName: '',
                Description: '',
                M4_Bits: {
                    CustomMetadataManagement: false
                }
            };

            userUIModel = {
                UserId: '',
                FullName: '',
                Location: ''
            };

            userPermissionsModel = {
                Database: '',
                IsTier_1: false,
                IsTier_2: false,
                IsTier_3: false,
                ContentAssistance: false,
                ManageCustomMetadata: false,
                DMSJobOperations: false,
                Reporting: false,
                ReportManagement: false,
                ManageRoles: false,
                SystemJobOperations: false,
                ManageSystemMetadata: false,
                TemplateManagement: false,
                TrusteeAsistance: false,
                ManageTrustees: false,
                WebOperations: {
                    CreateSystemWorkspaces: false
                }
            }

        })();

        var returnObject = {
            selectedApp: selectedAppSettings,
            applicationVariables: appsVar,
            userArea: userAreaDef,
            requestModel: requestModelDef,
            requestModelInstance: returnrequestModelDef,
            getAPIUrl: returnAPIUrl,
            getCaptionUIModel: returnCaptionUIModel,
            getDatabaseUI: getDatabaseUIModel,
            registerComponent: RegisterView,
            getSingleUserAPI: returnSingleUserAPI,
            getUserUI: getUserUIModel,
            getDBListAPI: returnDBListAPI,
            getUserPhotoAPI: returnUserPhotoAPI,
            getLogoutAPI: returnLogoutAPI,
            getServerVersionAPI: returnServerVersionAPI,
            getUserPermissionModel: returnUserPermissionModel,
            getPrimaryDBNameAPI: returnPrimaryDBNameAPI,
            getIMCCAPIUrl: returnIMCCAPIUrl,
            getApiV1BaseUrl: returnApiV1BaseUrl,
            getApiV2BaseUrl: returnApiV2BaseUrl
        };
        return returnObject;

        function getDatabaseUIModel(dataBaseApiModel) {
            var dbModel = angular.copy(databasesUIModel);
            dbModel.DatabaseName = dataBaseApiModel[CONST_DB.DatabaseName];
            dbModel.Description = dataBaseApiModel[CONST_DB.Description];
            if (dataBaseApiModel[CONST_DB.M4_Bits] != null && dataBaseApiModel[CONST_DB.M4_Bits][CONST_DB.CustomMetadataManagement] != null)
                dbModel.M4_Bits.CustomMetadataManagement = dataBaseApiModel[CONST_DB.M4_Bits][CONST_DB.CustomMetadataManagement];
            return dbModel;
        }


        function pushNavigationMenuObject(NavigationMenuJson, settings) {
            var isParentExists = false;
            var settingsObj;
            if (NavigationMenuJson.length > 0)
                angular.forEach(NavigationMenuJson, function(appSettings) {
                    //for (var appSettingsIndex in NavigationMenuJson) {
                    //    var appSettings = NavigationMenuJson[appSettingsIndex];
                    if (appSettings.hasOwnProperty('AppsID') && appSettings.AppsID == settings.AppsID) {
                        isParentExists = true;
                        settingsObj = pushNavigationMenuObject(appSettings.childMenus, settings.childMenus[0]);
                    }
                    //}
                });
            if (!isParentExists) {
                if (settings) {
                    NavigationMenuJson.push(settings);
                }
            } else {
                if (settingsObj) {
                    NavigationMenuJson.push(settingsObj);
                }
            }
        }




        function returnrequestModelDef() {
            return angular.copy(requestModelDe);
        }

        function returnIMCCAPIUrl(APIFOR) {
            var ApiUrl = baseIMCCApiUrl + WRSU_HOME[APIFOR];
            return ApiUrl;
        }


        function returnAPIUrl(APIFOR, requestModel, userId, dbName, action) {
            var ApiUrl = WRSU_HOME[APIFOR];
            if (requestModel)
                ApiUrl = prepareUrl(ApiUrl, requestModel);
            return ApiUrl;
        }

        function prepareUrl(URL, requestModel) {
            var ApiUrl = URL + '?offset=' + ((requestModel.pagenumber - 1) * requestModel.pageLength).toString() +
                '&limit=' + requestModel.pageLength.toString() + '&total=' + requestModel.isTotal + '&language=' + requestModel[CONST_HOME_CAPTIONS.Locale];

            if (requestModel.searchText != null && requestModel.searchText != '')
                ApiUrl += '&query=*' + requestModel.searchText + '*';

            if (requestModel.filters.length > 0) {
                angular.forEach(requestModel.filters, function(filterItem) {
                    if (filterItem.FilterValues[0] != null && filterItem.FilterValues[0] != '') {
                        ApiUrl += '&' + CONST_HOME_CAPTIONS[filterItem.FilterKey + 'Filter'] + '=*' + filterItem.FilterValues[0] + '*'
                    }
                });
            }
            return ApiUrl;
        }

        function returnCaptionUIModel(captionApiModel) {
            var captionModel = angular.copy(captionUIModel)
            captionModel.DisplayText = captionApiModel[CONST_HOME_CAPTIONS.DisplayText];
            captionModel.MetaDataItem = captionApiModel[CONST_HOME_CAPTIONS.MetaDataItem].toUpperCase();
            captionModel.isMetaItem = IsMetaItem(captionApiModel.id.toUpperCase());
            captionModel.ParentMetaItem = GetParentItem(captionApiModel.id.toUpperCase());
            captionModel.Locale = (!captionApiModel[CONST_HOME_CAPTIONS.Locale]) ? 1033 : captionApiModel[CONST_HOME_CAPTIONS.Locale];
            captionModel.CaptionNum = captionApiModel[CONST_HOME_CAPTIONS.CaptionNum];
            captionModel.CaptionSS_Num = captionApiModel[CONST_HOME_CAPTIONS.CaptionSS_Num];

            return captionModel; // angular.copy(captionModel);
        }

        function IsMetaItem(item) {
            switch (item) {
                case "CUSTOM1":
                case "CUSTOM2":
                case "CUSTOM3":
                case "CUSTOM4":
                case "CUSTOM5":
                case "CUSTOM6":
                case "CUSTOM7":
                case "CUSTOM8":
                case "CUSTOM9":
                case "CUSTOM10":
                case "CUSTOM11":
                case "CUSTOM12":
                case "CUSTOM29":
                case "CUSTOM30":
                case "CLASS":
                case "SUBCLASS":
                    return true;
                default:
                    return false;
            }
        }

        function GetParentItem(item) {
            switch (item) {
                case "CUSTOM2":
                    return "CUSTOM1";
                case "CUSTOM30":
                    return "CUSTOM29";
                case "SUBCLASS":
                    return "CLASS";
                default:
                    return "";
            }
        }

        function returnSingleUserAPI(dbName, userId) {
            var apiUrl = WRSU_HOME['GET_USER'];
            //apiUrl += '?' + CONST_USERS_HOME.DataBase + '=' + dbName + '&' + CONST_USERS_HOME.Alias + '=' + userId;
            return apiUrl;
        }

        function getUserUIModel(userApiModel) {
            var userModel = angular.copy(userUIModel);
            userModel.UserId = userApiModel[CONST_USERS_HOME.UserIdEx]; //.user_id_ex;
            userModel.FullName = userApiModel[CONST_USERS_HOME.FullName];
            return userModel;
        }

        function returnDBListAPI() {
            var apiUrl = WRSU_HOME['GET_DB_LIST'];
            return apiUrl;
        }

        function returnUserPhotoAPI(userId) {
            var apiUrl = WRSU_HOME['GET_USER_PHOTO'];
            apiUrl = apiUrl.replace("<userid>", userId);
            return apiUrl;
        }

        function returnServerVersionAPI() {
            var apiUrl = WRSU_HOME['GET_SERVER_VERSION'];
            return apiUrl;
        }

        function RegisterView(settings) {
            if (!$state.get('home.' + settings.AppsTarget)) {
                angular.module('iManage.').libInjector.registerView({
                    ID: settings.AppsTarget,
                    moduleName: settings.ModuleName,
                    controller: settings.Controller,
                    viewUrl: settings.ViewUrl,
                    templateUrl: settings.TemplateUrl,
                    requirejsNames: settings.RequirejsNames,
                    requirejsConfig: settings.RequirejsConfig,
                    cssUrl: settings.cssUrl
                });
            }
        }

        function returnLogoutAPI(authToken) {
            var apiUrl = WRSU_HOME['LOGOUT_USER'];
            apiUrl = apiUrl.replace("<authtocken>", authToken);
            return apiUrl;
        }

        function returnUserPermissionModel(permissions) {
            var permission = angular.copy(userPermissionsModel);
            permission.Database = permissions[CONST_PERMISSIONS.Database];
            if (permissions.m4_bits) {
                permission.IsTier_1 = permissions.m4_bits[CONST_PERMISSIONS.IsTier_1];
                permission.IsTier_2 = permissions.m4_bits[CONST_PERMISSIONS.IsTier_2];
                permission.IsTier_3 = permissions.m4_bits[CONST_PERMISSIONS.IsTier_3];
                permission.ContentAssistance = permissions.m4_bits[CONST_PERMISSIONS.ContentAssistance];
                permission.ManageCustomMetadata = permissions.m4_bits[CONST_PERMISSIONS.ManageCustomMetadata];
                permission.DMSJobOperations = permissions.m4_bits[CONST_PERMISSIONS.DMSJobOperations];
                permission.Reporting = permissions.m4_bits[CONST_PERMISSIONS.Reporting];
                permission.ReportManagement = permissions.m4_bits[CONST_PERMISSIONS.ReportManagement];
                permission.ManageRoles = permissions.m4_bits[CONST_PERMISSIONS.ManageRoles];
                permission.SystemJobOperations = permissions.m4_bits[CONST_PERMISSIONS.SystemJobOperations];
                permission.ManageSystemMetadata = permissions.m4_bits[CONST_PERMISSIONS.ManageSystemMetadata];
                permission.TemplateManagement = permissions.m4_bits[CONST_PERMISSIONS.TemplateManagement];
                permission.TrusteeAsistance = permissions.m4_bits[CONST_PERMISSIONS.TrusteeAsistance];
                permission.ManageTrustees = permissions.m4_bits[CONST_PERMISSIONS.ManageTrustees];
            }
            if (permissions.m3_bits) {
                permission.WebOperations.CreateSystemWorkspaces = permissions.m3_bits[CONST_PERMISSIONS.CreateSystemWorkspaces];
            }
            return permission;
        }

        function returnPrimaryDBNameAPI() {
            var apiUrl = WRSU_HOME['GET_PRIMARY_DBNAME'];
            return apiUrl;
        }

        function returnApiV1BaseUrl() {
            var apiUrl = baseUrl + WRSU_HOME.API_V1_VERSION;
            return apiUrl;
        }

        function returnApiV2BaseUrl(libraryName, isExcludeCustomerName, is_remove_api_v2) {
            var apiUrl = baseUrl;

            isExcludeCustomerName = isExcludeCustomerName || false;
            is_remove_api_v2 = is_remove_api_v2 || false;
            libraryName = libraryName || '';

            if (!is_remove_api_v2) {
                apiUrl += WRSU_HOME.API_V2_VERSION;
            }
            if (!isExcludeCustomerName) {
                apiUrl += WRSU_HOME.API_V2_CUSTOMER.replace('<customer_name>', customerName);
            }
            if (libraryName != null && libraryName.trim().length > 0)
                apiUrl += WRSU_HOME.API_V2_LIBRARY.replace('<library_name>', libraryName);

            return apiUrl;
        }
    }
})();