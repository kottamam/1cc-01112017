(function() {
    'use strict';

    angular.module('iManage.WebSettings').constant('API_URL_WebFilters', {
        SEARCH_CATEGORY: 'config/fields',
        POST_CATEGORY: 'config/{CAT_NAME}',
        DELETE_CATEGORY: 'config/{CAT_NAME}',
        PUT_CATEGORY: 'config/{OLD_CAT_NAME}/{NEW_CAT_NAME}',
        POST_FILE: 'config/{CAT_NAME}/files',
        SEARCH_FILES: 'config/{CAT_NAME}/files',
        DELETE_FILE: 'config/{CAT_NAME}/files/{FILE_NAME}',
        DOWNLOAD_FILE: 'config/{CAT_NAME}/{FILE_NAME}',
        EDIT_CONFIG_FILE: 'config/field/files',
        SEARCH_GROUPS: 'groups/search',
        WEB_SETTINGS_URL: 'web/customizations',
        SEARCHCAPTIONS: "captions/search",
        GET_INIT_DATA: 'init-data',
		GET_STARTUP_INIT_DATA: 'startup/init-data',
        GET_VISIBLE_FIELD_LIST: 'forms/visible-fields?form_type=edit_document&scope=<dbname>'
    });

    angular.module('iManage.WebSettings').constant('WebFilters_FILE', {
        FileName: 'filename',
        Lastupdated: 'lastupdated',
        TYPE: 'type',
        URL: 'uri'
    });

})();