(function() {
  "use strict";

  angular
    .module("iManage.WebSettings")
    .directive("filterTabContent", filterTabContent);

  filterTabContent.$inject = [
    "$compile",
    "$templateRequest",
    "$timeout",
    "$translate",
    "$filter"
  ];

  function filterTabContent(
    $compile,
    $templateRequest,
    $timeout,
    $translate,
    $filter
  ) {
    return {
      restrict: "E",
      replace:true,
      scope: {
        filterModel: "=",
        viewMode: "=",
        filterNew:"=",
        disableEdit:"=",
      },
      templateUrl: "scripts/web-filters/filtertabcontent.html",
      controller: [
        "$scope",
        "$element",       
        filterTabContentController
      ]
    };

    function filterTabContentController($scope, $element) {
      if(!$scope.filterModel)
        $scope.filterModel=[];
          $scope.filterModel.EditMode = false;
          $scope.OrginalItem = undefined;
          $scope.Title ='WebSettings.Filters.'+ $scope.viewMode;
         
          $scope.OpenEditMode = OpenEditMode;
          $scope.addCustomField=addCustomField;
          $scope.CustomFieldChange = CustomFieldChange;
          $scope.removeElement = removeElement;
          $scope.saveFilter = saveFilter;
          $scope.cancelFilter = cancelFilter;

          function OpenEditMode() {
            if($scope.disableEdit)
              return;
            $scope.filterModel.EditMode = true;
            $scope.OrginalItem = angular.copy($scope.filterModel);
            $scope.OrginalMissing = angular.copy($scope.filterNew);
            $scope.NewOrMissing=angular.copy($scope.filterNew);
          }   

        function addCustomField() {
           
            $scope.filterModel.push({ 'type': 'custom', 'DisplayText':   $scope.NewOrMissing[0].DisplayText,   'value': $scope.NewOrMissing[0].value });
             $scope.NewOrMissing.splice(0, 1)
            
        }

        function CustomFieldChange(currentItem,olditem, index) {
          if(currentItem !=olditem.value){ 
          $scope.NewOrMissing.push({ 'DisplayText':   $scope.filterModel[index].DisplayText,   'value':   $scope.filterModel[index].value});
          $scope.filterModel.splice(index, 1,{ 'type': 'custom', 'DisplayText':   currentItem,   'value': currentItem});
          var selectedItem = $filter('filter')($scope.NewOrMissing, { value:currentItem }, true);
         
            $scope.NewOrMissing.splice($scope.NewOrMissing.indexOf(selectedItem[0]), 1);
       
          }
        
         }

          function removeElement(index,item) {
         $scope.filterModel.splice(index, 1);
         $scope.NewOrMissing.push({ 'DisplayText':   item.DisplayText,   'value': item.value});
        
          }


           function saveFilter() {
               $scope.filterModel.EditMode = false;
            
           $scope.filterNew = angular.copy($scope.NewOrMissing); 
    }

      function cancelFilter() {

           $scope.filterModel.EditMode = false;
           $scope.filterModel= $scope.OrginalItem;
           $scope.filterNew= $scope.OrginalMissing;
           $scope.NewOrMissing=angular.copy($scope.filterNew);

       
    }

    
  
   /*   //variables
     
    

      //Functions
      $scope.OpenEditMode = OpenEditMode;
      $scope.Addseparator = Addseparator;
      $scope.RemoveItem = RemoveItem;
      $scope.CancelChanges = CancelChanges;
      $scope.UpdatePreview = UpdatePreview;
      $scope.AddSelectedItem=AddSelectedItem;


      $scope.$watch(function($scope) { return $('.nested-div.child-div-editmode').length },
              function(newValue, oldValue) { 
                console.log($element);
                if($scope.cmModel)                  
                    $scope.cmModel.ChildEditing = newValue!=0 && !($('.nested-div.child-div-editmode').scope() && $('.nested-div.child-div-editmode').scope().cmModel && $('.nested-div.child-div-editmode').scope().cmModel.children==$scope.cmModel);
              }
              //edited-imparent
             );
      

        $scope.$watch(function($scope) { return $scope.cmModel && $scope.cmModel.EditMode },
              function(newValue, oldValue) { 
            if(newValue){
               if($element.closest('.nested-div').closest('.filter-box').closest('div').length>0){
                   if($element.closest('.nested-div').closest('.filter-box').closest('div').scope().$parent.$parent.cmModel)
                 { 
                      $scope.OrginalParentItem = angular.copy($element.closest('.nested-div').closest('.filter-box').closest('div').scope().$parent.$parent.cmModel); 
                      $scope.OrginalParentItem.EditMode=$element.closest('.nested-div').closest('.filter-box').closest('div').scope().$parent.$parent.cmModel.EditMode;
                      $scope.OrginalParentItem.ChildEditing=$element.closest('.nested-div').closest('.filter-box').closest('div').scope().$parent.$parent.cmModel.ChildEditing;
                 }else   if($element.closest('.nested-div').closest('.filter-box').closest('div').scope().$parent.cmModel){
                    $scope.OrginalParentItem = angular.copy($element.closest('.nested-div').closest('.filter-box').closest('div').scope().$parent.cmModel); 
                      $scope.OrginalParentItem.EditMode=$element.closest('.nested-div').closest('.filter-box').closest('div').scope().$parent.cmModel.EditMode;
                      $scope.OrginalParentItem.ChildEditing=$element.closest('.nested-div').closest('.filter-box').closest('div').scope().$parent.cmModel.ChildEditing;
              
                 }
              } 
            }
            }
              //edited-imparent
             );
      

    

      function RemoveItem(index) {
        if($scope.cmModel[index].type!='separator')
           $scope.cmMissing.push(angular.copy($scope.cmModel[index]));

        $scope.cmModel.splice(index, 1);
      }

      function Addseparator(index) {
        index = index + 1;
        $scope.cmModel.splice(index, 0, {
        id: "wsCommandSeparator", type: "separator"
        });
      }

       function AddSelectedItem(item) {
         if(item){
        var selectedItem = $filter('filter')($scope.cmMissing, { id:item }, true);
         if(selectedItem.length>0)
       var index= $scope.cmMissing.indexOf(selectedItem[0]);
       $scope.cmModel.push(angular.copy(selectedItem[0]));
        $scope.cmMissing.splice(index, 1);
         }
      }

      function CancelChanges() {
       
      
         if($element.closest('.nested-div').closest('.filter-box').closest('div').length>0){
            if($element.closest('.nested-div').closest('.filter-box').closest('div').scope().$parent.$parent.cmModel)
              $element.closest('.nested-div').closest('.filter-box').closest('div').scope().$parent.$parent.cmModel  = $scope.OrginalParentItem; 
        
        }

         $scope.cmModel.EditMode = false;
        $scope.cmModel = $scope.OrginalItem;
        $scope.cmMissing = angular.copy($scope.OrginalMissing); 

      }
      function UpdatePreview() {
        $scope.cmModel.EditMode = false;
      }*/
    }
  }
})();

 