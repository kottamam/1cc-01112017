angular.module('iManage.WebSettings').controller("WebFiltersController", WebFiltersController);
WebFiltersController.$inject = ['$scope', '$filter', '$timeout', '$mdDialog', '$mdMedia', '$q', '$translate', '$window', '$location',  
    'homeFactory', 'homeService', 'WebFiltersFactory', 'WebFiltersService'
];

function WebFiltersController($scope, $filter, $timeout, $mdDialog, $mdMedia, $q, $translate, $window, $location,  
    homeFactory, homeService, WebFiltersFactory, WebFiltersService) {

     
    var requestModel = homeFactory.requestModelInstance();
    var baseV2Url = '';

    $scope.ActiveTabMapping={
        'DOCUMENTS':'documents',
        'EMAILS':'emails',
        'CLIENTS':'clients',
        'MATTERS':'workspace'
    };
     $scope.ActiveTabUIMapping={
        'DOCUMENTS':'Documents',
        'EMAILS':'Emails',
        'CLIENTS':'Clients',
        'MATTERS':'Matters'
    };
    $scope.FinalJson={};   
    $scope.Documents = {};
    $scope.Emails = {};
    $scope.Matters = {};
    $scope.Clients = {};
    $scope.DefultValues={
        Documents:{
        recentView : [
			{ 'type': 'default', 'DisplayText': 'WebSettings.list', 'iconName': 'list', 'value': 'list' },
            { 'type': 'default', 'DisplayText': 'WebSettings.Filters.activities', 'iconName': 'activities', 'value': 'activities' },
            { 'type': 'default', 'DisplayText': 'WebSettings.Filters.database', 'iconName': 'database', 'value': 'database' },
            { 'type': 'default', 'DisplayText': 'WebSettings.Filters.date', 'iconName': 'date', 'value': 'date' },
            { 'type': 'default', 'DisplayText': 'WebSettings.Filters.fileType', 'iconName': 'filetype', 'value': 'fileType' }
        ],
        browseView : [
			{ 'type': 'default', 'DisplayText': 'WebSettings.list', 'iconName': 'list', 'value': 'list' },
            { 'type': 'default', 'DisplayText': 'WebSettings.Filters.database', 'iconName': 'database', 'value': 'database' },
            { 'type': 'default', 'DisplayText': 'WebSettings.Filters.date', 'iconName': 'date', 'value': 'date' },
            { 'type': 'default', 'DisplayText': 'WebSettings.Filters.fileType', 'iconName': 'filetype', 'value': 'fileType' },
            { 'type': 'default', 'DisplayText': 'WebSettings.Filters.author/operator', 'iconName': 'authoroperator', 'value': 'author/operator' }
        ]         
    },
        Emails:{
             recentView : [
            { 'type': 'default', 'DisplayText': 'WebSettings.recentEmails', 'iconName': 'mail', 'value': 'mail' },
            { 'type': 'default', 'DisplayText': 'WebSettings.Filters.database', 'iconName': 'database', 'value': 'database' },
            { 'type': 'default', 'DisplayText': 'WebSettings.Filters.date', 'iconName': 'date', 'value': 'date' },
            { 'type': 'default', 'DisplayText': 'WebSettings.attachment', 'iconName': 'attachment', 'value': 'attachment' },
            { 'type': 'default', 'DisplayText': 'WebSettings.sender', 'iconName': 'sender', 'value': 'sender' }
        ],
        browseView : [
            { 'type': 'default', 'DisplayText': 'WebSettings.recentEmails', 'iconName': 'mail', 'value': 'mail' },
            { 'type': 'default', 'DisplayText': 'WebSettings.Filters.database', 'iconName': 'database', 'value': 'database' },
            { 'type': 'default', 'DisplayText': 'WebSettings.Filters.date', 'iconName': 'date', 'value': 'date' },
            { 'type': 'default', 'DisplayText': 'WebSettings.attachment', 'iconName': 'attachment', 'value': 'attachment' },
            { 'type': 'default', 'DisplayText': 'WebSettings.sender', 'iconName': 'sender', 'value': 'sender' }
        ]
        },
        Clients:{
          recentView : [
            { 'type': 'default', 'DisplayText': 'WebSettings.Filters.database', 'iconName': 'database', 'value': 'database' },
            { 'type': 'default', 'DisplayText': 'WebSettings.Filters.date', 'iconName': 'date', 'value': 'date' }
        ],
        browseView : []
        },
        Matters:{
               recentView : [
            { 'type': 'default', 'DisplayText': 'WebSettings.list', 'iconName': 'list', 'value': 'list' },
            { 'type': 'default', 'DisplayText': 'WebSettings.Filters.database', 'iconName': 'database', 'value': 'database' },
            { 'type': 'default', 'DisplayText': 'WebSettings.Filters.date', 'iconName': 'date', 'value': 'date' },
        ],
         browseView : [
            { 'type': 'default', 'DisplayText': 'WebSettings.Filters.database', 'iconName': 'database', 'value': 'database' },
        ]
        }
    };
    $scope.CustomCollection = [];
    $scope.RestoreFilters = RestoreFilters;
    $scope.SaveWebFilters = SaveWebFilters;   
    $scope.IsPostingData = false;
    $scope.IsRestorePostingData = false;
    $scope.Features = {};
    $scope.Features.EnableAdditionalTab = false;
    var lblConfirmation, lblWarning, lblSuccess, lblYes, lblNo, lblOk, SavedSuccessfully, RestoredSuccessfully;   
   
    $scope.alertMsg = "";
    var alertTimeout;
    $scope.removeToast = removeToast;
    var responseDefaultSettings = {};
    $scope.DBList = [];

    $timeout(function() {
        $(window).scrollTop(0);
    });

    initalize();

    function initalize() {
         RestoreToDefaults();
        getParams().then(function(response) {
            getCaptions();
            showProgressDialog();
            getDBList().then(function(response){
                $scope.DBList = response;
            });
            // = homeService.getData();
            var baseV2URL = homeFactory.getApiV2BaseUrl($location.search().library);
            var promiseVisibleFileds = WebFiltersService.getData('scripts/web-filters/data/mapping.json');              
            var promiseWebsettings = GetWebSettings();
            $q.all([promiseVisibleFileds, promiseWebsettings]).then(function(response) {
                
                if (response[0].status == 200) {
                    $scope.CustomCollection = [];
                     angular.forEach(response[0].data.data, function(fields) {
                         
                             $scope.CustomCollection.push({ 'DisplayText': fields, 'value': fields })
                        
                    });
                    
                } 
                
                  setAdditionalTab(response[1].data);
                     SetFilterSettings(response[1].data);
                
                 $scope.ActiveTab = "DOCUMENTS";
                $mdDialog.hide();
            });
            

           
        });
        $(window).scrollTop(0);


    }

    function setAdditionalTab(responseData){
           if (responseData && responseData.features) {
            if (responseData.features.additional_tab) {
                if (responseData.features.additional_tab.enable_additional_tab != undefined)
                    $scope.Features.EnableAdditionalTab = responseData.features.additional_tab.enable_additional_tab;
                if (responseData.features.additional_tab.metadata != undefined)
                    $scope.Features.Metadata = responseData.features.additional_tab.metadata;

                if (responseData.features.additional_tab.image_number != undefined)
                    $scope.Features.IconNumber = responseData.features.additional_tab.image_number;

            }
        }
    }

    function RestoreToDefaults() {
        $translate('WebSettings.Filters.doYouWantToSaveTheChanges').then(function(translatedValue) {
            lblConfirmation = translatedValue;
        });

        $translate('WebSettings.warning').then(function(translatedValue) {
            lblWarning = translatedValue;
        });
        $translate('success').then(function(translatedValue) {
            lblSuccess = translatedValue;
        });
        $translate('yes').then(function(translatedValue) {
            lblYes = translatedValue;
        });

        $translate('no').then(function(translatedValue) {
            lblNo = translatedValue;
        });

        $translate('ok').then(function(translatedValue) {
            lblOk = translatedValue;
        });
        $translate('WebSettings.Filters.savedSuccessfully').then(function(translatedValue) {
            SavedSuccessfully = translatedValue;
        });
        $translate('WebSettings.Filters.restoredSuccessfully').then(function(translatedValue) {
            RestoredSuccessfully = translatedValue;
        });     
       
    }

   

    function showProgressDialog(progressMessage) {
        if (!progressMessage) progressMessage = '';
        if ($('#dvProgressContent').length > 0) {
            if (progressMessage.trim().length > 0) {
                $('#dvProgressContent').html('<span id="spanProgressContent" class="apply-progress-msg">' + progressMessage + '</span>');
            }
        } else {
            $mdDialog.show({
                parent: angular.element(document.body),
                template: '<md-dialog ng-cloak height="100%" style="min-width: 1px !important;"><md-dialog-content class="apply-progress-dialog">' +
                    '<div id="dvProgressContent" class="md-dialog-content-clearpadding"><md-progress-circular md-mode="indeterminate"></md-progress-circular>' +
                    (progressMessage.trim().length > 0 ? ('<span id="spanProgressContent" class="apply-progress-msg">' + progressMessage + '</span>') : '') +
                    '</div></md-dialog-content></md-dialog>'
            }).then(function() {});
        }
    }

    function getParams() {
        var deferred = $q.defer();
        $scope.SelectedLibrary = $location.search().library;
        getCustomerId().then(function(response) {
            baseV2Url = homeFactory.getApiV2BaseUrl($scope.SelectedLibrary);
            deferred.resolve();
        });
        return deferred.promise;
    }

    function getCustomerId() {
        var deferred = $q.defer();
        var apiUrl;

        var baseUrlWithoutAPIV2 = homeFactory.getApiV2BaseUrl('', true, true);
        if (baseUrlWithoutAPIV2.indexOf('imcc/') != -1) {
            apiUrl = baseUrlWithoutAPIV2 + WebFiltersFactory.getInitDataAPI();
        } else {
            apiUrl = baseUrlWithoutAPIV2 + WebFiltersFactory.getStartupInitDataAPI();
        }

        var promise = homeService.getData(apiUrl);
        promise.then(function(response) {
            customerName = '1'; 
            if (response.status === 200 && response.data) {
                if (response.data.customer_id && response.data.customer_id.toString().trim().length > 0) {
                    customerName = response.data.customer_id.toString();
                } else if (response.data.data && response.data.data.customer_id && response.data.data.customer_id.toString().trim().length > 0) {
                    customerName = response.data.data.customer_id.toString();
                }
            }
            deferred.resolve();
        });
        return deferred.promise;
    }

    function getDefaultLocale() {
        var deferred = $q.defer();

        if ($location.search().locale && $location.search().locale.toString().trim().length > 0) {
            deferred.resolve({ Status: 0, LocaleDefault: $location.search().locale });
            return deferred.promise;
        }

        if (localStorage.getItem('locale') && localStorage.getItem('locale').toString().trim().length > 0) {
            deferred.resolve({ Status: 0, LocaleDefault: localStorage.getItem('locale') });
            return deferred.promise;
        }

        var promiseWebSetting = GetWebSettings();
        promiseWebSetting.then(function(responseWebSettings) {
            if (responseWebSettings.status === 200 && responseWebSettings.data && responseWebSettings.data.general &&
                responseWebSettings.data.general.language && responseWebSettings.data.general.language.trim().length > 0) {
                deferred.resolve({ Status: 0, LocaleDefault: responseWebSettings.data.general.language });
            } else {
                var baseURL = homeFactory.getApiV2BaseUrl();
                var apiUrl = homeFactory.getServerVersionAPI();
                var promise = homeService.getData(baseURL + apiUrl);
                promise.then(function(response) {
                    if (response && response.data && response.data.data && response.data.data['Locale Default']) {
                        deferred.resolve({ Status: 0, LocaleDefault: response.data.data['Locale Default'] });
                    } else {
                        deferred.resolve({ Status: 0, LocaleDefault: 'en-US' });
                    }
                });
            }
        });
        return deferred.promise;
    }

    function getCaptions() {

        var promise = getDefaultLocale();
        promise.then(function(localeLanguage) {
            var caprequestModel = homeFactory.requestModelInstance();
            caprequestModel.libraryName = $scope.SelectedLibrary;
            caprequestModel.isTotal = true;
            caprequestModel.searchText = '';
            caprequestModel.pageLength = 1000;
            caprequestModel.language =  localeLanguage.LocaleDefault;

            var apiUrl = WebFiltersFactory.getAPIUrl('SEARCHCAPTIONS', caprequestModel);
            $scope.mc.getlogDetails("Debug", 'Requested Api Url:' + JSON.stringify(apiUrl));
            var promise = homeService.getData(baseV2Url + apiUrl);
            promise.then(function(response) {
                $scope.CaptionsList = [];
                if (response && response.data && response.data.data) {                    
                        angular.forEach(response.data.data, function(caption) {
                            $scope.CaptionsList.push(homeFactory.getCaptionUIModel(caption));
                        });
                    
                }
            });
        });
    }

    

    bindEvent(window, 'message', function(e) {
        if(e.data=='App_Change'){
        CheckForChanges($scope.ActiveTab).then(function(){
            sendMessage(true);
        }); }else if(e.data=='RELOAD'){
            initalize();
        }else{
            sendMessage(true);
        }        
    });

     function CheckForChanges(InTab) {
           var promiseSave = $q.defer();
         if(InTab)
        { 
        var APISectionModel= $scope.ActiveTabMapping[InTab];
        var UISectionModel= $scope.ActiveTabUIMapping[InTab];

        var recentview=[];        
        var browseview=[];
        angular.forEach($scope[UISectionModel].recentView, function(item) {
              recentview.push(item.value)
          });
           angular.forEach($scope[UISectionModel].browseView, function(item) {
              browseview.push(item.value)
          });
          var JSONChanged=false;
          var filterJson=angular.copy($scope.FinalJson.filters);
          if(!filterJson || filterJson && !filterJson[APISectionModel] || filterJson && filterJson[APISectionModel] && !filterJson[APISectionModel][$scope.SelectedLibrary]){
             var drecentview=[];        
        var dbrowseview=[];
        angular.forEach($scope.DefultValues[UISectionModel].recentView, function(item) {
              drecentview.push(item.value)
          });
           angular.forEach($scope.DefultValues[UISectionModel].browseView, function(item) {
              dbrowseview.push(item.value)
          });
             JSONChanged= ((!angular.equals(drecentview, recentview)) || (!angular.equals(dbrowseview, browseview)));
        
          }else{
            JSONChanged= ((filterJson[APISectionModel][$scope.SelectedLibrary].recentview && !angular.equals(filterJson[APISectionModel][$scope.SelectedLibrary].recentview, recentview)) 
                             || (filterJson[APISectionModel][$scope.SelectedLibrary].browseview && !angular.equals(filterJson[APISectionModel][$scope.SelectedLibrary].browseview, browseview)))
          }
          if (!$scope.IsPostingData && JSONChanged) {
               
            
        var confirmDocumentSave = $mdDialog.confirm()
            .title(lblWarning)
            .theme('confirm-dialog')
            .textContent(lblConfirmation)
            .ariaLabel(lblWarning)
            .ok(lblYes)
            .cancel(lblNo);
        $mdDialog.show(confirmDocumentSave).then(function() {
             SaveWebFilters(InTab).then(function(){                   
                promiseSave.resolve();
            })
        }, function() {
          
            SetFilterSettings($scope.FinalJson);
    
            promiseSave.resolve();
        });
         }else{
              
                promiseSave.resolve();
            }
        }else
        {
              promiseSave.resolve();
        }
            
        return promiseSave.promise;
    }
    

    $scope.onTabChanges = TabChanged;
    
    function TabChanged(currentTabIndex) {
        
        var promiseSave = $q.defer();
        var SavedActiveTab = $scope.ActiveTab;
        $scope.ActiveTab = currentTabIndex;
         if ($scope.IsPostingData == true)
            return;
         CheckForChanges(SavedActiveTab).then(function(){
                 promiseSave.resolve();
         })
        
       
    
      
        return promiseSave.promise;
    };

    function SetFilterSettings(responseData) {
       if(responseData)
         responseData=responseData.filters
          
            angular.forEach($scope.ActiveTabUIMapping,function(value,key){
                 if (responseData && responseData[$scope.ActiveTabMapping[key]] && responseData[$scope.ActiveTabMapping[key]][$scope.SelectedLibrary]) {
                var CurrentItems=responseData[$scope.ActiveTabMapping[key]][$scope.SelectedLibrary];
               var RItems=CurrentItems.recentview;
                
                if(RItems){
                     $scope[value].recentView=[];
                     angular.forEach(RItems,function(item){
                            if (item.indexOf('custom') !== -1) {
                                    $scope[value].recentView.push({ 'type': 'custom', 'DisplayText':   item,   'value': item });
                             } else {
                                     $scope[value].recentView.push({ 'type': 'default', 'DisplayText': 'WebSettings.Filters.' + item, 'iconName': item.replace('/', ''), 'value': item });
                             }                       
        
                     });                 
                    }
                 var BItems=CurrentItems.browseview;
                if(BItems){
                     $scope[value].browseView=[];
                     angular.forEach(BItems,function(item){
                        if (item.indexOf('custom') !== -1) {
                                    $scope[value].browseView.push({ 'type': 'custom', 'DisplayText':   item,   'value': item });
                             } else {
                                     $scope[value].browseView.push({ 'type': 'default', 'DisplayText': 'WebSettings.Filters.' + item, 'iconName': item.replace('/', ''), 'value': item });
                             }
                         
                     });                    
                    }
                 }else{
                     
             $scope[value] =angular.copy($scope.DefultValues[value]);       
        
                 } 
              $scope[value].recentMissing = $scope.CustomCollection.filter(function(result1){                 
              return !$scope[value].recentView.some(function(result2){
                   return result1.value === result2.value;          
                });
                });  
             $scope[value].browseMissing = $scope.CustomCollection.filter(function(result1){               
              return !$scope[value].browseView.some(function(result2){
                   return result1.value === result2.value;  
                });
                }); 
                
            });
        
    }
  

    function GetWebSettings() {
        
        var deferred = $q.defer();
        var baseUrl = homeFactory.getApiV2BaseUrl($scope.SelectedLibrary, false, true);
        var apiUrl = baseUrl + WebFiltersFactory.getWebSettings();
        var promise = WebFiltersService.getData(apiUrl);
        promise.then(function(response) {
            $scope.FinalJson=response.data;
            deferred.resolve(response);
        }, function(response) {

            deferred.resolve(response);
        });
        return deferred.promise;

    }

  
      function RestoreFilters() {
            $scope[$scope.ActiveTabUIMapping[$scope.ActiveTab]] = angular.copy($scope.DefultValues[$scope.ActiveTabUIMapping[$scope.ActiveTab]]);  
            $scope.IsPostingData = true;
            $scope.IsRestorePostingData = true;
            SaveWebFilters();
      }

    function SaveWebFilters(tabName) {
        var deferred = $q.defer();
       
        $scope.IsPostingData = true;
        var SaveTab= tabName || $scope.ActiveTab;      
        GetWebSettings().then(function(response) {
            var responseDefaultSettings = {};
            if (response.status == 200) {
                responseDefaultSettings = response.data;
            }
            if (responseDefaultSettings.filters === undefined || responseDefaultSettings.filters.length <= 0)
                responseDefaultSettings.filters = {};



        var APISectionModel= $scope.ActiveTabMapping[SaveTab];
        var UISectionModel= $scope.ActiveTabUIMapping[SaveTab];

        if(!responseDefaultSettings.filters[APISectionModel])
        {
            responseDefaultSettings.filters[APISectionModel]={};
        }
        if(!responseDefaultSettings.filters[APISectionModel][$scope.SelectedLibrary])
        {
            responseDefaultSettings.filters[APISectionModel][$scope.SelectedLibrary]={};
        }
         delete responseDefaultSettings.filters[APISectionModel].recentview;
         delete responseDefaultSettings.filters[APISectionModel].browseview;       
        responseDefaultSettings.filters[APISectionModel][$scope.SelectedLibrary].recentview=[];        
        responseDefaultSettings.filters[APISectionModel][$scope.SelectedLibrary].browseview=[];
        angular.forEach($scope[UISectionModel].recentView, function(item) {
              responseDefaultSettings.filters[APISectionModel][$scope.SelectedLibrary].recentview.push(item.value)
          });
           angular.forEach($scope[UISectionModel].browseView, function(item) {
              responseDefaultSettings.filters[APISectionModel][$scope.SelectedLibrary].browseview.push(item.value)
          });
              ApplytoAllDb(responseDefaultSettings,APISectionModel).then(function(finalBody){
                           
             PostWebSettings(finalBody).then(function(response) {
                if (response.status == 201) {
                   $scope.FinalJson=responseDefaultSettings;
                    SetFilterSettings(responseDefaultSettings);
                }
                 deferred.resolve(response);
            });
              });

        });
        return deferred.promise;
    }

   function ApplytoAllDb(RequestBody,SaveTab){
            var deferred=$q.defer();
            if($scope.applyInAllDB && RequestBody.filters){
                //var apiUrl=homeFactory.getApiV2BaseUrl('')+homeFactory.getDBListAPI();
                //homeService.getData(apiUrl).then(function(response){
                getDBList().then(function(response){
                    if(response.length > 0){
                         angular.forEach(response, function(item){
                                 
                       
                         
                        

        
       
            RequestBody.filters[SaveTab][item.id] = RequestBody.filters[SaveTab][$scope.SelectedLibrary];
       
       
       
      
      


                            });
                    } 
                     deferred.resolve(RequestBody);
                    
                },function(response){
                     deferred.resolve(RequestBody);
                }
                );
                   
            }else{
                deferred.resolve(RequestBody);
            }
            return deferred.promise;
        }


       function PostWebSettings(Body) {
        if (Body.filters === undefined || Body.filters <= 0) {
            $scope.IsPostingData = false;
            $scope.IsRestorePostingData = false;
            return;
        }
        
        var deferred = $q.defer();
        var baseUrl = homeFactory.getApiV2BaseUrl($scope.SelectedLibrary, false, true);
        var apiUrl = baseUrl + WebFiltersFactory.getWebSettings();
        var promise = WebFiltersService.postWithBody(Body, apiUrl);
        promise.then(function(response) {
            if (response && response.status == 201) {
                if ($scope.IsPostingData && !$scope.IsRestorePostingData)
                    $scope.alertMsg = SavedSuccessfully;
                if ($scope.IsRestorePostingData)
                    $scope.alertMsg = RestoredSuccessfully;
                $scope.mc.getlogDetails("Info", 'Response:Success');
                $('div#toastPopup').addClass('show');
            } else {
                $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                
            }
            $timeout.cancel(alertTimeout);
            $timeout(function() {
                $('div#toastPopup').attr('class', '');
                $scope.alertMsg = '';
            }, 2000);
            $scope.IsRestorePostingData = false;
            $scope.IsPostingData = false;
            deferred.resolve(response);
        }, function(response) {
            $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
            deferred.resolve(response);
        });
       
        return deferred.promise;

    }    
    function bindEvent(element, eventName, eventHandler) {
        if (element.addEventListener) {
            element.addEventListener(eventName, eventHandler, false);
        } else if (element.attachEvent) {
            element.attachEvent('on' + eventName, eventHandler);
        }
    }

    var sendMessage = function (msg) {
        window.parent.postMessage(msg, '*');
    };

    
    function removeToast() {
        $('div#toastPopup').attr('class', '');
    } 

    function getDBList(){
        var deferred = $q.defer();
        var apiUrl=homeFactory.getApiV2BaseUrl('')+homeFactory.getDBListAPI();
            homeService.getData(apiUrl).then(function(response){
                if(response.data.data){
                    deferred.resolve(response.data.data);
                } else{
                    deferred.resolve([]);
                }
                    
            },function(response){
                     deferred.resolve([]);
            });
        return deferred.promise;
    }
}

 