(function() {
    'use strict';


    angular.module('iManage.WebSettings').factory('WebFiltersFactory', WebFiltersFactory);
    WebFiltersFactory.$inject = ['$q', 'API_URL_WebFilters', 'WebFilters_FILE', 'WRSU_HOME'];

    function WebFiltersFactory($q, WRSU_CONFIG, CONST_FILE, WRSU_HOME) {
        var FilterUIModel = {
            'type': '',
            'DisplayText': '',
            'iconName': '',
            'value': ''
        };
        var returnObject = {
            getCaptionsAPI: returngetCaptionsAPI,
            getWebSettings: getWebSettingsURL,
            getAPIUrl: returnAPIUrl,
            getInitDataAPI: returnInitDataAPI,
            getVisibleFieldsUrl: returnVisibleFields,
			getStartupInitDataAPI: returnStartupInitDataAPI
        };
        return returnObject;

        function returnInitDataAPI() {
            var apiUrl = WRSU_CONFIG.GET_INIT_DATA;
            return apiUrl;
        }
		
		function returnStartupInitDataAPI() {
            var apiUrl = WRSU_CONFIG.GET_STARTUP_INIT_DATA;
            return apiUrl;
        }

        function returngetCaptionsAPI(requestModel) {
            var ApiUrl = WRSU_CONFIG['SEARCHCAPTIONS'];
            ApiUrl += "?offset=" + ((requestModel.pagenumber - 1) * requestModel.pageLength).toString() +
                '&limit=' + requestModel.pageLength.toString() + '&total=' + requestModel.isTotal;

            return ApiUrl;
        }


        function getWebSettingsURL() {
            var ApiUrl = WRSU_CONFIG['WEB_SETTINGS_URL'];
            return ApiUrl;
        }

        function returnAPIUrl(APIFOR, requestModel) {
            var ApiUrl = WRSU_HOME[APIFOR];
            if (requestModel)
                ApiUrl = prepareUrl(ApiUrl, requestModel);
            return ApiUrl;
        }

        function prepareUrl(URL, requestModel) {
            var ApiUrl = URL + '?offset=' + ((requestModel.pagenumber - 1) * requestModel.pageLength).toString() +
                '&limit=' + requestModel.pageLength.toString() + '&total=' + requestModel.isTotal + '&language=' + requestModel.language;

            return ApiUrl;
        }

        function returnVisibleFields(DbName) {
            var ApiUrl = WRSU_CONFIG['GET_VISIBLE_FIELD_LIST'];
            ApiUrl = ApiUrl.replace('<dbname>', DbName);
            return ApiUrl;
        }
    }


})();