angular.module('iManage.WebSettings').controller("WebContextController", WebContextController);
WebContextController.$inject = ['$scope', '$filter', '$timeout', '$mdDialog', '$mdMedia', '$q', '$translate', '$window', '$location',  
    'homeFactory', 'homeService', 'WebSettingsFactory', 'WebSettingsService', 'WebContextFactory'
];

function WebContextController($scope, $filter, $timeout, $mdDialog, $mdMedia, $q, $translate, $window, $location,  
    homeFactory, homeService, WebSettingsFactory, WebSettingsService, WebContextFactory) {

    var vmContextCtrl = this;    
    var baseV2Url = '';
    vmContextCtrl.CaptionsList = [];
    vmContextCtrl.CategoryConstants={
     DOCUMENTS:'document',
     EMAILS:'email',
     CLIENTS:'client',
     VERSIONS:'version',
     FOLDERS:'folder',
     MATTERS:'workspace'
    };
   
    vmContextCtrl.OrginalItems={};
    vmContextCtrl.AdditionalItems={
        DOCUMENTS:['DOCUMENTS','VERSIONS'],
        EMAILS:['EMAILS'],
        CLIENTS:['CLIENTS'],
        VERSIONS:['VERSIONS'],
        FOLDERS:['FOLDERS'],
        MATTERS:['MATTERS']
    };

    vmContextCtrl.Features = {};
    vmContextCtrl.Features.EnableAdditionalTab = false;
  
    vmContextCtrl.SaveWebSettings = saveWebSettings;
    vmContextCtrl.SaveDefaults=SaveDefaults;
    vmContextCtrl.isRestoringData = false;
    
    vmContextCtrl.removeToast = removeToast;
    var localeValue='en-US';
  
    vmContextCtrl.IsPostingData = false;
   
   

    var lblConfirmation, lblWarning, lblYes, lblNo, lblSuccess, lblOk;

    $translate('WebSettings.doYouWantToSaveTheChanges').then(function(translatedValue) {
        lblConfirmation = translatedValue;
    });

    $translate('WebSettings.warning').then(function(translatedValue) {
        lblWarning = translatedValue;
    });
    $translate('yes').then(function(translatedValue) {
        lblYes = translatedValue;
    });

    $translate('no').then(function(translatedValue) {
        lblNo = translatedValue;
    });

    $translate('success').then(function(translatedValue) {
        lblSuccess = translatedValue;
    });

    $translate('ok').then(function(translatedValue) {
        lblOk = translatedValue;
    });

    
    $timeout(function() {
        $(window).scrollTop(0);
    });

    initalize();

    function initalize() {
        $(window).scrollTop(0);
        showProgressDialog();
        getParams().then(function(response) {
         
                vmContextCtrl.ActiveTab = 'DOCUMENTS';
                
                     
                   angular.forEach(vmContextCtrl.AdditionalItems[vmContextCtrl.ActiveTab], function (UIObject) {
                   
                   var category=vmContextCtrl.CategoryConstants[UIObject];
                   var websettingspromise= GetWebSettings();
                   var getmenuspromise= getmenusandExtensions(category);
                    var getmissingpromise= getmenusandmissing(category);
                $q.all([getmenuspromise,getmissingpromise,websettingspromise]).then(function(response){

                     vmContextCtrl[UIObject] =WebContextFactory.getTabContentUIModel(response[0].data[category],vmContextCtrl.Mapping,localeValue) 
                  vmContextCtrl[UIObject].EditMode=false; 
                    vmContextCtrl[UIObject].ChildEditing=false; 

                       if(response[1] && response[1].data && response[1].data.data)
                         vmContextCtrl[UIObject+'MISSING'] =WebContextFactory.getTabContentUIModel(response[1].data.data,vmContextCtrl.Mapping,localeValue)  
          
                        if (response[2].status == 200) {
                                        SetCustmizedSettings(response[2].data);
                                   } else
                        vmContextCtrl.Features.EnableAdditionalTab = false;

                                 $timeout(function() {
                                     $mdDialog.hide();
                                 });
    
        });
         });
          });  
          
          
    }

    function contextMenuInit(){
        var deferred = $q.defer();
        var baseUrl = homeFactory.getApiV2BaseUrl(false, true, true);
        var apiUrl = baseUrl + WebContextFactory.getAPIUrl('CM_INIT');  
       
        var promise = WebSettingsService.putWithOutBody(apiUrl);
        promise.then(function(response) {
            deferred.resolve(response);
        }, function(response) {

            deferred.resolve(response);
        });
        return deferred.promise;
    }

      
   function getmenusandExtensions(category) {
        var deferred = $q.defer();
        var baseUrl = homeFactory.getApiV2BaseUrl($scope.SelectedLibrary, false, true);
        var apiUrl = baseUrl  + WebContextFactory.getAPIUrl('CUSTOM_MENU',category);
        var promise = WebSettingsService.getData(apiUrl);
        promise.then(function(responseMenu) {
           deferred.resolve(responseMenu);
           
        }, function(response) {

            deferred.resolve(response);
        });
        return deferred.promise;

    }

     function getmenusandmissing(category) {
        var deferred = $q.defer();
        var baseUrl = homeFactory.getApiV2BaseUrl($scope.SelectedLibrary, false, true);
        var apiUrl = baseUrl + WebContextFactory.getAPIUrl('CM_MISSING_ITEM',category);
        var promise = WebSettingsService.getData(apiUrl);
        promise.then(function(response) {

            deferred.resolve(response);
        }, function(response) {

            deferred.resolve(response);
        });
        return deferred.promise;

    }
    


    function SetCustmizedSettings(responseData) {

        if (responseData && responseData.features) {
            if (responseData.features.additional_tab) {
                if (responseData.features.additional_tab.enable_additional_tab != undefined)
                    vmContextCtrl.Features.EnableAdditionalTab = responseData.features.additional_tab.enable_additional_tab;
                if (responseData.features.additional_tab.metadata != undefined)
                    vmContextCtrl.Features.Metadata = responseData.features.additional_tab.metadata;

                if (responseData.features.additional_tab.image_number != undefined)
                    vmContextCtrl.Features.IconNumber = responseData.features.additional_tab.image_number;
            }
        }
          if(responseData && responseData.menus)
          {
                angular.forEach(vmContextCtrl.CategoryConstants, function (category,TAB) {
                    if(responseData.menus[category])
                          vmContextCtrl.OrginalItems[TAB]=responseData.menus[category];
                 });                 
          } 
    }

    function getParams() {
        var deferred = $q.defer();
        $scope.SelectedLibrary = $location.search().library;
         var promiseDataMapfile = homeService.getData('scripts/web-contextmenu/data/mapping.json');
        promiseDataMapfile.then(function(response){
            vmContextCtrl.Mapping = response.data;
       
          getCustomerId().then(function(response) {
            baseV2Url = homeFactory.getApiV2BaseUrl($scope.SelectedLibrary);
         var captions=  getCaptions();
        var cminit= contextMenuInit();
       $q.all([captions,cminit]).then(function(){
      
          
            deferred.resolve();
        });
         });
          });

        return deferred.promise;
    }

    function getCustomerId() {
        var deferred = $q.defer();
        var apiUrl;

        var baseUrlWithoutAPIV2 = homeFactory.getApiV2BaseUrl('', true, true);
        if (baseUrlWithoutAPIV2.indexOf('imcc/') != -1) {
            apiUrl = baseUrlWithoutAPIV2 + WebSettingsFactory.getInitDataAPI();
        } else {
            apiUrl = baseUrlWithoutAPIV2 + WebSettingsFactory.getStartupInitDataAPI();
        }

        var promise = homeService.getData(apiUrl);
        promise.then(function(response) {
            customerName = '1';  
            if (response.status === 200 && response.data) {
                if (response.data.customer_id && response.data.customer_id.toString().trim().length > 0) {
                    customerName = response.data.customer_id.toString();
                } else if (response.data.data && response.data.data.customer_id && response.data.data.customer_id.toString().trim().length > 0) {
                    customerName = response.data.data.customer_id.toString();
                }
            }
            deferred.resolve();
        });
        return deferred.promise;
    }

    function getDefaultLocale() {
        var deferred = $q.defer();

        if ($location.search().locale && $location.search().locale.toString().trim().length > 0) {
            deferred.resolve({ Status: 0, LocaleDefault: $location.search().locale });
            return deferred.promise;
        }

        if (localStorage.getItem('locale') && localStorage.getItem('locale').toString().trim().length > 0) {
            deferred.resolve({ Status: 0, LocaleDefault: localStorage.getItem('locale') });
            return deferred.promise;
        }

        var promiseWebSetting = GetWebSettings();
        promiseWebSetting.then(function(responseWebSettings) {
            if (responseWebSettings.status === 200 && responseWebSettings.data && responseWebSettings.data.general &&
                responseWebSettings.data.general.language && responseWebSettings.data.general.language.trim().length > 0) {
                deferred.resolve({ Status: 0, LocaleDefault: responseWebSettings.data.general.language });
            } else {
                var baseURL = homeFactory.getApiV2BaseUrl();
                var apiUrl = homeFactory.getServerVersionAPI();
                var promise = homeService.getData(baseURL + apiUrl);
                promise.then(function(response) {
                    if (response && response.data && response.data.data && response.data.data['Locale Default']) {
                        deferred.resolve({ Status: 0, LocaleDefault: response.data.data['Locale Default'] });
                    } else {
                        deferred.resolve({ Status: 0, LocaleDefault: 'en-US' });
                    }
                });
            }
        });
        return deferred.promise;
    }

    function getCaptions() {

        var promise = getDefaultLocale();
        promise.then(function(localeLanguage) {
            localeValue=localeLanguage.LocaleDefault;
            var caprequestModel = homeFactory.requestModelInstance();
            caprequestModel.libraryName = $scope.SelectedLibrary;
            caprequestModel.isTotal = true;
            caprequestModel.searchText = '';
            caprequestModel.pageLength = 1000;
            caprequestModel.locale =localeValue;
           
            var apiUrl = homeFactory.getAPIUrl('SEARCHCAPTIONS', caprequestModel);
            $scope.mc.getlogDetails("Debug", 'Requested Api Url:' + JSON.stringify(apiUrl));
            var promise = homeService.getData(baseV2Url + apiUrl);
            promise.then(function(response) {
                vmContextCtrl.CaptionsList = [];
                if (response) {
                        angular.forEach(response.data["data"], function(caption) {
                            vmContextCtrl.CaptionsList.push(homeFactory.getCaptionUIModel(caption));
                        });                   
                }
            });
        });
    }

    function GetWebSettings() {
        var deferred = $q.defer();
        var baseUrl = homeFactory.getApiV2BaseUrl($scope.SelectedLibrary, false, true);
        var apiUrl = baseUrl + WebSettingsFactory.getWebSettings();
        var promise = WebSettingsService.getData(apiUrl);
        promise.then(function(response) {

            deferred.resolve(response);
        }, function(response) {

            deferred.resolve(response);
        });
        return deferred.promise;

    }

    function showProgressDialog() {
        $mdDialog.show({
            parent: angular.element(document.body),
            template: '<md-dialog ng-cloak height="100%" style="min-width: 1px !important;"><md-dialog-content><div class="md-dialog-content-clearpadding">' +
                '<md-progress-circular md-mode="indeterminate"></md-progress-circular>' +
                '</div></md-dialog-content></md-dialog>'
        });
    }

    function CheckForChanges(InTab) {
        var promiseSave = $q.defer();
          $timeout(function(){
                angular.forEach(vmContextCtrl.AdditionalItems[InTab], function (currentTabIndex) { 
	if(vmContextCtrl[currentTabIndex])	{		
        vmContextCtrl[currentTabIndex].EditMode=false;
        vmContextCtrl[currentTabIndex].ChildEditing=false; 
	}		
                });
         }); 
         var isChanged=false;
        angular.forEach(vmContextCtrl.AdditionalItems[InTab], function (currentTabIndex) { 
        if(!isChanged)
            isChanged=!vmContextCtrl.IsPostingData && vmContextCtrl.OrginalItems[currentTabIndex] && !angular.equals(vmContextCtrl.OrginalItems[currentTabIndex],  WebContextFactory.getCMAPIModel(vmContextCtrl[currentTabIndex]));
        });
           
        if (isChanged) {             
           
        var confirmDocumentSave = $mdDialog.confirm()
            .title(lblWarning)
            .theme('confirm-dialog')
            .textContent(lblConfirmation)
            .ariaLabel(lblConfirmation)
            .ok(lblYes)
            .cancel(lblNo);
        $mdDialog.show(confirmDocumentSave).then(function() {
            saveWebSettings(InTab).then(function(){                   
                promiseSave.resolve();
            })
        }, function() {
          
           
            
            promiseSave.resolve();
        });
         }else{
              
                promiseSave.resolve();
            }
            
        return promiseSave.promise;
    }

    $scope.$watch(function() { return $('md-tab-content.md-active .filter-item:visible').length },
              function(newValue, oldValue) { 
               var itemCount=   newValue- $('md-tab-content.md-active .filter-item.separator-item:visible').length ;
              
                    $('md-tab-content.md-active').attr("style","height:"+(itemCount*35+125)+"px")
                 }              
     );

    $scope.$on('OnContextMenuHover', function(){
        var itemCount = $('md-tab-content.md-active .filter-item:visible').length - $('md-tab-content.md-active .filter-item.separator-item:visible').length;
        $('md-tab-content.md-active').attr("style", "height:" + (itemCount * 35) + "px");
    });
      
    
    bindEvent(window, 'message', function (e) {
          if(e.data == "App_Change"){
             CheckForChanges(vmContextCtrl.ActiveTab).then(function(){
            sendMessage(true);
                 }); 
            }else if(e.data == "RELOAD"){
               initalize(); 
            }
       
    });

    vmContextCtrl.onTabChanges = TabChanged;
    
    function TabChanged(NewTab) {
       var PreActiveTab=vmContextCtrl.ActiveTab;
       vmContextCtrl.ActiveTab=NewTab;
       var promiseSave = $q.defer();
       if(PreActiveTab){
       CheckForChanges(PreActiveTab).then(function(responseChange){               
                var currentTabIndex=vmContextCtrl.ActiveTab;                     
                angular.forEach(vmContextCtrl.AdditionalItems[vmContextCtrl.ActiveTab], function (currentTabIndex) {                   
                var category=vmContextCtrl.CategoryConstants[currentTabIndex];                  
                var getmenuspromise= getmenusandExtensions(category);
                var getmissingpromise= getmenusandmissing(category);
                $q.all([getmenuspromise,getmissingpromise]).then(function(response){

                  vmContextCtrl[currentTabIndex] =WebContextFactory.getTabContentUIModel(response[0].data[category],vmContextCtrl.Mapping,localeValue); 
                  vmContextCtrl[currentTabIndex].EditMode=false;  
                  vmContextCtrl[currentTabIndex].ChildEditing=false;                
                  vmContextCtrl.OrginalItems[currentTabIndex]= WebContextFactory.getCMAPIModel(vmContextCtrl[currentTabIndex]);                    
                  if(response[1] && response[1].data && response[1].data.data)
                         vmContextCtrl[currentTabIndex+'MISSING'] =WebContextFactory.getTabContentUIModel(response[1].data.data,vmContextCtrl.Mapping,localeValue)  
                  promiseSave.resolve();    
                  $timeout(function() {
                       $mdDialog.hide();
                  });
    
                 });
                 });
        });
       }else{
            promiseSave.resolve();   
       }
        return promiseSave.promise;
    }
        function RestoreDefault(index){
             var deferred = $q.defer();
          if(vmContextCtrl.AdditionalItems[vmContextCtrl.ActiveTab][index]){ 
              currentTabIndex=  vmContextCtrl.AdditionalItems[vmContextCtrl.ActiveTab][index];  
        var baseUrl = homeFactory.getApiV2BaseUrl($scope.SelectedLibrary, false, true);
        
        var apiUrl = baseUrl +  WebContextFactory.getAPIUrl('CM_RESTORE',vmContextCtrl.CategoryConstants[currentTabIndex]); 
        var promise = WebSettingsService.postWithOutBody(apiUrl);
        promise.then(function(responsepost) {
           
                 var category=vmContextCtrl.CategoryConstants[currentTabIndex];                   
                var getmenuspromise= getmenusandExtensions(category);
                var getmissingpromise= getmenusandmissing(category);
                $q.all([getmenuspromise,getmissingpromise]).then(function(response){

                  vmContextCtrl[currentTabIndex] =WebContextFactory.getTabContentUIModel(response[0].data[category],vmContextCtrl.Mapping,localeValue); 
                  vmContextCtrl[currentTabIndex].EditMode=false;  
                  vmContextCtrl[currentTabIndex].ChildEditing=false;                
                  vmContextCtrl.OrginalItems[currentTabIndex]= WebContextFactory.getCMAPIModel(vmContextCtrl[currentTabIndex]);                    
                  if(response[1] && response[1].data && response[1].data.data)
                         vmContextCtrl[currentTabIndex+'MISSING'] =WebContextFactory.getTabContentUIModel(response[1].data.data,vmContextCtrl.Mapping,localeValue)  

                 index++;
                  if(vmContextCtrl.AdditionalItems[vmContextCtrl.ActiveTab][index]){
                    RestoreDefault(index).then(function(){
                         deferred.resolve();
                    })
                    }
                    else{
                 deferred.resolve();
                    }
                 });
           
        }, function(response) {

            deferred.resolve();
        });
          }else{
               deferred.resolve();
          }
        
return deferred.promise;
        }

       function SaveDefaults() {
        var deferred = $q.defer();
        vmContextCtrl.IsPostingData = true;
        vmContextCtrl.isRestoringData =true;
       
        RestoreDefault(0).then(function(){
                 $('div#toastPopup').addClass('show');
                $timeout(function() {
                    $('div#toastPopup').removeClass('show');
                      vmContextCtrl.IsPostingData = false;
                }, 2000);
                $timeout(function() {
                    vmContextCtrl.isRestoringData = false;
                }, 2500);
                 deferred.resolve();
        });
        return deferred.promise;

    }


    function saveWebSettings(saveTab) {
        var promiseSave = $q.defer();    
        vmContextCtrl.IsPostingData = true;
        var defaultSettings = {};
        if(!saveTab)
        saveTab=vmContextCtrl.ActiveTab;
        GetWebSettings().then(function(response) {
            if (response.status == 200) {
                defaultSettings = response.data;
            }
             angular.forEach(vmContextCtrl.AdditionalItems[saveTab], function (currentTabIndex) {
            var category=vmContextCtrl.CategoryConstants[currentTabIndex];
            if(!defaultSettings.menus){
                defaultSettings.menus={};               
            }
            defaultSettings.menus[category]=   WebContextFactory.getCMAPIModel(vmContextCtrl[currentTabIndex]); 
            vmContextCtrl.OrginalItems[currentTabIndex]=defaultSettings.menus[category];
             });          
            PostWebSettings(defaultSettings).then(function(){
                promiseSave.resolve();
            })
        });
           
        return promiseSave.promise;
    }

    function PostWebSettings(Body) {
        var deferred = $q.defer();
        var lblSaveContext;
        $translate('WebSettings.contextmenu.saveMessage').then(function(translatedValue) {
            lblSaveContext = translatedValue;
        });
        var baseUrl = homeFactory.getApiV2BaseUrl($scope.SelectedLibrary, false, true);
        var apiUrl = baseUrl + WebSettingsFactory.getWebSettings();
        var promise = WebSettingsService.postWithBody(Body, apiUrl);
        promise.then(function(response) {
            if (vmContextCtrl.IsPostingData) {
                
                $('div#toastPopup').addClass('show');
                $timeout(function() {
                    $('div#toastPopup').removeClass('show');
                }, 2000);
                $timeout(function() {
                    vmContextCtrl.isRestoringData = false;
                }, 2500);
            }
            vmContextCtrl.IsPostingData = false;
            deferred.resolve(response);
        }, function(response) {

            deferred.resolve(response);
        });
        return deferred.promise;
 
    }

    function removeToast() {
        $('div#toastPopup').removeClass('show');
    }  

    function bindEvent(element, eventName, eventHandler) {
        if (element.addEventListener) {
            element.addEventListener(eventName, eventHandler, false);
        } else if (element.attachEvent) {
            element.attachEvent('on' + eventName, eventHandler);
        }
    }

    var sendMessage = function (msg) {
        window.parent.postMessage(msg, '*');
    };
}