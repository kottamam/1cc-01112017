(function() {
    'use strict';


    angular.module('iManage.WebSettings').factory('WebContextFactory', WebContextFactory);
    WebContextFactory.$inject = ['$q','API_URL_ContextMenus','$window'];

    function WebContextFactory($q,API_URL_ContextMenus,$window) {

       

        var returnObject = {
            getCMAPIModel: getCMModel,
            getAPIUrl: returnAPIUrl,
            getTabContentUIModel:returnTabConentUIModel
        };
        return returnObject;

        function getCMModel(UIModel) {
            
           var returnModel=[];
            angular.forEach(UIModel, function (item) {
                if(item && item.type && item.type!='group'){
                    returnModel.push(item.id);
                }else if(item && item.type){
                    var groupObject={};
                    groupObject.id=item.id;
                    groupObject.items=getCMModel(item.children);
                    returnModel.push(groupObject);
                }
               
            });

            return returnModel;
        };

         function returnTabConentUIModel(apiModel,DataMapping,localeValue) {
           var returnobject=[];
           if(apiModel && apiModel.length>0){
            angular.forEach(apiModel, function (item) {
                if(item && item.type)
                { 
                    if(item.type=='yaml' || item.id=='wsCommandSeparator' || DataMapping[item.id])
                        returnobject.push(GenerateCmObject(angular.copy(item),DataMapping,localeValue));
                     
                } 
                else  if(item && item.items)
                {
                      var newobj=    {id: item.id, type: "group"}
                      if(DataMapping[item.id]){
                          newobj.DisplayText= 'WebSettings.contextmenu.'+DataMapping[item.id].DisplayText;
                          newobj.iconName=  DataMapping[item.id].iconName;
                           
                      }else{
                            newobj.DisplayText= 'WebSettings.contextmenu.'+item.id;                   
                           
                      }
                      newobj.children=returnTabConentUIModel(item.items,DataMapping,localeValue);
                      newobj.children.EditMode=false;
                       newobj.children.ChildEditing=false;
                     if(DataMapping[item.id])
                      returnobject.push(angular.copy(newobj));
                }else if(!item.id){  
                        if(item=='wsCommandSeparator' || DataMapping[item]){
                            var item1={};
                             item1.id= item;
                              item1.type= 'constant'; 

                        returnobject.push(GenerateCmObject(angular.copy(item1),DataMapping,localeValue));
                        }
                }
            });
           }
            return returnobject;
        };

        function GenerateCmObject(item,Mapping,localeValue){

            var returnObject={}
            returnObject.id=item.id;
            if(item.type=='yaml'){
            returnObject.type="yaml";
             returnObject.iconUrl=item.icon;
            returnObject.DisplayText=item.title[localeValue];
           
        }else   if(item.type=='constant'){
            if(item.id=='wsCommandSeparator')
                     returnObject.type="separator";
              else{
                     returnObject.type="constant";
                     if(Mapping[item.id]){
                        returnObject.DisplayText='WebSettings.contextmenu.'+Mapping[item.id].DisplayText;                     
                        returnObject.iconName=Mapping[item.id].iconName;
                     }else{
                          returnObject.DisplayText='WebSettings.contextmenu.'+item.id;  
                     }
              }
            }
             

           return  returnObject;

        }
        

        function returnAPIUrl(APIFOR, category) {
            var ApiUrl = API_URL_ContextMenus[APIFOR];
            if(category)
               ApiUrl =ApiUrl.replace('<category>',category);           
            return ApiUrl;
        }

      

    }
})();