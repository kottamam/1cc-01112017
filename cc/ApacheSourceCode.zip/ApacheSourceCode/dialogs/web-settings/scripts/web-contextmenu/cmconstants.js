(function() {
    'use strict';

    angular.module('iManage.WebSettings').constant('API_URL_ContextMenus', {
        CUSTOM_MENU:'web/contextmenus/customizations?category=<category>',
        CM_INIT:'contextmenus/init',
        CM_MISSING_ITEM:'web/contextmenus/missing?category=<category>',
        CM_RESTORE:'web/contextmenus/restoredefault?category=<category>'      
        
    });

    

})();