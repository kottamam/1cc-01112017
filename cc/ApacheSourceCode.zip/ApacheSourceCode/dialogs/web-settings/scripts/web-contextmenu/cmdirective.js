(function() {
  "use strict";

  angular
    .module("iManage.WebSettings")
    .directive("cmTabContent", contextmenuTabContent);

  contextmenuTabContent.$inject = [
    "$compile",
    "$templateRequest",
    "$timeout",
    "$translate",
    "$filter"
  ];

  function contextmenuTabContent(
    $compile,
    $templateRequest,
    $timeout,
    $translate,
    $filter
  ) {
    return {
      restrict: "E",
      replace:true,
      scope: {
        cmModel: "=",
        cmMissing:"="
      },
      templateUrl: "scripts/web-contextmenu/tabcontent.html",
      controller: [
        "$scope",
        "$element",  
		"$rootScope",
        cmTabContentController
      ]
    };

    function cmTabContentController($scope, $element,$rootScope) {
      
      $scope.OrginalItem = undefined;

      //Functions
      $scope.OpenEditMode = OpenEditMode;
      $scope.Addseparator = Addseparator;
      $scope.RemoveItem = RemoveItem;
      $scope.CancelChanges = CancelChanges;
      $scope.UpdatePreview = UpdatePreview;
      $scope.AddSelectedItem=AddSelectedItem;
      $scope.MenuMouseOver=OnMenuMouseOver;

      $scope.$watch(function($scope) { return $('.nested-div.child-div-editmode').length },
              function(newValue, oldValue) {                
                if($scope.cmModel)                  
                    $scope.cmModel.ChildEditing = newValue!=0 && !($('.nested-div.child-div-editmode').scope() && $('.nested-div.child-div-editmode').scope().cmModel && $('.nested-div.child-div-editmode').scope().cmModel.children==$scope.cmModel);
              }              
             );
      
       

        $scope.$watch(function($scope) { return $scope.cmModel && $scope.cmModel.EditMode },
              function(newValue, oldValue) { 
            if(newValue){
               if($element.closest('.nested-div').closest('.filter-box').closest('div').length>0){
                   if($element.closest('.nested-div').closest('.filter-box').closest('div').scope().$parent.$parent.cmModel)
                 {    $scope.OrginalParentMissing = angular.copy($element.closest('.nested-div').closest('.filter-box').closest('div').scope().$parent.$parent.cmMissing); 
                      $scope.OrginalParentItem = angular.copy($element.closest('.nested-div').closest('.filter-box').closest('div').scope().$parent.$parent.cmModel); 
                      $scope.OrginalParentItem.EditMode=$element.closest('.nested-div').closest('.filter-box').closest('div').scope().$parent.$parent.cmModel.EditMode;
                      $scope.OrginalParentItem.ChildEditing=$element.closest('.nested-div').closest('.filter-box').closest('div').scope().$parent.$parent.cmModel.ChildEditing;
                 }else   if($element.closest('.nested-div').closest('.filter-box').closest('div').scope().$parent.cmModel){
                    $scope.OrginalParentMissing = angular.copy($element.closest('.nested-div').closest('.filter-box').closest('div').scope().$parent.cmMissing);                      
                    $scope.OrginalParentItem = angular.copy($element.closest('.nested-div').closest('.filter-box').closest('div').scope().$parent.cmModel); 
                      $scope.OrginalParentItem.EditMode=$element.closest('.nested-div').closest('.filter-box').closest('div').scope().$parent.cmModel.EditMode;
                      $scope.OrginalParentItem.ChildEditing=$element.closest('.nested-div').closest('.filter-box').closest('div').scope().$parent.cmModel.ChildEditing;
              
                 }
              } 
            }
            }
              //edited-imparent
             );
      

      function OpenEditMode() {
        $scope.cmModel.EditMode = true;
        $scope.OrginalItem = angular.copy($scope.cmModel);
        $scope.OrginalMissing = angular.copy($scope.cmMissing);
        if(!$scope.cmMissing)
               $scope.cmMissing=[]; 
       
       
    }

      function RemoveItem(index) {
        if($scope.cmModel[index].type!='separator'){         
           $scope.cmMissing.push(angular.copy($scope.cmModel[index]));
        }
        $scope.cmModel.splice(index, 1);
      }

      function Addseparator(index) {
        index = index + 1;
        $scope.cmModel.splice(index, 0, {
        id: "wsCommandSeparator", type: "separator"
        });
      }

        function OnMenuMouseOver(){
           $rootScope.$broadcast('OnContextMenuHover');
         }

       function AddSelectedItem(item) {
         if(item){
        var selectedItem = $filter('filter')($scope.cmMissing, { id:item }, true);
         if(selectedItem.length>0)
       var index= $scope.cmMissing.indexOf(selectedItem[0]);
       $scope.cmModel.push(angular.copy(selectedItem[0]));
        $scope.cmMissing.splice(index, 1);
         }
      }

      function CancelChanges() {
       
      
         if($element.closest('.nested-div').closest('.filter-box').closest('div').length>0){
            if($element.closest('.nested-div').closest('.filter-box').closest('div').scope().$parent.$parent.cmModel){
              $element.closest('.nested-div').closest('.filter-box').closest('div').scope().$parent.$parent.cmModel  = $scope.OrginalParentItem; 
              $element.closest('.nested-div').closest('.filter-box').closest('div').scope().$parent.$parent.cmMissing  = $scope.OrginalParentMissing; 
           
           }
        }

         $scope.cmModel.EditMode = false;
        $scope.cmModel = $scope.OrginalItem;
        $scope.cmMissing = angular.copy($scope.OrginalMissing); 

      }
      function UpdatePreview() {
        $scope.cmModel.EditMode = false;
      }
    }
  }
})();

(function() {
  "use strict";

  angular
    .module("iManage.WebSettings")
    .directive("nestedContent", nestedContent);

  nestedContent.$inject = [
    "$compile",
    "$templateRequest",
    "$timeout",
    "$translate",
    "$filter"
  ];

  function nestedContent(
    $compile,
    $templateRequest,
    $timeout,
    $translate,
    $filter
  ) {
    return {
      restrict: "E",
      replace:true,
      scope: {
        cmModel: "=",
        cmMissing:"="
      },
      template: "<div></div>",
      link: function (scope, element, attrs) {
          if (angular.isArray(scope.cmModel.children)) {
              element.append("  <cm-tab-content cm-model='cmModel.children' cm-missing='cmMissing' class='nested-div'>   </cm-tab-content>");             
              $compile(element.contents())(scope)
          }
      }
    };
    
  }
})();