(function() {
    'use strict';


    angular.module('iManage.WebSettings').factory('WebAdvancedFactory', WebAdvancedFactory);
    WebAdvancedFactory.$inject = ['API_URL_WEB_ADVANCED', 'CONST_WEB_FORM_TYPES'];

    function WebAdvancedFactory(API_URL_WEB_ADVANCED, CONST_WEB_FORM_TYPES) {

        var returnObject = {
            getWebSettingsAPI: getWebSettingsURL,
            getCaptionsAPI: returngetCaptionsAPI,
            getViewListItems: returnViewListItems,
            getWorkspaceViewListItems: returnWorkspaceViewListItems,
            getVisibleFieldsUrl: returnVisibleFields,
            getConflictMapplingList: returnConflictMapplingList,
            getInitDataAPI: returnInitDataAPI,
            getStartupInitDataAPI: returnStartupInitDataAPI
        };
        return returnObject;

        function returnInitDataAPI() {
            var apiUrl = API_URL_WEB_ADVANCED.GET_INIT_DATA;
            return apiUrl;
        }

        function returnStartupInitDataAPI() {
            var apiUrl = API_URL_WEB_ADVANCED.GET_STARTUP_INIT_DATA;
            return apiUrl;
        }

        function getWebSettingsURL() {
            var ApiUrl = API_URL_WEB_ADVANCED.WEB_SETTINGS_URL;
            return ApiUrl;
        }

        function returngetCaptionsAPI(requestModel) {
            var ApiUrl = API_URL_WEB_ADVANCED.SEARCHCAPTIONS;
            ApiUrl += "?offset=" + ((requestModel.pagenumber - 1) * requestModel.pageLength).toString() +
                '&limit=' + requestModel.pageLength.toString() + '&total=' + requestModel.isTotal +
                '&language=' + requestModel.language;

            return ApiUrl;
        }

        function returnConflictMapplingList() {
            return {
                "document_number": "docnum",
                "create_date": "createdate",
                "size": "docsize"
            }
        }

        function returnViewListItems() {
            return [
                'accesstime',
                'account_id',
                'archived',
                'author',
                'authordescription',
                'bcc',
                'cc',
                'checkout',
                'class',
                'classdescription',
                'comments',
                'createdate',
                'custom10',
                'custom11',
                'custom12',
                'custom17',
                'custom18',
                'custom19',
                'custom20',
                'custom23',
                'custom24',
                'custom25',
                'custom26',
                'custom27',
                'custom28',
                'custom29',
                'custom30',
                'custom31',
                'custom1description',
                'custom2description',
                'custom3description',
                'custom4description',
                'custom5description',
                'custom6description',
                'custom7description',
                'custom8description',
                'custom9description',
                'custom10description',
                'custom11description',
                'custom12description',
                'custom29description',
                'custom30description',
                'customer_id',
                'customer_industry',
                'database',
                'date_received',
                'date_sent',
                'default_security',
                'deployment_level',
                'deployment_type',
                'description',
                'docnum',
                'doc_status',
                'echoenabled',
                'editdate',
                'extension',
                'docsize',
                'from',
                'indexable',
                'in_use',
                'in_use_by',
                'inusebydescription',
                'is_related',
                'last_user',
                'lastuserdescription',
                'location',
                'markedforarchive',
                'messageuniqueid',
                'name',
                'net_node',
                'operator',
                'operatordescription',
                'edit_profile_time',
                'project',
                'region',
                'retain_days',
                'salesforceid',
                'subclass',
                'subclassdescription',
                'to',
                'type',
                'typedescription',
                'version',
                'workspace'
            ]
        }

        function returnWorkspaceViewListItems() {
            return [
                'namedescription',
                'author',
                'database',
                'customer_id',
                'account_id',
                'docnum',
                'version',
                'editdate',
                'description',
                'operator',
                'type',
                'class',
                'subclass',
                'accesstime',
                'createdate',
                'retain_days',
                'docsize',
                'declared',
                'is_related',
                'location',
                'default_security',
                'user',
                'in_use_by',
                'net_node',
                'in_use',
                'checkout',
                'archived',
                'comments',
                'customer_industry',
                'deployment_level',
                'deployment_type',
                'doc_status',
                'region',
                'salesforceid',
                'project',
                'custom10',
                'custom11',
                'custom12',
                'from',
                'to',
                'cc',
                'bcc',
                'custom17',
                'custom18',
                'custom19',
                'custom20',
                'date_sent',
                'date_received',
                'custom23',
                'custom24',
                'custom25',
                'custom26',
                'custom27',
                'custom28',
                'custom29',
                'custom30',
                'customeriddescription',
                'accountiddescription',
                'customerindustrydescription',
                'deploymentleveldescription',
                'deplymenttypedescription',
                'deploymentstatusdescription',
                'regiondescription',
                'salesforceiddescription',
                'projectdescription',
                'custom10description',
                'custom11description',
                'custom12description',
                'custom29description',
                'custom30description',
                'authordescription',
                'operatordescription',
                'typedescription',
                'classdescription',
                'subclassdescription',
                'userdescription',
                'inusebydescription',
                'edittime',
                'extension'
            ]
        }

        function returnVisibleFields(DbName, section) {
            var ApiUrl = API_URL_WEB_ADVANCED.GET_VISIBLE_FIELD_LIST;
            ApiUrl = ApiUrl.replace('<dbname>', DbName);
            if(section == "documents"){
                ApiUrl = ApiUrl.replace('<form_type>', CONST_WEB_FORM_TYPES.DOCUMENT);
            }else if(section == "emails"){
                ApiUrl = ApiUrl.replace('<form_type>', CONST_WEB_FORM_TYPES.EMAIL);
            }else if(section == "matters"){
                ApiUrl = ApiUrl.replace('<form_type>', CONST_WEB_FORM_TYPES.MATTER);
            }else if(section == "folders"){
                ApiUrl = ApiUrl.replace('<form_type>', CONST_WEB_FORM_TYPES.FOLDER);
            }else{
                ApiUrl = ApiUrl.replace('<form_type>', CONST_WEB_FORM_TYPES.DOCUMENT);
            }
            return ApiUrl;
        }

    }
})();