(function() {
    'use strict';

    angular.module('iManage.WebSettings').constant('API_URL_WEB_ADVANCED', {
        WEB_SETTINGS_URL: "web/customizations",
        SEARCHCAPTIONS: "captions/search",
        GET_VISIBLE_FIELD_LIST: 'forms/visible-fields?form_type=<form_type>&scope=<dbname>',
        GET_INIT_DATA: 'init-data',
		GET_STARTUP_INIT_DATA: 'startup/init-data',
    });

    angular.module('iManage.WebSettings').constant('CONST_WEB_SETTINGS', {
        DOCUMENT_SEARCH: "documentsearch",
        DOCUMENT_BROWSE: "documentbrowse",
        EMAIL_SEARCH: "emailsearch",
        EMAIL_BROWSE: "emailbrowse",
        MATTER_SEARCH: "mattersearch",
        MATTER_BROWSE: "matterbrowse",
        CLIENT_SEARCH: "clientsearch",
        CLIENT_BROWSE: "clientbrowse",
        FOLDER_SEARCH: "foldersearch",
        FOLDER_BROWSE: "folderbrowse",
        DOCUMENT: "document",
        EMAIL: "email",
        MATTER: "workspace",
        CLIENT: "client",
        FOLDER: "folder"
    });

    angular.module('iManage.WebSettings').constant('CONST_WEB_INVERSE_SETTINGS', {
        documentsearch: "DocumentSearch",
        documentbrowse: "DocumentBrowse",
        emailsearch: "EmailSearch",
        emailbrowse: "EmailBrowse",
        mattersearch: "MatterSearch",
        matterbrowse: "MatterBrowse",
        clientsearch: "ClientSearch",
        clientbrowse: "ClientBrowse",
        foldersearch: "FolderSearch",
        folderbrowse: "FolderBrowse"
    });

    angular.module('iManage.WebSettings').constant('CONST_WEB_FORM_TYPES', {
        DOCUMENT: "edit_document",
        EMAIL: "edit_document",
        MATTER: "edit_workspace",
        FOLDER: "new_document"
    });

})();