(function () {
    'use strict';

    angular.module('iManage.WebSettings').controller("WebSettingsAdvancedController", WebSettingsAdvancedController);

    WebSettingsAdvancedController.$inject = ['$scope', '$timeout', '$q', '$location', '$mdDialog', '$translate',
        '$filter', 'homeFactory', 'WebAdvancedFactory', 'WebSettingsService', 'CONST_WEB_SETTINGS',
        'CONST_WEB_INVERSE_SETTINGS','homeService'
    ];

    function WebSettingsAdvancedController($scope, $timeout, $q, $location, $mdDialog, $translate, $filter, 
        homeFactory, WebAdvancedFactory, WebSettingsService, CONST_WEB_SETTINGS, CONST_WEB_INVERSE_SETTINGS,homeService) {

        var vmWebAdvancedCtrl = this;

        var WebSettings = {};
        var WebSettingsInitial = {};
        var lastEditedAutoComplete = {};
        var promiseListCaptions = [];
        var promiseListWorkspaceCaptions = [];
        var attributeList = [];
        var lblConfirmation, lblWarning, lblYes, lblNo;
        var libraryName = $location.search().library;
		var localeDefault;
        $scope.mc.isView = true;
		
        vmWebAdvancedCtrl.CONST_WEB_SETTINGS=CONST_WEB_SETTINGS;
        vmWebAdvancedCtrl.documentSearchDesktopAddNew = '';
        vmWebAdvancedCtrl.emailSearchDesktopAddNew = '';
        vmWebAdvancedCtrl.matterSearchDesktopAddNew = '';
        vmWebAdvancedCtrl.clientSearchDesktopAddNew = '';
        vmWebAdvancedCtrl.folderSearchDesktopAddNew = '';

        vmWebAdvancedCtrl.documentsSearchDesktopEditMode = false;
        vmWebAdvancedCtrl.emailsSearchDesktopEditMode = false;
        vmWebAdvancedCtrl.mattersSearchDesktopEditMode = false;
        vmWebAdvancedCtrl.clientsSearchDesktopEditMode = false;
        vmWebAdvancedCtrl.foldersSearchDesktopEditMode = false;

        vmWebAdvancedCtrl.documentSearchDesktopWebSettings = [];
        vmWebAdvancedCtrl.emailSearchDesktopWebSettings = [];
        vmWebAdvancedCtrl.matterSearchDesktopWebSettings = [];
        vmWebAdvancedCtrl.clientSearchDesktopWebSettings = [];
        vmWebAdvancedCtrl.folderSearchDesktopWebSettings = [];

        vmWebAdvancedCtrl.beforeDocumentSearchDesktopWebSettings = [];
        vmWebAdvancedCtrl.afterDocumentSearchDesktopWebSettings = [];
        vmWebAdvancedCtrl.beforeEmailSearchDesktopWebSettings = [];
        vmWebAdvancedCtrl.afterEmailSearchDesktopWebSettings = [];
        vmWebAdvancedCtrl.beforeMatterSearchDesktopWebSettings = [];
        vmWebAdvancedCtrl.afterMatterSearchDesktopWebSettings = [];
        vmWebAdvancedCtrl.beforeClientSearchDesktopWebSettings = [];
        vmWebAdvancedCtrl.afterClientSearchDesktopWebSettings = [];
        vmWebAdvancedCtrl.beforeFolderSearchDesktopWebSettings = [];
        vmWebAdvancedCtrl.afterFolderSearchDesktopWebSettings = [];

        vmWebAdvancedCtrl.beforeDocumentSearchDesktopWebSettingsLabel = [];
        vmWebAdvancedCtrl.afterDocumentSearchDesktopWebSettingsLabel = [];
        vmWebAdvancedCtrl.beforeEmailSearchDesktopWebSettingsLabel = [];
        vmWebAdvancedCtrl.afterEmailSearchDesktopWebSettingsLabel = [];
        vmWebAdvancedCtrl.beforeMatterSearchDesktopWebSettingsLabel = [];
        vmWebAdvancedCtrl.afterMatterSearchDesktopWebSettingsLabel = [];
        vmWebAdvancedCtrl.beforeClientSearchDesktopWebSettingsLabel = [];
        vmWebAdvancedCtrl.afterClientSearchDesktopWebSettingsLabel = [];
        vmWebAdvancedCtrl.beforeFolderSearchDesktopWebSettingsLabel = [];
        vmWebAdvancedCtrl.afterFolderSearchDesktopWebSettingsLabel = [];

        vmWebAdvancedCtrl.captionList = [];
        vmWebAdvancedCtrl.sampleWebSettings = {};
        vmWebAdvancedCtrl.maximumAllowedAttributes = 10;
        vmWebAdvancedCtrl.workspaceListItems = [];
        vmWebAdvancedCtrl.selectedTab = 'documentsTab';
        vmWebAdvancedCtrl.IsPostingData = false;
        vmWebAdvancedCtrl.isRestoringData = false;
		
        vmWebAdvancedCtrl.additionalTab = {
            enabled: false,
            imageNumber: 0,
            metadata: ''
        };
        vmWebAdvancedCtrl.DBList = [];

        vmWebAdvancedCtrl.removeItemInWebSettings = removeItemInWebSettings;
        vmWebAdvancedCtrl.saveWebSettings = saveWebSettings;
        vmWebAdvancedCtrl.addNewFieldChange = addNewFieldChange;
        vmWebAdvancedCtrl.restoreDefault = restoreDefault;
        vmWebAdvancedCtrl.onTabChange = onTabChange;
        vmWebAdvancedCtrl.removeToast = removeToast;       
        vmWebAdvancedCtrl.selectedItemChange = selectedItemChange;
        vmWebAdvancedCtrl.querySearch = querySearch;
        vmWebAdvancedCtrl.getListItemLabel = getListItemLabel;
        vmWebAdvancedCtrl.onDropdownClick = onDropdownClick;
        vmWebAdvancedCtrl.onSearchTextChange = onSearchTextChange;
        vmWebAdvancedCtrl.getClass = getClass;
        vmWebAdvancedCtrl.isAutocompleteFocus = isAutocompleteFocus;

        vmWebAdvancedCtrl.editDocumentsSearchDesktop = editDocumentsSearchDesktop;
        vmWebAdvancedCtrl.closeEditDocumentsSearchDesktop = closeEditDocumentsSearchDesktop;
        vmWebAdvancedCtrl.applyEditDocumentsSearchDesktop = applyEditDocumentsSearchDesktop;

        vmWebAdvancedCtrl.editEmailsSearchDesktop = editEmailsSearchDesktop;
        vmWebAdvancedCtrl.closeEditEmailsSearchDesktop = closeEditEmailsSearchDesktop;
        vmWebAdvancedCtrl.applyEditEmailsSearchDesktop = applyEditEmailsSearchDesktop;

        vmWebAdvancedCtrl.editMattersSearchDesktop = editMattersSearchDesktop;
        vmWebAdvancedCtrl.closeEditMattersSearchDesktop = closeEditMattersSearchDesktop;
        vmWebAdvancedCtrl.applyEditMattersSearchDesktop = applyEditMattersSearchDesktop;

        vmWebAdvancedCtrl.editClientsSearchDesktop = editClientsSearchDesktop;
        vmWebAdvancedCtrl.closeEditClientsSearchDesktop = closeEditClientsSearchDesktop;
        vmWebAdvancedCtrl.applyEditClientsSearchDesktop = applyEditClientsSearchDesktop;

        vmWebAdvancedCtrl.editFoldersSearchDesktop = editFoldersSearchDesktop;
        vmWebAdvancedCtrl.closeEditFoldersSearchDesktop = closeEditFoldersSearchDesktop;
        vmWebAdvancedCtrl.applyEditFoldersSearchDesktop = applyEditFoldersSearchDesktop;
		vmWebAdvancedCtrl.showDropDownIcon = showDropDownIcon;

        $timeout(function () {
            $(window).scrollTop(0);
        });

        function selectedItemChange(list, obj) {
            if(obj.ValueText){
                list.DisplayText = obj.ValueText;
            }
        }

        function querySearch(query, view) {
            var selectedItemObject = [];
            switch (view) {
                case "client":
                    selectedItemObject = vmWebAdvancedCtrl.clientSearchDesktopWebSettings;
                    break;
                case "document":
                    selectedItemObject = vmWebAdvancedCtrl.documentSearchDesktopWebSettings;
                    break;
                case "email":
                    selectedItemObject = vmWebAdvancedCtrl.emailSearchDesktopWebSettings;
                    break;
                case "folder":
                    selectedItemObject = vmWebAdvancedCtrl.folderSearchDesktopWebSettings;
                    break;
                case "workspace":
                    selectedItemObject = vmWebAdvancedCtrl.matterSearchDesktopWebSettings;
                    break;
            }
            var attributeListCopy = angular.copy(attributeList);
            var results = query ? attributeListCopy[view].filter(filterListItems(query)) : attributeListCopy[view];
            var selectedItem;
            var elementValue;
            if (results.length > 0) {
                angular.forEach(selectedItemObject, function(value, key) {
                    if (value.DisplayText !== undefined) {
                        selectedItem = results.filter(removeSelectedItems(value.DisplayText));
                        if (lastEditedAutoComplete.value && angular.isObject(lastEditedAutoComplete.value)) {
                            elementValue = lastEditedAutoComplete.value.DisplayText || "";
                        } else {
                            elementValue = lastEditedAutoComplete.value || "";
                        }
                        if (selectedItem.length > 0 && selectedItem[0].DisplayText != elementValue)
                            results.splice(results.indexOf(selectedItem[0]), 1);
                    }
                });
            }
            return results;
        }

        function removeSelectedItems(query) {
            var lowercaseQuery = angular.lowercase(query);

            return function filterFn(item) {
                return (angular.lowercase(item.ValueText).indexOf(lowercaseQuery) === 0);
            };
        }

        function filterListItems(query) {
            var lowercaseQuery = angular.lowercase(query);

            return function filterFn(item) {
                return (angular.lowercase(item.DisplayText).indexOf(lowercaseQuery) === 0);
            };
        }

        function substractArray(arrItems) {
            var formattedArray = [];
            if(arrItems){
                formattedArray = arrItems.map(function (value) {
                    return angular.lowercase(value);
                });
            }

            return function filterFn(item) {
                return formattedArray.length == 0 || (formattedArray.indexOf(angular.lowercase(item)) < 0);
            };
        }

        function getListItemLabel(valueText, view) {
            var Item = $filter('filter')(attributeList[view], { ValueText: valueText });
            if (Item.length > 0)
                return $filter('filter')(attributeList[view], { ValueText: valueText })[0].DisplayText;
            else
                return valueText;
        }

        function onDropdownClick(selectedItem, txtId){
            selectedItem.searchText = '';
            if(txtId){
                txtId = '#'+txtId;
                if($(txtId).length > 0){
                    $timeout(function(){
                        $(txtId)[0].focus();
                    })
                }
            }
        }

        function onAutocompleteLeave(){
            if(lastEditedAutoComplete && lastEditedAutoComplete.element){
                var elementValue = '';
                if(lastEditedAutoComplete.value && angular.isObject(lastEditedAutoComplete.value)){
                    elementValue = lastEditedAutoComplete.value.DisplayText || "";
                }else{
                    elementValue = lastEditedAutoComplete.value || "";
                }
                angular.element(document.querySelector('#' + lastEditedAutoComplete.element)).val(elementValue);
                //lastEditedAutoComplete = {};
            }
        }

        function onSearchTextChange(listItem, elementId){
            if(listItem && listItem.DisplayText != null){
                lastEditedAutoComplete = {
                    element: elementId,
                    value: listItem.DisplayText
                }
                angular.element(document.querySelector('#' + lastEditedAutoComplete.element)).on("blur", onAutocompleteLeave);
            }
        }

		getCustomerId().then(function(responseCustId) {
            getDefaultLocale().then(function(responseLocale) {
                localeDefault = responseLocale.LocaleDefault;
                getWebViewDetails();
            });
        });
        
        var promiseSampleWebSettings = WebSettingsService.getData('scripts/web-advanced/assets/sample-web-settings.json');
        promiseSampleWebSettings.then(function(response){
            vmWebAdvancedCtrl.sampleWebSettings = response.data;
        });

        bindEvent(window, 'message', function (e) {
            if(e.data == "App_Change"){
                var currentTab = vmWebAdvancedCtrl.selectedTab;
                onTabChange('').then(function(){
                    sendMessage(true);
                    vmWebAdvancedCtrl.selectedTab = currentTab;
                });
            }else if(angular.isObject(e.data) && e.data.Type == "Database_Change"){
                libraryName = e.data.Database;
                getWebViewDetails();
            }
        });

        function isAutocompleteFocus(elementId){
            if(angular.element('#' + elementId).attr('aria-expanded') == true || angular.element('#' + elementId).attr('aria-expanded') == "true"){
                return 'WebSettings.Views.type';
            }else{
                return 'WebSettings.Views.addMore';
            }
        }

        $translate('WebSettings.doYouWantToSaveTheChanges').then(function(translatedValue) {
            lblConfirmation = translatedValue;
        });

        $translate('WebSettings.warning').then(function(translatedValue) {
            lblWarning = translatedValue;
        });
        $translate('yes').then(function(translatedValue) {
            lblYes = translatedValue;
        });

        $translate('no').then(function(translatedValue) {
            lblNo = translatedValue;
        });

        function swapJsonKeyValues(input) {
            var one, output = {};
            for (one in input) {
                if (input.hasOwnProperty(one)) {
                    output[input[one]] = one;
                }
            }
            return output;
        }

        function isIe() {
            return false || !!document.documentMode;
        }
        
        function getClass() {
            if(isIe()) {
                return "ie";
            }
            else {
                return "non-ie";
            }
        }

        function setViewItemsModel(view, imProfileSettings, section){
            var viewModel = {};
            angular.forEach(view, function (value, key) {
                viewModel[key] = [];
                var filteredValues = [];
                if(vmWebAdvancedCtrl.isRestoringData){
                    filteredValues = value.filter(function filterFn(item) {
                        return $filter('filter')(attributeList[section], { ValueText: item }).length > 0;
                    });
                }else{
                    filteredValues = value;
                }
                angular.forEach(filteredValues,function(item){
                    var displayText = item;
                    if(imProfileSettings){
                        displayText = imProfileSettings[item];
                    }
                    viewModel[key].push({
                        'DisplayText': displayText
                    });
                });
            });
            return viewModel;
        }

        function setAttributeListItems(documentVisibleFields, matterVisibleFields){
            var promiseObjectModelList = [];
            var promiseObjectModel = $q.defer();
            var objectModel = {
                document:[],
                email:[],               
                client:[],
                folder:[]
            };
            objectModel[CONST_WEB_SETTINGS.MATTER]=[];
            angular.forEach(documentVisibleFields,function(item){
                var promiseVisibleFieldsObject = $q.defer();
                if(item.indexOf('custom') == 0){
                    promiseObjectModelList.push(promiseVisibleFieldsObject.promise);
                    getListItemObject(item).then(function(response){
                        objectModel.document.push(response);
                        objectModel.email.push(response);
                        promiseVisibleFieldsObject.resolve();
                    });
                    var customNumber = 0;
                    try {
                        customNumber = parseInt(item.slice(6))
                    } catch (err) {
                        customNumber = 0;
                    }
                    if ((customNumber >= 1 && customNumber <= 12) || (customNumber >= 29 && customNumber <= 30)) {
                        var promiseVisibleFieldsDescriptionObject = $q.defer();
                        promiseObjectModelList.push(promiseVisibleFieldsDescriptionObject.promise);
                        getListItemObject(item + 'description').then(function (response) {
                            objectModel.document.push(response);
                            objectModel.email.push(response);
                            promiseVisibleFieldsDescriptionObject.resolve();
                        });
                    }
                }
            });
            angular.forEach(matterVisibleFields,function(item){
                var promiseVisibleFieldsObject = $q.defer();
                if(item.indexOf('custom') == 0){
                    promiseObjectModelList.push(promiseVisibleFieldsObject.promise);
                    getListItemObject(item).then(function(response){
                        objectModel[CONST_WEB_SETTINGS.MATTER].push(response);
                        promiseVisibleFieldsObject.resolve();
                    });
                    var customNumber = 0;
                    try {
                        customNumber = parseInt(item.slice(6))
                    } catch (err) {
                        customNumber = 0;
                    }
                    if ((customNumber >= 1 && customNumber <= 12) || (customNumber >= 29 && customNumber <= 30)) {
                        var promiseVisibleFieldsDescriptionObject = $q.defer();
                        promiseObjectModelList.push(promiseVisibleFieldsDescriptionObject.promise);
                        getListItemObject(item + 'description').then(function (response) {
                            objectModel[CONST_WEB_SETTINGS.MATTER].push(response);
                            promiseVisibleFieldsDescriptionObject.resolve();
                        });
                    }
                }
            });
            var promiseAttributes = $q.defer();
            var promiseAttributeList = [];
            promiseObjectModelList.push(promiseAttributes.promise);
            var promiseStaticAttributes = WebSettingsService.getData('scripts/web-advanced/assets/static-attributes.json');
            promiseStaticAttributes.then(function (responseStaticAttributes) {
                angular.forEach(responseStaticAttributes.data.document.attributes, function(attr){
                    var promiseAttrObject = $q.defer();
                    promiseAttributeList.push(promiseAttrObject.promise);
                    getListItemObject(attr).then(function(response){
                        objectModel.document.push(response);
                        promiseAttrObject.resolve();
                    });
                });
                vmWebAdvancedCtrl.beforeDocumentSearchDesktopWebSettings = responseStaticAttributes.data.document.beforeAttributes;
                vmWebAdvancedCtrl.afterDocumentSearchDesktopWebSettings = responseStaticAttributes.data.document.afterAttributes;
                vmWebAdvancedCtrl.beforeDocumentSearchDesktopWebSettingsLabel = [];
                angular.forEach(vmWebAdvancedCtrl.beforeDocumentSearchDesktopWebSettings, function(item){                    
                    getListItemObject(item).then(function(response){
                        vmWebAdvancedCtrl.beforeDocumentSearchDesktopWebSettingsLabel.push(response.DisplayText);
                    });
                });
                vmWebAdvancedCtrl.afterDocumentSearchDesktopWebSettingsLabel = [];
                angular.forEach(vmWebAdvancedCtrl.afterDocumentSearchDesktopWebSettings, function(item){                    
                    getListItemObject(item).then(function(response){
                        vmWebAdvancedCtrl.afterDocumentSearchDesktopWebSettingsLabel.push(response.DisplayText);
                    });
                });

                angular.forEach(responseStaticAttributes.data.email.attributes, function(attr){
                    var promiseAttrObject = $q.defer();
                    promiseAttributeList.push(promiseAttrObject.promise);
                    getListItemObject(attr).then(function(response){
                        objectModel.email.push(response);
                        promiseAttrObject.resolve();
                    });
                });
                vmWebAdvancedCtrl.beforeEmailSearchDesktopWebSettings = responseStaticAttributes.data.email.beforeAttributes;
                vmWebAdvancedCtrl.afterEmailSearchDesktopWebSettings = responseStaticAttributes.data.email.afterAttributes;
                vmWebAdvancedCtrl.beforeEmailSearchDesktopWebSettingsLabel = [];
                angular.forEach(vmWebAdvancedCtrl.beforeEmailSearchDesktopWebSettings, function(item){                    
                    getListItemObject(item).then(function(response){
                        vmWebAdvancedCtrl.beforeEmailSearchDesktopWebSettingsLabel.push(response.DisplayText);
                    });
                });
                vmWebAdvancedCtrl.afterEmailSearchDesktopWebSettingsLabel = [];
                angular.forEach(vmWebAdvancedCtrl.afterEmailSearchDesktopWebSettings, function(item){                    
                    getListItemObject(item).then(function(response){
                        vmWebAdvancedCtrl.afterEmailSearchDesktopWebSettingsLabel.push(response.DisplayText);
                    });
                });

                angular.forEach(responseStaticAttributes.data[CONST_WEB_SETTINGS.MATTER].attributes, function(attr){
                    var promiseAttrObject = $q.defer();
                    promiseAttributeList.push(promiseAttrObject.promise);
                    getListItemObject(attr).then(function(response){
                        objectModel[CONST_WEB_SETTINGS.MATTER].push(response);
                        promiseAttrObject.resolve();
                    });
                });
                vmWebAdvancedCtrl.beforeMatterSearchDesktopWebSettings = responseStaticAttributes.data[CONST_WEB_SETTINGS.MATTER].beforeAttributes;
                vmWebAdvancedCtrl.afterMatterSearchDesktopWebSettings = responseStaticAttributes.data[CONST_WEB_SETTINGS.MATTER].afterAttributes;
                vmWebAdvancedCtrl.beforeMatterSearchDesktopWebSettingsLabel = [];
                angular.forEach(vmWebAdvancedCtrl.beforeMatterSearchDesktopWebSettings, function(item){                    
                    getListItemObject(item).then(function(response){
                        vmWebAdvancedCtrl.beforeMatterSearchDesktopWebSettingsLabel.push(response.DisplayText);
                    });
                });
                vmWebAdvancedCtrl.afterMatterSearchDesktopWebSettingsLabel = [];
                angular.forEach(vmWebAdvancedCtrl.afterMatterSearchDesktopWebSettings, function(item){                    
                    getListItemObject(item).then(function(response){
                        vmWebAdvancedCtrl.afterMatterSearchDesktopWebSettingsLabel.push(response.DisplayText);
                    });
                });

                angular.forEach(responseStaticAttributes.data.folder.attributes, function(attr){
                    var promiseAttrObject = $q.defer();
                    promiseAttributeList.push(promiseAttrObject.promise);
                    getListItemObject(attr).then(function(response){
                        objectModel.folder.push(response);
                        promiseAttrObject.resolve();
                    });
                });
                vmWebAdvancedCtrl.beforeFolderSearchDesktopWebSettings = responseStaticAttributes.data.folder.beforeAttributes;
                vmWebAdvancedCtrl.afterFolderSearchDesktopWebSettings = responseStaticAttributes.data.folder.afterAttributes;
                vmWebAdvancedCtrl.beforeFolderSearchDesktopWebSettingsLabel = [];
                angular.forEach(vmWebAdvancedCtrl.beforeFolderSearchDesktopWebSettings, function(item){                    
                    getListItemObject(item).then(function(response){
                        vmWebAdvancedCtrl.beforeFolderSearchDesktopWebSettingsLabel.push(response.DisplayText);
                    });
                });
                vmWebAdvancedCtrl.afterFolderSearchDesktopWebSettingsLabel = [];
                angular.forEach(vmWebAdvancedCtrl.afterFolderSearchDesktopWebSettings, function(item){                    
                    getListItemObject(item).then(function(response){
                        vmWebAdvancedCtrl.afterFolderSearchDesktopWebSettingsLabel.push(response.DisplayText);
                    });
                });

                if(responseStaticAttributes.data.client){
                    vmWebAdvancedCtrl.beforeClientSearchDesktopWebSettings = responseStaticAttributes.data.client.beforeAttributes;
                    vmWebAdvancedCtrl.afterClientSearchDesktopWebSettings = responseStaticAttributes.data.client.afterAttributes;
                    vmWebAdvancedCtrl.beforeClientSearchDesktopWebSettingsLabel = [];
                    angular.forEach(vmWebAdvancedCtrl.beforeClientSearchDesktopWebSettings, function(item){                    
                        getListItemObject(item).then(function(response){
                            vmWebAdvancedCtrl.beforeClientSearchDesktopWebSettingsLabel.push(response.DisplayText);
                        });
                    });
                    vmWebAdvancedCtrl.afterClientSearchDesktopWebSettingsLabel = [];
                    angular.forEach(vmWebAdvancedCtrl.afterClientSearchDesktopWebSettings, function(item){                    
                        getListItemObject(item).then(function(response){
                            vmWebAdvancedCtrl.afterClientSearchDesktopWebSettingsLabel.push(response.DisplayText);
                        });
                    });
                }
                $q.all(promiseAttributeList).then(function(){
                    promiseAttributes.resolve();
                });
            });

            $q.all(promiseObjectModelList).then(function(response){
                objectModel.document =  $filter('orderBy')(objectModel.document, 'DisplayText');
                objectModel.email =  $filter('orderBy')(objectModel.email, 'DisplayText');
                objectModel[CONST_WEB_SETTINGS.MATTER] =  $filter('orderBy')(objectModel[CONST_WEB_SETTINGS.MATTER], 'DisplayText');
                objectModel.client =  $filter('orderBy')(objectModel.client, 'DisplayText');
                objectModel.folder =  $filter('orderBy')(objectModel.folder, 'DisplayText');
                promiseObjectModel.resolve(objectModel);
            });

            return promiseObjectModel.promise;
        }

        function getListItemObject(item) {
            var promiseCaption = $q.defer();
            var listItemObj = {};
            var filteredItem = $filter('customLabel')(vmWebAdvancedCtrl.captionList, item);
            if (filteredItem == item && !$filter('isItemInList')(vmWebAdvancedCtrl.captionList, item)) {
                $translate('WebSettings.Views.' + item).then(function (translatedValue) {
                    listItemObj = {
                        DisplayText: translatedValue,
                        ValueText: item
                    };
                    promiseCaption.resolve(listItemObj);
                }, function () {
                    if (WebAdvancedFactory.getConflictMapplingList()[item]) {
                        var filteredItem = $filter('customLabel')(vmWebAdvancedCtrl.captionList, WebAdvancedFactory.getConflictMapplingList()[item]);
                        if (filteredItem == item && !$filter('isItemInList')(vmWebAdvancedCtrl.captionList, WebAdvancedFactory.getConflictMapplingList()[item])) {
                            $translate('WebSettings.Views.' + WebAdvancedFactory.getConflictMapplingList()[item]).then(function (translatedValue) {
                                listItemObj = {
                                    DisplayText: translatedValue,
                                    ValueText: item
                                };
                                promiseCaption.resolve(listItemObj);
                            }, function () {
                                listItemObj = {
                                    DisplayText: item,
                                    ValueText: item
                                };
                                promiseCaption.resolve(listItemObj);
                            });
                        }
                        else {
                            listItemObj = {
                                DisplayText: filteredItem,
                                ValueText: item
                            };
                            promiseCaption.resolve(listItemObj);
                        }
                    }
                    else {
                        listItemObj = {
                            DisplayText: item,
                            ValueText: item
                        };
                        promiseCaption.resolve(listItemObj);
                    }
                });
                promiseListCaptions.push(promiseCaption);
            }
            else {
                listItemObj = {
                    DisplayText: filteredItem,
                    ValueText: item
                };
                promiseCaption.resolve(listItemObj);
            }
            return promiseCaption.promise;
        }

        function getWebViewDetails() {
            var captionRequestModel = homeFactory.requestModelInstance();
            captionRequestModel.libraryName = libraryName;
            captionRequestModel.pageLength = 1000;
            captionRequestModel.language = localeDefault;
			
            var baseV2URL = homeFactory.getApiV2BaseUrl(libraryName);
            var apiUrlCaptions = baseV2URL + WebAdvancedFactory.getCaptionsAPI(captionRequestModel);
            var promiseCaptions = WebSettingsService.getData(apiUrlCaptions);
            var ApiUrlDocumentVisibleFileds = baseV2URL + WebAdvancedFactory.getVisibleFieldsUrl(libraryName, 'documents');
            var promiseDocumentVisibleFileds = WebSettingsService.getData(ApiUrlDocumentVisibleFileds);
            // var ApiUrlEmailVisibleFileds = baseV2URL + WebAdvancedFactory.getVisibleFieldsUrl(libraryName, 'emails');
            // var promiseEmailVisibleFileds = WebSettingsService.getData(ApiUrlEmailVisibleFileds);
            var ApiUrlMatterVisibleFileds = baseV2URL + WebAdvancedFactory.getVisibleFieldsUrl(libraryName, 'matters');
            var promiseMatterVisibleFileds = WebSettingsService.getData(ApiUrlMatterVisibleFileds);
            // var ApiUrlFolderVisibleFileds = baseV2URL + WebAdvancedFactory.getVisibleFieldsUrl(libraryName, 'folders');
            // var promiseFolderVisibleFileds = WebSettingsService.getData(ApiUrlFolderVisibleFileds);
            baseV2URL = homeFactory.getApiV2BaseUrl(libraryName, false, true);
            var apiUrlWebSettings = baseV2URL + WebAdvancedFactory.getWebSettingsAPI();
            var promiseWebSettings = WebSettingsService.getData(apiUrlWebSettings);
            var promiseImProfileMapping = WebSettingsService.getData('scripts/web-advanced/assets/imProfileMapping.json');
            var promiseDefaultWebSettings = WebSettingsService.getData('scripts/web-advanced/assets/default-values.json');
            $q.all([promiseCaptions, promiseWebSettings, promiseImProfileMapping, promiseDefaultWebSettings, promiseDocumentVisibleFileds, promiseMatterVisibleFileds]).then(function (response) {
                getDBList().then(function(response){
                    vmWebAdvancedCtrl.DBList = response;
                });
                vmWebAdvancedCtrl.captionList = [];
                angular.forEach(response[0].data.data, function (caption) {
                    vmWebAdvancedCtrl.captionList.push(homeFactory.getCaptionUIModel(caption));
                });
                promiseListCaptions = [];
                var promiseSetAttributeListItems = $q.defer();
                setAttributeListItems(response[4].data.data, response[5].data.data).then(function (responseList) {
                    attributeList = responseList;
                    promiseSetAttributeListItems.resolve();
                });
                var webSettingsList = {};
                var promiseWebSettingsData = $q.defer();
                if (response[1].status == 200 && response[1].data) {
                    webSettingsList = response[1].data;
                    promiseWebSettingsData.resolve();
                }
                if (!webSettingsList) {
                    webSettingsList = {};
                }
                if (!webSettingsList.views) {
                    webSettingsList["views"] = {};
                }
                angular.forEach(response[3].data.defaultvalues, function (viewValues, viewKey) {
                    if (!webSettingsList.views[viewKey]) {
                        webSettingsList.views[viewKey] = {};
                    }
                    if (!webSettingsList.views[viewKey][libraryName]) {
                        webSettingsList.views[viewKey][libraryName] = angular.copy(response[3].data.defaultvalues[viewKey]);
                    }
                });
                var promiseSetAttributeListAllItems = $q.defer();
                if (webSettingsList && webSettingsList.features && webSettingsList.features.additional_tab) {
                    vmWebAdvancedCtrl.additionalTab.enabled = webSettingsList.features.additional_tab.enable_additional_tab == true;
                    vmWebAdvancedCtrl.additionalTab.imageNumber = webSettingsList.features.additional_tab.image_number;
                    vmWebAdvancedCtrl.additionalTab.metadata = webSettingsList.features.additional_tab.metadata;
                    promiseSetAttributeListItems.promise.then(function () {
                        attributeList["client"] = [];
                        getListItemObject(vmWebAdvancedCtrl.additionalTab.metadata).then(function (response) {
                            attributeList.client.push(response);
                            promiseSetAttributeListAllItems.resolve();
                        });
                    });
                }
                else {
                    promiseSetAttributeListItems.promise.then(function () {
                        promiseSetAttributeListAllItems.resolve();
                    });
                }
                promiseSetAttributeListAllItems.promise.then(function () {
                    if (webSettingsList && webSettingsList.views) {
                        var imProfileSettings = swapJsonKeyValues(response[2].data);
                        var webSettingsViews = webSettingsList.views;
                        if (webSettingsViews[CONST_WEB_SETTINGS.DOCUMENT]) {
                            angular.forEach(webSettingsViews[CONST_WEB_SETTINGS.DOCUMENT], function (value, key) {
                                value = value.filter(substractArray(vmWebAdvancedCtrl.beforeDocumentSearchDesktopWebSettings));
                                value = value.filter(substractArray(vmWebAdvancedCtrl.afterDocumentSearchDesktopWebSettings));
                                webSettingsViews[CONST_WEB_SETTINGS.DOCUMENT][key] = value;
                            });
                            WebSettings["Document"] = setViewItemsModel(webSettingsViews[CONST_WEB_SETTINGS.DOCUMENT], imProfileSettings, 'document');
                            vmWebAdvancedCtrl.documentSearchDesktopWebSettings = angular.copy(WebSettings.Document[libraryName]);
                        }
                        if (webSettingsViews[CONST_WEB_SETTINGS.EMAIL]) {
                            angular.forEach(webSettingsViews[CONST_WEB_SETTINGS.EMAIL], function (value, key) {
                                value = value.filter(substractArray(vmWebAdvancedCtrl.beforeEmailSearchDesktopWebSettings));
                                value = value.filter(substractArray(vmWebAdvancedCtrl.afterEmailSearchDesktopWebSettings));
                                webSettingsViews[CONST_WEB_SETTINGS.EMAIL][key] = value;
                            });
                            WebSettings["Email"] = setViewItemsModel(webSettingsViews[CONST_WEB_SETTINGS.EMAIL], imProfileSettings, 'email');
                            vmWebAdvancedCtrl.emailSearchDesktopWebSettings = angular.copy(WebSettings.Email[libraryName]);
                        }
                        if (webSettingsViews[CONST_WEB_SETTINGS.MATTER]) {
                            angular.forEach(webSettingsViews[CONST_WEB_SETTINGS.MATTER], function (value, key) {
                                value = value.filter(substractArray(vmWebAdvancedCtrl.beforeMatterSearchDesktopWebSettings));
                                value = value.filter(substractArray(vmWebAdvancedCtrl.afterMatterSearchDesktopWebSettings));
                                webSettingsViews[CONST_WEB_SETTINGS.MATTER][key] = value;
                            });
                            WebSettings["Matter"] = setViewItemsModel(webSettingsViews[CONST_WEB_SETTINGS.MATTER], imProfileSettings, CONST_WEB_SETTINGS.MATTER);
                            vmWebAdvancedCtrl.matterSearchDesktopWebSettings = angular.copy(WebSettings.Matter[libraryName]);
                        }
                        if (webSettingsViews[CONST_WEB_SETTINGS.CLIENT]) {
                            angular.forEach(webSettingsViews[CONST_WEB_SETTINGS.CLIENT], function (value, key) {
                                value = value.filter(substractArray(vmWebAdvancedCtrl.beforeClientSearchDesktopWebSettings));
                                value = value.filter(substractArray(vmWebAdvancedCtrl.afterClientSearchDesktopWebSettings));
                                webSettingsViews[CONST_WEB_SETTINGS.CLIENT][key] = value;
                            });
                            WebSettings["Client"] = setViewItemsModel(webSettingsViews[CONST_WEB_SETTINGS.CLIENT], imProfileSettings, 'client');
                            vmWebAdvancedCtrl.clientSearchDesktopWebSettings = angular.copy(WebSettings.Client[libraryName]);
                        }
                        if (webSettingsViews[CONST_WEB_SETTINGS.FOLDER]) {
                            angular.forEach(webSettingsViews[CONST_WEB_SETTINGS.FOLDER], function (value, key) {
                                value = value.filter(substractArray(vmWebAdvancedCtrl.beforeFolderSearchDesktopWebSettings));
                                value = value.filter(substractArray(vmWebAdvancedCtrl.afterFolderSearchDesktopWebSettings));
                                webSettingsViews[CONST_WEB_SETTINGS.FOLDER][key] = value;
                            });
                            WebSettings["Folder"] = setViewItemsModel(webSettingsViews[CONST_WEB_SETTINGS.FOLDER], imProfileSettings, 'folder');
                            vmWebAdvancedCtrl.folderSearchDesktopWebSettings = angular.copy(WebSettings.Folder[libraryName]);
                        }
                    }
                    WebSettingsInitial = angular.copy(WebSettings);
                });
            });
        }

        function saveWebSettings(sectionName){
            var promiseSave = $q.defer();
            var webSettingsViews = {};
            var webSettingList = {};
            vmWebAdvancedCtrl.IsPostingData = true;
            var baseV2URL = homeFactory.getApiV2BaseUrl(libraryName, false, true);
            var webSettingsApiUrl = baseV2URL + WebAdvancedFactory.getWebSettingsAPI();
            var promiseWebSettingList = WebSettingsService.getData(webSettingsApiUrl);
            promiseWebSettingList.then(function(response){
                if(response.status == 200){
                    webSettingList = response.data;
                }
                angular.forEach(WebSettings, function(rootValue, rootKey){
                    if(!webSettingsViews[rootKey]){
                        webSettingsViews[rootKey] = {};
                    }
                    angular.forEach(rootValue, function(sectionValue, sectionKey){                        
                        if(!webSettingsViews[rootKey][sectionKey]){
                            webSettingsViews[rootKey][sectionKey] = {};
                        }
                        var attrList = [];
                        angular.forEach(sectionValue, function(attrValue, attrKey){
                            attrList.push(attrValue.DisplayText);
                        });
                        webSettingsViews[rootKey][sectionKey] = attrList;
                    });
                });
                var promiseImProfileMapping = WebSettingsService.getData('scripts/web-advanced/assets/imProfileMapping.json');
                promiseImProfileMapping.then(function (response) {
                    var imProfileSettings = response.data;
                    var webSettingsViewsTemp = angular.copy(webSettingsViews);

                    angular.forEach(webSettingsViewsTemp, function (view, viewKey) {
                        angular.forEach(view, function (section, sectionKey) {
                            angular.forEach(section, function (attr) {
                                webSettingsViews[viewKey][sectionKey][webSettingsViews[viewKey][sectionKey].indexOf(attr)] = imProfileSettings[attr];
                            });
                        });
                    })
                    if (!webSettingList["views"]){
                        webSettingList["views"] = {};
                    }
                    switch (sectionName) {
                        case 'documentsTab':
                            if (!webSettingList["views"][CONST_WEB_SETTINGS.DOCUMENT]) {
                                webSettingList["views"][CONST_WEB_SETTINGS.DOCUMENT] = {};
                            }
                            angular.forEach(webSettingsViews.Document, function(value, key){
                                value = (vmWebAdvancedCtrl.beforeDocumentSearchDesktopWebSettings || []).concat(value);
                                value = value.concat(vmWebAdvancedCtrl.afterDocumentSearchDesktopWebSettings || []);
                                webSettingsViews.Document[key] = value;
                            });
                            webSettingList["views"][CONST_WEB_SETTINGS.DOCUMENT][libraryName] = webSettingsViews.Document[libraryName];
                            break;
                        case 'emailsTab':
                            if (!webSettingList["views"][CONST_WEB_SETTINGS.EMAIL]) {
                                webSettingList["views"][CONST_WEB_SETTINGS.EMAIL] = {};
                            }
                            angular.forEach(webSettingsViews.Email, function(value, key){
                                value = (vmWebAdvancedCtrl.beforeEmailSearchDesktopWebSettings || []).concat(value);
                                value = value.concat(vmWebAdvancedCtrl.afterEmailSearchDesktopWebSettings || []);
                                webSettingsViews.Email[key] = value;
                            });
                            webSettingList["views"][CONST_WEB_SETTINGS.EMAIL][libraryName] = webSettingsViews.Email[libraryName];
                            break;
                        case 'mattersTab':
                            if (!webSettingList["views"][CONST_WEB_SETTINGS.MATTER]) {
                                webSettingList["views"][CONST_WEB_SETTINGS.MATTER] = {};
                            }
                            angular.forEach(webSettingsViews.Matter, function(value, key){
                                value = (vmWebAdvancedCtrl.beforeMatterSearchDesktopWebSettings || []).concat(value);
                                value = value.concat(vmWebAdvancedCtrl.afterMatterSearchDesktopWebSettings || []);
                                webSettingsViews.Matter[key] = value;
                            });
                            webSettingList["views"][CONST_WEB_SETTINGS.MATTER][libraryName] = webSettingsViews.Matter[libraryName];
                            break;
                        case 'clientsTab':
                            if (!webSettingList["views"][CONST_WEB_SETTINGS.CLIENT]) {
                                webSettingList["views"][CONST_WEB_SETTINGS.CLIENT] = {};
                            }
                            angular.forEach(webSettingsViews.Client, function(value, key){
                                value = (vmWebAdvancedCtrl.beforeClientSearchDesktopWebSettings || []).concat(value);
                                value = value.concat(vmWebAdvancedCtrl.afterClientSearchDesktopWebSettings || []);
                                webSettingsViews.Client[key] = value;
                            });
                            webSettingList["views"][CONST_WEB_SETTINGS.CLIENT][libraryName] = webSettingsViews.Client[libraryName];
                            break;
                        case 'foldersTab':
                            if (!webSettingList["views"][CONST_WEB_SETTINGS.FOLDER]) {
                                webSettingList["views"][CONST_WEB_SETTINGS.FOLDER] = {};
                            }
                            angular.forEach(webSettingsViews.Folder, function(value, key){
                                value = (vmWebAdvancedCtrl.beforeFolderSearchDesktopWebSettings || []).concat(value);
                                value = value.concat(vmWebAdvancedCtrl.afterFolderSearchDesktopWebSettings || []);
                                webSettingsViews.Folder[key] = value;
                            });
                            webSettingList["views"][CONST_WEB_SETTINGS.FOLDER][libraryName] = webSettingsViews.Folder[libraryName];
                            break;
                    }
                    ApplytoAllDb(webSettingList,sectionName).then(function(finalBody){
                           
                    var promisePostWebSettingList = WebSettingsService.postWithBody(finalBody, webSettingsApiUrl);
                    promisePostWebSettingList.then(function(response){
                        if(response.status == 201){
                            $('div#toastPopup').addClass('show');
                            $timeout(function() {
                                $('div#toastPopup').removeClass('show');   
                            }, 2000);
                        }
                        $timeout(function() {                      
                            vmWebAdvancedCtrl.isRestoringData = false;
                        }, 2500);
                        vmWebAdvancedCtrl.IsPostingData = false; 
                        promiseSave.resolve();
                    })
                    WebSettingsInitial = angular.copy(WebSettings);
                       
                    })
                   
                });
            })
            return promiseSave.promise;
        }

        function ApplytoAllDb(RequestBody,sectionName){
            var deferred=$q.defer();
            if(vmWebAdvancedCtrl.applyInAllDB && RequestBody["views"]){
                //var apiUrl=homeFactory.getApiV2BaseUrl('')+homeFactory.getDBListAPI();
                //homeService.getData(apiUrl).then(function(response){
                getDBList().then(function(response){    
                    if(response.length > 0){
                         angular.forEach(response, function(item){
                                 
                              switch (sectionName) {
                        case 'documentsTab':
                            if(RequestBody["views"][CONST_WEB_SETTINGS.DOCUMENT] && RequestBody["views"][CONST_WEB_SETTINGS.DOCUMENT][libraryName])
                                RequestBody["views"][CONST_WEB_SETTINGS.DOCUMENT][item.id]=angular.copy(RequestBody["views"][CONST_WEB_SETTINGS.DOCUMENT][libraryName]);
                            break;
                        case 'emailsTab':
                            
                             if(RequestBody["views"][CONST_WEB_SETTINGS.EMAIL] && RequestBody["views"][CONST_WEB_SETTINGS.EMAIL][libraryName])
                                RequestBody["views"][CONST_WEB_SETTINGS.EMAIL][item.id]=angular.copy(RequestBody["views"][CONST_WEB_SETTINGS.EMAIL][libraryName]);
                          
                           break;
                        case 'mattersTab':
                            if(RequestBody["views"][CONST_WEB_SETTINGS.MATTER] && RequestBody["views"][CONST_WEB_SETTINGS.MATTER][libraryName])
                                RequestBody["views"][CONST_WEB_SETTINGS.MATTER][item.id]=angular.copy(RequestBody["views"][CONST_WEB_SETTINGS.MATTER][libraryName]);
                          
  
                            break;
                        case 'clientsTab':
                             if(RequestBody["views"][CONST_WEB_SETTINGS.CLIENT] && RequestBody["views"][CONST_WEB_SETTINGS.CLIENT][libraryName])
                                RequestBody["views"][CONST_WEB_SETTINGS.CLIENT][item.id]=angular.copy(RequestBody["views"][CONST_WEB_SETTINGS.CLIENT][libraryName]);
                          
                            
                            break;
                        case 'foldersTab':
                            if(RequestBody["views"][CONST_WEB_SETTINGS.FOLDER] && RequestBody["views"][CONST_WEB_SETTINGS.FOLDER][libraryName])
                                RequestBody["views"][CONST_WEB_SETTINGS.FOLDER][item.id]=angular.copy(RequestBody["views"][CONST_WEB_SETTINGS.FOLDER][libraryName]);
                            break;
                    }
                  


                            });
                    } 
                     deferred.resolve(RequestBody);
                    
                },function(response){
                     deferred.resolve(RequestBody);
                }
                );
                   
            }else{
                deferred.resolve(RequestBody);
            }
            return deferred.promise;
        }

        function removeToast(){
            $('div#toastPopup').removeClass('show');
        }
        
        function addNewFieldChange(newVal, list, txtId){
            var listValue = angular.copy(newVal.ValueText);
            if(listValue && listValue.length > 0){
                list.push({
                    'DisplayText': listValue
                });
                if(txtId){
                    txtId = '#'+txtId;
                    if($(txtId).length > 0){
                        $(txtId)[0].value = '';
                    }
                    $timeout(function(){
                        // newVal.DisplayText = '';
                        newVal.searchText = undefined;
                    });
                }
            }
            return '';
        }
        
        function removeItemInWebSettings(item, settings){
            settings.splice(settings.indexOf(item), 1);
        }

        function bindEvent(element, eventName, eventHandler) {
            if (element.addEventListener) {
                element.addEventListener(eventName, eventHandler, false);
            } else if (element.attachEvent) {
                element.attachEvent('on' + eventName, eventHandler);
            }
        }

        var sendMessage = function (msg) {
            window.parent.postMessage(msg, '*');
        };

        function isTabModified(){
            var isModified = false;
            switch (vmWebAdvancedCtrl.selectedTab) {
                case 'documentsTab':
                    if(vmWebAdvancedCtrl.documentsSearchDesktopEditMode){
                        applyEditDocumentsSearchDesktop();
                    }
                    isModified = !angular.equals(WebSettingsInitial.Document[libraryName], WebSettings.Document[libraryName]);      
                    break;
                case 'emailsTab':
                    if(vmWebAdvancedCtrl.emailsSearchDesktopEditMode){
                        applyEditEmailsSearchDesktop();
                    }
                    isModified = !angular.equals(WebSettingsInitial.Email[libraryName], WebSettings.Email[libraryName]);      
                    break;
                case 'mattersTab':
                    if(vmWebAdvancedCtrl.mattersSearchDesktopEditMode){
                        applyEditMattersSearchDesktop();
                    }
                    isModified = !angular.equals(WebSettingsInitial.Matter[libraryName], WebSettings.Matter[libraryName]);      
                    break;
                case 'clientsTab':
                    if(vmWebAdvancedCtrl.clientsSearchDesktopEditMode){
                        applyEditClientsSearchDesktop();
                    }
                    isModified = !angular.equals(WebSettingsInitial.Client[libraryName], WebSettings.Client[libraryName]);      
                    break;
                case 'foldersTab':
                    if(vmWebAdvancedCtrl.foldersSearchDesktopEditMode){
                        applyEditFoldersSearchDesktop();
                    }
                    isModified = !angular.equals(WebSettingsInitial.Folder[libraryName], WebSettings.Folder[libraryName]);      
                    break;
            }
            return isModified;
        }
        
        function onTabChange(selectedTab){
            var promiseSave = $q.defer();
            if(vmWebAdvancedCtrl.selectedTab != selectedTab){
                if (isTabModified()) {
                    var confirmDocumentSave = $mdDialog.confirm()
                        .title(lblWarning)
                        .theme('confirm-dialog')
                        .textContent(lblConfirmation)
                        .ariaLabel('Save Changes')
                        .ok(lblYes)
                        .cancel(lblNo);

                    $mdDialog.show(confirmDocumentSave).then(function () {
                        saveWebSettings(vmWebAdvancedCtrl.selectedTab).then(function(){
                            promiseSave.resolve();
                        });
                        vmWebAdvancedCtrl.selectedTab = selectedTab;
                    }, function () {
                        switch (vmWebAdvancedCtrl.selectedTab) {
                            case 'documentsTab':
                                if (WebSettingsInitial.Document && WebSettingsInitial.Document[libraryName]) {
                                    if(!WebSettings["Document"]){
                                        WebSettings["Document"] = {};
                                    }
                                    WebSettings["Document"][libraryName] = angular.copy(WebSettingsInitial.Document[libraryName]);
                                    vmWebAdvancedCtrl.documentSearchDesktopWebSettings = angular.copy(WebSettings.Document[libraryName]);
                                }
                                break;
                            case 'emailsTab':
                                if (WebSettingsInitial.Email && WebSettingsInitial.Email[libraryName]) {
                                    if(!WebSettings["Email"]){
                                        WebSettings["Email"] = {};
                                    }
                                    WebSettings["Email"][libraryName] = angular.copy(WebSettingsInitial.Email[libraryName]);
                                    vmWebAdvancedCtrl.emailSearchDesktopWebSettings = angular.copy(WebSettings.Email[libraryName]);
                                }
                                break;
                            case 'mattersTab':
                                if (WebSettingsInitial.Matter && WebSettingsInitial.Matter[libraryName]) {
                                    if(!WebSettings["Matter"]){
                                        WebSettings["Matter"] = {};
                                    }
                                    WebSettings["Matter"][libraryName] = angular.copy(WebSettingsInitial.Matter[libraryName]);
                                    vmWebAdvancedCtrl.matterSearchDesktopWebSettings = angular.copy(WebSettings.Matter[libraryName]);
                                }
                                break;
                            case 'clientsTab':
                                if (WebSettingsInitial.Client && WebSettingsInitial.Client[libraryName]) {
                                    if(!WebSettings["Client"]){
                                        WebSettings["Client"] = {};
                                    }
                                    WebSettings["Client"][libraryName] = angular.copy(WebSettingsInitial.Client[libraryName]);
                                    vmWebAdvancedCtrl.clientSearchDesktopWebSettings = angular.copy(WebSettings.Client[libraryName]);
                                }
                                break;
                            case 'foldersTab':
                                if (WebSettingsInitial.Folder && WebSettingsInitial.Folder[libraryName]) {
                                    if(!WebSettings["Folder"]){
                                        WebSettings["Folder"] = {};
                                    }
                                    WebSettings["Folder"][libraryName] = angular.copy(WebSettingsInitial.Folder[libraryName]);
                                    vmWebAdvancedCtrl.folderSearchDesktopWebSettings = angular.copy(WebSettings.Folder[libraryName]);
                                }
                                break;
                        }
                        vmWebAdvancedCtrl.selectedTab = selectedTab;
                        promiseSave.resolve();
                    });
                }else{
                    vmWebAdvancedCtrl.selectedTab = selectedTab;
                    promiseSave.resolve();
                }
            }else{
                promiseSave.resolve();
            }
            return promiseSave.promise;
        }

        function restoreDefault(sectionName) {
            vmWebAdvancedCtrl.isRestoringData = true;
            var promiseDefaultWebSettings = WebSettingsService.getData('scripts/web-advanced/assets/default-values.json');
            var promiseImProfileMapping = WebSettingsService.getData('scripts/web-advanced/assets/imProfileMapping.json');        
            $q.all([promiseDefaultWebSettings, promiseImProfileMapping]).then(function(response){
                var defaultWebSettings = response[0].data;

                if (defaultWebSettings && defaultWebSettings.defaultvalues) {
                    var imProfileSettings = swapJsonKeyValues(response[1].data);
                    var webSettingsViews = defaultWebSettings.defaultvalues;
                    switch(sectionName){
                        case 'documentsTab':
                            if (webSettingsViews[CONST_WEB_SETTINGS.DOCUMENT]) {
                                WebSettings.Document[libraryName] = setViewItemsModel(webSettingsViews, imProfileSettings, 'document')[CONST_WEB_SETTINGS.DOCUMENT];
                                vmWebAdvancedCtrl.documentSearchDesktopWebSettings = angular.copy(WebSettings.Document[libraryName]);
                            }
                            break;
                        case 'emailsTab':
                            if (webSettingsViews[CONST_WEB_SETTINGS.EMAIL]) {
                                WebSettings.Email[libraryName] = setViewItemsModel(webSettingsViews, imProfileSettings, 'email')[CONST_WEB_SETTINGS.EMAIL];
                                vmWebAdvancedCtrl.emailSearchDesktopWebSettings = angular.copy(WebSettings.Email[libraryName]);
                            }
                            break;
                        case 'mattersTab':
                            if (webSettingsViews[CONST_WEB_SETTINGS.MATTER]) {
                                WebSettings.Matter[libraryName] = setViewItemsModel(webSettingsViews, imProfileSettings, CONST_WEB_SETTINGS.MATTER)[CONST_WEB_SETTINGS.MATTER];
                                vmWebAdvancedCtrl.matterSearchDesktopWebSettings = angular.copy(WebSettings.Matter[libraryName]);
                            }
                            break;
                        case 'clientsTab':
                            if (webSettingsViews[CONST_WEB_SETTINGS.CLIENT]) {
                                WebSettings.Client[libraryName] = setViewItemsModel(webSettingsViews, imProfileSettings, 'client')[CONST_WEB_SETTINGS.CLIENT];
                                vmWebAdvancedCtrl.clientSearchDesktopWebSettings = angular.copy(WebSettings.Client[libraryName]);
                            }
                            break;
                        case 'foldersTab':
                            if (webSettingsViews[CONST_WEB_SETTINGS.FOLDER]) {
                                WebSettings.Folder[libraryName] = setViewItemsModel(webSettingsViews, imProfileSettings, 'folder')[CONST_WEB_SETTINGS.FOLDER];
                                vmWebAdvancedCtrl.folderSearchDesktopWebSettings = angular.copy(WebSettings.Folder[libraryName]);
                            }
                            break;
                    }                    
                    saveWebSettings(sectionName);
                }
            })
        }

        //************** Document *********************//

        function editDocumentsSearchDesktop(){
            vmWebAdvancedCtrl.documentSearchDesktopWebSettings = angular.copy(WebSettings.Document[libraryName]);
            vmWebAdvancedCtrl.documentsSearchDesktopEditMode = true;
        }

        function closeEditDocumentsSearchDesktop(){
            vmWebAdvancedCtrl.documentsSearchDesktopEditMode = false;
            vmWebAdvancedCtrl.documentSearchDesktopWebSettings = angular.copy(WebSettings.Document[libraryName]);
        }

        function applyEditDocumentsSearchDesktop(){
            vmWebAdvancedCtrl.documentsSearchDesktopEditMode = false;
            WebSettings.Document[libraryName] = angular.copy(vmWebAdvancedCtrl.documentSearchDesktopWebSettings);
            // saveWebSettings('DocumentSearchDesktop');
        }

        //************** Document *********************//

        //************** Email *********************//

        function editEmailsSearchDesktop(){
            vmWebAdvancedCtrl.emailSearchDesktopWebSettings = angular.copy(WebSettings.Email[libraryName]);
            vmWebAdvancedCtrl.emailsSearchDesktopEditMode = true;
        }

        function closeEditEmailsSearchDesktop(){
            vmWebAdvancedCtrl.emailsSearchDesktopEditMode = false;
            vmWebAdvancedCtrl.emailSearchDesktopWebSettings = angular.copy(WebSettings.Email[libraryName]);
        }

        function applyEditEmailsSearchDesktop(){
            vmWebAdvancedCtrl.emailsSearchDesktopEditMode = false;
            WebSettings.Email[libraryName] = angular.copy(vmWebAdvancedCtrl.emailSearchDesktopWebSettings);
            // saveWebSettings('EmailSearchDesktop');
        }

        //************** Email *********************//
        
        //************** Matter *********************//

        function editMattersSearchDesktop(){
            vmWebAdvancedCtrl.matterSearchDesktopWebSettings = angular.copy(WebSettings.Matter[libraryName]);
            vmWebAdvancedCtrl.mattersSearchDesktopEditMode = true;
        }

        function closeEditMattersSearchDesktop(){
            vmWebAdvancedCtrl.mattersSearchDesktopEditMode = false;
            vmWebAdvancedCtrl.matterSearchDesktopWebSettings = angular.copy(WebSettings.Matter[libraryName]);
        }

        function applyEditMattersSearchDesktop(){
            vmWebAdvancedCtrl.mattersSearchDesktopEditMode = false;
            WebSettings.Matter[libraryName] = angular.copy(vmWebAdvancedCtrl.matterSearchDesktopWebSettings);
            // saveWebSettings('MatterSearchDesktop');
        }

        //************** Matter *********************//

        //************** Client *********************//

        function editClientsSearchDesktop(){
            vmWebAdvancedCtrl.clientSearchDesktopWebSettings = angular.copy(WebSettings.Client[libraryName]);
            vmWebAdvancedCtrl.clientsSearchDesktopEditMode = true;
        }

        function closeEditClientsSearchDesktop(){
            vmWebAdvancedCtrl.clientsSearchDesktopEditMode = false;
            vmWebAdvancedCtrl.clientSearchDesktopWebSettings = angular.copy(WebSettings.Client[libraryName]);
        }

        function applyEditClientsSearchDesktop(){
            vmWebAdvancedCtrl.clientsSearchDesktopEditMode = false;
            WebSettings.Client[libraryName] = angular.copy(vmWebAdvancedCtrl.clientSearchDesktopWebSettings);
            // saveWebSettings('ClientSearchDesktop');
        }

        //************** Client *********************//
        
        //************** Folder *********************//

        function editFoldersSearchDesktop(){
            vmWebAdvancedCtrl.folderSearchDesktopWebSettings = angular.copy(WebSettings.Folder[libraryName]);
            vmWebAdvancedCtrl.foldersSearchDesktopEditMode = true;
        }

        function closeEditFoldersSearchDesktop(){
            vmWebAdvancedCtrl.foldersSearchDesktopEditMode = false;
            vmWebAdvancedCtrl.folderSearchDesktopWebSettings = angular.copy(WebSettings.Folder[libraryName]);
        }

        function applyEditFoldersSearchDesktop(){
            vmWebAdvancedCtrl.foldersSearchDesktopEditMode = false;
            WebSettings.Folder[libraryName] = angular.copy(vmWebAdvancedCtrl.folderSearchDesktopWebSettings);
            // saveWebSettings('FolderSearchDesktop');
        }
										
		function getCustomerId() {
             var deferred = $q.defer();
            var apiUrl;

            var baseUrlWithoutAPIV2 = homeFactory.getApiV2BaseUrl('', true, true);
            if (baseUrlWithoutAPIV2.indexOf('imcc/') != -1) {
                apiUrl = baseUrlWithoutAPIV2 + WebAdvancedFactory.getInitDataAPI();
            } else {
                apiUrl = baseUrlWithoutAPIV2 + WebAdvancedFactory.getStartupInitDataAPI();
            }

            var promise = WebSettingsService.getData(apiUrl);
            promise.then(function(response) {
                customerName = '1';  
                if (response.status === 200 && response.data) {
                    if (response.data.customer_id && response.data.customer_id.toString().trim().length > 0) {
                        customerName = response.data.customer_id.toString();
                    } else if (response.data.data && response.data.data.customer_id && response.data.data.customer_id.toString().trim().length > 0) {
                        customerName = response.data.data.customer_id.toString();
                    }
                }
                deferred.resolve();
            });
            return deferred.promise;
        }
        
        //************** Folder *********************//
		
		function showDropDownIcon(txtId){
			var returnValue = false; 
			txtId = '#'+txtId;
			if($(txtId).parents('md-autocomplete-wrap').hasClass('md-menu-showing'))
				returnValue = true; 
			return returnValue;
		}

        function getDBList(){
            var deferred = $q.defer();
            var apiUrl=homeFactory.getApiV2BaseUrl('')+homeFactory.getDBListAPI();
                homeService.getData(apiUrl).then(function(response){
                    if(response.data.data){
                        deferred.resolve(response.data.data);
                    } else{
                        deferred.resolve([]);
                    }
                        
                },function(response){
                        deferred.resolve([]);
                });
            return deferred.promise;
        }
		
		function getDefaultLocale() {
            var deferred = $q.defer();

            if ($location.search().locale && $location.search().locale.toString().trim().length > 0) {
                deferred.resolve({ Status: 0, LocaleDefault: $location.search().locale });
                return deferred.promise;
            }

            if (localStorage.getItem('locale') && localStorage.getItem('locale').toString().trim().length > 0) {
                deferred.resolve({ Status: 0, LocaleDefault: localStorage.getItem('locale') });
                return deferred.promise;
            }

            var baseV2ApiUrl = homeFactory.getApiV2BaseUrl(libraryName, false, true);
            var apiUrlWebSettings = baseV2ApiUrl + WebAdvancedFactory.getWebSettingsAPI();
            var promiseWebSetting = WebSettingsService.getData(apiUrlWebSettings);
            promiseWebSetting.then(function(responseWebSettings) {
                if (responseWebSettings.status === 200 && responseWebSettings.data && responseWebSettings.data.general &&
                    responseWebSettings.data.general.language && responseWebSettings.data.general.language.trim().length > 0) {
                    deferred.resolve({ Status: 0, LocaleDefault: responseWebSettings.data.general.language });
                } else {
                    var baseURL = homeFactory.getApiV2BaseUrl();
                    var apiUrl = homeFactory.getServerVersionAPI();
                    var promise = homeService.getData(baseURL + apiUrl);
                    promise.then(function(response) {
                        if (response && response.data && response.data.data && response.data.data['Locale Default']) {
                            deferred.resolve({ Status: 0, LocaleDefault: response.data.data['Locale Default'] });
                        } else {
                            deferred.resolve({ Status: 0, LocaleDefault: 'en-US' });
                        }
                    });
                }
            });
            return deferred.promise;
        }
    }
})();