module.exports = {

    debug: true,
    releaseBuild: true,
    build_dir: 'build',
    core_files_html: './*.html',
    app_files: {
        assets: [
            './assets/**/*',
            '!./assets/**/*.css'
        ],
        app_js: [
            './framework/**/*.js'
        ],
        app_html: [
            './framework/**/*.html'
        ],
        app_styles: [
            './framework/**/*.css',
            './framework/**/*.scss'
        ],
        app_asset: [
            './framework/**/*.jpg',
            './framework/**/*.png',
            './framework/**/*.gif',
            './framework/**/*.ico',
            './framework/**/*.svg',
            './framework/**/*.pk'
        ]
    }
}