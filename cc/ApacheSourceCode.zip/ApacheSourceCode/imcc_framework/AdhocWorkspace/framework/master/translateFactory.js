﻿(function() {
    'use strict';

    define(['angular'], function(angular) {
        angular.module('iManage.adHocWorkspace').factory('translateFactory', translateFactory);
    });
    translateFactory.$inject = ["$q", "$timeout", "$location", "translateService", 'masterFactory', 'TSU_TRANSLATE'];

    function translateFactory($q, $timeout, $location, translateService, masterFactory, TSU_TRANSLATE) {

        return function(options) {
            var deferred = $q.defer(),
                translations;

            var WebLocation = window.location.href.split('dialogs/');
            baseUrl = WebLocation[0];
            var basePath = WebLocation[0].split('imanage/');
            basePath = basePath[0].split('imcc/');
            baseIMCCApiUrl = basePath[0];
            // baseHost = response.hostbase;

            getCustomerId().then(function() {
                var SystemConfig = getLocaleDefault();
                SystemConfig.then(function(responseConfig) {
                    var apiUrl = basePath[0] + 'imanage/' + TSU_TRANSLATE.GET_TRANSLATE;
                    if (responseConfig.LocaleDefault) {
                        apiUrl += "?locale=" + responseConfig.LocaleDefault;
                    }

                    var promise = translateService.getJson(apiUrl);
                    promise.then(function(response) {
                        if (response && response.data) {
                            translations = response.data;
                        }
                        deferred.resolve(translations);
                    });
                });
            });
            return deferred.promise;
        };

        function getCustomerId() {
            var deferred = $q.defer();

            var apiUrl = masterFactory.getApiV2BaseUrl('', true, true);
            if (apiUrl.indexOf('imcc/') !== -1) {
                apiUrl += TSU_TRANSLATE.GET_INIT_DATA;
            } else {
                apiUrl = TSU_TRANSLATE.GET_STARTUP_INIT_DATA;
            }

            var promise = translateService.getJson(apiUrl);
            promise.then(function(response) {
                customerName = '1';
                if (response.status === 200 && response.data) {
                    if (response.data.customer_id && response.data.customer_id.toString().trim().length > 0) {
                        customerName = response.data.customer_id.toString();
                    } else if (response.data.data && response.data.data.customer_id && response.data.data.customer_id.toString().trim().length > 0) {
                        customerName = response.data.data.customer_id.toString();
                    }
                }
                deferred.resolve();
            });
            return deferred.promise;
        }

        function getLocaleDefault() {
            var deferred = $q.defer();

            if ($location.search().locale && $location.search().locale.toString().trim().length > 0) {
                deferred.resolve({ Status: 0, LocaleDefault: $location.search().locale });
                return deferred.promise;
            }

            if (localStorage.getItem('locale') && localStorage.getItem('locale').toString().trim().length > 0) {
                deferred.resolve({ Status: 0, LocaleDefault: localStorage.getItem('locale') });
                return deferred.promise;
            }

            var promiseDb = getPrimaryDatabase();
            promiseDb.then(function(response) {
                var apiUrl = masterFactory.getApiV2BaseUrl((response.PrimaryDB || ''), false, false);
                if (apiUrl.indexOf('imcc/') !== -1) {
                    apiUrl += TSU_TRANSLATE.WEB_SETTINGS_URL;
                } else {
                    apiUrl += TSU_TRANSLATE.CONFIG_WEB_SETTINGS_URL;
                }

                var promiseWebSetting = translateService.getJson(apiUrl);
                promiseWebSetting.then(function(responseWebSetting) {
                    var localeDefault = 'en-US';
                    if (response.LocaleDefault && response.LocaleDefault.length > 0) {
                        localeDefault = response.LocaleDefault;
                    }
                    if (responseWebSetting.status === 200 && responseWebSetting.data) {
                        if (responseWebSetting.data.general && responseWebSetting.data.general.language &&
                            responseWebSetting.data.general.language.trim().length > 0) {
                            localeDefault = responseWebSetting.data.general.language;
                        }
                    }
                    deferred.resolve({ Status: 0, LocaleDefault: localeDefault });
                });
            });
            return deferred.promise;
        }

        function getPrimaryDatabase() {
            var deferred = $q.defer();

            var baseV2Url = masterFactory.getApiV2BaseUrl('', false, false);
            var dbListUrl = baseV2Url + TSU_TRANSLATE.GET_DB_LIST;
            var promiseDataBase = translateService.getJson(dbListUrl);
            promiseDataBase.then(function(responsedb) {

                var usesrDbList = [];
                angular.forEach(responsedb.data.data, function(db) {
                    usesrDbList.push(db.id);
                });

                var apiUrl = baseV2Url + TSU_TRANSLATE.GET_SYSTEM_CONFIG;
                var promise = translateService.getJson(apiUrl);
                promise.then(function(response) {
                    var primarydbName;
                    var localeDefault = 'en-US';

                    if (response && response.data && response.data.data) {
                        if (response.data.data['Locale Default'] && response.data.data['Locale Default'].toString().trim().length > 0) {
                            localeDefault = response.data.data['Locale Default'];
                        }

                        if (response.data.data.databases && response.data.data.databases.length > 0) {
                            angular.forEach(response.data.data.databases, function(db) {
                                if (db.Primary === 'Y') {
                                    if (usesrDbList.indexOf(db.id) > -1) {
                                        primarydbName = db.id;
                                    }
                                }
                            });
                        }
                    }
                    if (!primarydbName && usesrDbList.length > 0) {
                        primarydbName = usesrDbList[0];
                    }
                    deferred.resolve({ PrimaryDB: primarydbName, LocaleDefault: localeDefault });
                }, function(response) {
                    deferred.resolve({ PrimaryDB: undefined, LocaleDefault: 'en-US' });
                });
            });
            return deferred.promise;
        }
    }
})();