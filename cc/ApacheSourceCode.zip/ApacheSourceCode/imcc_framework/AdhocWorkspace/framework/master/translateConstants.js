﻿(function() {
    'use strict';

    define(['angular'], function() {
        angular.module('iManage.adHocWorkspace').constant('TSU_TRANSLATE', {
            GET_TRANSLATE: 'startup/strings',
            GET_INIT_DATA: 'init-data',
            WEB_SETTINGS_URL: 'web/customizations',
            CONFIG_WEB_SETTINGS_URL: 'config/Web/files/websettings',
            GET_DB_LIST: 'libraries',
            GET_SYSTEM_CONFIG: 'system/config?include_databases=true',
            GET_STARTUP_INIT_DATA: 'startup/init-data'
        });
    });
})();