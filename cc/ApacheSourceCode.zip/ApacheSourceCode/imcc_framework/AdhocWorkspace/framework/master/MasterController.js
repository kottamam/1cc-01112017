(function() {
    'use strict';

    define(['angular'], function() {
        angular.module('iManage.adHocWorkspace').controller("masterController", masterController);
    });

    masterController.$inject = ['loginService', '$state', '$cookies', 'masterFactory', '$interval', '$timeout', 'masterService', '$location', '$localStorage','$translate'];

    function masterController(loginService, $state, $cookies, masterFactory, $interval, $timeout, masterService, $location, $localStorage,$translate) {
        var mc = this;
        mc.$storage = $localStorage;

        if (mc.$storage.maxAge && mc.$storage.LastActiveTime) {
            if (new Date().getTime() > mc.$storage.LastActiveTime + (mc.$storage.maxAge * 1000)) {
                $localStorage.$reset();
            }
        }
        mc.loginModel = {
            UserName: '',
            Password: '',
            ApiUrl: '',
            AuthKey: '',
            ApplicationName: 'Control Center',
            networklogin: false,
            UserSessionTimeOut: null
        };

        mc.PasswordDisplayText = '';
        mc.onError = false;
        mc.message = '';
        mc.IsLoading = false;
        mc.passwordType = 'password';
        mc.objectDet = {
            name: ''
        };
        mc.maxAge = undefined;


        mc.getlogDetails = getlogDetails;
        mc.setSecurityLogDetails = setSecurityLogDetails;
        mc.validateUser = validateUser;
        mc.onLoginKeypress = onLoginKeypress;
        mc.hideShowPassword = hideShowPassword;
        $translate('adhocWorkspace.createWorkspace').then(function (translatedValue) {
            mc.ApplicationTitle  = translatedValue;
        });
        
        //mc.redirectToLoginPage = redirectToLoginPage;

        // function redirectToLoginPage(queryParam) {
        //     if (!baseUrl || baseUrl.trim().length === 0) {
        //         var settings = masterFactory.masterInitailValues();
        //         settings.then(function(response) {
        //             baseUrl = response.apiurl;
        //             baseIMCCApiUrl = response.imccapiurl;
        //             baseHost = response.hostbase;
        //             customerName = response.customername;
        //             redirectToLoginPage($location.search());
        //         });
        //     }
        // }

        function getlogDetails(level, message) {
            // var apiUrl = masterFactory.getAPIUrl('SAVELOG');
            // masterService.getlogDetails(apiUrl, level, message);
        }

        function setSecurityLogDetails(level, state, userAffected, activity, activityParam) {
            //var apiUrl = masterFactory.getAPIUrl('SECURITYLOG');
            //var message = mc.loginModel.UserName + ' - ' + state + ' - ' + userAffected + ' - ' + activity;
            //masterService.getlogDetails(apiUrl, level, message);
        }

        function validateUser(isApply) {
            mc.message = '';
            mc.onError = false;

            if (mc.loginModel.UserName.trim().length == 0 || mc.loginModel.Password.trim().length == 0)
                return;

            mc.IsLoading = true;
            closePreviousLoggedSession();
            /*if (!isApply) {
                mc.loginModel.Personal = "admin";
            } else {
                mc.loginModel.Personal = undefined;
            }*/
            mc.loginModel.Personal = undefined;
            mc.getlogDetails("Debug", "for Validate " + mc.loginModel.UserName + " in LogIn Page");
            var baseApiUrlV2 = masterFactory.getApiV2BaseUrl(null, true);
            var promise = loginService.validateUser(baseApiUrlV2, mc.loginModel);
            promise.then(function(response) { autheriseUser(response, isApply); }, function(response) {
                mc.IsLoading = false;
                mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                if (response.data) {
                    mc.onError = true;
                    mc.message = response.data.error.message;
                }
            });
        };

        function autheriseUser(response, isApply) {

            mc.loginModel.Password = '';
            if (response && response.status == 200 && response.data["X-Auth-Token"]) {
                mc.$storage.maxAge = parseInt(response.data["max_age"]);
                mc.$storage.LastActiveTime = new Date().getTime();

                if (response.data.user && response.data.user.user_id) {
                    mc.loginModel.UserName = response.data.user.user_id;
                }
            } else {
                mc.IsLoading = false;
                mc.onError = true;
                if (response && response.status == 401 && response.data.error.message) {
                    mc.message = response.data.error.message;
                } else {
                    mc.message = 'User ID or Password is incorrect.';
                    mc.getlogDetails("Debug", "User ID or Password is incorrect.");
                }
                $('input[name="UserId"]').focus().select();
                return;
            }
            mc.getlogDetails("Debug", 'Method:GET;Login Parameters are:' + JSON.stringify(mc.loginModel));

            mc.getlogDetails("Info", 'Response:Success');
            $cookies.remove('sessiontimeout'); //"persona":"admin"
            mc.$storage.LoginUserId = mc.loginModel.UserName;

            if ($location.search() && $location.search().server && $location.search().userid) {
                $cookies.put($location.search().server + "_" + mc.$storage.LoginUserId + "_" + "XSRF-TOKEN", $cookies.get("XSRF-TOKEN"), { 'expires': updateCookieExpiary(mc.$storage.maxAge), 'path': '/' });
            }
            $location.search().userid = mc.loginModel.UserName;
            mc.IsLoading = false;
            mc.onError = true;
            mc.message = '';

            $state.go('home', $location.search());
        }

        function closePreviousLoggedSession() {
            var userAuthKeyTemp = mc.$storage.UserAuthKey;

            if (userAuthKeyTemp && userAuthKeyTemp.trim().length > 0) {
                mc.loginModel.AuthKey = '';
                userAuthKeyTemp = '';

                if (angular.isDefined(mc.loginModel.UserSessionTimeOut)) {
                    $interval.cancel(mc.loginModel.UserSessionTimeOut);
                    mc.loginModel.UserSessionTimeOut = null;
                }
                if (UserSessionTimer) {
                    $timeout.cancel(UserSessionTimer);
                    UserSessionTimer = null;
                }
                $localStorage.$reset();
            }
        }

        function onLoginKeypress($event, isApply) {
            if ($event.keyCode == 13) {
                if ($($($event.target)[0]).attr('id') == "password") {
                    mc.validateUser(isApply);
                } else if ($($event.target).is('input') && $($event.target).val() && $($event.target).val().length > 0) {
                    $('input[id="password"]').focus();
                }
            }
        }

        function hideShowPassword() {

            if (mc.passwordType == 'password') {
                mc.passwordType = 'text';
            } else {
                mc.passwordType = 'password';
            }

        };
    }
})();