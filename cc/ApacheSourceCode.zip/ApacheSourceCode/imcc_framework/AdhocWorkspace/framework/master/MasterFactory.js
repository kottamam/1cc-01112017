(function() {
    'use strict';

    var X2JS;

    define(['angular', 'X2JS'], function(angular, x2js) {
        X2JS = x2js;
        angular.module('iManage.adHocWorkspace').factory('masterFactory', masterFactory);
    });

    masterFactory.$inject = ['$http', '$q', 'WRSU_MASTER', 'FRAMEWORK_PATHS'];

    function masterFactory($http, $q, WRSU_MASTER, FRAMEWORK_PATHS) {

        var sectionsObj = {};

        (function() {
            sectionsObj = {
                apiurl: '',
                imccapiurl: ''
            };
        })();

        var returnObject = {
            masterInitailValues: returnmasterInitailValues,
            getAPIUrl: returnAPIUrl,
            getLoginTypes: returnLoginTypes,
            getLoginPageAPI: returnLoginPageAPI,
            getSamlUrl: returnSamlUrl,
            getApiV1BaseUrl: returnApiV1BaseUrl,
            getApiV2BaseUrl: returnApiV2BaseUrl
        };
        return returnObject;

        function loadsettings() {
            var deferred = $q.defer();
            var x2js = new X2JS();
            var todayDate = (new Date()).toJSON();
            var promise = $http({
                url: "assets/content/settings.xml?v=" + todayDate,
                method: "GET",
                contentType: "application/json; charset=utf-8"
            });

            promise.then(function(response) {
                var navXml = x2js.xml_str2json(response.data);
                sectionsObj.apiurl = navXml.root.apiurl;
                sectionsObj.imccapiurl = navXml.root.imccapiurl;
                sectionsObj.hostbase = navXml.root.baseurl;
                deferred.resolve(sectionsObj);
            });
            return deferred.promise;
            //return sectionsObj;
        }

        function returnAPIUrl(APIFOR) {
            var ApiUrl = baseIMCCApiUrl + WRSU_MASTER[APIFOR];
            return ApiUrl;

        }

        function returnSamlUrl() {
            var ApiUrl = WRSU_MASTER['SAML_LOGIN'];
            return ApiUrl;

        }

        function returnLoginTypes() {
            var ApiUrl = WRSU_MASTER['LOGINTYPES'];
            return ApiUrl;
        }

        function returnLoginPageAPI(isApplyTemplate, params, pageName) {
            var baseConfig = baseHost; //.substr(1);
            if (baseConfig.charAt(0) == '/')
                baseConfig = baseHost.substr(1);

            var apiUrl = baseIMCCApiUrl + WRSU_MASTER['LOGIN_PAGE'];
            var querstring = '?';
            angular.forEach(params, function(value, key) {
                querstring += key + "=" + value + '&';
            });
            querstring = querstring.substring(0, querstring.length - 1)

            apiUrl += '&csrf_protection=true&network_login_url=' + baseConfig + '/%23/networklogin' + encodeURIComponent(querstring) + '&login_url=' + encodeURIComponent(baseConfig + '/#/login' + querstring) + '&redirect_url=' + encodeURIComponent('/' + baseConfig + '/#/' + pageName + querstring)

            return apiUrl;
        }

        function returnmasterInitailValues() {
            return loadsettings();
        }

        function returnApiV1BaseUrl() {
            var apiUrl = baseUrl + FRAMEWORK_PATHS.API_V1_VERSION;
            return apiUrl;
        }

        function returnApiV2BaseUrl(libraryName, isExcludeCustomerName, is_remove_api_v2) {
            var apiUrl = baseUrl;
            isExcludeCustomerName = isExcludeCustomerName || false;
            is_remove_api_v2 = is_remove_api_v2 || false;
            libraryName = libraryName || '';

            if (!is_remove_api_v2)
                apiUrl += FRAMEWORK_PATHS.API_V2_VERSION;

            if (!isExcludeCustomerName)
                apiUrl += FRAMEWORK_PATHS.API_V2_CUSTOMER.replace('<customer_name>', customerName);

            if (libraryName != null && libraryName.trim().length > 0)
                apiUrl += FRAMEWORK_PATHS.API_V2_LIBRARY.replace('<library_name>', libraryName);

            return apiUrl;
        }
    }
})();

(function() {
    'use strict';

    define('imModule/registerView', ['angular'], function() {
        angular.module('iManage.adHocWorkspace').config(registerView);
    });

    registerView.$inject = ['$pluggableViewsProvider'];

    function registerView($pluggableViewsProvider) {
        angular.module('iManage.adHocWorkspace').libInjector = $pluggableViewsProvider;
    }
})();