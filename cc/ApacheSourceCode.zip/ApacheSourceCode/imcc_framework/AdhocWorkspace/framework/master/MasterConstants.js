(function() {
    'use strict';

    define(['angular'], function() {
        angular.module('iManage.adHocWorkspace').constant('WRSU_MASTER', {
            SAVELOG: 'imcc/log',
            SECURITYLOG: 'imcc/securelog',
            LOGINTYPES: 'session/login-types',
            LOGIN_PAGE: 'session/login-page?application_name=imcc',
            SAML_LOGIN: 'session/saml-login',
            INITDATA: 'webapp/init-data'
        });
    });
})();