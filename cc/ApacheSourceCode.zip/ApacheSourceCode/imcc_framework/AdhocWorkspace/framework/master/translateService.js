﻿(function() {
    'use strict';

    define(['angular'], function(angular) {
        angular.module('iManage.adHocWorkspace').service('translateService', translateService);
    });
    translateService.$inject = ['$http'];

    function translateService($http) {
        this.getJson = function(apiUrl) {
            var promise = $http({
                url: apiUrl,
                method: "GET"
            });
            return promise;
        };
    }

})();