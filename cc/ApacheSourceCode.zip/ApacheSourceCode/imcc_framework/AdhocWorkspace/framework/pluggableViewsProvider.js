(function() {
    'use strict';

    define([
        'angular'
    ], function(angular) {
        return angular.module('iManage.pluggableViews')
            .provider('$pluggableViews', [
                '$controllerProvider',
                '$compileProvider',
                '$filterProvider',
                '$provide',
                '$injector',
                '$stateProvider',
                function($controllerProvider, $compileProvider, $filterProvider, $provide, $injector, $stateProvider) {
                    var providers = {
                        $compileProvider: $compileProvider,
                        $controllerProvider: $controllerProvider,
                        $filterProvider: $filterProvider,
                        $provide: $provide
                    };
                    this.views = [];

                    var pluggableViews = this;

                    this.registerModule = function(moduleName) {
                        var module = angular.module(moduleName);
                        if (module.isLoaded) {
                            return;
                        }
                        module.isLoaded = true;

                        if (module.requires) {
                            for (var i = 0; i < module.requires.length; i++) {
                                this.registerModule(module.requires[i]);
                            }
                        }

                        angular.forEach(module._invokeQueue, function(invokeArgs) {
                            var provider = providers[invokeArgs[0]];
                            provider[invokeArgs[1]].apply(provider, invokeArgs[2]);
                        });
                        angular.forEach(module._configBlocks, function(fn) {
                            $injector.invoke(fn);
                        });
                        angular.forEach(module._runBlocks, function(fn) {
                            $injector.invoke(fn);
                        });
                    };

                    this.toTitleCase = function(str) {
                        return str.replace(/\w\S*/g, function(txt) { return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase(); });
                    };

                    this.registerView = function(viewConfig) {
                        if (!viewConfig.viewUrl) {
                            viewConfig.viewUrl = '/' + viewConfig.ID;
                        }
                        if (!viewConfig.controller) {
                            viewConfig.controller = viewConfig.ID + 'Controller';
                        }
                        if (!viewConfig.requirejsNames) {
                            viewConfig.requirejsNames = [viewConfig.ID];
                        }
                        if (!viewConfig.moduleName) {
                            viewConfig.moduleName = viewConfig.ID;
                        }

                        this.views.push(viewConfig);

                        $stateProvider.state('home.' + viewConfig.ID, {
                            url: viewConfig.viewUrl,
                            views: {
                                'content@home': {
                                    templateUrl: viewConfig.templateUrl,
                                    controller: viewConfig.controller
                                }
                            },
                            resolve: {
                                resolver: ['$q', '$timeout', function($q, $timeout) {
                                    var deferred = $q.defer();
                                    if (viewConfig.requirejsConfig) {
                                        require.config(viewConfig.requirejsConfig);
                                    }
                                    require(viewConfig.requirejsNames, function() {
                                        pluggableViews.registerModule(viewConfig.moduleName);
                                        $timeout(function() {
                                            deferred.resolve();
                                            //angular.element('link.app-styles').remove();
                                            if (viewConfig.cssUrl && viewConfig.cssUrl.length > 0) {
                                                angular.forEach(viewConfig.cssUrl, function(url) {
                                                    var link = document.createElement('link');
                                                    link.className = "app-styles " + viewConfig.ID;
                                                    link.rel = "stylesheet";
                                                    link.type = "text/css";
                                                    link.href = url;
                                                    angular.element('head').append(link);
                                                });
                                            }
                                            $timeout(function() {
                                                angular.element('link.app-styles:not(.' + viewConfig.ID + ')').remove();
                                            }, 1000);
                                        });
                                    });
                                    return deferred.promise;
                                }]
                            }
                        });
                    };
                    this.$get = function() {
                        return {
                            views: pluggableViews.views,
                            registerModule: pluggableViews.registerModule,
                            registerView: pluggableViews.registerView,
                            toTitleCase: pluggableViews.toTitleCase
                        };
                    }
                }
            ]);
    });
}());