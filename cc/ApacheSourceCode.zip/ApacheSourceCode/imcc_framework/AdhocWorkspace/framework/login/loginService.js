(function() {
    'use strict';

    define(['angular'], function() {
        angular.module('iManage.adHocWorkspace').service("loginService", loginService);
    });

    loginService.$inject = ['$http'];

    function loginService($http) {
        this.validateUser = function(baseAPIUrl, loginmodel) {
            var bodydata = { 'user_id': loginmodel.UserName, 'password': loginmodel.Password, 'application_name': loginmodel.ApplicationName };
            if (loginmodel.Personal) {
                bodydata = { 'user_id': loginmodel.UserName, 'password': loginmodel.Password, 'application_name': loginmodel.ApplicationName, "persona": "admin" };
            }
            var promise = $http({
                url: baseAPIUrl + (loginmodel.networklogin ? 'session/network-login' : 'session/login') + '?csrf_protection=true',
                method: "PUT",
                data: bodydata,
                dataType: "json"
            });
            return promise;
        }

        this.logOutUser = function(baseAPIUrl, authToken) {
            var apiUrl = baseAPIUrl + 'session/logout?X-Auth-Token=' + authToken;
            var promise = $http({
                url: apiUrl,
                method: "GET"
            });
            return promise;
        };
    }
})();