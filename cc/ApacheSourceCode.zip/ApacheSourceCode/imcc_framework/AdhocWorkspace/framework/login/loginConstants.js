(function() {
    'use strict';

    define(['angular'], function() {
        angular.module('iManage.adHocWorkspace').constant('WRSU_LOGIN', {
            GETGROUPSOFUSERFROMGROUPS: 'groups/<alias>/members?alias=<userId>'
        });
    });
})();