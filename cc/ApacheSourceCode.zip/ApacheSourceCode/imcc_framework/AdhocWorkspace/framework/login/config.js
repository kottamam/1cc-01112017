(function() {
    'use strict';

    require.config({
        paths: {
            LoginConstants: 'login/loginConstants',
            LoginFactory: 'login/loginFactory',
            LoginService: 'login/loginService'
        }
    });

    define([
        'LoginConstants',
        'LoginFactory',
        'LoginService'
    ]);
})();