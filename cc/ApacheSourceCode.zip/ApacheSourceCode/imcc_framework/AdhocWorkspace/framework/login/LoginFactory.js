(function() {
    'use strict';

    var X2JS;

    define(['angular', 'X2JS'], function(angular, x2js) {
        X2JS = x2js;
        angular.module('iManage.adHocWorkspace').factory('loginFactory', loginFactory);
    });

    loginFactory.$inject = ['$http', '$q', 'homeService', 'homeFactory', 'WRSU_LOGIN'];

    function loginFactory($http, $q, homeService, homeFactory, WRSU_LOGIN) {

        var returnObject = {
            getpremittedUser: premittedUser
        }
        return returnObject;

        function loadsettings() {
            var deferred = $q.defer();
            var x2js = new X2JS();
            var todayDate = (new Date()).toJSON();
            var promise = $http.get("assets/content/settings.xml?v=" + todayDate)

            promise.then(function(response) {
                var navXml = x2js.xml_str2json(response.data);
                var sectionsObj = navXml.root.groupprefix;
                deferred.resolve(sectionsObj);
            });
            return deferred.promise;
        }

        function premittedUser(baseV2Url, username, dbName) {
            var deferred = $q.defer();
            var api = baseV2Url + getAPIUrl('GETGROUPSOFUSERFROMGROUPS', ['NRTADMIN'], username, dbName);
            var promiseOne = homeService.getData(api);
            promiseOne.then(function(responsegroups) {
                deferred.resolve(responsegroups.data.data);
            });
            return deferred.promise;
        }

        function getAPIUrl(APIFOR, requestModel, userId, dbName, action) {
            var ApiUrl = '';
            ApiUrl = WRSU_LOGIN[APIFOR];
            if (APIFOR == 'GETGROUPSOFUSERFROMGROUPS') {
                ApiUrl = prepareUrlGroupsOfUser(ApiUrl, requestModel, userId, dbName);
            }
            return ApiUrl;
        };

        function prepareUrlGroupsOfUser(URL, groups, User, dbName) {
            var apiUrl = URL.replace("<userId>", User);
            //apiUrl = apiUrl.replace("<dbName>", dbName);

            var aliasString = '';
            if (groups.length > 0) {
                angular.forEach(groups, function(grp) {
                    if (aliasString.trim().length > 0) {
                        aliasString += ',';
                    }
                    aliasString += grp;
                });
            }
            apiUrl = apiUrl.replace("<alias>", aliasString);
            return apiUrl;
        }

    };
})();