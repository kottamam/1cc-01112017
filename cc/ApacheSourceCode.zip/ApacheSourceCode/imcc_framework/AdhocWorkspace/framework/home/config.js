(function() {
    'use strict';

    require.config({
        paths: {
            HomeConstants: 'home/homeConstants',
            HomeFactory: 'home/homeFactory',
            HomeService: 'home/homeService'
        }
    });

    define([
        'HomeConstants',
        'HomeFactory',
        'HomeService'
    ]);
})();