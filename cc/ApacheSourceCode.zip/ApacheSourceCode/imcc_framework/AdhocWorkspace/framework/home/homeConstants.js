(function() {
    'use strict';

    define(['angular'], function() {
        angular.module('iManage.adHocWorkspace').constant('WRSU_HOME', {
            SEARCHCAPTIONS: 'captions/search',
            GET_USER: 'users/me',
            GET_DB_LIST: 'libraries',
            GET_PRIMARY_DBNAME: 'system/config?include_databases=true',
            GET_USER_PHOTO: 'users/<userid>/photo',
            LOGOUT_USER: 'session/logout',
            GET_SERVER_VERSION: 'system/config',
            PLUGIN_READ_FILES: 'imcc/plugin/readfile',
            PLUGIN_GET_FOLDERS: 'imcc/plugin/folders',
            PLUGIN_WRITE_FILES: 'imcc/plugin/writefile',
            GET_USER_PERMISSIONS: 'roles/search',
            GET_USER_OPERATIONS: 'operations'
        });

        angular.module('iManage.adHocWorkspace').constant('CONST_HOME_CAPTIONS', {
            MetaDataItem: 'id',
            MetaDataItemFilter: 'alias',
            Locale: 'locale',
            CaptionType: 'type',
            CaptionTypeFilter: 'type',
            DisplayText: 'label',
            DisplayTextFilter: 'label',
            DataBase: 'database',
            CaptionNum: 'num',
            CaptionSS_Num: 'ss_num',
            Language: 'language'
        });

        angular.module('iManage.adHocWorkspace').constant('CONST_DB', {
            DatabaseName: 'id',
            Type: 'type',
            M4_Bits: 'm4_bits',
            CustomMetadataManagement: 'custom_metadata_management'
        });


        // angular.module('iManage.adHocWorkspace').constant('CONST_DB', {
        //     DatabaseName: 'database',
        //     Description: 'description',
        //     M4_Bits: 'm4_bits',
        //     CustomMetadataManagement: 'custom_metadata_management'
        // });

        angular.module('iManage.adHocWorkspace').constant('CONST_PERMISSIONS', {
            Database: 'database',
            IsTier_1: 'admin_tier_1',
            IsTier_2: 'admin_tier_2',
            IsTier_3: 'admin_tier_3',
            ContentAssistance: 'content_assistance',
            ManageCustomMetadata: 'custom_metadata_management',
            DMSJobOperations: 'dms_job_perations',
            Reporting: 'report',
            ReportManagement: 'report_management',
            ManageRoles: 'role_management',
            SystemJobOperations: 'system_job_operations',
            ManageSystemMetadata: 'system_metadata_management',
            TemplateManagement: 'template_creation',
            TrusteeAsistance: 'trustee_asistance',
            ManageTrustees: 'trustee_management',
            CreateSystemWorkspaces: 'create_template'
        });

        angular.module('iManage.adHocWorkspace').constant('CONST_USERS_HOME', {
            UserId: 'user_id',
            FullName: 'full_name',
            Alias: 'alias',
            DataBase: 'database',
            UserIdEx: 'userid'
        });
    });
})();