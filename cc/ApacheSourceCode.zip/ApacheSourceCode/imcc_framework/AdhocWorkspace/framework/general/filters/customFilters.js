//customLabel
(function() {
    'use strict';

    define(['angular'], function() {
        angular.module('iManage.adHocWorkspace').filter('customLabel', customLabel);
    });
    customLabel.$inject = ['$filter'];

    function customLabel($filter) {

        return function(list, alias) {
            var capList = $filter('filter')(list, { MetaDataItem: (alias ? alias : '').toUpperCase() }, true);
            if (capList && capList.length == 1)
                  return capList[0].DisplayText;
            return alias;
        }
    };
})();

//nospace
(function() {
    'use strict';

    define('customFilter/nospace', ['angular'], function() {
        angular.module('iManage.adHocWorkspace').filter('nospace', nospace);
    });

    nospace.$inject = ['$filter'];

    function nospace($filter) {
        return function(value) {
            return (!value) ? '' : value.replace(/ /g, '');
        };
    }
})();

//humanizeDoc
(function() {
    'use strict';

    define('customFilter/humanizeDoc', ['angular'], function() {
        angular.module('iManage.adHocWorkspace').filter('humanizeDoc', humanizeDoc);
    });

    humanizeDoc.$inject = ['$filter'];

    function humanizeDoc($filter) {
        return function(doc) {
            if (!doc) return;
            if (doc.type === 'directive') {
                return doc.name.replace(/([A-Z])/g, function($1) {
                    return '-' + $1.toLowerCase();
                });
            }

            return doc.Label || doc.name || doc.AppsName;
        };
    }
})();