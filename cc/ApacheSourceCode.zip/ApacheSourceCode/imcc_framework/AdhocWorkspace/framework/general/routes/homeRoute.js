(function() {
    'use strict';

    define(['angular'], function() {
        angular.module('iManage.adHocWorkspace').config(homeRoute);
    });

    homeRoute.$inject = ['$stateProvider', '$urlRouterProvider', '$logProvider'];

    function homeRoute($stateProvider, $urlRouterProvider, $logProvider) {
        $urlRouterProvider.otherwise("/");

        $stateProvider
            .state('login', {
                url: '/login?dbname&server&userid&protocol',
                templateUrl: ((window.location.pathname).toLowerCase().indexOf('networklogin') > 0) ?
                    'framework/login/NetworkLogin.html' : 'framework/login/Login.html'

            }).state('networklogin', {
                url: '/networklogin?dbname&server&userid&protocol',
                templateUrl: 'framework/login/NetworkLogin.html'
            })
             .state('home', {
                 url: '/?dbname&server&userid&protocol',
                 templateUrl: 'framework/workspace/CreateWorkspace.html',
                 controller: 'adHocWorkspaceController as vmAdHocWorkspaceCtrl'
             })
            .state('home.management', {
                url: 'management',
                abstract: true
            })
    };
})();