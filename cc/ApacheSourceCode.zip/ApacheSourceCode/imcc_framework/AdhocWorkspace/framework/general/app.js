var baseUrl = '';
var baseIMCCApiUrl = '';
var baseHost = '';
var UserSessionTimer = null;
var sessionTime = 1000 * 60 * 60 * 4;
var cookieExpiary = new Date();
var customerName = '';

function updateCookieExpiary(maxage) {
    cookieExpiary = new Date();
    var time = cookieExpiary.getTime();
    if (maxage)
        time += maxage * 1000;
    else
        time += sessionTime;
    cookieExpiary.setTime(time);
    return cookieExpiary;
}