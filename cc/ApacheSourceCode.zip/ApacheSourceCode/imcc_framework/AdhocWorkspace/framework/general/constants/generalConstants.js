(function() {
    'use strict';

    define(['angular'], function() {
        angular.module('iManage.adHocWorkspace').constant('FRAMEWORK_PATHS', {
            DIRECTIVE_TEMPLATES: 'framework/general/directives/directiveTemplates/',
            APP_ROOT: 'plugin_root/',
            API_V1_VERSION: 'api/v1/',
            API_V2_VERSION: 'api/v2/',
            API_V2_CUSTOMER: 'customers/<customer_name>/',
            API_V2_LIBRARY: 'libraries/<library_name>/'
        });
    });
})();