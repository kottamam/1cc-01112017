(function() {
    'use strict';
    define(['angular'], function() {
        angular.module('iManage.adHocWorkspace', ['ngMaterial', 'ngAnimate', 'ui.router', 'ngAria', 'md.data.table', 'material.svgAssetsCache', 'ngMessages', 'ngCookies', 'ngSanitize', 'fixed.table.header', 'angular-nicescroll', 'iManage.pluggableViews', 'ngStorage', 'pascalprecht.translate']);
        angular.module('iManage.pluggableViews', []);
    });
})();

(function() {
    'use strict';

    define('general/modules/imModule/themingConfig', ['angular'], function() {
        angular.module('iManage.adHocWorkspace').config(themingConfig);
    });

    themingConfig.$inject = ['$mdThemingProvider'];

    function themingConfig($mdThemingProvider) {
        $mdThemingProvider.theme('default')
            .primaryPalette('light-blue', {
                'default': '300'
            })
            .accentPalette('deep-orange', {
                'default': '500'
            });
    }
})();

(function() {
    'use strict';

    define('general/modules/imModule/sessionTimeoutInterceptor', ['angular'], function() {
        angular.module('iManage.adHocWorkspace').factory('sessionTimeoutInterceptor', sessionTimeoutInterceptor);
    });
    sessionTimeoutInterceptor.$inject = ['$window', '$timeout', '$cookies', '$localStorage'];

    function sessionTimeoutInterceptor($window, $timeout, $cookies, $localStorage) {

        return {
            request: function(config) {
                $cookies.sessiontimeout = null;
                if ($cookies.get("XSRF-TOKEN")) {
                    $localStorage['LastActiveTime'] = new Date().getTime();
                }
                return config;
            },
            response: function(response) {
                // if (UserSessionTimer) {
                //     $timeout.cancel(UserSessionTimer);
                //     UserSessionTimer = null;
                // }
                return response;
            },
            responseError: function(response) {
                $cookies.sessiontimeout = response.status;
                return response;
            }
        };
    }
})();

(function() {
    'use strict';

    define('general/modules/imModule/httpProviderConfig', ['angular'], function() {
        angular.module('iManage.adHocWorkspace').config(httpProviderConfig);
    });

    httpProviderConfig.$inject = ['$httpProvider'];

    function httpProviderConfig($httpProvider) {
        $httpProvider.defaults.withCredentials = true;
        $httpProvider.defaults.useXDomain = true;
        return $httpProvider.interceptors.push('sessionTimeoutInterceptor');
    }
})();

(function() {
    'use strict';

    define('general/modules/imModule/stateChange', ['angular'], function() {
        angular.module('iManage.adHocWorkspace').run(stateChange);

        angular.module('iManage.adHocWorkspace').run(updateRoute);
    });

    stateChange.$inject = ['$rootScope', '$log', '$timeout', '$cookies', '$mdMedia', '$state'];

    function stateChange($rootScope, $log, $timeout, $cookies, $mdMedia, $state) {
        $rootScope.$on('$stateChangeStart', function(event, toState, toParams, fromState, fromParams, options) {
            // if ($rootScope.checkReadyToChangeState) {
            //     event.preventDefault();
            //     var promise = $rootScope.checkReadyToChangeState();
            //     promise.then(function(response) {
            //         if (response && response.Status === 0) {
            //             $rootScope.checkReadyToChangeState = null;
            //             $state.go(toState, toParams);

            //         }
            //     }, function(response) {});
            // }
        });
        $rootScope.$on("$stateChangeSuccess", function(event, toState, toParams, fromState, fromParams) {
            window.scrollTo(0, 0);
        });
        $rootScope.$mdMedia = $mdMedia;
    };

    updateRoute.$inject = ['$rootScope', '$log', '$timeout', '$cookies', '$mdMedia', '$urlRouter'];

    function updateRoute($rootScope, $log, $timeout, $cookies, $mdMedia, $urlRouter) {
        $rootScope.$on('$stateChangeCancel', function(event, toState, toParams, fromState, fromParams) {

            if (event.noUpdate !== true) {
                $urlRouter.update();
            }
            //return TransitionPrevented;
        })
    }
})();

(function() {
    'use strict';

    define('general/modules/imModule/setXSRFToken', ['angular'], function() {
        angular.module('iManage.adHocWorkspace').provider('Set_XSRF_TOKEN', setXSRFToken).config(setXSRFTokenConfig);
    });

    var headerName = 'X-XSRF-TOKEN';
    var cookieName = 'XSRF-TOKEN';
    var allowedMethods = ['GET'];

    function setXSRFToken() {

        this.setHeaderName = function(n) {
            headerName = n;
        }
        this.setCookieName = function(n) {
            cookieName = n;
        }
        this.setAllowedMethods = function(n) {
            allowedMethods = n;
        }
        this.$get = getXSRFToken;
    }

    getXSRFToken.$inject = ['$cookies'];

    function getXSRFToken($cookies) {
        return {
            'request': function(config) {
                if (allowedMethods.indexOf(config.method) === -1) {
                    // do something on success
                    //if ($cookies.get('XSRF-TOKEN') && $cookies.get('XSRF-TOKEN') != '')
                    //    config.headers[headerName] = $cookies.get('XSRF-TOKEN'); // $cookies[cookieName];
                }
                return config;
            }
        }
    }

    setXSRFTokenConfig.$inject = ['$httpProvider'];

    function setXSRFTokenConfig($httpProvider) {
        $httpProvider.interceptors.push('Set_XSRF_TOKEN');
    }
})();

(function() {
    'use strict';

    define('general/modules/imModule/SetXAuthTocken', ['angular'], function() {
        angular.module('iManage.adHocWorkspace').provider('Set_X_Auth_Token', setXSRFToken).config(setXSRFTokenConfig);
    });

    var headerName = 'X-Auth-Token';
    var allowedMethods = ['GET'];
    var cookieName = '';

    function setXSRFToken() {

        this.setHeaderName = function(n) {
            headerName = n;
        }
        this.setCookieName = function(n) {
            cookieName = n;
        }
        this.setAllowedMethods = function(n) {
            allowedMethods = n;
        }
        this.$get = getXSRFToken;
    }

    getXSRFToken.$inject = ['$localStorage'];

    function getXSRFToken($localStorage) {
        return {
            'request': function(config) {

                return config;
            }
        }
    }

    setXSRFTokenConfig.$inject = ['$httpProvider'];

    function setXSRFTokenConfig($httpProvider) {

    }
})();

(function() {
    'use strict';

    define('general/modules/imModule/SetXEnforceRoles', ['angular'], function() {
        angular.module('iManage.adHocWorkspace').provider('Set_X_Enforce_Roles', setXEnforceRoles).config(setXEnforceRoleConfig);
    });

    var headerName = 'X-Enforce-Roles';
    var allowedMethods = ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'];
    var cookieName = '';

    function setXEnforceRoles() {
        this.setHeaderName = function(n) {
            headerName = n;
        }
        this.setCookieName = function(n) {
            cookieName = n;
        }
        this.setAllowedMethods = function(n) {
            allowedMethods = n;
        }
        this.$get = getXEnforceRoles;
    }

    getXEnforceRoles.$inject = ['$cookies'];

    function getXEnforceRoles($cookies) {
        return {
            'request': function(config) {
                if (allowedMethods.indexOf(config.method) > 0) {
                    config.headers[headerName] = true;
                }
                return config;
            }
        }
    }

    setXEnforceRoleConfig.$inject = ['$httpProvider'];

    function setXEnforceRoleConfig($httpProvider) {
        $httpProvider.interceptors.push('Set_X_Enforce_Roles');
    }
})();


(function () {
    'use strict';

    define('general/modules/imModule/translateProviderConfig', ['angular'], function () {
        angular.module('iManage.adHocWorkspace').config(translateProviderConfig);
    });

    translateProviderConfig.$inject = ['$translateProvider'];
    function translateProviderConfig($translateProvider) {
        $translateProvider.addInterpolation('$translateMessageFormatInterpolation');
        $translateProvider.useLoader('translateFactory');
        $translateProvider.preferredLanguage('en-Us');		
		$translateProvider.useSanitizeValueStrategy('escapeParameters');
    }

})();