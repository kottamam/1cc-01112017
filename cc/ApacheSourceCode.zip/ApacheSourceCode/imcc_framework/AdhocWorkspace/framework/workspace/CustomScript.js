var Ext = window.external;
function logoutuser() {
    
    $('#userEditForm').scope().vmApply.Logout();
}
function closewin() {
     
        window.external.closeWindow();
     
}

function resizewin(dimensions) {
	
	  try {
                      window.external.resizeWindow(dimensions);
                    } catch (err) {}

}

