(function() {
    'use strict';

    define(['angular', 'X2JS'], function(angular, X2JS) {
        angular.module('iManage.adHocWorkspace').controller("adHocWorkspaceController", adHocWorkspaceController);
        adHocWorkspaceController.$inject = ['$scope', '$log', '$state', '$location', '$rootScope', '$timeout', '$cookies',
            '$interval', '$filter', '$stateParams', '$mdDialog', '$q', '$compile', '$window', 'loginService',
            'homeService', 'homeFactory', 'adHocWorkspaceFactory', 'masterFactory', 'loginFactory', '$translate', 'CONST_SYSTEM_CONFIG'
        ];

        function adHocWorkspaceController($scope, $log, $state, $location, $rootScope, $timeout, $cookies,
            $interval, $filter, $stateParams, $mdDialog, $q, $compile, $window, loginService,
            homeService, homeFactory, adHocWorkspaceFactory, masterFactory, loginFactory, $translate, CONST_SYSTEM_CONFIG) {

            var vmAdHocWorkspaceCtrl = this;
            var securityListSearchTimeOut = null;
            var securityListSearchTimeOutForMatterCategory = null;
            var groupMemberSearchTimeOut = null;
            var profileFromWs = null;
            var isgroupMemberSearchTextDirty = false;
            var isgroupMembersInstantSearch = false;
            var isNRTAdminGroupUserLoggedIn = false;
            var groupMembersTotalCount = 0;
            var autoCompleteListScrollStatus = 0;
            var metaDataItemTotalCount = 0;
            var currentSelectedCustomType = '';
            var lblWarning = '';
            var customModelList = [];
            var groupMembersReqModel = homeFactory.requestModelInstance();
            var customListRequestModel = homeFactory.requestModelInstance();
            var templateChanged = false;
            var category_parent_id = '';
            var categoryParentSecurity = '';
            var categorySecurityList = [];
            var inheritedCategorySecurityList = [];
            var baseV2Url = '';
            var folderEmailDomain = '';

            vmAdHocWorkspaceCtrl.shouldComeFirst = false;
            vmAdHocWorkspaceCtrl.subClassFromStrings = false;
            vmAdHocWorkspaceCtrl.ShowHippafield = true;
            vmAdHocWorkspaceCtrl.IsFolderPreview = false;
            vmAdHocWorkspaceCtrl.SelectedLibrary = '';
            vmAdHocWorkspaceCtrl.IsHideMainPage = false;
            vmAdHocWorkspaceCtrl.IsGroupMemberVisible = false;
            vmAdHocWorkspaceCtrl.IsHideWorkspaceWindow = false;
            vmAdHocWorkspaceCtrl.IsShowSuccessWindow = false;
            vmAdHocWorkspaceCtrl.IsShowClipboardCopyMsg = false;
            vmAdHocWorkspaceCtrl.IsAutoGenerateCustomAlias = false;
            vmAdHocWorkspaceCtrl.CreatedWorkspaceLocation = '';
            vmAdHocWorkspaceCtrl.SecurityListSearchText = '';
            vmAdHocWorkspaceCtrl.SecurityListSearchTextForMatterCategory = '';
            vmAdHocWorkspaceCtrl.CategoryText = '';
            vmAdHocWorkspaceCtrl.myMatterCaption = '';
            vmAdHocWorkspaceCtrl.SelectedTabIndex = 0;
            vmAdHocWorkspaceCtrl.LocationList = [];
            vmAdHocWorkspaceCtrl.NewUserGroupList = [];
            vmAdHocWorkspaceCtrl.addUserGroupListToCategory = [];
            vmAdHocWorkspaceCtrl.SecurityListWithFilter = [];
            vmAdHocWorkspaceCtrl.SecurityListWithFilterInMatterCategory = [];
            vmAdHocWorkspaceCtrl.SecurityList = [];
            vmAdHocWorkspaceCtrl.VisibleFieldList = [];
            vmAdHocWorkspaceCtrl.DenyCreateNewCustomItemList = [];
            vmAdHocWorkspaceCtrl.MatchField = [];
            vmAdHocWorkspaceCtrl.UserGroupSearchText = null;
            vmAdHocWorkspaceCtrl.SelectedUserGroup = null;
            vmAdHocWorkspaceCtrl.SelectedUserGroupForCategory = null;
            vmAdHocWorkspaceCtrl.SelectedMatterCategoryId = null;
            vmAdHocWorkspaceCtrl.IsSearchCategory = false;
            vmAdHocWorkspaceCtrl.adHocWSUIModel = adHocWorkspaceFactory.getAdHocWSInitialValues();
            vmAdHocWorkspaceCtrl.CustomGlobalValue = '';

            vmAdHocWorkspaceCtrl.SearchCustom1Text = null;
            vmAdHocWorkspaceCtrl.SearchCustom2Text = null;
            vmAdHocWorkspaceCtrl.SearchCustom29Text = null;
            vmAdHocWorkspaceCtrl.SearchCustom30Text = null;
            vmAdHocWorkspaceCtrl.SearchCustom3Text = null;
            vmAdHocWorkspaceCtrl.SearchCustom4Text = null;
            vmAdHocWorkspaceCtrl.SearchCustom5Text = null;
            vmAdHocWorkspaceCtrl.SearchCustom6Text = null;
            vmAdHocWorkspaceCtrl.SearchCustom6Text = null;
            vmAdHocWorkspaceCtrl.SearchCustom8Text = null;
            vmAdHocWorkspaceCtrl.SearchCustom9Text = null;
            vmAdHocWorkspaceCtrl.SearchCustom10Text = null;
            vmAdHocWorkspaceCtrl.SearchCustom11Text = null;
            vmAdHocWorkspaceCtrl.SearchCustom12Text = null;
            vmAdHocWorkspaceCtrl.SubClassSearchText = null;
            vmAdHocWorkspaceCtrl.OwnerText = $scope.mc.loginModel.UserName;
            vmAdHocWorkspaceCtrl.adHocWSUIModel.Owner = $scope.mc.loginModel.UserName;
            vmAdHocWorkspaceCtrl.adHocWSUIModel.Author = $scope.mc.loginModel.UserName;

            vmAdHocWorkspaceCtrl.GroupMembers = {
                SelectedGroup: null,
                HeaderText: '',
                SearchText: '',
                GroupMemberList: [],
                ClearSearchClick: groupMembers_ClearSearchClick,
                SearchClick: groupMembers_SearchClick,
                GroupMemberListScroll: groupMembers_onListScroll
            };

            vmAdHocWorkspaceCtrl.backFromAddUserGroup = backFromAddUserGroup;
            vmAdHocWorkspaceCtrl.saveSecurityUserGroup = saveSecurityUserGroup;
            vmAdHocWorkspaceCtrl.AccessLevel_Change = accessLevel_Change;
            vmAdHocWorkspaceCtrl.addUserGroup = addUserGroup;
            vmAdHocWorkspaceCtrl.SelectedUserGroup_Change = selectedUserGroup_Change;
            vmAdHocWorkspaceCtrl.addUserGroupToCategoryList = addUserGroupToCategoryList;
            vmAdHocWorkspaceCtrl.ShowGroupMemberList = showGroupMemberList;
            vmAdHocWorkspaceCtrl.HideGroupMemberList = hideGroupMemberList;
            vmAdHocWorkspaceCtrl.CloseWindow = closeWindow;
            vmAdHocWorkspaceCtrl.GetParams = getParams;
            vmAdHocWorkspaceCtrl.QueryCustomSearch = queryCustomSearch;
            vmAdHocWorkspaceCtrl.IsChecked = isChecked;
            vmAdHocWorkspaceCtrl.IsIndeterminate = isIndeterminate;
            vmAdHocWorkspaceCtrl.ChangeValue = changeValue;
            vmAdHocWorkspaceCtrl.addAdHocWS = addAdHocWS;
            vmAdHocWorkspaceCtrl.SearchSecurityUserGroup_Click = searchSecurityUserGroup_Click;
            vmAdHocWorkspaceCtrl.QuerySearchUserGroup = querySearchUserGroup;
            vmAdHocWorkspaceCtrl.CustomSearchText_Change = customSearchText_Change;
            vmAdHocWorkspaceCtrl.SelectedDB_Change = selectedDB_Change;
            vmAdHocWorkspaceCtrl.AutoCompleteSelectedItem_Change = autoCompleteSelectedItem_Change;
            vmAdHocWorkspaceCtrl.changeSelection = changeFolderSelection;
            vmAdHocWorkspaceCtrl.NewUserGroupListAccess_Change = newUserGroupListAccess_Change;
            vmAdHocWorkspaceCtrl.UserGroupListOfCategory_Change = UserGroupListOfCategory_Change;
            vmAdHocWorkspaceCtrl.SubClassSearchText_Change = subClassSearchText_Change;
            vmAdHocWorkspaceCtrl.SubClassAutoCompleteList_Scroll = subClassAutoCompleteList_Scroll;
            vmAdHocWorkspaceCtrl.SelectedTemplateChange = selectedTemplateChange;
            vmAdHocWorkspaceCtrl.LoadTemplatePreview = loadTemplatePreview;
            vmAdHocWorkspaceCtrl.IsAllowAddNewMetadata = isAllowAddNewMetadata;
            vmAdHocWorkspaceCtrl.Text_KeyDown = text_KeyDown;
            vmAdHocWorkspaceCtrl.showFolders = showFolders;
            vmAdHocWorkspaceCtrl.IsFolderListShowing = false;
            vmAdHocWorkspaceCtrl.expandFolder = expandFolder;
            vmAdHocWorkspaceCtrl.CopyPathtoClipboard = copyPathtoClipboard;
            vmAdHocWorkspaceCtrl.OwnerSearchText_Change = OwnerSearchText_Change;
            vmAdHocWorkspaceCtrl.CategorySearchText_Change = CategorySearchText_Change;
            vmAdHocWorkspaceCtrl.OpenSelectMatterCategoryForm = openSelectMatterCategoryForm;
            vmAdHocWorkspaceCtrl.SelectCategory_Click = selectCategory_Click;
            vmAdHocWorkspaceCtrl.TextChange = textChange;
            vmAdHocWorkspaceCtrl.TextNameChange = textNameChange;

            $scope.$watch(function() { return vmAdHocWorkspaceCtrl.SecurityListSearchText; }, function(val) {
                if (securityListSearchTimeOut)
                    $timeout.cancel(securityListSearchTimeOut);

                securityListSearchTimeOut = $timeout(function() {
                    searchSecurityUserGroup_Click();
                }, 1000);
            }, true);


            $scope.$watch(function() { return vmAdHocWorkspaceCtrl.SecurityListSearchTextForMatterCategory; }, function(val) {
                if (securityListSearchTimeOutForMatterCategory)
                    $timeout.cancel(securityListSearchTimeOutForMatterCategory);

                securityListSearchTimeOutForMatterCategory = $timeout(function() {
                    searchSecurityUserGroupInMatterCategory_Click();
                }, 1000);
            }, true);

            $scope.$watch(function() { return vmAdHocWorkspaceCtrl.GroupMembers.SearchText; }, function(val) {
                if (vmAdHocWorkspaceCtrl.GroupMembers.SearchText.length > 0) {
                    isgroupMemberSearchTextDirty = true;
                }
                if (groupMemberSearchTimeOut)
                    $timeout.cancel(groupMemberSearchTimeOut);

                if (isgroupMembersInstantSearch) {
                    isgroupMembersInstantSearch = false;
                    vmAdHocWorkspaceCtrl.GroupMembers.SearchClick();
                } else {
                    groupMemberSearchTimeOut = $timeout(function() {
                        if (isgroupMemberSearchTextDirty) {
                            vmAdHocWorkspaceCtrl.GroupMembers.SearchClick();
                        }
                    }, 2000);
                }
            }, true);

            var sessionTimoutWatch = $scope.$watch(function() { return $cookies.sessiontimeout; }, function(newVal, oldVal) {
                if ($cookies.sessiontimeout && $cookies.sessiontimeout === 401) {
                    sessionTimoutWatch();
                    $cookies.sessiontimeout = null;
                    logoutAPICall();
                } else if ($cookies.sessiontimeout) {
                    $cookies.sessiontimeout = null;
                }
            });

            vmAdHocWorkspaceCtrl.GetParams();

            function logoutAPICall() {
                var stateURL = baseIMCCApiUrl + "dialogs/workspace-create";
                var parameters = "/login/oauth2/authorize?response_type=token&scope=user&state=" + stateURL + "&client_id=fbwc";

                var apiUrl = homeFactory.getLogoutAPI('');
                var logoutRequest = homeService.getData(apiUrl);
                logoutRequest.then(function(response) {
                    resetAllValues();
                    window.location.href = baseIMCCApiUrl + "login/terminate?return_to=" + encodeURIComponent(parameters);
                }, function(response) {
                    resetAllValues();
                    window.location.href = baseIMCCApiUrl + "login/terminate?return_to=" + encodeURIComponent(parameters);
                });
            }

            function getParams() {
                resizeWindow({ width: '550', height: '700' });
                var actualUserName = $location.search().userid;
                vmAdHocWorkspaceCtrl.SelectedLibrary = '';
                if ($scope.mc.loginModel.UserName && $scope.mc.loginModel.UserName !== '') {
                    actualUserName = $scope.mc.loginModel.UserName;
                }
                if (!$scope.mc.$storage.maxAge)
                    $scope.mc.$storage.maxAge = '14400';
                $scope.mc.$storage.IsVirtualUserLogin = "redirected";

                vmAdHocWorkspaceCtrl.SelectedLibrary = $location.search().dbname;
                initialize();
            }

            function showFolders() {
                vmAdHocWorkspaceCtrl.IsFolderListShowing = true;
                if (vmAdHocWorkspaceCtrl.SelectedTemplate && vmAdHocWorkspaceCtrl.SelectedTemplate.NVPs && vmAdHocWorkspaceCtrl.SelectedTemplate.NVPs.Actual_Prefix)
                    vmAdHocWorkspaceCtrl.SelectedTemplate.NVPs.IMCC_Name_Prefix = vmAdHocWorkspaceCtrl.SelectedTemplate.NVPs.Actual_Prefix;
                selectedTemplateChange('reset');
            }

            function expandFolder(folder) {
                folder.IsExpanded = !folder.IsExpanded;
                if (folder.HasSubfolders && folder.SubFolders && folder.SubFolders.length == 0) {
                    var promiseChild = getOptionalFolders(folder.Id, {});
                    promiseChild.then(function(response) {
                        angular.forEach(response, function(folderDetails) {
                            if (folderDetails != null)
                                folder.SubFolders.push(folderDetails);
                        })
                        $timeout(function() {
                            $mdDialog.hide();
                        });
                    })
                }
            }

            function showProgressDialog(progressMessage) {
                if (!progressMessage) progressMessage = '';

                if (progressMessage.trim().length > 0) {
                    $translate(progressMessage).then(function(translatedValue) {
                        $mdDialog.show({
                            parent: angular.element(document.body),
                            template: '<md-dialog ng-cloak height="100%" style="min-width: 1px !important;"><md-dialog-content class="apply-progress-dialog">' +
                                '<div id="dvProgressContent" class="md-dialog-content-clearpadding"><md-progress-circular md-mode="indeterminate"></md-progress-circular>' +
                                '<span id="spanProgressContent" class="apply-progress-msg">' + translatedValue + '</span>' +
                                '</div></md-dialog-content></md-dialog>'
                        }).then(function() {});
                    });
                } else {
                    $mdDialog.show({
                        parent: angular.element(document.body),
                        template: '<md-dialog ng-cloak height="100%" style="min-width: 1px !important;"><md-dialog-content class="apply-progress-dialog">' +
                            '<div id="dvProgressContent" class="md-dialog-content-clearpadding"><md-progress-circular md-mode="indeterminate"></md-progress-circular>' +
                            '</div></md-dialog-content></md-dialog>'
                    }).then(function() {});
                }
            }

            function changeProgressDialogMessage(progressMessage) {
                if (!progressMessage) progressMessage = '';
                if ($('#spanProgressContent')) {
                    if (progressMessage.trim().length > 0) {
                        $translate(progressMessage).then(function(translatedValue) {
                            $('#spanProgressContent').html(translatedValue);
                        });
                    } else {
                        $('#spanProgressContent').html('&nbsp;');
                    }
                } else {
                    showProgressDialog(progressMessage);
                }
            }

            function initialize() {
                if (!baseUrl || baseUrl === '') {
                    var WebLocation = window.location.href.split('dialogs/');
                    baseUrl = WebLocation[0];
                    var basePath = WebLocation[0].split('imanage/');
                    basePath = basePath[0].split('imcc/');
                    baseIMCCApiUrl = basePath[0];
                }

                showProgressDialog();
                $translate('warning').then(function(translatedValue) {
                    lblWarning = translatedValue;
                });
                vmAdHocWorkspaceCtrl.IsAutoGenerateCustomAlias = false;
                vmAdHocWorkspaceCtrl.CreatedWorkspaceLocation = '';

                registerSessionTimeOut();
                var settingPromise = getCustomerId();
                settingPromise.then(function(response) {
                    var dbListPromise = getDBLibraries();
                    dbListPromise.then(function(response) {
                        if (response.Status === -1) {
                            redirectToLogin();
                        } else {
                            baseV2Url = masterFactory.getApiV2BaseUrl(vmAdHocWorkspaceCtrl.SelectedLibrary);
                            var userPromise = getUserDetails();
                            userPromise.then(function(response) {
                                initalizePageData();
                            });
                        }
                    });
                });
            }

            function samlLogin() {
                var initDataUrl = baseV2Url + homeFactory.getSingleUserAPI('', '');
                $scope.mc.loginModel.FullName = '';

                var promise = homeService.getData(initDataUrl).then(
                    function(response) {
                        if (response && response.data && response.data.data) {
                            $scope.mc.getlogDetails("Debug", 'Response:Success');

                            var loggedUserModel = homeFactory.getUserUI(response.data.data);
                            $scope.mc.$storage.maxAge = 14400;
                            if (loggedUserModel.FullName)
                                $scope.mc.loginModel.FullName = loggedUserModel.FullName;

                            $scope.mc.$storage.LoginUserId = loggedUserModel.UserId;
                            $scope.mc.loginModel.UserName = loggedUserModel.UserId;
                            $scope.mc.$storage.LastActiveTime = new Date().getTime();
                            getDBLibraries();
                        } else {
                            redirectToLogin();
                        }
                    },
                    function(response) {
                        redirectToLogin();
                    }
                );
            }

            function redirectToLogin() {

            }

            function registerSessionTimeOut() {
                var sessionTimoutWatch = $scope.$watch(function() { return $cookies.sessiontimeout; }, function(newVal, oldVal) {
                    if ($cookies.sessiontimeout && $cookies.sessiontimeout === 401) {
                        sessionTimoutWatch();
                        $cookies.sessiontimeout = null;
                        resetAllValues();
                        redirectToLogin();
                    } else if ($cookies.sessiontimeout) {
                        $cookies.sessiontimeout = null;
                    }
                });
            }

            function initalizePageData() {
                vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom25 = 'inter';
                vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom26 = 'inter';
                vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom27 = 'inter';
                vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom28 = 'inter';
                vmAdHocWorkspaceCtrl.SecurityListSearchText = '';
                vmAdHocWorkspaceCtrl.SecurityListSearchTextForMatterCategory = '';
                vmAdHocWorkspaceCtrl.NewUserGroupList = [];
                vmAdHocWorkspaceCtrl.SecurityListWithFilter = [];
                vmAdHocWorkspaceCtrl.SecurityListWithFilterInMatterCategory = [];
                vmAdHocWorkspaceCtrl.SecurityList = [];
                vmAdHocWorkspaceCtrl.VisibleFieldList = [];
                vmAdHocWorkspaceCtrl.CategoryText = null;

                vmAdHocWorkspaceCtrl.SearchCustom1Text = null;
                vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom1 = null;
                vmAdHocWorkspaceCtrl.SearchCustom2Text = null;
                vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom2 = null;
                vmAdHocWorkspaceCtrl.SearchCustom29Text = null;
                vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom29 = null;
                vmAdHocWorkspaceCtrl.SearchCustom30Text = null;
                vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom30 = null;
                vmAdHocWorkspaceCtrl.SearchCustom3Text = null;
                vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom3 = null;
                vmAdHocWorkspaceCtrl.SearchCustom4Text = null;
                vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom4 = null;
                vmAdHocWorkspaceCtrl.SearchCustom5Text = null;
                vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom5 = null;
                vmAdHocWorkspaceCtrl.SearchCustom6Text = null;
                vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom6 = null;
                vmAdHocWorkspaceCtrl.SearchCustom6Text = null;
                vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom7 = null;
                vmAdHocWorkspaceCtrl.SearchCustom8Text = null;
                vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom8 = null;
                vmAdHocWorkspaceCtrl.SearchCustom9Text = null;
                vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom9 = null;
                vmAdHocWorkspaceCtrl.SearchCustom10Text = null;
                vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom10 = null;
                vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom11 = null;
                vmAdHocWorkspaceCtrl.SearchCustom11Text = null;
                vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom12 = null;
                vmAdHocWorkspaceCtrl.SearchCustom12Text = null;
                vmAdHocWorkspaceCtrl.SubClassSearchText = null;
                vmAdHocWorkspaceCtrl.adHocWSUIModel.SubClass = null;
                vmAdHocWorkspaceCtrl.foldersList = [];
                vmAdHocWorkspaceCtrl.ItemsInSelectedLevel = [];
                vmAdHocWorkspaceCtrl.SelectedTemplate = null;
                vmAdHocWorkspaceCtrl.OwnerText = $scope.mc.loginModel.UserName;
                vmAdHocWorkspaceCtrl.adHocWSUIModel.Owner = $scope.mc.loginModel.UserName;
                vmAdHocWorkspaceCtrl.adHocWSUIModel.Author = $scope.mc.loginModel.UserName;
                folderEmailDomain = '';
                baseV2Url = masterFactory.getApiV2BaseUrl(vmAdHocWorkspaceCtrl.SelectedLibrary);

                var deferredarray = [];
                var nrtAdminCheckPromise = checkNRTAdminOrNot();
                deferredarray.push(nrtAdminCheckPromise.promise);
                var defferedVisibleFieldList = getVisibleFieldList();
                deferredarray.push(defferedVisibleFieldList.promise);
                var defferedCaption = getCaptions();
                deferredarray.push(defferedCaption.promise);
                var defferedUser = getUserDetails().then(function() {
                    addLoggedUserToSecurityList();
                });
                deferredarray.push(defferedUser.promise);
                var deferedtemp = $q.defer();
                deferredarray.push(deferedtemp.promise);

                getMatchFields().then(function() {
                    getTemplates().then(function() {
                        if (vmAdHocWorkspaceCtrl.SelectedTemplate && vmAdHocWorkspaceCtrl.SelectedTemplate.Id) {
                            var promiseNVP = getNameValuePairs(vmAdHocWorkspaceCtrl.SelectedTemplate.Id);
                            promiseNVP.then(function(response) {
                                vmAdHocWorkspaceCtrl.SelectedTemplate.NVPs = adHocWorkspaceFactory.getNVPUI(response.data);
                                vmAdHocWorkspaceCtrl.adHocWSUIModel.DefaultSecurity = vmAdHocWorkspaceCtrl.SelectedTemplate.NVPs.IMCC_Default_Security;
                            });
                        }
                        if (vmAdHocWorkspaceCtrl.MatchField && vmAdHocWorkspaceCtrl.MatchField.length > 0) {
                            templateChanged = true;
                            if (vmAdHocWorkspaceCtrl.MatchField[0])
                                SetMatchFiled(vmAdHocWorkspaceCtrl.MatchField[0]);
                            if (vmAdHocWorkspaceCtrl.MatchField[1])
                                SetMatchFiled(vmAdHocWorkspaceCtrl.MatchField[1]);
                        }
                        SetSubClass();
                        deferedtemp.resolve();
                    });
                });
                $q.all(deferredarray).then(function(allResponse) {
                    $timeout(function() {
                        $mdDialog.hide();
                    });
                });
            }

            function checkNRTAdminOrNot() {
                var defered = $q.defer();
                isNRTAdminGroupUserLoggedIn = false;

                var promise = loginFactory.getpremittedUser(baseV2Url, $scope.mc.loginModel.UserName, vmAdHocWorkspaceCtrl.SelectedLibrary);
                promise.then(function(response) {
                    isNRTAdminGroupUserLoggedIn = false;
                    if (response != null && response.length > 0) {
                        for (var iCount = 0; iCount < response.length; iCount++) {
                            if (response[iCount].user_id.toUpperCase() === $scope.mc.loginModel.UserName.toUpperCase()) {
                                isNRTAdminGroupUserLoggedIn = true;
                                break;
                            }
                        }
                    }
                    defered.resolve();
                }, function(response) {
                    defered.resolve();
                });
                return defered.promise;
            }

            function getMatchFields() {
                var deferd = $q.defer();
                folderEmailDomain = '';

                getMatchFieldsFromRegistry().then(function(response1) {
                    getMatchFieldsFromGlobal().then(function(response) {
                        deferd.resolve();
                    });
                });
                return deferd.promise;
            }

            function getMatchFieldsFromRegistry() {
                var defered = $q.defer();
                var baseV2UrlWithoutDbName = masterFactory.getApiV2BaseUrl();
                var apiUrl = baseV2UrlWithoutDbName + adHocWorkspaceFactory.getMatchFieldsUrl();
                $scope.mc.getlogDetails("Debug", 'Method:GET;URL' + JSON.stringify(apiUrl));

                var promise = homeService.getData(apiUrl);
                promise.then(function(response) {
                        if (response && response.data && response.data.data) {
                            var systemConfigUIModel = adHocWorkspaceFactory.getMatchFields(response.data.data);
                            if (systemConfigUIModel.IMCC_OF_MATCHFIELDS && systemConfigUIModel.IMCC_OF_MATCHFIELDS !== '' && vmAdHocWorkspaceCtrl.MatchField.length === 0) {
                                vmAdHocWorkspaceCtrl.MatchField = systemConfigUIModel.IMCC_OF_MATCHFIELDS.split(",");
                                if (vmAdHocWorkspaceCtrl.MatchField[0]) {
                                    vmAdHocWorkspaceCtrl.MatchField[0] = vmAdHocWorkspaceCtrl.MatchField[0].replace("improfile", "");
                                }
                                if (vmAdHocWorkspaceCtrl.MatchField[1]) {
                                    vmAdHocWorkspaceCtrl.MatchField[1] = vmAdHocWorkspaceCtrl.MatchField[1].replace("improfile", "");
                                }
                            }
                            if (systemConfigUIModel.hideHippa && systemConfigUIModel.hideHippa.toUpperCase() === 'Y') {
                                vmAdHocWorkspaceCtrl.ShowHippafield = false;
                            } else {
                                vmAdHocWorkspaceCtrl.ShowHippafield = true;
                            }
                            if (response.data.data['Email Domain'] && response.data.data['Email Domain'].trim().length > 0) {
                                folderEmailDomain = '.' + vmAdHocWorkspaceCtrl.SelectedLibrary + '@' + response.data.data['Email Domain']
                            }
                        }
                        defered.resolve();
                    },
                    function() {
                        defered.resolve();
                    });
                return defered.promise;
            }

            function getMatchFieldsFromGlobal() {
                var deferd1 = $q.defer();
                var baseUrlV2 = masterFactory.getApiV2BaseUrl(vmAdHocWorkspaceCtrl.SelectedLibrary, false, false);
                var apiUrl = baseUrlV2 + adHocWorkspaceFactory.getGlobalSettingsAPIUrl();
                var globalPromise = homeService.getData(apiUrl);
                globalPromise.then(function(response) {
                    if (response && response.status === 200) {
                        var globalSettingModel = adHocWorkspaceFactory.getGlobalSettingsModel(response.data);
                        if (globalSettingModel.MatchFields && globalSettingModel.MatchFields !== '' && globalSettingModel.MatchFields.length > 0) {
                            vmAdHocWorkspaceCtrl.MatchField = globalSettingModel.MatchFields.sort();

                            if (vmAdHocWorkspaceCtrl.MatchField[0])
                                vmAdHocWorkspaceCtrl.MatchField[0] = vmAdHocWorkspaceCtrl.MatchField[0].toLowerCase();
                            if (vmAdHocWorkspaceCtrl.MatchField[1])
                                vmAdHocWorkspaceCtrl.MatchField[1] = vmAdHocWorkspaceCtrl.MatchField[1].toLowerCase();
                        }
                        if (globalSettingModel.DenyCustomCreation && globalSettingModel.DenyCustomCreation !== '' && globalSettingModel.DenyCustomCreation.length > 0) {
                            angular.forEach(globalSettingModel.DenyCustomCreation, function(item) {
                                if (item !== null && item.trim().length > 0) {
                                    vmAdHocWorkspaceCtrl.DenyCreateNewCustomItemList.push(item.toUpperCase());
                                }
                            });
                        }

                        vmAdHocWorkspaceCtrl.ShowHippafield = !(globalSettingModel.HideHipaa && globalSettingModel.HideHipaa === true);
                        if (globalSettingModel.AutoGenerateFields || globalSettingModel.AutoGenerateFields === false) {
                            vmAdHocWorkspaceCtrl.IsAutoGenerateCustomAlias = globalSettingModel.AutoGenerateFields;
                        }
                        deferd1.resolve();
                    } else {
                        deferd1.resolve();
                    }
                }, function() {
                    deferd1.resolve();
                });
                return deferd1.promise;
            }

            function getTemplates() {
                var deffered = $q.defer();
                var requestModel = homeFactory.requestModelInstance();
                requestModel.pageLength = 300;
                requestModel.libraryName = vmAdHocWorkspaceCtrl.SelectedLibrary;

                var apiUrl = baseV2Url + adHocWorkspaceFactory.getTemplatesUrl(requestModel);
                $scope.mc.getlogDetails("Debug", 'Method:GET;URL' + JSON.stringify(apiUrl));

                var promise = homeService.getData(apiUrl);
                promise.then(function(response) {
                    vmAdHocWorkspaceCtrl.templateList = [];
                    if (response.status === 200) {
                        $scope.mc.getlogDetails("Info", "Received workspace details.");

                        var workSpaceUI;
                        angular.forEach(response.data.data, function(workSpace) {
                            workSpaceUI = adHocWorkspaceFactory.getworkSpaceUI(workSpace);
                            workSpaceUI.IMCCMATCHTYPE = "Exact";
                            vmAdHocWorkspaceCtrl.templateList.push(workSpaceUI);
                        });
                        if (vmAdHocWorkspaceCtrl.templateList.length > 0) {
                            //vmAdHocWorkspaceCtrl.SelectedTemplate = vmAdHocWorkspaceCtrl.templateList[0];
                        }
                    }
                    deffered.resolve();
                }, function(response) {
                    deffered.resolve();
                });
                return deffered.promise;
            }

            function SetSubClass() {
                vmAdHocWorkspaceCtrl.adHocWSUIModel.SubClass = null;
                vmAdHocWorkspaceCtrl.SubClassSearchText = '';
                if (vmAdHocWorkspaceCtrl.SelectedTemplate && vmAdHocWorkspaceCtrl.SelectedTemplate.SubClass) {
                    var searchAPIUrl = baseV2Url + adHocWorkspaceFactory.getSubClassDetailsAPI(vmAdHocWorkspaceCtrl.SelectedTemplate.SubClass);
                    var promise = homeService.getData(searchAPIUrl);
                    promise.then(function(response) {
                        if (response && response.data && response.data.data) {

                            var subClassUIModelTemp = adHocWorkspaceFactory.getSubClassUIModel(response.data.data[0]);
                            if (subClassUIModelTemp.Description && subClassUIModelTemp.Description.trim().length > 0) {
                                subClassUIModelTemp.Description = subClassUIModelTemp.Id + ' - ' + subClassUIModelTemp.Description;
                            } else {
                                subClassUIModelTemp.Description = subClassUIModelTemp.Id;
                            }
                            subClassUIModelTemp.IsSubClassItem = true;
                            vmAdHocWorkspaceCtrl.adHocWSUIModel.SubClass = subClassUIModelTemp;

                        }
                    });
                }
            }

            function SetMatchFiled(data) {
                vmAdHocWorkspaceCtrl.adHocWSUIModel['Custom' + data.replace("custom", "")] = null;
                vmAdHocWorkspaceCtrl['SearchCustom' + data.replace("custom", "") + 'Text'] = '';

                if (vmAdHocWorkspaceCtrl.SelectedTemplate) {
                    if (!data || data.trim().length === 0 || vmAdHocWorkspaceCtrl.SelectedTemplate[data] === null) {
                        return;
                    }
                    var requestModel = homeFactory.requestModelInstance();
                    requestModel.MetaType = data.toUpperCase();
                    requestModel.Alias = vmAdHocWorkspaceCtrl.SelectedTemplate[data];
                    requestModel.Database = vmAdHocWorkspaceCtrl.SelectedLibrary;

                    var searchAPIUrl = baseV2Url + adHocWorkspaceFactory.getCustomExistsAPI(requestModel);
                    var promise = homeService.getData(searchAPIUrl);
                    promise.then(function(response) {
                        if (response.status === 200 && response.data && response.data.data && response.data.data.length > 0) {
                            $scope.mc.getlogDetails("Success", 'Response:Success');

                            var metaDataUIModel = adHocWorkspaceFactory.getMetaDataUI(response.data.data[0]);
                            metaDataUIModel.IsMetaItem = true;
                            metaDataUIModel.IsItemCreated = true;
                            if (!vmAdHocWorkspaceCtrl.IsAutoGenerateCustomAlias) {
                                if (metaDataUIModel.Description && metaDataUIModel.Description.trim().length > 0) {
                                    metaDataUIModel.Description = metaDataUIModel.Alias + ' - ' + metaDataUIModel.Description;
                                } else {
                                    metaDataUIModel.Description = metaDataUIModel.Alias;
                                }
                            }
                            vmAdHocWorkspaceCtrl.adHocWSUIModel['Custom' + data.replace("custom", "")] = metaDataUIModel;
                        } else {
                            $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                        }
                    }, function(response) {
                        $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                    });
                }
            }

            function selectedTemplateChange(resetMatchfields) {
                $('.template-select-input').attr('style', '');
                $('.template-select-input').find('label').attr('style', '');
                var dialogExists = false;
                if ($('#spanProgressContent')) {
                    dialogExists = true;
                }
                changeProgressDialogMessage('adhocWorkspace.loadingItemsSelectedTemplates');
                vmAdHocWorkspaceCtrl.foldersList = [];
                vmAdHocWorkspaceCtrl.ItemsInSelectedLevel = [];
                if (vmAdHocWorkspaceCtrl.MatchField && !resetMatchfields && vmAdHocWorkspaceCtrl.MatchField.length > 0) {
                    templateChanged = true;
                    if (vmAdHocWorkspaceCtrl.MatchField[0])
                        SetMatchFiled(vmAdHocWorkspaceCtrl.MatchField[0]);
                    if (vmAdHocWorkspaceCtrl.MatchField[1])
                        SetMatchFiled(vmAdHocWorkspaceCtrl.MatchField[1]);
                }
                SetSubClass();
                var deffered = $q.defer();
                if (!resetMatchfields) {
                    vmAdHocWorkspaceCtrl.SecurityList = [];
                    vmAdHocWorkspaceCtrl.SecurityListWithFilter = [];
                }
                if (vmAdHocWorkspaceCtrl.SelectedTemplate) {
                    if (!resetMatchfields) {
                        var promiseLoggedUser = addLoggedUserToSecurityList();
                        promiseLoggedUser.then(function(responseLoggedUser) {
                            var promiseSecurity = getFolderSecurity(vmAdHocWorkspaceCtrl.SelectedTemplate.Id);
                            promiseSecurity.then(function(response) {
                                if (response.Status === 0 && response.SecurityList && response.SecurityList.length > 0) {
                                    angular.forEach(response.SecurityList, function(item) {
                                        var tempListFilter = $filter('filter')(vmAdHocWorkspaceCtrl.SecurityList, {
                                            Type: 'user',
                                            Id: item.Id
                                        }, true);
                                        if (tempListFilter.length === 0) {
                                            vmAdHocWorkspaceCtrl.SecurityList.push(angular.copy(item));
                                            vmAdHocWorkspaceCtrl.SecurityListWithFilter.push(angular.copy(item));
                                        }
                                        tempListFilter = undefined;
                                    });
                                }
                            });
                        });
                    }
                    var promiseNVP = getNameValuePairs(vmAdHocWorkspaceCtrl.SelectedTemplate.Id);
                    promiseNVP.then(function(response) {
                        vmAdHocWorkspaceCtrl.SelectedTemplate.NVPs = adHocWorkspaceFactory.getNVPUI(response.data);
                        vmAdHocWorkspaceCtrl.SelectedTemplate.NVPs.Actual_Prefix = vmAdHocWorkspaceCtrl.SelectedTemplate.NVPs.IMCC_Name_Prefix;
                        vmAdHocWorkspaceCtrl.adHocWSUIModel.DefaultSecurity = vmAdHocWorkspaceCtrl.SelectedTemplate.NVPs.IMCC_Default_Security;
                        var promiseChild = getOptionalFolders(vmAdHocWorkspaceCtrl.SelectedTemplate.Id, {});
                        promiseChild.then(function(response) {
                            angular.forEach(response, function(folder) {
                                if (folder != null)
                                    vmAdHocWorkspaceCtrl.foldersList.push(folder);
                            });
                            deffered.resolve();
                            $timeout(function() {
                                if (!dialogExists)
                                    $mdDialog.hide();
                            });
                        });
                    });
                }
                return deffered.promise;
            }

            function getNameValuePairs(id) {
                var deffered = $q.defer();
                if (!id) return;

                var requestModelObj = {};
                requestModelObj.Id = id;

                var apiUrl = baseV2Url + adHocWorkspaceFactory.getNVPUrl(requestModelObj);
                $scope.mc.getlogDetails("Debug", 'Method:GET;URL' + JSON.stringify(apiUrl));

                var promise = homeService.getData(apiUrl);
                promise.then(function(response) {
                    deffered.resolve(response.data);
                }, function(response) {
                    deffered.resolve([]);
                });
                return deffered.promise;
            }

            function getOptionalFolders(parentId, returnData) {
                var finaldeferred = $q.defer();

                var deferredarray = [];
                var requestObj = homeFactory.requestModelInstance();
                requestObj.Id = parentId;

                var apiUrl = baseV2Url + adHocWorkspaceFactory.getChildren(requestObj);
                $scope.mc.getlogDetails("Debug", 'Method:GET;URL' + JSON.stringify(apiUrl));

                var promise = homeService.getData(apiUrl)
                promise.then(function(response) {
                        if (response["status"] == 200 && response.data.data.length > 0) {
                            $scope.mc.getlogDetails("Info", "Received Folder details.");
                            if (!vmAdHocWorkspaceCtrl.SelectedTemplate.NVPs) {
                                vmAdHocWorkspaceCtrl.SelectedTemplate.NVPs = {};
                            }
                            replacehashValues(vmAdHocWorkspaceCtrl.SelectedTemplate.NVPs.IMCC_Name_Prefix).then(function(responsefolder) {
                                angular.forEach(response.data.data, function(folder) {
                                    var deferred = $q.defer();
                                    deferredarray.push(deferred.promise);

                                    var folderUIModel = adHocWorkspaceFactory.getFolderUI(folder);
                                    replacehashValues(folderUIModel.Name).then(function(responseFolderName) {

                                        folderUIModel.Name = responseFolderName;
                                        folderUIModel.Selected = false;
                                        folderUIModel.SubFolders = [];
                                        folderUIModel.IsExpanded = false;
                                        var IMCC_Allow_Prefix = vmAdHocWorkspaceCtrl.SelectedTemplate.NVPs.IMCC_Allow_Prefix;
                                        if (IMCC_Allow_Prefix == "1") {
                                            folderUIModel.Name = folderUIModel.Name + responsefolder;
                                        } else if (IMCC_Allow_Prefix == "0") {
                                            folderUIModel.Name = responsefolder + folderUIModel.Name;
                                        }
                                        var promiseNVP = getNameValuePairs(folderUIModel.Id);
                                        promiseNVP.then(function(response) {
                                            folderUIModel.NVPs = response.data;
                                            if (folderUIModel.NVPs.IMCC_IsOptional == undefined) {
                                                deferred.resolve(folderUIModel);
                                            } else {
                                                deferred.resolve(null);
                                            }

                                        });

                                    });
                                });
                                $q.all(deferredarray).then(function(AllResponse) {
                                    finaldeferred.resolve(AllResponse);
                                });

                            });

                        } else {
                            finaldeferred.resolve([]);
                            $scope.mc.getlogDetails("Info", 'Response:' + JSON.stringify(response));
                        }
                    },
                    function(response) {
                        finaldeferred.resolve([]);
                        $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));

                    });
                return finaldeferred.promise;
            }

            function changeFolderSelection(folder, event) {
                if (folder.NVPs.IMCC_IsOptional == 'false' || vmAdHocWorkspaceCtrl.IsFolderPreview)
                    return;
                folder.Selected = !folder.Selected;
                if (event)
                    event.stopPropagation();
            }

            function loadTemplatePreview() {
                vmAdHocWorkspaceCtrl.IsFolderPreview = true;
                vmAdHocWorkspaceCtrl.FoldersPreview = [];

                var selectedItems = ($filter('filter')(vmAdHocWorkspaceCtrl.foldersList, { Selected: true }, true))
                getAllChildrens(selectedItems).then(function(responsedata) {
                    vmAdHocWorkspaceCtrl.FoldersPreview = responsedata;
                });
            }

            function getAllChildrens(Objects) {
                var final = $q.defer();
                var deferedarry = [];
                angular.forEach(Objects, function(item) {
                    var dataQueue = $q.defer();
                    deferedarry.push(dataQueue.promise);
                    getOptionalFolders(item.Id, {})
                        .then(function(responsedata) {
                            item.SubFolders = [];
                            angular.forEach(responsedata, function(folder) {
                                if (folder != null)
                                    item.SubFolders.push(folder);
                            });

                            if (responsedata.length > 0) {
                                getAllChildrens(item.SubFolders).then(function(responsechild) {
                                    dataQueue.resolve(responsedata);
                                });
                            } else {
                                dataQueue.resolve(responsedata);
                            }
                        });
                });
                $q.all(deferedarry).then(function(Finalresponse) {
                    final.resolve(Objects);
                });
                return final.promise;
            }

            function closeWindow(actionType) {
                if ($location.search() && $location.search().protocol && $location.search().protocol === 'postmessage') {
                    var message = {
                        type: actionType,
                        data: JSON.stringify(vmAdHocWorkspaceCtrl.NewItemsList)
                    };
                    if ($window.parent)
                        $window.parent.postMessage(message, '*');
                } else {
                    try {
                        closewin();
                    } catch (err) {}
                }
                $scope.mc.onError = false;
            }

            function resizeWindow(dimensions) {
                if ($location.search() && $location.search().protocol && $location.search().protocol === 'postmessage') {
                    var message = {
                        type: 'resize',
                        data: JSON.stringify(dimensions)
                    };
                    if ($window.parent)
                        $window.parent.postMessage(message, '*');
                } else {
                    resizewin(dimensions.width + ';' + dimensions.height);
                }
            }


            function resetAllValues() {
                //$rootScope.checkReadyToChangeState = null;

                delete $scope.mc.$storage.LoginUserId;
                delete $scope.mc.$storage.toState;
                vmAdHocWorkspaceCtrl.SelectedLibrary = '';

                $scope.mc.loginModel.UserName = '';
                $scope.mc.loginModel.Password = '';
                if (angular.isDefined($scope.mc.loginModel.UserSessionTimeOut)) {
                    $interval.cancel($scope.mc.loginModel.UserSessionTimeOut);
                    $scope.mc.loginModel.UserSessionTimeOut = null;
                }
                if (UserSessionTimer) {
                    $timeout.cancel(UserSessionTimer);
                    UserSessionTimer = null;
                }
                sessionTime = -1;
            }

            function getDBLibraries() {
                var deferred = $q.defer();
                var baseV2UrlWithoutDbName = masterFactory.getApiV2BaseUrl();
                var apiUrl = baseV2UrlWithoutDbName + homeFactory.getDBListAPI();
                $scope.mc.getlogDetails("Debug", 'Method:GET;URL:' + apiUrl);

                var promise = homeService.getData(apiUrl);
                promise.then(function(response) {
                    if (response && response.data && response.data.data && response.data.data.length > 0) {
                        $scope.mc.getlogDetails("Info", 'Response:Success');

                        var promiseDB = getPrimaryDatabase();
                        promiseDB.then(function(responseDB) {
                            var tempDBModel;
                            var selectedDb;
                            var primaryDb;
                            vmAdHocWorkspaceCtrl.LocationList = [];
                            angular.forEach(response.data.data, function(db) {
                                tempDBModel = homeFactory.getDatabaseUI(db);
                                if (vmAdHocWorkspaceCtrl.SelectedLibrary && vmAdHocWorkspaceCtrl.SelectedLibrary.trim().length > 0) {
                                    if (tempDBModel.DatabaseName.toUpperCase() === vmAdHocWorkspaceCtrl.SelectedLibrary.toUpperCase()) {
                                        selectedDb = tempDBModel.DatabaseName;
                                    }
                                }
                                if (responseDB && responseDB.Status === 0 && responseDB.PrimaryDBName) {
                                    if (responseDB.PrimaryDBName.toUpperCase() === vmAdHocWorkspaceCtrl.SelectedLibrary.toUpperCase()) {
                                        primaryDb = tempDBModel.DatabaseName;
                                    }
                                }
                                vmAdHocWorkspaceCtrl.LocationList.push(tempDBModel);
                                tempDBModel = null;
                            });
                            if (selectedDb) {
                                vmAdHocWorkspaceCtrl.SelectedLibrary = selectedDb;
                            } else if (primaryDb) {
                                vmAdHocWorkspaceCtrl.SelectedLibrary = primaryDb;
                            } else {
                                vmAdHocWorkspaceCtrl.SelectedLibrary = vmAdHocWorkspaceCtrl.LocationList[0].DatabaseName;
                            }
                            deferred.resolve({ Status: 0 });
                        });

                        // if (!vmAdHocWorkspaceCtrl.SelectedLibrary || vmAdHocWorkspaceCtrl.SelectedLibrary.trim().length === 0) {
                        //     setUserDBToCombo();
                        // }
                        // if (!vmAdHocWorkspaceCtrl.SelectedLibrary || vmAdHocWorkspaceCtrl.SelectedLibrary.trim().length === 0) {
                        //     setUserDBToCombo();
                        // } else {
                        //     initalizePageData();
                        // }
                    } else if (response && response.data && response.data.status === 401 || response.status == 401) {
                        //redirectToLogin();
                        deferred.resolve({ Status: -1 });
                    }
                }, function(response) {
                    $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                    deferred.resolve({ Status: -1 });
                });
                return deferred.promise;
            }


            function getPrimaryDatabase() {
                var deferred = $q.defer();
                var baseV2UrlWithoutDbName = masterFactory.getApiV2BaseUrl();
                var apiUrl = baseV2UrlWithoutDbName + homeFactory.getPrimaryDBNameAPI();
                $scope.mc.getlogDetails("Debug", 'Method:GET;URL:' + apiUrl);

                var promise = homeService.getData(apiUrl, $scope.mc.loginModel.AuthKey);
                promise.then(function(response) {
                    if (response && response.data && response.data.data) {
                        $scope.mc.getlogDetails("Info", 'Response:Success');

                        if (response.data.data.databases && response.data.data.databases.length > 0) {
                            var tempListFilter = $filter('filter')(response.data.data.databases, {
                                Primary: 'Y'
                            }, true);
                            if (tempListFilter.length > 0) {
                                deferred.resolve({ Status: 0, PrimaryDBName: tempListFilter[0].id });
                            } else {
                                deferred.resolve({ Status: -1 });
                            }
                        } else {
                            deferred.resolve({ Status: -1 });
                        }
                    } else {
                        deferred.resolve({ Status: -1 });
                    }
                }, function(response) {
                    deferred.resolve({ Status: -1 });
                });
                return deferred.promise;
            }

            function selectedDB_Change() {
                showProgressDialog();
                initalizePageData();
            }

            function getWebSettings() {
                var deferred = $q.defer();
                var apiUrl;

                if (baseV2Url.indexOf('imcc/') !== -1) {
                    apiUrl = baseV2Url + adHocWorkspaceFactory.getWebSettingsUrl();
                } else {
                    apiUrl = baseV2Url + adHocWorkspaceFactory.getConfigWebSettingsUrl();
                }
                var promise = homeService.getData(apiUrl);
                promise.then(function(response) {
                    deferred.resolve(response);
                }, function(response) {
                    deferred.resolve(response);
                });
                return deferred.promise;
            }

            function getDefaultLocale() {
                var deferred = $q.defer();

                if ($location.search().locale && $location.search().locale.toString().trim().length > 0) {
                    deferred.resolve({ Status: 0, LocaleDefault: $location.search().locale });
                    return deferred.promise;
                }

                if (localStorage.getItem('locale') && localStorage.getItem('locale').toString().trim().length > 0) {
                    deferred.resolve({ Status: 0, LocaleDefault: localStorage.getItem('locale') });
                    return deferred.promise;
                }

                var promiseWebSetting = getWebSettings();
                promiseWebSetting.then(function(responseWebSettings) {
                    if (responseWebSettings.status === 200 && responseWebSettings.data && responseWebSettings.data.general &&
                        responseWebSettings.data.general.language && responseWebSettings.data.general.language.trim().length > 0) {
                        deferred.resolve({ Status: 0, LocaleDefault: responseWebSettings.data.general.language });
                    } else {
                        var apiUrl = masterFactory.getApiV2BaseUrl() + adHocWorkspaceFactory.getMatchFieldsUrl();
                        var promise = homeService.getData(apiUrl);
                        promise.then(function(response) {
                            if (response && response.data && response.data.data && response.data.data['Locale Default']) {
                                deferred.resolve({ Status: 0, LocaleDefault: response.data.data['Locale Default'] });
                            } else {
                                deferred.resolve({ Status: 0, LocaleDefault: 'en-US' });
                            }
                        });
                    }
                });
                return deferred.promise;
            }

            function getCaptions() {
                var deferred = $q.defer();
                var promise = getDefaultLocale();
                promise.then(function(localeLanguage) {
                    var capRequestModel = homeFactory.requestModelInstance();
                    capRequestModel.libraryName = vmAdHocWorkspaceCtrl.SelectedLibrary;
                    capRequestModel.isTotal = true;
                    capRequestModel.searchText = '';
                    capRequestModel.pageLength = 1000;
                    capRequestModel.language = localeLanguage.LocaleDefault;

                    var apiUrl = baseV2Url + homeFactory.getAPIUrl('SEARCHCAPTIONS', capRequestModel)
                    $scope.mc.getlogDetails("Debug", 'Requested Api Url:' + JSON.stringify(apiUrl));

                    var promise = homeService.getData(apiUrl);
                    promise.then(function(response) {
                        $scope.CaptionsList = [];
                        $scope.mc.getlogDetails("Debug", 'Response:Success');
                        vmAdHocWorkspaceCtrl.myMatterCaption = 'My Matters';
                        if (response && response.data && response.data.data) {
                            angular.forEach(response.data.data, function(caption) {
                                $scope.CaptionsList.push(homeFactory.getCaptionUIModel(caption));
                            });
                            var myMatterCaption = $filter('filter')($scope.CaptionsList, {
                                MetaDataItem: 'MYMTRSND'
                            }, true);
                            vmAdHocWorkspaceCtrl.myMatterCaption = myMatterCaption[0].DisplayText;
                        }
                        deferred.resolve();
                    }, function(response) {
                        deferred.resolve();
                    });
                });
                return deferred.promise;
            }

            function getUserDetails() {
                var defer = $q.defer();
                $scope.mc.loginModel.FullName = '';

                $scope.mc.getlogDetails("Debug", 'Method:GET; Action: ViewUser ;');

                var apiUrl = baseV2Url + homeFactory.getSingleUserAPI();
                var promise = homeService.getData(apiUrl);
                promise.then(function(response) {
                    if (response && response.data && response.data.data) {
                        $scope.mc.getlogDetails("Debug", 'Response:Success');

                        var loggedUserModel = homeFactory.getUserUI(response.data.data);
                        $scope.mc.loginModel.UserName = loggedUserModel.UserId;
                        $scope.mc.$storage.LoginUserId = loggedUserModel.UserId;
                        if (loggedUserModel.FullName)
                            $scope.mc.loginModel.FullName = loggedUserModel.FullName.trim();

                        apiUrl = baseV2Url + homeFactory.getUserDbOperationAPI();
                        $scope.mc.getlogDetails("Debug", 'Requested Api Url:' + JSON.stringify(apiUrl));

                        var promiseOp = homeService.getData(apiUrl);
                        promiseOp.then(function(responseOp) {
                            $scope.mc.getlogDetails("Debug", 'Response:Success');
                            //if (responseOp && responseOp.data && responseOp.data.data) {
                            if (responseOp && responseOp.data && responseOp.data.data && responseOp.data.data.length > 0) {
                                var filterListTemp = $filter('filter')(vmAdHocWorkspaceCtrl.LocationList, {
                                    DatabaseName: vmAdHocWorkspaceCtrl.SelectedLibrary
                                }, true);
                                if (filterListTemp.length > 0) {

                                    var DbFilterListTemp = $filter('filter')(responseOp.data.data, {
                                        database: vmAdHocWorkspaceCtrl.SelectedLibrary
                                    }, true);

                                    if (DbFilterListTemp.length > 0) {
                                        homeFactory.setDBOperation(filterListTemp[0], DbFilterListTemp[0]);
                                    }
                                }
                            }
                            defer.resolve($scope.mc.loginModel.UserName);
                        }, function(responseOp) {
                            $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(responseOp));
                            defer.resolve($scope.mc.loginModel.UserName);
                        });
                    }
                }, function(response) {
                    $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                    defer.resolve(null);
                });
                return defer.promise;
            }

            function addLoggedUserToSecurityList() {
                var deffered = $q.defer();
                var loggedUserModel = {};
                loggedUserModel.UserId = $scope.mc.loginModel.UserName;
                loggedUserModel.FullName = $scope.mc.loginModel.FullName;
                loggedUserModel.UserPhotoText = '';
                loggedUserModel.UserPhoto = null;
                loggedUserModel.Type = 'User';

                var promise = getUserPhoto(loggedUserModel);
                promise.then(function(response) {
                    var securityUIModel = null;
                    securityUIModel = adHocWorkspaceFactory.getSecurityInitialValue();
                    securityUIModel.Id = loggedUserModel.UserId;
                    securityUIModel.Name = loggedUserModel.FullName;
                    securityUIModel.UserPhoto = loggedUserModel.UserPhoto;
                    securityUIModel.UserPhotoText = loggedUserModel.UserPhotoText;
                    securityUIModel.AccessLevel = 'full_access';
                    securityUIModel.Access = 3;
                    securityUIModel.Type = 'user';

                    vmAdHocWorkspaceCtrl.SecurityList.push(securityUIModel);
                    vmAdHocWorkspaceCtrl.SecurityListWithFilter.push(securityUIModel);
                    securityUIModel = null;
                    deffered.resolve();
                });
                return deffered.promise;
            }

            function getVisibleFieldList() {
                var deferred = $q.defer();
                vmAdHocWorkspaceCtrl.VisibleFieldList = [];



                var apiUrl = baseV2Url + adHocWorkspaceFactory.getVisibleFieldListAPI(vmAdHocWorkspaceCtrl.SelectedLibrary);
                var promise = homeService.getData(apiUrl);
                promise.then(function(response) {
                    vmAdHocWorkspaceCtrl.VisibleFieldList = [];
                    if (response.status === 200 && response.data && response.data.data && response.data.data.length > 0) {
                        vmAdHocWorkspaceCtrl.VisibleFieldList = vmAdHocWorkspaceCtrl.VisibleFieldList.concat(response.data.data);
                    }
                    deferred.resolve();
                }, function(response) {
                    vmAdHocWorkspaceCtrl.VisibleFieldList = [];
                    deferred.resolve();
                });
                return deferred.promise;
            }

            function addUserGroupToCategoryList(item, event) {
                if (event) event.stopPropagation();
                if (item == null) {
                    vmAdHocWorkspaceCtrl.SelectedUserGroupForCategory = null;
                    document.getElementById("autoCompleteUserGroupSearch").blur();
                    return;
                }
                vmAdHocWorkspaceCtrl.addUserGroupListToCategory.push(item);
                vmAdHocWorkspaceCtrl.UserGroupSearchTextForCategory = '';
            }

            function selectedUserGroup_Change(item, event) {
                if (event) event.stopPropagation();
                if (item == null) {
                    vmAdHocWorkspaceCtrl.SelectedUserGroup = null;
                    document.getElementById("autoCompleteUserGroupSearch").blur();
                    return;
                }
                var securityUIModel = null;
                for (var iCount = 0; iCount < vmAdHocWorkspaceCtrl.NewUserGroupList.length; iCount++) {
                    if (item.Type === 'User') {
                        if (vmAdHocWorkspaceCtrl.NewUserGroupList[iCount].Id === item.UserId &&
                            vmAdHocWorkspaceCtrl.NewUserGroupList[iCount].Type === 'user') {
                            securityUIModel = vmAdHocWorkspaceCtrl.NewUserGroupList[iCount];
                            break;
                        }
                    } else if (item.Type === 'Group') {
                        if (vmAdHocWorkspaceCtrl.NewUserGroupList[iCount].Id === item.Name &&
                            vmAdHocWorkspaceCtrl.NewUserGroupList[iCount].Type === 'group') {
                            securityUIModel = vmAdHocWorkspaceCtrl.NewUserGroupList[iCount];
                            break;
                        }
                    }
                }
                if (securityUIModel === null) {
                    securityUIModel = adHocWorkspaceFactory.getSecurityInitialValue();
                    vmAdHocWorkspaceCtrl.NewUserGroupList.push(securityUIModel);
                    securityUIModel = null;

                    securityUIModel = vmAdHocWorkspaceCtrl.NewUserGroupList[vmAdHocWorkspaceCtrl.NewUserGroupList.length - 1];
                    if (item.Type === 'User') {
                        securityUIModel.Id = item.UserId;
                        securityUIModel.Name = item.FullName;
                        securityUIModel.UserPhoto = item.UserPhoto;
                        securityUIModel.UserPhotoText = item.UserPhotoText;
                        securityUIModel.Type = 'user';
                    } else if (item.Type === 'Group') {
                        securityUIModel.Id = item.Name;
                        securityUIModel.Name = item.IsFullNameFound ? item.FullName : item.Name;
                        securityUIModel.Type = 'group';
                        securityUIModel.UserPhoto = 'assets/images/active-users.svg';
                    }
                    securityUIModel.IsFullNameFound = item.IsFullNameFound;
                }
                securityUIModel.AccessLevel = 'full_access';
                securityUIModel.Access = 3;

                securityUIModel = null;
                item = null;
                vmAdHocWorkspaceCtrl.SelectedUserGroup = null;
                vmAdHocWorkspaceCtrl.UserGroupSearchText = '';
            }

            function querySearchUserGroup(searchText) {
                var deferredSearch = $q.defer();
                var deferedarry = [];
                var searchList = [];

                if (vmAdHocWorkspaceCtrl.IsCreateMatterCategoryShowing) {
                    if (searchText.length == 0) {
                        deferredSearch.resolve(categorySecurityList);
                    } else {
                        searchText = searchText.toUpperCase();
                        var categorySecurityListObj = [];
                        angular.forEach(categorySecurityList, function(item) {
                            if (item.Id.toUpperCase().indexOf(searchText) > -1 ||
                                (item.IsFullNameFound && item.Name.toUpperCase().indexOf(searchText) > -1)) {
                                categorySecurityListObj.push(angular.copy(item));
                            }
                        });
                        deferredSearch.resolve(categorySecurityListObj);
                    }
                } else {
                    searchText = searchText.trim();
                    if (searchText.length === 0) {
                        deferredSearch.resolve([]);
                        return deferredSearch.promise;
                    }

                    var deferred = $q.defer();
                    var promiseUser = searchUser(searchText);
                    promiseUser.then(function(response) {
                        if (response != null && response.length > 0) {
                            searchList = searchList.concat(response);
                            deferred.resolve();
                        } else {
                            deferred.resolve();
                        }
                    }, function(response) {
                        deferred.resolve();
                    });
                    deferedarry.push(deferred.promise);

                    var deferredGroup = $q.defer();
                    var promiseGroup = searchGroup(searchText);
                    promiseGroup.then(function(response) {
                        if (response.Status === 0) {
                            searchList = searchList.concat(response.SearchResultList);
                            deferredGroup.resolve();
                        }
                    }, function(response) {
                        deferredGroup.resolve();
                    });
                    deferedarry.push(deferredGroup.promise);

                    $q.all(deferedarry).then(function() {
                        deferredSearch.resolve(searchList);
                    });
                }
                return deferredSearch.promise;
            }

            function searchUser(searchText, filterType) {
                var deferred = $q.defer();
                var lblNoName = 'No Name';
                $translate(lblNoName).then(function(text) {
                    lblNoName = text;
                });
                var requestModel = homeFactory.requestModelInstance();
                requestModel.libraryName = vmAdHocWorkspaceCtrl.SelectedLibrary;
                requestModel.searchText = searchText;
                requestModel.pagenumber = 1;

                var apiUrl = baseV2Url + adHocWorkspaceFactory.getSearchUserAPI(requestModel, false);
                $scope.mc.getlogDetails("Debug", 'Requested Api Url:' + JSON.stringify(apiUrl));

                var promise = homeService.getData(apiUrl);
                promise.then(function(response) {
                    if (response.status === 200 && response.data && response.data.data && response.data.data.length > 0) {
                        $scope.mc.getlogDetails("Debug", 'Response:Success');

                        var userList = [];
                        var deferedarryPhoto = [];
                        angular.forEach(response.data.data, function(user) {
                            var deferredPhoto = $q.defer();
                            var userUIModel = adHocWorkspaceFactory.getUserUI(user);
                            userUIModel.IsFullNameFound = userUIModel.FullName != null && userUIModel.FullName.trim().length > 0;
                            if (!userUIModel.IsFullNameFound) {
                                userUIModel.FullName = lblNoName;
                                userUIModel.FullNameCustom = userUIModel.UserId;
                            } else {
                                userUIModel.FullNameCustom = userUIModel.FullName;
                            }
                            var filterListTemp = [];
                            var filterNewListTemp = [];
                            if (filterType !== 'no-filter') {
                                filterListTemp = $filter('filter')(vmAdHocWorkspaceCtrl.SecurityList, {
                                    Id: userUIModel.UserId,
                                    Type: 'user'
                                }, true);
                                filterNewListTemp = $filter('filter')(vmAdHocWorkspaceCtrl.NewUserGroupList, {
                                    Id: userUIModel.UserId,
                                    Type: 'user'
                                }, true);
                            }
                            if (filterListTemp.length > 0 || filterNewListTemp.length > 0) {
                                userUIModel = null;
                                deferredPhoto.resolve();
                            } else {
                                var promisePhoto = getUserPhoto(userUIModel);
                                promisePhoto.then(function(responsePhoto) {
                                    userList.push(userUIModel);
                                    userUIModel = null;
                                    deferredPhoto.resolve();
                                }, function(responsePhoto) {
                                    userList.push(userUIModel);
                                    userUIModel = null;
                                    deferredPhoto.resolve();
                                });
                            }
                            deferedarryPhoto.push(deferredPhoto.promise);
                        });
                        $q.all(deferedarryPhoto).then(function() {
                            deferred.resolve(userList);
                        });
                    } else {
                        $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                        deferred.resolve([]);
                    }
                }, function(response) {
                    $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                    deferred.resolve([]);
                });
                return deferred.promise;
            }

            function getUserPhoto(tempUserModel) {
                var deferred = $q.defer();
                var userId = '';
                var fullName = '';

                if (tempUserModel.Id != null && tempUserModel.Id.trim().length > 0) {
                    userId = tempUserModel.Id;
                } else if (tempUserModel.UserId != null && tempUserModel.UserId.trim().length > 0) {
                    userId = tempUserModel.UserId;
                }
                if (userId.trim().length === 0) {
                    deferred.resolve({ Status: -1 });
                    return deferred.promise;
                }
                if (tempUserModel.IsFullNameFound && tempUserModel.FullName) {
                    fullName = tempUserModel.FullName.trim();
                } else if (tempUserModel.Name != null && tempUserModel.Name.trim().length > 0) {
                    fullName = tempUserModel.Name.trim();
                }
                var photoText = '';
                if (fullName.length > 0) {
                    var nextChar = '';
                    var spaceFound = false;

                    for (var iCount = 0; iCount < fullName.length; iCount++) {
                        nextChar = fullName.substr(iCount, 1).trim();
                        if (nextChar.length === 0) {
                            spaceFound = true;
                            continue;
                        }
                        if (spaceFound) {
                            photoText = nextChar;
                            spaceFound = false;
                        }
                    }
                    if (photoText.trim().length === 0) {
                        photoText = fullName.substr(0, 2);
                    } else {
                        photoText = fullName.substr(0, 1) + photoText;
                    }
                } else {
                    photoText = userId.trim().substr(0, 2);
                }
                tempUserModel.UserPhotoText = photoText;

                var apiUrl = baseV2Url + adHocWorkspaceFactory.getUserPhotoAPI(userId);
                $scope.mc.getlogDetails("Debug", 'Requested Api Url:' + JSON.stringify(apiUrl));

                var promise = homeService.getImageData(apiUrl);
                promise.then(function(response) {
                    if (response.status === 200 && response.data) {
                        $scope.mc.getlogDetails("Debug", 'Response:Success');

                        var blob = new Blob([response.data], { type: 'application/octet-stream' });
                        var url = $window.URL || $window.webkitURL;
                        tempUserModel.UserPhoto = url.createObjectURL(blob);

                        deferred.resolve({ Status: 0 });
                    } else {
                        $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                        deferred.resolve({ Status: -1 });
                    }
                }, function(response) {
                    $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                    deferred.resolve({ Status: -1 });
                });
                return deferred.promise;
            }

            function searchGroup(searchText) {
                var deferred = $q.defer();
                var lblNoName = 'No Name';
                $translate(lblNoName).then(function(text) {
                    lblNoName = text;
                });
                var requestModel = homeFactory.requestModelInstance();
                requestModel.libraryName = vmAdHocWorkspaceCtrl.SelectedLibrary;
                requestModel.searchText = searchText;
                requestModel.pagenumber = 0;

                var apiUrl = baseV2Url + adHocWorkspaceFactory.getSearchGroupAPI(requestModel);
                $scope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(apiUrl));

                var promise = homeService.getData(apiUrl);
                promise.then(function(response) {
                    if (response.status === 200) {
                        $scope.mc.getlogDetails("Info", 'Response:Success');

                        var groupList = [];
                        angular.forEach(response.data.data, function(group) {
                            var newgroup = adHocWorkspaceFactory.getGroupUIModel(group);
                            newgroup.IsFullNameFound = newgroup.FullName != null && newgroup.FullName.trim().length > 0;
                            if (!newgroup.IsFullNameFound) {
                                newgroup.FullName = lblNoName;
                            }
                            var filterListTemp = $filter('filter')(vmAdHocWorkspaceCtrl.SecurityList, {
                                Id: newgroup.Name,
                                Type: 'group'
                            }, true);
                            var filterNewListTemp = $filter('filter')(vmAdHocWorkspaceCtrl.NewUserGroupList, {
                                Id: newgroup.Name,
                                Type: 'group'
                            }, true);
                            if (filterListTemp.length === 0 && filterNewListTemp.length === 0) {
                                groupList.push(newgroup);
                            }
                        });
                        deferred.resolve({ Status: 0, SearchResultList: groupList });
                    } else {
                        $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                        deferred.resolve({ Status: -1 });
                    }
                }, function(response) {
                    $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                    deferred.resolve({ Status: -1 });
                });
                return deferred.promise;
            }

            function newUserGroupListAccess_Change(member) {
                if (member.AccessLevel === 'RemoveItem') {
                    vmAdHocWorkspaceCtrl.NewUserGroupList = $.grep(vmAdHocWorkspaceCtrl.NewUserGroupList,
                        function(item, index) {
                            return item.Id === member.Id && item.Type === member.Type
                        }, true);
                }
            }

            function UserGroupListOfCategory_Change(member) {
                if (member.AccessLevel === 'RemoveItem') {
                    vmAdHocWorkspaceCtrl.addUserGroupListToCategory = $.grep(vmAdHocWorkspaceCtrl.addUserGroupListToCategory,
                        function(item, index) {
                            return item.Id === member.Id && item.Type === member.Type
                        }, true);
                }
            }

            function saveSecurityUserGroup() {
                if (vmAdHocWorkspaceCtrl.IsCreateMatterCategoryShowing) {
                    vmAdHocWorkspaceCtrl.SecurityListSearchTextForMatterCategory = '';
                    var filterListTemp = [];
                    var tempListFilter = $.grep(vmAdHocWorkspaceCtrl.addUserGroupListToCategory,
                        function(item, index) {
                            return item.Type !== 'RemoveItem';
                        });
                    angular.forEach(tempListFilter, function(item) {
                        filterListTemp = $filter('filter')(categorySecurityList, {
                            Id: item.Id,
                            Type: item.Type
                        }, true);
                        if (filterListTemp.length === 0) {
                            item.SID = 0;
                            categorySecurityList.push(angular.copy(item));
                        }
                        filterListTemp = [];
                    });
                    searchSecurityUserGroupInMatterCategory_Click();
                    backFromAddUserGroup();
                } else {
                    vmAdHocWorkspaceCtrl.SecurityListSearchText = '';
                    var filterListTemp = [];
                    var tempListFilter = $.grep(vmAdHocWorkspaceCtrl.NewUserGroupList,
                        function(item, index) {
                            return item.Type !== 'RemoveItem';
                        });
                    angular.forEach(tempListFilter, function(item) {
                        filterListTemp = $filter('filter')(vmAdHocWorkspaceCtrl.SecurityList, {
                            Id: item.Id,
                            Type: item.Type
                        }, true);
                        if (filterListTemp.length === 0) {
                            item.SID = 0;
                            vmAdHocWorkspaceCtrl.SecurityList.push(angular.copy(item));
                        }
                        filterListTemp = [];
                    });
                    searchSecurityUserGroup_Click();
                    backFromAddUserGroup();
                }
            }

            function searchSecurityUserGroup_Click() {
                var searchText = '';
                if (securityListSearchTimeOut)
                    $timeout.cancel(securityListSearchTimeOut);
                vmAdHocWorkspaceCtrl.SecurityListWithFilter = [];
                vmAdHocWorkspaceCtrl.SecurityListSearchText = vmAdHocWorkspaceCtrl.SecurityListSearchText.trim();
                searchText = vmAdHocWorkspaceCtrl.SecurityListSearchText.toUpperCase();

                if (vmAdHocWorkspaceCtrl.SecurityListSearchText.length === 0) {
                    vmAdHocWorkspaceCtrl.SecurityListWithFilter = angular.copy(vmAdHocWorkspaceCtrl.SecurityList);
                } else {
                    angular.forEach(vmAdHocWorkspaceCtrl.SecurityList, function(item) {
                        if (item.Id.toUpperCase().indexOf(searchText) > -1 ||
                            item.Name.toUpperCase().indexOf(searchText) > -1) {
                            vmAdHocWorkspaceCtrl.SecurityListWithFilter.push(angular.copy(item));
                        }
                    });
                }
            }

            function searchSecurityUserGroupInMatterCategory_Click() {
                var searchText = '';
                if (securityListSearchTimeOut)
                    $timeout.cancel(securityListSearchTimeOut);
                vmAdHocWorkspaceCtrl.SecurityListWithFilterInMatterCategory = [];
                vmAdHocWorkspaceCtrl.SecurityListSearchTextForMatterCategory = vmAdHocWorkspaceCtrl.SecurityListSearchTextForMatterCategory.trim();
                searchText = vmAdHocWorkspaceCtrl.SecurityListSearchTextForMatterCategory.toUpperCase();

                if (vmAdHocWorkspaceCtrl.SecurityListSearchTextForMatterCategory.length === 0) {
                    vmAdHocWorkspaceCtrl.SecurityListWithFilterInMatterCategory = angular.copy(categorySecurityList);
                } else {
                    angular.forEach(categorySecurityList, function(item) {
                        if (item.Id.toUpperCase().indexOf(searchText) > -1 ||
                            (item.IsFullNameFound && item.Name.toUpperCase().indexOf(searchText) > -1)) {
                            vmAdHocWorkspaceCtrl.SecurityListWithFilterInMatterCategory.push(angular.copy(item));
                        }
                    });
                }
            }

            function accessLevel_Change(selectedModel) {
                if (selectedModel.AccessLevel === 'RemoveItem') {
                    vmAdHocWorkspaceCtrl.SecurityList = $.grep(vmAdHocWorkspaceCtrl.SecurityList,
                        function(item, index) {
                            return !(item.Type === selectedModel.Type && item.Id === selectedModel.Id);
                        });
                    return;
                }
                for (var iCount = 0; iCount < vmAdHocWorkspaceCtrl.SecurityList.length; iCount++) {
                    if (selectedModel.Type === vmAdHocWorkspaceCtrl.SecurityList[iCount].Type &&
                        selectedModel.Id === vmAdHocWorkspaceCtrl.SecurityList[iCount].Id) {
                        vmAdHocWorkspaceCtrl.SecurityList[iCount].AccessLevel = selectedModel.AccessLevel;
                        break;
                    }
                }
            }

            function showGroupMemberList(groupModel) {
                vmAdHocWorkspaceCtrl.IsGroupMemberVisible = true;
                vmAdHocWorkspaceCtrl.GroupMembers.SelectedGroup = angular.copy(groupModel);
                vmAdHocWorkspaceCtrl.GroupMembers.HeaderText = '';
                vmAdHocWorkspaceCtrl.GroupMembers.SearchText = '';
                vmAdHocWorkspaceCtrl.GroupMembers.GroupMemberList = [];
                groupMembersReqModel = homeFactory.requestModelInstance();
                groupMembersReqModel.pagenumber = 1;

                getGroupMembers();
            }

            function hideGroupMemberList() {
                if (groupMemberSearchTimeOut)
                    $timeout.cancel(groupMemberSearchTimeOut);
                vmAdHocWorkspaceCtrl.IsGroupMemberVisible = false;
                vmAdHocWorkspaceCtrl.GroupMembers.SelectedGroup = null;
                vmAdHocWorkspaceCtrl.GroupMembers.HeaderText = '';
                vmAdHocWorkspaceCtrl.GroupMembers.SearchText = '';
                vmAdHocWorkspaceCtrl.GroupMembers.GroupMemberList = [];
                groupMembersTotalCount = 0;
            }

            function groupMembers_ClearSearchClick() {
                isgroupMembersInstantSearch = true;
                vmAdHocWorkspaceCtrl.GroupMembers.SearchText = '';
            }

            function groupMembers_SearchClick() {
                if (groupMemberSearchTimeOut)
                    $timeout.cancel(groupMemberSearchTimeOut);

                groupMembersReqModel = homeFactory.requestModelInstance();
                groupMembersReqModel.pagenumber = 1;
                vmAdHocWorkspaceCtrl.GroupMembers.GroupMemberList = [];
                getGroupMembers();
            }

            function groupMembers_onListScroll() {
                if (groupMembersTotalCount > vmAdHocWorkspaceCtrl.GroupMembers.GroupMemberList.length) {
                    groupMembersReqModel.pagenumber += 1;
                    getGroupMembers()
                }
            }

            function getGroupMembers() {
                groupMembersReqModel.libraryName = vmAdHocWorkspaceCtrl.SelectedLibrary;
                groupMembersReqModel.searchText = vmAdHocWorkspaceCtrl.GroupMembers.SearchText;

                var apiUrl = baseV2Url + adHocWorkspaceFactory.getGroupMembersAPI(groupMembersReqModel, vmAdHocWorkspaceCtrl.GroupMembers.SelectedGroup.Id);
                $scope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(apiUrl));

                var promise = homeService.getData(apiUrl);
                promise.then(function(response) {
                    if (response.status === 200 && response.data) {
                        if (vmAdHocWorkspaceCtrl.GroupMembers.SearchText.length === 0) {
                            if (response.data.total_count > 0) {
                                $translate('adhocWorkspace.groupMembersHeadingWithCount', {
                                    groupName: vmAdHocWorkspaceCtrl.GroupMembers.SelectedGroup.Id,
                                    membersCount: response.data.total_count.toString()
                                }).then(function(text) {
                                    vmAdHocWorkspaceCtrl.GroupMembers.HeaderText = text;
                                });
                            } else {
                                $translate('adhocWorkspace.groupMembersHeading').then(function(translatedValue) {
                                    vmAdHocWorkspaceCtrl.GroupMembers.HeaderText = translatedValue;
                                });
                            }
                        }
                        groupMembersTotalCount = response.data.total_count;

                        if (response.data.data) {
                            angular.forEach(response.data.data, function(userItem) {
                                var userUIModelTemp = adHocWorkspaceFactory.getUserUI(userItem);

                                getUserPhoto(userUIModelTemp).then(function(responseItem) {
                                    vmAdHocWorkspaceCtrl.GroupMembers.GroupMemberList.push(userUIModelTemp);
                                });
                            });
                        }
                    } else {
                        $scope.mc.getlogDetails("Error", 'Method:GET;URL:' + JSON.stringify(apiUrl) + ",Response:" + JSON.stringify(response));
                    }
                }, function(response) {
                    $scope.mc.getlogDetails("Error", 'Method:GET;URL:' + JSON.stringify(apiUrl) + ",Response:" + JSON.stringify(response));
                });
            }

            function addUserGroup() {
                vmAdHocWorkspaceCtrl.isAddUserGroupDialogShowing = true;
                vmAdHocWorkspaceCtrl.IsHideMainPage = true;
                vmAdHocWorkspaceCtrl.IsCreateMatterCategoryActive = false;
                vmAdHocWorkspaceCtrl.addUserGroupListToCategory = [];
            }

            function backFromAddUserGroup() {
                if (vmAdHocWorkspaceCtrl.IsCreateMatterCategoryShowing) {
                    vmAdHocWorkspaceCtrl.IsCreateMatterCategoryActive = true;
                    vmAdHocWorkspaceCtrl.isAddUserGroupDialogShowing = false;
                } else {
                    vmAdHocWorkspaceCtrl.IsHideMainPage = false;
                    vmAdHocWorkspaceCtrl.isAddUserGroupDialogShowing = false;
                    vmAdHocWorkspaceCtrl.NewUserGroupList = [];
                    vmAdHocWorkspaceCtrl.SelectedUserGroup = null;
                    vmAdHocWorkspaceCtrl.UserGroupSearchText = null;
                }
            }

            function customSearchText_Change(metaType) {
                var deffered = $q.defer();
                $('md-virtual-repeat-container.md-autocomplete-suggestions-container.md-whiteframe-z1.md-virtual-repeat-container.md-orient-vertical.ng-hide>div.md-virtual-repeat-scroller').off("scroll");
                autoCompleteListScrollStatus = 0;
                metaDataItemTotalCount = 0;
                customListRequestModel.pagenumber = 1;
                customModelList = [];
                currentSelectedCustomType = metaType;

                var searchText = getSearchText();
                if (searchText.trim().length === 0) {
                    customModelList.push({ IsBeginTypingItem: true, IsMetaItem: false });
                } else {
                    if (isAllowAddNewMetadata(metaType)) {
                        customModelList.push({ IsCreateNewItem: true, IsMetaItem: false });
                    }
                }
                var promise = queryCustomSearch();
                promise.then(function(response) {
                    if (response.length > 0) {
                        customModelList = customModelList.concat(response);
                    }
                    if (customModelList.length > 0) {
                        $timeout(function() {
                            $('md-virtual-repeat-container.md-autocomplete-suggestions-container.md-whiteframe-z1.md-virtual-repeat-container.md-orient-vertical:not(.ng-hide)>div.md-virtual-repeat-scroller').on("scroll", customAutoCompleteList_Scroll);
                            $('md-virtual-repeat-container.md-autocomplete-suggestions-container.md-whiteframe-z1.md-virtual-repeat-container.md-orient-vertical:not(.ng-hide)>div.md-virtual-repeat-scroller').scrollTop(0);
                            autoCompleteListScrollStatus = 1;
                        }, 1000);
                    }
                    deffered.resolve(customModelList);
                }, function(response) {
                    deffered.resolve([]);
                });
                return deffered.promise;
            }

            function customAutoCompleteList_Scroll() {
                var deffered = $q.defer();
                if (autoCompleteListScrollStatus !== 1) {
                    deffered.resolve(customModelList);
                    return deffered.promise;
                }
                var scrollHeight = (($(this).scrollTop() + $(this).innerHeight()) / $(this)[0].scrollHeight) * 100.0;
                if (scrollHeight < 75) {
                    deffered.resolve(customModelList);
                    return deffered.promise;
                }
                if (customModelList.length >= metaDataItemTotalCount) {
                    deffered.resolve(customModelList);
                    return deffered.promise;
                }
                autoCompleteListScrollStatus = 2;
                customListRequestModel.pagenumber += 1;

                var promise = queryCustomSearch();
                promise.then(function(response) {
                    if (response.length > 0) {
                        customModelList = customModelList.concat(response);
                    }
                    autoCompleteListScrollStatus = 1;
                    deffered.resolve(customModelList);
                }, function(response) {
                    autoCompleteListScrollStatus = 1;
                    deffered.resolve(customModelList);
                });
                return deffered.promise;
            }

            function getSearchText() {
                var searchText = '';
                switch (currentSelectedCustomType) {
                    case 'CUSTOM1':
                        searchText = vmAdHocWorkspaceCtrl.SearchCustom1Text;
                        break;

                    case 'CUSTOM2':
                        searchText = vmAdHocWorkspaceCtrl.SearchCustom2Text;
                        break;

                    case 'CUSTOM3':
                        searchText = vmAdHocWorkspaceCtrl.SearchCustom3Text;
                        break;

                    case 'CUSTOM4':
                        searchText = vmAdHocWorkspaceCtrl.SearchCustom4Text;
                        break;

                    case 'CUSTOM5':
                        searchText = vmAdHocWorkspaceCtrl.SearchCustom5Text;
                        break;

                    case 'CUSTOM6':
                        searchText = vmAdHocWorkspaceCtrl.SearchCustom6Text;
                        break;

                    case 'CUSTOM7':
                        searchText = vmAdHocWorkspaceCtrl.SearchCustom7Text;
                        break;

                    case 'CUSTOM8':
                        searchText = vmAdHocWorkspaceCtrl.SearchCustom8Text;
                        break;

                    case 'CUSTOM9':
                        searchText = vmAdHocWorkspaceCtrl.SearchCustom9Text;
                        break;

                    case 'CUSTOM10':
                        searchText = vmAdHocWorkspaceCtrl.SearchCustom10Text;
                        break;

                    case 'CUSTOM11':
                        searchText = vmAdHocWorkspaceCtrl.SearchCustom11Text;
                        break;

                    case 'CUSTOM12':
                        searchText = vmAdHocWorkspaceCtrl.SearchCustom12Text;
                        break;

                    case 'CUSTOM29':
                        searchText = vmAdHocWorkspaceCtrl.SearchCustom29Text;
                        break;

                    case 'CUSTOM30':
                        searchText = vmAdHocWorkspaceCtrl.SearchCustom30Text;
                        break;

                    default:
                        searchText = '';
                }
                if (!searchText) searchText = '';
                return searchText;
            }

            function queryCustomSearch() {
                var deffered = $q.defer();
                var searchAPIUrl = '';

                customListRequestModel.pageLength = 10;
                customListRequestModel.isTotal = true;
                customListRequestModel.searchText = getSearchText();
                customListRequestModel.libraryName = vmAdHocWorkspaceCtrl.SelectedLibrary;

                var metaType = currentSelectedCustomType.toUpperCase();
                if (metaType === 'CUSTOM2') {
                    if (vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom1 == null) {
                        customListRequestModel.MetaType = metaType;
                        searchAPIUrl = adHocWorkspaceFactory.getCustomSearchAPI(customListRequestModel);
                    } else {
                        customListRequestModel.parentAlias = vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom1.Alias;
                        customListRequestModel.MetaType = "CUSTOM1";
                        customListRequestModel.subType = metaType;
                        searchAPIUrl = adHocWorkspaceFactory.getChildCustomSearchAPI(customListRequestModel);
                    }
                } else if (metaType === 'CUSTOM30') {
                    if (vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom29 == null) {
                        customListRequestModel.MetaType = metaType;
                        searchAPIUrl = adHocWorkspaceFactory.getCustomSearchAPI(customListRequestModel);
                    } else {
                        customListRequestModel.parentAlias = vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom29.Alias;
                        customListRequestModel.MetaType = "CUSTOM29";
                        customListRequestModel.subType = metaType;
                        searchAPIUrl = adHocWorkspaceFactory.getChildCustomSearchAPI(customListRequestModel);
                    }
                } else {
                    customListRequestModel.MetaType = metaType;
                    searchAPIUrl = adHocWorkspaceFactory.getCustomSearchAPI(customListRequestModel);
                }
                searchAPIUrl = baseV2Url + searchAPIUrl;

                var promise = homeService.getData(searchAPIUrl);
                promise.then(function(response) {
                    if (response.status === 200 && response.data && response.data.total_count) {
                        metaDataItemTotalCount = response.data.total_count;
                    }
                    if (response.status === 200 && response.data && response.data.data) {
                        $scope.mc.getlogDetails("Success", 'Response:Success');

                        var metaModelList = [];
                        angular.forEach(response.data.data, function(metadata) {
                            var metaDataUIModel = adHocWorkspaceFactory.getMetaDataUI(metadata);
                            if (!vmAdHocWorkspaceCtrl.IsAutoGenerateCustomAlias) {
                                if (metaDataUIModel.Description && metaDataUIModel.Description.trim().length > 0) {
                                    metaDataUIModel.Description = metaDataUIModel.Alias + ' - ' + metaDataUIModel.Description;
                                } else {
                                    metaDataUIModel.Description = metaDataUIModel.Alias;
                                }
                            }
                            metaDataUIModel.IsMetaItem = true;
                            metaModelList.push(metaDataUIModel);
                            metaDataUIModel = null;
                        });
                        deffered.resolve(metaModelList);
                    } else {
                        $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                        deffered.resolve([]);
                    }
                }, function(response) {
                    $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                    deffered.resolve([]);
                });
                return deffered.promise;
            }

            function isIndeterminate(key) {
                return vmAdHocWorkspaceCtrl.adHocWSUIModel[key] === 'inter';
            }

            function isChecked(key) {
                return vmAdHocWorkspaceCtrl.adHocWSUIModel[key] === true;
            }

            function changeValue(key) {
                if (vmAdHocWorkspaceCtrl.adHocWSUIModel[key] === false)
                    vmAdHocWorkspaceCtrl.adHocWSUIModel[key] = 'inter';
                else if (vmAdHocWorkspaceCtrl.adHocWSUIModel[key] === true)
                    vmAdHocWorkspaceCtrl.adHocWSUIModel[key] = false;
                else if (vmAdHocWorkspaceCtrl.adHocWSUIModel[key] === 'inter')
                    vmAdHocWorkspaceCtrl.adHocWSUIModel[key] = true;
            }

            function addAdHocWS() {
                if (!vmAdHocWorkspaceCtrl.SelectedTemplate) {
                    angular.element($('#templateName-container')).trigger("focus");
                    //angular.element($element[0]).find(newRoute.triggerClickTarget).trigger("click");
                    return;
                }

                /*if (!vmAdHocWorkspaceCtrl.adHocWSUIModel.Name && vmAdHocWorkspaceCtrl.adHocWSUIModel.Name.trim().length === 0) {
                    return;
                }*/
                if (($('#numcustom17').val() && isNaN(vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom17)) ||
                    ($('#numcustom18').val() && isNaN(vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom18)) ||
                    ($('#numcustom19').val() && isNaN(vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom19)) ||
                    ($('#numcustom20').val() && isNaN(vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom20))) {
                    return;
                }

                replacehashValues(vmAdHocWorkspaceCtrl.SelectedTemplate.NVPs.IMCC_Template_PrefixSufix_Value).then(function(responsePrefixSuffix) {
                    replacehashValues(vmAdHocWorkspaceCtrl.adHocWSUIModel.Name).then(function(responsewsName) {

                        var wsName = vmAdHocWorkspaceCtrl.adHocWSUIModel.Name;
                        if (responsePrefixSuffix !== null && responsePrefixSuffix !== undefined && responsePrefixSuffix.trim().length > 0) {
                            if (responsePrefixSuffix && responsePrefixSuffix.indexOf(CONST_SYSTEM_CONFIG.PREFIX) == 0 && responsePrefixSuffix.lastIndexOf(CONST_SYSTEM_CONFIG.PREFIX) == responsePrefixSuffix.length - CONST_SYSTEM_CONFIG.PREFIX.length) {
                                var prefixvalue = responsePrefixSuffix.substring(0, responsePrefixSuffix.length - CONST_SYSTEM_CONFIG.PREFIX.length);
                                prefixvalue = prefixvalue.substring(CONST_SYSTEM_CONFIG.PREFIX.length);
                                responsePrefixSuffix = prefixvalue;
                            }
                            var IMCC_WSAllow_Prefix = vmAdHocWorkspaceCtrl.SelectedTemplate.NVPs.IMCC_Template_Allow_Prefix;
                            if (IMCC_WSAllow_Prefix === "1") {
                                wsName += responsePrefixSuffix;
                            } else if (IMCC_WSAllow_Prefix === "0") {
                                wsName = responsePrefixSuffix + wsName;
                            }
                        }
                        if (!wsName && wsName.trim().length === 0) {
                            //$mdDialog.hide();
                            return;
                        }
                        if (wsName)
                            wsName = wsName.substring(0, 254);

                        if (vmAdHocWorkspaceCtrl.adHocWSUIModel.Owner === null || vmAdHocWorkspaceCtrl.adHocWSUIModel.Owner === '') {
                            vmAdHocWorkspaceCtrl.OwnerText = '';
                            return;
                        } else {
                            if (vmAdHocWorkspaceCtrl.adHocWSUIModel.Owner.UserId) {
                                vmAdHocWorkspaceCtrl.adHocWSUIModel.Author = vmAdHocWorkspaceCtrl.adHocWSUIModel.Owner.UserId;
                                vmAdHocWorkspaceCtrl.adHocWSUIModel.Owner = vmAdHocWorkspaceCtrl.adHocWSUIModel.Owner.UserId;
                            }
                        }
                        showProgressDialog('adhocWorkspace.creatingWorkspaceProgressMsg');
                        var deferCategory = $q.defer();
                        if (vmAdHocWorkspaceCtrl.matterCategory.Name && vmAdHocWorkspaceCtrl.matterCategory.Name.length > 0) {
                            var categoryPromise = createMatterCategory();
                            categoryPromise.then(function(response) {
                                deferCategory.resolve();
                            })
                        } else {
                            deferCategory.resolve();
                        }
                        deferCategory.promise.then(function(categoryResponse) {
                            var metadataPromise = saveNewCustomDataUserAdded();
                            metadataPromise.then(function(responseMetadata) {

                                if (responseMetadata.Status !== 0) {
                                    $mdDialog.hide();

                                    if (responseMetadata && responseMetadata.ErrorMsg != null && responseMetadata.ErrorMsg.trim().length > 0) {
                                        showWarningMessage(responseMetadata.ErrorMsg);
                                        return;
                                    }
                                }

                                if (vmAdHocWorkspaceCtrl.SelectedTemplate) {
                                    if (vmAdHocWorkspaceCtrl.SelectedTemplate && vmAdHocWorkspaceCtrl.SelectedTemplate.NVPs && vmAdHocWorkspaceCtrl.SelectedTemplate.NVPs.Actual_Prefix)
                                        vmAdHocWorkspaceCtrl.SelectedTemplate.NVPs.IMCC_Name_Prefix = vmAdHocWorkspaceCtrl.SelectedTemplate.NVPs.Actual_Prefix;

                                    var promiseFolderList = selectedTemplateChange('reset');
                                    promiseFolderList.then(function(responseFolderList) {

                                        replacehashValues(vmAdHocWorkspaceCtrl.adHocWSUIModel.Description).then(function(responsewsDescription) {

                                            vmAdHocWorkspaceCtrl.adHocWSUIModel.Name = responsewsName;
                                            vmAdHocWorkspaceCtrl.adHocWSUIModel.Description = responsewsDescription;

                                            // setAutoGeneratedCustomAlias();
                                            var apiUrl = baseV2Url + adHocWorkspaceFactory.getPostWorkspaceAPI();
                                            $scope.mc.getlogDetails("Debug", 'Requested Api Url:' + JSON.stringify(apiUrl));

                                            var requestBody = adHocWorkspaceFactory.getAdHocWSPostModel(wsName, vmAdHocWorkspaceCtrl.adHocWSUIModel, vmAdHocWorkspaceCtrl.SelectedLibrary);
                                            var promise = homeService.postDataUsingBody(apiUrl, requestBody);
                                            promise.then(function(response) {
                                                    if (response && response.status && response.status === 201) {
                                                        $scope.mc.getlogDetails("Success", 'Workspace created successfully.');
                                                        if (response.data && response.data.data && response.data.data.id && response.data.data.id.trim().length > 0) {
                                                            vmAdHocWorkspaceCtrl.adHocWSUIModel.Id = response.data.data.id;
                                                            vmAdHocWorkspaceCtrl.NewItemsList = response.data.data;
                                                            var deferdArray = [];
                                                            var deferredFolderSecurity = $q.defer();
                                                            deferdArray.push(deferredFolderSecurity.promise);

                                                            changeProgressDialogMessage('adhocWorkspace.saveWorkspaceSecurity')
                                                            var promiseFolderSec = saveFolderSecurity(vmAdHocWorkspaceCtrl.adHocWSUIModel.Id, vmAdHocWorkspaceCtrl.adHocWSUIModel.DefaultSecurity, vmAdHocWorkspaceCtrl.SecurityList);
                                                            promiseFolderSec.then(function(response) {
                                                                deferredFolderSecurity.resolve(response);
                                                            }, function(response) {
                                                                deferredFolderSecurity.resolve({ Status: -1 });
                                                            });

                                                            if (vmAdHocWorkspaceCtrl.AddToOwner === true) {
                                                                var deferredCategory = $q.defer();
                                                                deferdArray.push(deferredCategory.promise);
                                                                var deferredCategoryUrl = $q.defer();
                                                                var categoryUrl = '';
                                                                if (vmAdHocWorkspaceCtrl.AddToOwner && vmAdHocWorkspaceCtrl.adHocWSUIModel.Category && vmAdHocWorkspaceCtrl.adHocWSUIModel.Category.Id && vmAdHocWorkspaceCtrl.adHocWSUIModel.Category.Id.length > 0) {
                                                                    categoryUrl = adHocWorkspaceFactory.getPostWorkspaceToCategoryAPI(vmAdHocWorkspaceCtrl.adHocWSUIModel.Category.Id);
                                                                    deferredCategoryUrl.resolve(categoryUrl);
                                                                } else {
                                                                    categoryUrl = adHocWorkspaceFactory.getPostWorkspaceToCategoryAPI('');
                                                                    deferredCategoryUrl.resolve(categoryUrl);
                                                                }
                                                                deferredCategoryUrl.promise.then(function(Url) {
                                                                    var categoryApiUrl = baseV2Url + Url;
                                                                    var workspaceCategoryRequestBody = {
                                                                        name: response.data.data.name,
                                                                        id: vmAdHocWorkspaceCtrl.adHocWSUIModel.Id

                                                                    }
                                                                    var categoryPostPromise = homeService.postDataUsingBody(categoryApiUrl, workspaceCategoryRequestBody);
                                                                    categoryPostPromise.then(function(response) {
                                                                        deferredCategory.resolve();
                                                                    });
                                                                })
                                                            }

                                                            var deferredFolderStructure = $q.defer();
                                                            deferdArray.push(deferredFolderStructure.promise);
                                                            getAllChildrens(vmAdHocWorkspaceCtrl.foldersList).then(function(responsedata) {
                                                                vmAdHocWorkspaceCtrl.FoldersPreview = responsedata;
                                                                var promiseFolderStructure = createInitailFolderStructures(response.data.data.id, response.data.data.owner)
                                                                promiseFolderStructure.then(function(responseFolderStructure) {
                                                                    deferredFolderStructure.resolve(responseFolderStructure);
                                                                }, function(responseFolderStructure) {
                                                                    deferredFolderStructure.resolve({ Status: -1 });
                                                                });
                                                            });

                                                            $q.all(deferdArray).then(function(responseAll) {
                                                                $mdDialog.hide();
                                                                showRestoreSuccessWindow();
                                                            });
                                                        }
                                                    } else {
                                                        $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                                                        $mdDialog.hide();

                                                        if (response && response.data && response.data.code_message) {
                                                            showWarningMessage(response.data.code_message);
                                                        } else if (response && response.statusText) {
                                                            showWarningMessage(response.statusText);
                                                        }
                                                    }
                                                },
                                                function(response) {
                                                    $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                                                    $mdDialog.hide();
                                                });
                                        });

                                    });
                                }
                            });
                        });

                    });
                });
            }

            function saveFolderSecurity(folderId, folderDefaultSecurity, folderSecurityList) {
                var deferred = $q.defer();
                var requestBody = {
                    include: [],
                    remove: []
                };
                var apiModel = null;

                if (folderDefaultSecurity.toUpperCase() !== 'INHERIT') {
                    angular.forEach(folderSecurityList, function(item) {
                        if (item.AccessLevel !== 'RemoveItem') {
                            apiModel = adHocWorkspaceFactory.getSecurityAPIModel(item);
                            requestBody.include.push(apiModel);
                        }
                    });
                    var apiUrl = baseV2Url + adHocWorkspaceFactory.getFolderSecurityAPI(folderId);
                    $scope.mc.getlogDetails("Debug", 'Requested Api Url:' + JSON.stringify(apiUrl));

                    var promise = homeService.postDataUsingBody(apiUrl, requestBody);
                    promise.then(function(response) {
                        if (response.Status === 200) {
                            $scope.mc.getlogDetails("Success", 'Folder security saved successfully.');
                            deferred.resolve({ Status: 0 });
                        } else {
                            $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                            deferred.resolve({ Status: -1, ErrorMsg: response.code_message });
                        }
                    }, function(response) {
                        $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                        deferred.resolve({ Status: -1 });
                    });
                } else {
                    deferred.resolve({ Status: 0 });
                }
                return deferred.promise;
            }

            function getFolderSecurity(folderId) {
                var deferred = $q.defer();
                var apiUrl = baseV2Url + adHocWorkspaceFactory.getFolderSecurityAPI(folderId);
                $scope.mc.getlogDetails("Debug", 'Requested Api Url:' + JSON.stringify(apiUrl));

                var promise = homeService.getData(apiUrl);
                promise.then(function(response) {

                    if (response.status === 200 && response.data && response.data.data && response.data.data.length > 0) {
                        $scope.mc.getlogDetails("Success", 'Template folder security retrived successfully.');

                        var folderSecurityList = [];
                        angular.forEach(response.data.data, function(item) {
                            var securityUIModel = adHocWorkspaceFactory.getSecurityUIModel(item);
                            folderSecurityList.push(securityUIModel);
                        });
                        deferred.resolve({ Status: 0, SecurityList: folderSecurityList });
                    } else {
                        $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                        deferred.resolve({ Status: -1, ErrorMsg: response.code_message });
                    }
                }, function(response) {
                    $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                    deferred.resolve({ Status: -1 });
                });
                return deferred.promise;
            }

            vmAdHocWorkspaceCtrl.NewMetaData = {
                MetaType: '',
                Alias: '',
                Description: '',
                IsEncrypted: !vmAdHocWorkspaceCtrl.ShowHippafield,
                IsShowAddMetaDataForm: false,
                OpenNewForm: openAddNewMetaDataForm,
                Save_Click: saveNewCustomData,
                Cancel_Click: closeAddNewMetaDataForm
            };

            function openAddNewMetaDataForm(metaType, description) {
                description = vmAdHocWorkspaceCtrl.CustomGlobalValue;
                var txtId = '#txtMetadataAlias';
                if (!vmAdHocWorkspaceCtrl.IsAutoGenerateCustomAlias) {
                    txtId = '#txtMetadataAlias';
                    resizeWindow({ width: '550', height: '360' });
                } else {
                    txtId = '#txtMetadataDescription';
                    resizeWindow({ width: '550', height: '275' });
                }
                vmAdHocWorkspaceCtrl.NewMetaData.MetaType = metaType.toLowerCase();
                vmAdHocWorkspaceCtrl.NewMetaData.Alias = '';
                vmAdHocWorkspaceCtrl.NewMetaData.Description = description;
                vmAdHocWorkspaceCtrl.NewMetaData.IsEncrypted = !vmAdHocWorkspaceCtrl.ShowHippafield;
                vmAdHocWorkspaceCtrl.IsHideMainPage = true;
                vmAdHocWorkspaceCtrl.NewMetaData.IsShowAddMetaDataForm = true;
                $timeout(function() {
                    $(txtId).focus();
                    $(txtId).select();
                }, 500);
            }

            vmAdHocWorkspaceCtrl.matterCategory = {
                Name: '',
                Description: '',
                InheritPermission: false,
                DefaultSecurity: "private",
                openForm: openCreateMatterCategoryForm,
                Back: closeCreateMatterCategoryForm,
                Save: saveMatterCategory,
                onInheritPermissionChange: onInheritPermissionChange
            }

            function onInheritPermissionChange() {
                if (vmAdHocWorkspaceCtrl.matterCategory.InheritPermission) {
                    vmAdHocWorkspaceCtrl.matterCategory.DefaultSecurity = categoryParentSecurity;
                    vmAdHocWorkspaceCtrl.SecurityListWithFilterInMatterCategory = angular.copy(inheritedCategorySecurityList);
                    categorySecurityList = angular.copy(inheritedCategorySecurityList);
                } else {

                }
            }

            function openCreateMatterCategoryForm(matterCategory) {
                vmAdHocWorkspaceCtrl.IsHideMainPage = true;
                vmAdHocWorkspaceCtrl.IsCreateMatterCategoryShowing = true;
                vmAdHocWorkspaceCtrl.IsCreateMatterCategoryActive = true;
                resizeWindow({ width: '550', height: '560' });
                vmAdHocWorkspaceCtrl.matterCategory.Name = matterCategory;
                vmAdHocWorkspaceCtrl.matterCategory.Description = '';
                vmAdHocWorkspaceCtrl.matterCategory.InheritPermission = true;
                vmAdHocWorkspaceCtrl.matterCategory.DefaultSecurity = 'private';
                vmAdHocWorkspaceCtrl.addUserGroupListToCategory = [];
                vmAdHocWorkspaceCtrl.SecurityListWithFilterInMatterCategory = [];
                vmAdHocWorkspaceCtrl.CategoryText = '';
                category_parent_id = '';

                var meApiUrl = baseV2Url + homeFactory.getSingleUserAPI();
                $scope.mc.getlogDetails("Debug", 'Requested Api Url:' + JSON.stringify(meApiUrl));

                var promise = homeService.getData(meApiUrl);
                promise.then(function(response) {
                        if (response && response.data && response.data.data) {
                            category_parent_id = response.data.data.my_matter_id;

                            var apiUrl = baseV2Url + adHocWorkspaceFactory.getMatterCategorySecurityAPI(category_parent_id);
                            $scope.mc.getlogDetails("Debug", 'Requested Api Url:' + JSON.stringify(apiUrl));

                            var promiseSecurity = homeService.getData(apiUrl);
                            promiseSecurity.then(function(responseSecurity) {
                                categorySecurityList = [];
                                inheritedCategorySecurityList = [];
                                if (responseSecurity && responseSecurity.data && responseSecurity.data.data) {
                                    var categorySecurityObj = adHocWorkspaceFactory.getCategorySecurtyModelList(responseSecurity.data);

                                    var differedPhotoList = [];
                                    angular.forEach(categorySecurityObj.Security, function(category) {
                                        var promisePhoto = getUserPhoto(category);
                                        differedPhotoList.push(promisePhoto);
                                    });
                                    $q.all(differedPhotoList).then(function(response) {
                                        inheritedCategorySecurityList = angular.copy(categorySecurityObj.Security);
                                        categorySecurityList = angular.copy(categorySecurityObj.Security);
                                        categoryParentSecurity = categorySecurityObj.DefaultSecurity;
                                        onInheritPermissionChange();
                                    });
                                }
                            });
                        }
                    },
                    function(response) {
                        $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                    });
                $timeout(function() {
                    $('#txtMatterCategoryName').focus();
                }, 500);
            }

            function closeAddNewMetaDataForm(newMetadataModel) {
                if (newMetadataModel && vmAdHocWorkspaceCtrl.IsAutoGenerateCustomAlias === false) {
                    if (newMetadataModel.Description == null || newMetadataModel.Description.trim().length === 0) {
                        newMetadataModel.Description = newMetadataModel.Alias;
                    } else {
                        newMetadataModel.Description = newMetadataModel.Alias + ' - ' + newMetadataModel.Description;
                    }
                }
                setNewCustomToAutoCompleteModel(newMetadataModel);
                resizeWindow({ width: '550', height: '700' });
                vmAdHocWorkspaceCtrl.IsHideMainPage = false;
                vmAdHocWorkspaceCtrl.NewMetaData.IsShowAddMetaDataForm = false;
                vmAdHocWorkspaceCtrl.NewMetaData.MetaType = '';
                vmAdHocWorkspaceCtrl.NewMetaData.Alias = '';
                vmAdHocWorkspaceCtrl.NewMetaData.Description = '';
                vmAdHocWorkspaceCtrl.NewMetaData.IsEncrypted = false;
            }

            function closeCreateMatterCategoryForm() {
                resizeWindow({ width: '550', height: '700' });
                vmAdHocWorkspaceCtrl.matterCategory.Name = '';
                vmAdHocWorkspaceCtrl.matterCategory.Description = '';
                vmAdHocWorkspaceCtrl.matterCategory.InheritPermission = true;
                vmAdHocWorkspaceCtrl.matterCategory.DefaultSecurity = 'private';
                vmAdHocWorkspaceCtrl.addUserGroupListToCategory = [];
                vmAdHocWorkspaceCtrl.SecurityListWithFilterInMatterCategory = [];
                vmAdHocWorkspaceCtrl.CategoryText = '';
                vmAdHocWorkspaceCtrl.IsHideMainPage = false;
                vmAdHocWorkspaceCtrl.IsCreateMatterCategoryShowing = false;
            }

            function saveMatterCategory() {
                vmAdHocWorkspaceCtrl.CategoryText = vmAdHocWorkspaceCtrl.matterCategory.Name;
                vmAdHocWorkspaceCtrl.IsHideMainPage = false;
                vmAdHocWorkspaceCtrl.IsCreateMatterCategoryShowing = false;
                vmAdHocWorkspaceCtrl.IsCreateMatterCategoryActive = false;
            }

            function createMatterCategory() {
                var defferedMaster = $q.defer();
                if (vmAdHocWorkspaceCtrl.matterCategory.Name == null || vmAdHocWorkspaceCtrl.matterCategory.Name == undefined || vmAdHocWorkspaceCtrl.matterCategory.Name.length == 0) {
                    defferedMaster.resolve({ status: -1 });
                    return;
                }

                // var meApiUrl = adHocWorkspaceFactory.getMeAPI();
                // $scope.mc.getlogDetails("Debug", 'Requested Api Url:' + JSON.stringify(meApiUrl));

                // var promise = homeService.getData(meApiUrl);
                // promise.then(function (response) {
                //     var matter_id = '';
                //     if (response && response.data && response.data.data) {
                //         matter_id = response.data.data.my_matter_id;
                //     }

                var postMatterCategoryApiUrl = baseV2Url + adHocWorkspaceFactory.postMatterCategoryAPI(category_parent_id);
                $scope.mc.getlogDetails("Debug", 'Requested Api Url:' + JSON.stringify(postMatterCategoryApiUrl));

                var requestBody = adHocWorkspaceFactory.getMatterCategoryPostModel(vmAdHocWorkspaceCtrl.matterCategory, vmAdHocWorkspaceCtrl.SelectedLibrary);
                var postPromise = homeService.postDataUsingBody(postMatterCategoryApiUrl, requestBody);
                postPromise.then(function(postResponse) {
                        if (postResponse && postResponse.status && postResponse.status === 201) {
                            var differedSecurity = $q.defer();
                            if (!vmAdHocWorkspaceCtrl.matterCategory.InheritPermission) {
                                var securityListTempObject = $.grep(vmAdHocWorkspaceCtrl.SecurityListWithFilterInMatterCategory,
                                    function(item, index) {
                                        return item.AccessLevel !== 'RemoveItem';
                                    });
                                var securityListObject = [];
                                angular.forEach(securityListTempObject, function(securityItem) {
                                    var security = {
                                        "access_level": securityItem.AccessLevel,
                                        "id": securityItem.Id,
                                        "type": securityItem.Type
                                    }
                                    securityListObject.push(security);
                                });
                                var securityPostBody = {
                                    "include": securityListObject
                                }

                                var securityApiUrl = baseV2Url + adHocWorkspaceFactory.getMatterCategorySecurityAPI(postResponse.data.data.id);
                                var postSecurityPromise = homeService.postDataUsingBody(securityApiUrl, securityPostBody);
                                postSecurityPromise.then(function(postSecurityResponse) {
                                    differedSecurity.resolve();
                                });
                            } else {
                                differedSecurity.resolve();
                            }

                            differedSecurity.promise.then(function(response) {
                                $scope.mc.getlogDetails("Success", 'Matter category created successfully.');
                                defferedMaster.resolve({ status: 1 });
                                // vmAdHocWorkspaceCtrl.IsHideMainPage = false;
                                // vmAdHocWorkspaceCtrl.IsCreateMatterCategoryShowing = false;
                                // vmAdHocWorkspaceCtrl.IsCreateMatterCategoryActive = false;
                                vmAdHocWorkspaceCtrl.adHocWSUIModel.Category = adHocWorkspaceFactory.getMatterCategoryUIModel(postResponse.data.data);
                            });
                        } else {
                            $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(postResponse));
                            defferedMaster.resolve({ status: -1 });
                        }
                    },
                    function(postResponse) {
                        $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(postResponse));
                        defferedMaster.resolve({ status: -1 });
                    });
                return defferedMaster.promise;
                // },
                // function(response) {
                //     $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                // });
            }

            function getMetaParentAlias(metaType) {
                var parentAlias = '';
                switch (metaType.toUpperCase()) {
                    case 'CUSTOM2':
                        parentAlias = vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom1.Alias;
                        break;

                    case 'CUSTOM30':
                        parentAlias = vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom29.Alias;
                        break;

                    default:
                        parentAlias = '';
                }
                return parentAlias;
            }

            function setNewAutoGenerateAlias(metadataUIModel) {
                var deferred = $q.defer();
                if (!vmAdHocWorkspaceCtrl.IsAutoGenerateCustomAlias || metadataUIModel == null) {
                    deferred.resolve({ Status: 0, ErrorMsg: '' });
                    return deferred.promise;
                }
                metadataUIModel.AutoGeneratedAlias = '';

                var aliasPromise = getNewAutoGeneratedCustomAlias(metadataUIModel.MetaType);
                aliasPromise.then(function(response) {
                    if (response.AutoGeneratedAlias != null && response.AutoGeneratedAlias.trim().length > 0) {
                        metadataUIModel.AutoGeneratedAlias = response.AutoGeneratedAlias;
                        deferred.resolve({ Status: 0, ErrorMsg: '' });
                    } else {
                        deferred.resolve({ Status: -1, ErrorMsg: '' });
                    }
                });
                return deferred.promise;
            }

            function saveNewCustomDataUserAdded() {
                var deferred = $q.defer();
                var defferedarray = [];

                if (vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom1 != null) {
                    var itemDeferred = $q.defer();
                    defferedarray.push(itemDeferred.promise);

                    var custom1Promise = postNewCustomData(angular.copy(vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom1));
                    custom1Promise.then(function(responseCustom1) {
                        if (responseCustom1.SavedItemModel != null)
                            vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom1 = angular.copy(responseCustom1.SavedItemModel);

                        if (responseCustom1.Status === 0) {
                            var itemDeferred2 = $q.defer();
                            defferedarray.push(itemDeferred2.promise);

                            var custom2Promise = postNewCustomData(angular.copy(vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom2));
                            custom2Promise.then(function(responseCustom2) {
                                if (responseCustom2.Status === 0 && responseCustom2.SavedItemModel != null) {
                                    vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom2 = angular.copy(responseCustom2.SavedItemModel);
                                }
                                itemDeferred2.resolve({ Status: responseCustom2.Status, ErrorMsg: responseCustom2.ErrorMsg });
                                itemDeferred.resolve({ Status: responseCustom1.Status, ErrorMsg: responseCustom1.ErrorMsg });
                            });
                        } else {
                            itemDeferred.resolve({ Status: responseCustom1.Status, ErrorMsg: responseCustom1.ErrorMsg });
                        }
                    });
                }
                if (vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom12 != null) {
                    var itemDeferred12 = $q.defer();
                    defferedarray.push(itemDeferred12.promise);

                    var custom12Promise = postNewCustomData(angular.copy(vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom12));
                    custom12Promise.then(function(responseCustom12) {
                        if (responseCustom12.Status === 0 && responseCustom12.SavedItemModel != null) {
                            vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom12 = angular.copy(responseCustom12.SavedItemModel);
                        }
                        itemDeferred12.resolve({ Status: responseCustom12.Status, ErrorMsg: responseCustom12.ErrorMsg });
                    });
                }
                if (vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom11 != null) {
                    var itemDeferred11 = $q.defer();
                    defferedarray.push(itemDeferred11.promise);

                    var custom11Promise = postNewCustomData(angular.copy(vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom11));
                    custom11Promise.then(function(responseCustom11) {
                        if (responseCustom11.Status === 0 && responseCustom11.SavedItemModel != null) {
                            vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom11 = angular.copy(responseCustom11.SavedItemModel);
                        }
                        itemDeferred11.resolve({ Status: responseCustom11.Status, ErrorMsg: responseCustom11.ErrorMsg });
                    });
                }
                if (vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom10 != null) {
                    var itemDeferred10 = $q.defer();
                    defferedarray.push(itemDeferred10.promise);

                    var custom10Promise = postNewCustomData(angular.copy(vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom10));
                    custom10Promise.then(function(responseCustom10) {
                        if (responseCustom10.Status === 0 && responseCustom10.SavedItemModel != null) {
                            vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom10 = angular.copy(responseCustom10.SavedItemModel);
                        }
                        itemDeferred10.resolve({ Status: responseCustom10.Status, ErrorMsg: responseCustom10.ErrorMsg });
                    });
                }
                if (vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom9 != null) {
                    var itemDeferred9 = $q.defer();
                    defferedarray.push(itemDeferred9.promise);

                    var custom9Promise = postNewCustomData(angular.copy(vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom9));
                    custom9Promise.then(function(responseCustom9) {
                        if (responseCustom9.Status === 0 && responseCustom9.SavedItemModel != null) {
                            vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom9 = angular.copy(responseCustom9.SavedItemModel);
                        }
                        itemDeferred9.resolve({ Status: responseCustom9.Status, ErrorMsg: responseCustom9.ErrorMsg });
                    });
                }
                if (vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom8 != null) {
                    var itemDeferred8 = $q.defer();
                    defferedarray.push(itemDeferred8.promise);

                    var custom8Promise = postNewCustomData(angular.copy(vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom8));
                    custom8Promise.then(function(responseCustom8) {
                        if (responseCustom8.Status === 0 && responseCustom8.SavedItemModel != null) {
                            vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom8 = angular.copy(responseCustom8.SavedItemModel);
                        }
                        itemDeferred8.resolve({ Status: responseCustom8.Status, ErrorMsg: responseCustom8.ErrorMsg });
                    });
                }
                if (vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom7 != null) {
                    var itemDeferred7 = $q.defer();
                    defferedarray.push(itemDeferred7.promise);

                    var custom7Promise = postNewCustomData(angular.copy(vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom7));
                    custom7Promise.then(function(responseCustom7) {
                        if (responseCustom7.Status === 0 && responseCustom7.SavedItemModel != null) {
                            vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom7 = angular.copy(responseCustom7.SavedItemModel);
                        }
                        itemDeferred7.resolve({ Status: responseCustom7.Status, ErrorMsg: responseCustom7.ErrorMsg });
                    });
                }
                if (vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom6 != null) {
                    var itemDeferred6 = $q.defer();
                    defferedarray.push(itemDeferred6.promise);

                    var custom6Promise = postNewCustomData(angular.copy(vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom6));
                    custom6Promise.then(function(responseCustom6) {
                        if (responseCustom6.Status === 0 && responseCustom6.SavedItemModel != null) {
                            vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom6 = angular.copy(responseCustom6.SavedItemModel);
                        }
                        itemDeferred6.resolve({ Status: responseCustom6.Status, ErrorMsg: responseCustom6.ErrorMsg });
                    });
                }
                if (vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom5 != null) {
                    var itemDeferred5 = $q.defer();
                    defferedarray.push(itemDeferred5.promise);

                    var custom5Promise = postNewCustomData(angular.copy(vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom5));
                    custom5Promise.then(function(responseCustom5) {
                        if (responseCustom5.Status === 0 && responseCustom5.SavedItemModel != null) {
                            vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom5 = angular.copy(responseCustom5.SavedItemModel);
                        }
                        itemDeferred5.resolve({ Status: responseCustom5.Status, ErrorMsg: responseCustom5.ErrorMsg });
                    });
                }
                if (vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom4 != null) {
                    var itemDeferred4 = $q.defer();
                    defferedarray.push(itemDeferred4.promise);

                    var custom4Promise = postNewCustomData(angular.copy(vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom4));
                    custom4Promise.then(function(responseCustom4) {
                        if (responseCustom4.Status === 0 && responseCustom4.SavedItemModel != null) {
                            vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom4 = angular.copy(responseCustom4.SavedItemModel);
                        }
                        itemDeferred4.resolve({ Status: responseCustom4.Status, ErrorMsg: responseCustom4.ErrorMsg });
                    });
                }
                if (vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom3 != null) {
                    var itemDeferred3 = $q.defer();
                    defferedarray.push(itemDeferred3.promise);

                    var custom3Promise = postNewCustomData(angular.copy(vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom3));
                    custom3Promise.then(function(responseCustom3) {
                        if (responseCustom3.Status === 0 && responseCustom3.SavedItemModel != null) {
                            vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom3 = angular.copy(responseCustom3.SavedItemModel);
                        }
                        itemDeferred3.resolve({ Status: responseCustom3.Status, ErrorMsg: responseCustom3.ErrorMsg });
                    });
                }

                if (vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom29 != null) {
                    var item29Deferred = $q.defer();
                    defferedarray.push(item29Deferred.promise);

                    var custom29Promise = postNewCustomData(angular.copy(vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom29));
                    custom29Promise.then(function(responseCustom29) {
                        if (responseCustom29.SavedItemModel != null) {
                            vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom29 = angular.copy(responseCustom29.SavedItemModel);
                        }
                        if (responseCustom29.Status === 0) {
                            var itemDeferred30 = $q.defer();
                            defferedarray.push(itemDeferred30.promise);

                            var custom30Promise = postNewCustomData(angular.copy(vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom30));
                            custom30Promise.then(function(responseCustom30) {
                                if (responseCustom30.Status === 0 && responseCustom30.SavedItemModel != null) {
                                    vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom30 = angular.copy(responseCustom30.SavedItemModel);
                                }
                                itemDeferred30.resolve({ Status: responseCustom30.Status, ErrorMsg: responseCustom30.ErrorMsg });
                                item29Deferred.resolve({ Status: responseCustom29.Status, ErrorMsg: responseCustom29.ErrorMsg });
                            });
                        } else {
                            item29Deferred.resolve({ Status: responseCustom29.Status, ErrorMsg: responseCustom29.ErrorMsg });
                        }
                    });
                }
                $q.all(defferedarray).then(function(response) {
                    var status = 0;
                    var errorMsg = '';
                    var defferedSavedArray = [];

                    angular.forEach(response, function(responseModel) {
                        if (responseModel.Status !== 0 && responseModel.ErrorMsg != null && responseModel.ErrorMsg.trim().length > 0) {
                            status = responseModel.Status;
                            if (errorMsg != null && errorMsg.trim().length === 0)
                                errorMsg = responseModel.ErrorMsg;
                            itemDeferred.resolve({ Status: -1 });
                        }
                    });
                    deferred.resolve({ Status: status, ErrorMsg: errorMsg });
                });
                return deferred.promise;
            }

            function postNewCustomData(metadataUIModel) {
                var deferred = $q.defer();
                if (metadataUIModel == null || metadataUIModel.IsItemCreated === true) {
                    deferred.resolve({ Status: 0, ErrorMsg: '', SavedItemModel: null });
                    return deferred.promise;
                }
                var promiseAliasCreate = setNewAutoGenerateAlias(metadataUIModel);
                promiseAliasCreate.then(function(response) {
                    if (vmAdHocWorkspaceCtrl.ShowHippafield === false)
                        metadataUIModel.HIPAAComplaint = true;
                    metadataUIModel.ParentAlias = getMetaParentAlias(metadataUIModel.MetaType);

                    var apiUrl = baseV2Url + adHocWorkspaceFactory.getPostMetaDataAPI(metadataUIModel.MetaType);
                    var apiModel = adHocWorkspaceFactory.getMetaAPIPOSTModel(metadataUIModel, vmAdHocWorkspaceCtrl.SelectedLibrary, vmAdHocWorkspaceCtrl.IsAutoGenerateCustomAlias);
                    $scope.mc.getlogDetails("Debug", 'Method:POST;URL:' + JSON.stringify(apiUrl) + 'Request Body:' + JSON.stringify(apiModel));

                    var promise = homeService.postDataUsingBody(apiUrl, apiModel);
                    promise.then(function(response) {
                        if (response && response.status === 200) {
                            $scope.mc.getlogDetails("Success", metadataUIModel.MetaType + ' created successfully.');

                            var newSavedMetadataUIModel = adHocWorkspaceFactory.getMetaUIModelInitialValue();
                            newSavedMetadataUIModel.EnableFlag = true;
                            newSavedMetadataUIModel.IsMetaItem = true;
                            newSavedMetadataUIModel.IsItemCreated = true;
                            newSavedMetadataUIModel.AutoGeneratedAlias = '';
                            newSavedMetadataUIModel.Alias = ''
                            newSavedMetadataUIModel.Description = metadataUIModel.DescriptionWithoutAlias;
                            newSavedMetadataUIModel.HIPAAComplaint = metadataUIModel.HIPAAComplaint;
                            newSavedMetadataUIModel.MetaType = metadataUIModel.MetaType.toUpperCase();
                            newSavedMetadataUIModel.ParentAlias = metadataUIModel.ParentAlias;

                            if (!vmAdHocWorkspaceCtrl.IsAutoGenerateCustomAlias) {
                                newSavedMetadataUIModel.Alias = metadataUIModel.Alias;
                                if (newSavedMetadataUIModel.Description && newSavedMetadataUIModel.Description.trim().length > 0) {
                                    newSavedMetadataUIModel.Description = newSavedMetadataUIModel.Alias + ' - ' + newSavedMetadataUIModel.Description;
                                } else {
                                    newSavedMetadataUIModel.Description = newSavedMetadataUIModel.Alias;
                                }
                            } else {
                                newSavedMetadataUIModel.Alias = metadataUIModel.AutoGeneratedAlias;
                            }
                            deferred.resolve({ Status: 0, ErrorMsg: '', SavedItemModel: newSavedMetadataUIModel });
                        } else {
                            $scope.mc.getlogDetails("Info", 'Failure');
                            var errorMesssage = '';
                            if (response && response.data && response.data.details && response.data.details.message)
                                errorMesssage = response.data.details.message;
                            else if (response && response.data && response.data.error && response.data.error.message)
                                errorMesssage = response.data.error.message;
                            else
                                errorMesssage = "Custom metadata creation failed";
                            deferred.resolve({ Status: -1, ErrorMsg: errorMesssage, SavedItemModel: null });
                        }
                    }, function(response) {
                        var errorMesssage = '';
                        $mdDialog.hide();
                        if (response && response.data && response.data.details && response.data.details.message)
                            errorMesssage = response.data.details.message;
                        else if (response && response.data && response.data.error && response.data.error.message)
                            errorMesssage = response.data.error.message;
                        else
                            errorMesssage = "Custom metadata creation failed";
                        deferred.resolve({ Status: -1, ErrorMsg: errorMesssage, SavedItemModel: null });
                    });
                });
                return deferred.promise;
            }

            function saveNewCustomData() {
                if (vmAdHocWorkspaceCtrl.IsAutoGenerateCustomAlias) {
                    if (vmAdHocWorkspaceCtrl.NewMetaData.Description == null || vmAdHocWorkspaceCtrl.NewMetaData.Description.trim().length === 0)
                        return;

                    var metaUIModelTemp = adHocWorkspaceFactory.getMetaUIModelInitialValue();
                    metaUIModelTemp.EnableFlag = true;
                    metaUIModelTemp.IsMetaItem = true;
                    metaUIModelTemp.AutoGeneratedAlias = '';
                    metaUIModelTemp.MetaType = vmAdHocWorkspaceCtrl.NewMetaData.MetaType.toUpperCase();
                    metaUIModelTemp.Alias = (0 - parseInt(metaUIModelTemp.MetaType.substr('CUSTOM'.length))).toString();
                    metaUIModelTemp.Description = vmAdHocWorkspaceCtrl.NewMetaData.Description;
                    metaUIModelTemp.DescriptionWithoutAlias = vmAdHocWorkspaceCtrl.NewMetaData.Description;
                    metaUIModelTemp.HIPAAComplaint = vmAdHocWorkspaceCtrl.NewMetaData.IsEncrypted;
                    metaUIModelTemp.ParentAlias = getMetaParentAlias(metaUIModelTemp.MetaType);

                    closeAddNewMetaDataForm(angular.copy(metaUIModelTemp));
                    metaUIModelTemp = null;
                } else {
                    if (vmAdHocWorkspaceCtrl.NewMetaData.Alias == null || vmAdHocWorkspaceCtrl.NewMetaData.Alias.trim().length === 0)
                        return;

                    showProgressDialog();
                    var checkPromise = checkMetaDataAlreadyExists(vmAdHocWorkspaceCtrl.NewMetaData.MetaType, vmAdHocWorkspaceCtrl.NewMetaData.Alias);
                    checkPromise.then(function(response) {
                        if (response.Status !== 0) {
                            $mdDialog.hide();
                            var captionAlias = vmAdHocWorkspaceCtrl.NewMetaData.MetaType.toUpperCase();
                            var capList = $filter('filter')($scope.CaptionsList, {
                                MetaDataItem: vmAdHocWorkspaceCtrl.NewMetaData.MetaType.toUpperCase()
                            }, true);
                            if (capList != null && capList.length > 0) {
                                captionAlias = capList[0].DisplayText;
                            }
                            showWarningMessage(captionAlias + ' already found.');
                            return;
                        } else if (response.Status === 0) {
                            var metaUIModelTemp = adHocWorkspaceFactory.getMetaUIModelInitialValue();
                            metaUIModelTemp.EnableFlag = true;
                            metaUIModelTemp.IsMetaItem = true;
                            metaUIModelTemp.AutoGeneratedAlias = '';
                            metaUIModelTemp.MetaType = vmAdHocWorkspaceCtrl.NewMetaData.MetaType.toUpperCase();
                            metaUIModelTemp.Alias = vmAdHocWorkspaceCtrl.NewMetaData.Alias;
                            metaUIModelTemp.Description = vmAdHocWorkspaceCtrl.NewMetaData.Description;
                            metaUIModelTemp.DescriptionWithoutAlias = vmAdHocWorkspaceCtrl.NewMetaData.Description;
                            metaUIModelTemp.HIPAAComplaint = vmAdHocWorkspaceCtrl.NewMetaData.IsEncrypted;
                            metaUIModelTemp.ParentAlias = getMetaParentAlias(metaUIModelTemp.MetaType);

                            closeAddNewMetaDataForm(angular.copy(metaUIModelTemp));
                            metaUIModelTemp = null;
                            $mdDialog.hide();
                        }
                    }, function(response) {});
                }
            }

            function checkMetaDataAlreadyExists(metaType, customAlias) {
                var deffered = $q.defer();
                var searchAPIUrl = '';

                var requestModel = {
                    MetaType: metaType,
                    Alias: customAlias.toLowerCase(),
                    Database: vmAdHocWorkspaceCtrl.SelectedLibrary
                };
                if (requestModel.MetaType.toUpperCase() === 'CUSTOM2' || requestModel.MetaType.toUpperCase() === 'CUSTOM30') {
                    requestModel.ParentType = requestModel.MetaType.toUpperCase() === 'CUSTOM2' ? 'CUSTOM1' : 'CUSTOM29';

                    requestModel.ParentAlias = getMetaParentAlias(requestModel.MetaType);
                    searchAPIUrl = adHocWorkspaceFactory.getChildCustomExistsAPI(requestModel);
                } else {
                    searchAPIUrl = adHocWorkspaceFactory.getCustomExistsAPI(requestModel);
                }
                searchAPIUrl = baseV2Url + searchAPIUrl;
                var promise = homeService.getData(searchAPIUrl);
                promise.then(function(response) {
                    var searchedItem = [];
                    requestModel.Alias = requestModel.Alias.toUpperCase();
                    if (response != null && response.status === 200 && response.data && response.data.data && response.data.data.length > 0) {
                        searchedItem = response.data.data.filter(function(i) {
                            return i.id === requestModel.Alias;
                        });
                    }
                    if (searchedItem.length > 0) {
                        deffered.resolve({ Status: -1 });
                    } else {
                        $scope.mc.getlogDetails("Info", 'Response:' + JSON.stringify(response));
                        deffered.resolve({ Status: 0 });
                    }
                }, function(response) {
                    $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                    deffered.resolve({ Status: 0 });
                });
                return deffered.promise;
            }

            function setNewCustomToAutoCompleteModel(newItem) {
                var customItemFound = true;
                switch (vmAdHocWorkspaceCtrl.NewMetaData.MetaType.toUpperCase()) {
                    case 'CUSTOM1':
                        if (!newItem) {
                            vmAdHocWorkspaceCtrl.SearchCustom1Text = '';
                            vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom1 = null;
                        } else {
                            vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom1 = angular.copy(newItem);
                        }
                        break;

                    case 'CUSTOM2':
                        if (!newItem) {
                            vmAdHocWorkspaceCtrl.SearchCustom2Text = '';
                            vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom2 = null;
                        } else {
                            vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom2 = angular.copy(newItem);
                        }
                        break;

                    case 'CUSTOM3':
                        if (!newItem) {
                            vmAdHocWorkspaceCtrl.SearchCustom3Text = '';
                            vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom3 = null;
                        } else {
                            vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom3 = angular.copy(newItem);
                        }
                        break;

                    case 'CUSTOM4':
                        if (!newItem) {
                            vmAdHocWorkspaceCtrl.SearchCustom4Text = '';
                            vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom4 = null;
                        } else {
                            vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom4 = angular.copy(newItem);
                        }
                        break;

                    case 'CUSTOM5':
                        if (!newItem) {
                            vmAdHocWorkspaceCtrl.SearchCustom5Text = '';
                            vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom5 = null;
                        } else {
                            vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom5 = angular.copy(newItem);
                        }
                        break;

                    case 'CUSTOM6':
                        if (!newItem) {
                            vmAdHocWorkspaceCtrl.SearchCustom6Text = '';
                            vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom6 = null;
                        } else {
                            vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom6 = angular.copy(newItem);
                        }
                        break;

                    case 'CUSTOM7':
                        if (!newItem) {
                            vmAdHocWorkspaceCtrl.SearchCustom7Text = '';
                            vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom7 = null;
                        } else {
                            vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom7 = angular.copy(newItem);
                        }
                        break;

                    case 'CUSTOM8':
                        if (!newItem) {
                            vmAdHocWorkspaceCtrl.SearchCustom8Text = '';
                            vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom8 = null;
                        } else {
                            vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom8 = angular.copy(newItem);
                        }
                        break;

                    case 'CUSTOM9':
                        if (!newItem) {
                            vmAdHocWorkspaceCtrl.SearchCustom9Text = '';
                            vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom9 = null;
                        } else {
                            vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom9 = angular.copy(newItem);
                        }
                        break;

                    case 'CUSTOM10':
                        if (!newItem) {
                            vmAdHocWorkspaceCtrl.SearchCustom10Text = '';
                            vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom10 = null;
                        } else {
                            vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom10 = angular.copy(newItem);
                        }
                        break;

                    case 'CUSTOM11':
                        if (!newItem) {
                            vmAdHocWorkspaceCtrl.SearchCustom11Text = '';
                            vmAdHocWorkspaceCtrl.SelectedCustom11Item = null;
                        } else {
                            vmAdHocWorkspaceCtrl.SelectedCustom11Item = angular.copy(newItem);
                        }
                        break;

                    case 'CUSTOM12':
                        if (!newItem) {
                            vmAdHocWorkspaceCtrl.SearchCustom12Text = '';
                            vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom12 = null;
                        } else {
                            vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom12 = angular.copy(newItem);
                        }
                        break;

                    case 'CUSTOM29':
                        if (!newItem) {
                            vmAdHocWorkspaceCtrl.SearchCustom29Text = '';
                            vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom29 = null;
                        } else {
                            vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom29 = angular.copy(newItem);
                        }
                        break;

                    case 'CUSTOM30':
                        if (!newItem) {
                            vmAdHocWorkspaceCtrl.SearchCustom30Text = '';
                            vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom30 = null;
                        } else {
                            vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom30 = angular.copy(newItem);
                        }
                        break;

                    default:
                        customItemFound = false;
                        break;
                }
                if (customItemFound && newItem) {
                    customModelList.push(newItem);
                }
            }

            function autoCompleteSelectedItem_Change(metaType) {
                switch (metaType.toUpperCase()) {
                    case 'CUSTOM1':

                        if (templateChanged && vmAdHocWorkspaceCtrl.MatchField[1] == 'custom2') {
                            templateChanged = false;
                        } else {
                            vmAdHocWorkspaceCtrl.SearchCustom2Text = '';
                            vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom2 = null;
                        }
                        break;
                    case 'CUSTOM29':
                        if (templateChanged && vmAdHocWorkspaceCtrl.MatchField[1] == 'custom30') {

                            templateChanged = false;
                        } else {
                            vmAdHocWorkspaceCtrl.SearchCustom30Text = '';
                            vmAdHocWorkspaceCtrl.adHocWSUIModel.Custom30 = null;
                        }
                        break;

                }
            }

            function subClassSearchText_Change() {
                var deffered = $q.defer();
                $('md-virtual-repeat-container.md-autocomplete-suggestions-container.md-whiteframe-z1.md-virtual-repeat-container.md-orient-vertical.ng-hide>div.md-virtual-repeat-scroller').off("scroll");
                autoCompleteListScrollStatus = 0;
                metaDataItemTotalCount = 0;
                customListRequestModel.pagenumber = 1;
                customListRequestModel.MetaType = null;
                customListRequestModel.subType = null;
                customModelList = [];
                currentSelectedCustomType = '';

                if (vmAdHocWorkspaceCtrl.SubClassSearchText.trim().length === 0) {
                    customModelList.push({ IsBeginTypingItem: true, IsSubClassItem: false });
                }
                var promise = querySubClassSearch();
                promise.then(function(response) {
                    if (response.length > 0) {
                        customModelList = customModelList.concat(response);
                        $timeout(function() {
                            $('md-virtual-repeat-container.md-autocomplete-suggestions-container.md-whiteframe-z1.md-virtual-repeat-container.md-orient-vertical:not(.ng-hide)>div.md-virtual-repeat-scroller').on("scroll", subClassAutoCompleteList_Scroll);
                            $('md-virtual-repeat-container.md-autocomplete-suggestions-container.md-whiteframe-z1.md-virtual-repeat-container.md-orient-vertical:not(.ng-hide)>div.md-virtual-repeat-scroller').scrollTop(0);
                            autoCompleteListScrollStatus = 1;
                        }, 1000);
                    }
                    deffered.resolve(customModelList);
                }, function(response) {
                    deffered.resolve([]);
                });
                return deffered.promise;
            }

            function subClassAutoCompleteList_Scroll() {
                var deffered = $q.defer();
                if (autoCompleteListScrollStatus !== 1) {
                    deffered.resolve(customModelList);
                    return deffered.promise;
                }
                var scrollHeight = (($(this).scrollTop() + $(this).innerHeight()) / $(this)[0].scrollHeight) * 100.0;
                if (scrollHeight < 75) {
                    deffered.resolve(customModelList);
                    return deffered.promise;
                }
                if (customModelList.length >= metaDataItemTotalCount) {
                    deffered.resolve(customModelList);
                    return deffered.promise;
                }
                autoCompleteListScrollStatus = 2;
                customListRequestModel.pagenumber += 1;

                var promise = querySubClassSearch();
                promise.then(function(response) {
                    if (response.length > 0) {
                        customModelList = customModelList.concat(response);
                    }
                    autoCompleteListScrollStatus = 1;
                    deffered.resolve(customModelList);
                }, function(response) {
                    autoCompleteListScrollStatus = 1;
                    deffered.resolve(customModelList);
                });
                return deffered.promise;
            }

            function querySubClassSearch() {
                var deffered = $q.defer();

                customListRequestModel.pageLength = 10;
                customListRequestModel.isTotal = true;
                customListRequestModel.searchText = vmAdHocWorkspaceCtrl.SubClassSearchText;
                customListRequestModel.libraryName = vmAdHocWorkspaceCtrl.SelectedLibrary;

                var searchAPIUrl = baseV2Url + adHocWorkspaceFactory.getSubClassListAPI(customListRequestModel);
                var promise = homeService.getData(searchAPIUrl);
                promise.then(function(response) {
                    if (response.status === 200 && response.data && response.data.total_count) {
                        metaDataItemTotalCount = response.data.total_count;
                    }
                    if (response.status === 200 && response.data && response.data.data) {
                        $scope.mc.getlogDetails("Success", 'Response:Success');

                        var subClassList = [];
                        angular.forEach(response.data.data, function(subClassItem) {
                            var subClassUIModelTemp = adHocWorkspaceFactory.getSubClassUIModel(subClassItem);
                            if (subClassUIModelTemp.Description && subClassUIModelTemp.Description.trim().length > 0) {
                                subClassUIModelTemp.Description = subClassUIModelTemp.Id + ' - ' + subClassUIModelTemp.Description;
                            } else {
                                subClassUIModelTemp.Description = subClassUIModelTemp.Id;
                            }
                            subClassUIModelTemp.IsSubClassItem = true;
                            subClassList.push(subClassUIModelTemp);
                            subClassUIModelTemp = null;
                        });
                        deffered.resolve(subClassList);
                    } else {
                        $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                        deffered.resolve([]);
                    }
                }, function(response) {
                    $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                    deffered.resolve([]);
                });
                return deffered.promise;
            }

            function createInitailFolderStructures(workspaceId, owner) {

                //vmAdHocWorkspaceCtrl.FoldersPreview
                var deferdarray = []
                    //var deferdarray1 = []
                    //var type = 'regular';
                    //if ($scope.mc.objectDet.type == 'imTypeDocumentSearchFolder') {
                    //    type = 'search';
                    //}
                    //if ($scope.mc.objectDet.type == 'imTypeDocumentFolder') {
                    //    type = 'regular';
                    //}
                    //if ($scope.mc.objectDet.type == 'imTypeDocumentTab') {
                    //    type = 'tab';
                    //}
                var requestBody = {
                    'TemplateId': vmAdHocWorkspaceCtrl.SelectedTemplate.Id
                }
                var deferedNVP = $q.defer();
                var apiUrl = baseV2Url + adHocWorkspaceFactory.getSaveNVPURL(workspaceId);
                $scope.mc.getlogDetails("Debug", 'Method:POST;URL:' + JSON.stringify(apiUrl));
                var promisenvp = homeService.postDataUsingBody(apiUrl, requestBody);
                promisenvp.then(function(response) {
                    if (response && response.status === 200) {
                        $scope.mc.getlogDetails("Debug", 'Success');
                        deferedNVP.resolve({ Status: 0 });
                    } else {
                        $scope.mc.getlogDetails("Error", 'Error:' + JSON.stringify(response));
                        if (response && response.data && response.data.code_message) {
                            deferedNVP.resolve({ Status: -1, ErrorMsg: response.data.code_message });
                        } else {
                            deferedNVP.resolve({ Status: -1, ErrorMsg: '' });
                        }
                    }
                }, function(response) {
                    $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                    deferedNVP.resolve({ Status: -1, ErrorMsg: '' });
                });
                deferdarray.push(deferedNVP.promise);
                var finishcount = 0;
                vmAdHocWorkspaceCtrl.EmailArray = [];
                angular.forEach(vmAdHocWorkspaceCtrl.FoldersPreview, function(folders) {
                    var defered1 = $q.defer();
                    folders.ParentId = workspaceId;
                    folders.Owner = owner;

                    /*var email = ''
                    if (folders.NVPs.IMCC_Email_Format)
                        email = folders.NVPs.IMCC_Email_Format;
                    var promiseEmail = getEmailAddress(email, folders);
                    promiseEmail.then(function(responseEmail) {
                        if (responseEmail != '') {
                            folders.Email = responseEmail;
                            folders.EmailFormat = responseEmail;
                        }*/

                    applyFolder(angular.copy(folders)).then(function(response) {
                        finishcount += 1;
                        $translate('adhocWorkspace.creatingTemplateObjects', {
                            itemIndex: finishcount.toString(),
                            totalCount: vmAdHocWorkspaceCtrl.FoldersPreview.length.toString()
                        }).then(function(text) {
                            changeProgressDialogMessage(text);
                        });
                        defered1.resolve(response);
                    });
                    //});
                    deferdarray.push(defered1.promise);
                });
                var deferedAlert = $q.defer();
                $q.all(deferdarray).then(function(results) {
                    var errorMsg = '';
                    angular.forEach(results, function(item) {
                        if (item && item.Status === -1) {
                            if (errorMsg.trim().length > 0) errorMsg += '<br />';
                            errorMsg += item.ErrorMsg != null ? item.ErrorMsg : '';
                        }
                    });
                    if (errorMsg.trim().length > 0) {
                        deferedAlert.resolve({ Status: -1, ErrorMsg: errorMsg });
                    } else {
                        deferedAlert.resolve({ Status: 0 });
                    }
                });
                return deferedAlert.promise;
            }

            function getEmailAddress(emailaddress, folder) {
                var defered = $q.defer();
                if (emailaddress && emailaddress.trim().length > 0 && !isGUId(emailaddress)) {
                    replacehashValues(emailaddress, folder).then(function(response) {
                        defered.resolve(response);
                    });
                } else if (emailaddress && emailaddress.trim().length > 0 && isGUId(emailaddress)) {
                    defered.resolve(folder.Name + '.' + folder.Name);
                } else if (folder.Email && folder.Email.trim().length > 0) {
                    emailaddress = folder.Email.replace(folderEmailDomain, '').trim();
                    if (emailaddress && emailaddress.trim().length > 0 && isGUId(emailaddress)) {
                        emailaddress = folder.Name + '.' + folder.Name;
                    }
                    defered.resolve(emailaddress);
                } else {
                    defered.resolve('');
                }
                return defered.promise;
            }

            function isGUId(stringToTest) {
                if (!stringToTest) return false;
                if (stringToTest[0] === "{") {
                    stringToTest = stringToTest.substring(1, stringToTest.length - 1);
                }
                var regexGuid = /^(\{){0,1}[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12}(\}){0,1}$/gi;
                return regexGuid.test(stringToTest);
            }

            function replacehashValues(emailaddress, folder) {
                var finalDeferd = $q.defer();
                var defferedArray = [];
                if (emailaddress != null && emailaddress.trim().length > 0) {
                    var defererednorm = $q.defer();
                    defferedArray.push(defererednorm.promise);
                    do {
                        if ((emailaddress.search(/%C([1-9]|[1][0-9]|[2][0-9]|[3][0])Alias%/i) != -1)) {
                            var matches = emailaddress.match(/%C([1-9]|[1][0-9]|[2][0-9]|[3][0])Alias%/i);
                            var mdata = matches[0].match(/\d+/g);
                            var customValue = 'Custom' + mdata[0];
                            if (vmAdHocWorkspaceCtrl.adHocWSUIModel[customValue])
                                emailaddress = emailaddress.replace(matches[0], vmAdHocWorkspaceCtrl.adHocWSUIModel[customValue].Alias);
                            else
                                emailaddress = emailaddress.replace(matches[0], '')
                        }
                    } while ((emailaddress.search(/%C([1-9]|[1][0-9]|[2][0-9]|[3][0])Alias%/i) != -1));


                    var deferdper = {};
                    do {
                        if (emailaddress.search(/%C([1-9]|[1][0-9]|[2][0-9]|[3][0])DESCR%/i) != -1) {
                            var matches = emailaddress.match(/%C([1-9]|[1][0-9]|[2][0-9]|[3][0])DESCR%/i);
                            var mdata = matches[0].match(/\d+/g);
                            var customName = ('Custom' + mdata[0].toString()).toLowerCase();

                            var requestObj = {};

                            if (vmAdHocWorkspaceCtrl.adHocWSUIModel['Custom' + mdata[0]]) {
                                requestObj.alias = vmAdHocWorkspaceCtrl.adHocWSUIModel['Custom' + mdata[0]].Alias;
                                emailaddress = emailaddress.replace(matches[0], '%' + customName + 'description%');

                                requestObj.type = '';
                                if (mdata[0] === '2')
                                    requestObj.type = 'custom1/' + vmAdHocWorkspaceCtrl.adHocWSUIModel['Custom1'].Alias + '/';
                                if (mdata[0] === '30')
                                    requestObj.type = 'custom29/' + vmAdHocWorkspaceCtrl.adHocWSUIModel['Custom29'].Alias + '/';
                                requestObj.type += 'custom' + mdata[0];
                                var apiUrl = baseV2Url + adHocWorkspaceFactory.getMetaData(requestObj);
                                $scope.mc.getlogDetails("Debug", 'Method:GET;URL' + JSON.stringify(apiUrl));
                                deferdper[customName] = $q.defer();
                                defferedArray.push(deferdper[customName].promise);
                                var promise = homeService.getData(apiUrl);
                                promise.then(function(response) {
                                    if (response["status"] == 200 && response.data && response.data.data) {
                                        emailaddress = emailaddress.replace('%' + response.data.data.wstype + 'description%', response.data.data['description'])
                                        deferdper[response.data.data.wstype].resolve(emailaddress);
                                    }
                                });
                            } else {
                                emailaddress = emailaddress.replace(matches[0], '');

                            }
                        }
                    } while (emailaddress.search(/%C([1-9]|[1][0-9]|[2][0-9]|[3][0])DESCR%/i) != -1);


                    do {
                        if ((emailaddress.search(/#C([1-9]|[1][0-9]|[2][0-9]|[3][0])Alias#/i) != -1)) {
                            var matches = emailaddress.match(/#C([1-9]|[1][0-9]|[2][0-9]|[3][0])Alias#/i);
                            var mdata = matches[0].match(/\d+/g);
                            var customValue = 'Custom' + mdata[0];
                            if (vmAdHocWorkspaceCtrl.adHocWSUIModel[customValue])
                                emailaddress = emailaddress.replace(matches[0], vmAdHocWorkspaceCtrl.adHocWSUIModel[customValue].Alias);
                            else
                                emailaddress = emailaddress.replace(matches[0], '')
                        }
                    } while ((emailaddress.search(/#C([1-9]|[1][0-9]|[2][0-9]|[3][0])Alias#/i) != -1));

                    var deferd = {};
                    do {
                        if (emailaddress.search(/#C([1-9]|[1][0-9]|[2][0-9]|[3][0])DESCR#/i) != -1) {
                            var matches = emailaddress.match(/#C([1-9]|[1][0-9]|[2][0-9]|[3][0])DESCR#/i);
                            var mdata = matches[0].match(/\d+/g);
                            var customName = ('Custom' + mdata[0].toString()).toLowerCase();

                            var requestObj = {};

                            if (vmAdHocWorkspaceCtrl.adHocWSUIModel['Custom' + mdata[0]]) {
                                requestObj.alias = vmAdHocWorkspaceCtrl.adHocWSUIModel['Custom' + mdata[0]].Alias;
                                emailaddress = emailaddress.replace(matches[0], '#' + customName + 'description#');

                                requestObj.type = '';
                                if (mdata[0] === '2')
                                    requestObj.type = 'custom1/' + vmAdHocWorkspaceCtrl.adHocWSUIModel['Custom1'].Alias + '/';
                                if (mdata[0] === '30')
                                    requestObj.type = 'custom29/' + vmAdHocWorkspaceCtrl.adHocWSUIModel['Custom29'].Alias + '/';
                                requestObj.type += 'custom' + mdata[0];
                                var apiUrl = baseV2Url + adHocWorkspaceFactory.getMetaData(requestObj);
                                $scope.mc.getlogDetails("Debug", 'Method:GET;URL' + JSON.stringify(apiUrl));
                                deferd[customName] = $q.defer();
                                defferedArray.push(deferd[customName].promise);
                                var promise = homeService.getData(apiUrl);
                                promise.then(function(response) {
                                    if (response["status"] == 200 && response.data && response.data.data) {
                                        emailaddress = emailaddress.replace('#' + response.data.data.wstype + 'description#', response.data.data['description'])
                                        deferd[response.data.data.wstype].resolve(emailaddress);
                                    }
                                });
                            } else {
                                emailaddress = emailaddress.replace(matches[0], '');

                            }
                        }
                    } while (emailaddress.search(/#C([1-9]|[1][0-9]|[2][0-9]|[3][0])DESCR#/i) != -1);

                    do {
                        if (emailaddress.search(/#USERID#/i) != -1) {
                            var matches = emailaddress.match(/#USERID#/i)
                            emailaddress = emailaddress.replace(matches[0], $scope.mc.loginModel.UserName);
                        }
                    } while ((emailaddress.search(/#USERID#/i) != -1));

                    do {
                        if (emailaddress.search(/#USERFULLNAME#/i) != -1) {
                            var matches = emailaddress.match(/#USERFULLNAME#/i)
                            emailaddress = emailaddress.replace(matches[0], $scope.mc.loginModel.FullName);
                        }
                    } while ((emailaddress.search(/#USERFULLNAME#/i) != -1));

                    do {
                        if (emailaddress.search(/%FOLDERNAME%/i) != -1) {
                            var matches = emailaddress.match(/%FOLDERNAME%/i)
                            emailaddress = emailaddress.replace(matches[0], folder.Name);
                        }
                    } while ((emailaddress.search(/%FOLDERNAME%/i) != -1));

                    do {
                        if (emailaddress.search(/#FOLDERNAME#/i) != -1) {
                            var matches = emailaddress.match(/#FOLDERNAME#/i)
                            emailaddress = emailaddress.replace(matches[0], folder.Name);
                        }
                    } while ((emailaddress.search(/#FOLDERNAME#/i) != -1));
                    defererednorm.resolve(emailaddress);
                }
                $q.all(defferedArray).then(function() {
                    finalDeferd.resolve(emailaddress);
                });
                return finalDeferd.promise;
            }

            function applyFolder(folder) {
                var defered = $q.defer();
                var subfolder = {};
                subfolder.Name = folder.Name;
                subfolder.DefaultSecurity = folder.DefaultSecurity;
                subfolder.Database = vmAdHocWorkspaceCtrl.selectedLibrary;
                subfolder.Description = folder.Description;
                subfolder.FolderType = folder.FolderType;
                subfolder.Owner = folder.Owner;

                var email = '';
                if (folder.NVPs.IMCC_Email_Format && folder.NVPs.IMCC_Email_Format.length > 0)
                    email = folder.NVPs.IMCC_Email_Format;
                var promiseEmail = getEmailAddress(email, folder);
                promiseEmail.then(function(responseEmail) {
                    if (responseEmail !== '') {
                        subfolder.Email = responseEmail;
                        subfolder.EmailFormat = responseEmail;
                        folder.Email = responseEmail;
                        folder.EmailFormat = responseEmail;
                    }
                    replacehashValues(subfolder.Description).then(function(responseDecription) {
                        subfolder.Description = responseDecription;
                        var profileOfCurrent = getProfileOfFolder(folder.FolderType, folder.Id).then(function(responseprofile) {
                            if (responseprofile) {

                                var wsProfile = getWorkspaceProfile();
                                var prof = {};
                                angular.forEach(responseprofile, function(value, key) {
                                    if (key.indexOf('operator') != -1 || key.indexOf('author') != -1) {
                                        if (key == 'operator' || key === 'author') {
                                            if (value.toString().search(/%USERID%/i) != -1) {
                                                /* if(subfolder.FolderType =='regular'){
                                                      var matches = value.match(/%USERID%/i)
                                                      if ($scope.mc.loginModel.UserName)
                                                          prof[key] = value.toString().replace(matches[0], vmAdHocWorkspaceCtrl.adHocWSUIModel.Owner || $scope.mc.loginModel.UserName);
                                                      else{
                                                          var data=value.toString().replace(matches[0], ''); 
                                                          if(data.toString().trim().length>0)
                                                              prof[key] = data; 
                                                      }
                                                   }  else{*/
                                                prof[key] = value;
                                                /*   } */

                                            }
                                        }
                                    } else if (key == 'content_type') {
                                        prof['contenttype'] = 'D,5';
                                    } else if (value && value.toString().search(/%WORKSPACE_VALUE%/i) != -1) {
                                        if (key.indexOf('custom') != -1) {
                                            var matches = value.match(/%WORKSPACE_VALUE%/i)
                                            if (wsProfile[key])
                                                prof[key] = value.toString().replace(matches[0], wsProfile[key]);
                                            else {
                                                var data = value.toString().replace(matches[0], '');
                                                if (data.toString().trim().length > 0)
                                                    prof[key] = value.toString().replace(matches[0], '');
                                            }
                                        } else {
                                            prof[key] = value;
                                        }

                                    } else {
                                        if (value != "") {
                                            if (key.indexOf('_desc') == -1) {
                                                prof[key] = value;
                                            } else if (key.indexOf('custom') == -1 && key.indexOf('operator') == -1 && key.indexOf('author') == -1) {
                                                prof[key] = value;
                                            }
                                        }
                                    }
                                });

                                if (subfolder.FolderType === 'search') {
                                    subfolder["searchprofile"] = prof;
                                }
                                if (subfolder.FolderType === 'regular') {
                                    subfolder["profile"] = prof;
                                }
                            }
                            if (subfolder["searchprofile"]) {
                                subfolder["searchprofile"]['contenttype'] = 'D,5';
                                subfolder["searchprofile"]['databases'] = vmAdHocWorkspaceCtrl.selectedLibrary;
                            }
                            var apiUrl = baseV2Url + adHocWorkspaceFactory.getFolderPostAPI(folder.ParentId, folder.FolderType);
                            var counter = 0;
                            if (vmAdHocWorkspaceCtrl.EmailArray.length > 0) {
                                var data = vmAdHocWorkspaceCtrl.EmailArray[vmAdHocWorkspaceCtrl.EmailArray.length - 1].replace(folder.EmailFormat, '');
                                if (data.indexOf('_') !== -1) {
                                    data = data.replace('_', '');
                                }
                                try {
                                    counter = (parseInt(data) + 1);
                                } catch (exp) {
                                    counter = 0;
                                }
                            }

                            checkForEmailExists(folder.Email, counter).then(function(emailResponse) {
                                if (emailResponse) {
                                    //  folders.EmailFormat = responseEmail;
                                    var finalEmail = emailExists(emailResponse, folder.EmailFormat)
                                    if (finalEmail && finalEmail !== '') {
                                        subfolder.Email = finalEmail;
                                        subfolder.EmailFormat = folder.EmailFormat;
                                    }
                                }
                                var requestBody = adHocWorkspaceFactory.getFolderPostAPIModel(subfolder);
                                $scope.mc.getlogDetails("Debug", 'Method:POST;URL:' + JSON.stringify(apiUrl) + 'Parametrs are' + JSON.stringify(requestBody));
                                var promise = homeService.postDataUsingBody(apiUrl, requestBody);
                                promise.then(function(response) {
                                     
									if (response && response.data && response.data.code === 'NRC_EMAIL_IN_USE') {
                                            var finalEmail1 = emailExists(subfolder.Email, folder.EmailFormat)
                                                //folder.Email = finalEmail1;
                                            applyFolder(angular.copy(folder)).then(function(response) {
                                                defered.resolve(response);
                                            });
                                         
                                    } else if (response && response.status === 201) {
                                        if (response.data && response.data.data && response.data.data.id && response.data.data.id.trim().length > 0) {
                                            $scope.mc.getlogDetails("Debug", 'Object Added with id' + response.data.data.id);

                                            var templateFolderId = folder.Id;
                                            folder.Id = response.data.data.id;
                                            if (folder.DefaultSecurity.toUpperCase() !== 'INHERIT') {

                                                var securityPromise = getFolderSecurity(templateFolderId);
                                                securityPromise.then(function(responseSecurity) {
                                                    if (responseSecurity.Status === 0 && responseSecurity.SecurityList && responseSecurity.SecurityList.length > 0) {
                                                        saveFolderSecurity(folder.Id, folder.DefaultSecurity, responseSecurity.SecurityList)
                                                    }
                                                });
                                            }

                                            var folderIdMappingPromise = saveTemplateFolderIdNVP(templateFolderId, folder.Id);
                                            folderIdMappingPromise.then(function(responseNVP) {
                                                vmAdHocWorkspaceCtrl.NewFlist += folder.Id + ';';

                                                if (folder.SubFolders.length > 0) {
                                                    var deferedarray = [];
                                                    angular.forEach(folder.SubFolders, function(subFolder) {
                                                        subFolder.ParentId = folder.Id;
                                                        var deferedque = $q.defer();
                                                        deferedarray.push(deferedque.promise);
                                                        applyFolder(angular.copy(subFolder)).then(function(response) {
                                                            deferedque.resolve(response);
                                                        }, function(response) {
                                                            deferedque.resolve(response);
                                                        });
                                                    });
                                                    $q.all(deferedarray).then(function() {
                                                        defered.resolve({ Status: 0 });
                                                    });
                                                } else {
                                                    defered.resolve({ Status: 0 });
                                                }
                                            }, function(response) {
                                                defered.resolve({ Status: 0 });
                                            });
                                        } else {
                                            defered.resolve({ Status: 0 });
                                            $scope.mc.getlogDetails("Error", 'Object not added error' + JSON.stringify(response));
                                        }
                                    } else {
                                        if (response && response.data && response.data.code_message) {
                                            $scope.mc.getlogDetails("Error", 'Error:' + JSON.stringify(response));
                                            defered.resolve({ Status: -1, ErrorMsg: response.data.code_message });
                                        } else {
                                            $scope.mc.getlogDetails("Error", 'Error:' + JSON.stringify(response));
                                            defered.resolve({ Status: -1, ErrorMsg: '' });
                                        }
                                    }
                                }, function(response) {
                                    $scope.mc.getlogDetails("Error", 'Object not added error' + JSON.stringify(response));
                                    defered.resolve({ Status: -1, ErrorMsg: '' });
                                });
                            });
                        });
                    });
                });
                return defered.promise;
            }

            function getWorkspaceProfile() {
                if (!profileFromWs) {
                    profileFromWs = {};
                    for (var i = 1; i <= 30; i++) {
                        if (vmAdHocWorkspaceCtrl.adHocWSUIModel['Custom' + i.toString()] && vmAdHocWorkspaceCtrl.adHocWSUIModel['Custom' + i.toString()].Alias)
                            profileFromWs['custom' + i.toString()] = vmAdHocWorkspaceCtrl.adHocWSUIModel['Custom' + i.toString()].Alias;
                        else if (vmAdHocWorkspaceCtrl.adHocWSUIModel['Custom' + i] && vmAdHocWorkspaceCtrl.adHocWSUIModel['Custom' + i.toString()] != 'inter') {
                            profileFromWs['custom' + i.toString()] = vmAdHocWorkspaceCtrl.adHocWSUIModel['Custom' + i.toString()];
                        }
                    }
                }
                return angular.copy(profileFromWs);
            }

            function getProfileOfFolder(ftype, Id) {
                var defered = $q.defer();
                if (ftype == 'tab') {
                    defered.resolve(undefined)
                } else {
                    var GETProfileURL = 'FOLDER_PROFILE'
                    if (ftype == 'search') {
                        GETProfileURL = 'SEARCH_PROFILE';
                    }
                    var apiUrl = baseV2Url + adHocWorkspaceFactory.getProfileUI(GETProfileURL, Id);
                    $scope.mc.getlogDetails("Debug", 'Method:GET;URL' + JSON.stringify(apiUrl));
                    var promise = homeService.getData(apiUrl);
                    promise.then(function(response) {
                            if (response && response.data && response.data.data) {
                                defered.resolve(response.data.data.profile || response.data.data.searchprofile || {})
                            } else {
                                defered.resolve(undefined)
                            }
                        },
                        function(response) {
                            defered.resolve(undefined)
                        });
                }
                return defered.promise;
            }

            function checkForEmailExists(emailaddress, count) {
                var defered = $q.defer();
                if (emailaddress && emailaddress != 'undefined') {
                    var body = {};
                    if (count == 0 || !count || count=="" || count==undefined) {
						count = 0;
                        body.email = encodeURIComponent(emailaddress);
                    } else {
                        body.email = encodeURIComponent(emailaddress) + '_' + count;
                    }
                    var apiUrl = baseV2Url + adHocWorkspaceFactory.getSearchFolder(body);
                    $scope.mc.getlogDetails("Debug", 'apiUrl:' + apiUrl);

                    var EmailAddress = homeService.getData(apiUrl);
                    EmailAddress.then(function(response) {
                        $scope.mc.getlogDetails("Debug", 'Email Response for ' + body.email + 'response' + JSON.stringify(response));

                        if (response.data.data.length > 0) {
                            checkForEmailExists(emailaddress, count + 1).then(function(emailResponse) {
                                defered.resolve(decodeURIComponent(emailResponse));
                            });
                        } else {
                            defered.resolve(decodeURIComponent(body.email));
                        }
                    });
                } else {
                    defered.resolve(undefined);
                }
                return defered.promise;
            }

            function emailExists(NewMail, Format) {
                while (vmAdHocWorkspaceCtrl.EmailArray.indexOf(NewMail) !== -1) {
                    var count = NewMail.replace(Format, '');
                    if (count.indexOf('_') !== -1) {
                        count = count.replace('_', '');
                    } else { count = '0'; }
                    NewMail = Format + '_' + (parseInt(count) + 1);
                }
                vmAdHocWorkspaceCtrl.EmailArray.push(NewMail);
                return NewMail;
            }

            function saveTemplateFolderIdNVP(templateFolderId, createdFolderId) {
                var deferedNVP = $q.defer();
                var requestBody = {
                    FolderTemplateId: templateFolderId
                };
                var apiUrl = baseV2Url + adHocWorkspaceFactory.getSaveNVPURL(createdFolderId);
                $scope.mc.getlogDetails("Debug", 'Method:POST;URL:' + JSON.stringify(apiUrl));

                var promisenvp = homeService.postDataUsingBody(apiUrl, requestBody);
                promisenvp.then(function(response) {
                    if (response && response.data && response.data.error && response.data.error.code) {
                        $scope.mc.getlogDetails("Error", 'Error:' + JSON.stringify(response));
                        deferedNVP.resolve(response);
                    } else {
                        $scope.mc.getlogDetails("Debug", 'Success');
                        deferedNVP.resolve(response);
                    }
                }, function(response) {
                    $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                    if (response && response.data && response.data.error && response.data.error.code) {
                        deferedNVP.resolve(response);
                    } else {
                        deferedNVP.resolve(response);
                    }
                });
                return deferedNVP.promise;
            }

            function isAllowAddNewMetadata(metaType) {
                metaType = metaType.trim().toUpperCase();
                if (metaType.length === 0) return false;

                if (vmAdHocWorkspaceCtrl.DenyCreateNewCustomItemList.indexOf(metaType) >= 0)
                    return false;

                if (isNRTAdminGroupUserLoggedIn === true)
                    return true;

                var filterList = ($filter('filter')(vmAdHocWorkspaceCtrl.LocationList, {
                    DatabaseName: vmAdHocWorkspaceCtrl.SelectedLibrary
                }, true));
                if (filterList.length === 0) {
                    return false;
                }
                return filterList[0].M4_Bits.CustomMetadataManagement === true;
            }

            function text_KeyDown(item, event) {
                if (event.keyCode === 9 || (event.originalEvent != null && event.originalEvent.keyCode === 9)) {
                    if (vmAdHocWorkspaceCtrl.SelectedTabIndex === 0) {
                        event.preventDefault();
                        $("#location").focus();
                    } else if (vmAdHocWorkspaceCtrl.SelectedTabIndex === 1) {
                        event.preventDefault();
                        $("#securityType").focus();
                    }
                }
            }

            function showRestoreSuccessWindow() {
                resizeWindow({ width: '500', height: '300' });
                vmAdHocWorkspaceCtrl.IsHideWorkspaceWindow = true;
                vmAdHocWorkspaceCtrl.IsShowSuccessWindow = true;
                setCreateWorkspacePath();
            }

            function setCreateWorkspacePath() {
                vmAdHocWorkspaceCtrl.CreatedWorkspaceLocation = baseIMCCApiUrl.trim();
                if (vmAdHocWorkspaceCtrl.CreatedWorkspaceLocation.substr(vmAdHocWorkspaceCtrl.CreatedWorkspaceLocation.length - 1) !== '/')
                    vmAdHocWorkspaceCtrl.CreatedWorkspaceLocation += '/';
                vmAdHocWorkspaceCtrl.CreatedWorkspaceLocation += 'link/w/' + vmAdHocWorkspaceCtrl.adHocWSUIModel.Id;
            }

            function copyPathtoClipboard() {

                $("#txtCeatedLocation").focus();
                $("#txtCeatedLocation").select();
                document.execCommand('copy');

                $timeout(function() {
                    if (window.getSelection) {
                        if (window.getSelection().empty) { // Chrome
                            window.getSelection().empty();
                        } else if (window.getSelection().removeAllRanges) { // Firefox
                            window.getSelection().removeAllRanges();
                        }
                    } else if (document.selection) { // IE?
                        document.selection.empty();
                    }
                    var txtTemp = document.getElementById('txtCeatedLocation');
                    if (txtTemp) {
                        txtTemp.selectionStart = txtTemp.selectionEnd;
                    }
                });
                vmAdHocWorkspaceCtrl.IsShowClipboardCopyMsg = true;
            }

            function OwnerSearchText_Change() {
                var deffered = $q.defer();
                $('md-virtual-repeat-container.md-autocomplete-suggestions-container.md-whiteframe-z1.md-virtual-repeat-container.md-orient-vertical.ng-hide>div.md-virtual-repeat-scroller').off("scroll");
                autoCompleteListScrollStatus = 0;
                metaDataItemTotalCount = 0;
                customListRequestModel.pagenumber = 1;
                customListRequestModel.MetaType = null;
                customListRequestModel.subType = null;
                customModelList = [];
                currentSelectedCustomType = '';
                var promise = searchUser(vmAdHocWorkspaceCtrl.OwnerText, 'no-filter');

                promise.then(function(response) {
                    customModelList = response;
                    deffered.resolve(customModelList);
                }, function(response) {
                    deffered.resolve([]);
                });
                return deffered.promise;
            }

            function CategorySearchText_Change() {
                var deffered = $q.defer();
                $('md-virtual-repeat-container.md-autocomplete-suggestions-container.md-whiteframe-z1.md-virtual-repeat-container.md-orient-vertical.ng-hide>div.md-virtual-repeat-scroller').off("scroll");
                autoCompleteListScrollStatus = 0;
                var matterCategoryList = [];
                if (vmAdHocWorkspaceCtrl.CategoryText == undefined || vmAdHocWorkspaceCtrl.CategoryText.trim().length === 0) {
                    matterCategoryList.push({ IsBeginTypingItem: true, IsMetaItem: false });
                } else {
                    matterCategoryList.push({ IsCreateNewItem: true, IsMetaItem: false });
                }
                var promise = getMatterCategory()
                promise.then(function(response) {
                    angular.forEach(response, function(categoryItem) {
                        if (vmAdHocWorkspaceCtrl.CategoryText && vmAdHocWorkspaceCtrl.CategoryText.length > 0) {
                            if (categoryItem.Name.toUpperCase().indexOf(vmAdHocWorkspaceCtrl.CategoryText.toUpperCase()) > -1) {
                                matterCategoryList.push(categoryItem);
                            }
                        } else {
                            matterCategoryList.push(categoryItem);
                        }
                    });
                    vmAdHocWorkspaceCtrl.CategoryArray = angular.copy(matterCategoryList);
                    deffered.resolve(matterCategoryList);
                });
                return deffered.promise;
            }

            function getMatterCategory() {
                var deffered = $q.defer();



                var searchAPIUrl = baseV2Url + adHocWorkspaceFactory.getMatterCategoryAPI();
                var promise = homeService.getData(searchAPIUrl);
                promise.then(function(response) {
                    if (response.status === 200 && response.data && response.data.data) {
                        $scope.mc.getlogDetails("Success", 'Response:Success');

                        var matterCategoryList = [];
                        angular.forEach(response.data.data, function(matterCategoryItem) {
                            var matterCategoryUIModelTemp = adHocWorkspaceFactory.getMatterCategoryUIModel(matterCategoryItem);
                            if (matterCategoryUIModelTemp.FolderType == 'category') {
                                matterCategoryList.push(matterCategoryUIModelTemp);
                            }
                            matterCategoryUIModelTemp = null;
                        });
                        deffered.resolve(matterCategoryList);
                    } else {
                        $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                        deffered.resolve([]);
                    }
                }, function(response) {
                    $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                    deffered.resolve([]);
                });
                return deffered.promise;
            }

            function getCustomerId() {
                var deferred = $q.defer();
                var apiUrl;

                var baseUrlWithoutAPIV2 = masterFactory.getApiV2BaseUrl('', true, true);
                if (baseUrlWithoutAPIV2.indexOf('imcc/') != -1) {
                    apiUrl = baseUrlWithoutAPIV2 + adHocWorkspaceFactory.getInitDataAPI();
                } else {
                    apiUrl = baseUrlWithoutAPIV2 + adHocWorkspaceFactory.getStartupInitDataAPI();
                }

                var promise = homeService.getData(apiUrl);
                promise.then(function(response) {
                    customerName = '1';
                    if (response.status === 200 && response.data) {
                        if (response.data.customer_id && response.data.customer_id.toString().trim().length > 0) {
                            customerName = response.data.customer_id.toString();
                        } else if (response.data.data && response.data.data.customer_id && response.data.data.customer_id.toString().trim().length > 0) {
                            customerName = response.data.data.customer_id.toString();
                        }
                    }
                    deferred.resolve();
                });
                return deferred.promise;
            }

            function getNewAutoGeneratedCustomAlias(customType) {
                var deferred = $q.defer();
                var newCustomAlias = Math.floor(Math.random() * Math.pow(10, 9)).toString();
                for (var iCount = newCustomAlias.length; iCount < 9; iCount++) {
                    newCustomAlias = '0' + newCustomAlias;
                }
                var checkPromise = checkMetaDataAlreadyExists(customType, newCustomAlias);
                checkPromise.then(function(response) {
                    if (response.Status === 0) {
                        deferred.resolve({ AutoGeneratedAlias: newCustomAlias });
                    } else {
                        var promise = getNewAutoGeneratedCustomAlias();
                        promise.then(function(response) {
                            deferred.resolve({ AutoGeneratedAlias: response.AutoGeneratedAlias });
                        });
                    }
                });
                return deferred.promise;
            }

            function showWarningMessage(warningMsg) {
                $mdDialog.show($mdDialog.alert()
                    .parent(angular.element(document.body))
                    .clickOutsideToClose(true)
                    .title(lblWarning)
                    .textContent(warningMsg)
                    .ariaLabel(lblWarning)
                    .ok('OK')
                );
            }

            function openSelectMatterCategoryForm() {
                vmAdHocWorkspaceCtrl.SelectedMatterCategoryId = null;
                vmAdHocWorkspaceCtrl.IsSearchCategory = false;
                $scope.MatterCategory_Url = baseUrl + 'dialogs/category-browser/?type=my-matters&mode=browse&protocol=postmessage';

                $mdDialog.show({
                    controller: ['$scope', '$mdDialog', DialogController],
                    scope: $scope, // use parent scope in template
                    preserveScope: true, // do not forget this if use parent scope
                    templateUrl: 'framework/workspace/misc/matter_category_list.html?v=200',
                    parent: angular.element(document.body),
                    clickOutsideToClose: true,
                    fullscreen: false

                }).then(function(answer) {

                }, function() {

                });
            }

            function DialogController($scope, $mdDialog) {
                $scope.hide = function() {
                    $mdDialog.hide();
                };
                $scope.cancel = function() {
                    $mdDialog.cancel();
                };
            }

            function selectCategory_Click() {
                vmAdHocWorkspaceCtrl.IsSearchCategory = false;
                if (!vmAdHocWorkspaceCtrl.SelectedMatterCategoryId || vmAdHocWorkspaceCtrl.SelectedMatterCategoryId.trim().length === 0) {
                    return;
                }
                vmAdHocWorkspaceCtrl.IsSearchCategory = true;
                vmAdHocWorkspaceCtrl.adHocWSUIModel.Category = null;

                var searchAPIUrl = baseV2Url + adHocWorkspaceFactory.getProfileUI('FOLDER_PROFILE', vmAdHocWorkspaceCtrl.SelectedMatterCategoryId);
                var promise = homeService.getData(searchAPIUrl);
                promise.then(function(response) {
                    if (response.status === 200 && response.data && response.data.data) {
                        $scope.mc.getlogDetails("Success", 'Response:Success');
                        vmAdHocWorkspaceCtrl.adHocWSUIModel.Category = adHocWorkspaceFactory.getFolderUI(response.data.data);
                    } else {
                        $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                    }
                    $mdDialog.hide();
                }, function(response) {
                    $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                    $mdDialog.hide();
                });
            }

            $($window).on("message", function(e) {
                vmAdHocWorkspaceCtrl.SelectedMatterCategoryId = null;

                if (e.originalEvent.data.type !== null && e.originalEvent.data.type === 'category_selected') {
                    if (e.originalEvent.data.data !== null) {
                        vmAdHocWorkspaceCtrl.SelectedMatterCategoryId = e.originalEvent.data.data.categoryId;
                    }
                }
            });

            function textChange(text) {
                vmAdHocWorkspaceCtrl.CustomGlobalValue = text;
            }

            function textNameChange() {
                if (vmAdHocWorkspaceCtrl.NewMetaData.Alias && vmAdHocWorkspaceCtrl.NewMetaData.Alias != '')
                    vmAdHocWorkspaceCtrl.NewMetaData.Alias = vmAdHocWorkspaceCtrl.NewMetaData.Alias.split(/\s+/).join('');
            }
        }
    });
})();