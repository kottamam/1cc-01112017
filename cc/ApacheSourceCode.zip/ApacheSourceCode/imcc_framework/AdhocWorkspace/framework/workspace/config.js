(function() {
    'use strict';

    require.config({
        paths: {
            UITree: 'workspace/misc/angular-ui-tree',
            WorkspaceController: 'workspace/WorkspaceController',
            WorkspaceConstants: 'workspace/WorkspaceConstants',
            WorkspaceFactory: 'workspace/WorkspaceFactory',
            Custom: 'workspace/CustomScript',
            WorkspaceDirective:'workspace/WorkspaceDirective'
        }
    });

    define([
        'UITree',
        'WorkspaceController',
        'WorkspaceConstants',
        'WorkspaceFactory',
        'Custom',
        'WorkspaceDirective'
    ]);
})();