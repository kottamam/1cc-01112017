(function () {
    'use strict';

    angular.module('iManage.adHocWorkspace').directive("noSpecialChar", noSpecialChar);

    noSpecialChar.$inject = ['$timeout', '$parse'];

    function noSpecialChar($timeout, $parse) {
        return {
            require: 'ngModel',
            restrict: 'A',
            link: function (scope, element, attrs, modelCtrl) {
                modelCtrl.$parsers.push(function (inputValue) {
                    var cleanInputValue='';
                    if (inputValue == null)
                        return ''
                    cleanInputValue = inputValue.replace(/[\~\`\[\]\'\"\,\s]*$/, '');
                    if (cleanInputValue != inputValue) {
                        modelCtrl.$setViewValue(cleanInputValue);
                        modelCtrl.$render();
                    }
                    return cleanInputValue;
                });
            }
        }
    }

})();

