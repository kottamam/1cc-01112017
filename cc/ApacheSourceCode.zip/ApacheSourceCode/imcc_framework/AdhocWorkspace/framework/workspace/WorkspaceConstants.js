(function() {
    'use strict';

    define(['angular'], function() {
        angular.module('iManage.adHocWorkspace').constant('API_URL_adHOC_WS', {
            GET_SINGLE_USER: 'users/<user_id>',
            SEARCH_METADATA: 'customs/<custom_type>/search',
            SEARCH_CHILD_METADATA: 'customs/<custom_type>/<palias>/<child_custom>/search',
            SEARCH_USERS: 'users/search?allow_logon=true&offset=<offset>&limit=<limit>&total=<total>',
            GET_USER_PHOTO: 'users/<userid>/photo',
            SEARCH_GROUPS: 'groups/search?offset=<offset>&limit=<limit>&total=true&enabled=true',
            GET_GROUP_USERS: 'groups/<group_alias>/members?offset=<offset>&limit=<limit>&total=<total>',
            POST_METADATA: 'customs/<custom_type>',
            FOLDER_SECURITY: 'workspaces/<ws_id>/security',
            WORKSPACE_POST: 'workspaces',
            GET_SUBCLASS_LIST: 'classes/webdoc/subclasses/search?&offset=<offset>&limit=<limit>&total=true',
            GET_SUBCLASS_DETAILS: 'classes/webdoc/subclasses/search?alias=<subalias>',
            GET_VISIBLE_FIELD_LIST: 'forms/visible-fields?form_type=new_workspace',
            GET_MATCH_FIELDS: 'system/config',
            SEARCH_TEMPLATE: 'workspaces/templates/search',
            NAME_VALUE_PAIRS: 'workspaces/<workspace_id>/name-value-pairs',
            GET_CHILDRENS: 'workspaces/<workspace_id>/children',
            POST_FOLDER: 'workspaces/<workspace_id>/folders',
            POST_TABS: 'workspaces/<workspace_id>/tabs',
            POST_SEARCH_FOLDERS: 'workspaces/<workspace_id>/search-folders',
            FOLDER_PROFILE: 'folders/{folderId}',
            SEARCH_PROFILE: 'search-folders/{folderId}',
            SEARCH_FOLDERS: 'folders/search',
            GET_METADATA: '{CTYPE}/{ALIAS}',
            GET_MATTER_CATEGORY_LIST: 'my-matters/children',
            MATTER_CATEGORY_POST: 'folders/<matter_id>/categories',
            CATEGORY_SECURITY: 'folders/<category_id>/security',
            POST_WORKSPACE_CATEGORY_SECURITY: 'my-matters/categories/<category_id>/shortcuts',
            POST_WORKSPACE_CATEGORY_SHORTCUTS: 'my-matters/shortcuts',
            GET_GLOBAL_SETTINGS: "config/web/files/commonsettings",
            GET_INIT_DATA: 'init-data',
            GET_STARTUP_INIT_DATA: 'startup/init-data',
            WEB_SETTINGS_URL: 'web/customizations',
            CONFIG_WEB_SETTINGS_URL: 'config/Web/files/websettings',
        });

        angular.module('iManage.adHocWorkspace').constant('CONST_adHOC_WS', {
            Author: "author",
            Class: "class",
            CreateDate: 'create_date',
            Custom1: "custom1",
            Custom2: "custom2",
            Custom3: "custom3",
            Custom4: "custom4",
            Custom5: "custom5",
            Custom6: "custom6",
            Custom7: "custom7",
            Custom8: "custom8",
            Custom9: "custom9",
            Custom10: "custom10",
            Custom11: "custom11",
            Custom12: "custom12",
            Custom17: "custom17",
            Custom18: "custom18",
            Custom19: "custom19",
            Custom20: "custom20",
            Custom21: "custom21",
            Custom22: "custom22",
            Custom23: "custom23",
            Custom24: "custom24",
            Custom25: "custom25",
            Custom26: "custom26",
            Custom27: "custom27",
            Custom28: "custom28",
            Custom29: "custom29",
            Custom30: "custom30",
            SubClass: "sub_class",
            Database: "database",
            DefaultSecurity: "default_security",
            DocumentNumber: 'document_number',
            EditDate: 'edit_date',
            EditProfileDate: 'edit_profile_date',
            FileCreateDate: 'file_create_date',
            FileEditDate: 'file_edit_date',
            HasAttachment: 'has_attachment',
            HasSubfolders: 'has_subfolders',
            Id: "id",
            InUse: 'in_use',
            Indexable: 'indexable',
            IsCheckedOut: 'is_checked_out',
            IsContainerSavedSearch: 'is_container_saved_search',
            IsContentSavedSearch: 'is_content_saved_search',
            IsExternal: 'is_external',
            IsExternalAsNormal: 'is_external_as_normal',
            IsHidden: 'is_hidden',
            IsHipaa: 'is_hipaa',
            Iwl: 'iwl',
            LastUser: 'last_user',
            Location: 'location',
            Name: 'name',
            Description: 'description',
            Operator: 'operator',
            Owner: 'owner',
            RetainDays: 'retain_days',
            Size: 'size',
            Subtype: 'subtype',
            Type: 'type',
            Version: 'version',
            Wstype: 'wstype'
        });

        angular.module('iManage.adHocWorkspace').constant('adHOC_WS_CONST_USERS', {
            UserId: 'user_id',
            FullName: 'full_name',
            Email: 'email',
            UserIdEx: 'user_id_ex'
        });

        angular.module('iManage.adHocWorkspace').constant('adHOC_WS_CONST_GROUPS', {
            GroupName: 'group_id',
            GroupFullName: 'full_name'
        });

        angular.module('iManage.adHocWorkspace').constant('adHOC_WS_CONST_SECURITY', {
            Access: "access",
            AccessLevel: "access_level",
            Id: "id",
            Name: "name",
            SID: "sid",
            Type: "type"
        });

        angular.module('iManage.adHocWorkspace').constant('adHOC_WS_CONST_METADATA', {
            Alias: 'id',
            Description: 'description',
            HIPAAComplaint: 'hipaa',
            EnableFlag: 'enabled',
            ParentAlias: 'parent',
            MetaType: 'wstype',
            DataBase: 'database'
        });

        angular.module('iManage.adHocWorkspace').constant('CONST_SYSTEM_CONFIG', {
            IMCC_OF_MATCHFIELDS: 'IMCC_OF_MATCHFIELDS',
            PREFIX: '<pre>'
        });

        angular.module('iManage.adHocWorkspace').constant('CONST_TEMPLATE_FOLDER', {
            Database: 'database',
            DefaultSecurity: 'default_security',
            Description: "description",
            EditDate: 'edit_date',
            FolderType: 'folder_type',
            HasSubfolders: 'has_subfolders',
            Id: 'id',
            IsContainerSavedSearch: 'is_container_saved_search',
            IsContentSavedSearch: 'is_content_saved_search',
            IsExternalAsNormal: 'is_external_as_normal',
            IsHidden: 'is_hidden',
            Name: 'name',
            Location: 'location',
            Owner: 'owner',
            ParentId: 'parent_id',
            SubType: 'subtype',
            ViewType: 'view_type',
            Wstype: 'wstype',
            Email: 'email'
        });

        angular.module('iManage.adHocWorkspace').constant('adHOC_WS_CONST_SUBCLASS', {
            Id: 'id',
            Description: 'description',
            Parent: 'parent',
            Database: 'database'
        });

        angular.module('iManage.adHocWorkspace').constant('adHOC_WS_CONST_MATTER_CATEGORY', {
            Database: 'database',
            DefaultSecurity: 'default_security',
            HasSubFolders: 'has_subfolders',
            Id: 'id',
            IsHidden: 'is_hidden',
            Name: 'name',
            Owner: 'owner',
            Description: 'description',
            ParentId: 'parent_id',
            ViewType: 'view_type',
            WSType: 'wstype',
            Profile: 'profile',
            FolderType: 'folder_type'
        });

    });
})();