(function () {
    'use strict';

    define(['angular'], function () {
        angular.module('iManage').constant('TSU_TEMPLATES', {
            GETMATCHFIELDS: 'api/v1/system/config',
            GETWORKSPACE: 'api/v1/workspaces/{WS_ID}',
            GETNAMEVALUEPAIRS: 'api/v1/workspaces/{WS_ID}/name-value-pairs',
            SEARCHTEMPLATE: 'api/v1/templates/search',
            GETFOLDERSFROMWORKSPCE: 'api/v1/workspaces/{WS_ID}/children',
            GETSUBFOLDERFROMFOLDER: 'api/v1/folders/{FOLDER_ID}/children',
            GETMETADATA: 'api/v1/{CTYPE}/{ALIAS}',
            POST_FOLDER: 'api/v1/workspaces/<workspace_id>/folders',
            POST_TABS: 'api/v1/workspaces/<workspace_id>/tabs',
            POST_SEARCH_FOLDERS: 'api/v1/workspaces/<workspace_id>/search-folders',
            GETFOLDERPATH: 'api/v1/folders/{FOLDER_ID}/path',
            SAVENAMEVALUEPAIRS: 'api/v1/workspaces/{WS_ID}/name-value-pairs',
            SEARCHFOLDERS: 'api/v1/folders/search',
            TABSPROFILE: 'api/v1/folders/{folderId}',
            SEARCHPROFILE: 'api/v1/search-folders/{folderId}',
            FOLDERPROFILE: 'api/v1/folders/{folderId}',
            GETGROUPUSERS: 'api/v1/groups/<group_alias>/members',
            SECURITYPROFILE: 'api/v1/workspaces/{FID}/security',
            GET_SINGLE_USER: 'api/v1/users/<user_id>'
        });

        angular.module('iManage').constant('CONST_WORKSPACETEMP', {
            Author: "author",
            Class: "class",
            CreateDate: 'create_date',
            Custom1: "custom1",
            Custom2: "custom2",
            Custom3: "custom3",
            Database: "database",
            DefaultSecurity: "default_security",
            DocumentNumber: 'document_number',
            EditDate: 'edit_date',
            EditProfileDate: 'edit_profile_date',
            FileCreateDate: 'file_create_date',
            FileEditDate: 'file_edit_date',
            HasAttachment: 'has_attachment',
            HasSubfolders: 'has_subfolders',
            Id: "id",
            InUse: 'in_use',
            Indexable: 'indexable',
            IsCheckedOut: 'is_checked_out',
            IsContainerSavedSearch: 'is_container_saved_search',
            IsContentSavedSearch: 'is_content_saved_search',
            IsExternal: 'is_external',
            IsExternalAsNormal: 'is_external_as_normal',
            IsHidden: 'is_hidden',
            IsHipaa: 'is_hipaa',
            Iwl: 'iwl',
            LastUser: 'last_user',
            Location: 'location',
            Name: 'name',
            Operator: 'operator',
            Owner: 'owner',
            RetainDays: 'retain_days',
            Size: 'size',
            Subtype: 'subtype',
            Type: 'type',
            Version: 'version',
            Wstype: 'wstype'
        });


        angular.module('iManage').constant('ACONST_USERS', {
            UserId: 'user_id',
            UserIdPut: 'alias',
            Alias: 'alias',//GetSingleUser for UserId
            FullName: 'full_name',
            Location: 'location',
            LocationFilter: 'location',
            Phone: 'phone',
            Ext: 'extension',
            Fax: 'fax',
            Email: 'email',
            IsExternalUser: 'is_external',
            IsExternalUserPut: 'external',
            IsExternalUserFilter: 'external',
            Password: 'user_password',
            UserMustChangePassword: 'force_password_change',
            PasswordNeverExpires: 'pwd_never_expire',
            PasswordNeverExpiresFilter: 'password_never_expire',
            IsAllowLogon: 'login',
            IsAllowLogonFilter: 'allow_logon',
            PreferredDatabase: 'preferred_database',
            PreferredDatabaseFilter: 'preferred_database',
            FileServer: 'doc_server',
            SecuredDocServer: 'secure_docserver',
            UserNos: 'user_nos',
            UserNosPut: 'nos',
            UserNum: 'user_num',//Success value checking after postUser,PUTUSER
            UserIdEx: 'user_id_ex',
            AddFormUserId: 'useridex',
            FailedLogin: 'failed_logins',
            DistName: 'distinguished_name',
            UserDomain: 'user_domain',
            ExchAutoDiscover: 'exch_autodiscover',
            LastEdited: 'edit_date',
            //UserDomain: 'user_domain',
            PasswordChangeDate: 'pwd_changed_ts',
            LastSyncDate: 'last_sync_ts',
            DateAccountLocked: 'lockout_ts',
            DataBase: 'database', //GetSingleUser for UserId
            UserIDForUserInGroup: 'UserID'
        });


        angular.module('iManage').constant('CONST_TEMPLATE_FOLDER', {
            Database: 'database',
            DefaultSecurity: 'default_security',
            Description: "description",
            EditDate: 'edit_date',
            FolderType: 'folder_type',
            HasSubfolders: 'has_subfolders',
            Id: 'id',
            IsContainerSavedSearch: 'is_container_saved_search',
            IsContentSavedSearch: 'is_content_saved_search',
            IsExternalAsNormal: 'is_external_as_normal',
            IsHidden: 'is_hidden',
            Name: 'name',
            Location: 'location',
            Owner: 'owner',
            ParentId: 'parent_id',
            SubType: 'subtype',
            ViewType: 'view_type',
            Wstype: 'wstype',
            Email:'email'
        });

       

        angular.module('iManage').constant('CONST_SYSTEM_CONFIG', {
            IMCC_OF_MATCHFIELDS: 'IMCC_OF_MATCHFIELDS'
        });

        angular.module('iManage').constant('CONST_SECURITY_MODEL', {
            Access: 'access',
            AccessLevel:'access_level',
            Id:'id',
            Name:'name',
            SID:'sid',
            Type:'type'
        });

        angular.module('iManage').constant('CONST_NAME_VALUE_PAIRS', {
           PREFIX: '<pre>'
        });
    });
})();
