var Ext = window.external;
function logoutuser() {
    
    $('#userEditForm').scope().vmApply.Logout();
}
function closewin(object) {
 
    window.external.closeWindow(object);

}

function resizewin(dimensions) {

    window.external.resizeWindow(dimensions);

}

