(function () {
    'use strict';

    require.config({
        paths: {
            UITree: 'applyTemplate/angular-ui-tree',
            ApplyController: 'applyTemplate/ApplyController',
            ApplyConstants: 'applyTemplate/ApplyConstants',
            ApplyFactory: 'applyTemplate/ApplyFactory',
            ApplyService: 'applyTemplate/ApplyService',
            Custom: 'applyTemplate/CustomScript',
        }
    });

    define([
        'UITree',
        'ApplyController',
        'ApplyConstants',
        'ApplyFactory',
        'ApplyService',
        'Custom'
    ]);
})();