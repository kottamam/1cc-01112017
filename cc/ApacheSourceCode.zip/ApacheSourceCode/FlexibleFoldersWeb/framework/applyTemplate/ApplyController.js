(function() {
    'use strict';

    define(['angular'], function(angular) {
        angular.module('iManage').controller("ApplyController", ApplyController);
        ApplyController.$inject = ['$scope', '$log', '$state', '$location', '$rootScope', '$timeout', 'loginService', '$cookies', 'homeService', 'homeFactory', '$interval', '$filter', '$stateParams', 'applyFactory', 'applyService', '$mdDialog', '$q', '$compile', 'masterFactory', '$window'];


        function ApplyController($scope, $log, $state, $location, $rootScope, $timeout, loginService, $cookies, homeService, homeFactory, $interval, $filter, $stateParams, applyFactory, applyService, $mdDialog, $q, $compile, masterFactory, $window) {

            var vmApply = this;
            vmApply.templateList = [];
            vmApply.workSpaceUIModel = {};
            vmApply.IsPreview = false;
            vmApply.foldersList = [];
            vmApply.NewFlist = '';
            vmApply.NewItemsList = [];
            var requestModel = homeFactory.requestModelInstance();
            vmApply.startedSearch = false;
            vmApply.selectedItem = undefined;
            vmApply.profileInfo = {};
            vmApply.wsprofileInfo = {};
            vmApply.profileInfoUI = {};
            vmApply.SelectedObject = {};
            vmApply.SelectedType = 'imTypeDocumentFolder';
            vmApply.tabTitle = 'Choose an Item';
            vmApply.ProfileTitle = undefined;
            vmApply.EmailArray = [];
            vmApply.DeterMine = false;
            vmApply.ProgressMessage = "";
            vmApply.GroupView = false;
            vmApply.SecurityModel = [];
            vmApply.groupMembers = [];
            vmApply.ItemsInSelectedLevel = [];
            vmApply.IsApplying = false;
            var groupMembersReqModel = homeFactory.requestModelInstance();
            var groupMembersSearchTimeOut = null;
            var isSearch = false;
            var isgroupMembersSearchTextDirty = false;
            var isgroupMembersInstantSearch = false;
            vmApply.groupMembersList = {
                SearchText: '',
                SearchClick: MembersSearchClick,
                ClearSearchClick: MembersClearSearchClick
            };

            vmApply.ItemChoosen = function() {
                $scope.mc.objectDet.type = vmApply.SelectedType;
                vmApply.tabTitle = '';
                if ($scope.mc.objectDet.type == 'imTypeDocumentSearchFolder') {
                    vmApply.tabTitle = 'Search folders';
                }
                if ($scope.mc.objectDet.type == 'imTypeDocumentFolder') {
                    vmApply.tabTitle = 'Folders';
                }
                if ($scope.mc.objectDet.type == 'imTypeDocumentTab') {
                    vmApply.tabTitle = 'Tabs';
                }
                vmApply.selectedItem = undefined;
                vmApply.ProgressMessage = 'Loading Templates';
                showProgressDialog();
                vmApply.templateList = [];
                getTemplates();

            };


            function samlLogin(StateName, Dtype) {


                var InitDataUrl = homeFactory.getSingleUserAPI('', ''); // masterFactory.getAPIUrl('INITDATA');
                $scope.mc.loginModel.FullName = '';
                var promise = homeService.getData(InitDataUrl).then(
                    function(response) {
                        if (response && response.data && response.data.data) {
                            $scope.mc.getlogDetails("Debug", 'Response:Success');
                            var loggedUserModel = homeFactory.getUserUI(response.data.data);
                            $scope.mc.$storage.maxAge = 14400;
                            if (loggedUserModel.FullName)
                                $scope.mc.loginModel.FullName = loggedUserModel.FullName;

                            $scope.mc.$storage.LoginUserId = loggedUserModel.UserId;
                            $scope.mc.loginModel.UserName = loggedUserModel.UserId;
                            $scope.mc.$storage.LastActiveTime = new Date().getTime();
                            $cookies.put($location.search().server + "_" + loggedUserModel.UserId + "_" + "XSRF-TOKEN", $cookies.get("XSRF-TOKEN"), { 'expires': updateCookieExpiary($scope.mc.$storage.maxAge), 'path': '/' });
                            InitalizePageData(StateName, Dtype);
                        } else {

                            redirectToLogin();
                        }

                    },
                    function(response) {

                        redirectToLogin();
                    }
                );


            }

            function redirectToLogin() {

                if ((!$cookies.get('XSRF-TOKEN') || $cookies.get('XSRF-TOKEN') == '') && $location.search() && $location.search().server && $location.search().userid) {
                    var pagename = '';
                    if ($state.current.name === 'applyhome.ApplyTemplates')
                        pagename = 'ApplyTemplates/Apply';
                    else
                        pagename = 'ApplyTemplates/Properties'

                    var ApiUrl = masterFactory.getLoginPageAPI(true, $location.search(), pagename);
                    // $scope.mc.$storage.IsVirtualUserLogin = "redirected";

                    window.location.href = ApiUrl;
                }
            }



            vmApply.GetParams = function() {
                

                var ActualUserName = $location.search().userid;
                if ($scope.mc.loginModel.UserName && $scope.mc.loginModel.UserName != '') {
                    ActualUserName = $scope.mc.loginModel.UserName;

                }

                if (!$scope.mc.$storage.maxAge)
                    $scope.mc.$storage.maxAge = '14400';

                $scope.mc.$storage.IsVirtualUserLogin = "redirected";

                $scope.mc.$storage.StatetoGO = $state.current.name;
                if ($location.search() && $location.search().server && $location.search().userid) {
                    //resizewin('550;265');
                    if ($location.search() && $location.search().server && $location.search().userid && $cookies.get($location.search().server + "_" + ActualUserName + "_" + "XSRF-TOKEN")) {

                        $scope.mc.loginModel.UserName = ActualUserName;
                        $scope.mc.$storage.LoginUserId = ActualUserName;
                        $cookies.put("XSRF-TOKEN", $cookies.get($location.search().server + "_" + ActualUserName + "_" + "XSRF-TOKEN"), { 'expires': updateCookieExpiary($scope.mc.$storage.maxAge), 'path': '/' });


                    } else if ($cookies.get("XSRF-TOKEN") && !$scope.mc.loginModel.UserName && $location.search() && $location.search().userid && $cookies.get("X-Login-Type") != 'saml') {
                        $scope.mc.loginModel.UserName = $location.search().userid;
                        $scope.mc.$storage.LoginUserId = $scope.mc.loginModel.UserName;
                        $cookies.put("XSRF-TOKEN", '', { 'expires': updateCookieExpiary($scope.mc.$storage.maxAge), 'path': '/' });

                    }
                }


                if ($location.search() && $location.search().id  && $location.search().type) {
                    vmApply.selectedLibrary = $location.search().dbname;
                    var Objid = $location.search().dbname + '!' + $location.search().id;
                    if ($location.search().id.indexOf('!') != -1) {
                        var data = $location.search().id.split('!');
                        vmApply.selectedLibrary = data[0];
                        Objid = $location.search().id;
                    } 
                    $scope.mc.SetData(Objid, $location.search().type)
                } else {
                    $mdDialog.show(
                        $mdDialog.alert()
                        .parent(angular.element(document.body))
                        .clickOutsideToClose(true)
                        .title('Warning')
                        .textContent('Some required parmeters seems to be missing in the url Please Contact Administrator.')
                        .ariaLabel('Warning')
                        .ok('OK')
                    );
                }
            };

            $scope.mc.SetData = function(Dfolderid, Dtype) {

                vmApply.SelectedType = Dtype;

                if ($state.current.name != 'applyhome.ApplyTemplates') {
                    if (vmApply.SelectedType == 'imTypeDocumentSearchFolder') {
                        vmApply.SelectedType = 'search';
                    } else if (vmApply.SelectedType == 'imTypeDocumentFolder') {
                        vmApply.SelectedType = 'regular';
                    } else if (vmApply.SelectedType == 'imTypeTab') {
                        vmApply.SelectedType = 'tab';
                    } else {
                        vmApply.SelectedType = 'ws';
                    }
                }


                $scope.mc.objectDet.type = vmApply.SelectedType;


                $scope.mc.objectDet.name = Dfolderid;                
                $scope.mc.objectDet.wid = Dfolderid;
                if ($scope.mc.objectDet.type == 'imTypeDocumentSearchFolder') {
                    vmApply.tabTitle = 'Search folders';
                }
                if ($scope.mc.objectDet.type == 'imTypeDocumentFolder') {

                    vmApply.tabTitle = 'Folders';
                }
                if ($scope.mc.objectDet.type == 'imTypeTab') {
                    $scope.mc.objectDet.type = 'imTypeDocumentTab'
                    vmApply.tabTitle = 'Tabs';
                }
                if ($state.current.name == 'applyhome.ApplyTemplates') {
                    vmApply.ProgressMessage = 'Identifying adhoc folder and flexible folder';//Getting match fields & other basic details';
                } else {
                    vmApply.ProgressMessage = 'Getting the selected item details';
                }
                Initialize($state.current.name, vmApply.SelectedType);


            }


            function Initialize(StateName, Dtype) {

                showProgressDialog();
                var settings = masterFactory.masterInitailValues();
                settings.then(function (response) {
                    baseUrl = response.apiurl;
                    baseIMCCApiUrl = response.imccapiurl;
                    baseHost = response.hostbase;
                    if ((!$cookies.get('XSRF-TOKEN') || $cookies.get('XSRF-TOKEN') == '') && $location.search() && $location.search().server && $location.search().userid) {
                        redirectToLogin(StateName);
                    } else if ($cookies.get('X-Login-Type') === 'saml') {
                        samlLogin(StateName, Dtype);
                    } else {
                        getUserDetails().then(function () {
                            InitalizePageData(StateName, Dtype);
                        });
                    }
                    registerSessionTimeOut();
                });
            }


            function InitalizePageData(StateName, Dtype) {

                getCaptions();

                if (StateName == 'applyhome.ApplyTemplates') {
                    vmApply.selectedItem = undefined;
                    getMatchFields();
                    getChildrenOfSelectedFolder();
                    getFolderPath();
                } else if (StateName == 'applyhome.ObjectProperties') {
                    vmApply.ProfileTitle = undefined;

                    getProfileOfSelectedFolder(Dtype, true);
                    GetSecurityInfo();
                    GenerateWatchForGroupSearch();
                    vmApply.onGroupUserScroll = onGroupUserScroll;

                }
            }



            $scope.ViewClicked = ViewClickedItem;

            vmApply.changeData = changeFolderSelection;
            vmApply.ApplyTemplate = ApplyTemplates;
            vmApply.closeWindow = function(actionType) {



                if ($location.search() && $location.search().protocol && $location.search().protocol === 'postmessage') {

                    var message = {
                        type: actionType,
                        data: JSON.stringify(vmApply.NewItemsList)
                    };

                    if ($window.parent)
                        $window.parent.postMessage(message, '*');

                } else {
                    try {
                        closewin(vmApply.NewFlist);
                    } catch (err) {}
                }

                $scope.mc.onError = false;

                //resetAllValues();
                //redirectToLogin();
                //$state.go($state.current.name, $location.search(), { reload: true, inherit: false });
            };
            vmApply.GetParams();


            function MembersSearchClick() {
                if (groupMembersSearchTimeOut)
                    $timeout.cancel(groupMembersSearchTimeOut);
                groupMembersReqModel = homeFactory.requestModelInstance();
                groupMembersReqModel.pagenumber = 1;
                vmApply.groupMembers = [];
                getGroupMembers();
            }

            function MembersClearSearchClick() {
                isgroupMembersInstantSearch = true;
                vmApply.groupMembersList.SearchText = '';
            }



            function GenerateWatchForGroupSearch() {
                $scope.$watch(function() {
                    return vmApply.groupMembersList.SearchText;
                }, function(val) {
                    if (vmApply.groupMembersList.SearchText.length > 0) {
                        isgroupMembersSearchTextDirty = true;
                    }
                    if (groupMembersSearchTimeOut)
                        $timeout.cancel(groupMembersSearchTimeOut);

                    if (isgroupMembersInstantSearch) {
                        isgroupMembersInstantSearch = false;
                        vmApply.groupMembersList.SearchClick();
                    } else {
                        groupMembersSearchTimeOut = $timeout(function() {
                            if (isgroupMembersSearchTextDirty) {
                                vmApply.groupMembersList.SearchClick();
                            }
                        }, 2000);
                    }
                }, true);
                $timeout(function () { $mdDialog.hide(); }, 3000);
            }

            function onGroupUserScroll() {
                if (vmApply.grouptotalCount > vmApply.groupMembers.length) {
                    groupMembersReqModel.pagenumber += 1;
                    getGroupMembers()
                }
            }

            function getGroupMembers() {
                groupMembersReqModel.libraryName = vmApply.selectedLibrary;
                groupMembersReqModel.searchText = vmApply.groupMembersList.SearchText;

                var apiUrl = applyFactory.getGroupUsersAPI(groupMembersReqModel, vmApply.GroupName);
                $scope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(apiUrl));

                var promise = homeService.getData(apiUrl, '');
                promise.then(function(response) {
                    if (response.status === 200) {

                        if (vmApply.groupMembersList.SearchText == '') {
                            if (response.data.total_count > 0) {
                                vmApply.GroupMembersHeaderText = vmApply.GroupName + " have " + response.data.total_count + " members";
                            } else {
                                vmApply.GroupMembersHeaderText = "Group Members"
                            }
                        }
                        vmApply.grouptotalCount = response.data.total_count;


                        angular.forEach(response.data.data, function(userItem) {

                            getUserPhoto(applyFactory.getUserUI(userItem)).then(function(responseItem) {
                                vmApply.groupMembers.push(responseItem);
                            });


                        });


                    } else {
                        $scope.mc.getlogDetails("Error", 'Method:GET;URL:' + JSON.stringify(apiUrl) + ",Response:" + JSON.stringify(response));

                    }
                }, function(response) {
                    $scope.mc.getlogDetails("Error", 'Method:GET;URL:' + JSON.stringify(apiUrl) + ",Response:" + JSON.stringify(response));

                });
            }


            function changeFolderSelection(folder, event) {
                if (folder.NVPs.IMCC_IsOptional == 'false' || vmApply.IsPreview)
                    return;
                folder.Selected = !folder.Selected;
                if (event)
                    event.stopPropagation();
            }

            function ViewClickedItem(Item) {
                if (Item.Type != 'user') {
                    vmApply.GroupView = true;

                    vmApply.groupMembersList.SearchText = '';
                    vmApply.groupMembers = [];
                    vmApply.GroupName = Item.Id;
                    groupMembersReqModel = homeFactory.requestModelInstance();
                    vmApply.grouptotalCount = 0;
                    getGroupMembers();
                }
            }

            function resetAllValues() {
                $rootScope.checkReadyToChangeState = null;
                $scope.mc.getlogDetails("Debug", 'Method:GET;URL: Logout');

                delete $scope.mc.$storage.LoginUserId;
                delete $scope.mc.$storage.toState;
                vmApply.selectedLibrary = '';
                $scope.selectedLibrary = '';

                $scope.mc.loginModel.UserName = '';
                $scope.mc.loginModel.Password = '';
                $cookies.put("XSRF-TOKEN", '', { 'path': '/' });
                if (angular.isDefined($scope.mc.loginModel.UserSessionTimeOut)) {
                    $interval.cancel($scope.mc.loginModel.UserSessionTimeOut);
                    $scope.mc.loginModel.UserSessionTimeOut = null;
                }
                if (UserSessionTimer) {
                    $timeout.cancel(UserSessionTimer);
                    UserSessionTimer = null;
                }
                sessionTime = -1;
            }

            $scope.mc.loginModel.UserSessionTimeOut = $interval(function() {
                if (!UserSessionTimer && $scope.mc.$storage.maxAge > 0) {
                    UserSessionTimer = $timeout(function() {
                        var mdAlert = $mdDialog.alert({
                            parent: angular.element(document.body),
                            clickOutsideToClose: true,
                            title: 'Warning',
                            textContent: 'User session expired.',
                            ariaLabel: 'Warning',
                            ok: 'OK'
                        });
                        $mdDialog
                            .show(mdAlert)
                            .finally(function() {
                                mdAlert = null;
                                vm.Logout();
                            });
                    }, $scope.mc.$storage.maxAge * 1000);
                }
            }, 1000 * 60);




            $scope.$state = $state;
            $scope.appsVar = homeFactory.applicationVariables;
            $scope.ScrollCounter = false;
            $scope.animationUrl = 'Images/loading.gif';

         
            function getUserDetails() {

                var defer = $q.defer();
                $scope.mc.loginModel.FullName = '';
                $scope.mc.getlogDetails("Debug", 'Method:GET; Action: ViewUser ;');
                var apiUrl = homeFactory.getSingleUserAPI();
                var promise = homeService.getData(apiUrl, '');
                promise.then(function(response) {
                    if (response && response.data && response.data.data) {
                        $scope.mc.getlogDetails("Debug", 'Response:Success');


                        var loggedUserModel = homeFactory.getUserUI(response.data.data);
                        $scope.mc.loginModel.UserName = loggedUserModel.UserId;
                        $scope.mc.$storage.LoginUserId = loggedUserModel.UserId;
                        if (loggedUserModel.FullName)
                            $scope.mc.loginModel.FullName = loggedUserModel.FullName.trim();



                    }
                    defer.resolve($scope.mc.loginModel.UserName);
                }, function(response) {
                    defer.resolve(response);
                    $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                });

                return defer.promise;
            }

            function registerSessionTimeOut() {
                var seesionTimoutWatch = $scope.$watch(function() { return $cookies.sessiontimeout; }, function(newVal, oldVal) {
                    if ($cookies.sessiontimeout && $cookies.sessiontimeout === 401) {
                        seesionTimoutWatch();
                        $cookies.sessiontimeout = null;
                        resetAllValues();
                        redirectToLogin();

                    } else if ($cookies.sessiontimeout) {
                        $cookies.sessiontimeout = null;
                    }
                });

            }

            vmApply.deSelect = function(item) {

            };

            vmApply.onSelect = function(item) {
                $scope.mc.objectDet.Template = item.Name;
                vmApply.hasChildren = true;
                vmApply.foldersList = []
                vmApply.ItemsInSelectedLevel = [];
                var objtype = 'regular';
                if ($scope.mc.objectDet.type == 'imTypeDocumentSearchFolder') {
                    objtype = 'search';
                }
                if ($scope.mc.objectDet.type == 'imTypeDocumentFolder') {
                    objtype = 'regular';
                }
                if ($scope.mc.objectDet.type == 'imTypeDocumentTab') {
                    objtype = 'tab';
                }

                var promiseChild = GetOptionalFolders(item.Id, $scope.mc.objectDet.level, objtype, 0, {});
                promiseChild.then(function (response) {
                   
                      
               
                    $timeout(function () { $mdDialog.hide(); RedirecttoAdhoc(item.Id); });

                }, function (response) {

                    vmApply.foldersList = [];
                    $timeout(function () { $mdDialog.hide(); RedirecttoAdhoc(item.Id); });
                   
                })
                $timeout(function() { $mdDialog.hide(); }, 3000);
            };

            function RedirecttoAdhoc(parentId){

                if (vmApply.ItemsInSelectedLevel.length == 0) {
                    
                    if (vmApply.workSpaceUIModel.NVPs.TemplateId && vmApply.workSpaceUIModel.NVPs.TemplateId === vmApply.selectedItem.Id) {
                        vmApply.DeterMine = false;
                        if ($location.search() && $location.search().server && $location.search().userid) {
                            resizewin('550;265');
                            var params = { parentid: $scope.mc.objectDet.wid, type: $location.search().type, protocol: 'external' }
                            $state.go('adhocFolders.Create', params);
                        } else {
                            var params = $location.search();
                            params.parentid = $scope.mc.objectDet.wid;
                            $state.go('adhocFolders.Create', params);
                        }
                        //vmApply.hasChildren = false;
                    } else if (vmApply.workSpaceUIModel.NVPs.TemplateId != vmApply.selectedItem.Id) {
                        
                        vmApply.DeterMine = true;
                    }
                } else {
                    
                    vmApply.DeterMine = true;
                }

            }

            function RemoveExistingFolders(items) {
                angular.forEach(items, function(item) {
                    var ItemArray = ($filter('filter')(vmApply.SelectedChildrens, { lowerName: item.Name.toLowerCase() }, true));
                    if (ItemArray.length == 0) {
                        vmApply.foldersList.push(item);
                    }
                });
            }

            function removeAlreadyCreatedFolders(folderTemplate) {
                var itemRemoved = false;
                var iCount = 0;

                for (iCount = 0; iCount < vmApply.SelectedChildrens.length; iCount++) {
                    var createdFolder = vmApply.SelectedChildrens[iCount];
                    if (createdFolder.NVPs && 'FolderTemplateId' in createdFolder.NVPs) {
                        if (createdFolder.NVPs.FolderTemplateId === folderTemplate.Id) {
                            itemRemoved = true;
                            break;
                        }
                    }
                    createdFolder = null;
                }
                if (!itemRemoved) {
                    var data = [];
                    data.push(folderTemplate);
                    var itemArray = ($filter('filter')(data, { path: vmApply.PathString }));
                    if (itemArray.length > 0) {
                        RemoveExistingFolders(itemArray);
                    }
                }
            }

            vmApply.LoadPreview = function() {

                vmApply.isPreview = true;
                vmApply.FoldersPreview = [];
                var objtype = 'regular';
                if ($scope.mc.objectDet.type == 'imTypeDocumentSearchFolder') {
                    objtype = 'search';
                }
                if ($scope.mc.objectDet.type == 'imTypeDocumentFolder') {
                    objtype = 'regular';
                }
                if ($scope.mc.objectDet.type == 'imTypeDocumentTab') {
                    objtype = 'tab';
                }
                var selectedlength = ($filter('filter')(vmApply.foldersList, { Selected: true }, true)).length;
                var deferedarry = [];
                vmApply.ProgressMessage = 'Loading preview:0 of ' + selectedlength + 'completed';
                showProgressDialog();
                var finishcount = 1;
                angular.forEach(vmApply.foldersList, function(item) {
                    if (item.Selected) {
                        var dataQueue = $q.defer();
                        var copyOfSelectedItem = angular.copy(item)
                        deferedarry.push(dataQueue.promise);
                        GetChildrens(item.Id, objtype, copyOfSelectedItem)
                            .then(function(responsedata) {
                                dataQueue.resolve(responsedata);

                                vmApply.ProgressMessage = 'Loading preview:' + finishcount + ' of ' + selectedlength + 'completed';
                                finishcount = finishcount + 1;

                                $timeout(function() { $mdDialog.hide(); });
                                if (finishcount != selectedlength)
                                    showProgressDialog();


                            });
                        vmApply.FoldersPreview.push(copyOfSelectedItem);
                    }
                });

                $q.all(deferedarry).then(function() {

                    $timeout(function() { $mdDialog.hide(); });
                });
            };

            function GetChildrens(parentId, objtype, returnData) {
                var deferred = $q.defer();

                if (!returnData.SubFolders) {
                    returnData.SubFolders = [];
                }
                var requestObj = homeFactory.requestModelInstance();
                requestObj.Id = parentId;
                var apiUrl = applyFactory.getAPIUrl('GETFOLDERSFROMWORKSPCE', requestObj);
                $scope.mc.getlogDetails("Debug", 'Method:GET;URL' + JSON.stringify(apiUrl));
                var promise = applyService.getData(apiUrl, "")
                promise.then(function(response) {
                    if (response["status"] == 200 && response.data.data.length > 0) {
                        $scope.mc.getlogDetails("Info", "Received Folder details.");

                        angular.forEach(response.data.data, function(folder) {

                            var folderUIModel = applyFactory.getFolderUI(folder);
                            folderUIModel.Selected = false;

                            if (vmApply.selectedItem.NVPs && vmApply.selectedItem.NVPs.IMCC_Allow_Prefix) {
                                ApplyPrefixSufix(folderUIModel).then(function(response) {
                                    folderUIModel = response;
                                    var profileInfo = getProfileOfFolder(folderUIModel.FolderType, folderUIModel.Id);
                                    profileInfo.then(function(responseprofile) {

                                        if (folderUIModel.FolderType == 'search') {
                                            folderUIModel["searchprofile"] = responseprofile;
                                        }
                                        if (folderUIModel.FolderType == 'regular') {
                                            folderUIModel["profile"] = responseprofile;
                                        }

                                    });

                                    var promiseNVP = getNameValuePairs(folderUIModel.Id);
                                    promiseNVP.then(function(response) {
                                        folderUIModel.NVPs = response.data;
                                        if (folderUIModel.NVPs.IMCC_IsOptional != undefined && folderUIModel.NVPs.IMCC_IsOptional == 'false')
                                            folderUIModel.Selected = true;
                                        else
                                            folderUIModel.NVPs.IMCC_IsOptional = 'true';


                                        folderUIModel.SubFolders = [];
                                        if (folderUIModel.FolderType == objtype) {

                                            if (folderUIModel.HasSubfolders) {
                                                var promiseChild = GetChildrens(folderUIModel.Id, objtype, folderUIModel);
                                                promiseChild.then(function(responsedata) {
                                                    if (!returnData.SubFolders)
                                                        returnData.SubFolders = [];
                                                    if (folderUIModel.NVPs.IMCC_IsOptional != undefined && folderUIModel.NVPs.IMCC_IsOptional == 'false')
                                                        returnData.SubFolders.push(folderUIModel);

                                                    deferred.resolve(returnData);
                                                }, function(response) {
                                                    if (returnData != {}) {
                                                        if (!returnData.SubFolders)
                                                            returnData.SubFolders = [];
                                                        if (folderUIModel.NVPs.IMCC_IsOptional != undefined && folderUIModel.NVPs.IMCC_IsOptional == 'false')
                                                            returnData.SubFolders.push(folderUIModel);
                                                    }
                                                    deferred.resolve(returnData);
                                                })
                                            } else {

                                                if (folderUIModel.NVPs.IMCC_IsOptional != undefined && folderUIModel.NVPs.IMCC_IsOptional == 'false')
                                                    returnData.SubFolders.push(folderUIModel);

                                                deferred.resolve(returnData);
                                            }
                                        } else {
                                            deferred.resolve(returnData);
                                        }

                                    }, function(response) {

                                        deferred.resolve([]);
                                        $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));

                                    });
                                })
                            } else {
                                var profileInfo = getProfileOfFolder(folderUIModel.FolderType, folderUIModel.Id);
                                profileInfo.then(function(responseprofile) {

                                    if (folderUIModel.FolderType == 'search') {
                                        folderUIModel["searchprofile"] = responseprofile;
                                    }
                                    if (folderUIModel.FolderType == 'regular') {
                                        folderUIModel["profile"] = responseprofile;
                                    }

                                });

                                var promiseNVP = getNameValuePairs(folderUIModel.Id);
                                promiseNVP.then(function(response) {
                                    folderUIModel.NVPs = response.data;
                                    if (folderUIModel.NVPs.IMCC_IsOptional != undefined && folderUIModel.NVPs.IMCC_IsOptional == 'false')
                                        folderUIModel.Selected = true;
                                    else
                                        folderUIModel.NVPs.IMCC_IsOptional = 'true';


                                    folderUIModel.SubFolders = [];
                                    if (folderUIModel.FolderType == objtype) {

                                        if (folderUIModel.HasSubfolders) {
                                            var promiseChild = GetChildrens(folderUIModel.Id, objtype, folderUIModel);
                                            promiseChild.then(function(responsedata) {
                                                if (!returnData.SubFolders)
                                                    returnData.SubFolders = [];
                                                if (folderUIModel.NVPs.IMCC_IsOptional != undefined && folderUIModel.NVPs.IMCC_IsOptional == 'false')
                                                    returnData.SubFolders.push(folderUIModel);

                                                deferred.resolve(returnData);
                                            }, function(response) {
                                                if (returnData != {}) {
                                                    if (!returnData.SubFolders)
                                                        returnData.SubFolders = [];
                                                    if (folderUIModel.NVPs.IMCC_IsOptional != undefined && folderUIModel.NVPs.IMCC_IsOptional == 'false')
                                                        returnData.SubFolders.push(folderUIModel);
                                                }
                                                deferred.resolve(returnData);
                                            })
                                        } else {

                                            if (folderUIModel.NVPs.IMCC_IsOptional != undefined && folderUIModel.NVPs.IMCC_IsOptional == 'false')
                                                returnData.SubFolders.push(folderUIModel);

                                            deferred.resolve(returnData);
                                        }
                                    } else {
                                        deferred.resolve(returnData);
                                    }

                                }, function(response) {

                                    deferred.resolve([]);
                                    $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));

                                });

                            }

                        });


                    } else {

                        deferred.resolve([]);
                        $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));

                    }


                }, function(response) {

                    deferred.resolve([]);
                    $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));

                });

                return deferred.promise;
            }

            function GetOptionalFolders(parentId, parentlevel, objtype, childlevel, returnData) {

                var finaldeferred = $q.defer();

                var deferredarray = [];
                var requestObj = homeFactory.requestModelInstance();
                requestObj.Id = parentId;
                var apiUrl = applyFactory.getAPIUrl('GETFOLDERSFROMWORKSPCE', requestObj);
                $scope.mc.getlogDetails("Debug", 'Method:GET;URL' + JSON.stringify(apiUrl));
                var promise = applyService.getData(apiUrl, "")
                promise.then(function(response) {
                    if (response["status"] == 200 && response.data.data.length > 0) {
                        $scope.mc.getlogDetails("Info", "Received Folder details.");
                        if (vmApply.selectedItem.Id === parentId) {                           
                            vmApply.hasChildren = true;
                        }
                        angular.forEach(response.data.data, function(folder) {
                            var deferred = $q.defer();
                            deferredarray.push(deferred.promise);
                            var folderUIModel = applyFactory.getFolderUI(folder);
                            folderUIModel.Selected = false;

                            if (vmApply.selectedItem.NVPs && vmApply.selectedItem.NVPs.IMCC_Allow_Prefix) {
                                ApplyPrefixSufix(folderUIModel).then(function(responsefolder) {
                                    var profileInfo = getProfileOfFolder(folderUIModel.FolderType, folderUIModel.Id);
                                    profileInfo.then(function(responseprofile) {

                                        if (folderUIModel.FolderType == 'search') {
                                            folderUIModel["searchprofile"] = responseprofile;
                                        }
                                        if (folderUIModel.FolderType == 'regular') {
                                            folderUIModel["profile"] = responseprofile;
                                        }

                                    });

                                    var promiseNVP = getNameValuePairs(folderUIModel.Id);
                                    promiseNVP.then(function(response) {
                                        folderUIModel.NVPs = response.data;
                                        if (folderUIModel.NVPs.IMCC_IsOptional != undefined && folderUIModel.NVPs.IMCC_IsOptional == 'false')
                                            folderUIModel.Selected = true;
                                        else
                                            folderUIModel.NVPs.IMCC_IsOptional = 'true';

                                    });

                                    if (!returnData.path) {
                                        folderUIModel.path = 'root>';
                                    } else {
                                        folderUIModel.path = returnData.path + returnData.Name +returnData.FolderType+ '>';
                                    }
                                    folderUIModel.SubFolders = [];
                                    if (parseInt(parentlevel) == childlevel && folderUIModel.path == vmApply.PathString) {
                                        
                                        vmApply.ItemsInSelectedLevel.push(folderUIModel);  
                                    }
                                    if (parseInt(parentlevel) == childlevel && folderUIModel.FolderType === objtype) {

                                        removeAlreadyCreatedFolders(folderUIModel);
                                        /*var data = [];
                                        data.push(folderUIModel);
                                        var ItemArray = ($filter('filter')(data, { path: vmApply.PathString }));
                                        if (ItemArray.length > 0) {

                                            RemoveExistingFolders(ItemArray);
                                        }*/

                                        deferred.resolve(folderUIModel);
                                    } else if (parseInt(parentlevel) >= childlevel) {
                                        if (folderUIModel.HasSubfolders) {
                                            var promiseChild = GetOptionalFolders(folderUIModel.Id, parentlevel, objtype, childlevel + 1, folderUIModel);
                                            promiseChild.then(function(responsedata) {

                                                if (returnData != {}) {
                                                    if (!returnData.children)
                                                        returnData.SubFolders = [];
                                                    if (folderUIModel.FolderType === objtype)
                                                        returnData.SubFolders.push(folderUIModel);
                                                }
                                                deferred.resolve(folderUIModel);
                                            });
                                        } else {
                                            if (returnData != {}) {
                                                if (!returnData.SubFolders)
                                                    returnData.SubFolders = [];
                                                if (folderUIModel.FolderType === objtype)
                                                    returnData.SubFolders.push(folderUIModel);
                                            }
                                            deferred.resolve(folderUIModel);
                                        }
                                    }
                                });

                            } else {
                                var profileInfo = getProfileOfFolder(folderUIModel.FolderType, folderUIModel.Id);
                                profileInfo.then(function(responseprofile) {

                                    if (folderUIModel.FolderType == 'search') {
                                        folderUIModel["searchprofile"] = responseprofile;
                                    }
                                    if (folderUIModel.FolderType == 'regular') {
                                        folderUIModel["profile"] = responseprofile;
                                    }

                                });

                                var promiseNVP = getNameValuePairs(folderUIModel.Id);
                                promiseNVP.then(function(response) {
                                    folderUIModel.NVPs = response.data;
                                    if (folderUIModel.NVPs.IMCC_IsOptional != undefined && folderUIModel.NVPs.IMCC_IsOptional == 'false')
                                        folderUIModel.Selected = true;
                                    else
                                        folderUIModel.NVPs.IMCC_IsOptional = 'true';

                                });

                                if (!returnData.path) {
                                    folderUIModel.path = 'root>';
                                } else {
                                    folderUIModel.path = returnData.path + returnData.Name + '>';
                                }
                                folderUIModel.SubFolders = [];
                                if (parseInt(parentlevel) == childlevel && folderUIModel.path == vmApply.PathString) {
                                    vmApply.ItemsInSelectedLevel.push(folderUIModel);
                                }

                                if (parseInt(parentlevel) == childlevel && folderUIModel.FolderType === objtype) {

                                    removeAlreadyCreatedFolders(folderUIModel);
                                    /*var data = [];
                                    data.push(folderUIModel);
                                    var ItemArray = ($filter('filter')(data, { path: vmApply.PathString }));
                                    if (ItemArray.length > 0) {

                                        RemoveExistingFolders(ItemArray);
                                    }*/

                                    deferred.resolve(folderUIModel);
                                } else if (parseInt(parentlevel) >= childlevel) {
                                    if (folderUIModel.HasSubfolders) {
                                        var promiseChild = GetOptionalFolders(folderUIModel.Id, parentlevel, objtype, childlevel + 1, folderUIModel);
                                        promiseChild.then(function(responsedata) {

                                            if (returnData != {}) {
                                                if (!returnData.children)
                                                    returnData.SubFolders = [];
                                                if (folderUIModel.FolderType === objtype)
                                                    returnData.SubFolders.push(folderUIModel);
                                            }
                                            deferred.resolve(folderUIModel);
                                        });
                                    } else {
                                        if (returnData != {}) {
                                            if (!returnData.SubFolders)
                                                returnData.SubFolders = [];
                                            if (folderUIModel.FolderType === objtype)
                                                returnData.SubFolders.push(folderUIModel);
                                        }
                                        deferred.resolve(folderUIModel);
                                    }
                                }

                            }


                            $q.all(deferredarray).then(function() {
                                finaldeferred.resolve();
                            });

                        });


                    } else {

                
                        finaldeferred.resolve();
                        $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));

                    }


                }, function(response) {

                    finaldeferred.resolve();
                    $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));

                });

                return finaldeferred.promise;
            }

            function ApplyPrefixSufix(folder, IMCC_Allow_Prefix) {



                var finalDeferd = $q.defer();
                var defferedArray = [];
                if (vmApply.selectedItem.NVPs.IMCC_Name_Prefix) {
                    var defererednorm = $q.defer();
                    defferedArray.push(defererednorm.promise);
                    do {

                        if (vmApply.selectedItem.NVPs.IMCC_Name_Prefix.search(/#C([1-9]|[1][0-9]|[2][09]|[3][0])Alias#/i) != -1) {
                            var matches = vmApply.selectedItem.NVPs.IMCC_Name_Prefix.match(/#C([1-9]|[1][0-9]|[2][09]|[3][0])Alias#/i)


                            var mdata = matches[0].match(/\d+/g);
                            var customValue = 'Custom' + mdata[0]
                            if (vmApply.workSpaceUIModel[customValue])
                                vmApply.selectedItem.NVPs.IMCC_Name_Prefix = vmApply.selectedItem.NVPs.IMCC_Name_Prefix.replace(matches[0], vmApply.workSpaceUIModel[customValue]);
                            else
                                vmApply.selectedItem.NVPs.IMCC_Name_Prefix = vmApply.selectedItem.NVPs.IMCC_Name_Prefix.replace(matches[0], '');


                        }

                    } while ((vmApply.selectedItem.NVPs.IMCC_Name_Prefix.search(/#C([1-9]|[1][0-9]|[2][09]|[3][0])Alias#/i) != -1))
                    do {

                        if (vmApply.selectedItem.NVPs.IMCC_Name_Prefix.search(/#C([1-9]|[1][0-2]|[2][9]|[3][0])DESCR#/i) != -1) {
                            var deferd1 = $q.defer();
                            defferedArray.push(deferd1.promise);
                            var matches = vmApply.selectedItem.NVPs.IMCC_Name_Prefix.match(/#C([1-9]|[1][0-2]|[2][9]|[3][0])DESCR#/i)
                            var mdata = matches[0].match(/\d+/g);
                            var requestObj = {};

                            if (vmApply.workSpaceUIModel['Custom' + mdata[0]]) {
                                vmApply.selectedItem.NVPs.IMCC_Name_Prefix = vmApply.selectedItem.NVPs.IMCC_Name_Prefix.replace(matches[0], '#C' + mdata[0] + 'DESCRIPTION#');
                                requestObj.alias = vmApply.workSpaceUIModel['Custom' + mdata[0]];
                                requestObj.type = '';
                                if (mdata[0] == '2')
                                    requestObj.type = 'custom1/' + vmApply.workSpaceUIModel['Custom1'] + '/';
                                if (mdata[0] == '30')
                                    requestObj.type = 'custom29/' + vmApply.workSpaceUIModel['Custom29'] + '/';
                                requestObj.type += 'custom' + mdata[0];
                                var apiUrl = applyFactory.getAPIUrl('GETMETADATA', requestObj);
                                $scope.mc.getlogDetails("Debug", 'Method:GET;URL' + JSON.stringify(apiUrl));
                                var promise = applyService.getData(apiUrl, "")
                                promise.then(function(response) {
                                    if (response["status"] == 200 && response.data && response.data.data) {

                                        vmApply.selectedItem.NVPs.IMCC_Name_Prefix = vmApply.selectedItem.NVPs.IMCC_Name_Prefix.replace('#C' + mdata[0] + 'DESCRIPTION#', response.data.data['description'])
                                        deferd1.resolve(vmApply.selectedItem.NVPs.IMCC_Name_Prefix);
                                    }
                                });
                            } else {
                                vmApply.selectedItem.NVPs.IMCC_Name_Prefix = vmApply.selectedItem.NVPs.IMCC_Name_Prefix.replace(matches[0], '');
                                deferd1.resolve(vmApply.selectedItem.NVPs.IMCC_Name_Prefix);
                            }



                        }


                    } while (vmApply.selectedItem.NVPs.IMCC_Name_Prefix.search(/#C([1-9]|[1][0-2]|[2][9]|[3][0])DESCR#/i) != -1);
                    do {
                        if (vmApply.selectedItem.NVPs.IMCC_Name_Prefix.search(/#USERID#/i) != -1) {
                            repeat = true;
                            var matches = vmApply.selectedItem.NVPs.IMCC_Name_Prefix.match(/#USERID#/i)
                            vmApply.selectedItem.NVPs.IMCC_Name_Prefix = vmApply.selectedItem.NVPs.IMCC_Name_Prefix.replace(matches[0], $scope.mc.loginModel.UserName)


                        }
                    } while ((vmApply.selectedItem.NVPs.IMCC_Name_Prefix.search(/#USERID#/i) != -1));

                    do {
                        if (vmApply.selectedItem.NVPs.IMCC_Name_Prefix.search(/#USERFULLNAME#/i) != -1) {

                            var matches = vmApply.selectedItem.NVPs.IMCC_Name_Prefix.match(/#USERFULLNAME#/i)
                            vmApply.selectedItem.NVPs.IMCC_Name_Prefix = vmApply.selectedItem.NVPs.IMCC_Name_Prefix.replace(matches[0], $scope.mc.loginModel.FullName);

                        }
                    } while ((vmApply.selectedItem.NVPs.IMCC_Name_Prefix.search(/#USERFULLNAME#/i) != -1));

                    do {
                        if (vmApply.selectedItem.NVPs.IMCC_Name_Prefix.search(/#FOLDERNAME#/i) != -1) {

                            var matches = vmApply.selectedItem.NVPs.IMCC_Name_Prefix.match(/#FOLDERNAME#/i)
                            vmApply.selectedItem.NVPs.IMCC_Name_Prefix = vmApply.selectedItem.NVPs.IMCC_Name_Prefix.replace(matches[0], folder.Name);

                        }
                    } while ((vmApply.selectedItem.NVPs.IMCC_Name_Prefix.search(/#FOLDERNAME#/i) != -1));

                    defererednorm.resolve(vmApply.selectedItem.NVPs.IMCC_Name_Prefix);
                }


                $q.all(defferedArray).then(function() {
                    IMCC_Allow_Prefix = vmApply.selectedItem.NVPs.IMCC_Allow_Prefix;
                    if (IMCC_Allow_Prefix == "2") {} else if (IMCC_Allow_Prefix == "1") {
                        folder.Name = folder.Name + vmApply.selectedItem.NVPs.IMCC_Name_Prefix;
                    } else if (IMCC_Allow_Prefix == "0") {
                        folder.Name = vmApply.selectedItem.NVPs.IMCC_Name_Prefix + folder.Name;
                    }
                    finalDeferd.resolve(folder);
                });
                return finalDeferd.promise;


            }

            function getMatchFields() {

                if ((!$cookies.get('XSRF-TOKEN') || $cookies.get('XSRF-TOKEN') == '') && $location.search() && $location.search().server && $location.search().userid)
                    return;
                var apiUrl = applyFactory.getAPIUrl('GETMATCHFIELDS');
                $scope.mc.getlogDetails("Debug", 'Method:GET;URL' + JSON.stringify(apiUrl));

                var promise = applyService.getData(apiUrl, '');

                promise.then(function(response) {


                        if (response && response.data && response.data.data) {

                            var systemConfigUIModel = applyFactory.getMatchFields(response.data.data);
                            if (systemConfigUIModel.IMCC_OF_MATCHFIELDS) {
                                vmApply.MatchField = systemConfigUIModel.IMCC_OF_MATCHFIELDS.split(",");
                                if (vmApply.MatchField[0])
                                    vmApply.MatchField[0] = vmApply.MatchField[0].replace("improfile", "");
                                if (vmApply.MatchField[1])
                                    vmApply.MatchField[1] = vmApply.MatchField[1].replace("improfile", "");
                            }

                        }
                    },
                    function(response) {

                    });
            }

            function GetSecurityInfo() {

                var GETSecurity = 'SECURITYPROFILE';
                var body = { Id: $scope.mc.objectDet.wid };
                var apiUrl = applyFactory.getAPIUrl(GETSecurity, body);
                $scope.mc.getlogDetails("Debug", 'Method:GET;URL' + JSON.stringify(apiUrl));
                var promise = applyService.getData(apiUrl, "");
                promise.then(function(response) {

                        if (response && response.data && response.data.data) {
                            $scope.mc.getlogDetails("Debug", 'SecurityINFO' + JSON.stringify(response.data.data));

                            vmApply.SecurityModel = [];
                            angular.forEach(response["data"]["data"], function(item) {
                                var SecurityModel = applyFactory.getSecurityModelUI(item);
                                if (SecurityModel.Type == 'user') {
                                    SecurityModel.UserId = SecurityModel.Id;
                                    SecurityModel.FullName = SecurityModel.Name;
                                    getUserPhoto(SecurityModel).then(function(responseItem) {
                                        vmApply.SecurityModel.push(responseItem)
                                    });
                                } else {

                                    vmApply.SecurityModel.push(SecurityModel);
                                }
                            });



                        }
                    },
                    function(response) {

                    });


            }

            function getSecurity(parentId) {
                var deffered = $q.defer();
                var GETProfileURL = 'GETWORKSPACE';

                if (parentId && parentId != '') {
                    var body = { Id: parentId };
                    var apiUrl = applyFactory.getAPIUrl(GETProfileURL, body);

                    $scope.mc.getlogDetails("Debug", 'Method:GET;URL' + JSON.stringify(apiUrl));
                    var promise = applyService.getData(apiUrl, "");
                    promise.then(function(response) {

                            if (response && response.data && response.data.data) {
                                var parentObject = applyFactory.getFolderUI(response.data.data);
                                if (parentObject.DefaultSecurity === 'inherit') {
                                    getSecurity(parentObject.ParentId).then(function(security) {
                                        deffered.resolve(security);
                                    });

                                } else {

                                    deffered.resolve(parentObject.DefaultSecurity);
                                }




                            } else {
                                deffered.resolve('private');
                            }
                        },
                        function(response) {
                            deffered.resolve('private');
                        });
                } else {
                    deffered.resolve('private');
                }
                return deffered.promise;
            }

            function getProfileOfSelectedFolder(ftype) {

                var GETProfileURL = 'GETWORKSPACE';
                if (ftype == 'search') {
                    GETProfileURL = 'SEARCHPROFILE';
                }
                if (ftype == 'regular') {
                    GETProfileURL = 'FOLDERPROFILE';
                }

                if (ftype == 'tab') {
                    GETProfileURL = 'TABSPROFILE';
                }

                var body = { Id: $scope.mc.objectDet.wid };
                var apiUrl = applyFactory.getAPIUrl(GETProfileURL, body);

                $scope.mc.getlogDetails("Debug", 'Method:GET;URL' + JSON.stringify(apiUrl));
                var promise = applyService.getData(apiUrl, "");
                promise.then(function(response) {

                        if (response && response.data && response.data.data) {
                            $scope.mc.getlogDetails("Debug", 'SELECTEDITEM' + JSON.stringify(response.data.data));
                            vmApply.SelectedObject = applyFactory.getFolderUI(response.data.data);
                            // folderModel.ParentId = folderApiModel[CONST_TEMPLATE_FOLDER.ParentId];
                            vmApply.SelectedObject.UserPhotoText = '';
                            vmApply.SelectedObject.UserPhoto = '';
                            vmApply.SelectedObject.UserId = vmApply.SelectedObject.Owner;

                            vmApply.SelectedObject.IsInherit = vmApply.SelectedObject.DefaultSecurity === 'inherit';
                            if (!vmApply.SelectedObject.IsInherit)
                                vmApply.SelectedObject.Security = vmApply.SelectedObject.DefaultSecurity;
                            else {

                                getSecurity(vmApply.SelectedObject.ParentId).then(function(security) { //security
                                    vmApply.SelectedObject.Security = security;
                                })

                            }
                            applyService.getData(applyFactory.getUserDetail(vmApply.SelectedObject.Owner)).then(function(response) {
                                if (response && response.data && response.data.data) {
                                    var UserModel = applyFactory.getUserUI(response.data.data);

                                    vmApply.SelectedObject.FullName = UserModel.FullName;
                                    getUserPhoto(vmApply.SelectedObject).then(function(responseItem) {
                                        vmApply.SelectedObject.UserPhotoText = responseItem.UserPhotoText;
                                        vmApply.SelectedObject.UserPhoto = responseItem.UserPhoto;
                                    });
                                } else {
                                    getUserPhoto(vmApply.SelectedObject).then(function(responseItem) {
                                        vmApply.SelectedObject.UserPhotoText = responseItem.UserPhotoText;
                                        vmApply.SelectedObject.UserPhoto = responseItem.UserPhoto;
                                    });
                                }
                            });
                            vmApply.profileInfo = response.data.data.profile || response.data.data.searchprofile || {};

                            if (!angular.equals(vmApply.profileInfo, {})) {
                                if (response.data.data.profile)
                                    vmApply.ProfileTitle = 'Profile';

                                if (response.data.data.searchprofile)
                                    vmApply.ProfileTitle = 'Search Profile';
                                if (vmApply.profileInfo.container) {
                                    getthecontainer($scope.mc.objectDet.wid.split('!')[0] + '!' + vmApply.profileInfo.container).then(function(response) {
                                        vmApply.profileInfoUI = applyFactory.GetProfileInfoUI(vmApply.profileInfo, vmApply.ProfileTitle, response);
                                    });
                                } else {
                                    vmApply.profileInfoUI = applyFactory.GetProfileInfoUI(vmApply.profileInfo, vmApply.ProfileTitle, '');

                                }
                            }

                        } else {
                            /*  if (showwaring) {
                                  var object = 'Workspace';
                                  if (ftype == 'search') {
                                      object = 'Search Folder';
                                  }
                                  if (ftype == 'regular') {
                                      object = 'Folder';
                                  }

                                  if (ftype == 'tab') {
                                      object = 'Tabs';
                                  }
                                  $mdDialog.show($mdDialog.alert()
                                        .parent(angular.element(document.body))
                                        .clickOutsideToClose(true)
                                        .title('Warning!')
                                        .textContent('We are unable to find the ' + object + ' details. Either object not found or you donot have access on the ' + object)
                                        .ariaLabel('')
                                        .ok('OK'));
                              }*/
                        }
                    },
                    function(response) {

                    });
            }

            function getProfileOfFolder(ftype, Id) {
                var defered = $q.defer();
                var GETProfileURL = 'TABSPROFILE'
                if (ftype == 'search') {
                    GETProfileURL = 'SEARCHPROFILE';
                }
                if (ftype == 'regular') {
                    GETProfileURL = 'FOLDERPROFILE';
                }
                var body = { Id: Id };
                var apiUrl = applyFactory.getAPIUrl(GETProfileURL, body);
                $scope.mc.getlogDetails("Debug", 'Method:GET;URL' + JSON.stringify(apiUrl));
                var promise = applyService.getData(apiUrl, "");
                promise.then(function(response) {
                        if (response && response.data && response.data.data) {
                            defered.resolve(response.data.data.profile || response.data.data.searchprofile || {})


                        } else {
                            defered.resolve({})


                        }
                    },
                    function(response) {
                        defered.resolve({})
                    });

                return defered.promise;
            }


            function getChildrenOfSelectedFolder() {

                vmApply.IsShowWorkspaceList = false;
                if (!$scope.mc.objectDet || !$scope.mc.objectDet.wid)
                    return;
                var requestObj = homeFactory.requestModelInstance();
                requestObj.Id = $scope.mc.objectDet.wid;

                var apiUrl = applyFactory.getAPIUrl('GETFOLDERSFROMWORKSPCE', requestObj);
                $scope.mc.getlogDetails("Debug", 'Method:GET;URL' + JSON.stringify(apiUrl));
                var promise = applyService.getData(apiUrl, "")
                promise.then(function(response) {
                    if (response["status"] == 401) {

                        resetAllValues();
                        redirectToLogin();

                    } else if (response["status"] == 200) {
                        $scope.mc.getlogDetails("Info", "Received workspace details.");
                        vmApply.SelectedChildrens = [];
                        angular.forEach(response["data"]["data"], function(item) {
                            var folderUi = applyFactory.getFolderUI(item);
                            folderUi.lowerName = folderUi.Name.toLowerCase();
                            folderUi.NVPs = null;

                            var promiseNVP = getNameValuePairs(folderUi.Id);
                            promiseNVP.then(function(response) {
                                folderUi.NVPs = response.data;
                                vmApply.SelectedChildrens.push(folderUi);
                            }, function(response) {});
                        });
                        $scope.IsShowWorkspaceList = true;

                    } else {

                        $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                        if (response.data && response.data.details && response.data.details.message) {
                            $mdDialog.show($mdDialog.alert()
                                .parent(angular.element(document.body))
                                .clickOutsideToClose(true)
                                .title('Warning!')
                                .textContent(response.data.details.message)
                                .ariaLabel('')
                                .ok('OK'));
                        } else {
                            $mdDialog.show($mdDialog.alert()
                                .parent(angular.element(document.body))
                                .clickOutsideToClose(true)
                                .title('Warning!')
                                .textContent(response.data.error.message)
                                .ariaLabel('')
                                .ok('OK'));
                        }
                    }


                }, function(response) {

                    $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                    if (response && response.data && response.data.details && response.data.details.message) {
                        $mdDialog.show($mdDialog.alert()
                            .parent(angular.element(document.body))
                            .clickOutsideToClose(true)
                            .title('Warning!')
                            .textContent(response.data.details.message)
                            .ariaLabel('')
                            .ok('OK'));
                        $scope.showSearchProgress = false;

                    } else {
                        $mdDialog.show($mdDialog.alert()
                            .parent(angular.element(document.body))
                            .clickOutsideToClose(true)
                            .title('Warning!')
                            .textContent(response.data.error.message)
                            .ariaLabel('')
                            .ok('OK'));
                        $scope.showSearchProgress = false;

                    }
                });
            }


            function getFolderPath() {

                vmApply.IsShowWorkspaceList = false;
                if (!$scope.mc.objectDet || !$scope.mc.objectDet.wid)
                    return;

                requestModel.Id = $scope.mc.objectDet.wid;
                var apiUrl = applyFactory.getAPIUrl('GETFOLDERPATH', requestModel);
                $scope.mc.getlogDetails("Debug", 'Method:GET;URL' + JSON.stringify(apiUrl));
                var promise = applyService.getData(apiUrl, "")
                promise.then(function(response) {
                    if (response["status"] == 200) {
                        $scope.mc.getlogDetails("Info", "Received workspace details.");
                        vmApply.ApplyItemPath = [];
                        vmApply.PathString = '';
                        angular.forEach(response["data"]["data"], function(item) {
                            vmApply.ApplyItemPath.push(applyFactory.getFolderUI(item));
                            if (vmApply.PathString == '')
                                vmApply.PathString = 'root>';
                            else {
                                vmApply.PathString += item.name + item.folder_type+'>';
                            }
                        });
                        $scope.mc.objectDet.level = response["data"]["data"].length-1;
                        getworkSpace(vmApply.ApplyItemPath[0].Id);

                        if (response["data"]["data"].length - 1 != '0') {

                            getProfileOfSelectedFolder(vmApply.ApplyItemPath[vmApply.ApplyItemPath.length - 1].FolderType);
                        }
                        $scope.IsShowWorkspaceList = true;


                    } else {

                        $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                        if (response.data && response.data.details && response.data.details.message) {
                            $mdDialog.show($mdDialog.alert()
                                .parent(angular.element(document.body))
                                .clickOutsideToClose(true)
                                .title('Warning!')
                                .textContent(response.data.details.message)
                                .ariaLabel('')
                                .ok('OK'));
                        } else {
                            $mdDialog.show($mdDialog.alert()
                                .parent(angular.element(document.body))
                                .clickOutsideToClose(true)
                                .title('Warning!')
                                .textContent(response.data.error.message)
                                .ariaLabel('')
                                .ok('OK'));
                        }
                    }


                }, function(response) {

                    $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                    if (response && response.data && response.data.details && response.data.details.message) {
                        $mdDialog.show($mdDialog.alert()
                            .parent(angular.element(document.body))
                            .clickOutsideToClose(true)
                            .title('Warning!')
                            .textContent(response.data.details.message)
                            .ariaLabel('')
                            .ok('OK'));


                    } else {
                        $mdDialog.show($mdDialog.alert()
                            .parent(angular.element(document.body))
                            .clickOutsideToClose(true)
                            .title('Warning!')
                            .textContent(response.data.error.message)
                            .ariaLabel('')
                            .ok('OK'));


                    }
                });
            }


            function getthecontainer(cid) {
                var q = $q.defer();




                var requestObj = { Id: cid };
                var apiUrl = applyFactory.getAPIUrl('GETWORKSPACE', requestObj);
                $scope.mc.getlogDetails("Debug", 'Method:GET;URL' + JSON.stringify(apiUrl));
                var promise = applyService.getData(apiUrl, "")
                promise.then(function(response) {
                    if (response["status"] == 200) {


                        var containerUIModel = applyFactory.getworkSpaceUI(response["data"]["data"]);

                        q.resolve(containerUIModel.Name);


                    } else {

                        q.resolve('');
                    }


                }, function(response) {

                    q.resolve('');
                });

                return q.promise;
            }

            function getworkSpace(workspaceId) {

                vmApply.IsShowWorkspaceList = false;
                if (!workspaceId)
                    return;


                var requestObj = { Id: workspaceId };
                var apiUrl = applyFactory.getAPIUrl('GETWORKSPACE', requestObj);
                $scope.mc.getlogDetails("Debug", 'Method:GET;URL' + JSON.stringify(apiUrl));
                var promise = applyService.getData(apiUrl, "")
                promise.then(function(response) {
                    if (response["status"] == 200) {
                        $scope.mc.getlogDetails("Info", "Received workspace details.");

                        vmApply.workSpaceUIModel = applyFactory.getworkSpaceUI(response["data"]["data"]);
                        vmApply.wsprofileInfo = applyFactory.getProfileInfo(response["data"]["data"]);
                        if ($scope.mc.objectDet.level == '0') {
                            vmApply.profileInfo = angular.copy(vmApply.wsprofileInfo);
                        }
                        var promiseNVP = getNameValuePairs(requestObj.Id);
                        promiseNVP.then(function(response) {
                            if (!vmApply.workSpaceUIModel.NVPs)
                                vmApply.workSpaceUIModel.NVPs = response.data;


                            vmApply.workSpaceUIModel.NVPs = response.data;

                            getTemplates();

                        });
                        $scope.IsShowWorkspaceList = true;


                    } else {

                        $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                        if (response.data && response.data.details && response.data.details.message) {
                            $mdDialog.show($mdDialog.alert()
                                .parent(angular.element(document.body))
                                .clickOutsideToClose(true)
                                .title('Warning!')
                                .textContent(response.data.details.message)
                                .ariaLabel('')
                                .ok('OK'));
                        } else {
                            $mdDialog.show($mdDialog.alert()
                                .parent(angular.element(document.body))
                                .clickOutsideToClose(true)
                                .title('Warning!')
                                .textContent(response.data.error.message)
                                .ariaLabel('')
                                .ok('OK'));
                        }
                    }


                }, function(response) {

                    $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                    if (response && response.data && response.data.details && response.data.details.message) {
                        $mdDialog.show($mdDialog.alert()
                            .parent(angular.element(document.body))
                            .clickOutsideToClose(true)
                            .title('Warning!')
                            .textContent(response.data.details.message)
                            .ariaLabel('')
                            .ok('OK'));
                        $scope.showSearchProgress = false;

                    } else {
                        $mdDialog.show($mdDialog.alert()
                            .parent(angular.element(document.body))
                            .clickOutsideToClose(true)
                            .title('Warning!')
                            .textContent(response.data.error.message)
                            .ariaLabel('')
                            .ok('OK'));
                        $scope.showSearchProgress = false;

                    }
                });
            }

            function getNameValuePairs(id) {
                var deffered = $q.defer();
                vmApply.IsShowWorkspaceList = false;
                if (!id)
                    return;

                requestModel.Id = id;
                var apiUrl = applyFactory.getAPIUrl('GETNAMEVALUEPAIRS', requestModel);
                $scope.mc.getlogDetails("Debug", 'Method:GET;URL' + JSON.stringify(apiUrl));
                var promise = applyService.getData(apiUrl, "")
                promise.then(function(response) {
                    deffered.resolve(response.data);
                }, function(response) {
                    deffered.resolve([]);
                });

                return deffered.promise;
            }


            function getTemplates() {

                var deffered = $q.defer();
                vmApply.templateList = [];

                vmApply.IsShowWorkspaceList = false;
                var requestModel1 = homeFactory.requestModelInstance();

                if ((vmApply.MatchField && vmApply.MatchField[0] && vmApply.workSpaceUIModel[vmApply.MatchField[0].replace('c', 'C')]) || (vmApply.MatchField && vmApply.MatchField[1] && vmApply.workSpaceUIModel[vmApply.MatchField[1].replace('c', 'C')])) {
                    requestModel1.MatchField = vmApply.MatchField;
                    angular.forEach(vmApply.MatchField, function(matchData) {
                        if (vmApply.workSpaceUIModel[matchData.replace('c', 'C')])
                            requestModel1[matchData] = vmApply.workSpaceUIModel[matchData.replace('c', 'C')];
                        else
                            requestModel1[matchData] = '';
                    });

                } else {

                    getTemplatesWithEmptyMatch();

                    deffered.resolve(vmApply.templateList);
                    return;
                }

                requestModel1.libraryName = vmApply.workSpaceUIModel.Database;
                var apiUrl = applyFactory.getAPIUrl('SEARCHTEMPLATE', requestModel1);
                $scope.mc.getlogDetails("Debug", 'Method:GET;URL' + JSON.stringify(apiUrl));
                var promise = applyService.getData(apiUrl, "")
                promise.then(function(response) {

                    if (response["status"] == 200) {
                        $scope.mc.getlogDetails("Info", "Received workspace details.");


                        var workSpaceUI;
                        angular.forEach(response["data"]["data"], function(workSpace) {
                            workSpaceUI = applyFactory.getworkSpaceUI(workSpace);
                            workSpaceUI.IMCCMATCHTYPE = "Exact";

                            if (vmApply.MatchField) {
                                if ((vmApply.MatchField[0] && vmApply.workSpaceUIModel[vmApply.MatchField[0].replace('c', 'C')] && vmApply.workSpaceUIModel[vmApply.MatchField[0].replace('c', 'C')] == workSpaceUI[vmApply.MatchField[0].replace('c', 'C')]))
                                    vmApply.templateList.push(workSpaceUI);
                                else if ((vmApply.MatchField[1] && vmApply.workSpaceUIModel[vmApply.MatchField[1].replace('c', 'C')] && vmApply.workSpaceUIModel[vmApply.MatchField[1].replace('c', 'C')] == workSpaceUI[vmApply.MatchField[1].replace('c', 'C')]))
                                    vmApply.templateList.push(workSpaceUI);
                            }
                        });
                        getTemplatesWithEmptyMatch();




                        deffered.resolve(vmApply.templateList);
                        $scope.IsShowWorkspaceList = true;


                    } else {
                        getTemplatesWithEmptyMatch();

                        $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                        if (response.data && response.data.details && response.data.details.message) {
                            $mdDialog.show($mdDialog.alert()
                                .parent(angular.element(document.body))
                                .clickOutsideToClose(true)
                                .title('Warning!')
                                .textContent(response.data.details.message)
                                .ariaLabel('')
                                .ok('OK'));
                        } else {
                            $mdDialog.show($mdDialog.alert()
                                .parent(angular.element(document.body))
                                .clickOutsideToClose(true)
                                .title('Warning!')
                                .textContent(response.data.error.message)
                                .ariaLabel('')
                                .ok('OK'));
                        }
                        deffered.resolve(vmApply.templateList);
                    }


                }, function(response) {
                    getTemplatesWithEmptyMatch();
                    deffered.resolve(vmApply.templateList);

                    $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                    if (response && response.data && response.data.details && response.data.details.message) {
                        $mdDialog.show($mdDialog.alert()
                            .parent(angular.element(document.body))
                            .clickOutsideToClose(true)
                            .title('Warning!')
                            .textContent(response.data.details.message)
                            .ariaLabel('')
                            .ok('OK'));

                    } else {
                        $mdDialog.show($mdDialog.alert()
                            .parent(angular.element(document.body))
                            .clickOutsideToClose(true)
                            .title('Warning!')
                            .textContent(response.data.error.message)
                            .ariaLabel('')
                            .ok('OK'));

                    }
                });

                return deffered.promise;
            }

            function getTemplatesWithEmptyMatch() {
                var deffered = $q.defer();



                //if (vmApply.MatchField) {
                vmApply.IsShowWorkspaceList = false;
                var requestModel2 = homeFactory.requestModelInstance();

                requestModel2.libraryName = vmApply.workSpaceUIModel.Database;
                var apiUrl = applyFactory.getAPIUrl('SEARCHTEMPLATE', requestModel2);
                $scope.mc.getlogDetails("Debug", 'Method:GET;URL' + JSON.stringify(apiUrl));

                var promise = applyService.getData(apiUrl, "")
                promise.then(function(response) {
                    $timeout(function() { $mdDialog.hide(); }, 3000);
                    if (response["status"] == 200) {

                        $scope.mc.getlogDetails("Info", "Received workspace details.");
                        var workSpaceUIModel;
                        angular.forEach(response["data"]["data"], function(workSpace) {
                            workSpaceUIModel = applyFactory.getworkSpaceUI(workSpace);
                            if (!vmApply.MatchField) {
                                workSpaceUIModel.IMCCMATCHTYPE = "EMPTY";
                                vmApply.templateList.push(workSpaceUIModel);
                            } else if (vmApply.MatchField && vmApply.MatchField.length == 1 && !workSpaceUIModel[vmApply.MatchField[0].replace('c', 'C')]) {
                                workSpaceUIModel.IMCCMATCHTYPE = "EMPTY";
                                vmApply.templateList.push(workSpaceUIModel);
                            } else if (vmApply.MatchField && vmApply.MatchField.length == 2 && !workSpaceUIModel[vmApply.MatchField[0].replace('c', 'C')] && !workSpaceUIModel[vmApply.MatchField[1].replace('c', 'C')]) {

                                workSpaceUIModel.IMCCMATCHTYPE = "EMPTY";
                                vmApply.templateList.push(workSpaceUIModel);
                            }
                        });


                        var index = -1
                        if (vmApply.templateList.length > 0) {
                            if (vmApply.workSpaceUIModel.NVPs && vmApply.workSpaceUIModel.NVPs.TemplateId) {

                                var ItemArray = ($filter('filter')(vmApply.templateList, { Id: vmApply.workSpaceUIModel.NVPs.TemplateId }, true));

                                if (ItemArray.length > 0 && (ItemArray[0].IMCCMATCHTYPE == 'Exact' || ItemArray[0].IMCCMATCHTYPE == 'EMPTY')) {
                                    index = vmApply.templateList.indexOf(ItemArray[0]);
                                }
                            }
                            if (index == -1) {
                                var ItemArray = ($filter('filter')(vmApply.templateList, { IMCCMATCHTYPE: 'Exact' }, true));

                                if (ItemArray.length > 0) {
                                    index = vmApply.templateList.indexOf(ItemArray[0]);
                                }
                            }
                            if (index == -1) {
                                var ItemArray = ($filter('filter')(vmApply.templateList, { IMCCMATCHTYPE: 'EMPTY' }, true));
                                if (ItemArray.length > 0) {
                                    index = vmApply.templateList.indexOf(ItemArray[0]);
                                }
                            }

                            if (index != -1) {
                                vmApply.selectedItem = vmApply.templateList[index];
                                if (!vmApply.templateList[index].NVPs) {
                                    var promiseNVP = getNameValuePairs(vmApply.templateList[index].Id);
                                    promiseNVP.then(function(response) {
                                        vmApply.templateList[index].NVPs = applyFactory.GetNVPUI(response.data);
                                        vmApply.selectedItem.NVPs = applyFactory.GetNVPUI(response.data);
                                        vmApply.onSelect(vmApply.selectedItem);
                                    });
                                }
                            }
                        }
                        $timeout(function() { $mdDialog.hide(); }, 1500);
                        deffered.resolve(vmApply.templateList);
                        $scope.IsShowWorkspaceList = true;


                    } else {
                        $timeout(function() { $mdDialog.hide(); }, 3000);
                        $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                        if (response.data && response.data.details && response.data.details.message) {
                            $mdDialog.show($mdDialog.alert()
                                .parent(angular.element(document.body))
                                .clickOutsideToClose(true)
                                .title('Warning!')
                                .textContent(response.data.details.message)
                                .ariaLabel('')
                                .ok('OK'));
                        } else {
                            $mdDialog.show($mdDialog.alert()
                                .parent(angular.element(document.body))
                                .clickOutsideToClose(true)
                                .title('Warning!')
                                .textContent(response.data.error.message)
                                .ariaLabel('')
                                .ok('OK'));
                        }
                        deffered.resolve(vmApply.templateList);
                    }


                }, function(response) {
                    $timeout(function() { $mdDialog.hide(); }, 3000);
                    deffered.resolve(vmApply.templateList);

                    $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                    if (response && response.data && response.data.details && response.data.details.message) {
                        $mdDialog.show($mdDialog.alert()
                            .parent(angular.element(document.body))
                            .clickOutsideToClose(true)
                            .title('Warning!')
                            .textContent(response.data.details.message)
                            .ariaLabel('')
                            .ok('OK'));

                    } else {
                        $mdDialog.show($mdDialog.alert()
                            .parent(angular.element(document.body))
                            .clickOutsideToClose(true)
                            .title('Warning!')
                            .textContent(response.data.error.message)
                            .ariaLabel('')
                            .ok('OK'));

                    }
                });
                //} else {
                //    deffered.resolve(vmApply.templateList);
                //}
                return deffered.promise;
            }




            function showProgressDialog() {

                $timeout(function() {

                    $mdDialog.show({
                        parent: angular.element(document.body),
                        template: '<md-dialog ng-cloak height="100%" style="min-width: 1px !important;"><md-dialog-content class="apply-progress-dialog"><div class="md-dialog-content-clearpadding">' +
                            '<md-progress-circular md-mode="indeterminate"></md-progress-circular><span class="apply-progress-msg">' + vmApply.ProgressMessage +
                            '</span></div></md-dialog-content></md-dialog>',

                    });
                });
            }

            vmApply.selectedItemChange = selectedItemChange;

            function selectedItemChange() {
                vmApply.ProgressMessage = 'Loading the ' + vmApply.tabTitle.replace('Apply', '') + ' in the selected templates';
                showProgressDialog();
                if (!vmApply.selectedItem.NVPs) {
                    var promiseNVP = getNameValuePairs(vmApply.selectedItem.Id);
                    promiseNVP.then(function(response) {
                        vmApply.selectedItem.NVPs = applyFactory.GetNVPUI(response.data);
                    });
                }
                vmApply.onSelect(vmApply.selectedItem);
            }

            function ApplyTemplates() {
                vmApply.IsApplying = true;
                var deferdarray = []
                var deferdarray1 = []
                var type = 'regular';
                if ($scope.mc.objectDet.type == 'imTypeDocumentSearchFolder') {
                    type = 'search';
                }
                if ($scope.mc.objectDet.type == 'imTypeDocumentFolder') {
                    type = 'regular';
                }
                if ($scope.mc.objectDet.type == 'imTypeDocumentTab') {
                    type = 'tab';
                }
                var requestBody = {
                    'TemplateId': vmApply.selectedItem.Id
                }
                if ((vmApply.workSpaceUIModel && vmApply.workSpaceUIModel.NVPs && !vmApply.workSpaceUIModel.NVPs.TemplateId) || (vmApply.workSpaceUIModel && !vmApply.workSpaceUIModel.NVPs)) {
                    var deferedNVP = $q.defer();
                    var apiUrl = applyFactory.getAPIUrl('SAVENAMEVALUEPAIRS', { Id: vmApply.workSpaceUIModel.Id });
                    $scope.mc.getlogDetails("Debug", 'Method:POST;URL:' + JSON.stringify(apiUrl));
                    var promisenvp = applyService.PostNVP(apiUrl, requestBody);
                    promisenvp.then(function (response) {
                        if (response && response.data && response.data.error && response.data.error.code) {
                            $scope.mc.getlogDetails("Error", 'Error:' + JSON.stringify(response));
                            if (response.data.error.code == 'InvalidCsrfToken' || response.data.error.code == 'InvalidToken') {

                                redirectUnauthorized();

                            } else {
                                deferedNVP.resolve(response);
                            }
                        } else {
                            $scope.mc.getlogDetails("Debug", 'Success');
                            deferedNVP.resolve(response);
                        }
                    }, function (response) {
                        $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                        if (response && response.data && response.data.error && response.data.error.code) {

                            if (response.data.error.code == 'InvalidCsrfToken' || response.data.error.code == 'InvalidToken') {

                                redirectUnauthorized();

                            } else {
                                deferedNVP.resolve(response);
                            }
                        } else {

                            deferedNVP.resolve(response);
                        }
                    });
                    deferdarray1.push(deferedNVP.promise);


                } else {

                    var deferedNVP = $q.defer();
                    var apiUrl = applyFactory.getAPIUrl('SAVENAMEVALUEPAIRS', { Id: vmApply.workSpaceUIModel.Id });
                    $scope.mc.getlogDetails("Debug", 'Method:POST;URL:' + JSON.stringify(apiUrl));
                    var promisenvp = applyService.PutNVP(apiUrl, requestBody);
                    promisenvp.then(function (response) {

                        if (response && response.data && response.data.error && response.data.error.code) {
                            $scope.mc.getlogDetails("Error", 'Error:' + JSON.stringify(response));
                            if (response.data.error.code == 'InvalidCsrfToken' || response.data.error.code == 'InvalidToken') {

                                redirectUnauthorized();

                            } else {
                                deferedNVP.resolve(response);
                            }
                        } else {
                            $scope.mc.getlogDetails("Debug", 'Success');
                            deferedNVP.resolve(response);
                        }
                    }, function (response) {
                        $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                        if (response && response.data && response.data.error && response.data.error.code) {

                            if (response.data.error.code == 'InvalidCsrfToken' || response.data.error.code == 'InvalidToken') {

                                redirectUnauthorized();

                            } else {
                                deferedNVP.resolve(response);
                            }
                        } else {

                            deferedNVP.resolve(response);
                        }
                    });
                    deferdarray1.push(deferedNVP.promise);
                }

                $q.all(deferdarray1).then(function () {

                    vmApply.ProgressMessage = 'Creating Object:0 of ' + vmApply.FoldersPreview.length + 'completed';
                    showProgressDialog();
                    var finishcount = 1;
                    vmApply.EmailArray = [];
                    angular.forEach(vmApply.FoldersPreview, function (folders) {
                        var defered1 = $q.defer();
                        folders.ParentId = $scope.mc.objectDet.wid;
                        var email = ''
                        if (folders.NVPs.IMCC_Email_Format)
                            email = folders.NVPs.IMCC_Email_Format;
                        if (email != '') {

                            var promiseEmail = getEmailAddress(email, folders);
                            promiseEmail.then(function (responseEmail) {
                                if (responseEmail != '') {
                                    folders.Email = responseEmail;
                                }
                                applyFolder(angular.copy(folders), type).then(function (response) {
                                    defered1.resolve(response);
                                    vmApply.ProgressMessage = 'Creating Object:' + finishcount + ' of ' + vmApply.FoldersPreview.length + 'completed';
                                    finishcount = finishcount + 1;
                                    $timeout(function () { $mdDialog.hide(); });
                                    if (finishcount < vmApply.FoldersPreview.length)
                                        showProgressDialog();
                                }, function (response) {
                                    defered1.resolve(response);
                                    vmApply.ProgressMessage = 'Creating Object:' + finishcount + ' of ' + vmApply.FoldersPreview.length + 'completed';
                                    finishcount = finishcount + 1;
                                    $timeout(function () { $mdDialog.hide(); });
                                    if (finishcount < vmApply.FoldersPreview.length)
                                        showProgressDialog();
                                });

                            });


                        } else {

                            applyFolder(angular.copy(folders), type).then(function (response) {
                                vmApply.ProgressMessage = 'Creating Object:' + finishcount + ' of ' + vmApply.FoldersPreview.length + 'completed';
                                finishcount = finishcount + 1;
                                $timeout(function () { $mdDialog.hide(); });
                                if (finishcount < vmApply.FoldersPreview.length)
                                    showProgressDialog();
                                defered1.resolve(response);
                            }, function (response) {
                                vmApply.ProgressMessage = 'Creating Object:' + finishcount + ' of ' + vmApply.FoldersPreview.length + 'completed';
                                finishcount = finishcount + 1;
                                $timeout(function () { $mdDialog.hide(); });
                                if (finishcount < vmApply.FoldersPreview.length)
                                    showProgressDialog();
                                defered1.resolve(response);
                            });
                        }
                        deferdarray.push(defered1.promise);
                    });
                    $q.all(deferdarray).then(function (results) {
                        $timeout(function () {
                            $mdDialog.hide();
                        if (results) {
                            var filteredarry = $filter('filter')(results, { Error: true });
                            if (filteredarry.length > 0) {
                                $mdDialog.show($mdDialog.alert()
                    .parent(angular.element(document.body))
                    .clickOutsideToClose(true)
                    .title('Warning!')
                    .textContent('Some of the folders not created.')
                    .ariaLabel('Warning!')
                    .ok('OK')).then(function () {
                       
                        vmApply.closeWindow('created');
                    });
                            } else {
                                
                                vmApply.closeWindow('created');
                            }
                        }
                        });

                    });
                });

            }

            function EmailExists(NewMail, Format) {

                while (vmApply.EmailArray.indexOf(NewMail) !== -1) {
                    var count = NewMail.replace(Format, '');
                    if (count.indexOf('_') !== -1) {
                        count = count.replace('_', '');
                    } else { count = '0'; }
                    NewMail = Format + '_' + (parseInt(count) + 1);
                }
                vmApply.EmailArray.push(NewMail);
                return NewMail;

            }

            function applyFolder(folder, type) {
                var defered = $q.defer();
                var subfolder = {};
                subfolder.Name = folder.Name;
                subfolder.DefaultSecurity = folder.DefaultSecurity;
                subfolder.Database = vmApply.selectedLibrary;
                subfolder.Description = folder.Description;
                subfolder.FolderType = type;

                if (type == 'search') {
                    subfolder["searchprofile"] = angular.copy(vmApply.wsprofileInfo);
                }
                if (type == 'regular') {
                    subfolder["profile"] = angular.copy(vmApply.wsprofileInfo);
                   
                }
                if (folder.searchprofile) {
                    angular.forEach(folder.searchprofile, function(value, key) {

                        if (key.search(/custom([1-9]|[1][0-9]|[2][09]|[3][0])/i) != -1) {
                            //if (value.search(/#C([1-9]|[1][0-9]|[2][09]|[3][0])Alias#/i) != -1) {
                            //    var matches = value.match(/#C([1-9]|[1][0-9]|[2][09]|[3][0])Alias#/i)

                            //    var mdata = matches[0].match(/\d+/g);
                            //    var customValue = 'custom' + mdata[0];
                            //    if (vmApply.profileInfo[customValue])
                            //        subfolder["searchprofile"][key] = value.replace(matches[0], vmApply.profileInfo[customValue]);
                            //    else
                            //        subfolder["searchprofile"][key] = value.replace(matches[0], '');


                            //}
							
							 if (value.search(/%WORKSPACE_VALUE%/i) != -1) {
                                 var matches = value.match(/%WORKSPACE_VALUE%/i)
                                 if (vmApply.wsprofileInfo[key])
                                     subfolder["searchprofile"][key] = value.replace(matches[0], vmApply.wsprofileInfo[key]);
                                 else
                                     subfolder["searchprofile"][key] = value.replace(matches[0], '');
                             }else{
							
							 subfolder["searchprofile"][key] = value;
							 }
                        } else if (key == 'content_type') {
                            subfolder["searchprofile"]['contenttype'] = 'D,5';
                        } else if (key == 'class') {
                            subfolder["searchprofile"][key] = value;
                            //if (value.search(/#CLASSID#/i) != -1) {

                            //    var matches = value.match(/#CLASSID#/i)
                            //    if (vmApply.profileInfo[key])
                            //        subfolder["searchprofile"][key] = value.replace(matches[0], vmApply.profileInfo[key]);
                            //    else if (value.replace(matches[0], '') != '')
                            //        subfolder["searchprofile"][key] = value.replace(matches[0], '');


                            //} else {
                            //    subfolder["searchprofile"][key] = value;
                            //}
                        } else if (key == 'subclass') {
                            //if (value.search(/#SUBCLASSID#/i) != -1) {
                            //    var matches = value.match(/#SUBCLASSID#/i)
                            //    if (vmApply.profileInfo[key])
                            //        subfolder["searchprofile"][key] = value.replace(matches[0], vmApply.profileInfo[key]);
                            //    else
                            //        subfolder["searchprofile"][key] = value.replace(matches[0], '');


                            //} else {
                            //    subfolder["searchprofile"][key] = value;
                            //}
                            subfolder["searchprofile"][key] = value;

                        } else if (key == 'type') {
                            //if (value.search(/#TYPEID#/i) != -1) {
                            //    var matches = value.match(/#TYPEID#/i)

                            //    if (vmApply.profileInfo[key])
                            //        subfolder["searchprofile"][key] = value.replace(matches[0], vmApply.profileInfo[key]);
                            //    else
                            //        subfolder["searchprofile"][key] = value.replace(matches[0], '');


                            //} else {
                            //    subfolder["searchprofile"][key] = value;
                            //}
                            subfolder["searchprofile"][key] = value;
                        } else {
                            subfolder["searchprofile"][key] = value;
                        }


                    });
                }
                if (folder.profile) {
                    angular.forEach(folder.profile, function(value, key) {
                        if (key.search(/custom([1-9]|[1][0-9]|[2][09]|[3][0])/i) != -1) {
                            //if (value.search(/#C([1-9]|[1][0-9]|[2][09]|[3][0])Alias#/i) != -1) {
                            //    var matches = value.match(/#C([1-9]|[1][0-9]|[2][09]|[3][0])Alias#/i)

                            //    var mdata = matches[0].match(/\d+/g);
                            //    var customValue = 'custom' + mdata[0];
                            //    if (vmApply.profileInfo[customValue])
                            //        subfolder["profile"][key] = value.replace(matches[0], vmApply.profileInfo[customValue]);
                            //    else
                            //        subfolder["profile"][key] = value.replace(matches[0], '');


                            //} else {
                            //    subfolder["profile"][key] = value;
                            //}
                             if (value.search(/%WORKSPACE_VALUE%/i) != -1) {
                                 var matches = value.match(/%WORKSPACE_VALUE%/i)
                                 if (vmApply.wsprofileInfo[key])
                                     subfolder["profile"][key] = value.replace(matches[0], vmApply.wsprofileInfo[key]);
                                 else
                                     subfolder["profile"][key] = value.replace(matches[0], '');
                             }else{
							
							 subfolder["profile"][key] = value;
							 }
                        } else

                        if (key == 'class') {

                            //if (value.search(/#CLASSID#/i) != -1) {

                            //    var matches = value.match(/#CLASSID#/i)                                                              
                            //    if (vmApply.profileInfo[key])
                            //        subfolder["profile"][key] = value.replace(matches[0], vmApply.profileInfo[key]);
                            //    else if (value.replace(matches[0], '')!='')
                            //        subfolder["profile"][key] = value.replace(matches[0], '');


                            //} else {
                            //    subfolder["profile"][key] = value;
                            //}
                            subfolder["profile"][key] = value;
                        } else if (key == 'subclass') {

                            //if (value.search(/#SUBCLASSID#/i) != -1) {
                            //    var matches = value.match(/#SUBCLASSID#/i)                                 
                            //    if (vmApply.profileInfo[key])
                            //        subfolder["profile"][key] = value.replace(matches[0], vmApply.profileInfo[key]);
                            //    else
                            //        subfolder["profile"][key] = value.replace(matches[0], '');

                            //} else {
                            //    subfolder["profile"][key] = value;
                            //}
                            subfolder["profile"][key] = value;
                        } else if (key == 'type') {

                            //if (value.search(/#TYPEID#/i) != -1) {
                            //    var matches = value.match(/#TYPEID#/i)

                            //    if (vmApply.profileInfo[key])
                            //        subfolder["profile"][key] = value.replace(matches[0], vmApply.profileInfo[key]);
                            //    else
                            //        subfolder["profile"][key] = value.replace(matches[0], '');


                            //} else {
                            //    subfolder["profile"][key] = value;
                            //}
                            subfolder["profile"][key] = value;

                        } else {
                            subfolder["profile"][key] = value;

                        }
                    });
                }
                if (subfolder["searchprofile"]) {
                    subfolder["searchprofile"]['container'] = GetTheContainerId();
                    subfolder["searchprofile"]['contenttype'] = 'D,5';
                    subfolder["searchprofile"]['databases'] = vmApply.selectedLibrary;

                }
                subfolder.Owner = $scope.mc.loginModel.UserName;
                var apiUrl = applyFactory.getFolderPostAPI(folder.ParentId, type);
                if (folder.Email) {
                    CheckForEmailExists(folder.Email, 0).then(function(emailResponse) {
                        var finalEmail = EmailExists(emailResponse, folder.Email)
                        subfolder.Email = finalEmail;
                        var requestBody = applyFactory.getFolderPostAPIModel(subfolder);
                        $scope.mc.getlogDetails("Debug", 'Method:POST;URL:' + JSON.stringify(apiUrl) + 'Parametrs are' + JSON.stringify(requestBody));
                        var promise = applyService.addFolder(apiUrl, "", requestBody);
                        promise.then(function(response) {

                            if (response.status == '520') {
                                if (response.data && response.data.code == '335') {
                                    var deferedarray = [];
                                    var deferedque = $q.defer();
                                    deferedarray.push(deferedque.promise);

                                    var finalEmail1 = EmailExists(subfolder.Email, folder.Email)
                                    folder.Email = finalEmail1;
                                    applyFolder(angular.copy(folder), type).then(function(response) {
                                        deferedque.resolve(response);
                                    }, function(response) {
                                        deferedque.resolve(response);
                                    });
                                    $q.all(deferedarray).then(function() {
                                        defered.resolve({ Sucess: true, Response: response });
                                    });
                                } else {
                                    defered.resolve({ Error: true, Response: response });
                                }
                            } else if (response && response.data && response.data.error && response.data.error.code) {
                                $scope.mc.getlogDetails("Error", 'Error:' + JSON.stringify(response));
                                if (response.data.error.code == 'InvalidCsrfToken' || response.data.error.code == 'InvalidToken') {

                                    redirectUnauthorized();

                                } else {
                                    defered.resolve({ Error: true, Response: response });
                                }
                            } else if (response.data && response.data.data && response.data.data.id && response.data.data.id.trim().length > 0) {
                                $scope.mc.getlogDetails("Debug", 'Object Added with id' + response.data.data.id);

                                var templateFolderId = folder.Id;
                                folder.Id = response.data.data.id;
                                var folderIdMappingPromise = saveTemplateFolderIdNVP(templateFolderId, folder.Id);
                                folderIdMappingPromise.then(function(responseNVP) {
                                    vmApply.NewFlist += folder.Id + ';';
                                    vmApply.NewItemsList.push(response.data.data);
                                    if (folder.SubFolders.length > 0) {
                                        var deferedarray = [];
                                        angular.forEach(folder.SubFolders, function(subFolder) {
                                            subFolder.ParentId = folder.Id;

                                            var deferedque = $q.defer();
                                            deferedarray.push(deferedque.promise);
                                            applyFolder(angular.copy(subFolder), type).then(function(response) {
                                                deferedque.resolve(response);
                                            }, function(response) {
                                                deferedque.resolve(response);
                                            });
                                        });
                                        $q.all(deferedarray).then(function() {
                                            defered.resolve({ Sucess: true, Response: response });
                                        });
                                    } else {
                                        defered.resolve({ Sucess: true, Response: response });
                                    }
                                }, function(response) {
                                     
                                });
                            } else {


                                defered.resolve({ Error: true, Response: response });
                                $scope.mc.getlogDetails("Error", 'Object not added error' + JSON.stringify(response));
                            }

                        }, function(response) {
                            $scope.mc.getlogDetails("Error", 'Object not added error' + JSON.stringify(response));
                            defered.resolve({ Error: true, Response: response });
                        });
                    });

                } else {
                    var requestBody = applyFactory.getFolderPostAPIModel(subfolder);
                    $scope.mc.getlogDetails("Debug", 'Method:POST;URL:' + JSON.stringify(apiUrl) + 'Parametrs are' + JSON.stringify(requestBody));
                    var promise = applyService.addFolder(apiUrl, "", requestBody);
                    promise.then(function(response) {
                        if (response.status == '520') {
                            if (response.data && response.data.code == '335') {
                                var deferedarray = [];
                                var deferedque = $q.defer();
                                deferedarray.push(deferedque.promise);
                                var finalEmail1 = EmailExists(subfolder.Email, folder.Email)
                                folder.Email = finalEmail1;
                                //folder.Email = folder.Email + $scope.mc.loginModel.UserName;
                                applyFolder(angular.copy(folder), type).then(function(response) {
                                    deferedque.resolve(response);
                                }, function(response) {
                                    deferedque.resolve(response);
                                });
                                $q.all(deferedarray).then(function() {
                                    defered.resolve({ Sucess: true, Response: response });
                                });
                            } else {
                                defered.resolve({ Error: true, Response: response });
                            }
                        }
                        if (response && response.data && response.data.error && response.data.error.code) {
                            $scope.mc.getlogDetails("Error", 'Error:' + JSON.stringify(response));
                            if (response.data.error.code == 'InvalidCsrfToken' || response.data.error.code == 'InvalidToken') {

                                redirectUnauthorized();

                            } else {
                                defered.resolve({ Error: true, Response: response });
                            }
                        } else if (response.data && response.data.data && response.data.data.id && response.data.data.id.trim().length > 0) {
                            $scope.mc.getlogDetails("Debug", 'Object Added with id' + response.data.data.id);
                            var templateFolderId = folder.Id;
                            folder.Id = response.data.data.id;

                            var folderIdMappingPromise = saveTemplateFolderIdNVP(templateFolderId, folder.Id);
                            folderIdMappingPromise.then(function(responseNVP) {
                                vmApply.NewFlist += folder.Id + ';';
                                vmApply.NewItemsList.push(response.data.data);
                                if (folder.SubFolders.length > 0) {
                                    var deferedarray = [];
                                    angular.forEach(folder.SubFolders, function(subFolder) {
                                        subFolder.ParentId = folder.Id;

                                        var deferedque = $q.defer();
                                        deferedarray.push(deferedque.promise);
                                        applyFolder(angular.copy(subFolder), type).then(function(response) {
                                            deferedque.resolve(response);
                                        }, function(response) {
                                            deferedque.resolve(response);
                                        });
                                    });
                                    $q.all(deferedarray).then(function() {
                                        defered.resolve({ Sucess: true, Response: response });
                                    });
                                } else {
                                    defered.resolve({ Sucess: true, Response: response });
                                    
                                }
                            }, function(response) {});
                        } else {
                            $scope.mc.getlogDetails("Error", 'Object not added error' + JSON.stringify(response));
                            defered.resolve({Error :true,Response :response});

                        }

                    }, function(response) {
                        $scope.mc.getlogDetails("Error", 'Object not added error' + JSON.stringify(response));
                        defered.resolve({ Error: true, Response: response });
                    });
                }
                return defered.promise;

            }

            function saveTemplateFolderIdNVP(templateFolderId, createdFolderId) {
                var deferedNVP = $q.defer();
                var requestBody = {
                    FolderTemplateId: templateFolderId
                };
                var apiUrl = applyFactory.getAPIUrl('SAVENAMEVALUEPAIRS', { Id: createdFolderId });
                $scope.mc.getlogDetails("Debug", 'Method:POST;URL:' + JSON.stringify(apiUrl));

                var promisenvp = applyService.PostNVP(apiUrl, requestBody);
                promisenvp.then(function(response) {
                    if (response && response.data && response.data.error && response.data.error.code) {
                        $scope.mc.getlogDetails("Error", 'Error:' + JSON.stringify(response));
                        if (response.data.error.code == 'InvalidCsrfToken' || response.data.error.code == 'InvalidToken') {
                            redirectUnauthorized();
                        } else {
                            deferedNVP.resolve(response);
                        }
                    } else {
                        $scope.mc.getlogDetails("Debug", 'Success');
                        deferedNVP.resolve(response);
                    }
                }, function(response) {
                    $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                    if (response && response.data && response.data.error && response.data.error.code) {
                        if (response.data.error.code == 'InvalidCsrfToken' || response.data.error.code == 'InvalidToken') {
                            redirectUnauthorized();
                        } else {
                            deferedNVP.resolve(response);
                        }
                    } else {
                        deferedNVP.resolve(response);
                    }
                });
                return deferedNVP.promise;
            }

            function GetTheContainerId() {

                var cId = -1;
                var Itemcount = vmApply.ApplyItemPath.length - 1;
                while (cId == -1 && Itemcount >= 0) {

                    if (vmApply.ApplyItemPath[Itemcount].FolderType == 'search') {
                        if (vmApply.ApplyItemPath[Itemcount] && vmApply.ApplyItemPath[Itemcount].searchprofile && vmApply.ApplyItemPath[Itemcount].searchprofile.container && vmApply.ApplyItemPath[Itemcount].searchprofile.container != -1)
                            cId = vmApply.ApplyItemPath[Itemcount].searchprofile.container;

                        Itemcount = Itemcount - 1;
                    } else {

                        cId = vmApply.ApplyItemPath[Itemcount].Id.replace(vmApply.selectedLibrary + '!', '');
                    }

                }
                if (cId == -1) {
                    cId = vmApply.ApplyItemPath[0].Id.replace(vmApply.selectedLibrary + '!', '');
                }
                return cId

            }

            function getEmailAddress(emailaddress, folder) {
                var defered = $q.defer();
                if (emailaddress != '') {
                    replacehashValues(emailaddress, folder).then(function(response) {

                        defered.resolve(response);

                    });
                } else {
                    defered.resolve('');
                }
                return defered.promise;
            }

            function CheckForEmailExists(emailaddress, count) {

                var defered = $q.defer();
                var body = {};
                if (count == 0) {
                    body.email = encodeURIComponent(emailaddress);
                } else {
                    body.email = encodeURIComponent(emailaddress) + '_' + count;
                }

                var apiUrl = applyFactory.getAPIUrl('SEARCHFOLDERS', body);
                $scope.mc.getlogDetails("Debug", 'apiUrl:' + apiUrl);
                var EmailAddress = applyService.getData(apiUrl, "");
                EmailAddress.then(function(response) {
                    $scope.mc.getlogDetails("Debug", 'Email Response for ' + body.email + 'response' + JSON.stringify(response));

                    if (response.data.data.length > 0) {
                        CheckForEmailExists(emailaddress, count + 1).then(function(emailResponse) {
                            defered.resolve(decodeURIComponent(emailResponse));
                        });
                    } else {
                        defered.resolve(decodeURIComponent(body.email));

                    }
                });

                return defered.promise;
            }

            function replacehashValues(emailaddress, folder) {
                var finalDeferd = $q.defer();
                var defferedArray = [];
                if (emailaddress) {
                    var defererednorm = $q.defer();
                    defferedArray.push(defererednorm.promise);
                    do {
                        if ((emailaddress.search(/#C([1-9]|[1][0-9]|[2][09]|[3][0])Alias#/i) != -1)) {

                            var matches = emailaddress.match(/#C([1-9]|[1][0-9]|[2][09]|[3][0])Alias#/i)


                            var mdata = matches[0].match(/\d+/g);
                            var customValue = 'Custom' + mdata[0]
                            if (vmApply.workSpaceUIModel[customValue])
                                emailaddress = emailaddress.replace(matches[0], vmApply.workSpaceUIModel[customValue])
                            else
                                emailaddress = emailaddress.replace(matches[0], '')

                        }
                    } while ((emailaddress.search(/#C([1-9]|[1][0-9]|[2][09]|[3][0])Alias#/i) != -1))
                    do {
                        if (emailaddress.search(/#C([1-9]|[1][0-2]|[2][9]|[3][0])DESCR#/i) != -1) {
                            var deferd1 = $q.defer();
                            defferedArray.push(deferd1.promise);
                            var matches = emailaddress.match(/#C([1-9]|[1][0-2]|[2][9]|[3][0])DESCR#/i)
                            var mdata = matches[0].match(/\d+/g);
                            var requestObj = {};

                            if (vmApply.workSpaceUIModel['Custom' + mdata[0]]) {
                                emailaddress = emailaddress.replace(matches[0], '#C' + mdata[0] + 'DESCRIPTION#');
                                requestObj.alias = vmApply.workSpaceUIModel['Custom' + mdata[0]];
                                requestObj.type = '';
                                if (mdata[0] == '2')
                                    requestObj.type = 'custom1/' + vmApply.workSpaceUIModel['Custom1'] + '/';
                                if (mdata[0] == '30')
                                    requestObj.type = 'custom29/' + vmApply.workSpaceUIModel['Custom29'] + '/';
                                requestObj.type += 'custom' + mdata[0];
                                var apiUrl = applyFactory.getAPIUrl('GETMETADATA', requestObj);
                                $scope.mc.getlogDetails("Debug", 'Method:GET;URL' + JSON.stringify(apiUrl));
                                var promise = applyService.getData(apiUrl, "")
                                promise.then(function(response) {
                                    if (response["status"] == 200 && response.data && response.data.data) {

                                        emailaddress = emailaddress.replace('#C' + mdata[0] + 'DESCRIPTION#', response.data.data['description'])
                                        deferd1.resolve(emailaddress);
                                    }
                                });
                            } else {
                                emailaddress = emailaddress.replace(matches[0], '');
                                deferd1.resolve(emailaddress);
                            }



                        }
                    } while (emailaddress.search(/#C([1-9]|[1][0-2]|[2][9]|[3][0])DESCR#/i) != -1);
                    do {
                        if (emailaddress.search(/#USERID#/i) != -1) {

                            var matches = emailaddress.match(/#USERID#/i)
                            emailaddress = emailaddress.replace(matches[0], $scope.mc.loginModel.UserName);


                        }
                    } while ((emailaddress.search(/#USERID#/i) != -1));

                    do {
                        if (emailaddress.search(/#USERFULLNAME#/i) != -1) {

                            var matches = emailaddress.match(/#USERFULLNAME#/i)
                            emailaddress = emailaddress.replace(matches[0], $scope.mc.loginModel.FullName);

                        }
                    } while ((emailaddress.search(/#USERFULLNAME#/i) != -1));

                    do {
                        if (emailaddress.search(/#FOLDERNAME#/i) != -1) {

                            var matches = emailaddress.match(/#FOLDERNAME#/i)
                            emailaddress = emailaddress.replace(matches[0], folder.Name);

                        }
                    } while ((emailaddress.search(/#FOLDERNAME#/i) != -1));

                    defererednorm.resolve(emailaddress);
                }
                $q.all(defferedArray).then(function() {
                    finalDeferd.resolve(emailaddress);
                });
                return finalDeferd.promise;

            }

            function getCaptions() {

                var caprequestModel = homeFactory.requestModelInstance();
                if (!vmApply.selectedLibrary)
                    vmApply.selectedLibrary = $scope.mc.objectDet.wid.split('!')[0];

                caprequestModel.libraryName = vmApply.selectedLibrary;
                caprequestModel.isTotal = true;
                caprequestModel.searchText = '';
                caprequestModel.pageLength = 1000;
                caprequestModel.locale = 1033;
                var apiUrl = homeFactory.getAPIUrl('SEARCHCAPTIONS', caprequestModel)
                $scope.mc.getlogDetails("Debug", 'Requested Api Url:' + JSON.stringify(apiUrl));
                var promise = homeService.getData(apiUrl, "");
                promise.then(function(response) {
                    $scope.appsVar.CaptionsList = [];
                    if (response) {

                        angular.forEach(response.data["data"], function(caption) {
                            $scope.appsVar.CaptionsList.push(homeFactory.getCaptionUIModel(caption));
                        });


                    }
                });
            }

            function getUserPhoto(userItem) {

                var defer = $q.defer();
                userItem.UserPhoto = undefined;
                userItem.UserPhotoText = '';
                if (userItem.UserId === '' || !userItem.UserId) {
                    defer.resolve(userItem);

                } else {
                    userItem.UserPhotoText = '';

                    var nextChar = '';
                    var photoText = '';
                    var spaceFound = false;



                    //if (userItem.FullName)
                    //    userItem.FullName = userItem.FullName.trim().toUpperCase();
                    if (userItem.FullName && userItem.FullName.length > 0) {
                        spaceFound = false;
                        for (var iCount = 0; iCount < userItem.FullName.length; iCount++) {
                            nextChar = userItem.FullName.substr(iCount, 1).trim();
                            if (nextChar.length === 0) {
                                spaceFound = true;
                                continue;
                            }
                            if (spaceFound) {
                                photoText = nextChar;
                                spaceFound = false;
                            }
                        }
                        if (photoText.trim().length === 0) {
                            photoText = userItem.FullName.substr(0, 2);
                        } else {
                            photoText = userItem.FullName.substr(0, 1) + photoText;
                        }
                    } else {
                        photoText = userItem.UserId.trim().substr(0, 2);
                    }
                    userItem.UserPhotoText = photoText.toUpperCase();

                    var apiUrl = homeFactory.getUserPhotoAPI(userItem.UserId);
                    var promise = homeService.getImageData(apiUrl, '');
                    promise.then(function(response) {
                        if (response.status === 200 && response.data) {
                            var blob = new Blob([response.data], { type: 'application/octet-stream' });
                            var URL = $window.URL || $window.webkitURL;
                            userItem.UserPhoto = URL.createObjectURL(blob);
                            defer.resolve(userItem);
                        } else {
                            defer.resolve(userItem);
                        }
                    }, function(response) {
                        userItem.UserPhoto = undefined;
                        defer.resolve(userItem);
                    });


                }
                return defer.promise;
            }


            function redirectUnauthorized() {
                $timeout(function() { $mdDialog.hide(); });
                $mdDialog.show($mdDialog.alert()
                    .parent(angular.element(document.body))
                    .clickOutsideToClose(true)
                    .title('Warning!')
                    .textContent('Your session ended due to unknown reason sorry for the inconvenience. Please login again')
                    .ariaLabel('')
                    .ok('OK'));
                resetAllValues();
                redirectToLogin();
            }

        }
    });
})();