(function () {
    'use strict';

    define(['angular'], function (angular) {
        angular.module('iManage').factory('applyFactory', applyFactory);
        applyFactory.$inject = ['TSU_TEMPLATES', 'CONST_WORKSPACETEMP', '$q', 'CONST_TEMPLATE_FOLDER', 'CONST_SYSTEM_CONFIG', 'CONST_SECURITY_MODEL', 'ACONST_USERS', 'CONST_NAME_VALUE_PAIRS'];
        function applyFactory(TSU_TEMPLATES, CONST_WORKSPACE, $q, CONST_TEMPLATE_FOLDER, CONST_SYSTEM_CONFIG, CONST_SECURITY_MODEL, CONST_USERS,CONST_NAME_VALUE_PAIRS) {

            var workSpaceUIModel = {
                Id: '',
                Author: '',
                Class: '',
                CreateDate: '',                
                Database: '',
                DefaultSecurity: '',
                DocumentNumber: 0,
                EditDate: '',
                EditProfileDate: '',
                FileCreateDate: '',
                FileEditDate: '',
                Iwl: '',
                LastUser: '',
                Location: '',
                Name: '',
                Operator: '',
                Owner: '',
                RetainDays: 0,
                Size: 0,
                Subtype: '',
                Type: '',
                Version: 0,
                Wstype: '',
                HasAttachment: false,
                HasSubfolders: false,
                InUse: false,
                Indexable: false,
                IsCheckedOut: false,
                IsContainerSavedSearch: false,
                IsContentSavedSearch: false,
                IsExternal: false,
                IsExternalAsNormal: false,
                IsHidden: false,
                IsHipaa: false
            };

            var folderUIModel = {
                Database: '',
                DefaultSecurity: '',
                Description:'',
                EditDate: '',
                FolderType: '',
                HasSubfolders: '',
                Id: '',
                IsContainerSavedSearch: '',
                IsContentSavedSearch: '',
                IsExternalAsNormal: '',
                IsHidden: '',
                Name: '',
                Owner: '',
                ParentId: '',
                SubType: '',
                ViewType: '',
                Wstype: ''
            };

            var SystemConfigUIModel = {
                IMCC_OF_MATCHFIELDS: ''
            };

            var returnWorkSpaceInitialValueSettings = function () {
                return angular.copy(workSpaceUIModel);
            };

            function getWorkSpaceUIModel(workSpaceApiModel) {
                var workSpaceModel = angular.copy(workSpaceUIModel);
                workSpaceModel.Author = workSpaceApiModel[CONST_WORKSPACE.Author];//.user_id_ex;
                workSpaceModel.Class = workSpaceApiModel[CONST_WORKSPACE.Class];
                workSpaceModel.CreateDate = GetDate(workSpaceApiModel[CONST_WORKSPACE.CreateDate]);

                for (var i = 1; i <= 30; i++)
                {
                    if (workSpaceApiModel["custom" + i])
                         workSpaceModel["Custom" + i] = workSpaceApiModel["custom"+i];
                   
                }
             
                workSpaceModel.Database = workSpaceApiModel[CONST_WORKSPACE.Database];
                workSpaceModel.DefaultSecurity = workSpaceApiModel[CONST_WORKSPACE.DefaultSecurity];
                workSpaceModel.DocumentNumber = workSpaceApiModel[CONST_WORKSPACE.DocumentNumber];
                workSpaceModel.EditDate = GetDate(workSpaceApiModel[CONST_WORKSPACE.EditDate]);
                workSpaceModel.EditProfileDate = GetDate(workSpaceApiModel[CONST_WORKSPACE.EditProfileDate]);
                workSpaceModel.FileCreateDate = GetDate(workSpaceApiModel[CONST_WORKSPACE.FileCreateDate]);
                workSpaceModel.FileEditDate = GetDate(workSpaceApiModel[CONST_WORKSPACE.FileEditDate]);
                workSpaceModel.HasAttachment = workSpaceApiModel[CONST_WORKSPACE.HasAttachment];
                workSpaceModel.HasSubfolders = workSpaceApiModel[CONST_WORKSPACE.HasSubfolders];
                workSpaceModel.Id = workSpaceApiModel[CONST_WORKSPACE.Id];

                workSpaceModel.Owner = workSpaceApiModel[CONST_WORKSPACE.Owner];
                workSpaceModel.RetainDays = workSpaceApiModel[CONST_WORKSPACE.RetainDays];
                workSpaceModel.Size = workSpaceApiModel[CONST_WORKSPACE.Size];
                workSpaceModel.Subtype = workSpaceApiModel[CONST_WORKSPACE.Subtype];
                workSpaceModel.Type = workSpaceApiModel[CONST_WORKSPACE.Type];
                workSpaceModel.Version = workSpaceApiModel[CONST_WORKSPACE.Version];
                workSpaceModel.Wstype = workSpaceApiModel[CONST_WORKSPACE.Wstype];

                workSpaceModel.InUse = workSpaceApiModel[CONST_WORKSPACE.InUse];
                workSpaceModel.Operator = workSpaceApiModel[CONST_WORKSPACE.Operator];
                workSpaceModel.Name = workSpaceApiModel[CONST_WORKSPACE.Name];
                workSpaceModel.Location = workSpaceApiModel[CONST_WORKSPACE.Location];
                workSpaceModel.LastUser = workSpaceApiModel[CONST_WORKSPACE.LastUser];
                workSpaceModel.Iwl = workSpaceApiModel[CONST_WORKSPACE.Iwl];
                workSpaceModel.IsHipaa = workSpaceApiModel[CONST_WORKSPACE.IsHipaa];
                workSpaceModel.IsHidden = workSpaceApiModel[CONST_WORKSPACE.IsHidden];
                workSpaceModel.IsExternalAsNormal = workSpaceApiModel[CONST_WORKSPACE.IsExternalAsNormal];
                workSpaceModel.IsExternal = workSpaceApiModel[CONST_WORKSPACE.IsExternal];
                workSpaceModel.IsContentSavedSearch = workSpaceApiModel[CONST_WORKSPACE.IsContentSavedSearch];

                workSpaceModel.Indexable = workSpaceApiModel[CONST_WORKSPACE.Indexable];
                workSpaceModel.IsCheckedOut = workSpaceApiModel[CONST_WORKSPACE.IsCheckedOut];
                workSpaceModel.IsContainerSavedSearch = workSpaceApiModel[CONST_WORKSPACE.IsContainerSavedSearch];
                return workSpaceModel;
            }

            function GetMonthName(monthNumber) {
                var month = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                return month[monthNumber - 1];
            }

            function GetDate(dateString) {
                var dateObj = new Date(dateString);
                if (dateObj != 'Invalid Date') {
                    var monthNumber = dateObj.getMonth() + 1;
                    var monthName = GetMonthName(monthNumber);
                    return monthName + " " + dateObj.getDate() + ", " + dateObj.getFullYear();

                }
                else {
                    return '';
                }
            }

            var returnWorkSpaceUIModel = function (workSpaceApiModel) {
                return getWorkSpaceUIModel(workSpaceApiModel);
            };

            
            var returnSecurityModelUI = function (securityModel) {
                return getSecurityUIModel(securityModel);
            }

            var returngetFolderUI = function (folderApiModel) {
                return getFolderUIModel(folderApiModel);
            }

            var returngetMatchFields = function (systemConfigApiModel) {
                return getMatchFields(systemConfigApiModel);
            }

            var returnGetNVPUI = function (nvpData) {
                
                    if (nvpData.IMCC_Name_Prefix && nvpData.IMCC_Name_Prefix.indexOf(CONST_NAME_VALUE_PAIRS.PREFIX) == 0 && nvpData.IMCC_Name_Prefix.lastIndexOf(CONST_NAME_VALUE_PAIRS.PREFIX) ==nvpData.IMCC_Name_Prefix.length-CONST_NAME_VALUE_PAIRS.PREFIX.length) {
                         
                        var prefixvalue = nvpData.IMCC_Name_Prefix.substring(0, nvpData.IMCC_Name_Prefix.length - CONST_NAME_VALUE_PAIRS.PREFIX.length);
                   
                        prefixvalue = prefixvalue.substring(CONST_NAME_VALUE_PAIRS.PREFIX.length);
                    
                         nvpData.IMCC_Name_Prefix = prefixvalue;
                    }
                
                return nvpData;
            }

            function returnGroupUsersAPI(requestModel, GroupName) {
                var apiUrl = baseUrl + TSU_TEMPLATES['GETGROUPUSERS'];
                apiUrl = apiUrl.replace("<group_alias>", GroupName);

                apiUrl += "?database=" + requestModel.libraryName + '&offset=' + (requestModel.pagenumber - 1) * requestModel.pageLength +
                            '&limit=' + requestModel.pageLength + '&total=' + requestModel.isTotal;

                if (requestModel.searchText.trim().length > 0)
                    apiUrl += '&alias=*' + requestModel.searchText.trim() + '*';

                return apiUrl;
            };

            function getMatchFields(systemConfigApiModel) {
                var systemConfigModel = angular.copy(SystemConfigUIModel);
                systemConfigModel.IMCC_OF_MATCHFIELDS = systemConfigApiModel[CONST_SYSTEM_CONFIG.IMCC_OF_MATCHFIELDS];
                return systemConfigModel;
            }
            function getSecurityUIModel(SModel) {
                var secModel = {};                
                secModel.Access = SModel[CONST_SECURITY_MODEL.Access];
                secModel.AccessLevel = GetAccessLevel(SModel[CONST_SECURITY_MODEL.AccessLevel]);
                secModel.Id = SModel[CONST_SECURITY_MODEL.Id];
                secModel.Name = SModel[CONST_SECURITY_MODEL.Name];
                secModel.SID = SModel[CONST_SECURITY_MODEL.SID];
                secModel.Type = SModel[CONST_SECURITY_MODEL.Type];          

                return secModel;
            }

            function GetAccessLevel(accessstr) {
                var returnstr = 'No Access'
                switch (accessstr) {
                    case "full_access": returnstr = 'Full Access';
                        break;
                    case "read_write": returnstr = 'Read/Write';
                        break;
                    case "read": returnstr = 'Read';
                        break;
                    default: break;
                }
                return returnstr;
            }

            function getFolderUIModel(folderApiModel) {
                var folderModel = angular.copy(folderUIModel);
                folderModel.Database = folderApiModel[CONST_TEMPLATE_FOLDER.Database];
                folderModel.DefaultSecurity = folderApiModel[CONST_TEMPLATE_FOLDER.DefaultSecurity];
                folderModel.Description = folderApiModel[CONST_TEMPLATE_FOLDER.Description];
                folderModel.EditDate = GetDate(folderApiModel[CONST_TEMPLATE_FOLDER.EditDate]);
                folderModel.FolderType = folderApiModel[CONST_TEMPLATE_FOLDER.FolderType];
                folderModel.HasSubfolders = folderApiModel[CONST_TEMPLATE_FOLDER.HasSubfolders];
                folderModel.Id = folderApiModel[CONST_TEMPLATE_FOLDER.Id];
                folderModel.IsContainerSavedSearch = folderApiModel[CONST_TEMPLATE_FOLDER.IsContainerSavedSearch];
                folderModel.Location = folderApiModel[CONST_TEMPLATE_FOLDER.Location];
                folderModel.IsContentSavedSearch = folderApiModel[CONST_TEMPLATE_FOLDER.IsContentSavedSearch];
                folderModel.IsExternalAsNormal = folderApiModel[CONST_TEMPLATE_FOLDER.IsExternalAsNormal];
                folderModel.IsHidden = folderApiModel[CONST_TEMPLATE_FOLDER.IsHidden];
                folderModel.Name = folderApiModel[CONST_TEMPLATE_FOLDER.Name];
                folderModel.Owner = folderApiModel[CONST_TEMPLATE_FOLDER.Owner];
                folderModel.ParentId = folderApiModel[CONST_TEMPLATE_FOLDER.ParentId];
                folderModel.SubType = folderApiModel[CONST_TEMPLATE_FOLDER.SubType];
                folderModel.ViewType = folderApiModel[CONST_TEMPLATE_FOLDER.ViewType];
                folderModel.Wstype = folderApiModel[CONST_TEMPLATE_FOLDER.Wstype];
                folderModel.Email = folderApiModel[CONST_TEMPLATE_FOLDER.Email];
                return folderModel;
            }

            function prepareFolderGetUrl(URL, requestModel) {
                var apiGetUrl = URL + '?offset=' + ((requestModel.pagenumber - 1) * requestModel.pageLength).toString();
                apiGetUrl += '&limit=' + requestModel.pageLength.toString() + '&total=' + requestModel.isTotal;
                requestModel.searchText = requestModel.searchText.trim();
                if (requestModel.searchText.length > 0) {
                    apiGetUrl += '&name=*' + requestModel.searchText + '*';
                }
                return apiGetUrl;
            }

            var returnUserDetail = function (UserId) {
                var ApiUrl = baseUrl + TSU_TEMPLATES['GET_SINGLE_USER'];
                ApiUrl = ApiUrl.replace('<user_id>', UserId);
                return ApiUrl;
            }

            var returnAPIUrl = function (APIFOR, requestModel) {
                var ApiUrl = baseUrl + TSU_TEMPLATES[APIFOR];

                if (APIFOR === 'SECURITYPROFILE') {
                    if (requestModel.Id) {

                        ApiUrl = ApiUrl.replace('{FID}', requestModel.Id);
                    }
                }
                else if ((APIFOR === 'FOLDERPROFILE' || APIFOR === 'TABSPROFILE' || APIFOR === 'SEARCHPROFILE') && requestModel !== null) {

                    if (requestModel.Id) {
                        
                        ApiUrl = ApiUrl.replace('{folderId}', requestModel.Id);
                    }

                }
                else if (APIFOR === 'SEARCHFOLDERS' && requestModel !== null) {

                    if (requestModel.email) {
                        ApiUrl = ApiUrl + '?email=' + requestModel.email;

                    }

                }
                else if (APIFOR === 'SAVENAMEVALUEPAIRS' && requestModel !== null) {
                   
                    ApiUrl = ApiUrl.replace('{WS_ID}', requestModel.Id);
                    ApiUrl = ApiUrl.replace('{name}', requestModel.key);
                    ApiUrl = ApiUrl.replace('{value}', requestModel.value);
                    
                }
                else if (APIFOR === 'GETFOLDERPATH' && requestModel !== null) {
                    ApiUrl = ApiUrl.replace('{FOLDER_ID}', requestModel.Id);
                } else if (APIFOR === 'GETMETADATA' && requestModel !== null) {
                    ApiUrl = ApiUrl.replace('{ALIAS}', requestModel.alias);
                    ApiUrl = ApiUrl.replace('{CTYPE}', requestModel.type);
                } else if (APIFOR === 'GETNAMEVALUEPAIRS' && requestModel !== null) {
                    ApiUrl = ApiUrl.replace('{WS_ID}', requestModel.Id);
                } else if (APIFOR === 'GETWORKSPACE' && requestModel !== null) {
                    ApiUrl = ApiUrl.replace('{WS_ID}', requestModel.Id);
                }
                else if (APIFOR === 'SEARCHTEMPLATE' && requestModel !== null) {
                    ApiUrl = prepareGetUrl(ApiUrl, requestModel);
                }
                else if (APIFOR == 'GETFOLDERSFROMWORKSPCE') {
                    ApiUrl = ApiUrl.replace('{WS_ID}', requestModel.Id);
                    ApiUrl = prepareFolderGetUrl(ApiUrl, requestModel);
                }
                else if (APIFOR == 'GETSUBFOLDERFROMFOLDER') {
                    ApiUrl = ApiUrl.replace('{FOLDER_ID}', requestModel.Id);
                    ApiUrl = prepareFolderGetUrl(ApiUrl, requestModel);
                }                 
                return ApiUrl;
            };



            function returnFolderPostAPI(parentId, type) {
                var apiUrl = '';
                if (type == 'regular') {
                    apiUrl = baseUrl + TSU_TEMPLATES['POST_FOLDER'];
                    apiUrl = apiUrl.replace('<workspace_id>', parentId);
                }
                else if (type == 'tab') {
                    apiUrl = baseUrl + TSU_TEMPLATES['POST_TABS'];
                    apiUrl = apiUrl.replace('<workspace_id>', parentId);
                }
                else if (type == 'search') {
                    apiUrl = baseUrl + TSU_TEMPLATES['POST_SEARCH_FOLDERS'];
                    apiUrl = apiUrl.replace('<workspace_id>', parentId);
                }
                return apiUrl;
            }

            function returnFolderPostAPIModel(folderUIModel) {
                var apiModel = {};
                apiModel[CONST_TEMPLATE_FOLDER.Database] = folderUIModel.Database;
                apiModel[CONST_TEMPLATE_FOLDER.DefaultSecurity] = folderUIModel.DefaultSecurity;
                apiModel[CONST_TEMPLATE_FOLDER.Description] = folderUIModel.Description;
                apiModel[CONST_TEMPLATE_FOLDER.Owner] = folderUIModel.Owner;
                apiModel[CONST_TEMPLATE_FOLDER.Name] = folderUIModel.Name;
                apiModel[CONST_TEMPLATE_FOLDER.Email] = folderUIModel.Email;
                if (folderUIModel.searchprofile) {
                    apiModel["searchprofile"] = folderUIModel.searchprofile; //{ "author": folderUIModel.Owner }
                }
                if (folderUIModel.profile) {
                    apiModel["profile"] = folderUIModel.profile; //{ "author": folderUIModel.Owner }
                }
                return apiModel;
            }
            function returnProfileInfo(wsModel) {
                var apiModel = {};

                for (var i = 1; i < 31; i++) {
                    if (wsModel['custom' + i])
                    {
                        apiModel['custom' + i] = wsModel['custom' + i];
                    }
                }
                return apiModel;
            }
            function returnProfileInfoUIModel(profileInfo,title,containerName) {
                var apiModel = {};
                if(title=='Search Profile')
                    apiModel['Restrict Search To'] = 'Documents and E-mails';
                angular.forEach(profileInfo, function (value, key) {
                    try{
                        switch (key) {
                            case 'author':
                            
                                apiModel['Author'] = value;
                                break;
                            case 'operator':
                             
                                apiModel['Operator'] = value;
                                break;
                            case 'emails_only':
                                if (value)
                                    apiModel['Restrict Search To'] = 'E-mails Only';
                                break;
                            case 'documents_only':
                                if (value)
                                    apiModel['Restrict Search To'] = 'Documents Only';
                                break;
                            case 'databases':
                                if (!apiModel['Search Scope'])
                                    apiModel['Search Scope'] = containerName + '<' + value + '>';
                           
                                break;
                            case 'container':
                                if (!apiModel['Search Scope'])
                                    apiModel['Search Scope'] = containerName + '<' + profileInfo['databases'] + '>';
                                break;
                            case 'description_fulltext':
                            case 'comments_fulltext':
                            case 'comments_description_fulltext':
                            case 'body':
                            case 'fulltext':
                                if (key == 'fulltext')
                                    apiModel['Look For Anywhere'] = value;
                                if (key == 'comments_fulltext')
                                    apiModel['Look For Comments'] = value;
                                if (key == 'comments_description_fulltext')
                                    apiModel['Look For Comments/Description'] = value;
                                if (key == 'body')
                                    apiModel['Look For Document contents'] = value;
                                if (key == 'description_fulltext')
                                    apiModel['Look For Description'] = value;
                                if (profileInfo['languageid']) {
                                    switch (profileInfo['languageid']) {
                                        case 'englishUTF8': apiModel['Langage'] ='English'; break;
                                        case 'frenchUTF8':apiModel['Langage'] ='French(Fran�ais)'; break;
                                        case 'germanUTF8':apiModel['Langage'] ='German(Deutsch)'; break;
                                        case 'spanishUTF8':apiModel['Langage'] ='Spanish(Espa�ol)'; break;
                                        case 'chineseUTF8':apiModel['Langage'] ='Chinese'; break;
                                        case 'japaneseUTF8':apiModel['Langage'] ='Japanese'; break;
                                        case 'polishUTF8':apiModel['Langage'] ='Polish(Polski)'; break;
                                        default:
                                            apiModel['Langage'] ='English';
                                    }
                                }
                                else
                                    apiModel['Langage'] = 'Any Language';
                            
                                break;
                            default:
                                if (key == 'create_date_start' || key == 'create_date_end' || key == 'create_date_relative') {
                                    if (!apiModel['Create Date']) {
                                        apiModel['Create Date'] = GenerateDateModel(profileInfo['create_date_relative'], profileInfo['create_date_start'], profileInfo['create_date_end']);
                                    }
                                }else  if (key == 'custom21_from' || key == 'custom21_to' || key == 'custom21_relative') {
                                    if (!apiModel['custom21']) {
                                        apiModel['custom21'] = GenerateDateModel(profileInfo['custom21_relative'], profileInfo['custom21_from'], profileInfo['custom21_to']);
                                    }
                                } else if (key == 'custom22_from' || key == 'custom22_to' || key == 'custom22_relative') {
                                    if (!apiModel['custom22']) {
                                        apiModel['custom22'] = GenerateDateModel(profileInfo['custom22_relative'], profileInfo['custom22_from'], profileInfo['custom22_to']);
                                    }
                                } else if (key == 'custom23_from' || key == 'custom23_to' || key == 'custom23_relative') {
                                    if (!apiModel['custom23']) {
                                        apiModel['custom23'] = GenerateDateModel(profileInfo['custom23_relative'], profileInfo['custom23_from'], profileInfo['custom23_to']);
                                    }
                                } else if (key == 'custom24_from' || key == 'custom24_to' || key == 'custom24_relative') {
                                    if (!apiModel['custom24']) {
                                        apiModel['custom24'] = GenerateDateModel(profileInfo['custom24_relative'], profileInfo['custom24_from'], profileInfo['custom24_to']);
                                    }
                                } else if (key == 'edit_date_start' || key == 'edit_date_end' || key == 'edit_date_relative') {
                                    if (!apiModel['Edit Date']) {
                                        apiModel['Edit Date'] = GenerateDateModel(profileInfo['edit_date_relative'], profileInfo['edit_date_start'], profileInfo['edit_date_end']);
                                    }
                                }
                                else if (key.search(/custom([1-9]|[1][0-9]|[2][0-9]|[3][0])/i) != -1) {
                                    var matches = key.match(/custom([1-9]|[1][0-9]|[2][09]|[3][0])/i);
                                    
                                    if (key != matches[0] + '_description' && key != matches[0] + '9_description' && key != matches[0] + '0_description') {
                                         
												if (profileInfo[matches[0] + '_description'] && key==matches[0]) {
                                                    apiModel[key] = value + '-' + profileInfo[matches[0] + '_description'];
                                                }else if (profileInfo[matches[0] + '9_description'] && key==matches[0]+'9') {
                                                    apiModel[key] = value + '-' + profileInfo[matches[0] + '9_description'];
                                                }else if (profileInfo[matches[0] + '0_description'] && key==matches[0]+'0') {
                                                    apiModel[key] = value + '-' + profileInfo[matches[0] + '0_description'];
                                                }else {
                                                    apiModel[key] = value;
                                                }
                                    }
                                   
                                }
                                else if (key != 'languageid' && key != 'content_type')
                                    apiModel[key] = value;
                        }
                    } catch (exp) {

                    }
                       
                });
                
                return apiModel;
            }
            function GenerateDateModel(rel, start, end) {
                if (rel) {
                    if(rel=="-1:-1d"){
                        return 'Yesterday';
                    }else if(rel=="0:0d"){
                        return 'Today';
                    }else if(rel=="-6:0d"){
                        return 'Last 7 days';
                    }else{
                        return 'Last 30 days';
                    }
                    
                } else if (start == end) {
                    return 'On ' + start;
                } else if (end == '12/30/9999 23:59:59') {
                    return 'On or after ' + start;
                } else if (start == '01/01/1753 00:00:00') {
                    return 'On or before ' + end;
                } else  {
                    return 'Between ' + start + ' and  '+end;
                }
            }

            function prepareGetWSUrl(URL, requestModel) {
                var apiGetUrl = URL + '?offset=' + ((requestModel.pagenumber - 1) * requestModel.pageLength).toString();
                apiGetUrl += '&limit=' + requestModel.pageLength.toString() + '&total=' + requestModel.isTotal;
                requestModel.searchText = requestModel.searchText.trim();
                if (requestModel.searchText.length > 0) {
                   
                    apiGetUrl += '&name=*' + requestModel.searchText + '*';
                   
                }
               
                if (requestModel.MatchField && requestModel.MatchField.length > 0) {

                    angular.forEach(requestModel.MatchField, function (matchData) {
                        apiGetUrl += '&' + matchData + '=*' + requestModel[matchData] + '*';
                    });
                }
                return apiGetUrl;
            }

            function prepareGetUrl(URL, requestModel) {
                var apiGetUrl = URL + '?offset=' + ((requestModel.pagenumber - 1) * requestModel.pageLength).toString();
                apiGetUrl += '&limit=' + requestModel.pageLength.toString() + '&total=' + requestModel.isTotal + '&scope=' + requestModel.libraryName;
                requestModel.searchText = requestModel.searchText.trim();
                if (requestModel.searchText.length > 0) {
                    apiGetUrl += '&name=*' + requestModel.searchText + '*';
                }
                if (requestModel.MatchField && requestModel.MatchField.length > 0) {

                    angular.forEach(requestModel.MatchField, function (matchData) {
                        apiGetUrl += '&' + matchData.toLowerCase() + '=' + requestModel[matchData] + '';
                    });
                }
                return apiGetUrl;
            }

            function getUserUIModel(userApiModel) {
                var userModel = {};
                userModel.UserId = userApiModel[CONST_USERS.UserIdEx] || userApiModel[CONST_USERS.UserId];//.user_id_ex;
                userModel.FullName = userApiModel[CONST_USERS.FullName];
                userModel.Location = userApiModel[CONST_USERS.Location];
                userModel.Phone = userApiModel[CONST_USERS.Phone];
                userModel.Ext = userApiModel[CONST_USERS.Ext];
                userModel.Fax = userApiModel[CONST_USERS.Fax];
                userModel.Email = userApiModel[CONST_USERS.Email];
                userModel.IsExternalUser = userApiModel[CONST_USERS.IsExternalUser];
                userModel.Password = userApiModel[CONST_USERS.Password];
                userModel.UserMustChangePassword = userApiModel[CONST_USERS.UserMustChangePassword];
                userModel.PasswordNeverExpires = userApiModel[CONST_USERS.PasswordNeverExpires];
                userModel.IsAllowLogon = userApiModel[CONST_USERS.IsAllowLogon];
                userModel.PreferredDatabase = userApiModel[CONST_USERS.PreferredDatabase];
                userModel.FileServer = userApiModel[CONST_USERS.FileServer];
                userModel.SecuredDocServer = userApiModel[CONST_USERS.SecuredDocServer];                
                userModel.UserNum = userApiModel[CONST_USERS.UserNum];
                userModel.UserIdEx = userApiModel[CONST_USERS.UserId];
                userModel.FailedLogin = userApiModel[CONST_USERS.FailedLogin];
                userModel.DistName = userApiModel[CONST_USERS.DistName];
                userModel.UserDomain = userApiModel[CONST_USERS.UserDomain];
                userModel.ExchAutoDiscover = userApiModel[CONST_USERS.ExchAutoDiscover];
                return userModel;

            }


            return {
                workSpaceInitailValues: returnWorkSpaceInitialValueSettings,
                getworkSpaceUI: returnWorkSpaceUIModel,
                getAPIUrl: returnAPIUrl,
                getFolderUI: returngetFolderUI,
                getSecurityModelUI: returnSecurityModelUI,
                getMatchFields: returngetMatchFields,
                getFolderPostAPIModel: returnFolderPostAPIModel,
                getFolderPostAPI: returnFolderPostAPI,
                getProfileInfo: returnProfileInfo,
                getUserUI: getUserUIModel,
                getGroupUsersAPI:returnGroupUsersAPI,
                GetProfileInfoUI: returnProfileInfoUIModel,
                getUserDetail: returnUserDetail,
                GetNVPUI: returnGetNVPUI
            }
        }
    });
})();