(function () {
    'use strict';

    define(['angular'], function () {
        angular.module('iManage').service("applyService", applyService);
        applyService.$inject = ['$http'];

        function applyService($http) {

            this.getData = function (URL, key) {
                var promise = $http({
                    url: URL,
                    method: "GET" 
                    
                });
                return promise;
            };

            this.getFoldersFromWorkspace = function (URL, key) {
                var promise = $http({
                    url: URL,
                    method: "GET" 
                });
                return promise;
            };

            this.PostNVP = function (URL, body) {
                var promise = $http({
                    url: URL,
                    method: "POST",
                    data: JSON.stringify(body)
                });
                return promise;
            };

            this.PutNVP = function (URL, body) {
                var promise = $http({
                    url: URL,
                    method: "PUT",
                    data: JSON.stringify(body)
                });
                return promise;
            };

            this.addFolder = function (URL, key, requestBody) {
                var promise = $http({
                    url: URL,
                    method: "POST" ,
                    data: JSON.stringify(requestBody)
                });
                return promise;
            };


        }
    });
})();