﻿(function () {
    'use strict';

    define(['angular'], function () {
        angular.module('iManage').service("adHocFolderService", adHocFolderService);
        adHocFolderService.$inject = ['$http'];

        function adHocFolderService($http) {

            this.getData = function (apiUrl) {
                var promise = $http({
                    url: apiUrl,
                    method: "GET"
                });
                return promise;
            };

            this.getImageData = function (URL, key) {
                var promise = $http({
                    url: URL,
                    method: "GET",
                    responseType: "blob"
                });
                return promise;
            };

            this.addFolder = function (adHocFolder, apiUrl) {
                var promise = $http({
                    url: apiUrl,
                    method: "POST",
                    data: JSON.stringify(adHocFolder)
                });
                return promise;
            };
           
        }
    });
})();