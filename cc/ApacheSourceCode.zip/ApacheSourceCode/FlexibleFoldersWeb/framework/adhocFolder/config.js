﻿(function () {
    'use strict';

    require.config({
        paths: {
            adHocFolderController: 'adHocFolder/adHocFolderController',
            adHocFolderConstants: 'adHocFolder/adHocFolderConstants',
            adHocFolderFactory: 'adHocFolder/adHocFolderFactory',
            adHocFolderService: 'adHocFolder/adHocFolderService'
        }
    });

    define([
        'adHocFolderController',
        'adHocFolderConstants',
        'adHocFolderFactory',
        'adHocFolderService'
    ]);
})();