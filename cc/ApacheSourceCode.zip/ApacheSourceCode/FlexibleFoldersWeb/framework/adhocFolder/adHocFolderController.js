﻿/// <reference path="misc/AddDate.html" />
/// <reference path="misc/AddDate.html" />
/// <reference path="misc/AddDate.html" />
(function () {
    'use strict';

    angular.module('iManage').controller("adHocFolderController", adHocFolderController);

    adHocFolderController.$inject = ['$rootScope', '$scope', '$filter', '$timeout', '$window', '$q', 'adHocFolderFactory', '$mdConstant', 'homeFactory', 
										'adHocFolderService', '$location', '$mdDialog', '$mdMedia', 'homeService'];

    function adHocFolderController($rootScope, $scope, $filter, $timeout, $window, $q, adHocFolderFactory, $mdConstant, homeFactory, adHocFolderService, 
									$location, $mdDialog, $mdMedia, homeService) {
        var vmadHocFolder = this;
		
		var isSecurityListSearchTextDirty = false;
        var isgroupMemberSearchTextDirty = false;
        var isgroupMembersInstantSearch = false;
        var groupMembersTotalCount = 0;
        var securityListSearchTimeOut = null;
        var groupMemberSearchTimeOut = null;
        var groupMembersReqModel = homeFactory.requestModelInstance();
		
        // getting Query Parameter.
        var parentId = $location.search().parentid;
        vmadHocFolder.Opertion = $location.search().type;
        vmadHocFolder.NewItem = {};
        vmadHocFolder.displayLabel = 'Show';
        var sel = parentId.split("!");
        
        if (sel.length > 0) 
            vmadHocFolder.selectedLibrary = sel[0];
        
        vmadHocFolder.showArea = false;
        vmadHocFolder.FolderType = 'Folder';
        vmadHocFolder.maxChips = 1;
        vmadHocFolder.EmailDomain = '';
        vmadHocFolder.adHocFolderModel = adHocFolderFactory.adHocFolderInitialValues();
        vmadHocFolder.keys = [$mdConstant.KEY_CODE.ENTER, $mdConstant.KEY_CODE.COMMA];

        vmadHocFolder.adHocFolderModel.custom25 = 'inter';
        vmadHocFolder.adHocFolderModel.custom26 = 'inter';
        vmadHocFolder.adHocFolderModel.custom27 = 'inter';
        vmadHocFolder.adHocFolderModel.custom28 = 'inter';

        vmadHocFolder.isAddUserGroupDialogShowing = false;
        vmadHocFolder.IsInheritSecurity = true;
        vmadHocFolder.SecurityList = [];
        vmadHocFolder.NewUserGroupList = [];
        vmadHocFolder.SecurityListWithFilter = [];
        vmadHocFolder.SelectedUserGroup = null;
        vmadHocFolder.UserGroupSearchText = null;
        vmadHocFolder.SecurityListSearchText = '';
        vmadHocFolder.adHocFolderDefaultSecurity = 'private';
        vmadHocFolder.adHocFolderModel.DefaultSecurity = 'inherit';
		vmadHocFolder.RestrictTo = "DOCUMENTS";
		vmadHocFolder.IsGroupMemberVisible = false;
		vmadHocFolder.WithIn = 'CurrentDb';
		vmadHocFolder.adHocFolderModel.WithIn = vmadHocFolder.selectedLibrary;
		vmadHocFolder.GroupMembers = {
            SelectedGroup: null,
            HeaderText: '',
            SearchText: '',
            GroupMemberList: [],
            ClearSearchClick: groupMembers_ClearSearchClick,
            SearchClick: groupMembers_SearchClick,
            GroupMemberListScroll: groupMembers_onListScroll
        };
		
        vmadHocFolder.SearchSecurityUserGroup_Click = searchSecurityUserGroup_Click;
        vmadHocFolder.SelectedUserGroup_Change = selectedUserGroup_Change;
        vmadHocFolder.QuerySearchUserGroup = querySearchUserGroup;
        vmadHocFolder.addUserGroup = addUserGroup;
        vmadHocFolder.backFromAddUserGroup = backFromAddUserGroup;
        vmadHocFolder.saveSecurityUserGroup = saveSecurityUserGroup;
        vmadHocFolder.IsInheritSecurity_Change = isInheritSecurity_Change;
        vmadHocFolder.AccessLevel_Change = accessLevel_Change;
		vmadHocFolder.ShowGroupMemberList = showGroupMemberList;
        vmadHocFolder.HideGroupMemberList = hideGroupMemberList;
		
        $scope.$watch(function () { return vmadHocFolder.SecurityListSearchText; }, function (val) {
            if (vmadHocFolder.SecurityListSearchText.length > 0) {
                isSecurityListSearchTextDirty = true;
            }
            if (securityListSearchTimeOut) $timeout.cancel(securityListSearchTimeOut);

            securityListSearchTimeOut = $timeout(function () {
                if (isSecurityListSearchTextDirty) {
                    searchSecurityUserGroup_Click();
                }
            }, 2000);
        }, true);
		
		$scope.$watch(function () { return vmadHocFolder.GroupMembers.SearchText; }, function (val) {
            if (vmadHocFolder.GroupMembers.SearchText.length > 0) {
                isgroupMemberSearchTextDirty = true;
            }
            if (groupMemberSearchTimeOut)
                $timeout.cancel(groupMemberSearchTimeOut);

            if (isgroupMembersInstantSearch) {
                isgroupMembersInstantSearch = false;
                vmadHocFolder.GroupMembers.SearchClick();
            } else {
                groupMemberSearchTimeOut = $timeout(function () {
                    if (isgroupMemberSearchTextDirty) {
                        vmadHocFolder.GroupMembers.SearchClick();
                    }
                }, 2000);
            }
        }, true);

        getCaptions(); // need to move the same to initalize function;
        fillDBinUserList();
        getParentFolderProfile();
        getParentSecurity();
        
		if (vmadHocFolder.Opertion == 'imTypeDocumentSearchFolder') {
		    vmadHocFolder.maxChips = 1000;
		    vmadHocFolder.FolderType = 'Search Folder';
		    vmadHocFolder.isCustomChipSupport = false;
		    vmadHocFolder.adHocFolderModel.custom21 = 'Anytime';
		    vmadHocFolder.adHocFolderModel.custom22 = 'Anytime';
		    vmadHocFolder.adHocFolderModel.custom23 = 'Anytime';
		    vmadHocFolder.adHocFolderModel.custom24 = 'Anytime';
		    vmadHocFolder.adHocFolderModel.create_date = 'Anytime';
		    vmadHocFolder.adHocFolderModel.edit_date = 'Anytime';

        }
        else if (vmadHocFolder.Opertion == 'imTypeDocumentFolder') {
            vmadHocFolder.maxChips = 1;
            vmadHocFolder.FolderType = 'Folder';
            vmadHocFolder.isCustomChipSupport = true;
        }
        else if (vmadHocFolder.Opertion == 'imTypeTab') {
            vmadHocFolder.FolderType = 'Tab';
            vmadHocFolder.isCustomChipSupport = true;
        }

        function getEmailDomain() {
            var MatchFieldList = [];
            var apiUrl = adHocFolderFactory.getAPIUrl('GET_EMAIL_DOMAIN');
            //$scope.mc.getlogDetails("Debug", 'Method:GET;URL' + JSON.stringify(apiUrl));
            var promise = adHocFolderService.getData(apiUrl);
            promise.then(function (response) {
                if (response && response['data'] && response['data']['data'] && response['data']['data']['Email Domain']) {
                    vmadHocFolder.EmailDomain = response['data']['data']['Email Domain'];
                    //angular.forEach(response.data.data, function (systemconfig) {
                    //    var systemConfigUIModel = adHocFolderFactory.getEmailDomain(systemconfig);
                    //    MatchFieldList.push(systemConfigUIModel);
                    //});
                    //if (MatchFieldList.length > 0) {  
                    //    if (MatchFieldList[0] && MatchFieldList[0].IMCC_EMAIL_DOMAIN) {
                    //        vmadHocFolder.EmailDomain = MatchFieldList[0].IMCC_EMAIL_DOMAIN;
                    //    }
                    //}
                }
            },
            function (response) {
                //$scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
            });
        }

        function addUserGroup() {
            vmadHocFolder.isAddUserGroupDialogShowing = true;
        }

        function backFromAddUserGroup() {
            vmadHocFolder.isAddUserGroupDialogShowing = false;
            vmadHocFolder.NewUserGroupList = [];
            vmadHocFolder.SelectedUserGroup = null;
            vmadHocFolder.UserGroupSearchText = null;
        }

        vmadHocFolder.isBackButton = function () {
            vmadHocFolder.isAddSerachCriteria = false;
            vmadHocFolder.chipCustom1 = [];
            vmadHocFolder.chipCustom2 = [];
            vmadHocFolder.chipCustom3 = [];
            vmadHocFolder.chipCustom4 = [];
            vmadHocFolder.chipCustom5 = [];
            vmadHocFolder.chipCustom6 = [];
            vmadHocFolder.chipCustom7 = [];
            vmadHocFolder.chipCustom8 = [];
            vmadHocFolder.chipCustom9 = [];
            vmadHocFolder.chipCustom10 = [];
            vmadHocFolder.chipCustom11 = [];
            vmadHocFolder.chipCustom12 = [];
            vmadHocFolder.adHocFolderModel.custom13 = '';
            vmadHocFolder.adHocFolderModel.custom14 = '';
            vmadHocFolder.adHocFolderModel.custom15 = '';
            vmadHocFolder.adHocFolderModel.custom16 = '';
            vmadHocFolder.adHocFolderModel.custom17 = '';
            vmadHocFolder.adHocFolderModel.custom18 = '';
            vmadHocFolder.adHocFolderModel.custom19 = '';
            vmadHocFolder.adHocFolderModel.custom20 = '';
            if (vmadHocFolder.Opertion == 'imTypeDocumentSearchFolder') {               
                vmadHocFolder.adHocFolderModel.custom21 = 'Anytime';
                vmadHocFolder.adHocFolderModel.custom22 = 'Anytime';
                vmadHocFolder.adHocFolderModel.custom23 = 'Anytime';
                vmadHocFolder.adHocFolderModel.custom24 = 'Anytime';

                vmadHocFolder.chipOperators = [];
                vmadHocFolder.selectedTypes = [];
                vmadHocFolder.adHocFolderModel.create_date = 'Anytime';
                vmadHocFolder.adHocFolderModel.edit_date = 'Anytime';
                vmadHocFolder.adHocFolderModel.FP_LookFor_Type = '0';
                vmadHocFolder.adHocFolderModel.FP_LookFor_Lang = 'anyLanguage';
                vmadHocFolder.adHocFolderModel.FP_LookFor = '';
                vmadHocFolder.adHocFolderModel.FP_DocumentNum = '';
                vmadHocFolder.adHocFolderModel.FP_Version = '';
            }
            vmadHocFolder.adHocFolderModel.custom25 = 'inter';
            vmadHocFolder.adHocFolderModel.custom26 = 'inter';
            vmadHocFolder.adHocFolderModel.custom27 = 'inter';
            vmadHocFolder.adHocFolderModel.custom28 = 'inter';
            vmadHocFolder.chipCustom29 = [];
            vmadHocFolder.chipCustom30 = [];
            vmadHocFolder.chipAuthors = [];            
            vmadHocFolder.chipClasses = [];
            
        }

        vmadHocFolder.closeWindow = function (actionType) {
           if ($location.search() && $location.search().protocol && $location.search().protocol === 'postmessage') {

                var message = {
                    type: actionType,
                    data: JSON.stringify(vmadHocFolder.NewItem)
                };

                if ($window.parent)
                    $window.parent.postMessage(message, '*');

            } else {
                try {
                    closewin(vmadHocFolder.NewItem);
                } catch (err) {   }
           }
           
        };

        vmadHocFolder.addCustomChip = function (metadata, type) {
            if (metadata == 'Custom1') {
                if (vmadHocFolder.chipCustom1.length == 1) {
                    vmadHocFolder.childAuto2Enable = false;
                    vmadHocFolder.chipCustom2 = [];
                }
                else {
                    vmadHocFolder.childAuto2Enable = true;
                    vmadHocFolder.chipCustom2 = [];
                }
                if (vmadHocFolder.chipCustom1 && vmadHocFolder.chipCustom1 != null && vmadHocFolder.chipCustom1.length > 0) {
                    var typrstr = '';
                    angular.forEach(vmadHocFolder.chipCustom1, function (metadata) {
                        if (typrstr == '') {
                            typrstr = typrstr.concat(metadata.Alias.toString());
                        }
                        else {
                            typrstr = typrstr.concat(',' + metadata.Alias.toString());
                        }
                    });

                    vmadHocFolder.adHocFolderModel.custom1 = typrstr;
                }
                else {
                    vmadHocFolder.adHocFolderModel.custom1 = '';
                    vmadHocFolder.chipCustom1 = [];
                }
            }
            else if (metadata == 'Custom29') {
                if (vmadHocFolder.chipCustom29.length == 1) {
                    vmadHocFolder.childAuto30Enable = false;
                    vmadHocFolder.chipCustom30 = [];
                }
                else {
                    vmadHocFolder.childAuto30Enable = true;
                    vmadHocFolder.chipCustom30 = [];
                }
                if (vmadHocFolder.chipCustom29 && vmadHocFolder.chipCustom29 != null && vmadHocFolder.chipCustom29.length > 0) {
                    var typrstr = '';
                    angular.forEach(vmadHocFolder.chipCustom29, function (metadata) {
                        if (typrstr == '') {
                            typrstr = typrstr.concat(metadata.Alias.toString());
                        }
                        else {
                            typrstr = typrstr.concat(',' + metadata.Alias.toString());
                        }
                    });

                    vmadHocFolder.adHocFolderModel.custom29 = typrstr;
                }
                else {
                    vmadHocFolder.adHocFolderModel.custom29 = '';
                    vmadHocFolder.chipCustom29 = [];
                }
            }
            else if (metadata == 'CLASS') {
                vmadHocFolder.chipSubClasses = [];
            }
        }

        vmadHocFolder.removeCustomChip = function (metadata, type) {
            if (metadata == 'Custom1') {
                if (vmadHocFolder.chipCustom1.length == 1) {
                    vmadHocFolder.childAuto2Enable = false;
                    vmadHocFolder.chipCustom2 = [];
                }
                else {
                    vmadHocFolder.childAuto2Enable = true;
                    vmadHocFolder.chipCustom2 = [];
                }
                if (vmadHocFolder.chipCustom1 && vmadHocFolder.chipCustom1 != null && vmadHocFolder.chipCustom1.length > 0) {
                    var typrstr = '';
                    angular.forEach(vmadHocFolder.chipCustom1, function (metadata) {
                        if (typrstr == '') {
                            typrstr = typrstr.concat(metadata.Alias.toString());
                        }
                        else {
                            typrstr = typrstr.concat(',' + metadata.Alias.toString());
                        }
                    });

                    vmadHocFolder.adHocFolderModel.custom1 = typrstr;
                }
                else {
                    vmadHocFolder.adHocFolderModel.custom1 = '';
                    vmadHocFolder.chipCustom1 = [];
                }
            }
            else if (metadata == 'Custom29') {
                if (vmadHocFolder.chipCustom29.length == 1) {
                    vmadHocFolder.childAuto30Enable = false;
                    vmadHocFolder.chipCustom30 = [];
                }
                else {
                    vmadHocFolder.childAuto30Enable = true;
                    vmadHocFolder.chipCustom30 = [];
                }
                if (vmadHocFolder.chipCustom29 && vmadHocFolder.chipCustom29 != null && vmadHocFolder.chipCustom29.length > 0) {
                    var typrstr = '';
                    angular.forEach(vmadHocFolder.chipCustom29, function (metadata) {
                        if (typrstr == '') {
                            typrstr = typrstr.concat(metadata.Alias.toString());
                        }
                        else {
                            typrstr = typrstr.concat(',' + metadata.Alias.toString());
                        }
                    });

                    vmadHocFolder.adHocFolderModel.custom29 = typrstr;
                }
                else {
                    vmadHocFolder.adHocFolderModel.custom29 = '';
                    vmadHocFolder.chipCustom29 = [];
                }
            }
            else if (metadata == 'CLASS') {
                vmadHocFolder.chipSubClasses = [];
            }
        }

        vmadHocFolder.labelChange = function () {
            if (vmadHocFolder.displayLabel == 'Show') {
                vmadHocFolder.displayLabel = 'Hide';
                vmadHocFolder.showArea = true;
                if ($location.search() && $location.search().protocol && $location.search().protocol == 'external') {
                    resizewin('550;700');
                }
                getEmailDomain();
            }
            else {
                vmadHocFolder.displayLabel = 'Show';
                vmadHocFolder.showArea = false;
                if ($location.search() && $location.search().protocol && $location.search().protocol == 'external') {
                    resizewin('550;265');
                }
            }
            
        };

        function getChipValues(chipCustom,type) {
            var typrstr = '';
            if (type == 'metaData') {
                angular.forEach(chipCustom, function (metadata) {
                    if (typrstr == '') {
                        typrstr = typrstr.concat(metadata.Alias.toString());
                    }
                    else {
                        typrstr = typrstr.concat(',' + metadata.Alias.toString());
                    }
                });
            }
            else if (type == 'user') {
                angular.forEach(chipCustom, function (users) {
                    if (typrstr == '') {
                        typrstr = typrstr.concat(users.UserId.toString());
                    }
                    else {
                        typrstr = typrstr.concat(',' + users.UserId.toString());
                    }
                });
            }
            else if (type == 'class') {
                angular.forEach(chipCustom, function (classes) {
                    if (typrstr == '') {
                        typrstr = typrstr.concat(classes.ClassId.toString());
                    }
                    else {
                        typrstr = typrstr.concat(',' + classes.ClassId.toString());
                    }
                });
            }
            else if (type == 'type') {
                angular.forEach(chipCustom, function (types) {
                    if (typrstr == '') {
                        typrstr = typrstr.concat(types.typeId.toString());
                    }
                    else {
                        typrstr = typrstr.concat(',' + types.typeId.toString());
                    }
                });
            }
            return typrstr;
        }

        function SetProfileValues() {
            vmadHocFolder.adHocFolderModel.Owner = $scope.mc.loginModel.UserName;

            if (vmadHocFolder.chipCustom1 && vmadHocFolder.chipCustom1 != null && vmadHocFolder.chipCustom1.length > 0) {
                vmadHocFolder.adHocFolderModel.custom1 = getChipValues(vmadHocFolder.chipCustom1, 'metaData');
            }
            else {
                vmadHocFolder.adHocFolderModel.custom1 = '';
                vmadHocFolder.chipCustom1 = [];
            }

            if (vmadHocFolder.chipCustom2 && vmadHocFolder.chipCustom2 != null && vmadHocFolder.chipCustom2.length > 0) {
                vmadHocFolder.adHocFolderModel.custom2 = getChipValues(vmadHocFolder.chipCustom2, 'metaData');;
            }
            else {
                vmadHocFolder.adHocFolderModel.custom2 = '';
                vmadHocFolder.chipCustom2 = [];
            }

            if (vmadHocFolder.chipCustom3 && vmadHocFolder.chipCustom3 != null && vmadHocFolder.chipCustom3.length > 0) {
                vmadHocFolder.adHocFolderModel.custom3 = getChipValues(vmadHocFolder.chipCustom3, 'metaData');;
            }
            else {
                vmadHocFolder.adHocFolderModel.custom3 = '';
                vmadHocFolder.chipCustom3 = [];
            }

            if (vmadHocFolder.chipCustom4 && vmadHocFolder.chipCustom4 != null && vmadHocFolder.chipCustom4.length > 0) {
                vmadHocFolder.adHocFolderModel.custom4 = getChipValues(vmadHocFolder.chipCustom4, 'metaData');;
            }
            else {
                vmadHocFolder.adHocFolderModel.custom4 = '';
                vmadHocFolder.chipCustom4 = [];
            }

            if (vmadHocFolder.chipCustom5 && vmadHocFolder.chipCustom5 != null && vmadHocFolder.chipCustom5.length > 0) {
                vmadHocFolder.adHocFolderModel.custom5 = getChipValues(vmadHocFolder.chipCustom5, 'metaData');;
            }
            else {
                vmadHocFolder.adHocFolderModel.custom5 = '';
                vmadHocFolder.chipCustom5 = [];
            }

            if (vmadHocFolder.chipCustom6 && vmadHocFolder.chipCustom6 != null && vmadHocFolder.chipCustom6.length > 0) {
                vmadHocFolder.adHocFolderModel.custom6 = getChipValues(vmadHocFolder.chipCustom6, 'metaData');;
            }
            else {
                vmadHocFolder.adHocFolderModel.custom6 = '';
                vmadHocFolder.chipCustom6 = [];
            }

            if (vmadHocFolder.chipCustom7 && vmadHocFolder.chipCustom7 != null && vmadHocFolder.chipCustom7.length > 0) {
                vmadHocFolder.adHocFolderModel.custom7 = getChipValues(vmadHocFolder.chipCustom7, 'metaData');;
            }
            else {
                vmadHocFolder.adHocFolderModel.custom7 = '';
                vmadHocFolder.chipCustom7 = [];
            }

            if (vmadHocFolder.chipCustom8 && vmadHocFolder.chipCustom8 != null && vmadHocFolder.chipCustom8.length > 0) {
                vmadHocFolder.adHocFolderModel.custom8 = getChipValues(vmadHocFolder.chipCustom8, 'metaData');;
            }
            else {
                vmadHocFolder.adHocFolderModel.custom8 = '';
                vmadHocFolder.chipCustom8 = [];
            }

            if (vmadHocFolder.chipCustom9 && vmadHocFolder.chipCustom9 != null && vmadHocFolder.chipCustom9.length > 0) {
                vmadHocFolder.adHocFolderModel.custom9 = getChipValues(vmadHocFolder.chipCustom9, 'metaData');;
            }
            else {
                vmadHocFolder.adHocFolderModel.custom9 = '';
                vmadHocFolder.chipCustom9 = [];
            }

            if (vmadHocFolder.chipCustom10 && vmadHocFolder.chipCustom10 != null && vmadHocFolder.chipCustom10.length > 0) {
                vmadHocFolder.adHocFolderModel.custom10 = getChipValues(vmadHocFolder.chipCustom10, 'metaData');;
            }
            else {
                vmadHocFolder.adHocFolderModel.custom10 = '';
                vmadHocFolder.chipCustom10 = [];
            }

            if (vmadHocFolder.chipCustom11 && vmadHocFolder.chipCustom11 != null && vmadHocFolder.chipCustom11.length > 0) {
                vmadHocFolder.adHocFolderModel.custom11 = getChipValues(vmadHocFolder.chipCustom11, 'metaData');;
            }
            else {
                vmadHocFolder.adHocFolderModel.custom11 = '';
                vmadHocFolder.chipCustom11 = [];
            }

            if (vmadHocFolder.chipCustom12 && vmadHocFolder.chipCustom12 != null && vmadHocFolder.chipCustom12.length > 0) {
                vmadHocFolder.adHocFolderModel.custom12 = getChipValues(vmadHocFolder.chipCustom12, 'metaData');;
            }
            else {
                vmadHocFolder.adHocFolderModel.custom12 = '';
                vmadHocFolder.chipCustom12 = [];
            }


            if (vmadHocFolder.chipCustom29 && vmadHocFolder.chipCustom29 != null && vmadHocFolder.chipCustom29.length > 0) {
                vmadHocFolder.adHocFolderModel.custom29 = getChipValues(vmadHocFolder.chipCustom29, 'metaData');
            }
            else {
                vmadHocFolder.adHocFolderModel.custom29 = '';
                vmadHocFolder.chipCustom29 = [];
            }

            if (vmadHocFolder.chipCustom30 && vmadHocFolder.chipCustom30 != null && vmadHocFolder.chipCustom30.length > 0) {
                vmadHocFolder.adHocFolderModel.custom30 = getChipValues(vmadHocFolder.chipCustom30, 'metaData');
            }
            else {
                vmadHocFolder.adHocFolderModel.custom30 = '';
                vmadHocFolder.chipCustom30 = [];
            }

            if (vmadHocFolder.chipAuthors && vmadHocFolder.chipAuthors != null && vmadHocFolder.chipAuthors.length > 0) {
                vmadHocFolder.adHocFolderModel.FP_Author = getChipValues(vmadHocFolder.chipAuthors, 'user');
            }
            else {
                vmadHocFolder.adHocFolderModel.FP_Author = '';
                vmadHocFolder.chipAuthors = [];
            }

            if (vmadHocFolder.chipClasses && vmadHocFolder.chipClasses != null && vmadHocFolder.chipClasses.length > 0) {
                vmadHocFolder.adHocFolderModel.FP_Class = getChipValues(vmadHocFolder.chipClasses, 'class');
            }
            else {
                vmadHocFolder.adHocFolderModel.FP_Class = '';
                vmadHocFolder.chipClasses = [];
            }

            if (vmadHocFolder.Opertion == 'imTypeDocumentFolder') {
                if (vmadHocFolder.chipSubClasses && vmadHocFolder.chipSubClasses != null && vmadHocFolder.chipSubClasses.length > 0) {
                    vmadHocFolder.adHocFolderModel.FP_SubClass = getChipValues(vmadHocFolder.chipSubClasses, 'class');
                }
                else {
                    vmadHocFolder.adHocFolderModel.FP_SubClass = '';
                    vmadHocFolder.chipSubClasses = [];
                }
            }
            else if (vmadHocFolder.Opertion == 'imTypeDocumentSearchFolder') {

                if (vmadHocFolder.chipOperators && vmadHocFolder.chipOperators != null && vmadHocFolder.chipOperators.length > 0) {
                    vmadHocFolder.adHocFolderModel.FP_Operator = getChipValues(vmadHocFolder.chipOperators, 'user');
                }
                else {
                    vmadHocFolder.adHocFolderModel.FP_Operator = '';
                    vmadHocFolder.chipOperators = [];
                }

                if (vmadHocFolder.selectedTypes && vmadHocFolder.selectedTypes != null && vmadHocFolder.selectedTypes.length > 0) {
                    vmadHocFolder.adHocFolderModel.FP_Type = getChipValues(vmadHocFolder.selectedTypes, 'type');
                }
                else {
                    vmadHocFolder.adHocFolderModel.FP_Type = '';
                    vmadHocFolder.selectedTypes = [];
                }

            }

        }
		  vmadHocFolder.adHocFolderModelOriginal = {};

        vmadHocFolder.addEditSearchCriteria = function () {
            vmadHocFolder.adHocFolderModelOriginal = angular.copy(vmadHocFolder.adHocFolderModel);
            vmadHocFolder.isAddSerachCriteria = true;
        }

        vmadHocFolder.backtoSearchCriteria = function () {
            vmadHocFolder.adHocFolderModel = angular.copy(vmadHocFolder.adHocFolderModelOriginal);
            vmadHocFolder.isAddSerachCriteria = false;
        }

        vmadHocFolder.SearchWithInChange = function () {
             
            switch (vmadHocFolder.WithIn) {
                case 'CurrentDb': vmadHocFolder.adHocFolderModel.WithIn = vmadHocFolder.selectedLibrary;
                    break;
                case 'AllDB':
                    vmadHocFolder.adHocFolderModel.WithIn = '';
                    angular.forEach(vmadHocFolder.DBLibrariesByUser, function (item) {
                        if (vmadHocFolder.adHocFolderModel.WithIn == '') {
                            vmadHocFolder.adHocFolderModel.WithIn +=  item.DatabaseName;
                        } else {
                            vmadHocFolder.adHocFolderModel.WithIn +=  ',' +item.DatabaseName;
                        }
                    
                });
                    break;
                case 'ChooseDb': vmadHocFolder.adHocFolderModel.WithIn = ''; vmadHocFolder.ChooseDb();
                    break;
                default: break;
            }
             
        }
        vmadHocFolder.EmailArray = [];

        function EmailExists(NewMail, Format) {

            while (vmadHocFolder.EmailArray.indexOf(NewMail) !== -1) {
                var count = NewMail.replace(Format, '');
                if (count.indexOf('_') !== -1) {
                    count = count.replace('_', '');
                } else { count = '0'; }
                NewMail = Format + '_' + (parseInt(count) + 1);
            }
            vmadHocFolder.EmailArray.push(NewMail);
            return NewMail;

        }

        function CheckForEmailExists(emailaddress, count) {

            var defered = $q.defer();
            var body = {};
            if (count == 0) {
                body.email = encodeURIComponent(emailaddress);
            } else {
                body.email = encodeURIComponent(emailaddress) + '_' + count;
            }

            var apiUrl = adHocFolderFactory.getAPIUrl('SEARCH_FOLDERS', body);
            //$scope.mc.getlogDetails("Debug", 'apiUrl:' + apiUrl);
            var EmailAddress = adHocFolderService.getData(apiUrl);
            EmailAddress.then(function (response) {
                
                if (response.data.data.length > 0) {
                    CheckForEmailExists(emailaddress, count + 1).then(function (emailResponse) {
                        defered.resolve(decodeURIComponent(emailResponse));
                    });
                } else {
                    defered.resolve(decodeURIComponent(body.email));

                }
            });

            return defered.promise;
        }

        vmadHocFolder.addAdHocFolder = function () {
            if (!vmadHocFolder.adHocFolderModel.Name && vmadHocFolder.adHocFolderModel.Name == '') {
                return;
            }
            else {
                var apiUrl;
                if (vmadHocFolder.Opertion != 'imTypeTab') {
                    SetProfileValues();
                    if (vmadHocFolder.Opertion == 'imTypeDocumentSearchFolder') {
                        vmadHocFolder.adHocFolderModel.FolderType = 'search';
                        vmadHocFolder.adHocFolderModel.RestrictTo = vmadHocFolder.RestrictTo;
                        apiUrl = adHocFolderFactory.getAPIUrl('POST_SEARCH_FOLDERS', parentId);
                    }
                    else if (vmadHocFolder.Opertion == 'imTypeDocumentFolder') {
                        vmadHocFolder.adHocFolderModel.FolderType = 'regular';
                        if (vmadHocFolder.adHocFolderModel.Email && vmadHocFolder.adHocFolderModel.Email != '') {
                            CheckForEmailExists(vmadHocFolder.adHocFolderModel.Email, 0).then(function (emailResponse) {
                                var finalEmail = EmailExists(emailResponse, vmadHocFolder.adHocFolderModel.Email)
                                vmadHocFolder.adHocFolderModel.Email = finalEmail;
                            });
                        }
                        apiUrl = adHocFolderFactory.getAPIUrl('POST_FOLDER', parentId);
                    }

                }
                else if (vmadHocFolder.Opertion == 'imTypeTab') {
                    vmadHocFolder.adHocFolderModel.Owner = $scope.mc.loginModel.UserName;
                    vmadHocFolder.adHocFolderModel.FolderType = 'tab';
                    apiUrl = adHocFolderFactory.getAPIUrl('POST_TAB', parentId);
                }

                var requestBody = adHocFolderFactory.getFolderPostAPIModel(vmadHocFolder.adHocFolderModel, vmadHocFolder.selectedLibrary);
                //var deffered = $q.defer();
                var promise = adHocFolderService.addFolder(requestBody, apiUrl);
                promise.then(function (response) {
                    if (response && response.status && response.status == 201) {
                        if (response.data && response.data.data && response.data.data.id && response.data.data.id.trim().length > 0) {
                            vmadHocFolder.adHocFolderModel.Id = response.data.data.id;
                            vmadHocFolder.NewItem = response.data.data;
                            if (vmadHocFolder.SecurityList.length > 0) {
                                var promiseSecurity = saveFolderSecurity();
                                promiseSecurity.then(function (responseSec) {
                                    console.log('security success');
                                    vmadHocFolder.closeWindow('created');
                                }, function (responseSec) {
                                });
                            } else {
                                vmadHocFolder.closeWindow('created');
                            }

                            $mdDialog.show(
                                              $mdDialog.alert()
                                              .parent(angular.element(document.body))
                                              .clickOutsideToClose(true)
                                              .title('Success')
                                              .textContent(vmadHocFolder.adHocFolderModel.Name + ' saved successfully.')
                                              .ariaLabel('Success')
                                              .ok('OK')
                                      );
                        }
                    }
                }, function (response) {
                    //deffered.resolve(response);
                });
                //return deffered.promise;
            }

        };
        
		function saveFolderSecurity() {
            var deferred = $q.defer();
            var requestBody = {
                include: [],
                remove: []
            };
            var apiModel = null;

            angular.forEach(vmadHocFolder.SecurityList, function (item) {
                if (item.AccessLevel !== 'RemoveItem') {
					apiModel = adHocFolderFactory.getSecurityAPIModel(item);
                    requestBody.include.push(apiModel);
                }
                //else {
                //    requestBody.remove.push(apiModel);
                //}
            });
            var apiUrl = adHocFolderFactory.getFolderSecurityAPI(vmadHocFolder.adHocFolderModel.Id);
            $scope.mc.getlogDetails("Debug", 'Requested Api Url:' + JSON.stringify(apiUrl));

            var promise = adHocFolderService.addFolder(requestBody, apiUrl);
            promise.then(function (response) {
                $scope.mc.getlogDetails("Success", 'Folder security retrived successfully.');
                deferred.resolve({ Status: 0 });
            }, function (response) {
                $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                deferred.resolve({ Status: -1 });
            });
            return deferred.promise;
        }
		
        vmadHocFolder.docInfo = {
            Custom1: '',
            Custom2: '',
            Custom29: '',
            Custom30: ''
        };

        //Custom1
        vmadHocFolder.selectedCustomItem = {};
        vmadHocFolder.searchCustomText = null;
        vmadHocFolder.queryCustomSearch = queryCustomSearch;

        vmadHocFolder.chipCustom1 = [];

        vmadHocFolder.transformCustom1Chip = transformCustom1Chip;


        function transformCustom1Chip(chip) {
            if (angular.isObject(chip)) {
                return chip;
            }
            // Otherwise, create a new one
            return { Alias: chip }
        }

        if (vmadHocFolder.docInfo.Custom1)
            vmadHocFolder.selectedCustomItem.Alias = $scope.docInfo.Custom1;
        else
            vmadHocFolder.selectedCustomItem = null;


        //Custom2
        vmadHocFolder.selectedCustom2Item = {};
        vmadHocFolder.searchCustom2Text = null;
        vmadHocFolder.queryCustom2Search = queryCustomSearch;

        vmadHocFolder.chipCustom2 = [];
        vmadHocFolder.transformCustom2Chip = transformCustom2Chip;

        function transformCustom2Chip(chip) {
            if (angular.isObject(chip)) {
                return chip;
            }
            return { Alias: chip }
        }

        if (vmadHocFolder.docInfo.Custom2)
            vmadHocFolder.selectedCustom2Item.Alias = vmadHocFolder.docInfo.Custom2;
        else
            vmadHocFolder.selectedCustom2Item = null;

        //Custom29
        vmadHocFolder.selectedCustom29Item = {};
        vmadHocFolder.searchCustom29Text = null;
        vmadHocFolder.queryCustom29Search = queryCustomSearch;

        vmadHocFolder.chipCustom29 = [];
        vmadHocFolder.transformCustom29Chip = transformCustom29Chip;

        function transformCustom29Chip(chip) {
            if (angular.isObject(chip)) {
                return chip;
            }

            // Otherwise, create a new one
            return { Alias: chip }
        }

        if (vmadHocFolder.docInfo.Custom29)
            vmadHocFolder.selectedCustom29Item.Alias = vmadHocFolder.docInfo.Custom29;
        else
            vmadHocFolder.selectedCustom29Item = null;

        //Custom30
        vmadHocFolder.selectedCustom30Item = {};
        vmadHocFolder.searchCustom30Text = null;
        vmadHocFolder.queryCustom30Search = queryCustomSearch;
        vmadHocFolder.chipCustom30 = [];
        vmadHocFolder.transformCustom30Chip = transformCustom30Chip;

        function transformCustom30Chip(chip) {
            if (angular.isObject(chip)) {
                return chip;
            }

            // Otherwise, create a new one
            return { Alias: chip }
        }

        if (vmadHocFolder.docInfo.Custom30)
            vmadHocFolder.selectedCustom30Item.Alias = vmadHocFolder.docInfo.Custom30;
        else
            vmadHocFolder.selectedCustom30Item = null;

        //Custom3
        vmadHocFolder.selectedCustom3Item = {};
        vmadHocFolder.searchCustom3Text = null;
        vmadHocFolder.queryCustom3Search = queryCustomSearch;
        vmadHocFolder.chipCustom3 = [];
        vmadHocFolder.transformCustom3Chip = transformCustom3Chip;

        function transformCustom3Chip(chip) {
            if (angular.isObject(chip)) {
                return chip;
            }

            // Otherwise, create a new one
            return { Alias: chip }
        }

        if (vmadHocFolder.docInfo.Custom3)
            vmadHocFolder.selectedCustom3Item.Alias = vmadHocFolder.docInfo.Custom3;
        else
            vmadHocFolder.selectedCustom3Item = null;

        //Custom4
        vmadHocFolder.selectedCustom4Item = {};
        vmadHocFolder.searchCustom4Text = null;
        vmadHocFolder.queryCustom4Search = queryCustomSearch;
        vmadHocFolder.chipCustom4 = [];
        vmadHocFolder.transformCustom4Chip = transformCustom4Chip;

        function transformCustom4Chip(chip) {
            if (angular.isObject(chip)) {
                return chip;
            }

            // Otherwise, create a new one
            return { Alias: chip }
        }

        if (vmadHocFolder.docInfo.Custom4)
            vmadHocFolder.selectedCustom4Item.Alias = vmadHocFolder.docInfo.Custom4;
        else
            vmadHocFolder.selectedCustom4Item = null;

        //Custom5
        vmadHocFolder.selectedCustom5Item = {};
        vmadHocFolder.searchCustom5Text = null;
        vmadHocFolder.queryCustom5Search = queryCustomSearch;
        vmadHocFolder.chipCustom5 = [];
        vmadHocFolder.transformCustom5Chip = transformCustom5Chip;

        function transformCustom5Chip(chip) {
            if (angular.isObject(chip)) {
                return chip;
            }

            // Otherwise, create a new one
            return { Alias: chip }
        }

        if (vmadHocFolder.docInfo.Custom5)
            vmadHocFolder.selectedCustom5Item.Alias = vmadHocFolder.docInfo.Custom5;
        else
            vmadHocFolder.selectedCustom5Item = null;

        //Custom6
        vmadHocFolder.selectedCustom6Item = {};
        vmadHocFolder.searchCustom6Text = null;
        vmadHocFolder.queryCustom6Search = queryCustomSearch;
        vmadHocFolder.chipCustom6 = [];
        vmadHocFolder.transformCustom6Chip = transformCustom6Chip;

        function transformCustom6Chip(chip) {
            if (angular.isObject(chip)) {
                return chip;
            }

            // Otherwise, create a new one
            return { Alias: chip }
        }

        if (vmadHocFolder.docInfo.Custom6)
            vmadHocFolder.selectedCustom6Item.Alias = vmadHocFolder.docInfo.Custom6;
        else
            vmadHocFolder.selectedCustom6Item = null;

        //Custom7
        vmadHocFolder.selectedCustom7Item = {};
        vmadHocFolder.searchCustom7Text = null;
        vmadHocFolder.queryCustom7Search = queryCustomSearch;
        vmadHocFolder.chipCustom7 = [];
        vmadHocFolder.transformCustom7Chip = transformCustom7Chip;

        function transformCustom7Chip(chip) {
            if (angular.isObject(chip)) {
                return chip;
            }

            // Otherwise, create a new one
            return { Alias: chip }
        }

        if (vmadHocFolder.docInfo.Custom7)
            vmadHocFolder.selectedCustom7Item.Alias = vmadHocFolder.docInfo.Custom7;
        else
            vmadHocFolder.selectedCustom7Item = null;

        //Custom8
        vmadHocFolder.selectedCustom8Item = {};
        vmadHocFolder.searchCustom8Text = null;
        vmadHocFolder.queryCustom8Search = queryCustomSearch;
        vmadHocFolder.chipCustom8 = [];
        vmadHocFolder.transformCustom8Chip = transformCustom8Chip;

        function transformCustom8Chip(chip) {
            if (angular.isObject(chip)) {
                return chip;
            }

            // Otherwise, create a new one
            return { Alias: chip }
        }

        if (vmadHocFolder.docInfo.Custom8)
            vmadHocFolder.selectedCustom8Item.Alias = vmadHocFolder.docInfo.Custom8;
        else
            vmadHocFolder.selectedCustom8Item = null;

        //Custom9
        vmadHocFolder.selectedCustom9Item = {};
        vmadHocFolder.searchCustom9Text = null;
        vmadHocFolder.queryCustom9Search = queryCustomSearch;
        vmadHocFolder.chipCustom9 = [];
        vmadHocFolder.transformCustom9Chip = transformCustom9Chip;

        function transformCustom9Chip(chip) {
            if (angular.isObject(chip)) {
                return chip;
            }

            // Otherwise, create a new one
            return { Alias: chip }
        }

        if (vmadHocFolder.docInfo.Custom9)
            vmadHocFolder.selectedCustom9Item.Alias = vmadHocFolder.docInfo.Custom9;
        else
            vmadHocFolder.selectedCustom9Item = null;

        //Custom10
        vmadHocFolder.selectedCustom10Item = {};
        vmadHocFolder.searchCustom10Text = null;
        vmadHocFolder.queryCustom10Search = queryCustomSearch;
        vmadHocFolder.chipCustom10 = [];
        vmadHocFolder.transformCustom10Chip = transformCustom10Chip;

        function transformCustom10Chip(chip) {
            if (angular.isObject(chip)) {
                return chip;
            }

            // Otherwise, create a new one
            return { Alias: chip }
        }

        if (vmadHocFolder.docInfo.Custom10)
            vmadHocFolder.selectedCustom10Item.Alias = vmadHocFolder.docInfo.Custom10;
        else
            vmadHocFolder.selectedCustom10Item = null;

        //Custom11
        vmadHocFolder.selectedCustom11Item = {};
        vmadHocFolder.searchCustom11Text = null;
        vmadHocFolder.queryCustom11Search = queryCustomSearch;
        vmadHocFolder.chipCustom11 = [];
        vmadHocFolder.transformCustom11Chip = transformCustom11Chip;

        function transformCustom11Chip(chip) {
            if (angular.isObject(chip)) {
                return chip;
            }

            // Otherwise, create a new one
            return { Alias: chip }
        }

        if (vmadHocFolder.docInfo.Custom11)
            vmadHocFolder.selectedCustom11Item.Alias = vmadHocFolder.docInfo.Custom11;
        else
            vmadHocFolder.selectedCustom11Item = null;


        //Custom12
        vmadHocFolder.selectedCustom12Item = {};
        vmadHocFolder.searchCustom12Text = null;
        vmadHocFolder.queryCustom12Search = queryCustomSearch;
        vmadHocFolder.chipCustom12 = [];
        vmadHocFolder.transformCustom12Chip = transformCustom12Chip;

        function transformCustom12Chip(chip) {
            if (angular.isObject(chip)) {
                return chip;
            }

            // Otherwise, create a new one
            return { Alias: chip }
        }

        if (vmadHocFolder.docInfo.Custom12)
            vmadHocFolder.selectedCustom12Item.Alias = vmadHocFolder.docInfo.Custom12;
        else
            vmadHocFolder.selectedCustom12Item = null;


        function queryCustomSearch(query, metaType) {

            var deffered = $q.defer();
            var customListRequestModel = homeFactory.requestModelInstance();
            var filterValueList = [];
            filterValueList[0] = query;
            var filterItem = { 'FilterKey': 'Alias', 'FilterValues': filterValueList };
            customListRequestModel.filters.push(filterItem);
            customListRequestModel.searchText = query;
            customListRequestModel.pagenumber = 1;
            customListRequestModel.libraryName = vmadHocFolder.selectedLibrary;
            var searchAPIUrl = '';
            metaType = metaType.toUpperCase();
            var obj = [];
            if (metaType == 'CUSTOM2' || metaType == 'CUSTOM30') {
                customListRequestModel.MetaType = metaType == 'CUSTOM2' ? "CUSTOM1" : "CUSTOM29";
                if (customListRequestModel.MetaType == 'CUSTOM1') {
                    if (vmadHocFolder.chipCustom1 && vmadHocFolder.chipCustom1 != null && vmadHocFolder.chipCustom1.length == 1) {
                        customListRequestModel.parentAlias = vmadHocFolder.chipCustom1[0].Alias;
                    }
                    else {
                        deffered.resolve(obj);
                        return deffered.promise;
                    }

                }
                else if (customListRequestModel.MetaType == 'CUSTOM29') {
                    if (vmadHocFolder.chipCustom29 && vmadHocFolder.chipCustom29 != null && vmadHocFolder.chipCustom29.length == 1) {
                        customListRequestModel.parentAlias = vmadHocFolder.chipCustom29[0].Alias;
                    }
                    else {
                        deffered.resolve(obj);
                        return deffered.promise;
                    }
                }
                //customListRequestModel.parentAlias = (metaType == 'CUSTOM2') ? vmadHocFolder.docInfo.Custom1 : vmadHocFolder.docInfo.Custom29;
                customListRequestModel.subType = metaType;
                if (customListRequestModel.parentAlias && customListRequestModel.parentAlias != '') {
                    searchAPIUrl = adHocFolderFactory.getAPIUrl('SEARCHCHILDMETADATA', customListRequestModel);
                }
                else {
                    customListRequestModel.MetaType = metaType;
                    searchAPIUrl = adHocFolderFactory.getAPIUrl('SEARCHMETADATA', customListRequestModel);
                }
            } else {
                customListRequestModel.MetaType = metaType;
                searchAPIUrl = adHocFolderFactory.getAPIUrl('SEARCHMETADATA', customListRequestModel);
            }

            if (searchAPIUrl != '') {
                //vmadHocFolder.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(searchAPIUrl));
                var userRequest = adHocFolderService.getData(searchAPIUrl);

                userRequest.then(function (response) {
                    if (response.status === 200) {
                        //vmadHocFolder.mc.getlogDetails("Info", "Metadata search results received.");
                        angular.forEach(response.data.data, function (metadata) {
                            //obj.push(TemplateFactory.getMetaDataUI(userItem));
                            var metaDataUIModel;
                            metaDataUIModel = adHocFolderFactory.getMetaDataUI(metadata);
                            if (metaDataUIModel.Description && metaDataUIModel.Description.trim().length > 0) {
                                metaDataUIModel.Description = metaDataUIModel.Alias + ' - ' + metaDataUIModel.Description;
                            } else {
                                metaDataUIModel.Description = metaDataUIModel.Alias;
                            }
                            obj.push(metaDataUIModel);
                            metaDataUIModel = null;

                        });
                        //var number = parseInt(metaType.replace("CUSTOM", ""));
                        //   obj.push({ Alias: '#C' + number + 'ALIAS#', Description: '#C' + number + 'ALIAS#' });

                        deffered.resolve(obj);
                    } else {
                        //vmadHocFolder.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                    }
                }, function (response) {
                    //vmadHocFolder.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                });
            }
            else
                deffered.resolve(obj);

            return deffered.promise;
        }



        //Author

        vmadHocFolder.AuthorInfo = {
            Author: ''
        };

        vmadHocFolder.selectedAuthorItem = {};
        vmadHocFolder.searchAuthorText = null;
        vmadHocFolder.queryAuthorSearch = queryAuthorSearch;

        vmadHocFolder.chipAuthors = [];
        vmadHocFolder.transformAuthorChip = transformAuthorChip;

        function transformAuthorChip(chip) {
            if (angular.isObject(chip)) {
                return chip;
            }
            // Otherwise, create a new one
            return { UserId: chip }
        }

        if (vmadHocFolder.AuthorInfo.Author)
            vmadHocFolder.selectedAuthorItem.UserId = vmadHocFolder.AuthorInfo.Author;
        else
            vmadHocFolder.selectedAuthorItem = null;

        //Operator

        vmadHocFolder.selectedOperatorItem = {};
        vmadHocFolder.searchOperatorText = null;
        vmadHocFolder.queryOperatorSearch = queryAuthorSearch;

        vmadHocFolder.chipOperators = [];
        vmadHocFolder.transformOperatorChip = transformOperatorChip;

        function transformOperatorChip(chip) {
            if (angular.isObject(chip)) {
                return chip;
            }

            // Otherwise, create a new one
            return { UserId: chip }
        }

        if (vmadHocFolder.AuthorInfo.Operator)
            vmadHocFolder.selectedOperatorItem.UserId = vmadHocFolder.AuthorInfo.Operator;
        else
            vmadHocFolder.selectedOperatorItem = null;

       

        function queryAuthorSearch(query) {
            var deffered = $q.defer();
            var customListRequestModel = homeFactory.requestModelInstance();
            customListRequestModel.searchText = query;
            customListRequestModel.pagenumber = 1;
            customListRequestModel.libraryName = vmadHocFolder.selectedLibrary;
            var searchAPIUrl = '';
            searchAPIUrl = adHocFolderFactory.getAPIUrl('SEARCH_USERS', customListRequestModel);
            //vmadHocFolder.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(searchAPIUrl));
            var userRequest = adHocFolderService.getData(searchAPIUrl);
            userRequest.then(function (response) {
                var obj = [];
                if (response.status === 200) {
                    angular.forEach(response.data.data, function (userItem) {
                        //var objUserModel = TemplateFactory.getUserUI(userItem);
                        //obj.push({ UserId: objUserModel.UserId });

                        //obj.push(TemplateFactory.getMetaDataUI(userItem));
                        var userUIModel;
                        userUIModel = adHocFolderFactory.getUserUI(userItem);
                        if (userUIModel.FullName && userUIModel.FullName.trim().length > 0) {
                            userUIModel.FullName = userUIModel.UserId + ' - ' + userUIModel.FullName;
                        } else {
                            userUIModel.FullName = userUIModel.UserId;
                        }
                        obj.push(userUIModel);
                        userUIModel = null;

                    });
                    deffered.resolve(obj);
                } else {
                    //vmadHocFolder.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                    deffered.resolve(obj);
                }
            }, function (response) {
                //vmadHocFolder.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                deffered.resolve([]);
            });
            return deffered.promise;
        }


        vmadHocFolder.classType = {
            ClassId: '',
            typeId: '',
            FClassId: '',
            subClassId: ''
        };

        //sub

        vmadHocFolder.chipSubClasses = [];
        vmadHocFolder.transformSubClassChip = transformSubClassChip;

        function transformSubClassChip(chip) {
            if (angular.isObject(chip)) {
                return chip;
            }

            // Otherwise, create a new one
            return { ClassId: chip }
        }

        vmadHocFolder.FolderSubClassItem = {};
        vmadHocFolder.FolderSubClassText = null;
        vmadHocFolder.querySubFolderClassSearch = queryClassSearch;

        if (vmadHocFolder.classType.subClassId)
            vmadHocFolder.FolderSubClassItem.ClassId = vmadHocFolder.classType.subClassId;
        else
            vmadHocFolder.FolderSubClassItem = null;


        //SF_Class

        vmadHocFolder.selectedClassItem = {};
        vmadHocFolder.searchClassText = null;
        vmadHocFolder.queryClassSearch = queryClassSearch;

        if (vmadHocFolder.classType.ClassId)
            vmadHocFolder.selectedClassItem.ClassId = vmadHocFolder.classType.ClassId;
        else
            vmadHocFolder.selectedClassItem = null;

        //Chip
        vmadHocFolder.chipClasses = [];
        vmadHocFolder.transformClassChip = transformClassChip;

        function transformClassChip(chip) {
            if (angular.isObject(chip)) {
                return chip;
            }
            // Otherwise, create a new one
            return { ClassId: chip }
        }
        //end

        //Type

        //Chip
        vmadHocFolder.selectedTypes = [];
        vmadHocFolder.transformTypeChip = transformTypeChip;

        function transformTypeChip(chip) {
            if (angular.isObject(chip)) {
                return chip;
            }

            // Otherwise, create a new one
            return { typeId: chip }
        }
        //end

        vmadHocFolder.selectedTypeItem = {};
        vmadHocFolder.searchTypeText = null;
        vmadHocFolder.queryTypeSearch = queryClassSearch;
        if (vmadHocFolder.classType.typeId)
            vmadHocFolder.selectedTypeItem.typeId = vmadHocFolder.classType.typeId;
        else
            vmadHocFolder.selectedTypeItem = null;

        function queryClassSearch(query, urlType) {
            var deffered = $q.defer();
            var customListRequestModel = homeFactory.requestModelInstance();
            customListRequestModel.searchText = query;
            customListRequestModel.pagenumber = 1;
            customListRequestModel.libraryName = vmadHocFolder.selectedLibrary;
            var searchAPIUrl = '';
            if (urlType == "Class") {
                searchAPIUrl = adHocFolderFactory.getAPIUrl('SEARCH_CLASS', customListRequestModel);
                var obj = [];
                //vmadHocFolder.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(searchAPIUrl));
                var userRequest = adHocFolderService.getData(searchAPIUrl);
                userRequest.then(function (response) {
                    if (response.status === 200) {
                        angular.forEach(response.data.data, function (classItem) {
                            //var objClassModel = TemplateFactory.getClassUI(classItem);
                            //obj.push({ ClassId: objClassModel.ClassId });
                            var classUIModel;
                            classUIModel = adHocFolderFactory.getClassUI(classItem);
                            if (classUIModel.Description && classUIModel.Description.trim().length > 0) {
                                classUIModel.Description = classUIModel.ClassId + ' - ' + classUIModel.Description;
                            } else {
                                classUIModel.Description = classUIModel.ClassId;
                            }
                            obj.push(classUIModel);
                            classUIModel = null;
                        });
                        // obj.push({ ClassId: '#CLASSID#', Description: '#CLASSID#' });
                        deffered.resolve(obj);
                    } else {
                        //vmadHocFolder.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                        deffered.resolve(obj);
                    }
                }, function (response) {
                    //vmadHocFolder.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                    deffered.resolve(obj);
                });
            }
            else if (urlType == "subClass") {
                var obj = [];
                if (vmadHocFolder.chipClasses && vmadHocFolder.chipClasses != null && vmadHocFolder.chipClasses.length != 1) {
                    deffered.resolve(obj);
                }
                else {
                    customListRequestModel.MetaType = vmadHocFolder.chipClasses[0].ClassId;

                    if (!customListRequestModel.MetaType || customListRequestModel.MetaType == '#CLASSID#') {
                        //obj.push({ ClassId: '#SUBCLASSID#', Description: '#SUBCLASSID#' });
                        deffered.resolve(obj);
                    }
                    else {
                        searchAPIUrl = adHocFolderFactory.getAPIUrl('SEARCH_SUBCLASS', customListRequestModel);

                        //vmadHocFolder.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(searchAPIUrl));
                        var userRequest = adHocFolderService.getData(searchAPIUrl);
                        userRequest.then(function (response) {
                            if (response.status === 200) {
                                angular.forEach(response.data.data, function (classItem) {

                                    var subclassUIModel;
                                    subclassUIModel = adHocFolderFactory.getClassUI(classItem);
                                    if (subclassUIModel.Description && subclassUIModel.Description.trim().length > 0) {
                                        subclassUIModel.Description = subclassUIModel.ClassId + ' - ' + subclassUIModel.Description;
                                    } else {
                                        subclassUIModel.Description = subclassUIModel.ClassId;
                                    }
                                    obj.push(subclassUIModel);
                                    subclassUIModel = null;
                                });
                                //obj.push({ ClassId: '#SUBCLASSID#', Description: '#SUBCLASSID#' });
                                deffered.resolve(obj);
                            } else {
                                //vmadHocFolder.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                                deffered.resolve(obj);
                            }
                        }, function (response) {
                            //vmadHocFolder.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                            deffered.resolve(obj);
                        });
                    }
                }
            }
            else if (urlType == 'Type') {
                searchAPIUrl = adHocFolderFactory.getAPIUrl('SEARCH_TYPES', customListRequestModel);
                var obj = [];
                //vmadHocFolder.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(searchAPIUrl));
                var userRequest = adHocFolderService.getData(searchAPIUrl);
                userRequest.then(function (response) {
                    if (response.status === 200) {
                        angular.forEach(response.data.data, function (typeItem) {

                            //obj.push(TemplateFactory.getTypeUI(typeItem));
                            var typeUIModel;
                            typeUIModel = adHocFolderFactory.getTypeUI(typeItem);
                            if (typeUIModel.Description && typeUIModel.Description.trim().length > 0) {
                                typeUIModel.Description = typeUIModel.typeId + ' - ' + typeUIModel.Description;
                            } else {
                                typeUIModel.Description = typeUIModel.typeId;
                            }
                            obj.push(typeUIModel);
                            typeUIModel = null;

                        });
                        //obj.push({ typeId: '#TYPEID#', Description: '#TYPEID#' });
                        deffered.resolve(obj);
                    } else {
                        //vmadHocFolder.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                        deffered.resolve(obj);
                    }
                }, function (response) {
                    //vmadHocFolder.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                    deffered.resolve(obj);
                });
            }
            return deffered.promise;
        }

        vmadHocFolder.NumLostFocus = function (type) {
            if (type == 'custom17') {
                if (isNaN(vmadHocFolder.adHocFolderModel.custom17)) {
                    vmadHocFolder.adHocFolderModel.custom17 = '';
                }
            }
            else if (type == 'custom18') {
                if (isNaN(vmadHocFolder.adHocFolderModel.custom18)) {
                    vmadHocFolder.adHocFolderModel.custom18 = '';
                }
            }
            else if (type == 'custom19') {
                if (isNaN(vmadHocFolder.adHocFolderModel.custom19)) {
                    vmadHocFolder.adHocFolderModel.custom19 = '';
                }
            }
            else if (type == 'custom20') {
                if (isNaN(vmadHocFolder.adHocFolderModel.custom20)) {
                    vmadHocFolder.adHocFolderModel.custom20 = '';
                }
            }
        };


        vmadHocFolder.calendarchange = function (type) {
            if (type == 'CUSTOM21' || type == 'CUSTOM22' || type == 'CUSTOM23' || type == 'CUSTOM24' || type == 'create_date' || type == 'edit_date') {
                if (vmadHocFolder.adHocFolderModel[type.toLowerCase()] == "Onorbefore" || vmadHocFolder.adHocFolderModel[type.toLowerCase()] == "Onorafter" || vmadHocFolder.adHocFolderModel[type.toLowerCase()] == "On" || vmadHocFolder.adHocFolderModel[type.toLowerCase()] == "Between") {
                    if (vmadHocFolder.adHocFolderModel[type.toLowerCase()] == "Between") {
                        vmadHocFolder.UntilDate = true;
                    }
                    else {
                        vmadHocFolder.UntilDate = false;
                    }
                    vmadHocFolder.AddDateField(type);
                }
                else {
                    if (type == 'create_date' || type == 'edit_date') {
                        vmadHocFolder.adHocFolderModel[type.toLowerCase() + '_start'] = '';
                        vmadHocFolder.adHocFolderModel[type.toLowerCase() + '_end'] = '';
                        vmadHocFolder.adHocFolderModel[type.toLowerCase() + '_relative'] = vmadHocFolder.adHocFolderModel[type.toLowerCase()];
                    }
                    else {
                        vmadHocFolder.adHocFolderModel[type.toLowerCase() + '_from'] = '';
                        vmadHocFolder.adHocFolderModel[type.toLowerCase() + '_to'] = '';
                        vmadHocFolder.adHocFolderModel[type.toLowerCase() + '_relative'] = vmadHocFolder.adHocFolderModel[type.toLowerCase()];
                    }
                }
            }
        }

        function DialogController($scope, $mdDialog) {
            $scope.hide = function () {
                $mdDialog.hide();
            };
            $scope.cancel = function () {
                $mdDialog.cancel();
            };
            
		}
        vmadHocFolder.SaveSearchCriteria = function () {
            SetProfileValues();
            vmadHocFolder.adHocFolderModel.FolderType = 'search';
            vmadHocFolder.adHocFolderModel.RestrictTo = vmadHocFolder.RestrictTo;
            var requestBody = adHocFolderFactory.getFolderPostAPIModel(vmadHocFolder.adHocFolderModel, vmadHocFolder.selectedLibrary);
            vmadHocFolder.adHocFolderModel.SearchProfile = adHocFolderFactory.getProfileInfoUI(requestBody.searchprofile, 'Search Profile', '');
            vmadHocFolder.isAddSerachCriteria = false;
       
        }

        $scope.addDateFields = function () {
            if (vmadHocFolder.adHocFolderModel[$scope.AddDate.Type.toLowerCase()] == "Onorbefore") {
                $scope.AddDate.UntilDate = $scope.AddDate.FromDate;
                $scope.AddDate.FromDate = '01/01/1753 00:00:00';

            }
            if (vmadHocFolder.adHocFolderModel[$scope.AddDate.Type.toLowerCase()] == "Onorafter") {
                $scope.AddDate.UntilDate = '12/30/9999 23:59:59';
            }
            if (vmadHocFolder.adHocFolderModel[$scope.AddDate.Type.toLowerCase()] == "On") {
                $scope.AddDate.UntilDate = $scope.AddDate.FromDate;
            }
            if ($scope.AddDate.Type == 'create_date' || $scope.AddDate.Type == 'edit_date') {
                vmadHocFolder.adHocFolderModel[$scope.AddDate.Type.toLowerCase() + '_start'] = $scope.AddDate.FromDate;
                vmadHocFolder.adHocFolderModel[$scope.AddDate.Type.toLowerCase() + '_end'] = $scope.AddDate.UntilDate;
                vmadHocFolder.adHocFolderModel[$scope.AddDate.Type.toLowerCase() + '_relative'] = '';
            }
            else {
                vmadHocFolder.adHocFolderModel[$scope.AddDate.Type.toLowerCase() + '_from'] = $scope.AddDate.FromDate;
                vmadHocFolder.adHocFolderModel[$scope.AddDate.Type.toLowerCase() + '_to'] = $scope.AddDate.UntilDate;
                vmadHocFolder.adHocFolderModel[$scope.AddDate.Type.toLowerCase() + '_relative'] = '';
            }
            $mdDialog.hide();
        }

		vmadHocFolder.CancelChooseDb = function () {
            vmadHocFolder.adHocFolderModel.WithIn = vmadHocFolder.selectedLibrary;
            vmadHocFolder.WithIn = 'CurrentDb';
            $mdDialog.hide();
        }

        vmadHocFolder.SaveChooseDb = function () {

            vmadHocFolder.adHocFolderModel.WithIn = '';
            angular.forEach(vmadHocFolder.DBLibrariesByUser, function (item) {
                if (item.Selected) {
                    if (vmadHocFolder.adHocFolderModel.WithIn == '') {
                        vmadHocFolder.adHocFolderModel.WithIn += item.DatabaseName;
                    } else {
                        vmadHocFolder.adHocFolderModel.WithIn += ',' + item.DatabaseName;
                    }
                }

            });
            if (vmadHocFolder.adHocFolderModel.WithIn == '') {
                vmadHocFolder.WithIn = 'CurrentDb';
                vmadHocFolder.adHocFolderModel.WithIn = vmadHocFolder.selectedLibrary;
            }
            $mdDialog.hide();
        }

 vmadHocFolder.ChooseDb = function () {

            angular.forEach(vmadHocFolder.DBLibrariesByUser, function (item) {
                item.Selected = false;

            });

            var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
            $mdDialog.show({
                controller: ['$scope', '$mdDialog', DialogController],
                scope: $scope, // use parent scope in template
                preserveScope: true, // do not forget this if use parent scope
                templateUrl: 'framework/adhocFolder/misc/ChooseDb.html',
                parent: angular.element(document.body),
                clickOutsideToClose: true,
                fullscreen: useFullScreen

            }).then(function (answer) {

            }, function () {

            });
            $scope.$watch(function () {
                return $mdMedia('xs') || $mdMedia('sm');
            }, function (wantsFullScreen) {
                $scope.customFullscreen = (wantsFullScreen === true);
            });
        };

        vmadHocFolder.AddDateField = function (type) {
            $scope.UserAction = 'Date';
            $scope.AddDate = {
                FromDate: new Date(),
                UntilDate: new Date(),
                Type: type
            };
            var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
            $mdDialog.show({
                controller: ['$scope', '$mdDialog', DialogController],
                scope: $scope, // use parent scope in template
                preserveScope: true, // do not forget this if use parent scope
                templateUrl: 'framework/adhocFolder/misc/AddDate.html',
                parent: angular.element(document.body),
                clickOutsideToClose: true,
                fullscreen: useFullScreen

            }).then(function (answer) {

            }, function () {

            });
            $scope.$watch(function () {
                return $mdMedia('xs') || $mdMedia('sm');
            }, function (wantsFullScreen) {
                $scope.customFullscreen = (wantsFullScreen === true);
            });
        };
		
		function getParentFolderProfile() {
            vmadHocFolder.IsInheritSecurity = true;
            vmadHocFolder.adHocFolderModel.DefaultSecurity = 'inherit';
            vmadHocFolder.adHocFolderDefaultSecurity = 'private';
            var apiUrl = adHocFolderFactory.getAPIUrl('GET_SINGLE_FOLDER_DETAILS', parentId);
            $scope.mc.getlogDetails("Debug", 'Requested Api Url:' + JSON.stringify(apiUrl));

            var promise = adHocFolderService.getData(apiUrl);
            promise.then(function (response) {
                if (response.status === 200 && response.data && response.data.data) {
                    if (response.data.data.wstype === 'workspace') {
                        vmadHocFolder.adHocFolderModel.DefaultSecurity = 'inherit';
                        vmadHocFolder.adHocFolderDefaultSecurity = response.data.data.default_security;
                        return;
                    }

                    var folderUIModelTemp = adHocFolderFactory.getFolderUIModel(response.data.data);
                    if (folderUIModelTemp.DefaultSecurity === 'inherit') {
                        vmadHocFolder.adHocFolderModel.DefaultSecurity = 'inherit';
                        vmadHocFolder.adHocFolderDefaultSecurity = folderUIModelTemp.InheritedDefaultSecurity
                    }
                    else {
                        vmadHocFolder.adHocFolderModel.DefaultSecurity = folderUIModelTemp.DefaultSecurity;
                        vmadHocFolder.adHocFolderDefaultSecurity = folderUIModelTemp.DefaultSecurity
                    }
                }
                else {
                    $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                }
            }, function (response) {
                $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));

            });
        }

        function getParentSecurity() {
            var apiUrl = adHocFolderFactory.getFolderSecurityAPI(parentId);
            $scope.mc.getlogDetails("Debug", 'Requested Api Url:' + JSON.stringify(apiUrl));

            var promise = adHocFolderService.getData(apiUrl);
            promise.then(function (response) {
                if (response.status === 200 && response.data && response.data.data && response.data.data.length > 0) {
                    $scope.mc.getlogDetails("Debug", 'Response:Success');

                    angular.forEach(response.data.data, function (item) {
                        var tempUIModel = adHocFolderFactory.getSecurityUIModel(item);
                        tempUIModel.SID = 0;
                        if (tempUIModel.Type === 'group') {
                            tempUIModel.UserPhoto = 'assets/images/active-users.svg';
                            vmadHocFolder.SecurityList.push(tempUIModel);
                            vmadHocFolder.SecurityListWithFilter.push(angular.copy(tempUIModel));
                            tempUIModel = null;
                        }
                        else if (tempUIModel.Type === 'user') {
                            var promisePhoto = getUserPhoto(tempUIModel);
                            promisePhoto.then(function (responsePhoto) {
                                vmadHocFolder.SecurityList.push(tempUIModel);
                                vmadHocFolder.SecurityListWithFilter.push(angular.copy(tempUIModel));
                                tempUIModel = null;
                            }, function (responsePhoto) {

                            });
                        }
                    });
                }
                else {
                    $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                }
            }, function (response) {
                $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));

            });
        }
        
        function selectedUserGroup_Change(item) {
            if (item == null) return;

            var securityUIModel = adHocFolderFactory.getSecurityInitialValue();
            if (item.Type === 'User') {
                securityUIModel.Id = item.UserId;
                securityUIModel.Name = item.FullName;
                securityUIModel.UserPhoto = item.UserPhoto;
                securityUIModel.UserPhotoText = item.UserPhotoText;
                securityUIModel.Type = 'user';
            }
            else if (item.Type === 'Group') {
                securityUIModel.Id = item.Name;
                securityUIModel.Name = item.FullName;
                securityUIModel.Type = 'group';
                securityUIModel.UserPhoto = 'assets/images/active-users.svg';
            }
            securityUIModel.AccessLevel = 'no_access';
            securityUIModel.Access = 0;

            vmadHocFolder.NewUserGroupList.push(securityUIModel);
            securityUIModel = null;
			item = null;
            vmadHocFolder.SelectedUserGroup = null;
            vmadHocFolder.UserGroupSearchText = '';
        }

        function querySearchUserGroup(searchText) {
            var deferredSearch = $q.defer();
            var deferedarry = [];
            var searchList = [];

            var deferred = $q.defer();
            var promiseUser = searchUser(searchText);
            promiseUser.then(function (response) {
                if (response.Status === 0) {
                    angular.forEach(response.SearchResultList, function (user) {
                        searchList.push(user);
                    });
                    deferred.resolve();
                }
            }, function (response) {
            });
            deferedarry.push(deferred.promise);

            var deferredGroup = $q.defer();
            var promiseGroup = searchGroup(searchText);
            promiseGroup.then(function (response) {
                if (response.Status === 0) {
                    angular.forEach(response.SearchResultList, function (group) {
                        searchList.push(group);
                    });
                    deferredGroup.resolve();
                }
            }, function (response) {
            });
            deferedarry.push(deferredGroup.promise);

            $q.all(deferedarry).then(function () {
                deferredSearch.resolve(searchList);
            });
            return deferredSearch.promise;
        }

        function searchUser(searchText) {
            var deferred = $q.defer();
            var requestModel = homeFactory.requestModelInstance();
            requestModel.libraryName = vmadHocFolder.selectedLibrary;
            requestModel.searchText = searchText;
            requestModel.pagenumber = 1;

            var apiUrl = adHocFolderFactory.getAPIUrl('SEARCH_USERS', requestModel);
            $scope.mc.getlogDetails("Debug", 'Requested Api Url:' + JSON.stringify(apiUrl));

            var promise = adHocFolderService.getData(apiUrl);
            promise.then(function (response) {
                if (response.status === 200) {
                    $scope.mc.getlogDetails("Debug", 'Response:Success');

                    var userList = [];
                    var deferedarryPhoto = [];
                    angular.forEach(response.data.data, function (user) {
                        var deferred = $q.defer();
                        var userUIModel = adHocFolderFactory.getUserUI(user);
                        var promisePhoto = getUserPhoto(userUIModel);
                        promisePhoto.then(function (responsePhoto) {
                            userList.push(userUIModel);
                            userUIModel = null;
                            deferred.resolve();
                        }, function (responsePhoto) {
                            userList.push(userUIModel);
                            userUIModel = null;
                            deferred.resolve();
                        });
                        deferedarryPhoto.push(deferred.promise);
                    });
                    $q.all(deferedarryPhoto).then(function () {
                        deferred.resolve({ Status: 0, SearchResultList: userList });
                    });
                } else {
                    $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                    deferred.resolve({ Status: -1 });
                }
            }, function (response) {
                $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                deferred.resolve({ Status: -1 });
            });
            return deferred.promise;
        }

        function getUserPhoto(tempUserModel) {
            var deferred = $q.defer();
            var userId = '';
            var fullName = '';

            if (tempUserModel.Id != null && tempUserModel.Id.trim().length > 0) {
                userId = tempUserModel.Id;
            }
            else if (tempUserModel.UserId != null && tempUserModel.UserId.trim().length > 0) {
                userId = tempUserModel.UserId;
            }
            if (userId.trim().length === 0) {
                deferred.resolve({ Status: -1 });
                return deferred.promise;
            }
            if (tempUserModel.FullName != null && tempUserModel.FullName.trim().length > 0) {
                fullName = tempUserModel.FullName.trim();
            }
            else if (tempUserModel.Name != null && tempUserModel.Name.trim().length > 0) {
                fullName = tempUserModel.Name.trim();
            }
            var photoText = '';
            if (fullName.length > 0) {
                var nextChar = '';
                var spaceFound = false;

                for (var iCount = 0; iCount < fullName.length; iCount++) {
                    nextChar = fullName.substr(iCount, 1).trim();
                    if (nextChar.length === 0) {
                        spaceFound = true;
                        continue;
                    }
                    if (spaceFound) {
                        photoText = nextChar;
                        spaceFound = false;
                    }
                }
                if (photoText.trim().length === 0) {
                    photoText = fullName.substr(0, 2);
                } else {
                    photoText = fullName.substr(0, 1) + photoText;
                }
            } else {
                photoText = userId.trim().substr(0, 2);
            }
            tempUserModel.UserPhotoText = photoText;

            var apiUrl = adHocFolderFactory.getUserPhotoAPI(userId);
            $scope.mc.getlogDetails("Debug", 'Requested Api Url:' + JSON.stringify(apiUrl));

            var promise = adHocFolderService.getImageData(apiUrl, '');
            promise.then(function (response) {
                if (response.status === 200 && response.data) {
                    $scope.mc.getlogDetails("Debug", 'Response:Success');

                    var blob = new Blob([response.data], { type: 'application/octet-stream' });
                    var url = $window.URL || $window.webkitURL;
                    tempUserModel.UserPhoto = url.createObjectURL(blob);

                    deferred.resolve({ Status: 0 });
                } else {
                    $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                    deferred.resolve({ Status: -1 });
                }
            }, function (response) {
                $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                deferred.resolve({ Status: -1 });
            });
            return deferred.promise;
        }

        function searchGroup(searchText) {
            var deferred = $q.defer();
            var requestModel = homeFactory.requestModelInstance();
            requestModel.libraryName = vmadHocFolder.selectedLibrary;
            requestModel.searchText = searchText;
            requestModel.pagenumber = 1;

            var apiUrl = adHocFolderFactory.getSearchGroupAPI(requestModel);
            $scope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(apiUrl));

            var promise = adHocFolderService.getData(apiUrl);
            promise.then(function (response) {
                if (response.status === 200) {
                    $scope.mc.getlogDetails("Info", 'Response:Success');

                    var groupList = [];
                    angular.forEach(response.data.data, function (group) {
                        var newgroup = adHocFolderFactory.getGroupUIModel(group);
                        groupList.push(newgroup);
                    });
                    deferred.resolve({ Status: 0, SearchResultList: groupList });
                } else {
                    $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                    deferred.resolve({ Status: -1 });
                }
            }, function (response) {
                $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                deferred.resolve({ Status: -1 });
            });
            return deferred.promise;
        }

        function saveSecurityUserGroup() {
            vmadHocFolder.SecurityListSearchText = '';
            if (securityListSearchTimeOut) $timeout.cancel(securityListSearchTimeOut);

            angular.forEach(vmadHocFolder.NewUserGroupList, function (item) {
                item.SID = 0;
                vmadHocFolder.SecurityList.push(angular.copy(item));
            });
            searchSecurityUserGroup_Click();
            backFromAddUserGroup();
        }

        function isInheritSecurity_Change() {
            if (vmadHocFolder.IsInheritSecurity) {
                vmadHocFolder.SecurityList = [];
                vmadHocFolder.SecurityListWithFilter = [];
                vmadHocFolder.SecurityListSearchText = '';
                if (securityListSearchTimeOut) $timeout.cancel(securityListSearchTimeOut);

                getParentSecurity();
            }
            else {
                vmadHocFolder.adHocFolderModel.DefaultSecurity = vmadHocFolder.adHocFolderDefaultSecurity;
            }
        }

        function searchSecurityUserGroup_Click() {
            vmadHocFolder.SecurityListWithFilter = [];
            if (securityListSearchTimeOut) $timeout.cancel(securityListSearchTimeOut);

            angular.forEach(vmadHocFolder.SecurityList, function (item) {
                if (vmadHocFolder.SecurityListSearchText.length === 0) {
                    vmadHocFolder.SecurityListWithFilter.push(angular.copy(item));
                }
                else {
                    if (item.Id.indexOf(vmadHocFolder.SecurityListSearchText) > -1) {
                        vmadHocFolder.SecurityListWithFilter.push(angular.copy(item));
                    }
                    else if (item.Name.indexOf(vmadHocFolder.SecurityListSearchText) > -1) {
                        vmadHocFolder.SecurityListWithFilter.push(angular.copy(item));
                    }
                }
            });
        }

        function accessLevel_Change(item) {
            for (var iCount = 0; iCount < vmadHocFolder.SecurityList.length; iCount++) {
                if (item.Type === vmadHocFolder.SecurityList[iCount].Type && item.Id === vmadHocFolder.SecurityList[iCount].Id) {
                    vmadHocFolder.SecurityList[iCount].AccessLevel = item.AccessLevel;
                    break;
                }
            }
        }

		function getCaptions() {

            var caprequestModel = homeFactory.requestModelInstance();
            

            caprequestModel.libraryName = vmadHocFolder.selectedLibrary;
            caprequestModel.isTotal = true;
            caprequestModel.searchText = '';
            caprequestModel.pageLength = 1000;
            caprequestModel.locale = 1033;
            var apiUrl = homeFactory.getAPIUrl('SEARCHCAPTIONS', caprequestModel)
            $scope.mc.getlogDetails("Debug", 'Requested Api Url:' + JSON.stringify(apiUrl));
            var promise = adHocFolderService.getData(apiUrl, "");
            promise.then(function (response) {
                $scope.CaptionsList = [];
                if (response) {

                    angular.forEach(response.data["data"], function (caption) {
                        $scope.CaptionsList.push(homeFactory.getCaptionUIModel(caption));
                    });


                }
            });
        }
     
        function fillDBinUserList() {
            var apiUrl = adHocFolderFactory.getDBListAPI();
            $scope.mc.getlogDetails("Debug", 'Method:GET;URL:' + apiUrl);
            var promise = adHocFolderService.getData(apiUrl);
            promise.then(function (response) {
                if (response && response.data && response.data.data && response.data.data.length > 0) {
                    $scope.mc.getlogDetails("Info", 'Response:Success');
                    vmadHocFolder.DBLibrariesByUser = [];
                    angular.forEach(response.data["data"], function (db) {
                        vmadHocFolder.DBLibrariesByUser.push(homeFactory.getDatabaseUI(db));
                    });
                }
                else {
                    $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
                }
            }, function (response) {
                $scope.mc.getlogDetails("Error", 'Response:' + JSON.stringify(response));
            });
        }

		vmadHocFolder.isIndeterminate = function (key) {
            return vmadHocFolder.adHocFolderModel[key] === 'inter';
        };

        vmadHocFolder.isChecked = function (key) {
            return vmadHocFolder.adHocFolderModel[key] === true;
        };

        vmadHocFolder.changeValue = function (key) {
            if (vmadHocFolder.adHocFolderModel[key] === false)
                vmadHocFolder.adHocFolderModel[key] = 'inter';
            else if (vmadHocFolder.adHocFolderModel[key] === true)
                vmadHocFolder.adHocFolderModel[key] = false;
            else if (vmadHocFolder.adHocFolderModel[key] === 'inter')
                vmadHocFolder.adHocFolderModel[key] = true;
        }


		
		function showGroupMemberList(groupModel) {
            vmadHocFolder.IsGroupMemberVisible = true;
            vmadHocFolder.GroupMembers.SelectedGroup = angular.copy(groupModel);
            vmadHocFolder.GroupMembers.HeaderText = '';
            vmadHocFolder.GroupMembers.SearchText = '';
            vmadHocFolder.GroupMembers.GroupMemberList = [];
            groupMembersReqModel = homeFactory.requestModelInstance();
            groupMembersReqModel.pagenumber = 1;

            getGroupMembers();
        }

        function hideGroupMemberList() {
            if (groupMemberSearchTimeOut)
                $timeout.cancel(groupMemberSearchTimeOut);
            vmadHocFolder.IsGroupMemberVisible = false;
            vmadHocFolder.GroupMembers.SelectedGroup = null;
            vmadHocFolder.GroupMembers.HeaderText = '';
            vmadHocFolder.GroupMembers.SearchText = '';
            vmadHocFolder.GroupMembers.GroupMemberList = [];
            groupMembersTotalCount = 0;
        }

        function groupMembers_ClearSearchClick() {
            isgroupMembersInstantSearch = true;
            vmadHocFolder.GroupMembers.SearchText = '';
        }

        function groupMembers_SearchClick() {
            if (groupMemberSearchTimeOut)
                $timeout.cancel(groupMemberSearchTimeOut);

            groupMembersReqModel = homeFactory.requestModelInstance();
            groupMembersReqModel.pagenumber = 1;
            vmadHocFolder.GroupMembers.GroupMemberList = [];
            getGroupMembers();
        }

        function groupMembers_onListScroll() {
            if (groupMembersTotalCount > vmadHocFolder.GroupMembers.GroupMemberList.length) {
                groupMembersReqModel.pagenumber += 1;
                getGroupMembers()
            }
        }

        function getGroupMembers() {
            groupMembersReqModel.libraryName = vmadHocFolder.selectedLibrary;
            groupMembersReqModel.searchText = vmadHocFolder.GroupMembers.SearchText;

            var apiUrl = adHocFolderFactory.getGroupMembersAPI(groupMembersReqModel, vmadHocFolder.GroupMembers.SelectedGroup.Id);
            $scope.mc.getlogDetails("Debug", 'Method:GET;URL:' + JSON.stringify(apiUrl));

            var promise = homeService.getData(apiUrl, '');
            promise.then(function (response) {
                if (response.status === 200 && response.data) {
                    if (vmadHocFolder.GroupMembers.SearchText.length === 0) {
                        if (response.data.total_count > 0) {
                            vmadHocFolder.GroupMembers.HeaderText = vmadHocFolder.GroupMembers.SelectedGroup.Id + " have " +
                                response.data.total_count.toString() + " members";
                        } else {
                            vmadHocFolder.GroupMembers.HeaderText = "Group Members";
                        }
                    }
                    groupMembersTotalCount = response.data.total_count;

                    if (response.data.data) {
                        angular.forEach(response.data.data, function (userItem) {
                            var userUIModelTemp = adHocFolderFactory.getUserUI(userItem);

                            getUserPhoto(userUIModelTemp).then(function (responseItem) {
                                vmadHocFolder.GroupMembers.GroupMemberList.push(userUIModelTemp);
                            });
                        });
                    }
                } else {
                    $scope.mc.getlogDetails("Error", 'Method:GET;URL:' + JSON.stringify(apiUrl) + ",Response:" + JSON.stringify(response));
                }
            }, function (response) {
                $scope.mc.getlogDetails("Error", 'Method:GET;URL:' + JSON.stringify(apiUrl) + ",Response:" + JSON.stringify(response));
            });
        }		
    }
})();