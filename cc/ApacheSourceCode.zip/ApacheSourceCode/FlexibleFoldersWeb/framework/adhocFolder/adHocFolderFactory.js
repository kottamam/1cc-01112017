﻿(function () {
    'use strict';

    define(['angular'], function (angular) {
        angular.module('iManage').factory('adHocFolderFactory', adHocFolderFactory);

		adHocFolderFactory.$inject = ['API_URL_adHOC_FODLER', 'CONST_FOLDER', 'CONST_SYSTEM_CONFIG', 'adHOC_FODLER_CONST_USERS', 'adHOC_FODLER_CONST_GROUPS', 'adHOC_FODLER_CONST_SECURITY'];
		function adHocFolderFactory(API_URL_adHOC_FODLER, CONST_FOLDER, CONST_SYSTEM_CONFIG, adHOC_FODLER_CONST_USERS, adHOC_FODLER_CONST_GROUPS, adHOC_FODLER_CONST_SECURITY) {

            var adHocFolderUIModel = {
                Database: '',
                DefaultSecurity: '',
				InheritedDefaultSecurity: '',
                Description: "",
                EditDate: '',
                FolderType: '',
                HasSubfolders: '',
                Id: '',
                IsContainerSavedSearch: '',
                IsContentSavedSearch: '',
                IsExternalAsNormal: '',
                IsHidden: '',
                Name: '',
                Owner: '',
                ParentId: '',
                SubType: '',
                ViewType: '',
                Wstype: '',
                ContentSavedSearchId: '',
                Profile: '',
                FP_Author: '',
                FP_Operator: '',
                FP_DocumentNum: '',
                FP_Version: '',
                FP_Description: '',
                FP_Class: '',
                FP_Email: '',
                FP_SubClass: '',
                FP_Type: '',
                FP_LookFor_Anywhere: '',
                FP_LookFor_Lang: '',
                FP_LookFor_Comments: '',
                FP_LookFor_CommentsDescription: '',
                FP_LookFor_Description: '',
                FP_LookFor_Body: '',
                FP_LookFor_Type: 0

                //SP_DocumentsOnly: '',
                //SP_EmailsOnly: '',
                //SP_Create_Relative: '',
                //SP_Create_Start: '',
                //SP_Create_End: '',
                //SP_Edit_Relative: '',
                //SP_Edit_Start: '',
                //SP_Edit_End: '',
                //SP_LookFor_Lang: '',
                //SP_LookFor: '',
                //SP_LookFor_Type: 0,
                //RestrictSeach: '',
                //CreateDate: ''
            };

            var classUIModel = {
                ClassId: ''
            };

            var userUIModel = {
                UserId: '',
                FullName: '',
                Email: '',
                UserPhoto: null,
                UserPhotoText: '',
                Type: 'User'
            };

            var groupUIModel = {
                Name: '',
                FullName: '',
                Type: 'Group'
            };

			var typeUIModel = {
                typeId: ''
            };

            var metaDataUIModel = {
                Alias: '',
                Description: '',
                HIPAAComplaint: false,
                EnableFlag: true,
                ParentAlias: '',
                GrandParentAlias: '',
                ShowEditButton: false
            };

            var SystemConfigUIModel = {
                //IMCC_OF_MATCHFIELDS: '',
                IMCC_EMAIL_DOMAIN: ''
            };
			
			var securityUIModel = {
                Id: '',
                Name: '',
                AccessLevel: '',
                Type: '',
                Access: null,
                SID: null,
                UserPhotoText: '',
                UserPhoto: null
            };

            var returnAdHocFolderInitialValues = function () {
                return angular.copy(adHocFolderUIModel);
            };

            var returnMetaUIModel = function (metaApiModel) {
                return getMetaDataUIModel(metaApiModel);

            }

            var returngetUserUI = function (userApiModel) {
                return getUserUIModel(userApiModel);
            }

            var returngetClassUI = function (classApiModel) {
                return getClassUIModel(classApiModel);
            }

            var returngetEmailDomain = function (systemConfigApiModel) {
                return getEmailDomain(systemConfigApiModel);
            }

            var returngetTypeUI = function (TypeApiModel) {
                return getTypeUIModel(TypeApiModel);
            }

            function getTypeUIModel(typeApiModel) {
                var typeModel = angular.copy(typeUIModel);
                typeModel.typeId = typeApiModel["id"];
                typeModel.Description = typeApiModel["description"];
                return typeModel;
            }

            function getEmailDomain(systemConfigApiModel) {
                var systemConfigModel = angular.copy(SystemConfigUIModel);
                //systemConfigModel.IMCC_OF_MATCHFIELDS = systemConfigApiModel[CONST_SYSTEM_CONFIG.IMCC_OF_MATCHFIELDS];
                systemConfigModel.IMCC_EMAIL_DOMAIN = systemConfigApiModel[CONST_SYSTEM_CONFIG.IMCC_EMAIL_DOMAIN];
                return systemConfigModel;
            }

            function getClassUIModel(classApiModel) {
                var classModel = angular.copy(classUIModel);//'',
                classModel.ClassId = classApiModel["id"];
                classModel.Description = classApiModel["description"];
                return classModel;
            }

            function getMetaDataUIModel(metaDataApiModel) {
                var metaModel = angular.copy(metaDataUIModel);
                metaModel.Alias = metaDataApiModel["id"];//.user_id_ex;
                metaModel.Description = metaDataApiModel["description"];
                metaModel.HIPAAComplaint = metaDataApiModel["hipaa"];
                metaModel.EnableFlag = metaDataApiModel["enabled"];
                return metaModel;
            }

            function getUserUIModel(userApiModel) {
                var userModel = angular.copy(userUIModel);
                userModel.UserId = userApiModel[adHOC_FODLER_CONST_USERS.UserIdEx] || userApiModel[adHOC_FODLER_CONST_USERS.UserId];
                userModel.FullName = userApiModel[adHOC_FODLER_CONST_USERS.FullName];
                userModel.Email = userApiModel[adHOC_FODLER_CONST_USERS.Email];

                return userModel;
            }

            function returnFolderPostAPIModel(adHocFolderModel, UserDb) {
                var apiModel = {};
                apiModel[CONST_FOLDER.Database] = UserDb;
                if (adHocFolderModel.DefaultSecurity && adHocFolderModel.DefaultSecurity != '')
                    apiModel[CONST_FOLDER.DefaultSecurity] = adHocFolderModel.DefaultSecurity;

                apiModel[CONST_FOLDER.Name] = adHocFolderModel.Name;
                apiModel[CONST_FOLDER.Description] = adHocFolderModel.Description;
                apiModel[CONST_FOLDER.Owner] = adHocFolderModel.Owner;
                apiModel[CONST_FOLDER.Email] = adHocFolderModel.Email;
                if (adHocFolderModel.FolderType != 'tab') {
                    if (adHocFolderModel.FolderType == 'regular') {
                        CONST_FOLDER.Profile = 'profile';
                    }
                    else if (adHocFolderModel.FolderType == 'search') {
                        CONST_FOLDER.Profile = 'searchprofile';
                    }
                    apiModel[CONST_FOLDER.Profile] = {};

                    if (adHocFolderModel.FolderType == 'search') {
                        apiModel[CONST_FOLDER.Profile]['contenttype'] = 'D,5';
                    }
                    else if (adHocFolderModel.FolderType == 'regular') {
                    }                   

                    if (adHocFolderModel.FolderType == 'regular') {

                        if (adHocFolderModel.FP_Author && adHocFolderModel.FP_Author != '') {
                            apiModel[CONST_FOLDER.Profile][CONST_FOLDER.FP_Author] = adHocFolderModel.FP_Author;
                        }

                        if (adHocFolderModel.FP_Class && adHocFolderModel.FP_Class != '') {
                            apiModel[CONST_FOLDER.Profile][CONST_FOLDER.FP_Class] = adHocFolderModel.FP_Class;
                        }

                        if (adHocFolderModel.FP_SubClass && adHocFolderModel.FP_SubClass != '') {
                            apiModel[CONST_FOLDER.Profile][CONST_FOLDER.FP_SubClass] = adHocFolderModel.FP_SubClass;
                        }
                    }
                    else if (adHocFolderModel.FolderType == 'search') {
                        if (adHocFolderModel.WithIn && adHocFolderModel.WithIn != '') {
                            apiModel[CONST_FOLDER.Profile]['databases'] = adHocFolderModel.WithIn;
                        }

                        if (adHocFolderModel.RestrictTo && adHocFolderModel.RestrictTo == 'DOCUMENTS') {
                            apiModel[CONST_FOLDER.Profile][CONST_FOLDER.FP_DocumentsOnly] = true;

                            if (adHocFolderModel.FP_Author && adHocFolderModel.FP_Author != '') {
                                apiModel[CONST_FOLDER.Profile][CONST_FOLDER.FP_Author] = adHocFolderModel.FP_Author;
                            }

                            if (adHocFolderModel.FP_Class && adHocFolderModel.FP_Class != '') {
                                apiModel[CONST_FOLDER.Profile][CONST_FOLDER.FP_Class] = adHocFolderModel.FP_Class;
                            }

                            if (adHocFolderModel.FP_Operator && adHocFolderModel.FP_Operator != '') {
                                apiModel[CONST_FOLDER.Profile][CONST_FOLDER.FP_Operator] = adHocFolderModel.FP_Operator;
                            }
                            if (adHocFolderModel.FP_DocumentNum && adHocFolderModel.FP_DocumentNum != '') {
                                apiModel[CONST_FOLDER.Profile][CONST_FOLDER.FP_DocumentNum] = adHocFolderModel.FP_DocumentNum;
                            }
                            if (adHocFolderModel.FP_Version && adHocFolderModel.FP_Version != '') {
                                apiModel[CONST_FOLDER.Profile][CONST_FOLDER.FP_Version] = adHocFolderModel.FP_Version;
                            }

                            if (adHocFolderModel.FP_Description && adHocFolderModel.FP_Description != '') {
                                apiModel[CONST_FOLDER.Profile][CONST_FOLDER.FP_Description] = adHocFolderModel.FP_Description;
                            }

                            if (adHocFolderModel.FP_Type && adHocFolderModel.FP_Type != '') {
                                apiModel[CONST_FOLDER.Profile][CONST_FOLDER.FP_Type] = adHocFolderModel.FP_Type;
                            }

                            if (adHocFolderModel.FP_LookFor_Lang && adHocFolderModel.FP_LookFor_Lang != '') {
                                apiModel[CONST_FOLDER.Profile][CONST_FOLDER.FP_LookFor_Lang] = adHocFolderModel.FP_LookFor_Lang;
                            }

                            if (adHocFolderModel[CONST_FOLDER.FP_Create_Relative] && adHocFolderModel[CONST_FOLDER.FP_Create_Relative] != '') {
                                apiModel[CONST_FOLDER.Profile][CONST_FOLDER.FP_Create_Relative] = adHocFolderModel[CONST_FOLDER.FP_Create_Relative];
                            }
                            else if (adHocFolderModel[CONST_FOLDER.FP_Create_Start] && adHocFolderModel[CONST_FOLDER.FP_Create_Start] != '') {
                                apiModel[CONST_FOLDER.Profile][CONST_FOLDER.FP_Create_Start] = adHocFolderModel[CONST_FOLDER.FP_Create_Start];
                                apiModel[CONST_FOLDER.Profile][CONST_FOLDER.FP_Create_End] = adHocFolderModel[CONST_FOLDER.FP_Create_End];
                            }
                            else if (adHocFolderModel[CONST_FOLDER.FP_Create_End] && adHocFolderModel[CONST_FOLDER.FP_Create_End] != '') {
                                apiModel[CONST_FOLDER.Profile][CONST_FOLDER.FP_Create_Start] = adHocFolderModel[CONST_FOLDER.FP_Create_Start];
                                apiModel[CONST_FOLDER.Profile][CONST_FOLDER.FP_Create_End] = adHocFolderModel[CONST_FOLDER.FP_Create_End];
                            }


                            if (adHocFolderModel[CONST_FOLDER.FP_Edit_Relative] && adHocFolderModel[CONST_FOLDER.FP_Edit_Relative] != '') {
                                apiModel[CONST_FOLDER.Profile][CONST_FOLDER.FP_Edit_Relative] = adHocFolderModel[CONST_FOLDER.FP_Edit_Relative];
                            }
                            else if (adHocFolderModel[CONST_FOLDER.FP_Edit_Start] && adHocFolderModel[CONST_FOLDER.FP_Edit_Start] != '') {
                                apiModel[CONST_FOLDER.Profile][CONST_FOLDER.FP_Edit_Start] = adHocFolderModel[CONST_FOLDER.FP_Edit_Start];
                                apiModel[CONST_FOLDER.Profile][CONST_FOLDER.FP_Edit_End] = adHocFolderModel[CONST_FOLDER.FP_Edit_End];
                            }
                            else if (adHocFolderModel[CONST_FOLDER.FP_Edit_End] && adHocFolderModel[CONST_FOLDER.FP_Edit_End] != '') {
                                apiModel[CONST_FOLDER.Profile][CONST_FOLDER.FP_Edit_Start] = adHocFolderModel[CONST_FOLDER.FP_Edit_Start];
                                apiModel[CONST_FOLDER.Profile][CONST_FOLDER.FP_Edit_End] = adHocFolderModel[CONST_FOLDER.FP_Edit_End];
                            }

                            if (adHocFolderModel.FP_LookFor && adHocFolderModel.FP_LookFor != '') {
                                if (adHocFolderModel.FP_LookFor_Type == 0) {
                                    apiModel[CONST_FOLDER.Profile][CONST_FOLDER.FP_LookFor_Anywhere] = adHocFolderModel.FP_LookFor;
                                } else if (adHocFolderModel.FP_LookFor_Type == 1) {
                                    apiModel[CONST_FOLDER.Profile][CONST_FOLDER.FP_LookFor_Comments] = adHocFolderModel.FP_LookFor;
                                } else if (adHocFolderModel.FP_LookFor_Type == 2) {
                                    apiModel[CONST_FOLDER.Profile][CONST_FOLDER.FP_LookFor_CommentsDescription] = adHocFolderModel.FP_LookFor;
                                } else if (adHocFolderModel.FP_LookFor_Type == 3) {
                                    apiModel[CONST_FOLDER.Profile][CONST_FOLDER.FP_LookFor_Description] = adHocFolderModel.FP_LookFor;
                                } else if (adHocFolderModel.FP_LookFor_Type == 4) {
                                    apiModel[CONST_FOLDER.Profile][CONST_FOLDER.FP_LookFor_Body] = adHocFolderModel.FP_LookFor;
                                }

                            }


                        }
                        else if (adHocFolderModel.RestrictTo && adHocFolderModel.RestrictTo == 'EMAILS') {
                            apiModel[CONST_FOLDER.Profile][CONST_FOLDER.FP_EmailsOnly] = true;
                        }

                    }

                  

                    for (var i = 1; i <= 30; i++) {
                        if (i != 21 && i != 22 && i != 23 && i != 24) {
                            if (i == 25 || i == 26 || i == 27 || i == 28) {
                                if ((adHocFolderModel.RestrictTo && adHocFolderModel.RestrictTo == 'DOCUMENTS' && adHocFolderModel.FolderType == 'search') || adHocFolderModel.FolderType == 'regular') {
                                    if (adHocFolderModel["custom" + i] == false) {
                                        apiModel[CONST_FOLDER.Profile]["custom" + i] = adHocFolderModel["custom" + i];
                                    }
                                    else if (adHocFolderModel["custom" + i] == true) {
                                        apiModel[CONST_FOLDER.Profile]["custom" + i] = adHocFolderModel["custom" + i];
                                    }
                                }
                            }
                            else {
                                if (adHocFolderModel.FolderType == 'search') {
                                    if (i == 13 || i == 14 || i == 15 || i == 16) {
                                        if (adHocFolderModel.RestrictTo && adHocFolderModel.RestrictTo == 'EMAILS') {
                                            if (adHocFolderModel["custom" + i] && adHocFolderModel["custom" + i] != '') {
                                                apiModel[CONST_FOLDER.Profile]["custom" + i] = adHocFolderModel["custom" + i];
                                            }
                                        }
                                    }
                                    else if (adHocFolderModel["custom" + i] && adHocFolderModel["custom" + i] != '' && adHocFolderModel.RestrictTo && adHocFolderModel.RestrictTo == 'DOCUMENTS') {
                                        apiModel[CONST_FOLDER.Profile]["custom" + i] = adHocFolderModel["custom" + i];
                                    }
                                }
                                else if (adHocFolderModel.FolderType == 'regular') {
                                    if (adHocFolderModel["custom" + i] && adHocFolderModel["custom" + i] != '') {
                                        apiModel[CONST_FOLDER.Profile]["custom" + i] = adHocFolderModel["custom" + i];
                                    }
                                }
                            }
                        }
                        else {
                            if (adHocFolderModel.FolderType == 'regular') {
                                if (adHocFolderModel["custom" + i] && adHocFolderModel["custom" + i] != '') {
                                    apiModel[CONST_FOLDER.Profile]["custom" + i] = GetDate(adHocFolderModel["custom" + i]);
                                }
                            }
                            else if (adHocFolderModel.FolderType == 'search' && adHocFolderModel.RestrictTo && adHocFolderModel.RestrictTo == 'EMAILS') {
                                if (adHocFolderModel["custom" + i + "_relative"] && adHocFolderModel["custom" + i + "_relative"] != '') {
                                    apiModel[CONST_FOLDER.Profile]["custom" + i + "_relative"] = adHocFolderModel["custom" + i + "_relative"];
                                }
                                else if (adHocFolderModel["custom" + i + "_from"] && adHocFolderModel["custom" + i + "_from"] != '') {
                                    apiModel[CONST_FOLDER.Profile]["custom" + i + "_from"] = adHocFolderModel["custom" + i + "_from"];
                                    apiModel[CONST_FOLDER.Profile]["custom" + i + "_to"] = adHocFolderModel["custom" + i + "_to"];
                                }
                                else if (adHocFolderModel["custom" + i + "_to"] && adHocFolderModel["custom" + i + "_to"] != '') {
                                    apiModel[CONST_FOLDER.Profile]["custom" + i + "_from"] = adHocFolderModel["custom" + i + "_from"];
                                    apiModel[CONST_FOLDER.Profile]["custom" + i + "_to"] = adHocFolderModel["custom" + i + "_to"];
                                }
                            }
                        }
                    }


                }
                return apiModel;
            }

            function GetMonthName(monthNumber) {
                var month = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                return month[monthNumber - 1];
            }

            function GetDate(dateString) {
                var dateObj = new Date(dateString);
                if (dateObj != 'Invalid Date') {
                    var monthNumber = dateObj.getMonth() + 1;
                    //var monthName = GetMonthName(monthNumber);
                    //return monthName + " " + dateObj.getDate() + ", " + dateObj.getFullYear();
                    return dateObj.getFullYear() + "-" + monthNumber + "-" + dateObj.getDate() + "T00:00:00Z";

                }
                else {
                    return '';
                }
            }

            var returnAPIUrl = function (APIFOR, requestModel) {
                var ApiUrl = baseUrl + API_URL_adHOC_FODLER[APIFOR];
              
               if (APIFOR == 'GETFOLDERSFROMWORKSPCE') {
                    ApiUrl = ApiUrl.replace('{WS_ID}', requestModel.Id);
                    ApiUrl = prepareFolderGetUrl(ApiUrl, requestModel);
                }
                else if (APIFOR == 'PUT_FOLDER') {
                    ApiUrl = ApiUrl.replace('{FOLDER_ID}', requestModel);
                }
                else if (APIFOR == 'POST_FOLDER') {
                    ApiUrl = ApiUrl.replace('<workspace_id>', requestModel);
                }
                else if (APIFOR == 'POST_TAB') {
                    ApiUrl = ApiUrl.replace('<workspace_id>', requestModel);
                }
                else if (APIFOR == 'POST_SEARCH_FOLDERS') {
                    ApiUrl = ApiUrl.replace('<workspace_id>', requestModel);
                }
                else if (APIFOR == 'GET_SINGLE_FOLDER_DETAILS') {
                    ApiUrl = ApiUrl.replace('{FOLDER_ID}', requestModel);
                }
                else if (APIFOR == 'PUT_SEARCH_FOLDER') {
                    ApiUrl = ApiUrl.replace('{SEARCH_FOLDER_ID}', requestModel);
                }
                else if (APIFOR == 'GETSINGLESEARCHFOLDERDETAILS') {
                    ApiUrl = ApiUrl.replace('{SEARCH_FOLDER_ID}', requestModel);
                }
                else if (APIFOR == 'SEARCHMETADATA') {
                    ApiUrl = ApiUrl.replace("{CUSTOMTYPE}", requestModel.MetaType.toLowerCase());
                    ApiUrl += "?enabled=true&database=" + requestModel.libraryName + '&offset=' + ((requestModel.pagenumber - 1) * requestModel.pageLength) + '&limit=' + requestModel.pageLength + '&total=' + requestModel.isTotal;
                    if (requestModel.searchText != null && requestModel.searchText != '')
                        ApiUrl += '&query=*' + requestModel.searchText + '*'
                }
                else if (APIFOR === 'SEARCH_USERS') {
                    ApiUrl += "?allow_logon=true&database=" + requestModel.libraryName + '&offset=' + ((requestModel.pagenumber - 1) * requestModel.pageLength) +
                        '&limit=' + requestModel.pageLength + '&total=' + requestModel.isTotal;
                    if (requestModel.searchText != null && requestModel.searchText != '')
                        ApiUrl += '&query=*' + requestModel.searchText + '*'
                }
                else if (APIFOR === 'SEARCH_CLASS') {
                    ApiUrl += "?database=" + requestModel.libraryName + '&offset=' + ((requestModel.pagenumber - 1) * requestModel.pageLength) + '&limit=' + requestModel.pageLength + '&total=' + requestModel.isTotal;
                    if (requestModel.searchText != null && requestModel.searchText != '')
                        ApiUrl += '&query=*' + requestModel.searchText + '*'
                }
                else if (APIFOR == 'SEARCH_TYPES') {
                    ApiUrl += "?database=" + requestModel.libraryName + '&offset=' + ((requestModel.pagenumber - 1) * requestModel.pageLength) + '&limit=' + requestModel.pageLength + '&total=' + requestModel.isTotal;
                    if (requestModel.searchText != null && requestModel.searchText != '')
                        ApiUrl += '&query=' + requestModel.searchText
                }
                else if (APIFOR == 'SEARCH_SUBCLASS') {
                    ApiUrl = ApiUrl.replace("{PARENTCLASS}", requestModel.MetaType.toLowerCase());
                    ApiUrl += "?database=" + requestModel.libraryName + '&offset=' + ((requestModel.pagenumber - 1) * requestModel.pageLength) + '&limit=' + requestModel.pageLength + '&total=' + requestModel.isTotal;
                    if (requestModel.searchText != null && requestModel.searchText != '')
                        ApiUrl += '&query=*' + requestModel.searchText + '*'
                }
                else if (APIFOR == 'SEARCHCHILDMETADATA') {
                    ApiUrl = ApiUrl.replace("{CUSTOMTYPE}", requestModel.MetaType.toLowerCase());
                    ApiUrl = ApiUrl.replace("{PALIAS}", requestModel.parentAlias);
                    ApiUrl = ApiUrl.replace("{CHILDCUSTOM}", requestModel.subType.toLowerCase());
                    ApiUrl += "?enabled=true&database=" + requestModel.libraryName + '&offset=' + ((requestModel.pagenumber - 1) * requestModel.pageLength) + '&limit=' + requestModel.pageLength + '&total=' + requestModel.isTotal;
                    if (requestModel.searchText != null && requestModel.searchText != '')
                        ApiUrl += '&query=*' + requestModel.searchText + '*'
                }
                else if (APIFOR === 'SEARCH_FOLDERS' && requestModel !== null) {

                    if (requestModel.email) {
                        ApiUrl = ApiUrl + '?email=' + requestModel.email;

                    }

                }
                return ApiUrl;
            };

            function returnDBListAPI() {
                var apiUrl = baseUrl + API_URL_adHOC_FODLER['GET_DB_LIST'];
                return apiUrl;
            }

            function returnSearchGroupAPI(requestModel) {
                var apiUrl = baseUrl + API_URL_adHOC_FODLER.SEARCH_GROUPS;
                apiUrl = apiUrl.replace('<dbname>', requestModel.libraryName);
                apiUrl = apiUrl.replace('<offset>', requestModel.pagenumber);
                apiUrl = apiUrl.replace('<limit>', requestModel.pageLength);

                if (requestModel.searchText && requestModel.searchText.trim().length > 0) {
                    apiUrl += '&query=*' + requestModel.searchText + '*';
                }
                return apiUrl;
            }

            function returnUserPhotoAPI(userId) {
                var apiUrl = baseUrl + API_URL_adHOC_FODLER.GET_USER_PHOTO;
                apiUrl = apiUrl.replace('<userid>', userId);

                return apiUrl;
            }

            function returnGroupUIModel(groupAPIModel) {
                var tempModel = angular.copy(groupUIModel);
                tempModel.Name = groupAPIModel[adHOC_FODLER_CONST_GROUPS.GroupName];
                tempModel.FullName = groupAPIModel[adHOC_FODLER_CONST_GROUPS.GroupFullName];
                return tempModel;
            }

            function returnSecurityInitialValue() {
                return angular.copy(securityUIModel);
            }

            function returnSecurityUIModel(securityAPIModelTemp) {
                var tempModel = returnSecurityInitialValue();
                tempModel.Id = securityAPIModelTemp[adHOC_FODLER_CONST_SECURITY.Id];
                tempModel.Name = securityAPIModelTemp[adHOC_FODLER_CONST_SECURITY.Name];
                tempModel.AccessLevel = securityAPIModelTemp[adHOC_FODLER_CONST_SECURITY.AccessLevel];
                tempModel.Type = securityAPIModelTemp[adHOC_FODLER_CONST_SECURITY.Type];
                tempModel.Access = securityAPIModelTemp[adHOC_FODLER_CONST_SECURITY.Access];
                tempModel.SID = securityAPIModelTemp[adHOC_FODLER_CONST_SECURITY.SID];
                return tempModel;
            }

            function returnSecurityAPIModel(uiModelTemp) {
                var tempModel = {};
                tempModel[adHOC_FODLER_CONST_SECURITY.Id] = uiModelTemp.Id;
                tempModel[adHOC_FODLER_CONST_SECURITY.Name] = uiModelTemp.Name;
                tempModel[adHOC_FODLER_CONST_SECURITY.AccessLevel] = uiModelTemp.AccessLevel;
                tempModel[adHOC_FODLER_CONST_SECURITY.Type] = uiModelTemp.Type;
                tempModel[adHOC_FODLER_CONST_SECURITY.Access] = 0;
                tempModel[adHOC_FODLER_CONST_SECURITY.SID] = uiModelTemp.SID;

                switch (uiModelTemp.AccessLevel) {
                    case 'read':
                        tempModel[adHOC_FODLER_CONST_SECURITY.Access] = 1;
                        break;

                    case 'read_write':
                        tempModel[adHOC_FODLER_CONST_SECURITY.Access] = 2;
                        break;

                    case 'full_access':
                        tempModel[adHOC_FODLER_CONST_SECURITY.Access] = 3;
                        break;

                    default:
                        tempModel[adHOC_FODLER_CONST_SECURITY.Access] = 0;
                        break;
                }
                return tempModel;
            }

            function returnFolderSecurityAPI(folderId) {
                var apiUrl = baseUrl + API_URL_adHOC_FODLER.FOLDER_SECURITY;
                apiUrl = apiUrl.replace('<object_id>', folderId);

                return apiUrl;
            }

            function returnFolderPathAPI(folderId) {
                var apiUrl = baseUrl + API_URL_adHOC_FODLER.GET_FOLDER_PATH;
                apiUrl = apiUrl.replace('<folder_id>', folderId);

                return apiUrl;
            }

            function returnFolderUIModel(tempFolderAPIModel) {
                var tempUIModel = returnAdHocFolderInitialValues();
                tempUIModel.Database = tempFolderAPIModel[CONST_FOLDER.Database];
                tempUIModel.DefaultSecurity = tempFolderAPIModel[CONST_FOLDER.DefaultSecurity];
                tempUIModel.Description = tempFolderAPIModel[CONST_FOLDER.Description];
                tempUIModel.FolderType = tempFolderAPIModel[CONST_FOLDER.FolderType];
                tempUIModel.HasSubfolders = tempFolderAPIModel[CONST_FOLDER.HasSubfolders];
                tempUIModel.Id = tempFolderAPIModel[CONST_FOLDER.Id];
                tempUIModel.Name = tempFolderAPIModel[CONST_FOLDER.Name];
                tempUIModel.Owner = tempFolderAPIModel[CONST_FOLDER.Owner];
                tempUIModel.ParentId = tempFolderAPIModel[CONST_FOLDER.ParentId];
                tempUIModel.SubType = tempFolderAPIModel[CONST_FOLDER.SubType];
                tempUIModel.ViewType = tempFolderAPIModel[CONST_FOLDER.ViewType];
                tempUIModel.Wstype = tempFolderAPIModel[CONST_FOLDER.Wstype];
				tempUIModel.InheritedDefaultSecurity = tempFolderAPIModel[CONST_FOLDER.DefaultSecurity] === 'inherit' ?
                                                    tempFolderAPIModel[CONST_FOLDER.InheritedDefaultSecurity] : '';
                return tempUIModel;
            }
			
			function returnGroupMembersAPI(requestModel, groupName) {
                var apiUrl = baseUrl + API_URL_adHOC_FODLER.GET_GROUP_USERS;
                apiUrl = apiUrl.replace("<group_alias>", groupName);

                apiUrl += "?database=" + requestModel.libraryName + '&offset=' + ((requestModel.pagenumber - 1) * requestModel.pageLength).toString() +
                            '&limit=' + requestModel.pageLength.toString() + '&total=' + requestModel.isTotal.toString();

                if (requestModel.searchText.trim().length > 0)
                    apiUrl += '&alias=*' + requestModel.searchText.trim() + '*';

                return apiUrl;
            }
			
			function returnProfileInfoUIModel(profileInfo, title, containerName) {
                var apiModel = {};
                if (title == 'Search Profile')
                    apiModel['Restrict Search To'] = 'Documents and E-mails';
                angular.forEach(profileInfo, function (value, key) {
                    try {
                        switch (key) {
                            case 'author':

                                apiModel['Author'] = value;
                                break;
                            case 'operator':

                                apiModel['Operator'] = value;
                                break;
                            case 'emails_only':
                                if (value)
                                    apiModel['Restrict Search To'] = 'E-mails Only';
                                break;
                            case 'documents_only':
                                if (value)
                                    apiModel['Restrict Search To'] = 'Documents Only';
                                break;
                            case 'databases':
                                if (!apiModel['Search Scope'])
                                    apiModel['Search Scope'] = containerName + '<' + value + '>';

                                break;
                            case 'container':
                                if (!apiModel['Search Scope'])
                                    apiModel['Search Scope'] = containerName + '<' + profileInfo['databases'] + '>';
                                break;
                            case 'description_fulltext':
                            case 'comments_fulltext':
                            case 'comments_description_fulltext':
                            case 'body':
                            case 'fulltext':
                                if (key == 'fulltext')
                                    apiModel['Look For Anywhere'] = value;
                                if (key == 'comments_fulltext')
                                    apiModel['Look For Comments'] = value;
                                if (key == 'comments_description_fulltext')
                                    apiModel['Look For Comments/Description'] = value;
                                if (key == 'body')
                                    apiModel['Look For Document contents'] = value;
                                if (key == 'description_fulltext')
                                    apiModel['Look For Description'] = value;
                                if (profileInfo['languageid']) {
                                    switch (profileInfo['languageid']) {
                                        case 'englishUTF8': apiModel['Langage'] = 'English'; break;
                                        case 'frenchUTF8': apiModel['Langage'] = 'French(Français)'; break;
                                        case 'germanUTF8': apiModel['Langage'] = 'German(Deutsch)'; break;
                                        case 'spanishUTF8': apiModel['Langage'] = 'Spanish(Español)'; break;
                                        case 'chineseUTF8': apiModel['Langage'] = 'Chinese'; break;
                                        case 'japaneseUTF8': apiModel['Langage'] = 'Japanese'; break;
                                        case 'polishUTF8': apiModel['Langage'] = 'Polish(Polski)'; break;
                                        default:
                                            apiModel['Langage'] = 'English';
                                    }
                                }
                                else
                                    apiModel['Langage'] = 'Any Language';

                                break;
                            default:
                                if (key == 'create_date_start' || key == 'create_date_end' || key == 'create_date_relative') {
                                    if (!apiModel['Create Date']) {
                                        apiModel['Create Date'] = GenerateDateModel(profileInfo['create_date_relative'], profileInfo['create_date_start'], profileInfo['create_date_end']);
                                    }
                                } else if (key == 'custom21_from' || key == 'custom21_to' || key == 'custom21_relative') {
                                    if (!apiModel['custom21']) {
                                        apiModel['custom21'] = GenerateDateModel(profileInfo['custom21_relative'], profileInfo['custom21_from'], profileInfo['custom21_to']);
                                    }
                                } else if (key == 'custom22_from' || key == 'custom22_to' || key == 'custom22_relative') {
                                    if (!apiModel['custom22']) {
                                        apiModel['custom22'] = GenerateDateModel(profileInfo['custom22_relative'], profileInfo['custom22_from'], profileInfo['custom22_to']);
                                    }
                                } else if (key == 'custom23_from' || key == 'custom23_to' || key == 'custom23_relative') {
                                    if (!apiModel['custom23']) {
                                        apiModel['custom23'] = GenerateDateModel(profileInfo['custom23_relative'], profileInfo['custom23_from'], profileInfo['custom23_to']);
                                    }
                                } else if (key == 'custom24_from' || key == 'custom24_to' || key == 'custom24_relative') {
                                    if (!apiModel['custom24']) {
                                        apiModel['custom24'] = GenerateDateModel(profileInfo['custom24_relative'], profileInfo['custom24_from'], profileInfo['custom24_to']);
                                    }
                                } else if (key == 'edit_date_start' || key == 'edit_date_end' || key == 'edit_date_relative') {
                                    if (!apiModel['Edit Date']) {
                                        apiModel['Edit Date'] = GenerateDateModel(profileInfo['edit_date_relative'], profileInfo['edit_date_start'], profileInfo['edit_date_end']);
                                    }
                                }
                                else if (key.search(/custom([1-9]|[1][0-9]|[2][0-9]|[3][0])/i) != -1) {
                                    var matches = key.match(/custom([1-9]|[1][0-9]|[2][09]|[3][0])/i);

                                    if (key != matches[0] + '_description' && key != matches[0] + '9_description' && key != matches[0] + '0_description') {

                                        if (profileInfo[matches[0] + '_description'] && key == matches[0]) {
                                            apiModel[key] = value + '-' + profileInfo[matches[0] + '_description'];
                                        } else if (profileInfo[matches[0] + '9_description'] && key == matches[0] + '9') {
                                            apiModel[key] = value + '-' + profileInfo[matches[0] + '9_description'];
                                        } else if (profileInfo[matches[0] + '0_description'] && key == matches[0] + '0') {
                                            apiModel[key] = value + '-' + profileInfo[matches[0] + '0_description'];
                                        } else {
                                            apiModel[key] = value;
                                        }
                                    }

                                }
                                else if (key != 'languageid' && key != 'content_type' && key != 'contenttype')
                                    apiModel[key] = value;
                        }
                    } catch (exp) {

                    }

                });

                return apiModel;
            }
				
            return {
                adHocFolderInitialValues: returnAdHocFolderInitialValues,
                getSecurityInitialValue: returnSecurityInitialValue,
                getAPIUrl: returnAPIUrl,
                getUserUI: returngetUserUI,
                getMetaDataUI: returnMetaUIModel,
                getFolderPostAPIModel: returnFolderPostAPIModel,
                getEmailDomain: returngetEmailDomain,
                getClassUI: returngetClassUI,
				getTypeUI: returngetTypeUI,
                getSearchGroupAPI: returnSearchGroupAPI,
                getUserPhotoAPI: returnUserPhotoAPI,
                getGroupUIModel: returnGroupUIModel,
                getSecurityAPIModel: returnSecurityAPIModel,
                getSecurityUIModel: returnSecurityUIModel,
                getFolderSecurityAPI: returnFolderSecurityAPI,
                getFolderPathAPI: returnFolderPathAPI,
                getFolderUIModel: returnFolderUIModel,
				getGroupMembersAPI: returnGroupMembersAPI,
				getDBListAPI: returnDBListAPI,
				getProfileInfoUI: returnProfileInfoUIModel
            }
        }
    });
})();