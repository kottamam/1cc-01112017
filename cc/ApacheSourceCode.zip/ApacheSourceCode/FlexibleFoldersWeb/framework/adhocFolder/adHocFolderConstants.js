﻿(function () {
    'use strict';

    angular.module('iManage').constant('API_URL_adHOC_FODLER', {
        FOLDER_SECURITY: 'api/v1/folders/<object_id>/security',
        POST_FOLDER: 'api/v1/workspaces/<workspace_id>/folders',
        GET_EMAIL_DOMAIN: 'api/v1/system/config',
        POST_TAB: 'api/v1/workspaces/<workspace_id>/folders',
		GET_FOLDER_PATH: 'api/v1/folders/<folder_id>/path',
        SEARCHMETADATA: 'api/v1/customs/{CUSTOMTYPE}/search',
        SEARCHCHILDMETADATA: 'api/v1/customs/{CUSTOMTYPE}/{PALIAS}/{CHILDCUSTOM}/search',
        GETNAMEVALUEPAIRS: 'api/v1/workspaces/{WS_ID}/name-value-pairs',
        PUTNAMEVALUEPAIRS: 'api/v1/workspaces/{WS_ID}/name-value-pairs',
        SAVENAMEVALUEPAIRS: 'api/v1/workspaces/{WS_ID}/name-value-pairs',
        POST_TABS: 'api/v1/workspaces/<workspace_id>/tabs',
        POST_SEARCH_FOLDERS: 'api/v1/workspaces/<workspace_id>/search-folders',
        DELETE_CHILDRENS: 'api/v1/folders/{FOLDER_ID}',
        PUT_FOLDER: 'api/v1/folders/{FOLDER_ID}',
        PUT_TAB: 'api/v1/tabs/{tab_id}',
        SEARCH_USERS: 'api/v1/users/search',
        SEARCH_FOLDERS: 'api/v1/folders/search',
        PUT_SEARCH_FOLDER: 'api/v1/search-folders/{SEARCH_FOLDER_ID}',
        GETSINGLESEARCHFOLDERDETAILS: 'api/v1/search-folders/{SEARCH_FOLDER_ID}',
        SEARCH_CLASS: 'api/v1/classes/search',
        SEARCH_TYPES: 'api/v1/types/search',
        SEARCH_SUBCLASS: 'api/v1/classes/{PARENTCLASS}/subclasses/search',
        GET_SINGLE_FOLDER_DETAILS: 'api/v1/folders/{FOLDER_ID}',
        DELETE_NAME_VALUE_PAIR: 'api/v1/workspaces/{WS_ID}/name-value-pairs/{name}',
		SEARCH_GROUPS: 'api/v1/groups/search?database=<dbname>&offset=<offset>&limit=<limit>&total=true&enabled=true',
        GET_USER_PHOTO: 'api/v1/users/<userid>/photo',
		GET_GROUP_USERS: 'api/v1/groups/<group_alias>/members',
		GET_DB_LIST: 'api/v1/session/databases/operations'
    });

    angular.module('iManage').constant('CONST_FOLDER', {
        Database: 'database',
        DefaultSecurity: 'default_security',
        Description: "description",
        EditDate: 'edit_date',
        Email: 'email',
        FolderType: 'folder_type',
        HasSubfolders: 'has_subfolders',
        Id: 'id',
        IsContainerSavedSearch: 'is_container_saved_search',
        IsContentSavedSearch: 'is_content_saved_search',
        IsExternalAsNormal: 'is_external_as_normal',
        IsHidden: 'is_hidden',
        Name: 'name',
        Owner: 'owner',
        ParentId: 'parent_id',
        SubType: 'subtype',
        ViewType: 'view_type',
        Wstype: 'wstype',
        ContentSavedSearchId: 'content_saved_search_id',
        Profile: 'profile',
        FP_Author: 'author',
        FP_Description: 'description',
        FP_Class: 'class',
        FP_Email: 'emails_only',
        FP_SubClass: 'subclass',
        SearchProfile: 'searchprofile',
        FP_Operator: 'operator',
        FP_DocumentNum: 'docnum',
        FP_Version: 'version',
        FP_Type: 'type',
        FP_LookFor_Anywhere: 'fulltext',
        FP_LookFor_Lang: 'languageid',
        FP_LookFor_Comments: 'comments_fulltext',
        FP_LookFor_CommentsDescription: 'comments_description_fulltext',
        FP_LookFor_Description: 'description_fulltext',
        FP_LookFor_Body: 'body',
        FP_Create_Relative: 'create_date_relative',
        FP_Create_Start: 'create_date_start',
        FP_Create_End: 'create_date_end',
        FP_Edit_Relative: 'edit_date_relative',
        FP_Edit_Start: 'edit_date_start',
        FP_Edit_End: 'edit_date_end',
        FP_DocumentsOnly: 'documents_only',
        FP_EmailsOnly: 'emails_only',
		InheritedDefaultSecurity: 'inherited_default_security'
          
        //SP_Cus21_Rrelative: 'custom21_relative',
        //SP_Cus21_From: 'custom21_from',
        //SP_Cus21_To: 'custom21_to',
        //SP_Cus22_Rrelative: 'custom22_relative',
        //SP_Cus22_From: 'custom22_from',
        //SP_Cus22_To: 'custom22_to',
        //SP_Cus23_Rrelative: 'custom23_relative',
        //SP_Cus23_From: 'custom23_from',
        //SP_Cus23_To: 'custom23_to',
        //SP_Cus24_Rrelative: 'custom24_relative',
        //SP_Cus24_From: 'custom24_from',
        //SP_Cus24_To: 'custom24_to',
    });

    angular.module('iManage').constant('CONST_SYSTEM_CONFIG', {
        //IMCC_OF_MATCHFIELDS: 'IMCC_OF_MATCHFIELDS',
        IMCC_EMAIL_DOMAIN: 'Email Domain'
    });
	
	angular.module('iManage').constant('adHOC_FODLER_CONST_USERS', {
        UserId: 'user_id',
        FullName: 'full_name',
        Email: 'email',
        UserIdEx: 'user_id_ex'
    });

    angular.module('iManage').constant('adHOC_FODLER_CONST_GROUPS', {
        GroupName: 'group_id',
        GroupFullName: 'full_name'
    });

    angular.module('iManage').constant('adHOC_FODLER_CONST_SECURITY', {
        Access: "access",
        AccessLevel: "access_level",
        Id: "id",
        Name: "name",
        SID: "sid",
        Type: "type"
    });
})();