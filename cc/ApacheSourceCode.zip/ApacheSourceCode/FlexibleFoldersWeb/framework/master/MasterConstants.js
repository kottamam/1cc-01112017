(function () {
    'use strict';

    define(['angular'], function () {
        angular.module('iManage').constant('WRSU_MASTER', {
            SAVELOG: 'imcc-api/v1/log',
            SECURITYLOG: 'imcc-api/v1/securelog',
            LOGINTYPES: 'api/v1/session/login-types',
            LOGIN_PAGE: 'api/v1/session/login-page?application_name=imcc',
			SAML_LOGIN:'api/v1/session/saml-login',
			INITDATA:'webapp/init-data'
        });
    });
})();