(function () {
    'use strict';

    require.config({
        paths: {
            MasterController: 'master/MasterController',
            MasterConstants: 'master/MasterConstants',
            MasterFactory: 'master/MasterFactory',
            MasterService: 'master/MasterService'
        },
        shim: {
            'imModule/registerView': { deps: ['general/modules/imModule', "pluggableViews"] }
        },
        bundles: {
            'master/MasterFactory': ['imModule/registerView']
        }
    });

    define([
        'MasterController',
        'MasterConstants',
        'MasterFactory',
        'MasterService',
        'imModule/registerView'
    ]);
})();