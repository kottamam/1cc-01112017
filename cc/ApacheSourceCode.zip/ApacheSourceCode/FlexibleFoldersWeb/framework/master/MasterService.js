(function () {
    'use strict';

    define(['angular'], function () {
        angular.module('iManage').service("masterService", masterService);
    });

    masterService.$inject = ['$http'];
    function masterService($http) {

        this.getlogDetails = function (URL, level, message) {
            var promise = $http({
                url: URL,
                method: "PUT",
                data: { 'Level': level, 'Message': message },
                dataType: "json"
            });
        };

        this.getData = function (URL) {
            URL = URL + (URL.indexOf('?') === -1 ? '?' : '&') + 'v=' + ((new Date()).getTime().toString());
            var promise = $http({
                url: URL,
                method: "GET"

            });
            return promise;
        };

        this.getIPAddress = function (URL) {
            var promise = $http({
                url: URL,
                method: "GET"
            });
            return promise;
        };

        this.getLoginTypes = function (URL) {
            var promise = $http({
                url: URL,
                method: "GET"
            });
            return promise;
        };

        this.getSamlLogin = function (URL) {
            var promise = $http({
                url: URL,
                method: "GET"
            });
            return promise;
        };
    }
})();