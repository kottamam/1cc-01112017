(function () {
    'use strict';

    var X2JS;

    define(['angular', 'X2JS'], function (angular, x2js) {
        X2JS = x2js;
        angular.module('iManage').factory('masterFactory', masterFactory);
    });

    masterFactory.$inject = ['$http', '$q', 'WRSU_MASTER'];
    function masterFactory($http, $q, WRSU_MASTER) {

        var sectionsObj = {}

        var returnObject = {
            masterInitailValues: returnmasterInitailValues,
            getAPIUrl: returnAPIUrl,
            getLoginTypes: returnLoginTypes,
            getLoginPageAPI: returnLoginPageAPI,
			getSamlUrl:returnSamlUrl
        };
        return returnObject;

        (function () {
            sectionsObj = {
                apiurl: '',
                imccapiurl: ''
            };
        })();

        function loadsettings() {
            var deferred = $q.defer();
            var x2js = new X2JS();
            var todayDate = (new Date()).toJSON();
            var promise = $http({
                url: "assets/content/settings.xml?v=" + todayDate,
                method: "GET",
                contentType: "application/json; charset=utf-8"
            });

            promise.then(function (response) {
                var navXml = x2js.xml_str2json(response.data);
                sectionsObj.apiurl = navXml.root.apiurl;
                sectionsObj.imccapiurl = navXml.root.imccapiurl;
                sectionsObj.hostbase = navXml.root.baseurl;
                deferred.resolve(sectionsObj);
            });
            return deferred.promise;
            //return sectionsObj;
        }

        function returnAPIUrl(APIFOR) {
            var ApiUrl = baseIMCCApiUrl + WRSU_MASTER[APIFOR];
            return ApiUrl;

        }
		
		 function returnSamlUrl() {
            var ApiUrl = baseUrl + WRSU_MASTER['SAML_LOGIN'];
            return ApiUrl;

        }

        function returnLoginTypes() {
            var ApiUrl = baseUrl + WRSU_MASTER['LOGINTYPES'];
            return ApiUrl;
        }

        function returnLoginPageAPI(isApplyTemplate, params, pageName) {
            var baseConfig = baseHost;  //.substr(1);
            if (baseConfig.charAt(0) == '/')
                baseConfig = baseHost.substr(1);

            var apiUrl = baseIMCCApiUrl + WRSU_MASTER['LOGIN_PAGE'];
			//isApplyTemplate=false;
            if (!isApplyTemplate) {
				
                apiUrl += '&csrf_protection=true&persona=admin&login_url=' + baseConfig + '/%23/login&network_login_url=' + baseConfig + '/%23/networklogin&redirect_url=/' + baseConfig + '/%23/Main_Home';
            }
            else {
                var querstring = '?';
                angular.forEach(params, function (value, key) {
                    querstring += key + "=" + value+'&';
                });
                querstring = querstring.substring(0, querstring.length - 1)

                apiUrl += '&csrf_protection=true&network_login_url=' + baseConfig + '/Applytemplate.html%23/networklogin' + encodeURIComponent(querstring) + '&login_url=' + encodeURIComponent(baseConfig + '/Applytemplate.html#/login' + querstring) + '&redirect_url=' + encodeURIComponent('/' + baseConfig + '/Applytemplate.html#/' + pageName + querstring)
            }
            return apiUrl;
        }

        function returnmasterInitailValues() {
            return loadsettings();
        }
    }
})();

(function () {
    'use strict';

    define('imModule/registerView', ['angular'], function () {
        angular.module('iManage').config(registerView);
    });

    registerView.$inject = ['$pluggableViewsProvider'];
    function registerView($pluggableViewsProvider) {
        angular.module('iManage').libInjector = $pluggableViewsProvider;
    }
})();