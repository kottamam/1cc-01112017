(function () {
    'use strict';

    define(['angular'], function () {
        angular.module('iManage').service("homeService", homeService);
    });

    homeService.$inject = ['$http'];
    function homeService($http) {

        this.getData = function (URL, key) {
            URL = URL + (URL.indexOf('?') === -1 ? '?' : '&') + 'v=' + ((new Date()).getTime().toString());
            var promise = $http({
                url: URL,
                method: "GET"
              
            });
            return promise;
        };

        this.putData = function (URL, key) {
            var promise = $http({
                url: URL,
                method: "PUT"
            });
            return promise;
        };

        this.putDataUsingBody = function (URL, key, body) {
            var response = $http({
                method: "PUT",
                url: URL,
                data: JSON.stringify(body)
            });
            return response;
        };

        this.postData = function (URL, key) {
            var response = $http({
                method: "POST",
                url: URL
            });
            return response;
        };

        this.postDataUsingBody = function (URL, key, body) {
            var response = $http({
                method: "POST",
                url: URL,
                data: JSON.stringify(body)
            });
            return response;
        };
		
		this.deleteData = function (URL, key) {
			var response = $http({
				method: "DELETE",
				url: URL
			});
			return response;
        };
		
        this.deleteDataUsingBody = function (URL, key, body) {
            var response = $http({
                method: "DELETE",
                url: URL,
                data: JSON.stringify(body)
            });
            return response;
        };

        this.patchDataUsingBody = function (URL, key, body) {
            var response = $http({
                method: "PATCH",
                url: URL,
                data: JSON.stringify(body)
            });
            return response;
        };

        this.getImageData = function (URL, key) {
            var promise = $http({
                url: URL,
                method: "GET",
                responseType: "blob"
            });
            return promise;
        };

        this.getJson = function (URL) {
            var promise = $http({
                url: URL,
                method: "GET"
            });
            return promise;
        }
    }
})();