(function () {
    'use strict';

    require.config({
        paths: {             
            HomeConstants: 'home/HomeConstants',
            HomeFactory: 'home/HomeFactory',
            HomeService: 'home/HomeService'
        }
    });

    define([       
        'HomeConstants',
        'HomeFactory',
        'HomeService'
    ]);
})();