(function() {
    'use strict';

    define(['angular'], function(angular) {
        angular.module('iManage').factory('homeFactory', homeFactory);
    });

    homeFactory.$inject = ['$http', '$q', '$state', '$filter', 'WRSU_HOME', 'CONST_HOME_CAPTIONS', 'CONST_DB', 'CONST_USERS_HOME', 'CONST_PERMISSIONS',  'homeService'];

    function homeFactory($http, $q, $state, $filter, WRSU_HOME, CONST_HOME_CAPTIONS, CONST_DB, CONST_USERS_HOME, CONST_PERMISSIONS,  homeService) {
        //Management
        var selectedAppSettings = {};
        var appsVar = {};
        var requestModelDef = {};
        var requestModelDe = {};
        var captionUIModel = {};
        var databasesUIModel = {};
        var userUIModel = {};
        var userPermissionsModel = {};
        var userAreaDef = [];

        (function() {
            userAreaDef = [{ AppTypeName: "Management", visibility: true }, { AppTypeName: "Content", visibility: true }, { AppTypeName: "System", visibility: true }];

            selectedAppSettings = {
                appType: '',
                CurrentTab: '',
                CurrentSubTab: '',
                NoAppsPermission: 'Error',
                TotalRowCount: 0,
                CurrentPageIndex: 1,
                ResponseCount: 50,
                MetaDataItem: ''
            }

            appsVar = {
                initialLoading: true,
                selectedRecordId: '',
                SearchText: '',
                CaptionsList: [],
                selectedMetaData: 'CUSTOM1',
                sortField: '',
                rightClickMenuID: '',
                tooltipValue: ''
            }

            requestModelDef = {
                libraryName: '',
                pagenumber: 1,
                pageLength: 50,
                isTotal: true,
                IsMoreRowsFound: false,
                Cursor: '',
                searchText: '',
                sortKey: '',
                sortValue: '', //,DESC
                filters: [] //[{'Key1',[{'Value1', 'Value2',etc}] },{'Key1',[{'Value1', 'Value2',etc}] }]
            }

            requestModelDe = {
                libraryName: '',
                pagenumber: 1,
                pageLength: 50,
                isTotal: true,
                IsMoreRowsFound: false,
                Cursor: '',
                searchText: '',
                sortKey: '',
                sortValue: '', //,DESC
                filters: [] //[{'Key1',[{'Value1', 'Value2',etc}] },{'Key1',[{'Value1', 'Value2',etc}] }]
            }

            captionUIModel = {
                DisplayText: '',
                MetaDataItem: '',
                isMetaItem: true,
                isallowedCreateProfile: true,
                isallowedSearchProfile: true,
                ParentMetaItem: '',
                MetaType: '',
                TagValue: 0
            };

            databasesUIModel = {
                DatabaseName: '',
                Description: '',
            };

            userUIModel = {
                UserId: '',
                FullName: '',
                Location: ''
            };

            userPermissionsModel = {
                Database: '',
                IsTier_1: false,
                IsTier_2: false,
                IsTier_3: false,
                ContentAssistance: false,
                ManageCustomMetadata: false,
                DMSJobOperations: false,
                Reporting: false,
                ReportManagement: false,
                ManageRoles: false,
                SystemJobOperations: false,
                ManageSystemMetadata: false,
                TemplateManagement: false,
                TrusteeAsistance: false,
                ManageTrustees: false,
                WebOperations: {
                    CreateSystemWorkspaces: false
                }
            }

        })();

        var returnObject = {
            selectedApp: selectedAppSettings,
            applicationVariables: appsVar,
            userArea: userAreaDef,
            requestModel: requestModelDef,
            getSections: NavigationMenu,
            requestModelInstance: returnrequestModelDef,
            getAPIUrl: returnAPIUrl,
            getCaptionUIModel: returnCaptionUIModel,
            getDatabaseUI: getDatabaseUIModel,
            registerComponent: RegisterView,
            getSingleUserAPI: returnSingleUserAPI,
            getUserUI: getUserUIModel,
            getDBListAPI: returnDBListAPI,
            getUserPhotoAPI: returnUserPhotoAPI,
            getLogoutAPI: returnLogoutAPI,
            getServerVersionAPI: returnServerVersionAPI,
            getUserPermissionModel: returnUserPermissionModel,
            getPrimaryDBNameAPI: returnPrimaryDBNameAPI
        };
        return returnObject;

        function getDatabaseUIModel(dataBaseApiModel) {
            var dbModel = angular.copy(databasesUIModel);
            dbModel.DatabaseName = dataBaseApiModel[CONST_DB.DatabaseName]; //.user_id_ex;
            dbModel.Description = dataBaseApiModel[CONST_DB.Description];
            return dbModel;
        }

        function NavigationMenu(captionsList, userLevel, permissions) {
            var settingJson = [];
            var deferredarray = [];
            var tileArray = [];
            var deferredAll = $q.defer();
            var ApiUrl = baseIMCCApiUrl + WRSU_HOME['PLUGIN_GET_FOLDERS'];
            homeService.getData(ApiUrl)
                .then(function(folderList) {
                    var folderListArray = $.map(folderList.data, function(value, index) {
                        return [value];
                    });
                    if (folderListArray.length > 0) {
                        var settingsFiles = ['framework/homeView/appSettings.json'];
                        homeService.getJson('plugin_root/registered_plugins.json').then(function(response) {
                            angular.forEach(response.data.plugin_folders, function(plugin) {
                                if ($filter('filter')(folderListArray, plugin, true).length > 0) {
                                    var hasPermission = false;
                                  
                                    if (hasPermission) {
                                        settingsFiles.push('plugin_root/' + plugin + '/appSettings.json');
                                    }
                                }
                            });
                            angular.forEach(settingsFiles, function(settings) {
                                var deferred = $q.defer();
                                var promise = $http.get(settings);
                                promise.then(function(response) {
                                    settingJson.push(response.data.section);
                                    var appSettings = response.data;
                                    var tileSettings = {};
                                    if (appSettings.section.showAsTile) {
                                        tileSettings.name = appSettings.section.name;
                                        if (appSettings.section.label) {
                                            tileSettings.label = appSettings.section.label;
                                        };
                                        if (appSettings.section.templateUrl) {
                                            tileSettings.appTarget = appSettings.section.name.replace(/ /g, '');
                                        };
                                        tileSettings.iconclass = appSettings.section.iconclass;
                                        tileSettings.order = appSettings.section.order ? appSettings.section.order : 0;
                                    } else if (appSettings.section.subsections && appSettings.section.subsections.showAsTile) {
                                        tileSettings.name = appSettings.section.subsections.name;
                                        if (appSettings.section.subsections.label) {
                                            tileSettings.label = appSettings.section.subsections.label;
                                        };
                                        if (appSettings.section.subsections.templateUrl) {
                                            tileSettings.appTarget = appSettings.section.name.replace(/ /g, '') + '_' + appSettings.section.subsections.name.replace(/ /g, '');
                                        } else if (appSettings.section.subsections.app && appSettings.section.subsections.app.templateUrl) {
                                            tileSettings.appTarget = appSettings.section.name.replace(/ /g, '') + '_' + appSettings.section.subsections.name.replace(/ /g, '') + '_' + appSettings.section.subsections.app.name.replace(/ /g, '');
                                        }
                                        tileSettings.iconclass = appSettings.section.subsections.iconclass;
                                        tileSettings.order = (appSettings.section.order ? appSettings.section.order : 0) + '_' + (appSettings.section.subsections.order ? appSettings.section.subsections.order : 0);
                                    } else if (appSettings.section.subsections && appSettings.section.subsections.app && appSettings.section.subsections.app.showAsTile) {
                                        tileSettings.name = appSettings.section.subsections.app.name;
                                        if (appSettings.section.subsections.app.label) {
                                            tileSettings.label = appSettings.section.subsections.app.label;
                                        };
                                        if (appSettings.section.subsections.app.templateUrl) {
                                            tileSettings.appTarget = appSettings.section.name.replace(/ /g, '') + '_' + appSettings.section.subsections.name.replace(/ /g, '') + '_' + appSettings.section.subsections.app.name.replace(/ /g, '');
                                        };
                                        tileSettings.iconclass = appSettings.section.subsections.app.iconclass;
                                        tileSettings.order = (appSettings.section.order ? appSettings.section.order : 0) + '_' + (appSettings.section.subsections.order ? appSettings.section.subsections.order : 0) + '_' + (appSettings.section.subsections.app.order ? appSettings.section.subsections.app.order : 0);
                                    } else if (appSettings.section.app && appSettings.section.app.showAsTile) {
                                        tileSettings.name = appSettings.section.app.name;
                                        if (appSettings.section.app.label) {
                                            tileSettings.label = appSettings.section.app.label;
                                        };
                                        if (appSettings.section.app.templateUrl) {
                                            tileSettings.appTarget = appSettings.section.name.replace(/ /g, '') + '_' + appSettings.section.app.name.replace(/ /g, '');
                                        };
                                        tileSettings.iconclass = appSettings.section.app.iconclass;
                                        tileSettings.order = (appSettings.section.order ? appSettings.section.order : 0) + '_' + (appSettings.section.app.order ? appSettings.section.app.order : 0);
                                    }
                                    if (tileSettings.name) {
                                        tileArray.push(tileSettings);
                                    }
                                    deferred.resolve(settingJson);
                                });
                                deferredarray.push(deferred.promise);
                            });

                            $q.all(deferredarray).then(function() {
                                var NavigationMenuJson = {
                                    NavigationMenu: [],
                                    TileMenu: []
                                };
                                var sectionsObj = settingJson;
                                angular.forEach(sectionsObj, function(section) {
                                    var navSettings = pushNavigationMenuObject(NavigationMenuJson.NavigationMenu, getJsonObject(section, '', '', captionsList))
                                });
                                angular.forEach(NavigationMenuJson.NavigationMenu, function(section) {
                                    var hasSubMenu = false;
                                    var hasApp = false;
                                    if (section.childMenus) {
                                        angular.forEach(section.childMenus, function(menuItem) {
                                            if (menuItem.AppsType && menuItem.AppsType == 'menu') {
                                                hasSubMenu = true;
                                            }
                                            if (menuItem.AppsType && menuItem.AppsType == 'tab') {
                                                hasApp = true;
                                            }
                                        });
                                    }
                                    if (hasSubMenu && hasApp) {
                                        var SubMenus = [];
                                        var ChildApps = [];
                                        angular.forEach(section.childMenus, function(menuItem) {
                                            if (menuItem.AppsType && menuItem.AppsType == 'menu') {
                                                SubMenus.push(menuItem);
                                                delete section.childMenus[menuItem];
                                            } else if (menuItem.AppsType && menuItem.AppsType == 'tab') {
                                                ChildApps.push(menuItem);
                                                delete section.childMenus[menuItem];
                                            }
                                        });
                                        section.AppsType = 'toggle-menu-apps';
                                        section.SubMenus = SubMenus;
                                        section.ChildApps = ChildApps;
                                    }
                                });
                                NavigationMenuJson.TileMenu = tileArray;
                                deferredAll.resolve(NavigationMenuJson);
                            });
                        });
                    }
                });
            return deferredAll.promise;
        };

        function pushNavigationMenuObject(NavigationMenuJson, settings) {
            var isParentExists = false;
            var settingsObj;
            if (NavigationMenuJson.length > 0)
                angular.forEach(NavigationMenuJson, function(appSettings) {
                    //for (var appSettingsIndex in NavigationMenuJson) {
                    //    var appSettings = NavigationMenuJson[appSettingsIndex];
                    if (appSettings.hasOwnProperty('AppsID') && appSettings.AppsID == settings.AppsID) {
                        isParentExists = true;
                        settingsObj = pushNavigationMenuObject(appSettings.childMenus, settings.childMenus[0]);
                    }
                    //}
                });
            if (!isParentExists) {
                if (settings) {
                    NavigationMenuJson.push(settings);
                }
            } else {
                if (settingsObj) {
                    NavigationMenuJson.push(settingsObj);
                }
            }
        }

        function getJsonObject(sectionobj, parentname, targetName, captionsList) {
            var obj = {};
            obj.AppsID = sectionobj.name.replace(/ /g, '');
            obj.AppsName = sectionobj.name;
            obj.Order = (sectionobj.order && sectionobj.order != '') ? sectionobj.order : 999;
            obj.Type = (sectionobj.appType && sectionobj.appType != '') ? sectionobj.appType : '';
            if (sectionobj.label) {
                obj.Label = sectionobj.label;
            }
            var url = '';
            var target = '';
            if (parentname != '') {
                url = parentname + '/' + obj.AppsName.replace(/ /g, '_');
                target = targetName + '_' + obj.AppsID;
            } else {
                url = obj.AppsName.replace(/ /g, '_');
                target = obj.AppsID;
            }

            obj.AppsIcon = sectionobj.iconclass;
            if (sectionobj.templateUrl != '' && sectionobj.templateUrl) {
                obj.AppsType = 'link';
            } else if (sectionobj.subsections && sectionobj.app) {
                obj.AppsType = 'toggle-menu';

            } else if (sectionobj.subsections && !sectionobj.app) {
                obj.AppsType = 'toggle';
            } else if (!sectionobj.subsections && sectionobj.app) {
                obj.AppsType = 'menu';
            }
            obj.AppsTarget = target;
            if (obj.AppsType == 'link' || obj.AppsType == 'toggle-menu') {
                obj.ModuleName = sectionobj.moduleName;
                obj.Controller = sectionobj.controller;
                obj.ViewUrl = (sectionobj.viewUrl && sectionobj.viewUrl != '') ? sectionobj.viewUrl : url;
                obj.TemplateUrl = (sectionobj.templateUrl && sectionobj.templateUrl != '') ? ((obj.Type == "FrameworkApp" ? "framework/" : "plugin_root/") + sectionobj.templateUrl) : '';
                var cssUrlList = [];
                if (sectionobj.cssUrl && sectionobj.cssUrl != '' && sectionobj.cssUrl != []) {
                    if (angular.isArray(sectionobj.cssUrl)) {
                        angular.forEach(sectionobj.cssUrl, function(url) {
                            cssUrlList.push((obj.Type == "FrameworkApp" ? "framework/" : "plugin_root/") + url);
                        });
                    } else if (angular.isString(sectionobj.cssUrl)) {
                        cssUrlList.push((obj.Type == "FrameworkApp" ? "framework/" : "plugin_root/") + sectionobj.cssUrl);
                    }
                }
                obj.cssUrl = cssUrlList;
                obj.RequirejsNames = sectionobj.requirejsNames;
                obj.RequirejsConfig = sectionobj.requirejsConfig;
            }

            obj.childMenus = [];

            if (sectionobj.subsections) {
                if (sectionobj.subsections.length) {
                    angular.forEach(sectionobj.subsections, function(subsection) {

                        obj.childMenus.push(getJsonObject(subsection, url, target, captionsList));
                    });
                } else {
                    obj.childMenus.push(getJsonObject(sectionobj.subsections, url, target, captionsList));
                }
            }
            if (sectionobj.app) {
                if (sectionobj.app.name == 'Metadata') {
                    angular.forEach(captionsList, function(caps) {
                        if (!caps.ParentMetaItem && caps.MetaDataItem != 'CLASS')
                            obj.childMenus.push(createCustomAppsObject(sectionobj.app, url, target, caps));
                    });
                } else {
                    obj.childMenus.push(getAppsJsonObject(sectionobj.app, url, target));
                }

            }

            if (obj.childMenus.length == 0) {
                obj.childMenus = "";
            }
            return obj;
        };

        function createCustomAppsObject(app, parentname, targetname, caption) {
            var obj = {};
            obj.AppsID = caption.MetaDataItem;
            obj.AppsName = caption.MetaDataItem;
            obj.Order = (app.order && app.order != '') ? app.order : 999;
            obj.Type = (app.appType && app.appType != '') ? app.appType : '';
            if (app.label) {
                obj.Label = app.label;
            }
            var url = '';
            var target = '';
            if (parentname != '') {
                url = parentname + '/' + obj.AppsID.replace(/ /g, '_');
                target = targetname + '_' + obj.AppsID;
            } else {
                url = obj.AppsID.replace(/ /g, '_');
                target = obj.AppsID;
            }

            obj.AppsIcon = app.iconclass;
            obj.AppsType = 'tab';
            obj.AppsTarget = target;
            obj.ModuleName = app.moduleName;
            obj.Controller = app.controller;
            obj.ViewUrl = (app.viewUrl && app.viewUrl != '') ? app.viewUrl : url;
            obj.TemplateUrl = (app.templateUrl && app.templateUrl != '') ? ((obj.Type == "FrameworkApp" ? "framework/" : "plugin_root/") + app.templateUrl) : '';
            var cssUrlList = [];
            if (app.cssUrl && app.cssUrl != '' && app.cssUrl != []) {
                if (angular.isArray(app.cssUrl)) {
                    angular.forEach(app.cssUrl, function(url) {
                        cssUrlList.push((obj.Type == "FrameworkApp" ? "framework/" : "plugin_root/") + url);
                    });
                } else if (angular.isString(app.cssUrl)) {
                    cssUrlList.push((obj.Type == "FrameworkApp" ? "framework/" : "plugin_root/") + app.cssUrl);
                }
            }
            obj.cssUrl = cssUrlList;
            obj.RequirejsNames = app.requirejsNames;
            obj.RequirejsConfig = app.requirejsConfig;

            return obj;
        };

        function getAppsJsonObject(app, parentname, targetname) {
            var obj = {};
            obj.AppsID = app.name.replace(/ /g, '');
            obj.AppsName = app.name;
            obj.Order = (app.order && app.order != '') ? app.order : 999;
            obj.Type = (app.appType && app.appType != '') ? app.appType : '';
            if (app.label) {
                obj.Label = app.label;
            }
            var url = '';
            var target = '';
            if (parentname != '') {
                url = parentname + '/' + obj.AppsName.replace(/ /g, '_');
                target = targetname + '_' + obj.AppsID;
            } else {
                url = obj.AppsName.replace(/ /g, '_');
                target = obj.AppsID;
            }

            obj.AppsIcon = app.iconclass;
            obj.AppsType = 'tab';
            obj.AppsTarget = target;
            obj.ModuleName = app.moduleName;
            obj.Controller = app.controller;
            obj.ViewUrl = (app.viewUrl && app.viewUrl != '') ? app.viewUrl : url;
            obj.TemplateUrl = (app.templateUrl && app.templateUrl != '') ? ((obj.Type == "FrameworkApp" ? "framework/" : "plugin_root/") + app.templateUrl) : '';
            var cssUrlList = [];
            if (app.cssUrl && app.cssUrl != '' && app.cssUrl != []) {
                if (angular.isArray(app.cssUrl)) {
                    angular.forEach(app.cssUrl, function(url) {
                        cssUrlList.push((obj.Type == "FrameworkApp" ? "framework/" : "plugin_root/") + url);
                    });
                } else if (angular.isString(app.cssUrl)) {
                    cssUrlList.push((obj.Type == "FrameworkApp" ? "framework/" : "plugin_root/") + app.cssUrl);
                }
            }
            obj.cssUrl = cssUrlList;
            obj.RequirejsNames = app.requirejsNames;
            obj.RequirejsConfig = app.requirejsConfig;

            return obj;

        };

        function returnrequestModelDef() {
            return angular.copy(requestModelDe);
        };

        function returnAPIUrl(APIFOR, requestModel, userId, dbName, action) {
            var ApiUrl = baseUrl + WRSU_HOME[APIFOR];
            ApiUrl = prepareUrl(ApiUrl, requestModel);
            return ApiUrl;
        };

        function prepareUrl(URL, requestModel) {
            var ApiUrl = URL + "?database=" + requestModel.libraryName + '&offset=' + ((requestModel.pagenumber - 1) * requestModel.pageLength) + '&limit=' + requestModel.pageLength + '&total=' + requestModel.isTotal + '&locale=' + requestModel[CONST_HOME_CAPTIONS.Locale];
            if (requestModel.searchText != null && requestModel.searchText != '')
                ApiUrl += '&query=*' + requestModel.searchText + '*'
            if (requestModel.filters.length > 0) {
                angular.forEach(requestModel.filters, function(filterItem) {
                    if (filterItem.FilterValues[0] != null && filterItem.FilterValues[0] != '') {
                        ApiUrl += '&' + CONST_HOME_CAPTIONS[filterItem.FilterKey + 'Filter'] + '=*' + filterItem.FilterValues[0] + '*'
                    }
                });
            }
            return ApiUrl;
        };

        function returnCaptionUIModel(captionApiModel) {
            var captionModel = angular.copy(captionUIModel)
            captionModel.DisplayText = captionApiModel[CONST_HOME_CAPTIONS.DisplayText];
            captionModel.MetaDataItem = captionApiModel[CONST_HOME_CAPTIONS.MetaDataItem].toUpperCase();
            captionModel.isMetaItem = IsMetaItem(captionApiModel.id.toUpperCase());
            captionModel.ParentMetaItem = GetParentItem(captionApiModel.id.toUpperCase());
            captionModel.Locale = (!captionApiModel[CONST_HOME_CAPTIONS.Locale]) ? 1033 : captionApiModel[CONST_HOME_CAPTIONS.Locale];
            captionModel.CaptionNum = captionApiModel[CONST_HOME_CAPTIONS.CaptionNum];
            captionModel.CaptionSS_Num = captionApiModel[CONST_HOME_CAPTIONS.CaptionSS_Num];

            return captionModel; // angular.copy(captionModel);
        };

        function IsMetaItem(item) {
            switch (item) {
                case "CUSTOM1":
                case "CUSTOM2":
                case "CUSTOM3":
                case "CUSTOM4":
                case "CUSTOM5":
                case "CUSTOM6":
                case "CUSTOM7":
                case "CUSTOM8":
                case "CUSTOM9":
                case "CUSTOM10":
                case "CUSTOM11":
                case "CUSTOM12":
                case "CUSTOM29":
                case "CUSTOM30":
                case "CLASS":
                case "SUBCLASS":
                    return true;
                default:
                    return false;
            }
        };

        function GetParentItem(item) {
            switch (item) {
                case "CUSTOM2":
                    return "CUSTOM1";
                case "CUSTOM30":
                    return "CUSTOM29";
                case "SUBCLASS":
                    return "CLASS";
                default:
                    return "";
            }

        }

        function returnSingleUserAPI(dbName, userId) {
            var apiUrl = baseUrl + WRSU_HOME['GET_USER'];
            //apiUrl += '?' + CONST_USERS_HOME.DataBase + '=' + dbName + '&' + CONST_USERS_HOME.Alias + '=' + userId;
            return apiUrl;
        }

        function getUserUIModel(userApiModel) {
            var userModel = angular.copy(userUIModel);
            userModel.UserId = userApiModel[CONST_USERS_HOME.UserIdEx]; //.user_id_ex;
            userModel.FullName = userApiModel[CONST_USERS_HOME.FullName];
            return userModel;
        }

        function returnDBListAPI() {
            var apiUrl = baseUrl + WRSU_HOME['GET_DB_LIST'];
            return apiUrl;
        }

        function returnUserPhotoAPI(userId) {
            var apiUrl = baseUrl + WRSU_HOME['GET_USER_PHOTO'];
            apiUrl = apiUrl.replace("<userid>", userId);
            return apiUrl;
        }

        function returnServerVersionAPI() {
            var apiUrl = baseUrl + WRSU_HOME['GET_SERVER_VERSION'];
            return apiUrl;
        }

        function RegisterView(settings) {
            if (!$state.get('home.' + settings.AppsTarget)) {
                angular.module('iManage').libInjector.registerView({
                    ID: settings.AppsTarget,
                    moduleName: settings.ModuleName,
                    controller: settings.Controller,
                    viewUrl: settings.ViewUrl,
                    templateUrl: settings.TemplateUrl,
                    requirejsNames: settings.RequirejsNames,
                    requirejsConfig: settings.RequirejsConfig,
                    cssUrl: settings.cssUrl
                });
            }
        }

        function returnLogoutAPI(authToken) {
            var apiUrl = baseUrl + WRSU_HOME['LOGOUT_USER'];
            apiUrl = apiUrl.replace("<authtocken>", authToken);
            return apiUrl;
        }

        function returnUserPermissionModel(permissions) {
            var permission = angular.copy(userPermissionsModel);
            permission.Database = permissions[CONST_PERMISSIONS.Database];
            if (permissions.m4_bits) {
                permission.IsTier_1 = permissions.m4_bits[CONST_PERMISSIONS.IsTier_1];
                permission.IsTier_2 = permissions.m4_bits[CONST_PERMISSIONS.IsTier_2];
                permission.IsTier_3 = permissions.m4_bits[CONST_PERMISSIONS.IsTier_3];
                permission.ContentAssistance = permissions.m4_bits[CONST_PERMISSIONS.ContentAssistance];
                permission.ManageCustomMetadata = permissions.m4_bits[CONST_PERMISSIONS.ManageCustomMetadata];
                permission.DMSJobOperations = permissions.m4_bits[CONST_PERMISSIONS.DMSJobOperations];
                permission.Reporting = permissions.m4_bits[CONST_PERMISSIONS.Reporting];
                permission.ReportManagement = permissions.m4_bits[CONST_PERMISSIONS.ReportManagement];
                permission.ManageRoles = permissions.m4_bits[CONST_PERMISSIONS.ManageRoles];
                permission.SystemJobOperations = permissions.m4_bits[CONST_PERMISSIONS.SystemJobOperations];
                permission.ManageSystemMetadata = permissions.m4_bits[CONST_PERMISSIONS.ManageSystemMetadata];
                permission.TemplateManagement = permissions.m4_bits[CONST_PERMISSIONS.TemplateManagement];
                permission.TrusteeAsistance = permissions.m4_bits[CONST_PERMISSIONS.TrusteeAsistance];
                permission.ManageTrustees = permissions.m4_bits[CONST_PERMISSIONS.ManageTrustees];
            }
            if (permissions.m3_bits) {
                permission.WebOperations.CreateSystemWorkspaces = permissions.m3_bits[CONST_PERMISSIONS.CreateSystemWorkspaces];
            }
            return permission;
        }

        function returnPrimaryDBNameAPI() {
            var apiUrl = baseUrl + WRSU_HOME['GET_PRIMARY_DBNAME'];
            return apiUrl;
        }
    };
})();