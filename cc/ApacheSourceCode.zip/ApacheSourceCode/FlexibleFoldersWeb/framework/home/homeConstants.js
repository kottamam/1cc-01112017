(function() {
    'use strict';

    define(['angular'], function() {
        angular.module('iManage').constant('WRSU_HOME', {
            SEARCHCAPTIONS: 'api/v1/captions/search',
            GET_USER: 'api/v1/users/me',
            GET_DB_LIST: 'api/v1/session/databases/operations',
            GET_PRIMARY_DBNAME: 'api/v1/system/config?include_databases=true',
            GET_USER_PHOTO: 'api/v1/users/<userid>/photo',
            LOGOUT_USER: 'api/v1/session/logout', //?X-Auth-Token=<authtocken>'
            GET_SERVER_VERSION: 'api/v1/system/config',
            PLUGIN_READ_FILES: 'imcc-api/v1/plugin/readfile',
            PLUGIN_GET_FOLDERS: 'imcc-api/v1/plugin/folders',
            PLUGIN_WRITE_FILES: 'imcc-api/v1/plugin/writefile',
            GET_USER_PERMISSIONS: 'admin-api/v1/roles/search'
        });

        angular.module('iManage').constant('CONST_HOME_CAPTIONS', {
            MetaDataItem: 'id',
            MetaDataItemFilter: 'alias',
            Locale: 'locale',
            CaptionType: 'type',
            CaptionTypeFilter: 'type',
            DisplayText: 'label',
            DisplayTextFilter: 'label',
            DataBase: 'database',
            CaptionNum: 'num',
            CaptionSS_Num: 'ss_num'
        });

        angular.module('iManage').constant('CONST_DB', {
            DatabaseName: 'database',
            Description: 'description'
        });

        angular.module('iManage').constant('CONST_PERMISSIONS', {
            Database: 'database',
            IsTier_1: 'admin_tier_1',
            IsTier_2: 'admin_tier_2',
            IsTier_3: 'admin_tier_3',
            ContentAssistance: 'content_assistance',
            ManageCustomMetadata: 'custom_metadata_management',
            DMSJobOperations: 'dms_job_perations',
            Reporting: 'report',
            ReportManagement: 'report_management',
            ManageRoles: 'role_management',
            SystemJobOperations: 'system_job_operations',
            ManageSystemMetadata: 'system_metadata_management',
            TemplateManagement: 'template_creation',
            TrusteeAsistance: 'trustee_asistance',
            ManageTrustees: 'trustee_management',
            CreateSystemWorkspaces: 'create_template'
        });

        angular.module('iManage').constant('CONST_USERS_HOME', {
            UserId: 'user_id',
            FullName: 'full_name',
            Alias: 'alias',
            DataBase: 'database',
            UserIdEx: 'userid'
        });
    });
})();