(function () {
    'use strict';

    define(['angular'], function () {
        angular.module('iManage').constant('WRSU_LOGIN', {
            GETGROUPSOFUSERFROMGROUPS: 'api/v1/groups/<alias>/members?database=<dbName>&alias=<userId>'
            
        });
    });
})();