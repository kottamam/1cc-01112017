(function () {
    'use strict';

    var X2JS;

    define(['angular', 'X2JS'], function (angular, x2js) {
        X2JS = x2js;
        angular.module('iManage').factory('loginFactory', loginFactory);
    });

    loginFactory.$inject = ['$http', '$q', 'homeService', 'homeFactory', 'WRSU_LOGIN'];
    function loginFactory($http, $q, homeService, homeFactory, WRSU_LOGIN) {

        var returnObject = {
            getpremittedUser: premittedUser
        }
        return returnObject;

        function loadsettings() {
            var deferred = $q.defer();
            var x2js = new X2JS();
            var todayDate = (new Date()).toJSON();
            var promise = $http.get("assets/content/settings.xml?v=" + todayDate)

            promise.then(function (response) {
                var navXml = x2js.xml_str2json(response.data);
                var sectionsObj = navXml.root.groupprefix;
                deferred.resolve(sectionsObj);
            });
            return deferred.promise;
        }

        function premittedUser(loginmodel, dbName) {
            var deferred = $q.defer();
            //var x2js = new X2JS();

            var api = getAPIUrl('GETGROUPSOFUSERFROMGROUPS', ['NRTADMIN'], loginmodel.UserName, dbName);
            var promiseOne = homeService.getData(api, loginmodel.AuthKey)
            promiseOne.then(function (responsegroups) {
                deferred.resolve(responsegroups.data.data);
            });



            //var apiUrl = homeFactory.getDBListAPI();
            //var promise = homeService.getData(apiUrl, loginmodel.AuthKey);
            //promise.then(function (responsedb) {

            //    if (responsedb && responsedb.data && responsedb.data.data && responsedb["data"]["data"].length) {
            //        angular.forEach(responsedb["data"]["data"], function (db) {
            //            var dbname = db.database;


            //        });
            //    } else {
            //        deferred.resolve();
            //    }
            //});
            return deferred.promise;
        }

        function getAPIUrl(APIFOR, requestModel, userId, dbName, action) {
            var ApiUrl = '';
            ApiUrl = baseUrl + WRSU_LOGIN[APIFOR];

            if (APIFOR == 'GETGROUPSOFUSERFROMGROUPS') {
                ApiUrl = prepareUrlGroupsOfUser(ApiUrl, requestModel, userId, dbName);

            }
            return ApiUrl;
        };

        function prepareUrlGroupsOfUser(URL, groups, User, dbName) {
            var apiUrl = URL.replace("<userId>", User);
            apiUrl = apiUrl.replace("<dbName>", dbName);

            var aliasString = '';
            if (groups.length > 0) {
                angular.forEach(groups, function (grp) {
                    if (aliasString.trim().length > 0) {
                        aliasString += ',';
                    }
                    aliasString += grp;
                });
            }
            apiUrl = apiUrl.replace("<alias>", aliasString);
            return apiUrl;
        }

    };
})();