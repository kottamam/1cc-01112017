(function () {
    'use strict';

    define(['angular'], function () {
        angular.module('iManage').service("loginService", loginService);
    });

    loginService.$inject = ['$http'];
    function loginService($http) {
        this.validateUser = function (loginmodel) {
            var bodydata = { 'user_id': loginmodel.UserName, 'password': loginmodel.Password, 'application_name': loginmodel.ApplicationName };               
            if (loginmodel.Personal) {
                bodydata = { 'user_id': loginmodel.UserName, 'password': loginmodel.Password, 'application_name': loginmodel.ApplicationName, "persona": "admin" };
            }
            var promise = $http({
                url: baseUrl + (loginmodel.networklogin ? 'api/v1/session/network-login' : 'api/v1/session/login') +'?csrf_protection=true',
                method: "PUT",
                data:bodydata,
                dataType: "json"
            });
            return promise;
        }

        this.logOutUser = function (authToken) {
            var apiUrl = baseUrl + 'api/v1/session/logout?X-Auth-Token=' + authToken;
            var promise = $http({
                url: apiUrl,
                method: "GET"
               
            });
            return promise;
        };
    }
})();