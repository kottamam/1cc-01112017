(function () {
    'use strict';

    require.config({
        paths: {
            LoginConstants: 'login/LoginConstants',
            LoginFactory: 'login/LoginFactory',
            LoginService: 'login/LoginService'
        }
    });

    define([
        'LoginConstants',
        'LoginFactory',
        'LoginService'
    ]);
})();