require.config({
    paths: {
        jquery: "../lib/vendor/jquery/dist/jquery.min",
        angular: "../lib/vendor/angular/angular.min",
        libraryConfig: '../lib/config',
        iManageGeneralConfig: 'general/config',
        pluggableViews: "pluggableViewsProvider",
        iManageMasterConfig: 'master/config',
        iManageHomeConfig: 'home/applyconfig',
        iManageLoginConfig: 'login/config',
        iManageApplyTemplateConfig: 'applyTemplate/config',
        iManageadHocFolderConfig: 'adhocFolder/config'
    },
    shim: {
        angular: { exports: 'angular', deps: ['jquery'] },
        jquery: { exports: '$' },
        iManageGeneralConfig: { deps: ["libraryConfig"] },
        pluggableViews: { deps: ["iManageGeneralConfig", "general/modules/imModule"] },
        iManageMasterConfig: { deps: ["iManageGeneralConfig"] },
        iManageHomeConfig: { deps: ["iManageMasterConfig"] },
        iManageLoginConfig: { deps: ["iManageHomeConfig"] },
        iManageApplyTemplateConfig: { deps: ["iManageHomeConfig"] },
        iManageadHocFolderConfig: { deps: ["iManageApplyTemplateConfig"] }
    },
    urlArgs: "bust=" + (new Date()).getTime(),
    waitSeconds: 0 
});

require([
        'angular',
        'libraryConfig',
        'iManageGeneralConfig',
        'pluggableViews',
        'iManageMasterConfig',
        'iManageHomeConfig',
        'iManageLoginConfig',
        'iManageApplyTemplateConfig',
        'iManageadHocFolderConfig'
], function (angular) {
    angular.element(document).ready(function () {
        angular.bootstrap(document, ['iManage']);
    });
}
);