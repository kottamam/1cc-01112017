//General configuration
(function () {
    'use strict';

    require.config({
        paths: {
            iManageGeneralApp: 'general/app'
        },
        bundles: {
            iManageGeneralApp: ['iManageModules', 'iManageConstants', 'iManageFilters', 'iManageDirectives', 'iManageRoutes']
        }
    });

    require([
        'iManageGeneralApp',
        'iManageModules',
        'iManageConstants',
        'iManageFilters',
        'iManageDirectives',
        'iManageRoutes',
    ]);
})();

//Module configuration
(function () {
    'use strict';

    require.config({
        shim: {
            'general/modules/imModule/themingConfig': { deps: ['general/modules/imModule'] },
            'general/modules/imModule/sessionTimeoutInterceptor': { deps: ['general/modules/imModule', 'iManageGeneralApp'] },
            'general/modules/imModule/httpProviderConfig': { deps: ['general/modules/imModule/sessionTimeoutInterceptor'] },
            'general/modules/imModule/stateChange': { deps: ['general/modules/imModule'] },
            'general/modules/imModule/setXSRFToken': { deps: ['general/modules/imModule'] },
            'general/modules/imModule/SetXAuthTocken': { deps: ['general/modules/imModule'] },
            'general/modules/imModule/SetXEnforceRoles': { deps: ['general/modules/imModule'] }
        },
        bundles: {
            'general/modules/imModule': ['general/modules/imModule/themingConfig', 'general/modules/imModule/sessionTimeoutInterceptor', 'general/modules/imModule/httpProviderConfig',
                                        'general/modules/imModule/stateChange', 'general/modules/imModule/setXSRFToken', 'general/modules/imModule/SetXAuthTocken',
                                        'general/modules/imModule/SetXEnforceRoles']
        }
    });

    define('iManageModules', [
        'general/modules/imModule',
        'general/modules/imModule/themingConfig',
        'general/modules/imModule/sessionTimeoutInterceptor',
        'general/modules/imModule/httpProviderConfig',
        'general/modules/imModule/stateChange',
        'general/modules/imModule/setXSRFToken',
        'general/modules/imModule/SetXAuthTocken', 'general/modules/imModule/SetXEnforceRoles']);
})();

//Constants configuration
(function () {
    'use strict';

    require.config({
        shim: {
            'general/constants/generalConstants': { deps: ["iManageModules"] }
        }
    });

    define('iManageConstants',[
        'general/constants/generalConstants'
    ]);
})();

//Custom filter configuration
(function () {
    'use strict';

    require.config({
        shim: {
            'general/filters/customFilters': { deps: ["iManageModules"] },
            'customFilter/nospace': { deps: ['general/filters/customFilters'] },
            'customFilter/humanizeDoc': { deps: ['general/filters/customFilters'] }
        },
        bundles: {
            'general/filters/customFilters': ['customFilter/nospace', 'customFilter/humanizeDoc']
        }
    });

    define('iManageFilters',[
        'general/filters/customFilters',
        'customFilter/nospace',
        'customFilter/humanizeDoc'
    ]);
})();

//Directive configuration
(function () {
    'use strict';

    require.config({
        paths: {
            homeDirective: "general/directives/homeDirective" 
        },
        shim: {
            homeDirective: { deps: ["iManageModules"] },
            'iManageDirectives/whenScrolled': { deps: ['homeDirective'] },
            'iManageDirectives/onDatatableScroll': { deps: ['homeDirective'] },
            'iManageDirectives/onSelectPickerRenderComplete': { deps: ['homeDirective'] },
            'iManageDirectives/onDatatableRenderComplete': { deps: ['homeDirective'] },
            'iManageDirectives/onStaticTableRenderComplete': { deps: ['homeDirective'] },
            'iManageDirectives/onDbListRenderComplete': { deps: ['homeDirective'] },
            'iManageDirectives/selectPickerRender': { deps: ['homeDirective'] },
            'iManageDirectives/onEditClick': { deps: ['homeDirective'] },
            'iManageDirectives/toogleAddClassNavTab': { deps: ['homeDirective'] },
            'iManageDirectives/toogleAddRoleNavTab': { deps: ['homeDirective'] },
            'iManageDirectives/numericSpinner': { deps: ['homeDirective'] },
            'iManageDirectives/onSecTemplatePermissionTableRender': { deps: ['homeDirective'] },
            'iManageDirectives/rowModifier': { deps: ['homeDirective'] },
            'iManageDirectives/tablePagination': { deps: ['homeDirective'] },
            'iManageDirectives/toogleAddRolesNavTab': { deps: ['homeDirective'] },
            'iManageDirectives/toogleAddRolesPriTab': { deps: ['homeDirective'] },
            'iManageDirectives/capitalize': { deps: ['homeDirective'] },
            'iManageDirectives/sortableColumn': { deps: ['homeDirective'] },
            'iManageDirectives/filterColumn': { deps: ['homeDirective'] },
            'iManageDirectives/contextMenu': { deps: ['homeDirective'] },
            'iManageDirectives/popOver': { deps: ['homeDirective'] },
            'iManageDirectives/ngFiles': { deps: ['homeDirective'] },
            'iManageDirectives/changeValue': { deps: ['homeDirective'] },
            'iManageDirectives/passwordCharView': { deps: ['homeDirective'] },
            'iManageDirectives/tableFilter': { deps: ['homeDirective'] },
            'iManageDirectives/tableWrapper': { deps: ['homeDirective'] },
            'iManageDirectives/filterTextbox': { deps: ['homeDirective', 'iManageDirectives/tableFilter'] },
            'iManageDirectives/filterCombobox': { deps: ['homeDirective', 'iManageDirectives/tableFilter'] },
            'iManageDirectives/responsiveTabs': { deps: ['homeDirective'] },
            'iManageDirectives/selectRows': { deps: ['homeDirective'] },
            'iManageDirectives/setFocus': { deps: ['homeDirective'] },
            'iManageDirectives/setDialogFocus': { deps: ['homeDirective'] },
            'iManageDirectives/clearAutoFocus': { deps: ['homeDirective'] },
            'iManageDirectives/toolTip': { deps: ['homeDirective'] },
            'iManageDirectives/fixTitle': { deps: ['homeDirective'] },
            'iManageDirectives/myEnter': { deps: ['homeDirective'] } 
        },
        bundles: {
            homeDirective: ['iManageDirectives/whenScrolled', 'iManageDirectives/onDatatableScroll', 'iManageDirectives/onSelectPickerRenderComplete', 'iManageDirectives/onDatatableRenderComplete', 'iManageDirectives/onStaticTableRenderComplete',
                                                            'iManageDirectives/onDbListRenderComplete', 'iManageDirectives/selectPickerRender', 'iManageDirectives/onEditClick', 'iManageDirectives/toogleAddClassNavTab', 'iManageDirectives/toogleAddRoleNavTab', 'iManageDirectives/numericSpinner',
                                                            'iManageDirectives/onSecTemplatePermissionTableRender', 'iManageDirectives/rowModifier', 'iManageDirectives/tablePagination', 'iManageDirectives/toogleAddRolesNavTab', 'iManageDirectives/toogleAddRolesPriTab',
                                                            'iManageDirectives/capitalize', 'iManageDirectives/sortableColumn', 'iManageDirectives/filterColumn', 'iManageDirectives/contextMenu', 'iManageDirectives/popOver', 'iManageDirectives/ngFiles', 'iManageDirectives/changeValue',
                                                            'iManageDirectives/passwordCharView', 'iManageDirectives/tableFilter', 'iManageDirectives/tableWrapper', 'iManageDirectives/filterTextbox', 'iManageDirectives/filterCombobox', 'iManageDirectives/responsiveTabs',
                                                            'iManageDirectives/selectRows', 'iManageDirectives/setFocus', 'iManageDirectives/setDialogFocus', 'iManageDirectives/clearAutoFocus', 'iManageDirectives/toolTip', 'iManageDirectives/fixTitle', 'iManageDirectives/myEnter']
        }
    });

    define('iManageDirectives', [
        'homeDirective',
        'iManageDirectives/whenScrolled',
        'iManageDirectives/onDatatableScroll',
        'iManageDirectives/onSelectPickerRenderComplete',
        'iManageDirectives/onDatatableRenderComplete',
        'iManageDirectives/onStaticTableRenderComplete',
        'iManageDirectives/onDbListRenderComplete',
        'iManageDirectives/selectPickerRender',
        'iManageDirectives/onEditClick',
        'iManageDirectives/toogleAddClassNavTab',
        'iManageDirectives/toogleAddRoleNavTab',
        'iManageDirectives/numericSpinner',
        'iManageDirectives/onSecTemplatePermissionTableRender',
        'iManageDirectives/rowModifier',
        'iManageDirectives/tablePagination',
        'iManageDirectives/toogleAddRolesNavTab',
        'iManageDirectives/toogleAddRolesPriTab',
        'iManageDirectives/capitalize',
        'iManageDirectives/sortableColumn',
        'iManageDirectives/filterColumn',
        'iManageDirectives/contextMenu',
        'iManageDirectives/popOver',
        'iManageDirectives/ngFiles',
        'iManageDirectives/changeValue',
        'iManageDirectives/passwordCharView',
        'iManageDirectives/tableFilter',
        'iManageDirectives/tableWrapper',
        'iManageDirectives/filterTextbox',
        'iManageDirectives/filterCombobox',
        'iManageDirectives/responsiveTabs',
        'iManageDirectives/selectRows',
        'iManageDirectives/setFocus',
        'iManageDirectives/setDialogFocus',
        'iManageDirectives/clearAutoFocus',
        'iManageDirectives/toolTip',
        'iManageDirectives/fixTitle',
        'iManageDirectives/myEnter'
    ]);
})();

//Route configuration
(function () {
    'use strict';

    require.config({
        shim: {
            'general/routes/homeRoute': { deps: ["iManageModules"] }
        }
    });

    define('iManageRoutes',[
        'general/routes/homeRoute'
    ]);
})();