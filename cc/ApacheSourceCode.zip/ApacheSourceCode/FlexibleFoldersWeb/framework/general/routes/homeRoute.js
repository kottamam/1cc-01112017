(function () {
    'use strict';

    define(['angular'], function () {
        // Declare app level module which depends on filters, and services
        angular.module('iManage').config(homeRoute);
    });

    homeRoute.$inject = ['$stateProvider', '$urlRouterProvider', '$logProvider'];
    function homeRoute($stateProvider, $urlRouterProvider, $logProvider) {
        //$locationProvider.html5Mode(true)
        $urlRouterProvider.otherwise("/");

        $stateProvider
        .state('login', {
            url: '/login?dbname&type&level&id&server&userid&protocol',
            templateUrl: ((window.location.pathname).toLowerCase().indexOf('networklogin') > 0) ? 'framework/applyTemplate/ApplyNetworkLogin.html' :  'framework/applyTemplate/ApplyTemplateLogin.html'
           
        }).state('networklogin', {
            url: '/networklogin?dbname&type&level&id&server&userid&protocol',
            templateUrl: 'framework/applyTemplate/ApplyNetworkLogin.html'
        })
        .state('applyhome', {
            url: '/ApplyTemplates',
            templateUrl: 'framework/applytemplate/Header.html',
            controller: 'ApplyController as vmApply',
        })
        .state('applyhome.ApplyTemplates', {
            url: '/Apply?dbname&type&level&id&server&userid&protocol',
            views: {
                'content@applyhome': {
                    templateUrl: 'framework/applytemplate/Applytemplate.html'
                }
            }
        }).state('adhocFolders', {
                url: '/adhocfolders',
                templateUrl: 'framework/adhocFolder/Header.html',
                controller: 'adHocFolderController as vmadHocFolder',
            })
        .state('adhocFolders.Create', {
            url: '/Create?type&parentid&protocol',
            views: {
                'content@adhocFolders': {
                    templateUrl: 'framework/adhocFolder/CreateFolder.html'
                }
            }
        }).state('applyhome.ObjectProperties', {
                url: '/Properties?dbname&type&level&id&server&userid&protocol',
                 views: {
                     'content@applyhome': {
                         templateUrl: 'framework/applytemplate/Properties.html'
                     }
                 }
             })
        .state('home.management', {
            url: 'management',
            abstract: true
        })
    };
})();
