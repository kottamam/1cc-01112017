(function () {
    'use strict';

    define(['angular'], function () {
        angular.module('iManage').constant('FRAMEWORK_PATHS', {
            DIRECTIVE_TEMPLATES: 'framework/general/directives/directiveTemplates/',
            APP_ROOT: 'plugin_root/'
        });

      
    });
})();