var baseUrl = '';
var baseIMCCApiUrl = '';
var baseHost = '';
var UserSessionTimer = null;
var sessionTime = 1000 * 60 * 60 * 4;
var cookieExpiary = new Date();

function updateCookieExpiary(maxage) {
    cookieExpiary = new Date();
    var time = cookieExpiary.getTime();
    if (maxage)
        time += maxage*1000;
    else
        time += sessionTime;
    cookieExpiary.setTime(time);
    return cookieExpiary;
}

//var eventMethod = window.addEventListener ? "addEventListener" : "attachEvent";
//var eventer = window[eventMethod];
//var messageEvent = eventMethod == "attachEvent" ? "onmessage" : "message";

//// Listen to message from child window
//eventer(messageEvent, function (e) {
//    var key = e.message ? "message" : "data";
//    var data = e[key];
//    alert(JSON.stringify(e));
//    //run function//
//}, false);


