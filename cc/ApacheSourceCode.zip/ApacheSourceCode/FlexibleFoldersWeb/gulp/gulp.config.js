
module.exports = {

    //gulp logLevel
    debug: true,
    releaseBuild: true,
    build_dir: 'build',
    core_files_html: './*.html',
    app_files: {
        assets: [
            './assets/**/*',
            '!./assets/**/*.css'
        ],
        app_js: [
            './framework/**/*.js'
        ],
        app_html: [
            './framework/**/*.html'
        ],
        app_styles: [
            './framework/**/*.css',
            './framework/**/*.scss'
        ],
        app_asset: [
            './plugin_root/**/*.jpg',
            './plugin_root/**/*.png',
            './plugin_root/**/*.gif',
            './plugin_root/**/*.ico',
            './plugin_root/**/*.svg',
            './plugin_root/**/*.pk'
        ]
    }
}
