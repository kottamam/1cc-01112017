import compileall
import os
import shutil
import stat


def handle_delete_errors(func, path, exc_info):
    os.chmod(path, stat.S_IWRITE)
    os.unlink(path)


def delete_dir(path):
    if os.path.isdir(path):
        print "> Deleting " + path
        shutil.rmtree(path, onerror=handle_delete_errors)


if __name__ == '__main__':
    # cd to this directory to use relative paths
    abspath = os.path.abspath(__file__)
    dname = os.path.dirname(abspath)
    os.chdir(dname)

    # Clean dist folder
    delete_dir("dist")

    # copy app to dist/app
    print "> Copying app"
    src_dir = os.path.join("dist", "src", "imccapi")
    shutil.copytree("PythonFiles", src_dir)

    # compile .py to .pyc in dist/src/app
    print "> Compiling *.py"
    compileall.compile_dir(src_dir)

    # copy .pyc files to dist/obj/app
    print "> Copying *.pyc"
    obj_dir = os.path.join("dist", "obj", "imccapi")
    shutil.copytree(src_dir, obj_dir, ignore=shutil.ignore_patterns('*.py'))

    # zip all compiled files
    print "> Building archive imccapi.zip"
    zip_path = os.path.join("dist", "imccapi")
    zip_root_dir = os.path.join("dist", "obj")
    shutil.make_archive(zip_path, "zip", zip_root_dir)
