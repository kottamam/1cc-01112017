from . import imcc_api
from .. import imcc
from ctypes import c_char_p, create_string_buffer, c_int, byref
from flask import request, jsonify, g
from werkzeug.utils import secure_filename
import json
import os
from os.path import basename

import zipfile
BUFFER_SIZE = 1048576

@imcc_api.route('/plugin/encryptfile', methods=['POST'])
def EncryptFile():
    #try:

      basepath = os.path.join( os.environ["WORKSITE_HOME"],"web_module","iManageControlCenter","plugin_root") 
      filename = request.args.get('filepath', '')
      if not filename:
          return '',400
      
      fullpath = os.path.join(basepath,filename)

      encryptedFileName = os.path.splitext(os.path.basename(fullpath))[0] + "_encrypted" + os.path.splitext(filename)[1];

      fullecncryptedPath = os.path.join(os.path.dirname(fullpath),encryptedFileName)

      #call c function to encrypt here
      ret  = imcc.EDF(c_char_p(fullpath), c_char_p(fullecncryptedPath)) 
      #replace contents of fullpath with fEncryptedPath
      if(ret  == 0):
          os.remove(fullpath)
          os.rename(fullecncryptedPath,fullpath)
          return 'Success',200
      else:
          if(os.path.exists(fullecncryptedPath)):
              os.remove(fullecncryptedPath)
          return 'Internal Server Error',500
          
      
              
       
    #except:
        #return 'Internal Server Error',500
