// AppEncryptor.cpp : Defines the exported functions for the DLL application.
//

#include "stdafx.h"
#include "AppEncryptor.h"
#include "CryptoApi.h"
#include <string.h>
#include <Shlwapi.h>

#include <string.h>
#include "libjson\libjson.h"


TCHAR * DecryptInFile(const char* szInFile);



BOOL  GetDecFolderModuleproductKey(char * decryptedStringCopy, char *folder, char * moduleName, char *productKey);
char*  GetActualPhysicalFolder(char * szInFile);
BOOL VerifyModuleNameLicenseKeyinSettingsJson(char *moduleName, const char* szAppSettingsJson, char* productKey);

const char password[21] = "BCvb7uZyZp7wMkjnuLV9";
extern "C" APPENCRYPTOR_API  int EDF(const char* szInFile, const char* szOutFile)
{
	HANDLE hInFile = INVALID_HANDLE_VALUE;
	HANDLE hOutFile = INVALID_HANDLE_VALUE;
	BYTE* pbInFileContents = NULL;
	try
	{
		if ((hInFile = CreateFile(

			szInFile,

			GENERIC_READ,

			0,

			NULL,

			OPEN_ALWAYS,

			FILE_ATTRIBUTE_NORMAL,

			NULL

			)) == INVALID_HANDLE_VALUE)
			return 1;

		DWORD dwInFileLen = 0;
		if ((dwInFileLen = GetFileSize(hInFile, NULL)) == INVALID_FILE_SIZE)
		{
			if (hInFile != INVALID_HANDLE_VALUE)
			{
				CloseHandle(hInFile);
				hInFile = INVALID_HANDLE_VALUE;
			}
			return 1;
		}




		// Create a buffer for the public key



		if (!(pbInFileContents = (BYTE *)malloc(dwInFileLen)))

		{

			if (hInFile != INVALID_HANDLE_VALUE)
			{
				CloseHandle(hInFile);
				hInFile = INVALID_HANDLE_VALUE;
			}
			return 1;

		}


		// Read public key



		if (!ReadFile(hInFile, pbInFileContents, dwInFileLen, &dwInFileLen, NULL))

		{
			if (hInFile != INVALID_HANDLE_VALUE)
			{
				CloseHandle(hInFile);
				hInFile = INVALID_HANDLE_VALUE;
			}
			/*if (pbInFileContents != NULL)
			{
			free(pbInFileContents);
			pbInFileContents = NULL;
			}*/
			return 1;
		}
		CryptoApi crypt;
		crypt.Init(password);
		DWORD lengthEncrypted;
		pbInFileContents[dwInFileLen] = '\0';


		if (!crypt.EnCrypt(pbInFileContents, lengthEncrypted))
		{
			if (hInFile != INVALID_HANDLE_VALUE)
			{
				CloseHandle(hInFile);
				hInFile = INVALID_HANDLE_VALUE;
			}
			if (pbInFileContents != NULL)
			{
				free(pbInFileContents);
				pbInFileContents = NULL;
			}
			return 1;
		}

		if (hInFile != INVALID_HANDLE_VALUE)
		{
			CloseHandle(hInFile);


			hInFile = INVALID_HANDLE_VALUE;
		}


		if ((hOutFile = CreateFile(

			szOutFile,

			GENERIC_WRITE,

			0,

			NULL,

			CREATE_ALWAYS,

			FILE_ATTRIBUTE_NORMAL,

			NULL

			)) == INVALID_HANDLE_VALUE)
		{
			/*if (pbInFileContents != NULL)
			{
			free(pbInFileContents);
			pbInFileContents = NULL;
			}*/
			return 1;
		}
		DWORD lpNumberOfBytesWritten = 0;
		if (!WriteFile(

			hOutFile,

			(LPCVOID)pbInFileContents,

			lengthEncrypted,

			&lpNumberOfBytesWritten,

			NULL

			))
		{
			if (hOutFile != INVALID_HANDLE_VALUE)
			{
				CloseHandle(hOutFile);
				hOutFile = INVALID_HANDLE_VALUE;
			}
			/*	if (pbInFileContents != NULL)
			{
			free(pbInFileContents);
			pbInFileContents = NULL;
			}*/
			return 1;
		}

		if (hOutFile != INVALID_HANDLE_VALUE)
		{
			CloseHandle(hOutFile);
			hOutFile = INVALID_HANDLE_VALUE;
		}

		if (hInFile != INVALID_HANDLE_VALUE)
		{
			CloseHandle(hInFile);
			hInFile = INVALID_HANDLE_VALUE;
		}
		/*if (pbInFileContents != NULL)
		{
		free(pbInFileContents);
		pbInFileContents = NULL;
		}*/
	}
	catch (...)
	{
		int i = 0;
	}
	if (hOutFile != INVALID_HANDLE_VALUE)
	{
		CloseHandle(hOutFile);
		hOutFile = INVALID_HANDLE_VALUE;
	}
	//if (pbInFileContents != NULL)
	//{
	//	free(pbInFileContents);
	//	pbInFileContents = NULL;
	//}
	return 0;
}
extern "C" APPENCRYPTOR_API  int DFCF(const char* szInFile, const char* szAppSettingsJson)
{
	TCHAR* pDecryptedString = DecryptInFile(szInFile);




	if (pDecryptedString != NULL && strlen(pDecryptedString) > 0)
	{

		char* decryptedStringCopy = new char[strlen(pDecryptedString) + 1];
		strcpy(decryptedStringCopy, pDecryptedString);
		char folder[256];
		folder[0] = '\0';

		char moduleName[256];
		moduleName[0] = '\0';
		char productKey[256];
		productKey[0] = '\0';
		BOOL bSuccess = GetDecFolderModuleproductKey(decryptedStringCopy, folder, moduleName, productKey);
		productKey[36] = '\0';
		if (bSuccess == FALSE)
			return 1;



		char* actualPhysicalFolder = GetActualPhysicalFolder((char *)szInFile);

		if (strlen(actualPhysicalFolder) == 0)
			return 1;

		int iCmp = strcmp(actualPhysicalFolder, folder);
		if (iCmp != 0)
			return 1;

		//check module name format is correct
		/*char *splitChar = ".";
		char* tokenizedModuleName = new char[strlen(moduleName) + 1];
		strcpy(tokenizedModuleName, moduleName);
		char *token = strtok(tokenizedModuleName, splitChar);
		iCmp = strcmp(actualPhysicalFolder, token);

		if (iCmp != 0)
		return 1;*/


		BOOL bVerified = VerifyModuleNameLicenseKeyinSettingsJson(moduleName, szAppSettingsJson, productKey);

		if (bVerified == FALSE)
			return 1;

		if (actualPhysicalFolder != NULL)
			delete actualPhysicalFolder;

		//if (tokenizedModuleName != NULL)
		//delete tokenizedModuleName;

		if (decryptedStringCopy != NULL)
			delete decryptedStringCopy;
	}
	else
		return 1;

	if (pDecryptedString != NULL)
	{
		free(pDecryptedString);
		pDecryptedString = NULL;
	}
	return 0;

}
TCHAR * DecryptInFile(const char* szInFile)
{

	HANDLE hInFile = INVALID_HANDLE_VALUE;
	BYTE* pbInFileContents = NULL;
	try
	{

		if ((hInFile = CreateFile(

			szInFile,

			GENERIC_READ,

			0,

			NULL,

			OPEN_ALWAYS,

			FILE_ATTRIBUTE_NORMAL,

			NULL

			)) == INVALID_HANDLE_VALUE)
			return "";

		DWORD dwInFileLen = 0;
		if ((dwInFileLen = GetFileSize(hInFile, NULL)) == INVALID_FILE_SIZE)
		{
			if (hInFile != INVALID_HANDLE_VALUE)
			{
				CloseHandle(hInFile);
				hInFile = INVALID_HANDLE_VALUE;
			}
			hInFile = INVALID_HANDLE_VALUE;
			return "";
		}

		if (dwInFileLen == 0)
			return "";
		if (!(pbInFileContents = (BYTE *)malloc(dwInFileLen)))
		{
			if (hInFile != INVALID_HANDLE_VALUE)
			{
				CloseHandle(hInFile);
				hInFile = INVALID_HANDLE_VALUE;
			}
			return "";
		}


		// Read public key
		if (!ReadFile(hInFile, pbInFileContents, dwInFileLen, &dwInFileLen, NULL))
		{
			if (hInFile != INVALID_HANDLE_VALUE)
			{
				CloseHandle(hInFile);
				hInFile = INVALID_HANDLE_VALUE;
			}
			if (pbInFileContents != NULL)
			{
				free(pbInFileContents);
				pbInFileContents = NULL;
			}
			hInFile = INVALID_HANDLE_VALUE;
			return "";
		}
		CryptoApi crypt;
		crypt.Init(password);

		if (!crypt.DeCrypt(pbInFileContents, dwInFileLen))
		{
			if (hInFile != INVALID_HANDLE_VALUE)
			{
				CloseHandle(hInFile);
				hInFile = INVALID_HANDLE_VALUE;
			}
			if (pbInFileContents != NULL)
			{
				free(pbInFileContents);
				pbInFileContents = NULL;
			}
			hInFile = INVALID_HANDLE_VALUE;
			return "";
		}

		pbInFileContents[dwInFileLen] = '\0';

		if (hInFile != INVALID_HANDLE_VALUE)
		{
			CloseHandle(hInFile);
			hInFile = INVALID_HANDLE_VALUE;
		}


	}
	catch (...)
	{


	}

	if (hInFile != INVALID_HANDLE_VALUE)
	{
		CloseHandle(hInFile);
		hInFile = INVALID_HANDLE_VALUE;
	}
	return (TCHAR*)pbInFileContents;

}

BOOL  GetDecFolderModuleproductKey(char * decryptedStringCopy, char *folder, char * moduleName, char *productKey)
{
	BOOL bRet = TRUE;
	try

	{
		const char s[3] = "$$";
		char *token;


		/* get the first token */
		token = strtok(decryptedStringCopy, s);
		strcpy(folder, token);

		if (token == NULL)
			return FALSE;
		int i = 0;
		while (token != NULL)
		{
			token = strtok(NULL, s);
			if (token == NULL)
				break;

			if (i == 0) strcpy(moduleName, token);
			else if (i == 1) strcpy(productKey, token);
			i++;
		}
	}
	catch (...)
	{
		bRet = FALSE;
	}
	return bRet;
}

char*  GetActualPhysicalFolder(char * szInFile)
{

	char* folderName = new char[256];
	folderName[0] = '\0';
	try
	{
		char* folderOnly = new char[strlen(szInFile) + sizeof(char)];
		memset(folderOnly, 0, sizeof(folderOnly));
		strcpy(folderOnly, szInFile);
		PathRemoveFileSpec(folderOnly);


		//Check directory name matches

		char * splitChar = "\\";
		char * token = strtok(folderOnly, splitChar);
		while (token != NULL)
		{
			token = strtok(NULL, splitChar);
			if (token != NULL && strlen(token) > 0)
				strcpy(folderName, token);

		}
		if (folderOnly != NULL)
			delete folderOnly;
		if (token != NULL)
			delete token;
	}
	catch (...)
	{

	}
	return folderName;
}

BOOL VerifyModuleNameLicenseKeyinSettingsJson(char *moduleName, const char* szAppSettingsJson, char* productKey)
{
	BOOL bRet = TRUE;
	HANDLE hInFile = INVALID_HANDLE_VALUE;
	try

	{

		if ((hInFile = CreateFile(

			szAppSettingsJson,

			GENERIC_READ,

			0,

			NULL,

			OPEN_ALWAYS,

			FILE_ATTRIBUTE_NORMAL,

			NULL

			)) == INVALID_HANDLE_VALUE)
			return FALSE;


		DWORD dwInFileLen = 0;
		if ((dwInFileLen = GetFileSize(hInFile, NULL)) == INVALID_FILE_SIZE)
		{
			if (hInFile != INVALID_HANDLE_VALUE)
			{
				CloseHandle(hInFile);
				hInFile = INVALID_HANDLE_VALUE;
			}
			return FALSE;
		}



		BYTE* pbInFileContents = NULL;
		if (!(pbInFileContents = (BYTE*)malloc(dwInFileLen)))
		{
			if (hInFile != INVALID_HANDLE_VALUE)
			{
				CloseHandle(hInFile);
				hInFile = INVALID_HANDLE_VALUE;
			}
			return FALSE;
		}


		memset(pbInFileContents, 0, dwInFileLen);


		DWORD dwLengthRead = 0;
		if (!ReadFile(hInFile, (char *)pbInFileContents, dwInFileLen, &dwLengthRead, NULL))
		{
			if (hInFile != INVALID_HANDLE_VALUE)
			{
				CloseHandle(hInFile);
				hInFile = INVALID_HANDLE_VALUE;
			}
			return FALSE;
		}


		pbInFileContents[dwLengthRead - 1] = '\0';



		JSONNODE *obj = json_parse((char*)pbInFileContents);

		if (obj == NULL)
		{
			if (hInFile != INVALID_HANDLE_VALUE)
			{
				CloseHandle(hInFile);
				hInFile = INVALID_HANDLE_VALUE;
			}
			return FALSE;
		}

		JSONNODE *sectionInJson = json_get(obj, "section");
		if (sectionInJson == NULL)
		{
			if (hInFile != INVALID_HANDLE_VALUE)
			{
				CloseHandle(hInFile);
				hInFile = INVALID_HANDLE_VALUE;
			}
			return FALSE;
		}

		JSONNODE* LicenseKeyInJson = json_get(sectionInJson, "LicenseKey");
		if (LicenseKeyInJson == NULL)
		{
			if (hInFile != INVALID_HANDLE_VALUE)
			{
				CloseHandle(hInFile);
				hInFile = INVALID_HANDLE_VALUE;
			}
			return FALSE;
		}
		const char *LicenseKeyJsonValue = json_as_string(LicenseKeyInJson);

		int iCmp = strcmp(LicenseKeyJsonValue, productKey);
		if (iCmp != 0)
		{
			if (hInFile != INVALID_HANDLE_VALUE)
			{
				CloseHandle(hInFile);
				hInFile = INVALID_HANDLE_VALUE;
			}
			return FALSE;

		}

		JSONNODE* appInJson = json_get(sectionInJson, "app");
		JSONNODE* subsection = NULL;
		if (appInJson == NULL)
		{
			subsection = json_get(sectionInJson, "subsections");
			appInJson = json_get(subsection, "app");
		}
		if (appInJson == NULL)
		{
			if (hInFile != INVALID_HANDLE_VALUE)
			{
				CloseHandle(hInFile);
				hInFile = INVALID_HANDLE_VALUE;
			}
			return FALSE;
		}

		JSONNODE* moduleNameInJson = json_get(appInJson, "moduleName");
		if (moduleNameInJson == NULL)
		{
			if (hInFile != INVALID_HANDLE_VALUE)
			{
				CloseHandle(hInFile);
				hInFile = INVALID_HANDLE_VALUE;
			}
			return FALSE;
		}

		const char *moduleNameJsonValue = json_as_string(moduleNameInJson);
		if (moduleNameJsonValue == NULL)
		{
			if (hInFile != INVALID_HANDLE_VALUE)
			{
				CloseHandle(hInFile);
				hInFile = INVALID_HANDLE_VALUE;
			}
			return FALSE;
		}

		iCmp = strcmp(moduleNameJsonValue, moduleName);
		if (iCmp != 0)
		{
			if (hInFile != INVALID_HANDLE_VALUE)
			{
				CloseHandle(hInFile);
				hInFile = INVALID_HANDLE_VALUE;
			}
			return FALSE;
		}

		if (moduleNameJsonValue != NULL)
			json_free((void*)moduleNameJsonValue);



		if (obj != NULL)
			json_delete(obj);

		if (hInFile != INVALID_HANDLE_VALUE)
		{
			CloseHandle(hInFile);
			hInFile = INVALID_HANDLE_VALUE;
		}

	}
	catch (...)
	{
		bRet = FALSE;
	}
	if (hInFile != INVALID_HANDLE_VALUE)
	{
		CloseHandle(hInFile);
		hInFile = INVALID_HANDLE_VALUE;
	}
	return bRet;

}

