﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;

using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.IO;

namespace App_Licenser
{
    public partial class Form1 : Form
    {

        [DllImport("AppEncryptor.dll", EntryPoint = "EDF", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
        private static extern Int32 Api_Encrypt(StringBuilder inFile,StringBuilder outFile);
        [DllImport("AppEncryptor.dll", EntryPoint = "DFCF", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
        private static extern Int32 Api_Decrypt(string inFile, string outFile);
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnEncrypt_Click(object sender, EventArgs e)
        {

            string decryptedFilePath = string.Empty;
            btnEncrypt.Enabled = false;
            try
            {
                if (txtFolderName.Text == null || txtFolderName.Text.Trim().Length == 0 || txtModuleName.Text == null || txtModuleName.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Please enter folder name and module name. Both are mandatory");
                    btnEncrypt.Enabled = true;
                    return;
                }
                string pluginRootPath = CreatePluginRootIfNotAvailable();
                if(pluginRootPath == null || pluginRootPath.Trim().Length == 0)
                {
                    MessageBox.Show("Plugin root directory could not be created");
                    btnEncrypt.Enabled = true;
                    return;
                }
                string guid = System.Guid.NewGuid().ToString();
                string textToEncrypt = txtFolderName.Text.Trim() + "$$" + txtModuleName.Text.Trim() + "$$" + guid;
                string appDirectory = pluginRootPath + "\\" + txtFolderName.Text.Trim();
                System.IO.DirectoryInfo dirInfo =  System.IO.Directory.CreateDirectory(appDirectory);
                if(dirInfo == null )
                {
                    MessageBox.Show("App directory could not be created");
                    btnEncrypt.Enabled = true;
                    return;
                }
                string decryptedLicenseFileName = "LicenseKey_decrypted.pk";
                decryptedFilePath = dirInfo.FullName + "\\" + decryptedLicenseFileName;
                FileStream fs = File.Open(decryptedFilePath, FileMode.Create) ;
                if(fs == null )
                {
                    MessageBox.Show("Decrypted file path could not be created");
                    btnEncrypt.Enabled = true;
                    return;
                }
                fs.Close();
                StreamWriter sw = new StreamWriter(decryptedFilePath);
                sw.WriteLine(textToEncrypt);
                sw.Close();

                string encryptedFileName = "LicenseKey.pk";
                string encryptedFilePath = dirInfo.FullName + "\\" + encryptedFileName;
                StringBuilder strBuildDecrypted = new StringBuilder(decryptedFilePath);
                StringBuilder strBuildEncrypted = new StringBuilder(encryptedFilePath);

                int iResult  = Api_Encrypt(strBuildDecrypted, strBuildEncrypted);
                if(iResult != 0)
                {
                    MessageBox.Show("Encryption failed");
                    btnEncrypt.Enabled = true;
                    return;
                }
                txtLicenseKey.Text = guid;
                //Write license key to a file as well
                string appSettingsFileName = "AppSettingsEntry.txt";
                string appSettingsFile = dirInfo.FullName + "\\" + appSettingsFileName;

                fs = File.Open(appSettingsFile, FileMode.Create);
                if (fs == null)
                {
                    MessageBox.Show("Decrypted file path could not be created");
                    btnEncrypt.Enabled = true;
                    return;
                }
                fs.Close();
                sw = new StreamWriter(appSettingsFile);
                sw.WriteLine("\"LicenseKey\":\"" + guid + "\"");
                sw.Close();
                MessageBox.Show("Encryption completed successfully. Please check folder - " + dirInfo.FullName + " Folder for the output files");
            }
            catch(Exception ex)
            {
                btnEncrypt.Enabled = true;
                MessageBox.Show("Encryption failed with exception -  " + ex.Message);
            }
            finally
            {
                if (decryptedFilePath != null && decryptedFilePath.Trim().Length > 0)
                    System.IO.File.Delete(decryptedFilePath);
            }

        }

        private string  CreatePluginRootIfNotAvailable()
        {
            string plugin_root = string.Empty;
            try
            {
                string pluginroot = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly().Location) + "\\plugin_root";
               System.IO.DirectoryInfo dirInfo = System.IO.Directory.CreateDirectory(pluginroot);
               plugin_root = dirInfo.FullName;
            }
            catch
            {

            }
            return plugin_root;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            btnEncrypt.Enabled = true;
            txtFolderName.Text = string.Empty;
            txtModuleName.Text = string.Empty;
            txtLicenseKey.Text = string.Empty;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Api_Decrypt(@"D:\WorkingFolder\iManage\SourceCode\ChicagoGit\LicenseFiles\imWebConfig\imWebConfig\Licensekey.pk", @"C:\Users\rammanohar\Downloads\imWebConfig\imWebConfig\appSettings.json");
        }
    }
}
